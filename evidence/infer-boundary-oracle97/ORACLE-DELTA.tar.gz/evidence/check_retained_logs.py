import hashlib
import importlib.util
import json
import pathlib
import tarfile


ROOT = pathlib.Path('/Users/tommyvolk/.t3/worktrees/verus/t3-60978068')
OUTPUT = pathlib.Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location(
    'boundaries', ROOT / 'source/tools/check_native_resource_boundaries.py',
)
BOUNDARIES = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(BOUNDARIES)
CHECKS = []
ARCHIVES = {
    'evidence/infer-consolidation95/REVIEWED-CANDIDATE.tar.gz': {
        'evidence/replay2/default-off-tests.log', 'evidence/replay2/feature-on-tests.log',
        'evidence/replay3/default-off-tests.log', 'evidence/replay3/feature-on-tests.log',
    },
    'evidence/infer-boundary-followup96/REVIEWED-CANDIDATE.tar.gz': {
        'evidence/focused3/default-off-tests.log',
        'evidence/replay3/default-off-tests.log', 'evidence/replay3/feature-on-tests.log',
    },
}
for archive_name, expected_passes in ARCHIVES.items():
    with tarfile.open(ROOT / archive_name, 'r:gz') as archive:
        for member in archive.getmembers():
            if not member.name.endswith('-tests.log'):
                continue
            raw = archive.extractfile(member).read()
            accepted = BOUNDARIES.checked_test_log(raw.decode())
            expected = member.name in expected_passes
            CHECKS.append({
                'source_archive': archive_name, 'member': member.name,
                'sha256': hashlib.sha256(raw).hexdigest(),
                'accepted': accepted, 'expected': expected,
            })
assert len(CHECKS) == 10
assert all(item['accepted'] == item['expected'] for item in CHECKS), CHECKS
RESULT = {
    'classification': 're-evaluation of retained logs, not new Cargo execution',
    'current_runner_sha256': hashlib.sha256(
        (ROOT / 'source/tools/check_native_resource_boundaries.py').read_bytes(),
    ).hexdigest(),
    'initial_check_harness_error': (
        'The first check incorrectly classified historical hardening95 replay1 as passing. '
        'Its sealed receipt is unsuccessful and its raw log reports four passed, one failed. '
        'The new parser correctly rejected it. No source correction followed this harness error.'
    ),
    'checks': CHECKS,
}
with (OUTPUT / 'retained-log-checks.json').open('x') as output:
    json.dump(RESULT, output, indent=2)
    output.write('\n')
for item in CHECKS:
    print(item['source_archive'], item['member'], item['accepted'])
