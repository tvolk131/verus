import dataclasses
import itertools
import json
from pathlib import Path


@dataclasses.dataclass(frozen=True)
class Root:
    page: int
    checksum: int
    length: int


@dataclasses.dataclass(frozen=True)
class Payload:
    transaction_id: int
    user_root: object
    system_root: object
    version: int = 3


@dataclasses.dataclass(frozen=True)
class Header:
    primary_slot: int
    two_phase_commit: bool
    primary_unflushed: bool
    recovery_required: bool
    slots: tuple
    geometry: tuple = (4096, 1, 64, 2, 0)


def stage(before, transaction_id, user_root, system_root):
    if before.primary_slot not in (0, 1):
        raise ValueError('physical slot must be zero or one')
    primary = before.slots[before.primary_slot]
    if not primary.transaction_id < transaction_id <= 2 ** 64 - 1:
        raise ValueError('transaction ID must increase without overflow')
    secondary_index = before.primary_slot ^ 1
    replacement = Payload(transaction_id, user_root, system_root,
                          before.slots[secondary_index].version)
    slots = list(before.slots)
    slots[secondary_index] = replacement
    prepared = dataclasses.replace(before, slots=tuple(slots))
    committed = dataclasses.replace(prepared, primary_slot=secondary_index,
                                    two_phase_commit=True, primary_unflushed=False)
    return prepared, committed


def selected_payload(header):
    primary = header.slots[header.primary_slot]
    secondary = header.slots[header.primary_slot ^ 1]
    if not header.two_phase_commit and secondary.transaction_id > primary.transaction_id:
        return secondary
    return primary


def relation(before, transaction_id, user_root, system_root, prepared, committed):
    secondary = before.primary_slot ^ 1
    expected = Payload(transaction_id, user_root, system_root,
                       before.slots[secondary].version)
    return all((
        prepared.primary_slot == before.primary_slot,
        prepared.two_phase_commit == before.two_phase_commit,
        prepared.primary_unflushed == before.primary_unflushed,
        prepared.recovery_required == before.recovery_required,
        prepared.geometry == before.geometry,
        prepared.slots[before.primary_slot] == before.slots[before.primary_slot],
        prepared.slots[secondary] == expected,
        committed.primary_slot == secondary,
        committed.two_phase_commit is True,
        committed.primary_unflushed is False,
        committed.recovery_required == before.recovery_required,
        committed.geometry == before.geometry,
        committed.slots == prepared.slots,
        selected_payload(committed) == expected,
    ))


def fixture(primary_slot=0, prior_mode=False, unflushed=True, recovery=True):
    return Header(primary_slot, prior_mode, unflushed, recovery,
                  (Payload(7, Root(1, 11, 111), None, 1),
                   Payload(9, None, Root(2, 22, 222), 3)))


def sample_cases():
    roots = (None, Root(3, 33, 333), Root(5, 55, 555))
    for primary_slot, prior_mode, unflushed, recovery, user_root, system_root in itertools.product(
            (0, 1), (False, True), (False, True), (False, True), roots, roots):
        before = fixture(primary_slot, prior_mode, unflushed, recovery)
        prepared, committed = stage(before, 12, user_root, system_root)
        yield before, user_root, system_root, prepared, committed


def semantic_controls():
    before = fixture()
    user_root = Root(3, 33, 333)
    system_root = Root(5, 55, 555)
    prepared, committed = stage(before, 12, user_root, system_root)
    cases = {
        'premature_mode_change': (dataclasses.replace(prepared, two_phase_commit=True), committed),
        'missing_selector_swap': (prepared, dataclasses.replace(committed, primary_slot=before.primary_slot)),
        'uncleared_unflushed': (prepared, dataclasses.replace(committed, primary_unflushed=True)),
        'changed_geometry': (dataclasses.replace(prepared, geometry=(8192, 1, 64, 2, 0)), committed),
        'lost_old_primary': (dataclasses.replace(prepared, slots=(committed.slots[1], prepared.slots[1])), committed),
        'swapped_associations': (prepared, dataclasses.replace(committed, slots=(prepared.slots[0],
            dataclasses.replace(prepared.slots[1], user_root=system_root, system_root=user_root)))),
    }
    corrected = relation(before, 12, user_root, system_root, prepared, committed)
    return {name: {'mutant_relation': relation(before, 12, user_root, system_root, *headers),
                   'corrected_relation': corrected} for name, headers in cases.items()}


def evidence():
    cases = list(sample_cases())
    assert all(relation(before, 12, user_root, system_root, prepared, committed)
               for before, user_root, system_root, prepared, committed in cases)
    outcomes = semantic_controls()
    assert all(not pair['mutant_relation'] and pair['corrected_relation'] for pair in outcomes.values())
    return {
        'scope': 'FINITE_INDEPENDENT_FIELD_PROJECTION_NOT_NATIVE_CODEC_OR_STORAGE_SEMANTICS',
        'finite_header_cases': len(cases),
        'paired_semantic_controls': outcomes,
        'all18': 'OPEN',
        'new_native_bodies_checked': 0,
        'acceptance': False,
        'adoption': False,
    }


if __name__ == '__main__':
    destination = Path(__file__).with_name('controls111-results.json')
    assert not destination.exists()
    destination.write_text(json.dumps(evidence(), indent=2, sort_keys=True) + '\n')
    print(destination)
