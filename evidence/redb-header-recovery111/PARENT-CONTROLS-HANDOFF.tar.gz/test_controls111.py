import dataclasses
import unittest

import controls111 as controls


class HeaderProjectionTests(unittest.TestCase):
    def test_finite_projection(self):
        self.assertEqual(controls.evidence()['finite_header_cases'], 144)

    def test_six_mutant_corrected_pairs(self):
        outcomes = controls.semantic_controls()
        self.assertEqual(len(outcomes), 6)
        for name, outcome in outcomes.items():
            with self.subTest(name=name):
                self.assertFalse(outcome['mutant_relation'])
                self.assertTrue(outcome['corrected_relation'])

    def test_both_previous_modes_remain_in_first_header(self):
        for mode in (False, True):
            before = controls.fixture(prior_mode=mode)
            prepared, committed = controls.stage(before, 12, None, None)
            self.assertEqual(prepared.two_phase_commit, mode)
            self.assertTrue(committed.two_phase_commit)

    def test_old_primary_remains_unchanged_for_both_indices(self):
        for primary in (0, 1):
            before = controls.fixture(primary_slot=primary)
            prepared, committed = controls.stage(before, 12, None, None)
            self.assertEqual(prepared.slots[primary], before.slots[primary])
            self.assertEqual(committed.slots[primary], before.slots[primary])

    def test_secondary_version_is_preserved(self):
        for primary in (0, 1):
            before = controls.fixture(primary_slot=primary)
            prepared, committed = controls.stage(before, 12, None, None)
            self.assertEqual(committed.slots[primary ^ 1].version, before.slots[primary ^ 1].version)

    def test_maximum_id_does_not_require_a_successor(self):
        before = controls.fixture()
        prepared, committed = controls.stage(before, 2 ** 64 - 1, None, None)
        self.assertEqual(controls.selected_payload(committed).transaction_id, 2 ** 64 - 1)

    def test_equal_id_is_rejected(self):
        with self.assertRaises(ValueError):
            controls.stage(controls.fixture(), 7, None, None)

    def test_out_of_range_id_is_rejected(self):
        with self.assertRaises(ValueError):
            controls.stage(controls.fixture(), 2 ** 64, None, None)

    def test_payload_label_is_not_physical_slot(self):
        before = dataclasses.replace(controls.fixture(), primary_slot=3)
        with self.assertRaises(ValueError):
            controls.stage(before, 12, None, None)

    def test_prior_onephase_prepared_header_selects_newer_secondary(self):
        before = controls.fixture(prior_mode=False)
        prepared, committed = controls.stage(before, 12, None, None)
        self.assertEqual(controls.selected_payload(prepared).transaction_id, 12)

    def test_prior_twophase_prepared_header_retains_old_selection(self):
        before = controls.fixture(prior_mode=True)
        prepared, committed = controls.stage(before, 12, None, None)
        self.assertEqual(controls.selected_payload(prepared).transaction_id, 7)

    def test_final_selection_transports_both_associated_roots(self):
        user_root = controls.Root(3, 33, 333)
        system_root = controls.Root(5, 55, 555)
        prepared, committed = controls.stage(controls.fixture(), 12, user_root, system_root)
        payload = controls.selected_payload(committed)
        self.assertEqual((payload.user_root, payload.system_root), (user_root, system_root))

    def test_no_native_acceptance_is_reported(self):
        evidence = controls.evidence()
        self.assertEqual(evidence['all18'], 'OPEN')
        self.assertEqual(evidence['new_native_bodies_checked'], 0)
        self.assertFalse(evidence['acceptance'])
        self.assertFalse(evidence['adoption'])


if __name__ == '__main__':
    unittest.main(verbosity=2)
