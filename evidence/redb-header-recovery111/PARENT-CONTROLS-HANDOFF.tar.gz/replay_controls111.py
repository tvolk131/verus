import datetime
import json
import os
from pathlib import Path
import signal
import subprocess
import sys

from check import ROOT, authenticate, identity


def replay():
    directory = ROOT / 'parent-controls-replay'
    directory.mkdir()
    authenticate(directory / 'authentication-entry.json')
    sources = [Path(__file__), ROOT / 'controls111.py', ROOT / 'test_controls111.py',
               Path(sys.executable).resolve()]
    before = [identity(filename) for filename in sources]
    environment = {
        'PATH': '/usr/bin:/bin:/usr/sbin:/sbin',
        'HOME': str(directory / 'home'),
        'PYTHONDONTWRITEBYTECODE': '1',
        'PYTHONPATH': str(ROOT),
        'TMPDIR': str(directory / 'tmp'),
    }
    Path(environment['HOME']).mkdir()
    Path(environment['TMPDIR']).mkdir()
    commands = [
        [sys.executable, '-B', '-m', 'unittest', '-v', 'test_controls111'],
        [sys.executable, '-B', '-c',
         'import controls111, json; print(json.dumps(controls111.evidence(), indent=2, sort_keys=True))'],
    ]
    outcomes = []
    for number, argv in enumerate(commands, 1):
        prefix = directory / ('command-%02d' % number)
        authenticate(prefix.with_suffix('.authentication-preexecution.json'))
        assert [identity(filename) for filename in sources] == before
        invocation = {'argv': argv, 'environment': environment, 'cwd': str(ROOT),
                      'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                      'inputs': before, 'timeout_seconds': 30}
        prefix.with_suffix('.invocation.json').write_text(json.dumps(invocation, indent=2) + '\n')
        process = None
        interrupted = None
        timed_out = False
        status = None
        with prefix.with_suffix('.stdout').open('wb') as stdout, prefix.with_suffix('.stderr').open('wb') as stderr:
            try:
                process = subprocess.Popen(argv, cwd=ROOT, env=environment, stdin=subprocess.DEVNULL,
                                           stdout=stdout, stderr=stderr, start_new_session=True)
                status = process.wait(timeout=30)
            except (subprocess.TimeoutExpired, KeyboardInterrupt) as error:
                timed_out = isinstance(error, subprocess.TimeoutExpired)
                interrupted = None if timed_out else error
                if process is not None:
                    os.killpg(process.pid, signal.SIGKILL)
                    status = process.wait()
        authenticate(prefix.with_suffix('.authentication-exit.json'))
        outcome = {'number': number, 'status': status, 'timed_out': timed_out,
                   'interrupted': interrupted is not None,
                   'completed_zero_exit': status == 0 and not timed_out and interrupted is None}
        prefix.with_suffix('.result.json').write_text(json.dumps(outcome, indent=2) + '\n')
        outcomes.append(outcome)
        if interrupted is not None:
            raise interrupted
        assert outcome['completed_zero_exit']
    assert (directory / 'command-02.stdout').read_bytes() == (ROOT / 'controls111-results.json').read_bytes()
    assert [identity(filename) for filename in sources] == before
    authenticate(directory / 'authentication-exit.json')
    receipt = {
        'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'scope': 'FINITE_FIELD_PROJECTION_ONLY_NOT_NATIVE_SEMANTICS',
        'outcomes': outcomes,
        'unit_tests': 13,
        'finite_header_cases': 144,
        'semantic_mutant_corrected_pairs': 6,
        'selected_input_matches': 1416,
        'first_unreceipted_run_preserved': True,
        'all18': 'OPEN',
        'acceptance': False,
        'adoption': False,
    }
    (directory / 'RESULTS.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt, indent=2))


if __name__ == '__main__':
    replay()
