# Operational matched-runtime selection

The first parent application failed before verification with PermissionError13:
the historical launcher is a regular file with mode0400, not executable. That
attempt remains charged and retained in parent-check-01-shared-contract.

No frozen permission bits, bytes, runtime or toolchain were changed or copied.
The repaired runner checks SHA256 equality of the historical and executable
midpoint verus, rust_verify and z3 files, runs the executable midpoint launcher
with VERUS_ROOT pointing at the historical runtime and VERUS_Z3_PATH pointing at
the executable midpoint solver, and removes VARGO_TARGET_DIR from the environment.
The historical vstd and exact provider pairs remain the dependency set.

Parent application2 passed with exact fresh metadata export, zero errors and
zero verified bodies: contract111.rs contains open definitions only. All1416
selected inputs authenticate at entry, immediately before execution and at exit.
The raw invocation and result record the actual environment and executable path.
No native application or build ran. This is operational compatibility evidence,
not proof of the current source's correspondence to the frozen binary.

The parent finite controls independently exercise144 abstract field-projection
cases and six semantic mutant/corrected pairs. They are not a byte serializer,
Rust semantics, native recovery, storage or theorem acceptance. The actual
encoder/parser/recovery claims belong to the independent proof lanes.
