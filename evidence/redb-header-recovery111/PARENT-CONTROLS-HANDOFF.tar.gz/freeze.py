import datetime
import hashlib
import json
from pathlib import Path
import shutil


PARENT = Path('/Users/tommyvolk/.t3/worktrees/verus/t3-60978068')
DESTINATION = PARENT / 'evidence/redb-header-recovery111'
PREVIOUS = PARENT / 'evidence/redb-storage-composition110'
SCRATCH = Path('/private/tmp/redb-header-recovery111-20261108T051418Z')
HISTORICAL = Path('/private/tmp/verus-crash-consistency94-20261105/native-recovery-reencoding-021')


def identity(filename):
    content = filename.read_bytes()
    return {'path': str(filename), 'bytes': len(content), 'sha256': hashlib.sha256(content).hexdigest()}


records = {}
previous = json.loads((PREVIOUS / 'INPUTS.json').read_text())
previous_result = json.loads((PREVIOUS / 'ROUND-RESULTS.json').read_text())
expected_documents = {record['path']: record for record in previous_result['selected_inputs']['expected_post_review_document_updates']}
document_updates = []
for record in previous['records']:
    filename = Path(record['path'])
    current = identity(filename)
    if str(filename) in expected_documents:
        prior_update = expected_documents[str(filename)]
        assert identity(PREVIOUS / prior_update['snapshot'])['sha256'] == record['sha256']
        document_updates.append({
            'path': str(filename),
            'round110_frozen_sha256': record['sha256'],
            'round110_reconciled_sha256': prior_update['reconciled_sha256'],
            'round111_current_sha256': current['sha256'],
            'reason': 'Reviewed round110 reconciliation followed by explicit distinct-task111 scope entry',
        })
    else:
        assert current['sha256'] == record['sha256'], str(filename)
    records[str(filename)] = current
for record in json.loads((PREVIOUS / 'ROUND-MANIFEST.json').read_text())['files']:
    filename = PREVIOUS / record['path']
    current = identity(filename)
    assert current['sha256'] == record['sha256'], str(filename)
    records[str(filename)] = current
assert identity(HISTORICAL / 'MANIFEST.json')['sha256'] == '474753727618543b4bcf102250557aa4ca302118c21968306c1245dc5f68ff35'
for relative, record in json.loads((HISTORICAL / 'MANIFEST.json').read_text()).items():
    filename = HISTORICAL / relative
    current = identity(filename)
    assert current['sha256'] == record['sha256'] and current['bytes'] == record['size_bytes'], str(filename)
    records[str(filename)] = current
for name, expected in json.loads((HISTORICAL / 'runtime-binding.json').read_text())['runtime'].items():
    filename = HISTORICAL / 'runtime' / name
    current = identity(filename)
    assert current['sha256'] == expected, str(filename)
    records[str(filename)] = current
review_root = Path('/private/tmp/redb-review110-LwF1feEi')
for record in json.loads((review_root / 'MANIFEST.json').read_text())['files']:
    filename = review_root / record['path']
    current = identity(filename)
    assert current['sha256'] == record['sha256'], str(filename)
    records[str(filename)] = current
module_root = Path('/private/tmp/redb-storage110-laneA-LBwsoPMW/publication/laneA')
for name in ['composition110.rs', 'buffered_flush109.rs', 'ack_cfg.rs']:
    original = module_root / name
    copy = SCRATCH / 'shared' / name
    assert not copy.exists()
    shutil.copyfile(original, copy)
    assert identity(original)['sha256'] == identity(copy)['sha256']
    records[str(original)] = identity(original)
    records[str(copy)] = identity(copy)
for filename in [
    DESTINATION / 'PLAN.md', Path(__file__), SCRATCH / 'shared/contract111.rs',
    PREVIOUS / 'ROUND-MANIFEST.json', HISTORICAL / 'MANIFEST.json', HISTORICAL / 'SEAL.json',
    review_root / 'MANIFEST.json', review_root / 'SEAL.json', review_root / 'HANDOFF.json',
]:
    records[str(filename)] = identity(filename)
now = datetime.datetime.now(datetime.timezone.utc).isoformat()
manifest = {
    'schema': 'redb-header-recovery111-frozen-selected-inputs-v1',
    'utc': now,
    'first_read_or_atomic_snapshot_claim': False,
    'documented_live_document_updates': document_updates,
    'historical_round109_drifts': previous['historical_round109_drifts'],
    'historical_round110_document_updates': previous['documented_authorization_and_reconciliation_updates'],
    'compiler_source_correspondence': 'UNESTABLISHED',
    'native_path_preservation': 'FAILED',
    'native_git_continuity': 'UNAVAILABLE',
    'inherited_boundary': 'EXPLICIT_INHERITED_STD_BOOL_TCB_NOT_RUST_CORE_PROOF',
    'records': [records[name] for name in sorted(records)],
}
assert not (DESTINATION / 'INPUTS.json').exists()
(DESTINATION / 'INPUTS.json').write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
authorization = {
    'schema': 'redb-header-recovery111-standing-scope-v1',
    'authorization': 'STANDING_ROUTINE_PROOF_DEBUG_REVIEW_PERMISSION_DISTINCT_CONSUMER_COMPOSITION_NOT_OLD_ALLOWANCE_RESET',
    'clarification': str(PREVIOUS / 'CONTINUATION-AUTHORIZATION.md'),
    'round_start_utc': '2026-11-08T05:14:18Z',
    'optional_work_stop_utc': '2026-11-08T06:02:18Z',
    'hard_deadline_utc': '2026-11-08T06:14:18Z',
    'scratch_cap_bytes': 4 * 1024 ** 3,
    'global_free_floor_bytes': 16 * 1024 ** 3,
    'free_bytes_at_freeze': shutil.disk_usage('/private/tmp').free,
    'plan': identity(DESTINATION / 'PLAN.md'),
    'inputs': identity(DESTINATION / 'INPUTS.json'),
    'new_builds_authorized': False,
    'new_trust_adoption_authorized': False,
    'parent_source_integration_authorized': False,
    'excluded_work_authorized': False,
    'parent_application_cap': 4,
    'all18': 'OPEN',
}
assert authorization['free_bytes_at_freeze'] > authorization['global_free_floor_bytes']
(DESTINATION / 'AUTHORIZATION.json').write_text(json.dumps(authorization, indent=2, sort_keys=True) + '\n')
print(json.dumps({'utc': now, 'selected_inputs': len(records), 'documented_live_document_updates': len(document_updates), 'plan_sha256': authorization['plan']['sha256'], 'inputs_sha256': authorization['inputs']['sha256'], 'shared': {path.name: identity(path)['sha256'] for path in (SCRATCH / 'shared').iterdir()}, 'free_bytes': authorization['free_bytes_at_freeze']}, indent=2))
