import datetime
import json
from pathlib import Path
import shutil
import tarfile

from check import EVIDENCE, ROOT, authenticate, identity


def retain():
    destination = ROOT / 'parent-retained'
    destination.mkdir()
    authenticate(destination / 'authentication-entry.json')
    names = [
        'check.py', 'freeze.py', 'controls111.py', 'test_controls111.py',
        'replay_controls111.py', 'retain_parent111.py', 'OPERATIONAL-RUNTIME.md',
        'controls111-results.json', 'controls111-unittest.stdout',
        'controls111-unittest.stderr', 'PARENT-APPLICATIONS.json',
    ]
    for directory in ['parent-controls-replay', 'parent-check-01-shared-contract',
                      'parent-check-02-shared-contract']:
        names.extend(str(filename.relative_to(ROOT)) for filename in (ROOT / directory).rglob('*')
                     if filename.is_file())
    for name in sorted(names):
        source = ROOT / name
        assert not source.is_symlink()
        target = destination / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
        assert source.read_bytes() == target.read_bytes()
    authenticate(destination / 'authentication-exit.json')
    records = []
    for filename in sorted(destination.rglob('*')):
        if filename.is_file():
            record = identity(filename)
            record['path'] = str(filename.relative_to(destination))
            records.append(record)
    manifest = {'scope': 'SELECTED_PARENT_BASELINE_AND_FINITE_CONTROLS', 'files': records}
    (destination / 'MANIFEST.json').write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
    archive_path = EVIDENCE / 'PARENT-CONTROLS-HANDOFF.tar.gz'
    assert not archive_path.exists()
    selected = {record['path'] for record in records} | {'MANIFEST.json'}
    with tarfile.open(archive_path, 'w:gz') as archive:
        for name in sorted(selected):
            archive.add(destination / name, arcname=name, recursive=False)
    with tarfile.open(archive_path, 'r:gz') as archive:
        members = archive.getmembers()
        assert len(members) == len(selected)
        assert {member.name for member in members} == selected
        for member in members:
            assert member.isfile()
            assert archive.extractfile(member).read() == (destination / member.name).read_bytes()
    receipt = {
        'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'source': str(destination), 'archive': identity(archive_path),
        'manifest': identity(destination / 'MANIFEST.json'),
        'selected_payloads': len(records), 'archive_members_compared': len(members),
        'selected_input_matches_entry_and_exit': 1416,
        'parent_applications_charged_so_far': 2,
        'parent_applications_remaining': 2,
        'spec_only_baseline_verified_bodies': 0,
        'launch_failure_preserved_and_charged': True,
        'finite_projection_cases': 144, 'paired_semantic_controls': 6,
        'fresh_python_unit_tests_passed': 13,
        'first_control_run_lacks_immediate_separate_authentication_receipt': True,
        'fresh_control_replay_has_entry_preexecution_exit_receipts': True,
        'native_semantics': False, 'all18': 'OPEN',
        'acceptance': False, 'adoption': False, 'integration': False,
    }
    (EVIDENCE / 'PARENT-CONTROLS-RESULTS.json').write_text(json.dumps(receipt, indent=2, sort_keys=True) + '\n')
    print(json.dumps(receipt, indent=2, sort_keys=True))


if __name__ == '__main__':
    retain()
