import datetime
import json
from pathlib import Path
import shutil

from prepare_finalization111 import (
    EVIDENCE, PARENT, ROOT, authenticate_archive, authenticate_records,
    digest, identity, payloads,
)


REVIEW = Path('/private/tmp/redb-header-recovery111-independent-6VYnqG7c')


def main():
    assert not (EVIDENCE / 'INDEPENDENT-REVIEW-RESULTS.json').exists()
    assert digest(REVIEW / 'HANDOFF.json') == 'a6946007614199c6a891b2cab754f707992c840f6bea98d8e995e7d68c9a8728'
    assert digest(REVIEW / 'SEAL.json') == 'cb56a2d71e08e2720d50bbe4a6abd7538ba9aa7f48a4b81084b84fca70de46b9'
    handoff = json.loads((REVIEW / 'HANDOFF.json').read_text())
    seal = json.loads((REVIEW / 'SEAL.json').read_text())
    assert handoff['all18'] == 'OPEN' and handoff['native_acceptance'] is False
    assert seal['sealed_before_deadline'] is True
    assert digest(REVIEW / 'MANIFEST.json') == handoff['manifest']['sha256'] == '659858690ee445742d451a03f469a9c09658dc99e0eb420fc63ed23d60d00e2b'
    assert digest(REVIEW / 'REPORT.md') == handoff['report']['sha256']
    assert digest(REVIEW / 'REVIEW-HANDOFF.tar.gz') == seal['archive']['sha256'] == 'b565efb00a2e94d0d8ff4dc456a95398bc4dca6a42305b117289d4b0edbe6a8b'
    records = payloads(json.loads((REVIEW / 'MANIFEST.json').read_text()))
    assert len(records) == handoff['payloads'] == 279
    authenticated = authenticate_records(records, REVIEW)
    assert not authenticated['mismatches']
    archived = authenticate_archive(REVIEW, REVIEW / 'REVIEW-HANDOFF.tar.gz', records,
                                    ['MANIFEST.json', 'HANDOFF.json'])
    assert archived['members_byte_compared'] == seal['archive_members'] == 281
    selected = authenticate_records(json.loads((EVIDENCE / 'INPUTS.json').read_text())['records'])
    combined = authenticate_records(json.loads((ROOT / 'COMBINED-INPUTS.json').read_text())['records'])
    assert selected == {'records': 1416, 'mismatches': []}
    assert combined == {'records': 351, 'mismatches': []}
    exit_authentication = json.loads((REVIEW / 'authentication-exit.json').read_text())
    assert all(record['mismatches'] == 0 and record['matches'] == record['records']
               for record in exit_authentication['summary'].values())
    accounting = json.loads((REVIEW / 'ACCOUNTING.json').read_text())
    assert accounting['charged_applications'] == handoff['charged_applications'] == 6
    assert accounting['fully_completed_verifier_applications'] == 4
    assert accounting['interrupted_verifier_processes'] == accounting['prelaunch_setup_failures'] == 1
    assert accounting['new_parent_applications'] == 0
    checks = []
    for number, label, expected_verified, expected_errors in [
        (2, 'combined-positive-retry', 80, 0),
        (4, 'H-mode-and-P-roots-negative', 78, 3),
        (5, 'P-full-positive-witnesses', 71, 0),
        (6, 'combined-byte-identical-restoration', 80, 0),
    ]:
        folder = REVIEW / ('check-%02d-%s' % (number, label))
        invocation = json.loads((folder / 'invocation.json').read_text())
        process = json.loads((folder / 'result.json').read_text())
        raw = json.loads((folder / 'stdout.txt').read_text())
        verification = raw['verification-results']
        success = expected_errors == 0
        assert verification['verified'] == expected_verified
        assert verification['errors'] == expected_errors
        assert verification['success'] == success
        assert not verification['encountered-vir-error']
        assert verification['is-verifying-entire-crate'] is True
        assert process['returncode'] == (0 if success else 1)
        assert process['launcher_error'] is None and process['termination_reason'] is None
        assert process['process_reaped'] is True and process['export_initially_absent'] is True
        assert invocation['export_fresh_absent'] is True
        export_path = Path(invocation['export_path'])
        if success:
            assert digest(export_path) == process['export']['sha256']
        else:
            assert not export_path.exists()
            diagnostics = (folder / 'stderr.txt').read_text()
            assert diagnostics.count('error: assertion failed') == 3
            assert 'staging111.rs:77:16' in diagnostics
            assert 'review_source.rs:12:12' in diagnostics
            assert 'review_source.rs:18:12' in diagnostics
        checks.append({'number': number, 'verification': verification,
                       'source_sha256': invocation['source']['sha256'],
                       'export_present': export_path.exists(), 'returncode': process['returncode']})
    assert checks[0]['source_sha256'] == checks[-1]['source_sha256'] == 'd590effe76335c59044da26cdd51486e0aa87e1dd175eff2f88a9fc8de58c673'
    copied = {}
    for original, destination in {
        'REPORT.md': 'INDEPENDENT-REVIEW.md',
        'HANDOFF.json': 'INDEPENDENT-REVIEW-METADATA.json',
        'SEAL.json': 'INDEPENDENT-REVIEW-SEAL.json',
        'MANIFEST.json': 'INDEPENDENT-REVIEW-MANIFEST.json',
        'ACCOUNTING.json': 'INDEPENDENT-REVIEW-ACCOUNTING.json',
        'FRESH-RAW-SUMMARY.json': 'INDEPENDENT-REVIEW-RAW-SUMMARY.json',
        'REVIEW-HANDOFF.tar.gz': 'INDEPENDENT-REVIEW-HANDOFF.tar.gz',
    }.items():
        target = EVIDENCE / destination
        assert not target.exists()
        shutil.copyfile(REVIEW / original, target)
        assert digest(target) == digest(REVIEW / original)
        copied[original] = identity(target)
    snapshots = {}
    for name, destination in [('GOAL.md', 'HISTORICAL-GOAL.md'),
                               ('STATUS.json', 'HISTORICAL-STATUS.json')]:
        source = PARENT / 'evidence/redb-crash-consistency94' / name
        target = EVIDENCE / destination
        assert not target.exists()
        shutil.copyfile(source, target)
        assert digest(source) == digest(target)
        snapshots[str(source)] = {'snapshot': destination, 'sha256': digest(source)}
    receipt = {
        'schema': 'redb111-independent-review-retention-v1',
        'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'source': str(REVIEW), 'review_completed': True,
        'verdict': handoff['verdict'], 'review_exit_mismatches': 0,
        'charged_applications': 6, 'verifier_launches': 5,
        'fully_completed_verifier_applications': 4,
        'interrupted_reaped_verifier_processes': 1, 'prelaunch_setup_failures': 1,
        'parent_applications_consumed': 0, 'authenticated_payloads': 279,
        'archive_members_compared': 281, 'fresh_checks': checks,
        'archive': identity(REVIEW / 'REVIEW-HANDOFF.tar.gz'),
        'manifest': identity(REVIEW / 'MANIFEST.json'),
        'report': identity(REVIEW / 'REPORT.md'), 'handoff': identity(REVIEW / 'HANDOFF.json'),
        'retained_copies': copied, 'historical_documents_before_reconciliation': snapshots,
        'conjunction_nonvacuity': 'SOURCE_AUDITED_NOT_NEWLY_VERIFIER_CHECKED',
        'historical_ID_negative': 'RAW_AUDITED_NOT_FRESHLY_REPLAYED',
        'fresh_root_negative_wrappers': 'NEW_COMBINED_HARNESS_NOT_INDIVIDUAL_HISTORICAL_WRAPPER_REPLAYS',
        'acceptance': False, 'adoption': False, 'integration': False, 'all18': 'OPEN',
    }
    destination = EVIDENCE / 'INDEPENDENT-REVIEW-RESULTS.json'
    destination.write_text(json.dumps(receipt, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'retained': identity(destination), 'authenticated_payloads': 279,
                      'archive_members_compared': 281, 'fresh_checks': len(checks),
                      'all18': 'OPEN'}, sort_keys=True))


if __name__ == '__main__':
    main()
