import datetime
import json
from pathlib import Path

from check import EVIDENCE, ROOT, authenticate, identity


def capture():
    authenticate(ROOT / 'preservation-audit-authentication-entry.json')
    historical = Path('/private/tmp/verus-crash-consistency94-20261105/native-leaf-lookup-007')
    manifest = json.loads((historical / 'MANIFEST.json').read_text())
    seal = json.loads((historical / 'SEAL.json').read_text())
    assert identity(historical / 'MANIFEST.json')['sha256'] == seal['manifest_sha256']
    names = ['SUMMARY.json', 'binding-check.json', 'finalize.py',
             'preservation-final.json', 'EXTERNAL-LOSS-AND-RECOVERY.md']
    records = []
    for name in names:
        observed = identity(historical / name)
        assert observed['bytes'] == manifest[name]['size_bytes']
        assert observed['sha256'] == manifest[name]['sha256']
        records.append(observed)
    guard = json.loads((historical / 'preservation-final.json').read_text())['guard_observation']
    summary = json.loads((historical / 'SUMMARY.json').read_text())
    assert len(guard['original_missing']) == 1331
    result = {
        'schema': 'redb111-historical-preservation-qualification-v1',
        'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'scope': 'HISTORICAL_RECORD_INTERPRETATION_NOT_REPAIR_OR_CURRENT_ALL_CONTENT_RECHECK',
        'supplemental_discovery_reads_precede_this_captured_comparison': True,
        'supplemental_inputs_not_added_to_frozen_1416': True,
        'manifest': identity(historical / 'MANIFEST.json'),
        'seal': identity(historical / 'SEAL.json'),
        'internally_sealed_records_match': records,
        'historical_missing_original_paths': len(guard['original_missing']),
        'historical_original_path_preservation': guard['original_path_preservation'],
        'historical_recovered_contents_match_reported': guard['recovered_content_hashes_match'],
        'historical_original_git_metadata': summary['original_native_git_metadata'],
        'native_preservation_repaired': False,
        'original_native_git_continuity_repaired': False,
        'new_verifier_applications': 0,
        'all18': 'OPEN', 'acceptance': False, 'adoption': False,
    }
    for record in records:
        assert identity(Path(record['path'])) == record
    destination = EVIDENCE / 'PRESERVATION-QUALIFICATION.json'
    assert not destination.exists()
    destination.write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    authenticate(ROOT / 'preservation-audit-authentication-exit.json')
    print(json.dumps(identity(destination), indent=2))


if __name__ == '__main__':
    capture()
