import collections
import datetime
import json
from pathlib import Path

from prepare_finalization111 import EVIDENCE, ROOT, identity


def main():
    raw_path = ROOT / 'parent-check-03-combined/stdout.txt'
    result_path = ROOT / 'parent-check-03-combined/result.json'
    result = json.loads(result_path.read_text())
    raw = json.loads(raw_path.read_text())
    assert raw['verification-results'] == result['verification']
    assert result['verification']['success'] and result['verification']['verified'] == 80
    inference = raw['verus-infer']
    assert inference['status'] == 'no_inference'
    assert inference['requested_functions'] == inference['generated_functions'] == 0
    assert not inference['functions'] and not inference['failed_functions']
    scope = inference['verification_scope']
    assert scope['complete_selected_scope_verified'] is True
    assert scope['checked_exec_bodies'] == 4 and scope['checked_proof_bodies'] == 59
    bindings = {}
    for manifest_path in [EVIDENCE / 'INPUTS.json', ROOT / 'COMBINED-INPUTS.json']:
        for record in json.loads(manifest_path.read_text())['records']:
            if record['path'] in bindings:
                assert bindings[record['path']] == record
            bindings[record['path']] = record
    checked = [record for record in scope['native_functions']
               if record['body_status'] in ['checked_exec_body', 'checked_proof_body']]
    counts = collections.Counter(record['body_status'] for record in checked)
    assert counts['checked_exec_body'] == 4 and counts['checked_proof_body'] == 59
    source_records = {}
    for record in checked:
        assert record['selected'] is True
        filename = Path(record['source'].split(':', 1)[0])
        assert str(filename) in bindings, str(filename)
        assert identity(filename) == bindings[str(filename)]
        source_records[str(filename)] = bindings[str(filename)]
    report = {
        'schema': 'redb111-parent-combined-raw-scope-audit-v1',
        'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'raw_stdout': identity(raw_path), 'result': identity(result_path),
        'verification': result['verification'],
        'inference_status': inference['status'],
        'requested_inference_functions': inference['requested_functions'],
        'generated_inference_functions': inference['generated_functions'],
        'checked_authored_exec_bodies': 4, 'checked_local_proof_bodies': 59,
        'checked_bodies': checked, 'source_bindings': list(source_records.values()),
        'complete_selected_scope_verified': True,
        'new_original_native_executable_bodies_checked': 0,
        'scope_limits': scope['limitations'],
        'separate_P_witness_and_control_harnesses_in_combined_check': False,
        'interpretation': 'Ordinary Verus proof composition with existing imported contracts; no local inference requested or generated',
        'audit_setup_caveat': 'First read used nonexistent stdout instead of stdout.txt; no verifier application or source mutation resulted',
        'acceptance': False, 'all18': 'OPEN',
    }
    destination = EVIDENCE / 'COMBINED-SCOPE-AUDIT.json'
    assert not destination.exists()
    destination.write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'report': identity(destination), 'checked_exec_bodies': 4,
                      'checked_proof_bodies': 59, 'bound_sources': len(source_records),
                      'inference_status': inference['status']}, sort_keys=True))


if __name__ == '__main__':
    main()
