import datetime
import hashlib
import json
from pathlib import Path
import shutil
import tarfile


PARENT = Path('/Users/tommyvolk/.t3/worktrees/verus/t3-60978068')
ROOT = Path('/private/tmp/redb-header-recovery111-20261108T051418Z')
EVIDENCE = PARENT / 'evidence/redb-header-recovery111'


def digest(filename):
    hasher = hashlib.sha256()
    with filename.open('rb') as source:
        for block in iter(lambda: source.read(1024 * 1024), b''):
            hasher.update(block)
    return hasher.hexdigest()


def identity(filename):
    return {'path': str(filename), 'bytes': filename.stat().st_size,
            'sha256': digest(filename)}


def payloads(manifest):
    if isinstance(manifest.get('files'), list):
        return manifest['files']
    return manifest['records']


def authenticate_records(records, root=None):
    assert len(records) == len({record['path'] for record in records})
    mismatches = []
    for record in records:
        filename = Path(record['path'])
        if root is not None:
            if not filename.is_absolute():
                assert '..' not in filename.parts
                filename = root / filename
            filename.relative_to(root)
            assert not filename.is_symlink(), str(filename)
        if not filename.is_file():
            mismatches.append({'path': str(filename), 'reason': 'missing_file'})
            continue
        observed = identity(filename)
        if observed['bytes'] != record['bytes'] or observed['sha256'] != record['sha256']:
            mismatches.append({'expected': record, 'observed': observed})
    return {'records': len(records), 'mismatches': mismatches}


def authenticate_archive(root, archive_path, manifest_records, extras):
    expected_names = set(extras)
    for record in manifest_records:
        filename = Path(record['path'])
        relative = filename.relative_to(root) if filename.is_absolute() else filename
        assert '..' not in relative.parts
        expected_names.add(str(relative))
    compared = []
    with tarfile.open(archive_path, 'r:gz') as archive:
        members = archive.getmembers()
        assert len(members) == len(expected_names)
        assert {member.name for member in members} == expected_names
        for member in members:
            relative = Path(member.name)
            assert member.isfile() and not relative.is_absolute()
            assert '..' not in relative.parts
            stream = archive.extractfile(member)
            assert stream is not None
            hasher = hashlib.sha256()
            for block in iter(lambda: stream.read(1024 * 1024), b''):
                hasher.update(block)
            filename = root / relative
            assert member.size == filename.stat().st_size
            assert hasher.hexdigest() == digest(filename), member.name
            compared.append(member.name)
    return {'archive': identity(archive_path), 'members_byte_compared': len(compared)}


def main():
    destination = EVIDENCE / 'FINALIZATION-PREFLIGHT.json'
    assert not destination.exists()
    authorization = json.loads((EVIDENCE / 'AUTHORIZATION.json').read_text())
    for name in ['plan', 'inputs']:
        filename = Path(authorization[name]['path'])
        assert identity(filename) == authorization[name]
    selected = authenticate_records(json.loads((EVIDENCE / 'INPUTS.json').read_text())['records'])
    combined_inputs = ROOT / 'COMBINED-INPUTS.json'
    assert digest(combined_inputs) == 'd868ed5079f9fdf8ff1afc5981fb61cdab7896e00a84b5e8f48ccc027cf468b5'
    combined = authenticate_records(json.loads(combined_inputs.read_text())['records'])
    retained = {}
    for label, receipt_name, extras in [
        ('H', 'H-RETENTION.json', ['MANIFEST.json', 'HANDOFF.json']),
        ('P', 'P-RETENTION.json', ['MANIFEST.json', 'SEAL.json']),
        ('combined', 'COMBINED-RETENTION.json', ['MANIFEST.json', 'HANDOFF.json']),
        ('controls', 'PARENT-CONTROLS-RESULTS.json', ['MANIFEST.json']),
    ]:
        receipt = json.loads((EVIDENCE / receipt_name).read_text())
        root = Path(receipt['source'])
        manifest_path = root / 'MANIFEST.json'
        records = payloads(json.loads(manifest_path.read_text()))
        authenticated = authenticate_records(records, root)
        expected_manifest = receipt.get('manifest', {}).get('sha256')
        if expected_manifest is None and 'expected' in receipt:
            expected_manifest = receipt['expected']['manifest_sha256']
        assert digest(manifest_path) == expected_manifest
        archive_path = Path(receipt['archive']['path'])
        assert identity(archive_path) == receipt['archive']
        archive = authenticate_archive(root, archive_path, records, extras)
        expected_members = receipt.get('archive_members_byte_compared', receipt.get('archive_members_compared'))
        assert archive['members_byte_compared'] == expected_members
        retained[label] = {'source': str(root), 'authentication': authenticated,
                           'manifest': identity(manifest_path), **archive}
    applications = json.loads((ROOT / 'PARENT-APPLICATIONS.json').read_text())
    assert [record['number'] for record in applications] == [1, 2, 3]
    assert all(record['charged'] for record in applications)
    now = datetime.datetime.now(datetime.timezone.utc)
    deadline = datetime.datetime.fromisoformat(authorization['hard_deadline_utc'].replace('Z', '+00:00'))
    assert now < deadline
    result = {
        'schema': 'redb111-finalization-preflight-v1', 'utc': now.isoformat(),
        'previous_goal_turn': 'NO_PROGRESS_SUMMARY_ONLY_REVALIDATED_WITH_COMPLETE_INPUT_AND_ARCHIVE_AUTHENTICATION',
        'selected_inputs': selected, 'composition_inputs': combined,
        'retained': retained, 'parent_applications_charged': len(applications),
        'parent_application_cap': authorization['parent_application_cap'],
        'free_bytes': shutil.disk_usage('/private/tmp').free,
        'review_pending': True, 'goal_status': 'ACTIVE', 'all18': 'OPEN',
        'acceptance': False, 'adoption': False, 'integration': False,
        'compiler_source_correspondence': 'UNESTABLISHED',
        'native_path_preservation': 'FAILED', 'native_git_continuity': 'UNAVAILABLE',
    }
    result['success'] = not selected['mismatches'] and not combined['mismatches'] and all(
        not retained[label]['authentication']['mismatches'] for label in retained)
    destination.write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    assert result['success']
    assert result['free_bytes'] > authorization['global_free_floor_bytes']
    print(json.dumps({'success': result['success'], 'receipt': identity(destination),
                      'selected_inputs': selected['records'], 'composition_inputs': combined['records'],
                      'payload_counts': {label: retained[label]['authentication']['records'] for label in retained},
                      'archive_counts': {label: retained[label]['members_byte_compared'] for label in retained}}, sort_keys=True))


if __name__ == '__main__':
    main()
