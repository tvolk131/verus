import datetime
import json
from pathlib import Path
import re

from check import EVIDENCE, ROOT, authenticate, identity
from retain_candidate111 import authenticate_candidate


def audit():
    expected = json.loads((ROOT / 'H-EXPECTED.json').read_text())
    directory = Path(expected['root'])
    authenticate(ROOT / 'H-raw-audit-authentication-entry.json')
    names = authenticate_candidate(directory, expected)
    results = []
    for attempt in sorted(directory.glob('attempt-*')):
        result = json.loads((attempt / 'result.json').read_text())
        invocation = json.loads((attempt / 'invocation.json').read_text())
        raw = json.loads((attempt / 'stdout.txt').read_text())
        diagnostics = (attempt / 'stderr.txt').read_text()
        assert raw['verification-results'] == result['verification']
        assert invocation['export_fresh_absent'] is True
        export_path = Path(invocation['export_path'])
        assert export_path == attempt / 'candidate.vir'
        assert export_path.is_file() == result['export_present']
        assert '--no-cheating' in invocation['argv'] and '--compile' not in invocation['argv']
        assert result['timed_out'] is False
        verification = result['verification']
        if verification.get('success'):
            classification = 'FULL_POSITIVE'
            assert result['status'] == 0 and result['export_present']
            assert verification['errors'] == 0
        elif verification.get('encountered-vir-error'):
            classification = 'FRONTEND_REJECTION_NOT_SEMANTIC_CONTROL'
            assert result['status'] != 0 and not result['export_present']
        elif 'Resource limit (rlimit) exceeded' in diagnostics:
            classification = 'RESOURCE_LIMIT_INCONCLUSIVE'
            assert not result['export_present']
        else:
            classification = 'INTENDED_BACKEND_ASSERTION_REJECTION'
            assert attempt.name == 'attempt-10-mutant-mode-header-position'
            assert result['status'] != 0 and not result['export_present']
            assert verification['errors'] == 1
            assert diagnostics.count('error: assertion failed') == 1
            assert 'staging111.rs:77:16' in diagnostics
            assert 'assert(header.two_phase_commit == before.two_phase_commit)' in diagnostics
        results.append({'attempt': attempt.name, 'classification': classification,
                        'result': identity(attempt / 'result.json'),
                        'raw_stdout': identity(attempt / 'stdout.txt'),
                        'raw_stderr': identity(attempt / 'stderr.txt'),
                        'status': result['status'], 'verification': verification,
                        'exact_export_present': result['export_present']})
    assert len(results) == 12
    original = directory / 'attempt-03-positive-complete/staging111.rs'
    restored = directory / 'attempt-12-restored-positive/staging111.rs'
    assert original.read_bytes() == restored.read_bytes() == (directory / 'staging111.rs').read_bytes()
    mutant = (directory / 'attempt-10-mutant-mode-header-position/staging111.rs').read_text()
    corrected = (directory / 'attempt-11-corrected-mode-header-position/staging111.rs').read_text()
    assert corrected == mutant.replace('    header.two_phase_commit = true;\n', '', 1)
    source = (directory / 'staging111.rs').read_text()
    executable = re.findall(r'^pub fn ([A-Za-z_][A-Za-z_0-9]*)', source, re.MULTILINE)
    proofs = re.findall(r'^pub proof fn ([A-Za-z_][A-Za-z_0-9]*)', source, re.MULTILINE)
    assert len(executable) == 2 and len(proofs) == 3
    result = {
        'schema': 'redb111-parent-H-raw-evidence-audit-v1',
        'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'scope': 'PARENT_RAW_EVIDENCE_AUDIT_NOT_INDEPENDENT_REVIEW_OR_REPLAY',
        'applications': results, 'applications_charged': 12,
        'authored_executable_body_names': executable,
        'authored_proof_body_names': proofs,
        'verified_obligations_in_complete_positive': 9,
        'all_positive_sources_are_not_claimed_identical': True,
        'original_complete_positive_and_restored_and_final_are_byte_identical': True,
        'new_verifier_applications': 0, 'new_native_bodies_checked': 0,
        'all18': 'OPEN', 'acceptance': False, 'adoption': False,
    }
    assert authenticate_candidate(directory, expected) == names
    authenticate(ROOT / 'H-raw-audit-authentication-exit.json')
    destination = EVIDENCE / 'H-PARENT-RAW-AUDIT.json'
    assert not destination.exists()
    destination.write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'output': identity(destination), 'executable_bodies': executable,
                      'proof_bodies': proofs, 'audited_applications': len(results)}, indent=2))


if __name__ == '__main__':
    audit()
