import datetime
import json
from pathlib import Path

from check import EVIDENCE, ROOT, authenticate, identity


def capture():
    authenticate(ROOT / 'correspondence-authentication-entry.json')
    native = Path('/private/tmp/verus-crash-consistency94-20261105/native-leaf-lookup-007/recovered-native/redb/src')
    historical = Path('/private/tmp/verus-crash-consistency94-20261105/native-recovery-reencoding-021')
    selected = json.loads((EVIDENCE / 'INPUTS.json').read_text())['records']
    frozen = {record['path']: record for record in selected}
    excerpts = [
        (native / 'tree_store/page_store/page_manager.rs', 1613, 1629, 'native_header_write_branches'),
        (native / 'tree_store/page_store/page_manager.rs', 1825, 1859, 'native_header_staging_and_barriers'),
        (native / 'tree_store/page_store/page_manager.rs', 1873, 1891, 'native_post_sync_publication'),
        (native / 'tree_store/page_store/cached_file.rs', 490, 523, 'native_flush_buffer_and_partial_error_prefix'),
        (native / 'tree_store/page_store/cached_file.rs', 596, 600, 'native_flush_then_sync'),
        (historical / 'roundtrip-005.rs', 109, 121, 'imported_fixed_geometry_domain'),
        (ROOT / 'shared/composition110.rs', 274, 291, 'conditional_complete_flush_product'),
        (ROOT / 'shared/ack_cfg.rs', 48, 55, 'model_local_mode_domain'),
    ]
    records = []
    for filename, first, last, label in excerpts:
        observed = identity(filename)
        assert observed == frozen[str(filename)]
        lines = filename.read_text().splitlines()
        records.append({'label': label, 'input': observed, 'first_line': first,
                        'last_line': last, 'lines': lines[first - 1:last]})
    result = {
        'schema': 'redb111-source-correspondence-frontier-v1',
        'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'scope': 'SOURCE_OBSERVATIONS_NOT_NATIVE_SEMANTICS_OR_EXECUTED_BINDING_TRACE',
        'excerpts': records,
        'inherited_boundary': 'EXPLICIT_INHERITED_STD_BOOL_TCB_NOT_RUST_CORE_PROOF',
        'native_path_preservation': 'FAILED',
        'git_continuity': 'UNAVAILABLE',
        'compiler_source_correspondence': 'UNESTABLISHED',
        'new_verifier_applications': 0,
        'native_bodies_checked': 0,
        'all18': 'OPEN', 'acceptance': False, 'adoption': False,
    }
    destination = EVIDENCE / 'NATIVE-LINKAGE-SOURCE.json'
    assert not destination.exists()
    destination.write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    authenticate(ROOT / 'correspondence-authentication-exit.json')
    print(json.dumps(identity(destination), indent=2))


if __name__ == '__main__':
    capture()
