import datetime
import json
from pathlib import Path
import shutil

from check import EVIDENCE, ROOT


def sample():
    free = shutil.disk_usage('/private/tmp').free
    sizes = {}
    for label, directory in [('parent_scratch', ROOT), ('retained_evidence', EVIDENCE)]:
        sizes[label] = sum(filename.stat().st_size for filename in directory.rglob('*')
                           if filename.is_file() and not filename.is_symlink())
    ledger = ROOT / 'RESOURCE-SAMPLES.json'
    records = json.loads(ledger.read_text()) if ledger.exists() else []
    record = {
        'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'free_bytes': free, 'sampled_bytes': sizes,
        'free_strictly_above_16_gib': free > 16 * 1024 ** 3,
        'sampled_parent_and_retention_below_1_gib': sum(sizes.values()) < 1024 ** 3,
        'scope': 'BOUNDARY_SAMPLE_NOT_CONTINUOUS_PEAK_OR_DELEGATE_USAGE',
    }
    records.append(record)
    ledger.write_text(json.dumps(records, indent=2, sort_keys=True) + '\n')
    print(json.dumps(record, indent=2, sort_keys=True))
    assert record['free_strictly_above_16_gib']
    assert record['sampled_parent_and_retention_below_1_gib']


if __name__ == '__main__':
    sample()
