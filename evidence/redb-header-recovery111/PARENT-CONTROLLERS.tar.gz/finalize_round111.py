import datetime
import json
from pathlib import Path
import shutil
import tarfile

from prepare_finalization111 import (
    EVIDENCE, PARENT, ROOT, authenticate_archive, authenticate_records,
    digest, identity, payloads,
)


def file_bytes(root):
    return sum(filename.stat().st_size for filename in root.rglob('*') if filename.is_file())


def main():
    assert not (EVIDENCE / 'ROUND-RESULTS.json').exists()
    assert not (EVIDENCE / 'ROUND-MANIFEST.json').exists()
    authorization = json.loads((EVIDENCE / 'AUTHORIZATION.json').read_text())
    for name in ['plan', 'inputs']:
        assert identity(Path(authorization[name]['path'])) == authorization[name]
    review = json.loads((EVIDENCE / 'INDEPENDENT-REVIEW-RESULTS.json').read_text())
    assert review['review_completed'] is True
    assert review['acceptance'] is False and review['all18'] == 'OPEN'
    assert 0 <= review['verifier_launches'] <= review['charged_applications'] <= 6
    assert review['review_exit_mismatches'] == 0
    for name in ['archive', 'manifest', 'report', 'handoff']:
        assert identity(Path(review[name]['path'])) == review[name]
    selected = json.loads((EVIDENCE / 'INPUTS.json').read_text())
    snapshots = review['historical_documents_before_reconciliation']
    assert len(snapshots) == 2
    unchanged = []
    expected_updates = []
    for record in selected['records']:
        filename = Path(record['path'])
        if str(filename) in snapshots:
            snapshot = snapshots[str(filename)]
            assert digest(EVIDENCE / snapshot['snapshot']) == record['sha256'] == snapshot['sha256']
            observed = identity(filename)
            assert observed['sha256'] != record['sha256']
            expected_updates.append({'frozen': record, 'reconciled': observed,
                                     'snapshot': snapshot['snapshot'],
                                     'reason': 'Explicit post-review parent documentation reconciliation'})
        else:
            assert identity(filename) == record, str(filename)
            unchanged.append(str(filename))
    assert len(selected['records']) == 1416
    assert len(unchanged) == 1414 and len(expected_updates) == 2
    combined_inputs = ROOT / 'COMBINED-INPUTS.json'
    assert digest(combined_inputs) == 'd868ed5079f9fdf8ff1afc5981fb61cdab7896e00a84b5e8f48ccc027cf468b5'
    combined_authentication = authenticate_records(json.loads(combined_inputs.read_text())['records'])
    assert combined_authentication['records'] == 351
    assert not combined_authentication['mismatches']
    counts = {}
    roots = {'parent_controllers': ROOT, 'retained_evidence': EVIDENCE,
             'independent_review': Path(review['source'])}
    for label, receipt_name, extras in [
        ('H', 'H-RETENTION.json', ['MANIFEST.json', 'HANDOFF.json']),
        ('P', 'P-RETENTION.json', ['MANIFEST.json', 'SEAL.json']),
        ('combined', 'COMBINED-RETENTION.json', ['MANIFEST.json', 'HANDOFF.json']),
        ('controls', 'PARENT-CONTROLS-RESULTS.json', ['MANIFEST.json']),
    ]:
        receipt = json.loads((EVIDENCE / receipt_name).read_text())
        root = Path(receipt['source'])
        if label in ['H', 'P']:
            roots[label] = root
        manifest = root / 'MANIFEST.json'
        records = payloads(json.loads(manifest.read_text()))
        observed = authenticate_records(records, root)
        assert not observed['mismatches']
        expected_manifest = receipt.get('manifest', {}).get('sha256')
        if expected_manifest is None:
            expected_manifest = receipt['expected']['manifest_sha256']
        assert digest(manifest) == expected_manifest
        assert identity(Path(receipt['archive']['path'])) == receipt['archive']
        archived = authenticate_archive(root, Path(receipt['archive']['path']), records, extras)
        counts[label] = {'payloads': len(records),
                         'archive_members_compared': archived['members_byte_compared']}
    applications = json.loads((ROOT / 'PARENT-APPLICATIONS.json').read_text())
    assert [record['number'] for record in applications] == list(range(1, len(applications) + 1))
    assert all(record['charged'] for record in applications)
    assert len(applications) <= authorization['parent_application_cap'] == 4
    lane_charges = {}
    for label in ['H', 'P']:
        accounting = json.loads((roots[label] / 'ACCOUNTING.json').read_text())
        lane_charges[label] = accounting['charged_applications']
        assert lane_charges[label] == (12 if label == 'H' else 13)
    status = json.loads((PARENT / 'evidence/redb-crash-consistency94/STATUS.json').read_text())
    assert status['whole_goal_acceptance'] is False
    assert status['pending_independent_review_tasks'] == []
    assert len(status['completion_properties']) == 6 and len(status['required_histories']) == 3
    assert status['native_header_recovery111'].startswith('COMPLETE_CONDITIONAL_')
    scope = json.loads((EVIDENCE / 'COMBINED-SCOPE-AUDIT.json').read_text())
    assert scope['inference_status'] == 'no_inference'
    assert scope['checked_authored_exec_bodies'] == 4
    assert scope['checked_local_proof_bodies'] == 59
    controller_archive = EVIDENCE / 'PARENT-CONTROLLERS.tar.gz'
    assert not controller_archive.exists()
    test_log = (ROOT / 'finalization-tests.stderr').read_text()
    assert 'Ran 12 tests in ' in test_log and test_log.rstrip().endswith('OK')
    controller_names = [filename.name for filename in sorted(ROOT.iterdir())
                        if filename.is_file() and not filename.is_symlink()
                        and not filename.name.startswith('finalization-live.')]
    symbolic_fixtures = [{'path': str(filename.relative_to(ROOT)),
                         'target': str(filename.readlink())}
                        for filename in sorted((ROOT / 'finalization-tests').rglob('*'))
                        if filename.is_symlink()]
    controller_names.extend(str(filename.relative_to(ROOT))
                            for filename in sorted((ROOT / 'finalization-tests').rglob('*'))
                            if filename.is_file() and not filename.is_symlink())
    with tarfile.open(controller_archive, 'w:gz') as archive:
        for name in controller_names:
            archive.add(ROOT / name, arcname=name, recursive=False)
    controller_records = [identity(ROOT / name) for name in controller_names]
    authenticate_archive(ROOT, controller_archive, controller_records, [])
    now = datetime.datetime.now(datetime.timezone.utc)
    start = datetime.datetime.fromisoformat(authorization['round_start_utc'].replace('Z', '+00:00'))
    deadline = datetime.datetime.fromisoformat(authorization['hard_deadline_utc'].replace('Z', '+00:00'))
    assert now < deadline
    sizes = {label: file_bytes(root) for label, root in roots.items()}
    free_bytes = shutil.disk_usage('/private/tmp').free
    assert sum(sizes.values()) < authorization['scratch_cap_bytes']
    assert free_bytes > authorization['global_free_floor_bytes']
    result = {
        'schema': 'redb-header-recovery111-completed-round-v1',
        'status': 'BOUNDED_ROUND_COMPLETE_DATABASE_GOAL_OPEN',
        'start_utc': start.isoformat(), 'completed_utc': now.isoformat(),
        'hard_deadline_utc': deadline.isoformat(), 'elapsed_seconds': (now - start).total_seconds(),
        'within_original_round_deadline': True, 'task_allowances_reset': False,
        'H_verified_obligations': 9, 'H_authored_exec_bodies': 2, 'H_proof_bodies': 3,
        'P_full_harness_verified_obligations': 71, 'combined_verified_obligations': 80,
        'combined_checked_authored_exec_bodies': 4, 'combined_checked_local_proof_bodies': 59,
        'combined_inference_status': 'no_inference',
        'combined_contains_separate_P_witness_and_control_harnesses': False,
        'new_original_native_executable_bodies_checked': 0,
        'H_charged_applications': lane_charges['H'], 'P_charged_applications': lane_charges['P'],
        'parent_charged_applications': len(applications),
        'review_charged_applications': review['charged_applications'],
        'review_verifier_launches': review['verifier_launches'],
        'total_charged_applications': sum(lane_charges.values()) + len(applications) + review['charged_applications'],
        'single_independent_review_completed': True, 'review_verdict': review['verdict'],
        'selected_inputs': {'frozen_count': 1416, 'unchanged_after_reconciliation': len(unchanged),
                            'unexpected_mismatches': 0, 'expected_document_updates': expected_updates},
        'composition_inputs_unchanged': combined_authentication['records'],
        'authenticated_candidate_payloads_and_archive_members': counts,
        'parent_finite_projection_cases': 144, 'parent_paired_semantic_controls': 6,
        'parent_fresh_python_tests': 13, 'finite_controls_are_native_semantics': False,
        'finalization_metadata_tests': 12, 'finalization_tests_are_native_proof': False,
        'finalization_test_logs': [identity(ROOT / 'finalization-tests.stdout'),
                                   identity(ROOT / 'finalization-tests.stderr')],
        'sampled_file_bytes_by_root': sizes, 'sampled_total_file_bytes': sum(sizes.values()),
        'sampled_free_disk_bytes': free_bytes,
        'resource_sampling_limit': 'Boundary observations, not continuous peak measurements or OS quotas',
        'native_header_cache_backend_callback_resource_history_bindings': 'OPEN',
        'compiler_source_correspondence': 'UNESTABLISHED',
        'native_path_preservation': 'FAILED', 'native_git_continuity': 'UNAVAILABLE',
        'goal_service_status_last_observed': 'ACTIVE', 'redb_open_cells': 18,
        'final_cells_closed': 0, 'acceptance': False, 'adoption': False, 'integration': False,
        'new_trusted_assumptions_adopted': 0, 'builds': 0, 'native_application_runs': 0,
        'S0_infer_full_scope_import_export_barriers': 'UNCHANGED_FAIL_CLOSED',
        'controller_archive': identity(controller_archive),
        'symbolic_test_fixtures_not_archived_as_links': symbolic_fixtures,
        'active_finalization_streams_not_in_controller_archive': ['finalization-live.stdout', 'finalization-live.stderr'],
        'caveats': ['PARENT-OPERATION-CAVEATS.md', 'PRESERVATION-QUALIFICATION.md',
                    'NATIVE-CLOSURE-LEDGER.md', 'INDEPENDENT-REVIEW.md',
                    'POST-REVIEW-OPERATION-CAVEATS.md'],
    }
    (EVIDENCE / 'ROUND-RESULTS.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    records = []
    for filename in sorted(EVIDENCE.rglob('*')):
        if filename.is_file():
            assert not filename.is_symlink()
            record = identity(filename)
            record['path'] = str(filename.relative_to(EVIDENCE))
            records.append(record)
    manifest = {'schema': 'redb111-retained-round-manifest-v1', 'utc': now.isoformat(),
                'excludes': ['ROUND-MANIFEST.json'], 'files': records}
    manifest_path = EVIDENCE / 'ROUND-MANIFEST.json'
    manifest_path.write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
    assert not authenticate_records(records, EVIDENCE)['mismatches']
    print(json.dumps({'round_results': identity(EVIDENCE / 'ROUND-RESULTS.json'),
                      'manifest': identity(manifest_path), 'manifested_files': len(records),
                      'total_charged_applications': result['total_charged_applications'],
                      'all18': 'OPEN', 'goal_status': 'ACTIVE'}, sort_keys=True))


if __name__ == '__main__':
    main()
