import io
from pathlib import Path
import tarfile
import unittest

from prepare_finalization111 import (
    ROOT, authenticate_archive, authenticate_records, identity,
)


class FinalizationTests(unittest.TestCase):
    def setUp(self):
        self.root = ROOT / 'finalization-tests' / self._testMethodName
        self.root.mkdir(parents=True)
        self.payload = self.root / 'payload.txt'
        self.payload.write_bytes(b'original payload\n')
        self.record = identity(self.payload)

    def make_archive(self, name='payload.txt', content=b'original payload\n', duplicate=False, directory=False):
        archive_path = self.root / 'test.tar.gz'
        with tarfile.open(archive_path, 'w:gz') as archive:
            member = tarfile.TarInfo(name)
            if directory:
                member.type = tarfile.DIRTYPE
                archive.addfile(member)
            else:
                member.size = len(content)
                archive.addfile(member, io.BytesIO(content))
                if duplicate:
                    archive.addfile(member, io.BytesIO(content))
        return archive_path

    def test_exact_payload_authenticates(self):
        result = authenticate_records([self.record], self.root)
        self.assertEqual(result, {'records': 1, 'mismatches': []})

    def test_changed_payload_is_reported(self):
        self.payload.write_bytes(b'changed payload\n')
        result = authenticate_records([self.record], self.root)
        self.assertEqual(len(result['mismatches']), 1)

    def test_missing_payload_is_reported(self):
        record = dict(self.record, path=str(self.root / 'absent.txt'))
        result = authenticate_records([record], self.root)
        self.assertEqual(result['mismatches'][0]['reason'], 'missing_file')

    def test_duplicate_manifest_identity_refused(self):
        with self.assertRaises(AssertionError):
            authenticate_records([self.record, self.record], self.root)

    def test_relative_manifest_escape_refused(self):
        record = dict(self.record, path='../outside.txt')
        with self.assertRaises(AssertionError):
            authenticate_records([record], self.root)

    def test_absolute_manifest_escape_refused(self):
        record = dict(self.record, path=str(self.root.parent / 'outside.txt'))
        with self.assertRaises(ValueError):
            authenticate_records([record], self.root)

    def test_symlink_payload_refused(self):
        alias = self.root / 'alias.txt'
        alias.symlink_to(self.payload)
        record = dict(self.record, path=str(alias))
        with self.assertRaises(AssertionError):
            authenticate_records([record], self.root)

    def test_exact_archive_authenticates(self):
        archive = self.make_archive()
        result = authenticate_archive(self.root, archive, [self.record], [])
        self.assertEqual(result['members_byte_compared'], 1)

    def test_wrong_archive_member_refused(self):
        archive = self.make_archive(name='wrong.txt')
        with self.assertRaises(AssertionError):
            authenticate_archive(self.root, archive, [self.record], [])

    def test_changed_archive_content_refused(self):
        archive = self.make_archive(content=b'modified payload\n')
        with self.assertRaises(AssertionError):
            authenticate_archive(self.root, archive, [self.record], [])

    def test_duplicate_archive_member_refused(self):
        archive = self.make_archive(duplicate=True)
        with self.assertRaises(AssertionError):
            authenticate_archive(self.root, archive, [self.record], [])

    def test_directory_archive_member_refused(self):
        archive = self.make_archive(directory=True)
        with self.assertRaises(AssertionError):
            authenticate_archive(self.root, archive, [self.record], [])


if __name__ == '__main__':
    unittest.main(verbosity=2)
