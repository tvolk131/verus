use vstd::prelude::*;
#[path = "/private/tmp/redb-header-recovery111-H-20261108T052400Z/attempt-10-mutant-mode-header-position/staging111.rs"]
pub mod h_old_mode_negative;
#[path = "/private/tmp/redb-header-recovery111-P-cPSXKcfk/witnesses111.rs"]
pub mod witnesses;

verus! {

pub fn wrong_user_root_control()
{
    let actual = witnesses::concrete_decoder_nonvacuity();
    assert(actual.transaction_slots@[1].user_root == Some(witnesses::witness_system_root()));
}

pub fn wrong_system_root_control()
{
    let actual = witnesses::concrete_decoder_nonvacuity();
    assert(actual.transaction_slots@[1].system_root == Some(witnesses::witness_user_root()));
}

}
