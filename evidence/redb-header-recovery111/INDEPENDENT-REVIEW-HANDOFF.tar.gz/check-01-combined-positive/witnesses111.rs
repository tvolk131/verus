use vstd::prelude::*;
use recovery_reencoding021::*;
use recovery_roundtrip021::*;
use rootcodec94::BtreeHeader;
#[path = "recovery_product111.rs"]
pub mod bridge;

verus! {

pub open spec fn witness_user_root() -> BtreeHeader {
    BtreeHeader { root: pagecodec94::PageNumber { region: 2, page_index: 3, page_order: 0 },
        checksum: 101, length: 17 }
}

pub open spec fn witness_system_root() -> BtreeHeader {
    BtreeHeader { root: pagecodec94::PageNumber { region: 4, page_index: 5, page_order: 0 },
        checksum: 202, length: 19 }
}

pub open spec fn witness_prepared() -> DatabaseHeader {
    DatabaseHeader {
        primary_slot: 0, recovery_required: false, two_phase_commit: false,
        primary_unflushed: false, page_size: 4096, region_header_pages: 0,
        region_max_data_pages: 1, full_regions: 1, trailing_partial_region_pages: 0,
        transaction_slots: [
            TransactionHeader { version: 3, user_root: None, system_root: None,
                transaction_id: TransactionId(7), corrupt_bytes: None },
            TransactionHeader { version: 3, user_root: Some(witness_user_root()),
                system_root: Some(witness_system_root()), transaction_id: TransactionId(11),
                corrupt_bytes: None },
        ],
    }
}

pub open spec fn witness_expected() -> DatabaseHeader {
    DatabaseHeader { primary_slot: 1, two_phase_commit: true, ..witness_prepared() }
}

pub open spec fn witness_image() -> bridge::product::storage::Image {
    bridge::product::storage::clean(Seq::new(8192, |position: int| 0u8))
}

pub proof fn witness_domain()
    ensures bridge::expected_domain(witness_expected(), 8192),
{
    hide(hash94::header_hash);
    hide(hash94::scalar_spec);
    let expected = witness_expected();
    assert(3u64 <= (0x000F_FFFFu64 >> 0u8)
        && 5u64 <= (0x000F_FFFFu64 >> 0u8)) by(bit_vector);
    assert(pagecodec94::canonical_page(witness_user_root().root));
    assert(pagecodec94::canonical_page(witness_system_root().root));
    assert(slot_roundtrip_domain(expected.transaction_slots@[0]));
    assert(slot_roundtrip_domain(expected.transaction_slots@[1]));
    assert(header_roundtrip_domain(expected));
    assert(selected_slot_stable(expected));
    assert(layout_bytes(header_layout(expected)) == 8192);
    assert(bridge::expected_file_length(expected, 8192));
}

pub proof fn concrete_product_nonvacuity()
    ensures ({
        let expected = witness_expected();
        let config = bridge::product::acknowledgement::witness_config();
        let start = bridge::product::initial(config, witness_image(), Seq::empty(),
            database_bytes(witness_prepared(), true), database_bytes(expected, true));
        let actions = Seq::new(46, |position: int| bridge::product::success_action());
        let final_state = bridge::product::run(start, config, actions);
        &&& bridge::expected_domain(expected, 8192)
        &&& config.new_slot == 3 && expected.primary_slot == 1
        &&& config.old_secondary == 1
        &&& expected.transaction_slots@[1].transaction_id.0 == 11
        &&& expected.transaction_slots@[1].user_root == Some(witness_user_root())
        &&& expected.transaction_slots@[1].system_root == Some(witness_system_root())
        &&& final_state.control.status == 1 && !final_state.blocked
        &&& final_state.image.durable.subrange(0, 320) == database_bytes(expected, true)
        &&& finalization_accepts_bytes(final_state.image.durable.subrange(0, 320), 8192)
        &&& forall|actual: DatabaseHeader, clean: bool|
            finalized_from_bytes(final_state.image.durable.subrange(0, 320), 8192, actual, clean)
                ==> bridge::selected_payload_matches(actual, expected)
    }),
{
    hide(hash94::header_hash);
    hide(hash94::scalar_spec);
    let expected = witness_expected();
    let config = bridge::product::acknowledgement::witness_config();
    let image = witness_image();
    let pending = Seq::empty();
    bridge::product::storage::clean_valid(Seq::new(8192, |position: int| 0u8));
    assert(bridge::product::storage::pending_valid(pending, 8192));
    witness_domain();
    bridge::product::nonvacuous_symbolic_success(image, pending,
        database_bytes(witness_prepared(), true), database_bytes(expected, true));
    bridge::product::initial_invariant(config, image, pending,
        database_bytes(witness_prepared(), true), database_bytes(expected, true));
    let start = bridge::product::initial(config, image, pending,
        database_bytes(witness_prepared(), true), database_bytes(expected, true));
    let actions = Seq::new(46, |position: int| bridge::product::success_action());
    bridge::public_ok_recovers_expected(start, config, actions, expected, 8192);
}

pub fn concrete_decoder_nonvacuity() -> (result: DatabaseHeader)
    ensures bridge::selected_payload_matches(result, witness_expected()),
        result.primary_slot == 1,
        result.transaction_slots@[1].transaction_id.0 == 11,
        result.transaction_slots@[1].user_root == Some(witness_user_root()),
        result.transaction_slots@[1].system_root == Some(witness_system_root()),
{
    hide(hash94::header_hash);
    hide(hash94::scalar_spec);
    let user_root = BtreeHeader {
        root: pagecodec94::PageNumber { region: 2, page_index: 3, page_order: 0 },
        checksum: 101, length: 17,
    };
    let system_root = BtreeHeader {
        root: pagecodec94::PageNumber { region: 4, page_index: 5, page_order: 0 },
        checksum: 202, length: 19,
    };
    let expected = DatabaseHeader {
        primary_slot: 1, recovery_required: false, two_phase_commit: true,
        primary_unflushed: false, page_size: 4096, region_header_pages: 0,
        region_max_data_pages: 1, full_regions: 1, trailing_partial_region_pages: 0,
        transaction_slots: [
            TransactionHeader { version: 3, user_root: None, system_root: None,
                transaction_id: TransactionId(7), corrupt_bytes: None },
            TransactionHeader { version: 3, user_root: Some(user_root),
                system_root: Some(system_root), transaction_id: TransactionId(11),
                corrupt_bytes: None },
        ],
    };
    proof {
        assert(expected.transaction_slots@ == witness_expected().transaction_slots@);
        vstd::array::axiom_array_ext_equal(expected.transaction_slots, witness_expected().transaction_slots);
        assert(expected == witness_expected());
        witness_domain();
    }
    let encoded = expected.to_bytes(true);
    let result = bridge::decode_expected_header(&encoded, &expected, 8192);
    match result {
        Ok((actual, clean)) => actual,
        Err(_) => { proof { assert(false); } unreachable!() },
    }
}

}
