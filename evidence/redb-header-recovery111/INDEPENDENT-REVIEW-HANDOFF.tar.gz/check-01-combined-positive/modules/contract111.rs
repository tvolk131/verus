use vstd::prelude::*;
use recovery_reencoding021::*;
use recovery_roundtrip021::*;
use rootcodec94::BtreeHeader;

verus! {

pub open spec fn root_domain(root: Option<BtreeHeader>) -> bool {
    match root {
        Some(value) => pagecodec94::canonical_page(value.root),
        None => true,
    }
}

pub open spec fn stage_domain(before: DatabaseHeader, transaction_id: TransactionId,
    user_root: Option<BtreeHeader>, system_root: Option<BtreeHeader>) -> bool {
    &&& header_roundtrip_domain(before)
    &&& transaction_id.0 > before.transaction_slots@[before.primary_slot as int].transaction_id.0
    &&& root_domain(user_root)
    &&& root_domain(system_root)
}

pub open spec fn prepared_header(before: DatabaseHeader, transaction_id: TransactionId,
    user_root: Option<BtreeHeader>, system_root: Option<BtreeHeader>) -> DatabaseHeader {
    let replacement = TransactionHeader {
        version: before.transaction_slots@[(before.primary_slot ^ 1) as int].version,
        user_root, system_root, transaction_id, corrupt_bytes: None,
    };
    DatabaseHeader {
        transaction_slots: if before.primary_slot == 0 {
            [before.transaction_slots@[0], replacement]
        } else {
            [replacement, before.transaction_slots@[1]]
        },
        ..before
    }
}

pub open spec fn committed_header(prepared: DatabaseHeader) -> DatabaseHeader {
    DatabaseHeader {
        primary_slot: prepared.primary_slot ^ 1,
        two_phase_commit: true,
        primary_unflushed: false,
        ..prepared
    }
}

}
