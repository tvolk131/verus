import datetime
import hashlib
import json
from pathlib import Path
import sys
sys.dont_write_bytecode = True
import tarfile
from review import ROOT, FIRST, DEADLINE, save, record, utc, resources, digest

deadline = datetime.datetime.fromisoformat(DEADLINE.replace('Z', '+00:00'))
first = datetime.datetime.fromisoformat(FIRST.replace('Z', '+00:00'))
ledger = json.loads((ROOT / 'APPLICATIONS.json').read_text())
assert len(ledger) == 6
assert len([row for row in ledger if row['state'] == 'completed']) == 4
samples = []
for path in ROOT.glob('check-*/result.json'):
    result = json.loads(path.read_text())
    assert result['process_reaped']
    assert result['elapsed_seconds'] <= 90
    samples.extend(result['samples'])
samples.append(resources())
assert all(row['free_ok'] and row['scratch_ok'] for row in samples)
exit_auth = json.loads((ROOT / 'authentication-exit.json').read_text())
assert all(summary['mismatches'] == 0 for summary in exit_auth['summary'].values())
assert all(pair['byte_identical'] for pair in exit_auth['pairs'])
accounting = dict(utc=utc(), first_clock=FIRST, deadline=DEADLINE,
    elapsed_seconds=(datetime.datetime.now(datetime.timezone.utc) - first).total_seconds(),
    charged_applications=6, fully_completed_verifier_applications=4,
    interrupted_verifier_processes=1, prelaunch_setup_failures=1,
    applications=ledger, new_parent_applications=0, review_workers=1,
    min_observed_free_bytes=min(row['free_bytes'] for row in samples),
    max_observed_scratch_bytes=max(row['scratch_bytes'] for row in samples),
    samples_are_not_continuous_hard_limits=True, no_further_chain=True,
    authentication_exit_sha256=digest(ROOT / 'authentication-exit.json'))
save(ROOT / 'ACCOUNTING.json', accounting)
excluded = {'MANIFEST.json', 'HANDOFF.json', 'SEAL.json', 'REVIEW-HANDOFF.tar.gz'}
payloads = [path for path in sorted(ROOT.rglob('*')) if path.is_file() and path.name not in excluded]
manifest = dict(utc=utc(), root=str(ROOT), excludes=sorted(excluded),
    records=[dict(relative_path=str(path.relative_to(ROOT)), **record(path)) for path in payloads])
save(ROOT / 'MANIFEST.json', manifest)
handoff = dict(utc=utc(), root=str(ROOT), verdict='NO_NEW_BLOCKING_CONDITIONAL_CONTRACT_DEFECT',
    native_acceptance=False, adoption=False, integration=False, all18='OPEN',
    manifest=record(ROOT / 'MANIFEST.json'), report=record(ROOT / 'REPORT.md'),
    accounting=record(ROOT / 'ACCOUNTING.json'), payloads=len(payloads),
    charged_applications=6, parent_applications_used=0,
    fresh_combined='80/0 twice; source bytes identical', fresh_p_full='71/0',
    fresh_negative='78/3; intended H mode, user-root, system-root assertions',
    reviewer_errors='one monitor-denied killed/reaped process; one prelaunch source-path error',
    inherited_boundary='EXPLICIT_INHERITED_STD_BOOL_TCB_NOT_RUST_CORE_PROOF',
    native_path_preservation='FAILED', native_git='UNAVAILABLE',
    compiler_source_correspondence='UNESTABLISHED', automatic_followup=False)
save(ROOT / 'HANDOFF.json', handoff)
members = payloads + [ROOT / 'MANIFEST.json', ROOT / 'HANDOFF.json']
archive = ROOT / 'REVIEW-HANDOFF.tar.gz'
with tarfile.open(archive, 'w:gz') as stream:
    for path in members:
        stream.add(path, arcname=str(path.relative_to(ROOT)), recursive=False)
verified = []
with tarfile.open(archive) as stream:
    for member in stream.getmembers():
        content = stream.extractfile(member).read()
        assert hashlib.sha256(content).hexdigest() == digest(ROOT / member.name)
        verified.append(member.name)
assert len(verified) == len(members)
final_resources = resources()
assert final_resources['free_ok'] and final_resources['scratch_ok']
now = datetime.datetime.now(datetime.timezone.utc)
assert now < deadline and (now - first).total_seconds() < 900
save(ROOT / 'SEAL.json', dict(utc=utc(), first_clock=FIRST, absolute_deadline=DEADLINE,
    sealed_before_deadline=True, elapsed_seconds=(now - first).total_seconds(),
    archive=record(archive), archive_members=len(verified), all_archive_members_byte_compared=True,
    manifest=record(ROOT / 'MANIFEST.json'), handoff=record(ROOT / 'HANDOFF.json'),
    report=record(ROOT / 'REPORT.md'), resources=final_resources,
    archive_excludes_outer_seal=True, no_further_work_or_chain=True))
print(json.dumps(json.loads((ROOT / 'SEAL.json').read_text()), indent=2))
