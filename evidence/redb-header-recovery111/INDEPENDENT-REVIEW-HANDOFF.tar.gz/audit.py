import hashlib
import json
from pathlib import Path
import re
import shutil
import tarfile
from review import ROOT, REPO, PARENT, HROOT, PROOT, save, record, digest, utc, resources

EVIDENCE = REPO / 'evidence/redb-header-recovery111'
SNAPSHOT = ROOT / 'audited-evidence'
SNAPSHOT.mkdir(exist_ok=True)

def raw_outcome(folder, label):
    retained = ROOT / 'historical-raw' / label
    retained.mkdir(parents=True, exist_ok=True)
    copied = []
    for name in ['stdout.txt', 'stderr.txt', 'result.json', 'invocation.json']:
        path = folder / name
        if path.exists():
            target = retained / name
            shutil.copyfile(path, target)
            copied.append(record(path))
    stdout = folder / 'stdout.txt'
    stderr = folder / 'stderr.txt'
    try:
        parsed = json.loads(stdout.read_text())
        verification = parsed.get('verification-results')
        decoding_error = None
    except Exception as error:
        verification = None
        decoding_error = repr(error)
    diagnostics = stderr.read_text(errors='replace') if stderr.exists() else ''
    return dict(label=label, folder=str(folder), files=copied,
        raw_verification=verification, raw_json_error=decoding_error,
        assertion_failures=diagnostics.count('error: assertion failed'),
        resource_limit=('resource limit' in diagnostics.lower()),
        diagnostics=diagnostics)

historical = []
for prefix, root in [('H', HROOT), ('P', PROOT), ('parent', PARENT)]:
    pattern = 'parent-check-*' if prefix == 'parent' else 'attempt-*'
    for folder in sorted(root.glob(pattern)):
        historical.append(raw_outcome(folder, prefix + '-' + folder.name))
save(ROOT / 'HISTORICAL-RAW-AUDIT.json', historical)

archives = []
for label in ['H', 'P', 'COMBINED']:
    retention = json.loads((EVIDENCE / (label + '-RETENTION.json')).read_text())
    archive = Path(retention['archive']['path'])
    source = Path(retention['source'])
    rows = []
    with tarfile.open(archive) as stream:
        for member in stream.getmembers():
            if not member.isfile():
                continue
            payload = stream.extractfile(member).read()
            actual = hashlib.sha256(payload).hexdigest()
            disk = source / member.name
            rows.append(dict(member=member.name, bytes=len(payload), archive_sha256=actual,
                disk=record(disk), matches=actual == digest(disk)))
    archives.append(dict(label=label, archive=record(archive),
        declared_sha256=retention['archive']['sha256'],
        archive_matches=digest(archive) == retention['archive']['sha256'],
        members=len(rows), all_members_match=all(row['matches'] for row in rows), records=rows))
    shutil.copyfile(archive, SNAPSHOT / archive.name)
save(ROOT / 'ARCHIVE-BYTE-AUDIT.json', archives)

documents = ['PLAN.md', 'INPUTS.json', 'NATIVE-CLOSURE-LEDGER.md', 'NATIVE-LINKAGE-SOURCE.json',
    'PRESERVATION-QUALIFICATION.md', 'PRESERVATION-QUALIFICATION.json',
    'PARENT-OPERATION-CAVEATS.md', 'H-PARENT-RAW-AUDIT.json', 'PARENT-CONTROLS-RESULTS.json',
    'H-RETENTION.json', 'P-RETENTION.json', 'COMBINED-RETENTION.json']
receipts = []
frozen = {row['path'] for row in json.loads((EVIDENCE / 'INPUTS.json').read_text())['records']}
for name in documents:
    path = EVIDENCE / name
    shutil.copyfile(path, SNAPSHOT / name)
    receipts.append(dict(actual=record(path), in_original_1416=str(path) in frozen,
        role='Supplemental source-only audit, not frozen-provenance repair' if str(path) not in frozen else 'Frozen selected input'))
for label, root in [('H', HROOT), ('P', PROOT)]:
    for name in ['REPORT.md', 'API.md', 'HANDOFF.json', 'MANIFEST.json', 'SEAL.json']:
        path = root / name
        if path.exists():
            shutil.copyfile(path, SNAPSHOT / (label + '-' + name))
shutil.copyfile(PARENT / 'COMBINED-INPUTS.json', SNAPSHOT / 'COMBINED-INPUTS.json')
save(ROOT / 'SUPPLEMENTAL-READ-RECEIPTS.json', receipts)

fresh = []
for item in json.loads((ROOT / 'APPLICATIONS.json').read_text()):
    folder = Path(item['folder'])
    stdout = folder / 'stdout.txt'
    try:
        verification = json.loads(stdout.read_text())['verification-results']
    except Exception:
        verification = None
    fresh.append(dict(application=item, raw_verification=verification,
        diagnostics=(folder / 'stderr.txt').read_text(errors='replace') if (folder / 'stderr.txt').exists() else None))
save(ROOT / 'FRESH-RAW-SUMMARY.json', fresh)

combined = [Path(fresh[index]['application']['folder']) / 'review_source.rs' for index in [1, 5]]
stage = HROOT / 'staging111.rs'
source_audit = dict(utc=utc(),
    combined_restoration=dict(records=[record(path) for path in combined],
        byte_identical=combined[0].read_bytes() == combined[1].read_bytes() == (PARENT / 'combined111.rs').read_bytes()),
    h_exec_bodies=re.findall(r'pub fn ([A-Za-z_][A-Za-z_0-9]*)', stage.read_text()),
    h_proof_bodies=re.findall(r'pub proof fn ([A-Za-z_][A-Za-z_0-9]*)', stage.read_text()),
    shared_contract_equal=(PARENT / 'shared/contract111.rs').read_bytes() == (PROOT / 'modules/contract111.rs').read_bytes(),
    p_harnesses_separate_from_generic_source=True,
    new_combined_nonvacuity_theorem_freshly_checked=False,
    paired_root_mutants_fresh_in_single_application=True,
    exact_historical_p_negative_wrappers_freshly_replayed=False,
    p_selected_id_negative_freshly_replayed=False,
    python_field_projection_controls_freshly_replayed=False,
    resources=resources())
save(ROOT / 'SOURCE-AUDIT.json', source_audit)
print(json.dumps(dict(historical_applications=len(historical),
    archives=[dict(label=row['label'], members=row['members'], matches=row['all_members_match']) for row in archives],
    fresh=[dict(number=row['application']['number'], raw=row['raw_verification']) for row in fresh],
    source=source_audit), indent=2))
