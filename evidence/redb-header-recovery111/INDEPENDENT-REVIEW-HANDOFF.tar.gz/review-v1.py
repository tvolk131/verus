import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import resource
import shutil
import signal
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
REPO = Path('/Users/tommyvolk/.t3/worktrees/verus/t3-60978068')
PARENT = Path('/private/tmp/redb-header-recovery111-20261108T051418Z')
HROOT = Path('/private/tmp/redb-header-recovery111-H-20261108T052400Z')
PROOT = Path('/private/tmp/redb-header-recovery111-P-cPSXKcfk')
HIST = Path('/private/tmp/verus-crash-consistency94-20261105/native-recovery-reencoding-021/runtime')
EXEC = Path('/private/tmp/verus-crash-consistency94-20261105/native-leaf-lookup-007/midpoint-runtime-proposal/runtime')
FIRST = '2026-11-08T05:47:57Z'
DEADLINE = '2026-11-08T06:02:18Z'
EXPECTED = {
    REPO / 'evidence/redb-header-recovery111/PLAN.md': 'df54d19d300c2393f6ebf40c68e0a3300f7db5856c58dbbb995845c4652fb1db',
    REPO / 'evidence/redb-header-recovery111/INPUTS.json': '9fae5c40b2e2a49cc50b69533325efd00a0f5c385ff384236a5a234ad54273e3',
    PARENT / 'COMBINED-INPUTS.json': 'd868ed5079f9fdf8ff1afc5981fb61cdab7896e00a84b5e8f48ccc027cf468b5',
    HROOT / 'staging111.rs': '0d894c65c6315d1c0de84c6f06a797b9b448d55b9539c542d020502345b6bc31',
    HROOT / 'MANIFEST.json': '74f9c69f848a3ed7342bce0a8ebc523e53fbe929576a55b50a89c2b06a044211',
    HROOT / 'HANDOFF.json': '615ba834c3ee57e7584091c49aa8b556e208efb5250f3607eed28819805b2e60',
    HROOT / 'REPORT.md': 'bfbcaf8f359ac5c02c153762cfbe9cacd0e19a6ba905410af5e1b7fb2e241175',
    PROOT / 'recovery_product111.rs': 'f091f82098b565a863f0f32cf01dd17d46b31ee167fc6d0588a5399a0de928b1',
    PROOT / 'MANIFEST.json': 'e46be684c5f66c54621815bc0e0b96e29ae3526b53546a90cd0fc2ded0e64989',
    PROOT / 'HANDOFF.json': '6f5ee1a7fdd55ca12c589a5c57842db83c797f83eab5d5510d8330fa4bc6ec05',
    PROOT / 'SEAL.json': '166bd5dd8c8d7e766b10740feb161d34060b02edd5f7aa2f5bd57e1b6090f74d',
    PROOT / 'REPORT.md': '74eae5b09ecec92354d990902d8ae5cabce1fcdead04d1d7b62681ec8d15336e',
    PARENT / 'combined-retained/MANIFEST.json': '2e32a972ecb8d0d64da00654b4117df85261af2450f2e63f84ba04f173d1c2c1',
    PARENT / 'combined-retained/HANDOFF.json': '2c36396afce1fff2977ac24bbe97bebe07994dd7085c664a38dc269ece21c971',
    PARENT / 'combined111.rs': 'd590effe76335c59044da26cdd51486e0aa87e1dd175eff2f88a9fc8de58c673',
    PARENT / 'combined-retained/combined111.rs': 'd590effe76335c59044da26cdd51486e0aa87e1dd175eff2f88a9fc8de58c673',
}

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

def digest(path):
    hasher = hashlib.sha256()
    with open(path, 'rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            hasher.update(block)
    return hasher.hexdigest()

def record(path):
    path = Path(path)
    try:
        info = path.stat()
        return dict(path=str(path), resolved=str(path.resolve()), bytes=info.st_size,
                    mode=oct(info.st_mode & 0o7777), executable=os.access(path, os.X_OK),
                    sha256=digest(path))
    except (OSError, ValueError) as error:
        return dict(path=str(path), error=str(error))

def resources():
    size = sum(path.stat().st_size for path in ROOT.rglob('*') if path.is_file())
    return dict(utc=utc(), free_bytes=shutil.disk_usage(ROOT).free, scratch_bytes=size,
                free_ok=shutil.disk_usage(ROOT).free > 16 * 1024**3,
                scratch_ok=size <= 512 * 1024**2)

def authenticate(label, complete=False):
    cache = {}
    def actual(path):
        key = str(path)
        if key not in cache:
            cache[key] = record(path)
        return cache[key]
    groups = {}
    groups['top_level'] = [dict(expected_sha256=expected, actual=actual(path),
        matches=actual(path).get('sha256') == expected) for path, expected in EXPECTED.items()]
    manifests = [(HROOT / 'MANIFEST.json', 'files', HROOT),
                 (PROOT / 'MANIFEST.json', 'records', PROOT),
                 (PARENT / 'combined-retained/MANIFEST.json', 'files', PARENT / 'combined-retained'),
                 (PARENT / 'COMBINED-INPUTS.json', 'records', PARENT)]
    if complete:
        manifests.append((REPO / 'evidence/redb-header-recovery111/INPUTS.json', 'records', REPO))
    for manifest, key, base in manifests:
        rows = []
        for expected in json.loads(manifest.read_text())[key]:
            path = Path(expected['path'])
            if not path.is_absolute():
                path = base / path
            observed = actual(path)
            rows.append(dict(expected=expected, actual=observed,
                matches=observed.get('sha256') == expected['sha256'] and observed.get('bytes') == expected['bytes']))
        groups[str(manifest)] = rows
    pairs = []
    for name in ['verus', 'rust_verify', 'z3']:
        selected, used = actual(HIST / name), actual(EXEC / name)
        pairs.append(dict(name=name, selected=selected, used=used,
                          byte_identical=selected.get('sha256') == used.get('sha256')))
    toolpaths = [HIST / 'vstd.vir', HIST / 'libvstd.rlib', EXEC / 'vstd.vir', EXEC / 'libvstd.rlib',
        Path(sys.executable), Path('/bin/zsh'), Path('/bin/ps'), Path('/usr/bin/env'),
        Path('/usr/bin/date'), Path('/bin/df'), Path('/usr/bin/shasum'), Path('/usr/bin/tar'),
        Path('/Users/tommyvolk/.rustup/toolchains/1.99.1-aarch64-apple-darwin/bin/rustc'),
        Path('/Users/tommyvolk/.rustup/toolchains/1.99.1-aarch64-apple-darwin/bin/rustdoc'),
        Path('/Users/tommyvolk/.t3/userdata/providers/codex/codex_095eca24-b4b7-4a15-8759-9d8964dbd03a/shadow/tmp/arg0-macos/codex-arg011pOCK/apply_patch')]
    invocation = json.loads((PARENT / 'parent-check-03-combined/invocation.json').read_text())
    for index, argument in enumerate(invocation['argv']):
        if argument in ['--extern', '--import']:
            toolpaths.append(Path(invocation['argv'][index + 1].split('=', 1)[1]))
    data = dict(utc=utc(), label=label, groups=groups, pairs=pairs,
        tools=[actual(path) for path in toolpaths], runner=record(__file__), resources=resources(),
        first_clock=FIRST, absolute_deadline=DEADLINE, actual_python=sys.executable,
        no_atomic_snapshot_claim=True,
        summary={key: dict(records=len(rows), matches=sum(row['matches'] for row in rows),
                          mismatches=sum(not row['matches'] for row in rows)) for key, rows in groups.items()})
    save(ROOT / ('authentication-' + label + '.json'), data)
    print(json.dumps(data['summary'], indent=2), flush=True)
    return data

def scope(source, destination):
    pending = [Path(source)]
    visited = {}
    while pending:
        path = pending.pop()
        if str(path) in visited:
            continue
        text = path.read_text()
        info = record(path)
        target = destination / (str(len(visited)).zfill(3) + '-' + path.name)
        shutil.copyfile(path, target)
        info['snapshot'] = str(target)
        visited[str(path)] = info
        pending.extend(path.parent / relative for relative in re.findall(r'#\[path\s*=\s*"([^"]+)"\]', text))
    return list(visited.values())

def run(label, original, expected):
    ledger_path = ROOT / 'APPLICATIONS.json'
    ledger = json.loads(ledger_path.read_text()) if ledger_path.exists() else []
    if len(ledger) >= 6:
        raise RuntimeError('Six-application limit reached')
    if utc() >= '2026-11-08T06:00:40+00:00':
        raise RuntimeError('Insufficient time reserved for sealing')
    folder = ROOT / ('check-' + str(len(ledger) + 1).zfill(2) + '-' + label)
    folder.mkdir()
    item = dict(number=len(ledger) + 1, label=label, original=str(original), expected=expected,
                charged=True, state='setup_started', utc=utc(), folder=str(folder))
    ledger.append(item)
    save(ledger_path, ledger)
    entry = authenticate('preexecution-' + str(item['number']))
    for key, summary in entry['summary'].items():
        if summary['mismatches']:
            item['state'] = 'setup_authentication_failure'
            save(ledger_path, ledger)
            raise RuntimeError(key + ' authentication mismatch')
    for path in PROOT.glob('*.rs'):
        shutil.copyfile(path, folder / path.name)
    shutil.copytree(PROOT / 'modules', folder / 'modules')
    source = folder / 'review_source.rs'
    shutil.copyfile(original, source)
    (folder / 'source-scope').mkdir()
    save(folder / 'source-scope.json', scope(source, folder / 'source-scope'))
    template = json.loads((PARENT / 'parent-check-03-combined/invocation.json').read_text())
    arguments = list(template['argv'])
    arguments[arguments.index('--crate-name') + 1] = 'independent_review111'
    export = folder / 'fresh.vir'
    arguments[arguments.index('--export') + 1] = str(export)
    arguments[-1] = str(source)
    environment = dict(template['environment'])
    oldcwd = template['cwd']
    for key, value in environment.items():
        if value.startswith(oldcwd):
            environment[key] = value.replace(oldcwd, str(folder), 1)
            if key != 'PWD':
                Path(environment[key]).mkdir(parents=True, exist_ok=True)
    if 'VARGO_TARGET_DIR' in environment or '--compile' in arguments:
        raise RuntimeError('Forbidden environment or compile flag')
    invocation = dict(argv=arguments, environment=environment, cwd=str(folder),
        source=record(source), original_source=record(original), export_path=str(export),
        export_fresh_absent=not export.exists(), timeout_seconds=90, utc=utc())
    save(folder / 'invocation.json', invocation)
    began = time.monotonic()
    samples = []
    process = None
    reason = None
    error = None
    with open(folder / 'stdout.txt', 'wb') as stdout, open(folder / 'stderr.txt', 'wb') as stderr:
        try:
            process = subprocess.Popen(arguments, cwd=folder, env=environment,
                stdout=stdout, stderr=stderr, start_new_session=True)
            while process.poll() is None:
                sample = resources()
                sample['elapsed_seconds'] = time.monotonic() - began
                observed = subprocess.run(['/bin/ps', '-axo', 'pid,ppid,command'],
                    stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
                sample['verifier_processes'] = [line for line in observed.stdout.splitlines()
                    if str(process.pid) in line or str(EXEC) in line or 'rust_verify' in line or '/z3' in line]
                samples.append(sample)
                if time.monotonic() - began >= 90:
                    reason = 'timeout'
                elif not sample['free_ok'] or not sample['scratch_ok']:
                    reason = 'resource_limit'
                elif utc() >= DEADLINE.replace('Z', '+00:00'):
                    reason = 'absolute_deadline'
                if reason:
                    os.killpg(process.pid, signal.SIGKILL)
                    break
                time.sleep(0.2)
            process.wait()
        except Exception as caught:
            error = repr(caught)
            if process is not None and process.poll() is None:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait()
    result = dict(utc=utc(), elapsed_seconds=time.monotonic() - began,
        returncode=process.returncode if process else None, termination_reason=reason, launcher_error=error,
        process_reaped=process is None or process.poll() is not None, samples=samples,
        export=record(export), export_initially_absent=invocation['export_fresh_absent'],
        stdout=record(folder / 'stdout.txt'), stderr=record(folder / 'stderr.txt'),
        child_resource_usage_raw=tuple(resource.getrusage(resource.RUSAGE_CHILDREN)))
    save(folder / 'result.json', result)
    item.update(state='completed' if not error and not reason else 'inconclusive',
        returncode=result['returncode'], elapsed_seconds=result['elapsed_seconds'],
        export_sha256=result['export'].get('sha256'), termination_reason=reason, launcher_error=error)
    save(ledger_path, ledger)
    print(json.dumps(item, indent=2), flush=True)
    print((folder / 'stdout.txt').read_text(errors='replace')[-3000:], flush=True)
    print((folder / 'stderr.txt').read_text(errors='replace')[-2000:], flush=True)

if __name__ == '__main__':
    if sys.argv[1] == 'authenticate':
        authenticate(sys.argv[2], complete=True)
    elif sys.argv[1] == 'run':
        run(sys.argv[2], Path(sys.argv[3]), sys.argv[4])
