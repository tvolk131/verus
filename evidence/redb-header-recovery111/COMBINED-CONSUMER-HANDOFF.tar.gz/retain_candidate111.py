import datetime
import json
from pathlib import Path
import shutil
import sys
import tarfile

from check import EVIDENCE, ROOT, authenticate, identity


def authenticate_candidate(directory, expected):
    assert directory.is_dir() and not directory.is_symlink()
    assert identity(directory / 'MANIFEST.json')['sha256'] == expected['manifest_sha256']
    assert identity(directory / 'HANDOFF.json')['sha256'] == expected['handoff_sha256']
    if 'seal_sha256' in expected:
        assert identity(directory / 'SEAL.json')['sha256'] == expected['seal_sha256']
    manifest = json.loads((directory / 'MANIFEST.json').read_text())
    records_key = expected.get('manifest_records_key', 'files')
    assert isinstance(manifest[records_key], list)
    names = set()
    for record in manifest[records_key]:
        reported = Path(record['path'])
        relative = reported.relative_to(directory) if reported.is_absolute() else reported
        assert relative.parts and '..' not in relative.parts
        filename = directory / relative
        assert filename.resolve() == filename.absolute()
        assert filename.is_file() and not filename.is_symlink()
        observed = identity(filename)
        assert observed['bytes'] == record['bytes']
        assert observed['sha256'] == record['sha256']
        assert str(relative) not in names
        names.add(str(relative))
    assert 'MANIFEST.json' not in names
    assert ('HANDOFF.json' in names) == expected.get('manifest_includes_handoff', False)
    assert identity(directory / expected['source'])['sha256'] == expected['source_sha256']
    assert identity(directory / 'REPORT.md')['sha256'] == expected['report_sha256']
    return names


def retain(expected_path):
    expected = json.loads(expected_path.read_text())
    label = expected['label']
    assert label in ['H', 'P']
    directory = Path(expected['root']).resolve()
    authenticate(ROOT / (label + '-retention-authentication-entry.json'))
    names = authenticate_candidate(directory, expected)
    archive_path = EVIDENCE / (label + '-CANDIDATE-HANDOFF.tar.gz')
    assert not archive_path.exists()
    members_expected = names | {'MANIFEST.json', 'HANDOFF.json'}
    if (directory / 'SEAL.json').is_file():
        members_expected.add('SEAL.json')
    with tarfile.open(archive_path, 'w:gz') as archive:
        for name in sorted(members_expected):
            archive.add(directory / name, arcname=name, recursive=False)
    with tarfile.open(archive_path, 'r:gz') as archive:
        members = archive.getmembers()
        assert len(members) == len(members_expected)
        assert {member.name for member in members} == members_expected
        for member in members:
            assert member.isfile() and not Path(member.name).is_absolute()
            assert '..' not in Path(member.name).parts
            assert archive.extractfile(member).read() == (directory / member.name).read_bytes()
    copies = ['REPORT.md', 'HANDOFF.json', 'MANIFEST.json', expected['source']]
    copies.extend(expected.get('additional_copies', []))
    for name in copies:
        target = EVIDENCE / (label + '-CANDIDATE-' + Path(name).name)
        assert not target.exists()
        shutil.copyfile(directory / name, target)
        assert target.read_bytes() == (directory / name).read_bytes()
    assert authenticate_candidate(directory, expected) == names
    authenticate(ROOT / (label + '-retention-authentication-exit.json'))
    result = {
        'schema': 'redb111-candidate-retention-v1',
        'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'source': str(directory), 'expected': expected,
        'selected_input_matches_entry_and_exit': 1416,
        'payload_matches': len(names), 'archive_members_byte_compared': len(members),
        'archive': identity(archive_path),
        'new_native_body_proof_credit': False,
        'independent_review': 'PENDING_SINGLE_COMBINED_REVIEW',
        'all18': 'OPEN', 'acceptance': False, 'adoption': False, 'integration': False,
    }
    (EVIDENCE / (label + '-RETENTION.json')).write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == '__main__':
    retain(Path(sys.argv[1]))
