import datetime
import json
from pathlib import Path
import shutil
import sys

from check import EVIDENCE, ROOT, identity
from retain_candidate111 import authenticate_candidate


def capture():
    records = {}
    for label in ['H', 'P']:
        expected = json.loads((ROOT / (label + '-EXPECTED.json')).read_text())
        directory = Path(expected['root'])
        names = authenticate_candidate(directory, expected)
        names |= {'MANIFEST.json', 'HANDOFF.json'}
        if (directory / 'SEAL.json').is_file():
            names.add('SEAL.json')
        for name in names:
            observed = identity(directory / name)
            records[observed['path']] = observed
    for filename in [ROOT / 'combined111.rs', ROOT / 'check.py', Path(__file__),
                     ROOT / 'retain_candidate111.py', ROOT / 'H-EXPECTED.json',
                     ROOT / 'P-EXPECTED.json', Path(sys.executable).resolve()]:
        observed = identity(filename)
        records[observed['path']] = observed
    destination = ROOT / 'COMBINED-INPUTS.json'
    if destination.exists():
        previous = identity(destination)
        snapshot = ROOT / ('COMBINED-INPUTS-' + previous['sha256'] + '.json')
        assert not snapshot.exists()
        shutil.copyfile(destination, snapshot)
    result = {'schema': 'redb111-parent-combined-selected-inputs-v1',
              'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'records': [records[name] for name in sorted(records)],
              'first_read_or_atomic_snapshot_claim': False}
    destination.write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'manifest': identity(destination), 'records': len(records)}, indent=2))


if __name__ == '__main__':
    capture()
