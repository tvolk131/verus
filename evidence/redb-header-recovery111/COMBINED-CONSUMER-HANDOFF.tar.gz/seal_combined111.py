import datetime
import json
from pathlib import Path
import re
import shutil
import tarfile

from check import EVIDENCE, ROOT, authenticate, identity


def seal():
    destination = ROOT / 'combined-retained'
    destination.mkdir()
    authenticate(destination / 'authentication-entry.json')
    attempt = ROOT / 'parent-check-03-combined'
    result = json.loads((attempt / 'result.json').read_text())
    assert result['completed_zero_exit'] and result['export_present']
    assert result['verification']['verified'] == 80 and result['verification']['errors'] == 0
    assert (ROOT / 'combined111.rs').read_bytes() == (attempt / 'combined111.rs').read_bytes()
    names = ['combined111.rs', 'COMBINED-INPUTS.json', 'PARENT-APPLICATIONS.json',
             'check.py', 'capture_combined_inputs111.py', 'retain_candidate111.py',
             'seal_combined111.py', 'H-EXPECTED.json', 'P-EXPECTED.json']
    names.extend(str(filename.relative_to(ROOT)) for filename in attempt.rglob('*') if filename.is_file())
    for name in sorted(names):
        target = destination / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(ROOT / name, target)
        assert (ROOT / name).read_bytes() == target.read_bytes()
    scope = []
    included_sources = [
        ROOT / 'combined111.rs',
        Path('/private/tmp/redb-header-recovery111-H-20261108T052400Z/staging111.rs'),
        Path('/private/tmp/redb-header-recovery111-P-cPSXKcfk/recovery_product111.rs'),
    ]
    included_sources.extend(Path('/private/tmp/redb-header-recovery111-P-cPSXKcfk/modules') / name
                            for name in ['composition110.rs', 'buffered_flush109.rs', 'ack_cfg.rs'])
    for filename in included_sources:
        source = filename.read_text()
        scope.append({'source': identity(filename),
                      'public_exec_declarations': re.findall(r'^pub fn ([A-Za-z_][A-Za-z_0-9]*)', source, re.MULTILINE),
                      'public_proof_declarations': re.findall(r'^pub proof fn ([A-Za-z_][A-Za-z_0-9]*)', source, re.MULTILINE)})
    receipt = {
        'schema': 'redb111-parent-combined-proof-v1',
        'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'source': identity(ROOT / 'combined111.rs'), 'result': result,
        'selected_frozen_records': 1416, 'supplemental_records': 351,
        'source_declaration_audit_not_compiler_body_counter': scope,
        'parent_applications_charged': 3, 'parent_application_cap': 4,
        'one_parent_application_reserved_for_small_review_findings': True,
        'H_and_P_sources_unchanged': True,
        'P_separate_witness_and_control_sources_not_in_parent_combined_crate': True,
        'native_supplied_slice_binding': 'CALLER_PREMISE_NOT_NATIVE_FETCH',
        'inherited_boundary': 'EXPLICIT_INHERITED_STD_BOOL_TCB_NOT_RUST_CORE_PROOF',
        'new_native_bodies_checked': 0, 'all18': 'OPEN',
        'independent_review': 'PENDING_SINGLE_COMBINED_REVIEW',
        'acceptance': False, 'adoption': False, 'integration': False,
    }
    (destination / 'RESULTS.json').write_text(json.dumps(receipt, indent=2, sort_keys=True) + '\n')
    authenticate(destination / 'authentication-exit.json')
    records = []
    for filename in sorted(destination.rglob('*')):
        if filename.is_file():
            observed = identity(filename)
            observed['path'] = str(filename.relative_to(destination))
            records.append(observed)
    manifest = {'schema': 'redb111-parent-combined-manifest-v1', 'files': records}
    (destination / 'MANIFEST.json').write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
    handoff = {'schema': 'redb111-parent-combined-handoff-v1',
               'manifest': identity(destination / 'MANIFEST.json'),
               'source': identity(destination / 'combined111.rs'),
               'results': identity(destination / 'RESULTS.json'),
               'verified': 80, 'errors': 0, 'all18': 'OPEN', 'acceptance': False}
    (destination / 'HANDOFF.json').write_text(json.dumps(handoff, indent=2, sort_keys=True) + '\n')
    selected = {record['path'] for record in records} | {'MANIFEST.json', 'HANDOFF.json'}
    archive_path = EVIDENCE / 'COMBINED-CONSUMER-HANDOFF.tar.gz'
    assert not archive_path.exists()
    with tarfile.open(archive_path, 'w:gz') as archive:
        for name in sorted(selected):
            archive.add(destination / name, arcname=name, recursive=False)
    with tarfile.open(archive_path, 'r:gz') as archive:
        members = archive.getmembers()
        assert len(members) == len(selected) and {member.name for member in members} == selected
        for member in members:
            assert member.isfile()
            assert archive.extractfile(member).read() == (destination / member.name).read_bytes()
    for name in ['RESULTS.json', 'MANIFEST.json', 'HANDOFF.json', 'combined111.rs']:
        shutil.copyfile(destination / name, EVIDENCE / ('COMBINED-' + name))
    retained = {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                'source': str(destination), 'archive': identity(archive_path),
                'manifest': identity(destination / 'MANIFEST.json'),
                'handoff': identity(destination / 'HANDOFF.json'),
                'payloads': len(records), 'archive_members_compared': len(members),
                'verified_obligations': 80, 'new_native_bodies_checked': 0,
                'all18': 'OPEN', 'acceptance': False, 'adoption': False, 'integration': False}
    (EVIDENCE / 'COMBINED-RETENTION.json').write_text(json.dumps(retained, indent=2, sort_keys=True) + '\n')
    print(json.dumps(retained, indent=2, sort_keys=True))


if __name__ == '__main__':
    seal()
