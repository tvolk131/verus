import datetime
import hashlib
import json
import os
from pathlib import Path
import signal
import shutil
import subprocess
import sys


ROOT = Path('/private/tmp/redb-header-recovery111-20261108T051418Z')
EVIDENCE = Path('/Users/tommyvolk/.t3/worktrees/verus/t3-60978068/evidence/redb-header-recovery111')
HISTORICAL = Path('/private/tmp/verus-crash-consistency94-20261105/native-recovery-reencoding-021')
EXECUTABLE_RUNTIME = Path('/private/tmp/verus-crash-consistency94-20261105/native-leaf-lookup-007/midpoint-runtime-proposal/runtime')


def identity(filename):
    content = filename.read_bytes()
    return {'path': str(filename), 'bytes': len(content), 'sha256': hashlib.sha256(content).hexdigest()}


def authenticate(destination):
    frozen = json.loads((EVIDENCE / 'INPUTS.json').read_text())['records']
    failures = [record['path'] for record in frozen if identity(Path(record['path']))['sha256'] != record['sha256']]
    supplemental = ROOT / 'COMBINED-INPUTS.json'
    extra_records = json.loads(supplemental.read_text())['records'] if supplemental.exists() else []
    extra_failures = [record['path'] for record in extra_records if identity(Path(record['path']))['sha256'] != record['sha256']]
    destination.write_text(json.dumps({'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'matches': len(frozen) - len(failures), 'failures': failures, 'supplemental_matches': len(extra_records) - len(extra_failures), 'supplemental_failures': extra_failures, 'supplemental_manifest': identity(supplemental) if supplemental.exists() else None}, indent=2) + '\n')
    assert not failures
    assert not extra_failures


def run_check(label, source):
    ledger = ROOT / 'PARENT-APPLICATIONS.json'
    charges = json.loads(ledger.read_text()) if ledger.exists() else []
    assert len(charges) < 4
    number = len(charges) + 1
    directory = ROOT / ('parent-check-%02d-%s' % (number, label))
    directory.mkdir()
    charges.append({'number': number, 'label': label, 'directory': str(directory), 'charged': True, 'utc': datetime.datetime.now(datetime.timezone.utc).isoformat()})
    ledger.write_text(json.dumps(charges, indent=2) + '\n')
    authenticate(directory / 'authentication-entry.json')
    original_source = source
    source = directory / original_source.name
    shutil.copyfile(original_source, source)
    supplemental = ROOT / 'COMBINED-INPUTS.json'
    if supplemental.exists():
        shutil.copyfile(supplemental, directory / 'supplemental-inputs.json')
    baseline = json.loads(Path('/private/tmp/redb-backend110-B-cCGFf2VR/attempt-10/invocation.json').read_text())
    original_directory = baseline['cwd']
    environment = {name: value.replace(original_directory, str(directory)) for name, value in baseline['environment'].items()}
    for executable in ['verus', 'rust_verify', 'z3']:
        assert identity(EXECUTABLE_RUNTIME / executable)['sha256'] == identity(HISTORICAL / 'runtime' / executable)['sha256']
        assert os.access(EXECUTABLE_RUNTIME / executable, os.X_OK)
    environment.pop('VARGO_TARGET_DIR', None)
    environment['VERUS_ROOT'] = str(HISTORICAL / 'runtime')
    environment['VERUS_Z3_PATH'] = str(EXECUTABLE_RUNTIME / 'z3')
    for name in ['CARGO_HOME', 'CARGO_TARGET_DIR', 'HOME', 'RUSTUP_HOME', 'TEMP', 'TMP', 'TMPDIR', 'XDG_CACHE_HOME', 'XDG_CONFIG_HOME', 'XDG_DATA_HOME', 'XDG_STATE_HOME', 'VERUS_INFER_CACHE']:
        Path(environment[name]).mkdir(parents=True, exist_ok=True)
    export_path = directory / 'candidate.vir'
    assert not export_path.exists()
    argv = [str(EXECUTABLE_RUNTIME / 'verus'), '--sysroot', '/Users/tommyvolk/.rustup/toolchains/1.99.1-aarch64-apple-darwin', '--edition=2024', '--target', 'aarch64-apple-darwin', '--crate-type=lib', '--crate-name', 'header_bridge111', '--no-cheating', '--output-json', '--num-threads', '1', '--triggers-mode', 'silent', '--multiple-errors', '8', '--rlimit', '30', '-C', 'debug-assertions=no']
    for crate in ['pagecodec94', 'rootcodec94', 'hash94', 'hashdispatch013', 'recovery_reencoding021', 'recovery_roundtrip021']:
        argv.extend(['--extern', '%s=%s' % (crate, HISTORICAL / 'artifacts' / ('lib' + crate + '.rlib')), '--import', '%s=%s' % (crate, HISTORICAL / 'artifacts' / (crate + '.vir'))])
    argv.extend(['-L', 'dependency=' + str(HISTORICAL / 'artifacts'), '--export', str(export_path), str(source)])
    invocation = {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'number': number, 'argv': argv, 'environment': environment, 'cwd': str(directory), 'source': identity(source), 'original_source': identity(original_source), 'runner': identity(Path(__file__)), 'export_fresh_absent': True, 'timeout_seconds': 90}
    (directory / 'invocation.json').write_text(json.dumps(invocation, indent=2) + '\n')
    authenticate(directory / 'authentication-preexecution.json')
    process = None
    interruption = None
    timed_out = False
    launch_error = None
    status = None
    with (directory / 'stdout.txt').open('wb') as stdout, (directory / 'stderr.txt').open('wb') as stderr:
        try:
            process = subprocess.Popen(argv, cwd=directory, env=environment, stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr, start_new_session=True)
            status = process.wait(timeout=90)
        except (subprocess.TimeoutExpired, KeyboardInterrupt) as error:
            timed_out = isinstance(error, subprocess.TimeoutExpired)
            interruption = None if timed_out else error
            if process is not None:
                os.killpg(process.pid, signal.SIGKILL)
                status = process.wait()
        except OSError as error:
            launch_error = repr(error)
    authenticate(directory / 'authentication-exit.json')
    try:
        output = json.loads((directory / 'stdout.txt').read_text())
    except (ValueError, UnicodeError):
        output = {}
    result = {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'number': number, 'status': status, 'timed_out': timed_out, 'interrupted': interruption is not None, 'launch_error': launch_error, 'completed_zero_exit': status == 0 and not timed_out and interruption is None and launch_error is None, 'export_present': export_path.is_file(), 'export': identity(export_path) if export_path.is_file() else None, 'verification': output.get('verification-results', {}), 'source_after': identity(source)}
    (directory / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))
    if interruption is not None:
        raise interruption
    return result


if __name__ == '__main__':
    run_check(sys.argv[1], Path(sys.argv[2]).resolve())
