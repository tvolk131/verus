import datetime
import difflib
import json
from pathlib import Path
import sys
import time

sys.dont_write_bytecode = True
import runner

ROOT = runner.ROOT

def load(path):
    return json.loads(path.read_text())

def main():
    assert time.time() < runner.DEADLINE
    runner.authentication(ROOT / 'authentication-final-exit.json')
    ledger = load(ROOT / 'APPLICATIONS.json')
    assert len(ledger) == 13
    results = []
    observations = []
    for charge in ledger:
        directory = Path(charge['directory'])
        result = load(directory / 'result.json')
        invocation = load(directory / 'invocation.json')
        assert result['source_unchanged']
        assert result['elapsed_seconds'] <= 90
        assert not result['timed_out'] and not result['interrupted']
        assert result['error'] is None
        assert result['resources']['within_limits']
        assert invocation['export_fresh_absent']
        assert invocation['environment']['VERUS_ROOT'] == str(runner.HISTORICAL / 'runtime')
        assert invocation['environment']['VERUS_Z3_PATH'] == str(runner.EXECUTABLE / 'z3')
        assert 'VARGO_TARGET_DIR' not in invocation['environment']
        assert '--no-cheating' in invocation['argv']
        assert '--compile' not in invocation['argv']
        assert '--verify-only-module' not in invocation['argv']
        assert '--verify-function' not in invocation['argv']
        assert invocation['argv'][invocation['argv'].index('--num-threads') + 1] == '1'
        expected_export = directory / 'candidate.vir'
        assert result['export_path'] == str(expected_export)
        assert result['export_present'] == expected_export.is_file()
        if expected_export.is_file():
            assert result['export']['sha256'] == runner.identity(expected_export)['sha256']
        for phase in ['entry', 'preexecution', 'exit']:
            path = directory / ('authentication-' + phase + '.json')
            authentication = load(path)
            assert authentication['records'] == 1416
            assert authentication['matches'] == 1416
            assert not authentication['failures']
            observations.append(runner.identity(path))
        results.append({'number': charge['number'], 'label': charge['label'], 'directory': str(directory), 'status': result['status'], 'verification': result['verification'], 'elapsed_seconds': result['elapsed_seconds'], 'source_sha256': result['source_after']['sha256'], 'export': result['export']})
    baseline = results[6]
    assert baseline['verification']['success']
    controls = []
    for number, corrected_number, property_name, text in [(8, 9, 'selected transaction ID', 'transaction_id.0 == 7'), (10, 11, 'associated user root', 'user_root == Some(witnesses::witness_system_root())'), (12, 13, 'associated system root', 'system_root == Some(witnesses::witness_user_root())')]:
        negative = results[number - 1]
        corrected = results[corrected_number - 1]
        stderr = (Path(negative['directory']) / 'stderr.txt').read_text()
        assert negative['status'] == 1
        assert negative['verification']['verified'] == 70
        assert negative['verification']['errors'] == 1
        assert not negative['verification']['encountered-vir-error']
        assert 'assertion failed' in stderr and text in stderr
        assert 'error[E' not in stderr
        assert negative['export'] is None
        assert corrected['status'] == 0
        assert corrected['verification']['success']
        assert corrected['verification']['verified'] == 71
        assert corrected['verification']['errors'] == 0
        assert corrected['source_sha256'] == baseline['source_sha256']
        assert corrected['export'] is not None
        controls.append({'property': property_name, 'negative_application': number, 'corrected_and_restored_application': corrected_number, 'intended_backend_assertion_reached': True, 'byte_identical_to_baseline': True, 'baseline_and_restored_sha256': baseline['source_sha256']})
    assert runner.identity(ROOT / 'semantic_controls111.rs')['sha256'] == baseline['source_sha256']
    runner.save(ROOT / 'CONTROLS.json', controls)
    final_resources = runner.resources()
    assert final_resources['within_limits']
    first = datetime.datetime.fromisoformat(runner.FIRST_CLOCK)
    elapsed = time.time() - first.timestamp()
    accounting = {'utc': runner.utc(), 'first_clock_utc': runner.FIRST_CLOCK, 'elapsed_since_first_clock_seconds': elapsed, 'own_hard_deadline_utc': '2026-11-08T05:49:56Z', 'charged_applications': len(ledger), 'charged_application_cap': 16, 'workers': 1, 'application_timeout_seconds': 90, 'maximum_observed_application_seconds': max(result['elapsed_seconds'] for result in results), 'applications': results, 'all_attempts_retained': True, 'authentication_observations': observations, 'all_frozen_records_each_observation': 1416, 'resources': final_resources, 'continuous_peak_measurement': False, 'no_extension_or_reset': True}
    runner.save(ROOT / 'ACCOUNTING.json', accounting)
    authored = [ROOT / name for name in ['recovery_product111.rs', 'witnesses111.rs', 'semantic_controls111.rs']]
    patch = ''.join(''.join(difflib.unified_diff([], path.read_text().splitlines(True), fromfile='/dev/null', tofile='lane-P/' + path.name)) for path in authored)
    (ROOT / 'final-source.patch').write_text(patch)
    last = results[-1]
    assert last['verification']['success'] and last['verification']['verified'] == 71
    handoff = {'schema': 'round111-lane-P-sealed-source-consumer-v1', 'utc': runner.utc(), 'result': 'CHECKED_CONDITIONAL_SOURCE_MODULE_COMPOSITION_NOT_NATIVE_ADMISSION', 'source': runner.identity(ROOT / 'recovery_product111.rs'), 'witnesses': runner.identity(ROOT / 'witnesses111.rs'), 'controls': runner.identity(ROOT / 'semantic_controls111.rs'), 'api': runner.identity(ROOT / 'API.md'), 'report': runner.identity(ROOT / 'REPORT.md'), 'patch': runner.identity(ROOT / 'final-source.patch'), 'modules': [runner.identity(ROOT / 'modules' / name) for name in sorted(runner.SHARED_HASHES)], 'stable_apis': ['decode_expected_header', 'public_ok_recovers_expected', 'expected_file_length', 'expected_domain', 'selected_payload_matches'], 'final_full_crate_application': 13, 'final_export': last['export'], 'charged_applications': len(ledger), 'inherited_boundary': 'EXPLICIT_INHERITED_STD_BOOL_TCB_NOT_RUST_CORE_PROOF', 'trust_adopted': False, 'native_path': 'FAILED', 'native_git': 'UNAVAILABLE', 'compiler_source_correspondence': 'UNESTABLISHED', 'all18': 'OPEN', 'parent_integration': False, 'lane_H_rechecked': False, 'automatic_followups': False}
    runner.save(ROOT / 'HANDOFF.json', handoff)
    retained = [runner.identity(path) for path in sorted(ROOT.rglob('*')) if path.is_file() and path.name not in ['MANIFEST.json', 'SEAL.json']]
    runner.save(ROOT / 'MANIFEST.json', {'schema': 'round111-lane-P-retained-manifest-v1', 'utc': runner.utc(), 'records': retained, 'files': len(retained), 'authentication_final': runner.identity(ROOT / 'authentication-final-exit.json'), 'manifest_excludes': ['MANIFEST.json', 'SEAL.json']})
    seal = {'schema': 'round111-lane-P-seal-v1', 'utc': runner.utc(), 'manifest': runner.identity(ROOT / 'MANIFEST.json'), 'handoff': runner.identity(ROOT / 'HANDOFF.json'), 'report': runner.identity(ROOT / 'REPORT.md'), 'source': runner.identity(ROOT / 'recovery_product111.rs'), 'patch': runner.identity(ROOT / 'final-source.patch'), 'final_export': last['export'], 'resources_after_seal_content': runner.resources(), 'charged_applications': len(ledger), 'complete': True, 'no_followup': True}
    runner.save(ROOT / 'SEAL.json', seal)
    print(json.dumps({'seal': runner.identity(ROOT / 'SEAL.json'), 'manifest': seal['manifest'], 'handoff': seal['handoff'], 'report': seal['report'], 'source': seal['source'], 'patch': seal['patch'], 'export': seal['final_export'], 'accounting': runner.identity(ROOT / 'ACCOUNTING.json'), 'resources': runner.resources()}, indent=2))

if __name__ == '__main__':
    main()
