use vstd::prelude::*;
#[path = "witnesses111.rs"]
pub mod witnesses;

verus! {

pub fn selected_id_and_roots_control()
{
    let actual = witnesses::concrete_decoder_nonvacuity();
    assert(actual.transaction_slots@[1].transaction_id.0 == 11);
    assert(actual.transaction_slots@[1].user_root == Some(witnesses::witness_system_root()));
    assert(actual.transaction_slots@[1].system_root == Some(witnesses::witness_system_root()));
}

}
