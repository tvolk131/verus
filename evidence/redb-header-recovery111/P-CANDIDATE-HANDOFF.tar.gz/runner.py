import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import sys
import time

ROOT = Path('/private/tmp/redb-header-recovery111-P-cPSXKcfk')
EVIDENCE = Path('/Users/tommyvolk/.t3/worktrees/verus/t3-60978068/evidence/redb-header-recovery111')
SHARED = Path('/private/tmp/redb-header-recovery111-20261108T051418Z/shared')
HISTORICAL = Path('/private/tmp/verus-crash-consistency94-20261105/native-recovery-reencoding-021')
EXECUTABLE = Path('/private/tmp/verus-crash-consistency94-20261105/native-leaf-lookup-007/midpoint-runtime-proposal/runtime')
PYTHON = Path('/Library/Developer/CommandLineTools/Library/Frameworks/Python3.framework/Versions/3.9/bin/python3.9')
FIRST_CLOCK = '2026-11-08T05:24:56+00:00'
DEADLINE = datetime.datetime.fromisoformat('2026-11-08T05:49:56+00:00').timestamp()
CRATES = ['pagecodec94', 'rootcodec94', 'hash94', 'hashdispatch013', 'recovery_reencoding021', 'recovery_roundtrip021']
SHARED_HASHES = {'contract111.rs': '839e12109cc0ae0699536cbc7f401dc6d2b7d5f6f44eeccf8c9453bf450277ef', 'composition110.rs': '00289ba9a9189b9b24491ef68ae84fa74e75a04d1c19277db4e6bafa26456f5e', 'buffered_flush109.rs': '29485224c99ba2f994012ff53b2ddc98c9cab79daaf7b3fc2a855b952d2fdc4f', 'ack_cfg.rs': '447a7fcfa23fcdec6114be0ec4eb27274ed4133efbc7d81fdac896dffd9306a2'}

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def save(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

def identity(path):
    content = path.read_bytes()
    return {'path': str(path), 'realpath': str(path.resolve()), 'bytes': len(content), 'sha256': hashlib.sha256(content).hexdigest(), 'mode': oct(path.stat().st_mode & 0o777)}

def resources():
    total = sum(path.stat().st_size for path in ROOT.rglob('*') if path.is_file())
    free = shutil.disk_usage('/private/tmp').free
    return {'utc': utc(), 'scratch_bytes': total, 'scratch_cap_bytes': 768 * 1024**2, 'global_free_bytes': free, 'global_free_floor_bytes': 16 * 1024**3, 'within_limits': total <= 768 * 1024**2 and free > 16 * 1024**3, 'seconds_remaining': DEADLINE - time.time()}

def source_closure(source):
    pending = [source]
    found = set()
    while pending:
        current = pending.pop().resolve()
        if current in found:
            continue
        found.add(current)
        for relative in re.findall(r'#\[path\s*=\s*"([^"]+)"\]', current.read_text()):
            pending.append(current.parent / relative)
    return sorted(found)

def authentication(destination):
    expected = {'PLAN.md': 'df54d19d300c2393f6ebf40c68e0a3300f7db5856c58dbbb995845c4652fb1db', 'INPUTS.json': '9fae5c40b2e2a49cc50b69533325efd00a0f5c385ff384236a5a234ad54273e3'}
    failures = []
    selected = []
    for name, digest in expected.items():
        current = identity(EVIDENCE / name)
        selected.append(current)
        if current['sha256'] != digest:
            failures.append(current)
    records = json.loads((EVIDENCE / 'INPUTS.json').read_text())['records']
    assert len(records) == 1416
    for record in records:
        try:
            current = identity(Path(record['path']))
            if current['bytes'] != record['bytes'] or current['sha256'] != record['sha256']:
                failures.append({'expected': record, 'actual': current})
        except OSError as error:
            failures.append({'expected': record, 'error': repr(error)})
    tools = [identity(PYTHON)]
    for name in ['verus', 'rust_verify', 'z3']:
        actual = identity(EXECUTABLE / name)
        original = identity(HISTORICAL / 'runtime' / name)
        tools.extend([actual, original])
        if actual['sha256'] != original['sha256'] or not os.access(EXECUTABLE / name, os.X_OK):
            failures.append({'tool_mismatch': name})
    sysroot = Path('/Users/tommyvolk/.rustup/toolchains/1.99.1-aarch64-apple-darwin')
    for name in ['rustc', 'rustdoc']:
        tools.append(identity(sysroot / 'bin' / name))
    initial_path = ROOT / 'authentication-initial.json'
    if initial_path.exists():
        initial_tools = {tool['path']: tool for tool in json.loads(initial_path.read_text())['tools']}
        for tool in tools:
            initial_tool = initial_tools.get(tool['path'])
            if initial_tool is None or initial_tool['sha256'] != tool['sha256'] or initial_tool['bytes'] != tool['bytes'] or initial_tool['mode'] != tool['mode']:
                failures.append({'tool_changed_since_entry': tool})
    providers = [identity(HISTORICAL / 'artifacts' / filename) for crate in CRATES for filename in [crate + '.vir', 'lib' + crate + '.rlib']]
    for name, digest in SHARED_HASHES.items():
        for directory in [SHARED, ROOT / 'modules']:
            current = identity(directory / name)
            if current['sha256'] != digest:
                failures.append({'shared_mismatch': current})
    current_resources = resources()
    save(destination, {'utc': utc(), 'records': len(records), 'matches': len(records) - sum('expected' in failure for failure in failures), 'failures': failures, 'selected': selected, 'tools': tools, 'providers': providers, 'resources': current_resources})
    assert not failures
    assert current_resources['within_limits']

def run(label, source):
    ledger = ROOT / 'APPLICATIONS.json'
    charges = json.loads(ledger.read_text()) if ledger.exists() else []
    assert len(charges) < 16
    assert time.time() + 95 < DEADLINE
    directory = ROOT / ('attempt-%02d-%s' % (len(charges) + 1, label))
    directory.mkdir()
    export = directory / 'candidate.vir'
    assert not export.exists()
    charges.append({'number': len(charges) + 1, 'label': label, 'directory': str(directory), 'charged': True, 'utc': utc()})
    save(ledger, charges)
    status = None
    timed_out = False
    interrupted = False
    error_text = None
    process = None
    started = time.monotonic()
    source_before = identity(source)
    closure = source_closure(source)
    scope = [identity(path) for path in closure]
    (directory / 'source-snapshot.rs').write_bytes(source.read_bytes())
    for path in closure:
        destination = directory / 'source-scope' / path.relative_to(ROOT)
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(path.read_bytes())
    save(directory / 'source-scope.json', scope)
    baseline = json.loads(Path('/private/tmp/redb-header-recovery111-20261108T051418Z/parent-check-02-shared-contract/invocation.json').read_text())
    environment = {name: value.replace(baseline['cwd'], str(directory)) for name, value in baseline['environment'].items()}
    environment.pop('VARGO_TARGET_DIR', None)
    environment['VERUS_ROOT'] = str(HISTORICAL / 'runtime')
    environment['VERUS_Z3_PATH'] = str(EXECUTABLE / 'z3')
    argv = [str(EXECUTABLE / 'verus'), '--sysroot', '/Users/tommyvolk/.rustup/toolchains/1.99.1-aarch64-apple-darwin', '--edition=2024', '--target', 'aarch64-apple-darwin', '--crate-type=lib', '--crate-name', 'recovery_product111', '--no-cheating', '--output-json', '--num-threads', '1', '--triggers-mode', 'silent', '--multiple-errors', '8', '--rlimit', '30', '-C', 'debug-assertions=no']
    for crate in CRATES:
        argv.extend(['--extern', '%s=%s' % (crate, HISTORICAL / 'artifacts' / ('lib' + crate + '.rlib')), '--import', '%s=%s' % (crate, HISTORICAL / 'artifacts' / (crate + '.vir'))])
    argv.extend(['-L', 'dependency=' + str(HISTORICAL / 'artifacts'), '--export', str(export), str(source)])
    save(directory / 'invocation.json', {'utc': utc(), 'argv': argv, 'environment': environment, 'cwd': str(directory), 'source_scope': scope, 'runner': identity(Path(__file__)), 'export_path': str(export), 'export_fresh_absent': not export.exists(), 'timeout_seconds': 90})
    try:
        authentication(directory / 'authentication-entry.json')
        for name in ['CARGO_HOME', 'CARGO_TARGET_DIR', 'HOME', 'RUSTUP_HOME', 'TEMP', 'TMP', 'TMPDIR', 'XDG_CACHE_HOME', 'XDG_CONFIG_HOME', 'XDG_DATA_HOME', 'XDG_STATE_HOME', 'VERUS_INFER_CACHE']:
            Path(environment[name]).mkdir(parents=True, exist_ok=True)
        authentication(directory / 'authentication-preexecution.json')
        with (directory / 'stdout.txt').open('wb') as stdout, (directory / 'stderr.txt').open('wb') as stderr:
            process = subprocess.Popen(argv, cwd=directory, env=environment, stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr, start_new_session=True)
            try:
                status = process.wait(timeout=90)
            except BaseException as error:
                timed_out = isinstance(error, subprocess.TimeoutExpired)
                interrupted = not timed_out
                os.killpg(process.pid, signal.SIGKILL)
                status = process.wait()
                error_text = repr(error)
    except BaseException as error:
        error_text = repr(error)
        if process is not None and process.poll() is None:
            os.killpg(process.pid, signal.SIGKILL)
            status = process.wait()
    finally:
        try:
            authentication(directory / 'authentication-exit.json')
        except BaseException as error:
            error_text = (error_text or '') + '; exit authentication: ' + repr(error)
        try:
            output = json.loads((directory / 'stdout.txt').read_text())
        except (OSError, ValueError, UnicodeError):
            output = {}
        result = {'utc': utc(), 'status': status, 'timed_out': timed_out, 'interrupted': interrupted, 'error': error_text, 'completed_zero_exit': status == 0 and not timed_out and not interrupted and error_text is None, 'elapsed_seconds': time.monotonic() - started, 'verification': output.get('verification-results', {}), 'export_path': str(export), 'export_present': export.is_file(), 'export': identity(export) if export.is_file() else None, 'source_after': identity(source), 'source_unchanged': identity(source)['sha256'] == source_before['sha256'], 'resources': resources()}
        save(directory / 'result.json', result)
        print(json.dumps(result, indent=2))
    return result

if __name__ == '__main__':
    if sys.argv[1] == 'authenticate':
        authentication(ROOT / sys.argv[2])
        print(json.dumps(resources()))
    else:
        run(sys.argv[1], Path(sys.argv[2]).resolve())
