import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time


ROOT = Path('/private/tmp/redb-header-recovery111-H-20261108T052400Z')
EVIDENCE = Path('/Users/tommyvolk/.t3/worktrees/verus/t3-60978068/evidence/redb-header-recovery111')
HISTORICAL = Path('/private/tmp/verus-crash-consistency94-20261105/native-recovery-reencoding-021')
RUNTIME = Path('/private/tmp/verus-crash-consistency94-20261105/native-leaf-lookup-007/midpoint-runtime-proposal/runtime')
BASELINE = Path('/private/tmp/redb-header-recovery111-20261108T051418Z/parent-check-02-shared-contract/invocation.json')
SHARED = Path('/private/tmp/redb-header-recovery111-20261108T051418Z/shared/contract111.rs')
PYTHON = Path('/Library/Developer/CommandLineTools/Library/Frameworks/Python3.framework/Versions/3.9/bin/python3.9')
FIRST_CLOCK = datetime.datetime(2026, 11, 8, 5, 24, 0, tzinfo=datetime.timezone.utc)
DEADLINE = FIRST_CLOCK + datetime.timedelta(minutes=25)
CRATES = ['pagecodec94', 'rootcodec94', 'hash94', 'hashdispatch013', 'recovery_reencoding021', 'recovery_roundtrip021']


def utc():
    return datetime.datetime.now(datetime.timezone.utc)


def save(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def identity(path):
    digest = hashlib.sha256()
    with path.open('rb') as content:
        while True:
            block = content.read(1024 * 1024)
            if not block:
                break
            digest.update(block)
    status = path.stat()
    return {'path': str(path), 'resolved_path': str(path.resolve()), 'bytes': status.st_size,
            'sha256': digest.hexdigest(), 'mode': oct(status.st_mode & 0o777)}


def resources():
    scratch_bytes = sum(path.stat().st_size for path in ROOT.rglob('*') if path.is_file())
    return {'utc': utc().isoformat(), 'scratch_bytes': scratch_bytes,
            'global_free_bytes': shutil.disk_usage('/private/tmp').free}


def authenticate(destination):
    records = json.loads((EVIDENCE / 'INPUTS.json').read_text())['records']
    assert len(records) == 1416
    checked = []
    failures = []
    for record in records:
        actual = identity(Path(record['path']))
        matches = actual['sha256'] == record['sha256'] and actual['bytes'] == record['bytes']
        checked.append({'expected': record, 'actual': actual, 'matches': matches})
        if not matches:
            failures.append(record['path'])
    frozen = [(EVIDENCE / 'PLAN.md', 'df54d19d300c2393f6ebf40c68e0a3300f7db5856c58dbbb995845c4652fb1db'),
              (EVIDENCE / 'INPUTS.json', '9fae5c40b2e2a49cc50b69533325efd00a0f5c385ff384236a5a234ad54273e3'),
              (SHARED, '839e12109cc0ae0699536cbc7f401dc6d2b7d5f6f44eeccf8c9453bf450277ef')]
    for path, expected in frozen:
        actual = identity(path)
        if actual['sha256'] != expected:
            failures.append(str(path))
        checked.append({'expected_sha256': expected, 'actual': actual})
    pairs = [{suffix: identity(HISTORICAL / 'artifacts' / filename)
              for suffix, filename in [('metadata', crate + '.vir'), ('binary', 'lib' + crate + '.rlib')]}
             for crate in CRATES]
    tools = []
    for name in ['verus', 'rust_verify', 'z3']:
        executable = identity(RUNTIME / name)
        historical = identity(HISTORICAL / 'runtime' / name)
        matches = executable['sha256'] == historical['sha256']
        tools.append({'executable': executable, 'historical': historical, 'byte_identical': matches})
        if not matches or not os.access(RUNTIME / name, os.X_OK):
            failures.append(str(RUNTIME / name))
    sample = resources()
    save(destination, {'utc': utc().isoformat(), 'selected_records': len(records),
                       'matches': len(records) - sum(not item.get('matches', True) for item in checked),
                       'failures': failures, 'records': checked, 'used_complete_pairs': pairs,
                       'tools': tools, 'python': identity(PYTHON), 'runner': identity(Path(__file__)),
                       'baseline': identity(BASELINE), 'resources': sample})
    assert not failures, failures
    assert sample['scratch_bytes'] <= 768 * 1024 * 1024
    assert sample['global_free_bytes'] > 16 * 1024 * 1024 * 1024


def run(label, source):
    ledger = ROOT / 'APPLICATIONS.json'
    charges = json.loads(ledger.read_text()) if ledger.exists() else []
    assert len(charges) < 16
    assert utc() < DEADLINE - datetime.timedelta(seconds=95)
    number = len(charges) + 1
    directory = ROOT / ('attempt-%02d-%s' % (number, label))
    directory.mkdir()
    charges.append({'number': number, 'label': label, 'directory': str(directory),
                    'charged': True, 'utc': utc().isoformat()})
    save(ledger, charges)
    authenticate(directory / 'authentication-entry.json')
    source_snapshot = directory / source.name
    source_snapshot.write_bytes(source.read_bytes())
    baseline = json.loads(BASELINE.read_text())
    environment = {name: value.replace(baseline['cwd'], str(directory))
                   for name, value in baseline['environment'].items()}
    environment.pop('VARGO_TARGET_DIR', None)
    environment['VERUS_ROOT'] = str(HISTORICAL / 'runtime')
    environment['VERUS_Z3_PATH'] = str(RUNTIME / 'z3')
    for name in ['CARGO_HOME', 'CARGO_TARGET_DIR', 'HOME', 'RUSTUP_HOME', 'TEMP', 'TMP', 'TMPDIR',
                 'XDG_CACHE_HOME', 'XDG_CONFIG_HOME', 'XDG_DATA_HOME', 'XDG_STATE_HOME', 'VERUS_INFER_CACHE']:
        Path(environment[name]).mkdir(parents=True, exist_ok=True)
    export = directory / 'candidate.vir'
    assert not export.exists()
    argv = baseline['argv'][:]
    argv[argv.index('--crate-name') + 1] = 'header_staging111'
    argv[argv.index('--export') + 1] = str(export)
    argv[-1] = str(source_snapshot)
    save(directory / 'scope.json', {
        'inherited_boundary': 'EXPLICIT_INHERITED_STD_BOOL_TCB_NOT_RUST_CORE_PROOF',
        'adopted': False, 'new_native_body_credit': False, 'source_module': identity(SHARED),
        'source': identity(source_snapshot), 'imports': CRATES, 'all18': 'OPEN',
        'native_path': 'FAILED', 'native_git': 'UNAVAILABLE', 'compiler_source': 'UNESTABLISHED',
        'single_worker': True, 'no_compile': '--compile' not in argv})
    save(directory / 'invocation.json', {'utc': utc().isoformat(), 'number': number, 'argv': argv,
         'environment': environment, 'cwd': str(directory), 'source': identity(source_snapshot),
         'runner': identity(Path(__file__)), 'timeout_seconds': 90, 'export_fresh_absent': True,
         'export_path': str(export), 'resources': resources()})
    authenticate(directory / 'authentication-preexecution.json')
    process = None
    status = None
    timed_out = False
    error = None
    started = time.monotonic()
    with (directory / 'stdout.txt').open('wb') as stdout, (directory / 'stderr.txt').open('wb') as stderr:
        try:
            process = subprocess.Popen(argv, cwd=directory, env=environment, stdin=subprocess.DEVNULL,
                                       stdout=stdout, stderr=stderr, start_new_session=True)
            status = process.wait(timeout=90)
        except (subprocess.TimeoutExpired, KeyboardInterrupt, OSError) as failure:
            timed_out = isinstance(failure, subprocess.TimeoutExpired)
            error = repr(failure)
            if process is not None:
                os.killpg(process.pid, signal.SIGKILL)
                status = process.wait()
    duration = time.monotonic() - started
    authenticate(directory / 'authentication-exit.json')
    try:
        output = json.loads((directory / 'stdout.txt').read_text())
    except (ValueError, UnicodeError):
        output = {}
    result = {'utc': utc().isoformat(), 'number': number, 'status': status, 'timed_out': timed_out,
              'error': error, 'duration_seconds': duration, 'verification': output.get('verification-results', {}),
              'export_path': str(export), 'export_present': export.is_file(),
              'export': identity(export) if export.is_file() else None,
              'source_after': identity(source_snapshot), 'resources': resources()}
    save(directory / 'result.json', result)
    print(json.dumps(result, indent=2), flush=True)


if __name__ == '__main__':
    if sys.argv[1] == 'authenticate':
        authenticate(ROOT / sys.argv[2])
    else:
        run(sys.argv[1], Path(sys.argv[2]).resolve())
