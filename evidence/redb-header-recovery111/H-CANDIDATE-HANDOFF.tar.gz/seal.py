import difflib
import json
from pathlib import Path
import re

import runner


root = runner.ROOT
source = root / 'staging111.rs'
ledger = json.loads((root / 'APPLICATIONS.json').read_text())
assert len(ledger) == 12
results = [json.loads((Path(charge['directory']) / 'result.json').read_text()) for charge in ledger]
original = root / 'attempt-03-positive-complete/staging111.rs'
restored = root / 'attempt-12-restored-positive/staging111.rs'
assert source.read_bytes() == original.read_bytes() == restored.read_bytes()
assert runner.identity(source)['sha256'] == '0d894c65c6315d1c0de84c6f06a797b9b448d55b9539c542d020502345b6bc31'
assert results[11]['status'] == 0 and results[11]['verification']['verified'] == 9
assert results[10]['status'] == 0 and results[10]['verification']['verified'] == 9
assert results[9]['status'] == 1 and not results[9]['verification']['encountered-vir-error']
negative_stderr = (root / 'attempt-10-mutant-mode-header-position/stderr.txt').read_text()
assert 'assertion failed' in negative_stderr
assert 'header.two_phase_commit == before.two_phase_commit' in negative_stderr
assert 'Resource limit' not in negative_stderr
assert all(not result['timed_out'] and result['duration_seconds'] <= 90 for result in results)
assert runner.utc() < runner.DEADLINE

source_lines = source.read_text().splitlines(keepends=True)
patch = ''.join(difflib.unified_diff([], source_lines, fromfile='/dev/null', tofile='staging111.rs'))
(root / 'FINAL.patch').write_text(patch)
mutant = root / 'attempt-10-mutant-mode-header-position/staging111.rs'
corrected = root / 'attempt-11-corrected-mode-header-position/staging111.rs'
correction = ''.join(difflib.unified_diff(mutant.read_text().splitlines(keepends=True),
                    corrected.read_text().splitlines(keepends=True),
                    fromfile='mutant/staging111.rs', tofile='corrected/staging111.rs'))
(root / 'CONTROL-MUTANT-CORRECTION.patch').write_text(correction)
runner.save(root / 'RESTORATION.json', {'byte_identical': True, 'baseline': runner.identity(original),
            'restored_snapshot': runner.identity(restored), 'final': runner.identity(source)})
runner.authenticate(root / 'authentication-task-exit.json')
authentications = []
samples = [runner.resources()]
for charge, result in zip(ledger, results):
    directory = Path(charge['directory'])
    invocation = json.loads((directory / 'invocation.json').read_text())
    samples.extend([result['resources'], invocation['resources']])
    assert invocation['export_fresh_absent']
    assert invocation['export_path'] == result['export_path']
    assert invocation['environment']['VERUS_ROOT'] == str(runner.HISTORICAL / 'runtime')
    assert 'VARGO_TARGET_DIR' not in invocation['environment']
    assert '--compile' not in invocation['argv']
    for checkpoint in ['entry', 'preexecution', 'exit']:
        path = directory / ('authentication-' + checkpoint + '.json')
        authentication = json.loads(path.read_text())
        assert authentication['matches'] == 1416 and not authentication['failures']
        samples.append(authentication['resources'])
        authentications.append({'path': str(path), 'matches': authentication['matches'],
                               'failures': authentication['failures'], 'utc': authentication['utc']})
        assert len(authentication['used_complete_pairs']) == 6
        assert all(tool['byte_identical'] and tool['historical']['mode'] == '0o400'
                   for tool in authentication['tools'])
runner.save(root / 'AUTHENTICATION-SUMMARY.json', {'application_checkpoints': authentications,
            'application_checkpoint_count': len(authentications), 'selected_records_per_checkpoint': 1416,
            'failures': [], 'final_task_checkpoint': runner.identity(root / 'authentication-task-exit.json')})
runner.save(root / 'ACCOUNTING.json', {
    'first_clock_utc': runner.FIRST_CLOCK.isoformat(), 'seal_utc': runner.utc().isoformat(),
    'elapsed_seconds': (runner.utc() - runner.FIRST_CLOCK).total_seconds(),
    'hard_own_deadline_utc': runner.DEADLINE.isoformat(), 'optional_own_cutoff_utc': '2026-11-08T05:46:00Z',
    'absolute_lane_deadline_utc': '2026-11-08T05:54:18Z', 'charged_applications': len(ledger),
    'charged_cap': 16, 'one_worker': True, 'applications': ledger, 'results': results,
    'maximum_application_seconds': max(result['duration_seconds'] for result in results),
    'boundary_samples_not_continuous_peaks': True, 'resource_samples': samples,
    'observed_scratch_max_bytes': max(sample['scratch_bytes'] for sample in samples),
    'observed_global_free_min_bytes': min(sample['global_free_bytes'] for sample in samples),
    'scratch_cap_bytes': 768 * 1024 * 1024, 'global_free_strict_floor_bytes': 16 * 1024 * 1024 * 1024})
line_map = {match.group(1): number for number, line in enumerate(source_lines, 1)
            for match in [re.match(r'pub (?:open spec |proof )?fn ([a-z_0-9]+)', line)] if match}
files = [runner.identity(path) for path in sorted(root.rglob('*'))
         if path.is_file() and path.name not in ['MANIFEST.json', 'HANDOFF.json']]
runner.save(root / 'MANIFEST.json', {'root': str(root), 'utc': runner.utc().isoformat(),
            'excludes': ['MANIFEST.json', 'HANDOFF.json'], 'files': files})
final_sample = runner.resources()
assert final_sample['scratch_bytes'] <= 768 * 1024 * 1024
assert final_sample['global_free_bytes'] > 16 * 1024 * 1024 * 1024
handoff = {'schema': 'redb-header-recovery111-lane-H-sealed-v1', 'status': 'PASS_CONDITIONAL',
           'utc': runner.utc().isoformat(), 'charged_applications': len(ledger), 'source_lines': line_map,
           'conditional_boundary': 'EXPLICIT_INHERITED_STD_BOOL_TCB_NOT_RUST_CORE_PROOF',
           'adopted': False, 'all18': 'OPEN', 'native_path': 'FAILED', 'native_git': 'UNAVAILABLE',
           'compiler_source_correspondence': 'UNESTABLISHED', 'new_native_body_proof_credit': False,
           'automatic_followups': False, 'resources_at_handoff': final_sample,
           'artifacts': {name: runner.identity(root / name) for name in
                         ['staging111.rs', 'FINAL.patch', 'REPORT.md', 'runner.py', 'seal.py',
                          'MANIFEST.json', 'ACCOUNTING.json', 'AUTHENTICATION-SUMMARY.json',
                          'RESTORATION.json', 'CONTROL-MUTANT-CORRECTION.patch']},
           'final_export': results[11]['export'],
           'negative': str(root / 'attempt-10-mutant-mode-header-position'),
           'corrected': str(root / 'attempt-11-corrected-mode-header-position'),
           'restored': str(root / 'attempt-12-restored-positive')}
runner.save(root / 'HANDOFF.json', handoff)
print(json.dumps({'handoff': runner.identity(root / 'HANDOFF.json'), 'details': handoff}, indent=2))
