#!/usr/bin/env python3
"""Deliberate validation mutations. Always restore and replay original sources."""
import hashlib, importlib.util, json, subprocess, sys
from pathlib import Path
BASE=Path(__file__).resolve().parent
ROOT=BASE/'aleph'
PREFIX=sys.argv[1] if len(sys.argv)>1 else ''
spec=importlib.util.spec_from_file_location('reports','/Users/tommyvolk/Documents/GitHub/verus/source/tools/check_native_adoption.py')
reader=importlib.util.module_from_spec(spec);spec.loader.exec_module(reader)
sig='crypto/src/signature.rs'; validator='consensus/src/units/validator.rs'
source={p:(ROOT/p).read_bytes() for p in [sig,validator]}
session='''        if full_unit.session_id() != self.session_id {
            // NOTE: this implies malicious behavior as the unit's session_id
            // is incompatible with session_id of the message it arrived in.
            return Err(ValidationError::WrongSession(full_unit.clone()));
        }
'''
round_check='''        if full_unit.round() > self.max_round {
            return Err(ValidationError::RoundTooHigh(full_unit.clone()));
        }
'''
parent='''        pre_unit
            .control_hash
            .validate(unit_coord)
            .map_err(|e| ValidationError::ParentValidationFailed(pre_unit.clone(), e))?;'''
cases=[
 ('signature-guard',sig,'if !keychain.verify(self.signable.hash().as_ref(), &self.signature, index) {','if false && !keychain.verify(self.signable.hash().as_ref(), &self.signature, index) {'),
 ('session-guard',validator,'if full_unit.session_id() != self.session_id {','if false && full_unit.session_id() != self.session_id {'),
 ('round-guard',validator,'if full_unit.round() > self.max_round {','if false && full_unit.round() > self.max_round {'),
 ('membership-guard',validator,'if n_members != self.keychain.node_count() {','if false && n_members != self.keychain.node_count() {'),
 ('parent-guard',validator,parent,'        let _ = unit_coord;'),
 ('returned-payload',validator,'ValidationError::WrongSession(full_unit.clone())','ValidationError::WrongSession(FullUnit::new(full_unit.as_pre_unit().clone(), None, self.session_id))'),
 ('session-round-priority',validator,session+round_check,round_check+session),
]
summary={'kind':'deliberate mutations, not original Aleph bug discoveries','cases':[]}
def run(label,packages,flags=()):
 label=PREFIX+label
 cmd=[sys.executable,str(BASE/'run.py'),label,'--packages',*packages,*flags]
 result=subprocess.run(cmd,cwd=ROOT,text=True,capture_output=True)
 out=BASE/'runs'/label
 (out/'controller.stdout').write_text(result.stdout);(out/'controller.stderr').write_text(result.stderr)
 return result.returncode,reader.reports((out/'stdout').read_text()),(out/'stderr').read_text()
failure=None
try:
 code,reports,error=run('healthy-before',['aleph-bft-crypto','aleph-bft-types','aleph-bft'])
 assert code==0 and all(r['verification-results']['success'] for r in reports), 'healthy baseline must verify before mutations'
 for name,path,before,after in cases:
  text=source[path].decode();assert text.count(before)==1,(name,'source anchor')
  try:
   (ROOT/path).write_text(text.replace(before,after))
   packages=['aleph-bft-crypto'] if path==sig else ['aleph-bft']
   code,reports,error=run('mutation-'+name,packages)
   assert code!=0 and len(reports)>=1,(name,'expected ordinary proof failure')
   report=reports[-1];inference=report['verus-infer']
   assert inference['interface_written'] is False
   assert inference['functions'] and all(f['required_checks_passed'] for f in inference['functions']), (name,'helper check failed')
   assert 'panicked at' not in error and 'Verus Infer unsupported:' not in error
   assert any(x in error for x in ['postcondition not satisfied','precondition not satisfied','invariant not satisfied']),error
   summary['cases'].append({'name':name,'path':path,'rejected':True,'helper_checks_healthy':True,'interface_withheld':True,'source_before':hashlib.sha256(source[path]).hexdigest(),'source_mutated':hashlib.sha256((ROOT/path).read_bytes()).hexdigest(),'verification':report['verification-results']})
   print(name+': ordinary proof rejected, helper certificates healthy',flush=True)
  finally:(ROOT/path).write_bytes(source[path])
 for name,flags in [('no-verify',['--no-verify']),('filtered',['--verify-root','--verify-function','validate_unit'])]:
  code,reports,error=run(name,['aleph-bft'],flags)
  assert code!=0,name
  if reports:assert reports[-1]['verus-infer']['interface_written'] is False
  else:assert 'Partial verification must use `cargo verus focus`' in error,error
  summary['cases'].append({'name':name,'rejected':True,'interface_withheld':True,'verifier_started':bool(reports)})
except Exception as error:failure=repr(error)
finally:
 for path,data in source.items():(ROOT/path).write_bytes(data)
 code,reports,error=run('restored-full',['aleph-bft-crypto','aleph-bft-types','aleph-bft'],['--fresh'])
 summary['restored_full_passed']=code==0 and len(reports)==3 and all(r['verification-results']['success'] for r in reports)
 summary['failure']=failure
 (BASE/(PREFIX+'controls-summary.json')).write_text(json.dumps(summary,indent=2)+'\n')
assert failure is None,failure
assert summary['restored_full_passed']
print(json.dumps(summary,indent=2))
