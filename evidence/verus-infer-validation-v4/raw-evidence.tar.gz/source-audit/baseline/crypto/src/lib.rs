//! Utilities for node addressing and message signing.

mod node;
mod signature;
#[cfg(verus_keep_ghost)]
mod native_adoption;

pub use node::{Index, NodeCount, NodeIndex, NodeMap, NodeSubset};
pub use signature::{
    IncompleteMultisignatureError, Indexed, Keychain, MultiKeychain, Multisigned,
    PartialMultisignature, PartiallyMultisigned, Signable, Signature, SignatureError, SignatureSet,
    Signed, UncheckedSigned,
};
