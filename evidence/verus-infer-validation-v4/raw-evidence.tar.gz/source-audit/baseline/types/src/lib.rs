//! Traits that need to be implemented by the user.

mod dataio;
mod network;
mod tasks;

pub use aleph_bft_crypto::{
    IncompleteMultisignatureError, Index, Indexed, Keychain, MultiKeychain, Multisigned, NodeCount,
    NodeIndex, NodeMap, NodeSubset, PartialMultisignature, PartiallyMultisigned, Signable,
    Signature, SignatureError, SignatureSet, Signed, UncheckedSigned,
};
pub use dataio::{DataProvider, FinalizationHandler, OrderedUnit, UnitFinalizationHandler};
pub use network::{Network, Recipient};
pub use tasks::{SpawnHandle, TaskHandle};

use codec::Codec;
#[cfg(verus_keep_ghost)]
use aleph_native_opaque::*;
use vstd::prelude::*;
use std::{fmt::Debug, hash::Hash as StdHash};

/// Data type that we want to order.
#[verus_verify]
pub trait Data: Eq + Clone + Send + Sync + Debug + StdHash + Codec + 'static {}

#[verus_verify]
impl<T> Data for T where T: Eq + Clone + Send + Sync + Debug + StdHash + Codec + 'static {}

/// A hasher, used for creating identifiers for blocks or units.
#[verus_verify]
pub trait Hasher: Eq + Clone + Send + Sync + Debug + 'static {
    /// A hash, as an identifier for a block or unit.
    type Hash: AsRef<[u8]> + Eq + Ord + Copy + Clone + Send + Sync + Debug + StdHash + Codec;

    fn hash(s: &[u8]) -> Self::Hash;
}

/// The number of a session for which the consensus is run.
pub type SessionId = u64;

/// An asynchronous round of the protocol.
pub type Round = u16;
