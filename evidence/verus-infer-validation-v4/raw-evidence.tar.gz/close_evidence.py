#!/usr/bin/env python3
from pathlib import Path
import hashlib, importlib.util, json, subprocess, tarfile
BASE=Path(__file__).resolve().parent;ROOT=BASE/'aleph';MAIN=Path('/Users/tommyvolk/Documents/GitHub/verus')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
spec=importlib.util.spec_from_file_location('reader',MAIN/'source/tools/check_native_adoption.py');reader=importlib.util.module_from_spec(spec);spec.loader.exec_module(reader)
label='accepted-restored-full';run=BASE/'runs'/label;receipt=json.loads((run/'receipt.json').read_text());reports=reader.reports((run/'stdout').read_text())
assert receipt['exit_status']==0 and receipt['sources_unchanged'] and len(reports)==3
assert all(sha(ROOT/p)==h for p,h in receipt['after'].items())
functions=[f for r in reports for f in r['verus-infer']['functions']]
assert len(functions)==39
for f in functions:
 assert f['mode']=='exact' and f['required_checks_passed']
 for name in ['soundness','maximality','exactness']:assert f['proofs'][name]['required'] and f['proofs'][name]['status']=='proved'
assert sum(r['verification-results']['verified'] for r in reports)==204
assert all(r['verification-results']['success'] and r['verification-results']['errors']==0 and r['verus-infer']['interface_written'] for r in reports)
native=json.loads((BASE/'runs/native-tests/receipt.json').read_text())
assert native['exit_status']==0 and native['sources_unchanged'] and native['after']==receipt['after']
import re
outcomes=re.findall(r'test result: ok\. (\d+) passed; 0 failed', (BASE/'runs/native-tests/stdout').read_text())
assert [int(n) for n in outcomes]==[181,11,0,0,1,0]
infer=json.loads((BASE/'engine-validation/infer-final-receipt.json').read_text())
assert infer['exit']==0 and infer['compiler_sha256']==receipt['engine_artifacts']['rust_verify']
assert 'test result: ok. 285 passed; 0 failed;' in (BASE/'engine-validation/infer-final.stdout').read_text()
vstd=json.loads((BASE/'engine-validation/vstd-final-receipt.json').read_text())
assert vstd['exit']==0 and vstd['artifact_hashes']==receipt['engine_artifacts']
assert '2215 verified, 0 errors' in (BASE/'engine-validation/vstd-final.stdout').read_text()
for name,digest in receipt['engine_artifacts'].items():assert sha(MAIN/'source/target-verus/release'/name)==digest
# Recover old proof reports directly from the pinned v3 archive to compare names.
prior=ROOT/'verification/mechanical_v3/raw-evidence.tar.gz'
with tarfile.open(prior) as tar:
 member=next(m for m in tar.getmembers() if m.name.endswith('runs/fixed-restored-full/stdout'))
 oldreports=reader.reports(tar.extractfile(member).read().decode())
oldhelpers={f['function'] for r in oldreports for f in r['verus-infer']['functions']}
newhelpers={f['function'] for f in functions};assert len(oldhelpers)==35 and oldhelpers<=newhelpers
oldchecked={f['function'] for r in oldreports for f in r['verus-infer']['verification_scope']['native_functions'] if f['body_status'] in ['checked_exec_body','checked_proof_body']}
newchecked={f['function'] for r in reports for f in r['verus-infer']['verification_scope']['native_functions'] if f['body_status'] in ['checked_exec_body','checked_proof_body']}
assert oldchecked<=newchecked,(oldchecked-newchecked)
# Accepted v3 workspaces/artifacts are independent of the new fixture.
baseline=json.loads((BASE/'baseline/receipt.json').read_text());oldroot=Path('/private/tmp/verus-mechanical-v3/aleph')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=oldroot,text=True).strip()==baseline['native_head']
assert all(sha(oldroot/p)==h for p,h in baseline['source_hashes'].items())
engine=json.loads((ROOT/'verification/mechanical_v3/engine.json').read_text());engine_root=Path(engine['engine_source'])
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=engine_root,text=True).strip()==engine['engine_commit']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=engine_root,text=True).strip()
assert all(sha(engine_root/'target-verus/release'/n)==h for n,h in engine['artifacts_sha256'].items())
assert sha(engine_root/'z3')==engine['z3_sha256']
controls=json.loads((BASE/'accepted-controls-summary.json').read_text());assert controls['restored_full_passed'] and controls['failure'] is None and len(controls['cases'])==9
for c in controls['cases']:assert c['rejected'] and c['interface_withheld']
for p in json.loads((BASE/'engine-source-receipt.json').read_text())['source_hashes']:
 assert sha(MAIN/p)==json.loads((BASE/'engine-source-receipt.json').read_text())['source_hashes'][p]
audit=json.loads((BASE/'source-audit/source-audit.json').read_text())
assert audit['common_bodies_compared']==179 and not audit['changed_original_bodies']
assert all(not e['requires'] and not e['ensures'] for e in audit['new_assumed_signatures'])
oldentries=json.loads((BASE/'source-audit/baseline-inventory.json').read_text())['entries']
newentries=json.loads((BASE/'source-audit/accepted-inventory.json').read_text())['entries']
def fnkey(e):return (e['file'],e.get('owner',''),e.get('name',''),e.get('mode',''))
a={fnkey(e):e for e in oldentries if e['kind']=='function' and e['has_body']}
b={fnkey(e):e for e in newentries if e['kind']=='function' and e['has_body']}
assert len(a.keys()&b.keys())==179 and all(a[k]['body']==b[k]['body'] for k in a.keys()&b.keys())
summary={'decision':'MET for the finite native unchecked-unit validation milestone','proof_run':label,'verification_results':204,'errors':0,'exact_helpers':39,'required_proofs_individually_checked':117,'checked_exec_bodies':sum(r['verus-infer']['verification_scope']['checked_exec_bodies'] for r in reports),'checked_proof_bodies':sum(r['verus-infer']['verification_scope']['checked_proof_bodies'] for r in reports),'prior_v3_helpers_retained':len(oldhelpers),'prior_v3_checked_items_retained':len(oldchecked),'original_bodies_unchanged':179,'additional_serializer_exclusions':0,'mutation_cases':7,'publication_controls':2,'restored_sources_match_fresh_proof':True,'v3_native_tracked_files_unchanged':len(baseline['source_hashes']),'v3_engine_clean':True,'v3_engine_artifacts_unchanged':len(engine['artifacts_sha256'])+1,'native_unit_tests':192,'native_doctests':1,'inference_regression_tests':285,'vstd_verified':2215,'metadata_schema':38,'inference_policy':50,'candidate_cache':56,'new_inferred_helpers':sorted(newhelpers-oldhelpers),'source_hashes':receipt['after'],'engine_artifacts':receipt['engine_artifacts']}
summary['native_implementation_commit']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
summary['engine_implementation_commit']=subprocess.check_output(['git','rev-parse','5929d1db8'],cwd=MAIN,text=True).strip()
summary['native_worktree_clean']=not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True).strip()
assert summary['native_worktree_clean']
(BASE/'closure-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k not in ['source_hashes','engine_artifacts']},indent=2))
