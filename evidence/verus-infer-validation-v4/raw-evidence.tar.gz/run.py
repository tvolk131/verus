#!/usr/bin/env python3
import argparse,hashlib,json,os,subprocess,time
from pathlib import Path
BASE=Path(__file__).resolve().parent
ROOT=BASE/'aleph'
ENGINE=Path('/Users/tommyvolk/Documents/GitHub/verus/source')
p=argparse.ArgumentParser();p.add_argument('label');p.add_argument('--native',action='store_true');p.add_argument('--fresh',action='store_true');p.add_argument('--packages',nargs='+',default=['aleph-bft-crypto']);a,flags=p.parse_known_args()
out=BASE/'runs'/a.label;out.mkdir(parents=True,exist_ok=False)
env=dict(os.environ)
for k in ['RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','CARGO_BUILD_TARGET','VERUS_INFER_CACHE']:env.pop(k,None)
env.update(RUSTUP_TOOLCHAIN='1.85.1' if a.native else '1.99.1',CARGO_TARGET_DIR=str(BASE/(('native-target' if a.native else 'proof-target-v50')+('-'+a.label if a.fresh else ''))),VERUS_Z3_PATH=str(ENGINE/'z3'),VERUS_INFER_CACHE=str(BASE/'candidate-cache'))
env['PATH']=str(ENGINE/'target-verus/release')+os.pathsep+env.get('PATH','')
if a.native:env['CARGO_ENCODED_RUSTFLAGS']=''
patch='patch.crates-io.vstd.path='+json.dumps(str(ENGINE/'vstd'))
cmd=['cargo']+(['test'] if a.native else ['verus','verify'])+['--config',patch,'--offline','--locked']
for package in a.packages:cmd+=['-p',package]
if not a.native:cmd+=['--fwd-verus-args-to','roots','--','--infer-goals','--no-cheating','--output-json']+flags
def fingerprint():
 return {str(f.relative_to(ROOT)):hashlib.sha256(f.read_bytes()).hexdigest() for f in [*ROOT.glob('*/src/**/*.rs'),*ROOT.glob('*/Cargo.toml'),ROOT/'Cargo.toml',ROOT/'Cargo.lock',*(ROOT/'verification/native_adoption_v2_replay/opaque').glob('src/*.rs')]}
r={'argv':cmd,'cwd':str(ROOT),'environment':{k:env[k] for k in ['RUSTUP_TOOLCHAIN','CARGO_TARGET_DIR','VERUS_Z3_PATH','VERUS_INFER_CACHE']},'before':fingerprint(),'engine_artifacts':{name:hashlib.sha256((ENGINE/'target-verus/release'/name).read_bytes()).hexdigest() for name in ['rust_verify','verus','cargo-verus','vstd.vir','libvstd.rlib']},'runner_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(out/'receipt-start.json').write_text(json.dumps(r,indent=2)+'\n');started=time.monotonic()
with (out/'stdout').open('w') as stdout,(out/'stderr').open('w') as stderr:result=subprocess.run(cmd,cwd=ROOT,env=env,stdout=stdout,stderr=stderr)
r.update(exit_status=result.returncode,seconds=time.monotonic()-started,after=fingerprint());r['sources_unchanged']=r['before']==r['after'];(out/'receipt.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({'label':a.label,'exit':result.returncode,'seconds':r['seconds'],'sources_unchanged':r['sources_unchanged']}))
lines=(out/'stderr').read_text().splitlines()
for i,line in enumerate(lines):
 if line.startswith('error'):print('\n'.join(lines[max(0,i-1):i+14]))
raise SystemExit(result.returncode)
