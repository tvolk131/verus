#!/usr/bin/env python3
"""Source mutations and publication controls over this replay's actual packages."""
import difflib, hashlib, json, subprocess, sys, argparse
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]; OUT=Path(__file__).resolve().parent
PKGS=['--packages','aleph-bft-crypto','aleph-bft-types','aleph-bft']
parser=argparse.ArgumentParser();parser.add_argument('--prefix',default='');args=parser.parse_args()

def reports(label):
 s=(OUT/'runs'/label/'stdout').read_text(); dec=json.JSONDecoder(); result=[]; p=0
 while (b:=s.find('{',p))>=0:
  try:o,n=dec.raw_decode(s[b:]);p=b+n
  except ValueError:p=b+1;continue
  if isinstance(o,dict) and 'verus-infer' in o:result.append(o)
 return result

def run(label,flags=(),rebuild=True):
 label=args.prefix+label
 cmd=[sys.executable,str(OUT/'run.py'),label]+(['--rebuild'] if rebuild else [])+PKGS+(['--',*flags] if flags else [])
 p=subprocess.run(cmd,cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
 print(p.stdout,flush=True)
 rr=reports(label); summary=dict(label=label,argv=cmd,exit=p.returncode,reports=[])
 for r in rr:
  i=r['verus-infer']; summary['reports'].append(dict(status=i['status'],crate_success=i['crate_success'],interface_written=i['interface_written'],exact_helpers=len(i['functions']),healthy_helpers=sum(f['required_checks_passed'] for f in i['functions']),checked_exec_bodies=i['verification_scope']['checked_exec_bodies']))
 summary['vir_artifacts']={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in Path('/private/tmp/aleph-proof-v2-replay-target').rglob('libaleph_bft*.vir')}
 return summary

cases=[
 ('quorum','crypto/src/node.rs','(*self * 2) / 3 + NodeCount(1)','(*self * 2) / 4 + NodeCount(1)'),
 ('round_guard','consensus/src/creation/collector.rs','if round >= self.for_round {','if round > self.for_round {'),
 ('replay_update','consensus/src/creation/collector.rs','Some((_, r)) if *r < round =>','Some((_, r)) if *r <= round =>'),
 ('quorum_selection','consensus/src/creation/collector.rs','if self.direct_parents < self.candidates.size().consensus_threshold() {','if self.direct_parents <= self.candidates.size().consensus_threshold() {'),
 ('selection_error_order','consensus/src/creation/collector.rs',
 '''        if self.direct_parents < self.candidates.size().consensus_threshold() {
            return Err(ConstraintError::NotEnoughParents);
        }
        match self.candidates.get(node_id) {
            Some((_, r)) if *r == self.for_round - 1 => Ok(&self.candidates),
            _ => Err(ConstraintError::MissingOwnParent),
        }''',
 '''        match self.candidates.get(node_id) {
            Some((_, r)) if *r == self.for_round - 1 => {},
            _ => return Err(ConstraintError::MissingOwnParent),
        }
        if self.direct_parents < self.candidates.size().consensus_threshold() {
            return Err(ConstraintError::NotEnoughParents);
        }
        Ok(&self.candidates)'''),
 ('metadata_error_order','consensus/src/units/control_hash.rs',
 '''        self.unit_creator_is_descendant_of_previous_unit(unit_coord)?;
        self.previous_round_have_enough_parents(unit_coord.round)?;''',
 '''        self.previous_round_have_enough_parents(unit_coord.round)?;
        self.unit_creator_is_descendant_of_previous_unit(unit_coord)?;'''),
 ('hash_error_payload','consensus/src/units/control_hash.rs',
 '''                self.combined_hash,
                recalculated_control_hash,''',
 '''                recalculated_control_hash,
                self.combined_hash,'''),
 ('metadata_projection','consensus/src/units/control_hash.rs','parents_with_rounds.insert(parent_index, *parent_round);','parents_with_rounds.insert(parent_index, 0);'),
 ('creation_coordinates','consensus/src/creation/creator.rs','Ok(PreUnit::new(self.node_id, round, control_hash))','Ok(PreUnit::new(self.node_id, 0, control_hash))'),
 ('creation_history','consensus/src/creation/creator.rs','.get(usize::from(prev_round))','.get(usize::from(round))'),
]
results=[]
try:
 results.append(run('repeat-full'))
 assert results[-1]['exit']==0
 for ix,(label,file,before,after) in enumerate(cases):
  path=ROOT/file; original=path.read_text(); assert original.count(before)==1,(label,original.count(before))
  mutated=original.replace(before,after)
  patch=''.join(difflib.unified_diff(original.splitlines(True),mutated.splitlines(True),fromfile=file,tofile=file))
  (OUT/'mutations').mkdir(exist_ok=True);(OUT/'mutations'/f'{label}.patch').write_text(patch)
  try:
   path.write_text(mutated)
   r=run('mutation-'+label,rebuild=ix!=0)
   r.update(source=file,mutation_sha256=hashlib.sha256(patch.encode()).hexdigest())
   results.append(r); assert r['exit']!=0,label
   assert not any(x['interface_written'] and not x['crate_success'] for x in r['reports'])
  finally:path.write_text(original)
  (OUT/(args.prefix+'controls-summary.json')).write_text(json.dumps(results,indent=2)+'\n')
 results.append(run('no-verify',flags=['--no-verify']))
 assert results[-1]['exit']!=0
 results.append(run('filtered',flags=['--verify-root','--verify-function','map_size']))
 assert results[-1]['exit']!=0
 results.append(run('restored-full'))
 assert results[-1]['exit']==0
finally:
 (OUT/(args.prefix+'controls-summary.json')).write_text(json.dumps(results,indent=2)+'\n')
print('All mutation and publication controls completed',flush=True)
