#!/usr/bin/env python3
"""Reconcile the compiled native scope with this author's semantic inventory."""
import argparse, collections, hashlib, json
from pathlib import Path
OUT=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--run',default='final-restored-full');a=p.parse_args()
s=(OUT/'runs'/a.run/'stdout').read_text();decoder=json.JSONDecoder();reports=[];cursor=0
while (b:=s.find('{',cursor))>=0:
 try:o,n=decoder.raw_decode(s[b:]);cursor=b+n
 except ValueError:cursor=b+1;continue
 if isinstance(o,dict) and 'verus-infer' in o:reports.append(o)
summary=[];functions=[];certificates=[]
for index,report in enumerate(reports):
 i=report['verus-infer'];scope=i['verification_scope']
 package=['aleph-bft-crypto','aleph-bft-types','aleph-bft'][index]
 summary.append(dict(package=package,verification=report['verification-results'],status=i['status'],interface_written=i['interface_written'],exact_helpers=len(i['functions']),obligations=sum(len(f['proofs']) for f in i['functions']),native_functions=len(scope['native_functions']),native_statuses=dict(collections.Counter(f['body_status'] for f in scope['native_functions'])),checked_exec_bodies=scope['checked_exec_bodies'],checked_proof_bodies=scope['checked_proof_bodies'],assistance={k:i[k] for k in ['factory_assistance','pointwise_assistance','growth_loop_assistance','range_loop_assistance','mutable_selector_assistance','goal_assistance']}))
 for f in i['functions']:
  assert f['mode']=='exact' and f['required_checks_passed']
  assert all(f['proofs'][p]['required'] and f['proofs'][p]['status']=='proved' for p in ['soundness','maximality','exactness'])
  certificates.append(dict(package=package,**f))
 for f in scope['native_functions']:
  if f['body_status']=='checked_exec_body':
   if f['automatically_derived']:meaning='actual native derive implementation checked against its selected semantic interface'
   elif 'native_adoption' in f['rust_function'] or '_goal' in f['rust_function'] or 'policy_goal' in f['rust_function'] or any(x in f['rust_function'] for x in ['selection_policy','initial_valid']):meaning='universal application or input-coverage goal over the native APIs'
   elif any(x in f['rust_function'] for x in ['try_','fill_prefix','observe_valid','add_unit_observed','validate_eligible']):meaning='additive checked semantic API; its body and pre/postconditions are verified'
   elif 'project_parent_rounds' in f['rust_function'] or 'initialize_collectors_through' in f['rust_function'] or '::observe' in f['rust_function']:meaning='production helper extracted from original executable logic; required native path calls this checked body'
   else:meaning='native implementation checked directly (possibly with documented semantics-preserving edits)'
  elif f['body_status']=='checked_proof_body':meaning='checked generic or representation law; no executable implementation is assumed'
  elif f['body_status']=='specification_definition_or_declaration':meaning='author-supplied mathematical vocabulary or selected semantic interface; see authored-inputs.json and report.md'
  elif f['body_status']=='interface_without_checked_body':meaning='trait interface declaration, not evidence of an implementation; opaque Hasher hash or conditional Unit observation interface'
  elif not f['selected']:meaning='outside this finite slice or an explicit unused-derive exclusion; supplies no callable checked contract'
  else:meaning='selected compiler/type/marker item without translated executable body; not counted as checked executable code'
  functions.append(dict(package=package,semantic_classification=meaning,**f))
(OUT/'proof-summary.json').write_text(json.dumps(dict(run=a.run,packages=summary,exact_helpers=len(certificates),required_precision_obligations=3*len(certificates),checked_exec_bodies=sum(x['checked_exec_bodies'] for x in summary),checked_proof_bodies=sum(x['checked_proof_bodies'] for x in summary)),indent=2)+'\n')
(OUT/'function-inventory.json').write_text(json.dumps(functions,indent=2)+'\n')
(OUT/'helper-certificates.json').write_text(json.dumps(certificates,indent=2)+'\n')
print(json.dumps(dict(exact_helpers=len(certificates),checked_exec_bodies=sum(x['checked_exec_bodies'] for x in summary),checked_proof_bodies=sum(x['checked_proof_bodies'] for x in summary))))
