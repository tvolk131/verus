//! Approved opaque third-party declarations. No encoding or equality equation.
#![cfg_attr(verus_keep_ghost, feature(sized_hierarchy))]
use vstd::prelude::*;

#[cfg(verus_keep_ghost)]
verus! {
#[verifier::external_trait_specification]
pub trait CodecEncode {
    type ExternalTraitSpecificationFor: codec::Encode;
    fn size_hint(&self) -> usize;
    fn encode_to<T: codec::Output + ?Sized>(&self, dest: &mut T);
    fn encode(&self) -> Vec<u8>;
    fn using_encoded<R, F: FnOnce(&[u8]) -> R>(&self, f: F) -> R
        requires forall|bytes: &[u8]| f.requires((bytes,));
}

#[verifier::external_trait_specification]
pub trait CodecDecode: Sized {
    type ExternalTraitSpecificationFor: codec::Decode;
    fn decode<I: codec::Input>(value: &mut I) -> Result<Self, codec::Error>;
}

#[verifier::external_trait_specification]
pub trait CodecInput {
    type ExternalTraitSpecificationFor: codec::Input;
}
#[verifier::external_trait_specification]
pub trait CodecOutput {
    type ExternalTraitSpecificationFor: codec::Output;
}
#[verifier::external_trait_specification]
pub trait CodecWrapper: core::ops::Deref {
    type ExternalTraitSpecificationFor: codec::WrapperTypeEncode;
}
#[verifier::external_type_specification]
#[verifier::external_body]
pub struct CodecError(codec::Error);

pub assume_specification<D: Into<std::borrow::Cow<'static, str>>>[codec::Error::chain](error: codec::Error, description: D) -> codec::Error;

pub assume_specification<T: codec::Encode + ?Sized, X: codec::WrapperTypeEncode<Target=T>>[<X as codec::Encode>::size_hint](x: &X) -> usize;
pub assume_specification<T: codec::Encode + ?Sized, X: codec::WrapperTypeEncode<Target=T>>[<X as codec::Encode>::encode](x: &X) -> Vec<u8>;
pub assume_specification<T: codec::Encode + ?Sized, X: codec::WrapperTypeEncode<Target=T>, W: codec::Output + ?Sized>[<X as codec::Encode>::encode_to](x: &X, dest: &mut W);

#[verifier::external_trait_specification]
pub trait CodecMarker: codec::Decode + codec::Encode {
    type ExternalTraitSpecificationFor: codec::Codec;
}

#[verifier::external_trait_specification]
pub trait OpaqueAsRef<T: core::marker::PointeeSized>: core::marker::PointeeSized {
    type ExternalTraitSpecificationFor: core::convert::AsRef<T>;
    fn as_ref(&self) -> &T;
}

#[verifier::external_type_specification]
#[verifier::external_body]
pub struct OpaqueRawRwLock(parking_lot::RawRwLock);

#[verifier::external_trait_specification]
pub trait OpaqueRawLock {
    type ExternalTraitSpecificationFor: parking_lot::lock_api::RawRwLock;
    type GuardMarker;
}

#[verifier::external_type_specification]
#[verifier::external_body]
#[verifier::reject_recursive_types(R)]
#[verifier::reject_recursive_types(T)]
pub struct OpaqueRwLock<R, T: ?Sized>(parking_lot::lock_api::RwLock<R, T>);

#[verifier::external_type_specification]
#[verifier::external_body]
#[verifier::reject_recursive_types(R)]
#[verifier::reject_recursive_types(T)]
pub struct OpaqueReadGuard<'a, R: parking_lot::lock_api::RawRwLock, T: ?Sized>(parking_lot::lock_api::RwLockReadGuard<'a, R, T>);

#[verifier::external_type_specification]
#[verifier::external_body]
#[verifier::reject_recursive_types(R)]
#[verifier::reject_recursive_types(T)]
pub struct OpaqueWriteGuard<'a, R: parking_lot::lock_api::RawRwLock, T: ?Sized>(parking_lot::lock_api::RwLockWriteGuard<'a, R, T>);

pub assume_specification<R: parking_lot::lock_api::RawRwLock, T: ?Sized>[parking_lot::lock_api::RwLock::<R, T>::read](lock: &parking_lot::lock_api::RwLock<R, T>)
    -> (result: parking_lot::lock_api::RwLockReadGuard<'_, R, T>);
pub assume_specification<R: parking_lot::lock_api::RawRwLock, T: ?Sized>[parking_lot::lock_api::RwLock::<R, T>::write](lock: &parking_lot::lock_api::RwLock<R, T>)
    -> (result: parking_lot::lock_api::RwLockWriteGuard<'_, R, T>);
pub assume_specification<'a, 'g, R: parking_lot::lock_api::RawRwLock + 'a, T: ?Sized + 'a>[<parking_lot::lock_api::RwLockReadGuard<'a, R, T> as core::ops::Deref>::deref](guard: &'g parking_lot::lock_api::RwLockReadGuard<'a, R, T>) -> (result: &'g T);
pub assume_specification<'a, 'g, R: parking_lot::lock_api::RawRwLock + 'a, T: ?Sized + 'a>[<parking_lot::lock_api::RwLockWriteGuard<'a, R, T> as core::ops::Deref>::deref](guard: &'g parking_lot::lock_api::RwLockWriteGuard<'a, R, T>) -> (result: &'g T);
pub assume_specification<'a, 'g, R: parking_lot::lock_api::RawRwLock + 'a, T: ?Sized + 'a>[<parking_lot::lock_api::RwLockWriteGuard<'a, R, T> as core::ops::DerefMut>::deref_mut](guard: &'g mut parking_lot::lock_api::RwLockWriteGuard<'a, R, T>) -> (result: &'g mut T);
pub assume_specification<R: parking_lot::lock_api::RawRwLock, T>[parking_lot::lock_api::RwLock::<R, T>::new](value: T) -> parking_lot::lock_api::RwLock<R, T>;
pub assume_specification<R: parking_lot::lock_api::RawRwLock, T: ?Sized>[parking_lot::lock_api::RwLock::<R, T>::try_read](lock: &parking_lot::lock_api::RwLock<R, T>) -> Option<parking_lot::lock_api::RwLockReadGuard<'_, R, T>>;

}
