# Explicit generated-implementation exclusions

These attributes select proof scope, supply no assumed callable contract, and do not remove native Rust implementations. No checked call uses an excluded implementation's contract. The scope JSON separately inventories all unannotated/outside-slice methods.

| Type | Excluded implementations | Checked-path reason |
|---|---|---|
| NodeIndex | Hash, Debug, Default | Formatting/hashing/default construction unused by checked scalar/map/creation logic |
| NodeCount | Sub, SubAssign, Sum, Hash, Debug, Default | Native threshold uses checked Mul, Div and real Add; raw counter update uses primitive field addition. Actual AddAssign remains checked against its ordinary arithmetic interface. |
| NodeMap | Eq, PartialEq, Hash, Debug, Default, Decode, Encode, From | Checked content comparisons use logical sequence equality; construction uses with_size, not From/default. Serializers have no usable checked contract. Actual Clone remains checked. |
| CreationInputError | Debug, Eq, PartialEq | Checked policies use logical variant/payload equality, not executable comparison/formatting |
| ConstraintError | Eq, Error, Display, Debug, PartialEq | Enum, selectors and error order checked; generated formatting/std Error left native and unverified under the explicit authorization |
| UnitsCollector | Clone | The native path advances by cloning its NodeMap field directly; it never calls the whole-collector Clone derive |
| ControlHash::Error | Eq, Debug, PartialEq | Checked error policies inspect logical tags/payloads, including conditional hash eq_spec; executable enum Eq unused |
| ControlHash | Clone, Eq, PartialEq, Hash, Debug, Decode, Encode | No checked creation/validation operation clones or compares the entire metadata value executably; codec behavior is opaque |
| UnitCoord | Eq, PartialEq, Hash, Debug, Default, Encode, Decode | Construction/accessors and original Copy/Clone checked; logical coordinate equality used in goals |
| PreUnit | Clone, Eq, PartialEq, Hash, Debug, Decode, Encode | Constructor/accessors forward complete values; no checked clone/codec/comparison call on PreUnit |
| FullUnit | Debug, Decode, Encode, Eq, PartialEq, Hash | Actual Unit impl checked without executable FullUnit comparison/serialization contracts. The hand-written Clone is unannotated/outside slice and is not called by checked methods. |

The required hash calls invoke codec's **opaque default `Encode::using_encoded` interface**, not a checked first-party serializer contract. The native library implementation can execute generated Encode methods behind that boundary; those implementations are not claimed unused at runtime or verified. The permitted model gives the result no encoding or return relation whatsoever, so none of their behavior is assumed or used to establish a goal. This is the explicit codec trust cut, not a trusted first-party encoding equation. In particular no encode/decode/hash agreement is claimed.

`crypto/src/signature.rs` is unchanged. There is **no** Signed or UncheckedSigned serializer exclusion. No checked Signed Unit delegation, signature verification, Keychain call or outer signed-unit validator is claimed. Those native functions are reported outside the selected scope.
