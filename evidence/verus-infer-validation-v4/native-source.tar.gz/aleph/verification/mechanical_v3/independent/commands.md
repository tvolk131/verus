# Reproducible audit commands

All commands below write only into a new audit-owned directory. Do not rerun with an existing run label, modify the pinned engine/artifacts, or run the proposal's mutation controller.

The actual audit root is `/private/tmp/verus-mechanical-v3/independent-audit/20261030T154530Z`; the commands and hashes used for successful proof/native runs are in their receipts. To replay the retained audit runner in a fresh root, copy `run.py` and `generic-direct.py` there first. Each derives its output directory from its own file location.

```sh
df -h /private/tmp
python3 /path/to/new-audit-root/run.py proof
python3 /path/to/new-audit-root/run.py native
```

The runner's proof argv, executed from `/private/tmp/verus-mechanical-v3/aleph`, is:

```sh
cargo verus verify \
  --config 'patch.crates-io.vstd.path="/private/tmp/verus-mechanical-v3/engine/verus/source/vstd"' \
  --offline --locked \
  -p aleph-bft-crypto -p aleph-bft-types -p aleph-bft \
  --fwd-verus-args-to roots -- --infer-goals --no-cheating --output-json
```

The runner puts the fixed `source/target-verus/release` first on PATH, sets RUSTUP_TOOLCHAIN=1.99.1, VERUS_Z3_PATH to fixed source/z3, and fresh CARGO_TARGET_DIR/VERUS_INFER_CACHE paths below its own audit directory. Native argv changes `verus verify` to `test`, uses Rust 1.85.1, an independent native target/cache, empty CARGO_ENCODED_RUSTFLAGS, and omits Verus flags. Full exact argv and sanitized influencing environment are recorded.

Build the fixed generic source parser, without rebuilding engine artifacts (run from fixed engine repository root):

```sh
env RUSTUP_TOOLCHAIN=1.99.1 \
  CARGO_TARGET_DIR=/path/to/new-audit-root/inventory-target \
  CARGO_ENCODED_RUSTFLAGS='' \
  cargo build --release --offline --locked \
  --manifest-path source/tools/adoption_inventory/Cargo.toml
```

Invoke that parser on every `.rs` under the proposal's crypto/src, types/src and consensus/src, plus `verification/native_adoption_v2_replay/opaque/src/lib.rs`. The exact list/argv used here is in inventory-receipt.json. Invoke it separately on the supplied original node, constructor and selector files. Compare each required complete function's parsed `body` string, including full loop and suffix/tail. See original-inputs.json and original-body-checks.json.

Actual retained native expansion command (from proposal root):

```sh
env RUSTUP_TOOLCHAIN=1.99.1 RUSTC_BOOTSTRAP=1 \
  CARGO_TARGET_DIR=/path/to/new-audit-root/expansion-target \
  CARGO_ENCODED_RUSTFLAGS='' \
  cargo rustc \
  --config 'patch.crates-io.vstd.path="/private/tmp/verus-mechanical-v3/engine/verus/source/vstd"' \
  --offline --locked -p aleph-bft-crypto --lib -- -Zunpretty=expanded
```

`RUSTC_BOOTSTRAP=1` is used only for this ordinary Rust inspection of the expansion. It is not used for the application proof or native tests. The generated native AddAssign implementation is retained at crypto-expanded.rs:197.

Run focused fixed-engine generic regressions (from fixed engine repository root):

```sh
python3 source/tools/check_native_adoption.py \
  --verus-source /private/tmp/verus-mechanical-v3/engine/verus/source \
  --output /path/to/new-audit-root/generic-adoption
python3 /path/to/new-audit-root/generic-direct.py
```

The first checks the read-only unrelated native Cargo fixture with fresh audit output. It does not mutate its fixture. The second extracts general test constants from infer_cases/local_folds.rs, infer_growth.rs and infer_cases/derive_assignments.rs into new audit-owned source copies; it executes 17 positive/negative cases and compiles positive crates. Every compiler invocation and expected status/interface absence is recorded in generic-direct/receipts.json.

Evidence integrity: hash raw-evidence.tar.gz against raw-evidence-index.json, verify all 48 extracted member sizes/SHA256s, reconstruct the three stated single-line mutations in memory and compare hashes to their receipt entries. Read restored proof/native evidence and failed publication reports. Do not run `verification/mechanical_v3/controls.py` against the shared proposal.

Before/after integrity procedure: obtain engine/proposal HEAD and porcelain status; hash all git-tracked files and supplied original files; hash the eight artifact paths and Z3 in PINNED_ENGINE.json; compare the frozen-document/pin receipt hashes. The accepted results and baseline hash inventory are in initial-hashes.json and final-integrity-receipt.json.
