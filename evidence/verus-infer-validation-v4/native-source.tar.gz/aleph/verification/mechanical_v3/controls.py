#!/usr/bin/env python3
"""Native semantic mutations, with restoration and full raw evidence."""
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[2]
OUT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('generic_report_reader',
    '/Users/tommyvolk/Documents/GitHub/verus/source/tools/check_native_adoption.py')
reader=importlib.util.module_from_spec(spec);spec.loader.exec_module(reader)
cases=[
 ('counter-step','consensus/src/creation/collector.rs',
  'self.direct_parents += NodeCount(1);','self.direct_parents += NodeCount(2);'),
 ('constructor-projection','consensus/src/units/control_hash.rs',
  'parents_with_rounds.insert(parent_index, *parent_round);',
  'parents_with_rounds.insert(parent_index, 0);'),
 ('selected-coordinate','consensus/src/creation/creator.rs',
  '&mut self.round_collectors[round as usize]', '&mut self.round_collectors[0]'),
]
summary={'kind':'implementation mutations, not original Aleph bug discoveries','cases':[]}
prefix=sys.argv[1] if len(sys.argv)>1 else ''
baseline={path:(ROOT/path).read_bytes() for _,path,_,_ in cases}
def run(label,packages,flags=()):
    label=prefix+label
    cmd=[sys.executable,str(OUT/'run.py'),label,'--rebuild','--packages',*packages]
    if flags:cmd+=['--',*flags]
    result=subprocess.run(cmd,cwd=ROOT,text=True,capture_output=True)
    run_dir=OUT/'runs'/label
    parsed=reader.reports((run_dir/'stdout').read_text())
    (run_dir/'controller.stdout').write_text(result.stdout)
    (run_dir/'controller.stderr').write_text(result.stderr)
    return result.returncode,parsed,(run_dir/'stderr').read_text()
failure=None
try:
    for name,path,before,after in cases:
        source=baseline[path].decode();assert source.count(before)==1,(name,'source anchor')
        try:
            (ROOT/path).write_text(source.replace(before,after))
            code,reports,error=run('mutation-'+name,['aleph-bft'])
            assert code!=0 and len(reports)==1,(name,'expected proof failure')
            report=reports[0];inference=report['verus-infer']
            assert inference['interface_written'] is False
            assert inference['functions'] and all(f['required_checks_passed'] for f in inference['functions'])
            assert 'panicked at' not in error and 'Verus Infer unsupported:' not in error
            assert any(x in error for x in ['postcondition not satisfied','precondition not satisfied','invariant not satisfied'])
            summary['cases'].append({'name':name,'path':path,'rejected':True,
                'helper_checks_healthy':True,'interface_withheld':True,
                'verification':report['verification-results']})
        finally:
            (ROOT/path).write_bytes(baseline[path])
    for name,flags in [('no-verify',['--no-verify']),('filtered',['--verify-root','--verify-function','create_unit'])]:
        code,reports,error=run(name,['aleph-bft'],flags)
        assert code!=0,name
        if reports:
            assert reports[0]['verus-infer']['interface_written'] is False
        else:
            assert 'Partial verification must use `cargo verus focus`' in error
        summary['cases'].append({'name':name,'rejected':True,'interface_withheld':True})
except Exception as e:
    failure=repr(e)
finally:
    for path,source in baseline.items():(ROOT/path).write_bytes(source)
    code,reports,error=run('restored-full',['aleph-bft-crypto','aleph-bft-types','aleph-bft'])
    summary['restored_full_passed']=code==0 and len(reports)==3 and all(
        r['verification-results']['success'] for r in reports)
    summary['failure']=failure
    (OUT/(prefix+'controls-summary.json')).write_text(json.dumps(summary,indent=2)+'\n')
assert failure is None,failure
assert summary['restored_full_passed']
print(json.dumps(summary,indent=2))
