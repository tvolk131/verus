#!/usr/bin/env python3
"""Offline fixed-engine runner. Keeps exact commands, logs and source fingerprints."""
import argparse, hashlib, json, os, subprocess, time
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
ENGINE = Path('/private/tmp/verus-mechanical-v3/engine/verus/source')
p=argparse.ArgumentParser(); p.add_argument('label'); p.add_argument('--native', action='store_true'); p.add_argument('--unlock',action='store_true'); p.add_argument('--rebuild',action='store_true'); p.add_argument('--packages', nargs='+', default=['aleph-bft-crypto']); a, flags=p.parse_known_args(); a.flags=flags[1:] if flags[:1] == ['--'] else flags
patch='patch.crates-io.vstd.path='+json.dumps(str(ENGINE/'vstd'))
env=dict(os.environ, RUSTUP_TOOLCHAIN='1.85.1' if a.native else '1.99.1', CARGO_TARGET_DIR='/private/tmp/verus-mechanical-v3/native-target' if a.native else '/private/tmp/verus-mechanical-v3/proof-target', VERUS_Z3_PATH=str(ENGINE/'z3'), VERUS_INFER_CACHE='/private/tmp/verus-mechanical-v3/candidate-cache')
env['PATH']=str(ENGINE/'target-verus/release')+os.pathsep+env.get('PATH','')
if a.native: env['CARGO_ENCODED_RUSTFLAGS']=''
cmd=['cargo']+(['test'] if a.native else ['verus','verify'])+['--config',patch,'--offline']+([] if a.unlock else ['--locked'])
for package in a.packages: cmd+=['-p',package]
cmd+= a.flags if a.native else ['--fwd-verus-args-to','roots','--','--infer-goals','--no-cheating','--output-json']+a.flags
out=OUT/'runs'/a.label;out.mkdir(parents=True,exist_ok=False)
files=[*ROOT.glob('*/src/**/*.rs'),*ROOT.glob('*/Cargo.toml'),ROOT/'Cargo.toml',ROOT/'Cargo.lock',*(ROOT/'verification/native_adoption_v2_replay/opaque').glob('src/*.rs'),ROOT/'verification/native_adoption_v2_replay/opaque/Cargo.toml']
receipt=dict(argv=cmd,cwd=str(ROOT),environment={k:env[k] for k in ['RUSTUP_TOOLCHAIN','CARGO_TARGET_DIR','VERUS_Z3_PATH','VERUS_INFER_CACHE']},sources={str(f.relative_to(ROOT)):hashlib.sha256(f.read_bytes()).hexdigest() for f in files},runner_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
start=time.monotonic()
if a.rebuild:
 clean=['cargo','--config',patch,'clean','--offline']
 for package in a.packages: clean+=['-p',package]
 with (out/'clean.stdout').open('w') as stdout,(out/'clean.stderr').open('w') as stderr:
  cleaned=subprocess.run(clean,cwd=ROOT,env=env,stdout=stdout,stderr=stderr)
 receipt['clean_argv']=clean; receipt['clean_exit_status']=cleaned.returncode
 if cleaned.returncode: raise SystemExit('clean failed')
with (out/'stdout').open('w') as stdout,(out/'stderr').open('w') as stderr:
 result=subprocess.run(cmd,cwd=ROOT,env=env,stdout=stdout,stderr=stderr)
receipt.update(exit_status=result.returncode,seconds=time.monotonic()-start)
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(dict(label=a.label,exit=result.returncode,seconds=receipt['seconds'])))
lines=(out/'stderr').read_text().splitlines()
for i,line in enumerate(lines):
 if line.startswith('error'):
  print('\n'.join(lines[max(0,i-2):i+15]))
if a.native: print((out/'stdout').read_text()[-2000:])
raise SystemExit(result.returncode)
