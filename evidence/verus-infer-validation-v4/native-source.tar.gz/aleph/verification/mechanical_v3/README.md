# Original native patterns: accepted mechanical adoption v3

Status: complete. Parent validation and the fresh-context independent audit pass.
This source restores the original assignment expression, complete ControlHash
constructor and complete growth/mutable-return selector, using general Verus
support at clean fixed engine fbab46ec4. This is a finite extension of the
completed v2 source closure; it does not claim arbitrary Rust support.

Implementation commit: 8b7e0f1. The original unannotated source is pinned at
f35c7bba6d628bcafdf0d65dd471cc6f868ec034. `source-audit.json` records exact parsed
body-token equality for the original constructor and selector. Only four native
source files change from the accepted v2 implementation: 12 additions and 47
deletions. Two extracted helpers and the hand-authored assignment interface are
removed. All nineteen remaining authored spec-function definitions match v2.

The accepted fixed-engine proof is `runs/fixed-restored-full`: 154 verified
results, 35 exact helpers/all 105 required checks, 83 executable bodies and one
generated proof body. The actual derived NodeCount assignment is checked/inferred;
the original constructor and selector are checked ordinary semantic APIs. Lower
result/body counts reflect removal of helpers, not lost application coverage.

The accepted separate native result is `runs/fixed-engine-native-restored`:
181 consensus unit tests, 11 crypto unit tests and one crypto doctest. The earlier
`fixed-engine-native` run is explicitly excluded because native compilation
overlapped source mutation controls, despite succeeding. It is not acceptance
evidence. Development failure logs remain local history; use the named final
receipts and hashes in `parent-summary.json`.

Committed raw evidence is losslessly compressed in `raw-evidence.tar.gz`; its
member paths, sizes and hashes are listed in `raw-evidence-index.json`. Expand
it in this directory to inspect the original reports and source inventory:

```sh
tar -xzf raw-evidence.tar.gz
```

`fixed-controls-summary.json` and the corresponding `runs/fixed-*` logs retain
three deliberate implementation mutations, ordinary proof rejection after
healthy helper checks, failed exports withheld, no-verify/filtered rejection and
a restored full run. These mutations are tests of the specification/verification
connection, not bugs discovered in original Aleph.

Reproduce using unused labels:

```sh
python3 verification/mechanical_v3/run.py proof-again --rebuild --packages aleph-bft-crypto aleph-bft-types aleph-bft
python3 verification/mechanical_v3/run.py native-again --native --rebuild --packages aleph-bft-crypto aleph-bft-types aleph-bft
python3 verification/mechanical_v3/controls.py another-
```

Run mutation controls sequentially with all jobs that read application source.
The runner records commands, source hashes and exit status. `authored-inputs.json`
and `inventory-command.json` complement the compiler's function inventory; parsing
does not certify semantic coverage. Existing six views/two validity predicates,
application behavior and coverage goals and opaque codec/lock/hash boundaries
remain as in the accepted v2 scope. Signed serializer exclusions remain
unauthorized and unapplied. No new trusted behavior,
local supporting proofs, loop annotations or manual triggers are added.

## Independent acceptance

The fresh-context [acceptance report](independent/ACCEPTANCE_REPORT.md) concludes
MET with no blocking objections. On unchanged proposal `53a8917b` and fixed engine
`fbab46ec4`, fresh caches/targets reproduce 154 results, 35 exact helpers/all
105 checks, 83 checked exec bodies and one generated proof body. Separate
same-source native testing passes 192 unit tests and one doctest. Seventeen
direct generic cases and the nine-case Cargo fixture pass their expected
positive/negative outcomes. The auditor reviewed and reconstructed native
mutation source hashes; it did not rerun mutations or the parent's 631-check
engine suite. These distinctions are recorded in `independent-summary.json`.

The report is preserved verbatim. Its raw receipts, source inventory, actual
derive expansion, generic inputs/outputs, certificates and reviewed mutation
records are losslessly archived in `independent/raw-evidence.tar.gz`, with
individual sizes/hashes in `independent/raw-evidence-index.json`. Extract from
`independent/` to resolve the report's relative links. Build targets and candidate
caches are not archived. The archive also preserves the exact launched charter,
brief and compiler pin under `frozen-inputs/`.

The auditor treats the supplied original export's Git provenance as a fixed
input assertion. After its return, the parent separately matched all three
exports/committed references to actual blobs at local Git commit `f35c7bb`;
`original-git-provenance.json` records that witness. It makes no claim about remote
repository provenance and does not change the independent report. All edits
after the audit are evidence/documentation only. The finite scope, authored
semantics and explicit opaque boundaries remain unchanged. Nothing is pushed.
