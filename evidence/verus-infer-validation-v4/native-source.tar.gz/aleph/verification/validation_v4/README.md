# Native unchecked-unit validation v4

Finite milestone complete, October 30, 2026. Native baseline:
`a2de660d5467ce3611584768285b9227a1e2832b`; Verus implementation:
`5929d1db8`. All prior v3 checked items and 35 inferred helpers remain checked.

The original `UncheckedSigned::check`, `Validator::validate_unit` and
`validate_unit_parents` executable bodies are unchanged and now checked. The
returned value retains the actual input signable object and signature. Errors
follow signature, session, maximum round, member count and existing control-hash
priority. Cloned error payloads satisfy the checked clone relation; generic
cloning is not assumed to preserve identity.

`lawful_index` and `lawful_verification` are explicit opt-in semantic interfaces,
false by default. FullUnit proves its index/session observations. An unrelated
checked reference keychain proves accepted/rejected signature paths. This is a
conditional verification-interface theorem, not certification of a cryptographic
implementation or every value constructible through Signed's Decode impl.
Hashing, AsRef and locking retain their opaque result boundaries. Positive-round
arithmetic retains v3's `members <= usize::MAX / 2` domain. Initial hash comparison
retains its actual opaque comparison meaning.

The acceptance replay has 204 verified results, zero errors, 39 exact helpers
with all 117 mandatory certificates proved, and 125 checked executable bodies
plus one existing generated proof body. The universal order goal covers all
branches, including simultaneous faults; a second goal builds a positive-round
unit through the original constructors and proves acceptance. Seven deliberate
semantic mutations fail ordinary application verification while helper
certificates remain healthy. No-verify and filtered publication are rejected.
Restored source passes a fresh full replay. Native tests: 192 unit tests and one
doctest. Verus inference regression tests: 285 passing; vstd: 2,215 verified.

The parsed source comparison finds all 179 comparable original bodies unchanged.
The sole Rust structural refactor splits FullUnit's constructor into a selected
impl block; its body is unchanged. PreUnit and ControlHash Clone exclusions were
removed and their derives checked. No serializer or other exclusion was added.
Signed, UncheckedSigned and SignatureError codec derive bodies are checked
against typed-only codec declarations; no encoding equation is supplied.

Durable evidence, original/accepted syntax inventories, exact commands, full
stdout/stderr, source hashes, assumptions and accepted source archive are in the
Verus repository at `evidence/verus-infer-validation-v4`. The original v3 fixture
and fixed engine were left unchanged. This acceptance was checked locally by the
implementing agent; no new independent-agent audit is claimed. No push was made.
