use vstd::prelude::*;
use crate::units::{ControlHashError, UnitCoord};
use crate::{
    units::{FullUnit, PreUnit, SignedUnit, UncheckedSignedUnit, Unit},
    Data, Hasher, Keychain, NodeCount, NodeIndex, Round, SessionId, Signature, SignatureError,
};
use std::{
    fmt::{Display, Formatter, Result as FmtResult},
    result::Result as StdResult,
};

/// All that can be wrong with a unit except control hash issues.
#[derive(Eq, PartialEq, Debug)]
#[verus_verify]
pub enum ValidationError<H: Hasher, D: Data, S: Signature> {
    WrongSignature(UncheckedSignedUnit<H, D, S>),
    WrongSession(FullUnit<H, D>),
    RoundTooHigh(FullUnit<H, D>),
    WrongNumberOfMembers(PreUnit<H>),
    ParentValidationFailed(PreUnit<H>, ControlHashError<H>),
}

impl<H: Hasher, D: Data, S: Signature> Display for ValidationError<H, D, S> {
    fn fmt(&self, f: &mut Formatter<'_>) -> FmtResult {
        use ValidationError::*;
        match self {
            WrongSignature(usu) => write!(f, "wrongly signed unit: {:?}", usu),
            WrongSession(fu) => write!(f, "unit from wrong session: {:?}", fu),
            RoundTooHigh(fu) => write!(f, "unit with too high round {}: {:?}", fu.round(), fu),
            WrongNumberOfMembers(pu) => write!(
                f,
                "wrong number of members implied by unit {:?}: {:?}",
                pu.n_members(),
                pu
            ),
            ParentValidationFailed(pu, control_hash_error) => write!(
                f,
                "parent validation failed for unit: {:?}. Internal error: {}",
                pu, control_hash_error
            ),
        }
    }
}

#[verus_verify]
impl<H: Hasher, D: Data, S: Signature> From<SignatureError<FullUnit<H, D>, S>>
    for ValidationError<H, D, S>
{
    #[verus_spec(result => ensures match result {
        ValidationError::WrongSignature(unit) => unit@ == se@,
        _ => false,
    },)]
    fn from(se: SignatureError<FullUnit<H, D>, S>) -> Self {
        ValidationError::WrongSignature(se.unchecked)
    }
}

#[derive(Clone, Eq, PartialEq, Debug, Hash)]
#[verus_verify]
pub struct Validator<K: Keychain> {
    session_id: SessionId,
    keychain: K,
    max_round: Round,
}

type Result<H, D, K> =
    StdResult<SignedUnit<H, D, K>, ValidationError<H, D, <K as Keychain>::Signature>>;

impl<K: Keychain> Validator<K> {
    #[verus_infer]
    pub fn new(session_id: SessionId, keychain: K, max_round: Round) -> Self {
        Validator {
            session_id,
            keychain,
            max_round,
        }
    }

    pub fn node_count(&self) -> NodeCount {
        self.keychain.node_count()
    }

    pub fn index(&self) -> NodeIndex {
        self.keychain.index()
    }

    #[verus_spec(result =>
        requires self@.1.lawful_verification(),
            uu@.0@.0@.0 > 0 ==> self@.1.members().0 <= usize::MAX / 2,
        ensures self.validation_policy(uu, result),
    )]
    pub fn validate_unit<H: Hasher, D: Data>(
        &self,
        uu: UncheckedSignedUnit<H, D, K::Signature>,
    ) -> Result<H, D, K> {
        let su = uu.check(&self.keychain)?;
        let full_unit = su.as_signable();
        if full_unit.session_id() != self.session_id {
            // NOTE: this implies malicious behavior as the unit's session_id
            // is incompatible with session_id of the message it arrived in.
            return Err(ValidationError::WrongSession(full_unit.clone()));
        }
        if full_unit.round() > self.max_round {
            return Err(ValidationError::RoundTooHigh(full_unit.clone()));
        }
        self.validate_unit_parents(su)
    }

    #[verus_spec(result =>
        requires self@.1.lawful_verification(),
            su@.0@.0@.0 > 0 ==> (su@.0@.0@.1.0 < self@.1.members().0 && self@.1.members().0 <= usize::MAX / 2),
        ensures self.parent_policy(su, result),
    )]
    fn validate_unit_parents<H: Hasher, D: Data>(
        &self,
        su: SignedUnit<H, D, K>,
    ) -> Result<H, D, K> {
        let pre_unit = su.as_signable().as_pre_unit();
        let n_members = pre_unit.n_members();
        if n_members != self.keychain.node_count() {
            return Err(ValidationError::WrongNumberOfMembers(pre_unit.clone()));
        }
        let unit_coord = UnitCoord::new(pre_unit.round(), pre_unit.creator());
        pre_unit
            .control_hash
            .validate(unit_coord)
            .map_err(|e| ValidationError::ParentValidationFailed(pre_unit.clone(), e))?;
        Ok(su)
    }
}

#[cfg(test)]
mod tests {
    use super::{ValidationError::*, Validator as GenericValidator};
    use crate::{
        units::{
            full_unit_to_unchecked_signed_unit, preunit_to_unchecked_signed_unit,
            random_full_parent_units_up_to, random_unit_with_parents, PreUnit,
            {ControlHash, ControlHashError},
        },
        NodeCount, NodeIndex,
    };
    use aleph_bft_mock::Keychain;
    use codec::{Decode, Encode};

    type Validator = GenericValidator<Keychain>;

    #[test]
    fn validates_initial_unit() {
        let n_members = NodeCount(7);
        let creator_id = NodeIndex(0);
        let session_id = 0;
        let max_round = 2;
        let keychain = Keychain::new(n_members, creator_id);
        let validator = Validator::new(session_id, keychain, max_round);
        let full_unit = random_full_parent_units_up_to(0, n_members, session_id)[0][0].clone();
        let unchecked_unit = full_unit_to_unchecked_signed_unit(full_unit, &keychain);
        let checked_unit = validator
            .validate_unit(unchecked_unit.clone())
            .expect("Unit should validate.");
        assert_eq!(unchecked_unit, checked_unit.into());
    }

    #[test]
    fn detects_wrong_initial_control_hash() {
        let n_members = NodeCount(7);
        let creator_id = NodeIndex(0);
        let session_id = 0;
        let max_round = 2;
        let keychain = Keychain::new(n_members, creator_id);
        let validator = Validator::new(session_id, keychain, max_round);
        let preunit = random_full_parent_units_up_to(0, n_members, session_id)[0][0]
            .as_pre_unit()
            .clone();
        let mut control_hash = preunit.control_hash().clone();
        let encoded = control_hash.encode();
        // first 8 bytes is encoded NodeMap of size 7
        let mut borked_control_hash_bytes = encoded[0..=7].to_vec();
        borked_control_hash_bytes.extend([0u8, 1u8, 0u8, 1u8, 0u8, 1u8, 0u8, 1u8]);
        control_hash = ControlHash::decode(&mut borked_control_hash_bytes.as_slice())
            .expect("should decode correctly");
        let preunit = PreUnit::new(preunit.creator(), preunit.round(), control_hash);
        let unchecked_unit =
            preunit_to_unchecked_signed_unit(preunit.clone(), session_id, &keychain);
        let other_preunit = match validator.validate_unit(unchecked_unit.clone()) {
            Ok(_) => panic!("Validated bad unit."),
            Err(ParentValidationFailed(unit, ControlHashError::RoundZeroBadControlHash(_, _))) => {
                unit
            }
            Err(e) => panic!("Unexpected error from validator: {:?}", e),
        };
        assert_eq!(other_preunit, preunit);
    }

    #[test]
    fn detects_wrong_session_id() {
        let n_members = NodeCount(7);
        let creator_id = NodeIndex(0);
        let session_id = 0;
        let wrong_session_id = 43;
        let max_round = 2;
        let keychain = Keychain::new(n_members, creator_id);
        let validator = Validator::new(session_id, keychain, max_round);
        let full_unit =
            random_full_parent_units_up_to(0, n_members, wrong_session_id)[0][0].clone();
        let unchecked_unit = full_unit_to_unchecked_signed_unit(full_unit, &keychain);
        let full_unit = match validator.validate_unit(unchecked_unit.clone()) {
            Ok(_) => panic!("Validated bad unit."),
            Err(WrongSession(full_unit)) => full_unit,
            Err(e) => panic!("Unexpected error from validator: {:?}", e),
        };
        assert_eq!(full_unit, unchecked_unit.into_signable());
    }

    #[test]
    fn detects_wrong_number_of_members() {
        let n_members = NodeCount(7);
        let n_plus_one_members = NodeCount(8);
        let creator_id = NodeIndex(0);
        let session_id = 0;
        let max_round = 2;
        let keychain = Keychain::new(n_plus_one_members, creator_id);
        let validator = Validator::new(session_id, keychain, max_round);
        let full_unit = random_full_parent_units_up_to(0, n_members, session_id)[0][0].clone();
        let preunit = full_unit.as_pre_unit().clone();
        let unchecked_unit = full_unit_to_unchecked_signed_unit(full_unit, &keychain);
        let other_preunit = match validator.validate_unit(unchecked_unit) {
            Ok(_) => panic!("Validated bad unit."),
            Err(WrongNumberOfMembers(other_preunit)) => other_preunit,
            Err(e) => panic!("Unexpected error from validator: {:?}", e),
        };
        assert_eq!(other_preunit, preunit);
    }

    #[test]
    fn detects_below_threshold() {
        let n_members = NodeCount(7);
        let creator_id = NodeIndex(0);
        let session_id = 0;
        let max_round = 2;
        let parents = random_full_parent_units_up_to(0, n_members, session_id)[0]
            .iter()
            .take(4)
            .cloned()
            .collect();
        let unit = random_unit_with_parents(creator_id, &parents, 1);
        let preunit = unit.as_pre_unit().clone();
        let keychain = Keychain::new(n_members, creator_id);
        let unchecked_unit = full_unit_to_unchecked_signed_unit(unit, &keychain);
        let validator = Validator::new(session_id, keychain, max_round);
        let other_preunit = match validator.validate_unit(unchecked_unit) {
            Ok(_) => panic!("Validated bad unit."),
            Err(ParentValidationFailed(
                other_preunit,
                ControlHashError::NotEnoughParentsForRound(_),
            )) => other_preunit,
            Err(e) => panic!("Unexpected error from validator: {:?}", e),
        };
        assert_eq!(other_preunit, preunit);
    }

    #[test]
    fn detects_too_high_round() {
        let n_members = NodeCount(7);
        let creator_id = NodeIndex(0);
        let session_id = 0;
        let max_round = 2;
        let keychain = Keychain::new(n_members, creator_id);
        let validator = Validator::new(session_id, keychain, max_round);
        let full_unit = random_full_parent_units_up_to(3, n_members, session_id)[3][0].clone();
        let unchecked_unit = full_unit_to_unchecked_signed_unit(full_unit, &keychain);
        let full_unit = match validator.validate_unit(unchecked_unit.clone()) {
            Ok(_) => panic!("Validated bad unit."),
            Err(RoundTooHigh(full_unit)) => full_unit,
            Err(e) => panic!("Unexpected error from validator: {:?}", e),
        };
        assert_eq!(full_unit, unchecked_unit.into_signable());
    }
}

#[cfg(verus_keep_ghost)]
verus! {
impl<H: Hasher, D: Data, S: Signature> vstd::std_specs::convert::FromSpecImpl<SignatureError<FullUnit<H, D>, S>> for ValidationError<H, D, S> {
    open spec fn obeys_from_spec() -> bool { true }
    open spec fn from_spec(value: SignatureError<FullUnit<H, D>, S>) -> Self {
        ValidationError::WrongSignature(value.unchecked)
    }
}
impl<K: Keychain> View for Validator<K> {
    type V = (SessionId, K, Round);
    closed spec fn view(&self) -> Self::V { (self.session_id, self.keychain, self.max_round) }
}
impl<K: Keychain> Validator<K> {
    pub closed spec fn signature_accepted<H: Hasher, D: Data>(&self, uu: UncheckedSignedUnit<H, D, K::Signature>) -> bool {
        uu@.0@.0@.1.0 < self@.1.members().0 &&
        exists|bytes: &[u8]| self.keychain.accepted(bytes@, uu@.1, uu@.0@.0@.1)
    }
    pub closed spec fn signature_rejected<H: Hasher, D: Data>(&self, uu: UncheckedSignedUnit<H, D, K::Signature>) -> bool {
        uu@.0@.0@.1.0 >= self@.1.members().0 ||
        exists|bytes: &[u8]| !self.keychain.accepted(bytes@, uu@.1, uu@.0@.0@.1)
    }
    pub closed spec fn metadata_policy<H: Hasher, D: Data>(&self, unit: FullUnit<H, D>, result: StdResult<(), ControlHashError<H>>) -> bool {
        let pre = unit@.0;
        let coord = UnitCoord { round: pre@.0, creator: pre@.1 };
        if pre@.0 == 0 { pre@.2.initial_policy(result) }
        else { result == pre@.2.numeric_policy(coord) }
    }
    pub closed spec fn parent_policy<H: Hasher, D: Data>(&self, input: SignedUnit<H, D, K>, result: Result<H, D, K>) -> bool {
        let pre = input@.0@.0;
        if pre@.2@.0.len() != self@.1.members().0 {
            match result {
                Err(ValidationError::WrongNumberOfMembers(payload)) => pre.__verus_clone_relation(payload),
                _ => false,
            }
        } else {
            match result {
                Ok(unit) => unit@ == input@ && self.metadata_policy(input@.0, Ok(())),
                Err(ValidationError::ParentValidationFailed(payload, error)) =>
                    pre.__verus_clone_relation(payload) && self.metadata_policy(input@.0, Err(error)),
                _ => false,
            }
        }
    }
    pub closed spec fn validation_policy<H: Hasher, D: Data>(&self, input: UncheckedSignedUnit<H, D, K::Signature>, result: Result<H, D, K>) -> bool {
        match result {
            Err(ValidationError::WrongSignature(payload)) =>
                payload@ == input@ && self.signature_rejected(input),
            Err(ValidationError::WrongSession(payload)) =>
                self.signature_accepted(input) && input@.0@.2 != self.session_id && input@.0.clone_relation(payload),
            Err(ValidationError::RoundTooHigh(payload)) =>
                self.signature_accepted(input) && input@.0@.2 == self.session_id &&
                input@.0@.0@.0 > self.max_round && input@.0.clone_relation(payload),
            Err(ValidationError::WrongNumberOfMembers(payload)) =>
                self.signature_accepted(input) && input@.0@.2 == self.session_id &&
                input@.0@.0@.0 <= self.max_round && input@.0@.0@.2@.0.len() != self@.1.members().0 &&
                input@.0@.0.__verus_clone_relation(payload),
            Err(ValidationError::ParentValidationFailed(payload, error)) =>
                self.signature_accepted(input) && input@.0@.2 == self.session_id &&
                input@.0@.0@.0 <= self.max_round && input@.0@.0@.2@.0.len() == self@.1.members().0 &&
                input@.0@.0.__verus_clone_relation(payload) && self.metadata_policy(input@.0, Err(error)),
            Ok(unit) =>
                unit@ == input@ && self.signature_accepted(input) && input@.0@.2 == self.session_id &&
                input@.0@.0@.0 <= self.max_round && input@.0@.0@.2@.0.len() == self@.1.members().0 &&
                self.metadata_policy(input@.0, Ok(())),
        }
    }
}

// Independent end-to-end goals use a checked interface implementation. Its
// decision ignores bytes, so arbitrary hashing/AsRef results remain represented.
use aleph_bft_types::{ValidationExampleKeychain, validation_example_input};

fn validation_order_goal<H: Hasher, D: Data>(
    input: UncheckedSignedUnit<H, D, u8>, count: NodeCount,
    session: SessionId, max_round: Round,
) -> (result: Result<H, D, ValidationExampleKeychain>)
    requires input@.0@.0@.0 > 0 ==> count.0 <= usize::MAX / 2,
    ensures
        if input@.1 != 37 || input@.0@.0@.1.0 >= count.0 {
            match result {
                Err(ValidationError::WrongSignature(payload)) => payload@ == input@,
                _ => false,
            }
        } else if input@.0@.2 != session {
            match result {
                Err(ValidationError::WrongSession(payload)) => input@.0.clone_relation(payload),
                _ => false,
            }
        } else if input@.0@.0@.0 > max_round {
            match result {
                Err(ValidationError::RoundTooHigh(payload)) => input@.0.clone_relation(payload),
                _ => false,
            }
        } else if input@.0@.0@.2@.0.len() != count.0 {
            match result {
                Err(ValidationError::WrongNumberOfMembers(payload)) =>
                    input@.0@.0.__verus_clone_relation(payload),
                _ => false,
            }
        } else {
            let validator = Validator { session_id: session,
                keychain: ValidationExampleKeychain { count }, max_round };
            match result {
                Ok(signed) => signed@ == input@ && validator.metadata_policy(input@.0, Ok(())),
                Err(ValidationError::ParentValidationFailed(payload, error)) =>
                    input@.0@.0.__verus_clone_relation(payload) && validator.metadata_policy(input@.0, Err(error)),
                _ => false,
            }
        },
{
    Validator::new(session, ValidationExampleKeychain { count }, max_round).validate_unit(input)
}

pub fn validates_constructed_positive_goal<H: Hasher, D: Data>(
    parent_hash: H::Hash, data: Option<D>, session: SessionId,
) -> (result: Result<H, D, ValidationExampleKeychain>)
    ensures match result {
        Ok(signed) => signed@.1 == 37 && signed@.0@.2 == session &&
            signed@.0@.1 == data && signed@.0@.0@.0 == 1 && signed@.0@.0@.1 == NodeIndex(0),
        _ => false,
    },
{
    let mut parents = crate::NodeMap::with_size(NodeCount(1));
    parents.insert(NodeIndex(0), (parent_hash, 0));
    let control = crate::units::ControlHash::<H>::new(&parents);
    control.validate_eligible(UnitCoord::new(1, NodeIndex(0)));
    let pre = PreUnit::new(NodeIndex(0), 1, control);
    let unit = FullUnit::new(pre, data, session);
    let input = validation_example_input(unit, 37);
    Validator::new(session, ValidationExampleKeychain { count: NodeCount(1) }, 1).validate_unit(input)
}
}
