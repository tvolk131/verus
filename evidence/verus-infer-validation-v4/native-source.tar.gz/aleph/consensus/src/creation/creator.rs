use crate::{
    creation::collector::{ConstraintError, UnitsCollector},
    units::{ControlHash, PreUnit, Unit},
    Hasher, NodeCount, NodeIndex, NodeMap, Round,
};
use anyhow::Result;
use std::cmp;
use vstd::prelude::*;

#[verus_verify(external_derive(Debug, Eq, PartialEq))]
#[derive(Debug, Eq, PartialEq)]
pub enum CreationInputError {
    TerminalRound,
    OutsideMembership(NodeIndex),
}

#[verus_verify]
pub struct Creator<H: Hasher> {
    round_collectors: Vec<UnitsCollector<H>>,
    node_id: NodeIndex,
    n_members: NodeCount,
}

verus! {
impl<H: Hasher> View for Creator<H> {
    type V = (Seq<UnitsCollector<H>>, NodeIndex, NodeCount);
    closed spec fn view(&self) -> Self::V {
        (self.round_collectors@, self.node_id, self.n_members)
    }
}
impl<H: Hasher> Creator<H> {
    pub open spec fn valid(&self) -> bool {
        &&& 0 < self@.0.len() <= u16::MAX
        &&& forall|i: int| 0 <= i < self@.0.len() ==>
            self@.0[i].valid() && self@.0[i]@.1 == i + 1 && self@.0[i]@.0.len() == self@.2.0
    }
    pub closed spec fn selected_parents(&self, round: Round) -> Result<Seq<Option<(H::Hash, Round)>>, ConstraintError> {
        if round == 0 { Ok(Seq::new(self.n_members.0 as nat, |i: int| None)) }
        else if round as int - 1 >= self.round_collectors@.len() {
            Err(ConstraintError::NotEnoughParents)
        } else {
            let collector = self.round_collectors@[round as int - 1];
            if collector@.2.0 < (2 * self.n_members.0 as int) / 3 + 1 {
                Err(ConstraintError::NotEnoughParents)
            } else if collector@.0[self.node_id.0 as int].is_some() &&
                collector@.0[self.node_id.0 as int].unwrap().1 == round - 1 {
                Ok(collector@.0)
            } else { Err(ConstraintError::MissingOwnParent) }
        }
    }

    pub fn new(node_id: NodeIndex, n_members: NodeCount) -> (result: Self)
        ensures result.valid(), result@.1 == node_id, result@.2 == n_members,
            result@.0.len() == 1,
    {
        Creator {
            node_id,
            n_members,
            round_collectors: vec![UnitsCollector::new_initial(n_members)],
        }
    }
}
}

impl<H: Hasher> Creator<H> {
    #[verus_infer]
    pub fn current_round(&self) -> Round {
        (self.round_collectors.len() - 1) as Round
    }

    // gets or initializes a unit collector for a given round (and all between if not there)
    #[verus_spec(slot =>
        requires old(self).valid(), round < u16::MAX,
        ensures slot.valid(), slot@.1 == round as int + 1,
            slot@.0.len() == old(self).n_members.0,
    )]
    fn get_or_initialize_collector_for_round(&mut self, round: Round) -> &mut UnitsCollector<H> {
        while round > self.current_round() {
            let next_collector = UnitsCollector::from_previous(
                self.round_collectors
                    .last()
                    .expect("we always have at least one"),
            );
            self.round_collectors.push(next_collector);
        }
        &mut self.round_collectors[round as usize]
    }

    #[verus_spec(result =>
        requires old(self).valid(),
        ensures final(self).valid(), final(self)@.1 == old(self)@.1,
            final(self)@.2 == old(self)@.2,
            result.is_err() == (round == u16::MAX),
            result.is_err() ==> result == Err(CreationInputError::TerminalRound),
            result.is_err() ==> final(self)@ == old(self)@,
            result.is_ok() ==> final(self)@.0.len() == if old(self)@.0.len() > round as int + 1 {
                old(self)@.0.len() as int
            } else { round as int + 1 },
            final(self)@.0.take(old(self)@.0.len() as int) == old(self)@.0,
    )]
    pub fn try_initialize_round(&mut self, round: Round) -> Result<(), CreationInputError> {
        if round == Round::MAX {
            return Err(CreationInputError::TerminalRound);
        }
        let _ = self.get_or_initialize_collector_for_round(round);
        Ok(())
    }

    /// To create a new unit, we need to have at least the consensus threshold of parents available in previous round.
    /// Additionally, our unit from previous round must be available.
    #[verus_spec(result =>
        requires self.valid(),
            round > 0 ==> (self@.1.0 < self@.2.0 && self@.2.0 <= usize::MAX / 2),
        ensures result.is_ok() == self.selected_parents(round).is_ok(),
            result.is_err() ==> result->Err_0 == self.selected_parents(round)->Err_0,
            result.is_ok() ==> result.unwrap()@.0 == round,
            result.is_ok() ==> result.unwrap()@.1 == self@.1,
            result.is_ok() ==> result.unwrap()@.2@.0.len() == self@.2.0,
            result.is_ok() ==> result.unwrap()@.2@.0 == self.selected_parents(round).unwrap().map_values(
                |slot: Option<(H::Hash, Round)>| match slot { None => None, Some((_, r)) => Some(r) }),
            result.is_ok() && round == 0 ==> forall|i: int| 0 <= i < result.unwrap()@.2@.0.len() ==>
                result.unwrap()@.2@.0[i].is_none(),
            result.is_ok() && round > 0 ==> result.unwrap()@.2@.0[self@.1.0 as int] == Some((round - 1) as Round),
            result.is_ok() && round > 0 ==> forall|i: int| 0 <= i < result.unwrap()@.2@.0.len()
                && result.unwrap()@.2@.0[i].is_some() ==> result.unwrap()@.2@.0[i].unwrap() < round,
            result.is_ok() && round > 0 ==> result.unwrap()@.2@.0.count_prefix(
                |slot: Option<Round>| slot == Some((round - 1) as Round), result.unwrap()@.2@.0.len())
                >= (2 * self@.2.0 as int) / 3 + 1,
    )]
    pub fn create_unit(&self, round: Round) -> Result<PreUnit<H>, ConstraintError> {
        let control_hash = match round.checked_sub(1) {
            None => ControlHash::new(&NodeMap::with_size(self.n_members)),
            Some(prev_round) => ControlHash::new(
                self.round_collectors
                    .get(usize::from(prev_round))
                    .ok_or(ConstraintError::NotEnoughParents)?
                    .prospective_parents(self.node_id)?,
            ),
        };

        Ok(PreUnit::new(self.node_id, round, control_hash))
    }

    #[verus_spec(
        requires old(self).valid(), unit.lawful_observation(),
            unit.observed_coord()@.0 < u16::MAX,
            unit.observed_coord()@.1.0 < old(self)@.2.0,
        ensures final(self).valid(), final(self)@.1 == old(self)@.1,
            final(self)@.2 == old(self)@.2,
            final(self)@.0.len() == if old(self)@.0.len() > unit.observed_coord()@.0 as int + 1 {
                old(self)@.0.len() as int
            } else { unit.observed_coord()@.0 as int + 1 },
            forall|i: int| unit.observed_coord()@.0 <= i < final(self)@.0.len() ==>
                final(self)@.0[i].records(unit.observed_coord()@.1, unit.observed_coord()@.0),
            final(self)@.0.take(if unit.observed_coord()@.0 < old(self)@.0.len() {
                unit.observed_coord()@.0 as int
            } else { old(self)@.0.len() as int }) == old(self)@.0.take(
                if unit.observed_coord()@.0 < old(self)@.0.len() {
                    unit.observed_coord()@.0 as int
                } else { old(self)@.0.len() as int }),
    )]
    pub fn add_unit<U: Unit<Hasher = H>>(&mut self, unit: &U) {
        let start_round = unit.round();
        let end_round = cmp::max(start_round, self.current_round());
        for round in start_round..=end_round {
            self.get_or_initialize_collector_for_round(round)
                .add_unit(unit);
        }
    }

    #[verus_spec(result =>
        requires old(self).valid(), unit.lawful_observation(),
        ensures final(self).valid(), final(self)@.1 == old(self)@.1,
            final(self)@.2 == old(self)@.2,
            result == if unit.observed_coord()@.0 == u16::MAX {
                Err(CreationInputError::TerminalRound)
            } else if unit.observed_coord()@.1.0 >= old(self)@.2.0 {
                Err(CreationInputError::OutsideMembership(unit.observed_coord()@.1))
            } else { Ok(()) },
            result.is_err() ==> final(self)@ == old(self)@,
            result.is_ok() ==> final(self)@.0.len() == if old(self)@.0.len() > unit.observed_coord()@.0 as int + 1 {
                old(self)@.0.len() as int
            } else { unit.observed_coord()@.0 as int + 1 },
            result.is_ok() ==> forall|i: int| unit.observed_coord()@.0 <= i < final(self)@.0.len() ==>
                final(self)@.0[i].records(unit.observed_coord()@.1, unit.observed_coord()@.0),
            final(self)@.0.take(if unit.observed_coord()@.0 < old(self)@.0.len() {
                unit.observed_coord()@.0 as int
            } else { old(self)@.0.len() as int }) == old(self)@.0.take(
                if unit.observed_coord()@.0 < old(self)@.0.len() {
                    unit.observed_coord()@.0 as int
                } else { old(self)@.0.len() as int }),
    )]
    pub fn try_add_unit<U: Unit<Hasher = H>>(&mut self, unit: &U) -> Result<(), CreationInputError> {
        if unit.round() == Round::MAX {
            return Err(CreationInputError::TerminalRound);
        }
        let creator = unit.creator();
        if creator.0 >= self.n_members.0 {
            return Err(CreationInputError::OutsideMembership(creator));
        }
        self.add_unit(unit);
        Ok(())
    }
}

#[cfg(verus_keep_ghost)]
verus! {
/// Universal success implication, for every valid represented Creator, arbitrary
/// hash payloads, frozen-domain membership and every requested u16 round.
pub fn creation_metadata_goal<H: Hasher>(creator: &Creator<H>, round: Round)
    requires creator.valid(), creator@.2.0 <= usize::MAX / 2,
        round > 0 ==> creator@.1.0 < creator@.2.0,
{
    let created = creator.create_unit(round);
    if let Ok(unit) = created {
        assert(unit@.0 == round && unit@.1 == creator@.1);
        let metadata = unit.control_hash();
        assert(metadata@.0.len() == creator@.2.0);
        if round > 0 {
            assert(metadata@.0[creator@.1.0 as int] == Some((round - 1) as Round));
            assert(forall|i: int| 0 <= i < metadata@.0.len() && metadata@.0[i].is_some()
                ==> metadata@.0[i].unwrap() < round);
            assert(metadata@.0.count_prefix(|slot: Option<Round>| slot == Some((round - 1) as Round),
                metadata@.0.len()) >= (2 * creator@.2.0 as int) / 3 + 1);
            let coordinate = crate::units::UnitCoord::new(unit.round(), unit.creator());
            let validation = metadata.validate_eligible(coordinate);
            assert(validation == Ok(()));
        }
    }
}
}

#[cfg(test)]
mod tests {
    use super::CreationInputError;
    use crate::{
        creation::creator::Creator as GenericCreator,
        units::{
            create_preunits, creator_set, preunit_to_full_unit, random_full_parent_units_up_to,
        },
        NodeCount, NodeIndex,
    };
    use aleph_bft_mock::Hasher64;

    type Creator = GenericCreator<Hasher64>;

    #[test]
    fn checked_terminal_and_membership_rejections_do_not_grow_history() {
        let mut creator = Creator::new(NodeIndex(0), NodeCount(4));
        assert_eq!(creator.try_initialize_round(u16::MAX), Err(CreationInputError::TerminalRound));
        assert_eq!(creator.round_collectors.len(), 1);
        let terminal = preunit_to_full_unit(crate::units::PreUnit::new(
            NodeIndex(0), u16::MAX, crate::units::ControlHash::new(&crate::NodeMap::with_size(NodeCount(4)))), 0);
        assert_eq!(creator.try_add_unit(&terminal), Err(CreationInputError::TerminalRound));
        assert_eq!(creator.round_collectors.len(), 1);
        let outside = preunit_to_full_unit(crate::units::PreUnit::new(
            NodeIndex(4), 0, crate::units::ControlHash::new(&crate::NodeMap::with_size(NodeCount(4)))), 0);
        assert_eq!(creator.try_add_unit(&outside), Err(CreationInputError::OutsideMembership(NodeIndex(4))));
        assert_eq!(creator.round_collectors.len(), 1);
        let mut zero = Creator::new(NodeIndex(99), NodeCount(0));
        assert!(zero.create_unit(0).is_ok());
        assert_eq!(zero.try_add_unit(&outside), Err(CreationInputError::OutsideMembership(NodeIndex(4))));
        assert_eq!(zero.round_collectors.len(), 1);
    }

    #[test]
    fn creates_initial_unit() {
        let n_members = NodeCount(7);
        let round = 0;
        let creator = Creator::new(NodeIndex(0), n_members);
        assert_eq!(creator.current_round(), round);
        let preunit = creator
            .create_unit(round)
            .expect("Creation should succeed.");
        assert_eq!(preunit.round(), round);
    }

    #[test]
    fn creates_unit_with_all_parents() {
        let n_members = NodeCount(7);
        let mut creators = creator_set(n_members);
        let new_units = create_preunits(creators.iter(), 0);
        let new_units: Vec<_> = new_units
            .into_iter()
            .map(|pu| preunit_to_full_unit(pu, 0))
            .collect();
        let creator = &mut creators[0];
        creator.add_units(&new_units);
        let round = 1;
        assert_eq!(creator.current_round(), 0);
        let preunit = creator
            .create_unit(round)
            .expect("Creation should succeed.");
        assert_eq!(preunit.round(), round);
    }

    fn create_unit_with_minimal_parents(n_members: NodeCount) {
        let n_parents = n_members.consensus_threshold().0;
        let mut creators = creator_set(n_members);
        let new_units = create_preunits(creators.iter().take(n_parents), 0);
        let new_units: Vec<_> = new_units
            .into_iter()
            .map(|pu| preunit_to_full_unit(pu, 0))
            .collect();
        let creator = &mut creators[0];
        creator.add_units(&new_units);
        let round = 1;
        assert_eq!(creator.current_round(), 0);
        let preunit = creator
            .create_unit(round)
            .expect("Creation should succeed.");
        assert_eq!(preunit.round(), round);
    }

    #[test]
    fn creates_unit_with_minimal_parents_4() {
        create_unit_with_minimal_parents(NodeCount(4));
    }

    #[test]
    fn creates_unit_with_minimal_parents_5() {
        create_unit_with_minimal_parents(NodeCount(5));
    }

    #[test]
    fn creates_unit_with_minimal_parents_6() {
        create_unit_with_minimal_parents(NodeCount(6));
    }

    #[test]
    fn creates_unit_with_minimal_parents_7() {
        create_unit_with_minimal_parents(NodeCount(7));
    }

    fn dont_create_unit_below_parents_threshold(n_members: NodeCount) {
        let n_parents = n_members.consensus_threshold() - NodeCount(1);
        let mut creators = creator_set(n_members);
        let new_units = create_preunits(creators.iter().take(n_parents.0), 0);
        let new_units: Vec<_> = new_units
            .into_iter()
            .map(|pu| preunit_to_full_unit(pu, 0))
            .collect();
        let creator = &mut creators[0];
        creator.add_units(&new_units);
        let round = 1;
        assert_eq!(creator.current_round(), 0);
        assert!(creator.create_unit(round).is_err())
    }

    #[test]
    fn cannot_create_unit_below_parents_threshold_4() {
        dont_create_unit_below_parents_threshold(NodeCount(4));
    }

    #[test]
    fn cannot_create_unit_below_parents_threshold_5() {
        dont_create_unit_below_parents_threshold(NodeCount(5));
    }

    #[test]
    fn cannot_create_unit_below_parents_threshold_6() {
        dont_create_unit_below_parents_threshold(NodeCount(6));
    }

    #[test]
    fn cannot_create_unit_below_parents_threshold_7() {
        dont_create_unit_below_parents_threshold(NodeCount(7));
    }

    #[test]
    fn creates_two_units_when_possible() {
        let n_members = NodeCount(7);
        let mut creators = creator_set(n_members);
        for round in 0..2 {
            let new_units = create_preunits(creators.iter().skip(1), round);
            let new_units: Vec<_> = new_units
                .into_iter()
                .map(|pu| preunit_to_full_unit(pu, 0))
                .collect();
            for creator in creators.iter_mut() {
                creator.add_units(&new_units);
            }
        }
        let creator = &mut creators[0];
        assert_eq!(creator.current_round(), 1);
        for round in 0..3 {
            let preunit = creator
                .create_unit(round)
                .expect("Creation should succeed.");
            assert_eq!(preunit.round(), round);
            let unit = preunit_to_full_unit(preunit, 0);
            creator.add_unit(&unit);
        }
    }

    #[test]
    fn cannot_create_unit_without_predecessor() {
        let n_members = NodeCount(7);
        let mut creators = creator_set(n_members);
        let new_units = create_preunits(creators.iter().skip(1), 0);
        let new_units: Vec<_> = new_units
            .into_iter()
            .map(|pu| preunit_to_full_unit(pu, 0))
            .collect();
        let creator = &mut creators[0];
        creator.add_units(&new_units);
        let round = 1;
        assert!(creator.create_unit(round).is_err());
    }

    #[test]
    fn creates_unit_with_ancient_parents() {
        let n_members = NodeCount(7);
        let mut creator = Creator::new(NodeIndex(0), n_members);
        let units = random_full_parent_units_up_to(1, n_members, 43);
        creator.add_units(&units[0]);
        for unit in units[1].iter().take(5) {
            creator.add_unit(unit);
        }
        let round = 2;
        let preunit = creator
            .create_unit(round)
            .expect("Creation should succeed.");
        assert_eq!(preunit.round(), round);
        for coord in preunit.control_hash().parents().take(5) {
            assert_eq!(coord.round(), round - 1);
        }
        assert_eq!(
            preunit
                .control_hash()
                .parents()
                .nth(5)
                .expect("there is a sixth parent")
                .round(),
            round - 2
        );
    }

    #[test]
    fn creates_unit_with_ancient_parents_weird_order() {
        let n_members = NodeCount(7);
        let mut creator = Creator::new(NodeIndex(0), n_members);
        let units = random_full_parent_units_up_to(1, n_members, 43);
        for unit in units[1].iter().take(5) {
            creator.add_unit(unit);
        }
        creator.add_units(&units[0]);
        let round = 2;
        let preunit = creator
            .create_unit(round)
            .expect("Creation should succeed.");
        assert_eq!(preunit.round(), round);
        for coord in preunit.control_hash().parents().take(5) {
            assert_eq!(coord.round(), round - 1);
        }
        assert_eq!(
            preunit
                .control_hash()
                .parents()
                .nth(5)
                .expect("there is a sixth parent")
                .round(),
            round - 2
        );
    }

    #[test]
    fn creates_old_unit_with_best_parents() {
        let n_members = NodeCount(7);
        let mut creator = Creator::new(NodeIndex(0), n_members);
        let units = random_full_parent_units_up_to(2, n_members, 43);
        for round_units in &units {
            for unit in round_units.iter().take(5) {
                creator.add_unit(unit);
            }
        }
        creator.add_unit(&units[0][5]);
        let round = 1;
        let preunit = creator
            .create_unit(round)
            .expect("Creation should succeed.");
        assert_eq!(preunit.round(), round);
        for coord in preunit.control_hash().parents().take(5) {
            assert_eq!(coord.round(), round - 1);
        }
        assert!(preunit.control_hash().parents().nth(5).is_some());
    }
}
