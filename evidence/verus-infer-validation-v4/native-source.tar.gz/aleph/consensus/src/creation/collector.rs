use crate::{units::Unit, Hasher, NodeCount, NodeIndex, NodeMap, Round};
use anyhow::Result;
use thiserror::Error;
use vstd::prelude::*;

#[verus_verify(external_derive(Eq, Error, Display, Debug, PartialEq))]
#[derive(Eq, Error, Debug, PartialEq)]
pub enum ConstraintError {
    #[error("Not enough parents.")]
    NotEnoughParents,
    #[error("Missing own parent.")]
    MissingOwnParent,
}

#[verus_verify(external_derive(Clone))]
#[derive(Clone)]
pub struct UnitsCollector<H: Hasher> {
    candidates: NodeMap<(H::Hash, Round)>,
    for_round: Round,
    direct_parents: NodeCount,
}

verus! {
impl<H: Hasher> View for UnitsCollector<H> {
    type V = (Seq<Option<(H::Hash, Round)>>, Round, NodeCount);
    closed spec fn view(&self) -> Self::V {
        (self.candidates@, self.for_round, self.direct_parents)
    }
}
impl<H: Hasher> UnitsCollector<H> {
    pub open spec fn valid(&self) -> bool {
        &&& self@.1 > 0
        &&& forall|i: int| 0 <= i < self@.0.len() && self@.0[i].is_some() ==>
            self@.0[i].unwrap().1 < self@.1
        &&& self@.2.0 == self@.0.count_prefix(
            |slot: Option<(H::Hash, Round)>| slot.is_some() && slot.unwrap().1 == self@.1 - 1,
            self@.0.len())
    }
    pub open spec fn records(&self, node_id: NodeIndex, round: Round) -> bool {
        node_id.0 < self@.0.len() && self@.0[node_id.0 as int].is_some() &&
            self@.0[node_id.0 as int].unwrap().1 >= round
    }
}
}

verus! {
impl<H: Hasher> UnitsCollector<H> {
    pub fn initial_valid(n_members: NodeCount) -> (result: Self)
        ensures result.valid(), result@.1 == 1, result@.2.0 == 0,
            result@.0.len() == n_members.0,
            forall|i: int| 0 <= i < result@.0.len() ==> result@.0[i].is_none(),
    { Self::new_initial(n_members) }

    pub fn observe_valid(&mut self, node_id: NodeIndex, hash: H::Hash, round: Round)
        requires old(self).valid(),
            round < old(self)@.1 ==> node_id.0 < old(self)@.0.len(),
        ensures final(self).valid(), final(self)@.1 == old(self)@.1,
            final(self)@.0.len() == old(self)@.0.len(),
            final(self)@.0 == if round < old(self)@.1 &&
                (old(self)@.0[node_id.0 as int].is_none() ||
                 old(self)@.0[node_id.0 as int].unwrap().1 < round) {
                old(self)@.0.update(node_id.0 as int, Some((hash, round)))
            } else { old(self)@.0 },
    { self.observe(node_id, hash, round); }

    fn selection_policy(&self, node_id: NodeIndex) -> (result: Result<&NodeMap<(H::Hash, Round)>, ConstraintError>)
        requires self.valid(), self@.0.len() <= usize::MAX / 2,
            self@.0.len() > 0 ==> node_id.0 < self@.0.len(),
        ensures
            result == if self@.2.0 < (2 * self@.0.len()) / 3 + 1 {
                Err(ConstraintError::NotEnoughParents)
            } else if self@.0[node_id.0 as int].is_some() &&
                self@.0[node_id.0 as int].unwrap().1 == self@.1 - 1 {
                Ok(&self.candidates)
            } else { Err(ConstraintError::MissingOwnParent) },
            result.is_ok() ==> result.unwrap()@ == self@.0,
    { self.prospective_parents(node_id) }

    pub fn from_previous(previous: &UnitsCollector<H>) -> (result: Self)
        requires previous.valid(), previous@.1 < u16::MAX,
        ensures previous.valid() ==> result.valid(), result@.1 == previous@.1 + 1,
            result@.0.len() == previous@.0.len(), result@.2.0 == 0,
            forall|i: int| 0 <= i < previous@.0.len() ==>
                result@.0[i].is_some() == previous@.0[i].is_some(),
            forall|i: int| 0 <= i < previous@.0.len() ==>
                cloned(previous@.0[i], result@.0[i]),
            forall|i: int| 0 <= i < previous@.0.len() && previous@.0[i].is_some() ==>
                result@.0[i].unwrap().1 == previous@.0[i].unwrap().1,
    {
        let next = UnitsCollector {
            candidates: previous.candidates.clone(),
            for_round: previous.for_round + 1,
            direct_parents: NodeCount(0),
        };
        next
    }

    pub fn try_from_previous(previous: &UnitsCollector<H>) -> (result: Result<Self, Round>)
        requires previous.valid(),
        ensures result.is_err() == (previous@.1 == u16::MAX),
            result.is_err() ==> result == Err(u16::MAX),
            result.is_ok() ==> result.unwrap().valid(),
            result.is_ok() ==> result.unwrap()@.1 == previous@.1 as int + 1,
            result.is_ok() ==> result.unwrap()@.0.len() == previous@.0.len(),
    {
        if previous.for_round == Round::MAX { return Err(Round::MAX); }
        Ok(Self::from_previous(previous))
    }

}
}

impl<H: Hasher> UnitsCollector<H> {
    #[verus_infer]
    pub fn new_initial(n_members: NodeCount) -> Self {
        UnitsCollector {
            candidates: NodeMap::with_size(n_members),
            for_round: 1,
            direct_parents: NodeCount(0),
        }
    }


    #[verus_spec(
        requires old(self).valid(), unit.lawful_observation(),
            unit.observed_coord()@.0 < old(self)@.1 ==>
                unit.observed_coord()@.1.0 < old(self)@.0.len(),
        ensures final(self).valid(), final(self)@.1 == old(self)@.1,
            final(self)@.0.len() == old(self)@.0.len(),
            unit.observed_coord()@.0 < old(self)@.1 ==>
                final(self).records(unit.observed_coord()@.1, unit.observed_coord()@.0),
            unit.observed_coord()@.0 >= old(self)@.1 ==> final(self)@ == old(self)@,
    )]
    pub fn add_unit<U: Unit<Hasher = H>>(&mut self, unit: &U) {
        let _ = self.add_unit_observed(unit);
    }

    /// Captures the actual opaque hash observation used by ingestion.
    #[verus_spec(observation =>
        requires old(self).valid(), unit.lawful_observation(),
            unit.observed_coord()@.0 < old(self)@.1 ==>
                unit.observed_coord()@.1.0 < old(self)@.0.len(),
        ensures observation.0 == unit.observed_coord()@.1,
            observation.2 == unit.observed_coord()@.0,
            final(self).valid(), final(self)@.1 == old(self)@.1,
            final(self)@.0.len() == old(self)@.0.len(),
            observation.2 < old(self)@.1 ==> final(self).records(observation.0, observation.2),
            final(self)@.0 == if observation.2 < old(self)@.1 &&
                (old(self)@.0[observation.0.0 as int].is_none() ||
                    old(self)@.0[observation.0.0 as int].unwrap().1 < observation.2) {
                old(self)@.0.update(observation.0.0 as int, Some((observation.1, observation.2)))
            } else { old(self)@.0 },
    )]
    pub fn add_unit_observed<U: Unit<Hasher = H>>(&mut self, unit: &U) -> (NodeIndex, H::Hash, Round) {
        let node_id = unit.creator();
        let hash = unit.hash();
        let round = unit.round();

        self.observe_valid(node_id, hash, round);
        (node_id, hash, round)
    }

    #[verus_infer]
    fn observe(&mut self, node_id: NodeIndex, hash: H::Hash, round: Round) {
        if round >= self.for_round {
            return;
        }

        let to_insert = match self.candidates.get(node_id) {
            None => Some((hash, round)),
            Some((_, r)) if *r < round => Some((hash, round)),
            _ => None,
        };

        if let Some(data) = to_insert {
            self.candidates.insert(node_id, data);
            if round == self.for_round - 1 {
                self.direct_parents += NodeCount(1);
            }
        }
    }

    #[verus_infer]
    pub fn prospective_parents(
        &self,
        node_id: NodeIndex,
    ) -> Result<&NodeMap<(H::Hash, Round)>, ConstraintError> {
        if self.direct_parents < self.candidates.size().consensus_threshold() {
            return Err(ConstraintError::NotEnoughParents);
        }
        match self.candidates.get(node_id) {
            Some((_, r)) if *r == self.for_round - 1 => Ok(&self.candidates),
            _ => Err(ConstraintError::MissingOwnParent),
        }
    }
}

#[cfg(test)]
mod tests {
    use crate::{
        creation::collector::{ConstraintError, UnitsCollector},
        units::{random_full_parent_units_up_to, Unit},
        NodeCount, NodeIndex,
    };
    use aleph_bft_mock::Hasher64;

    #[test]
    fn terminal_advance_rejects_and_maximum_predecessor_advances() {
        let mut previous = UnitsCollector::<Hasher64>::new_initial(NodeCount(0));
        previous.for_round = u16::MAX - 1;
        let terminal = UnitsCollector::try_from_previous(&previous).unwrap();
        assert_eq!(terminal.for_round, u16::MAX);
        assert!(matches!(UnitsCollector::try_from_previous(&terminal), Err(u16::MAX)));
        assert_eq!(terminal.for_round, u16::MAX);
    }

    #[test]
    fn original_raw_terminal_advance_panics() {
        let mut terminal = UnitsCollector::<Hasher64>::new_initial(NodeCount(0));
        terminal.for_round = u16::MAX;
        assert!(std::panic::catch_unwind(|| UnitsCollector::from_previous(&terminal)).is_err());
    }

    #[test]
    fn initial_fails_without_parents() {
        let n_members = NodeCount(4);
        let units_collector = UnitsCollector::<Hasher64>::new_initial(n_members);

        let err = units_collector
            .prospective_parents(NodeIndex(0))
            .expect_err("should fail without parents");
        assert_eq!(err, ConstraintError::NotEnoughParents);
    }

    #[test]
    fn initial_fails_with_too_few_parents() {
        let n_members = NodeCount(4);
        let mut units_collector = UnitsCollector::new_initial(n_members);
        let units = random_full_parent_units_up_to(0, n_members, 43);
        units_collector.add_unit(&units[0][0]);

        let err = units_collector
            .prospective_parents(NodeIndex(0))
            .expect_err("should fail without parents");
        assert_eq!(err, ConstraintError::NotEnoughParents);
    }

    #[test]
    fn initial_fails_without_own_parent() {
        let n_members = NodeCount(4);
        let mut units_collector = UnitsCollector::new_initial(n_members);
        let units = random_full_parent_units_up_to(0, n_members, 43);
        for unit in units[0].iter().skip(1) {
            units_collector.add_unit(unit);
        }

        let err = units_collector
            .prospective_parents(NodeIndex(0))
            .expect_err("should fail without parents");
        assert_eq!(err, ConstraintError::MissingOwnParent);
    }

    #[test]
    fn initial_successfully_computes_minimal_parents() {
        let n_members = NodeCount(4);
        let mut units_collector = UnitsCollector::new_initial(n_members);
        let units = random_full_parent_units_up_to(0, n_members, 43);
        for unit in units[0].iter().take(3) {
            units_collector.add_unit(unit);
        }

        let parents = units_collector
            .prospective_parents(NodeIndex(0))
            .expect("we should be able to retrieve parents");
        assert_eq!(parents.item_count(), 3);

        let new_units: Vec<_> = units[0]
            .iter()
            .take(3)
            .map(|unit| (unit.hash(), unit.round()))
            .collect();
        let selected_parents: Vec<_> = parents.values().cloned().collect();
        assert_eq!(new_units, selected_parents);
    }

    #[test]
    fn initial_successfully_computes_full_parents() {
        let n_members = NodeCount(4);
        let mut units_collector = UnitsCollector::new_initial(n_members);
        let units = random_full_parent_units_up_to(0, n_members, 43);
        for unit in &units[0] {
            units_collector.add_unit(unit);
        }

        let parents = units_collector
            .prospective_parents(NodeIndex(0))
            .expect("we should be able to retrieve parents");
        assert_eq!(parents.item_count(), 4);

        let new_units: Vec<_> = units[0]
            .iter()
            .map(|unit| (unit.hash(), unit.round()))
            .collect();
        let selected_parents: Vec<_> = parents.values().cloned().collect();
        assert_eq!(new_units, selected_parents);
    }

    #[test]
    fn initial_ignores_future_rounds() {
        let n_members = NodeCount(4);
        let mut units_collector = UnitsCollector::new_initial(n_members);
        let units = random_full_parent_units_up_to(2, n_members, 43);
        for round_units in &units {
            for unit in round_units {
                units_collector.add_unit(unit);
            }
        }

        let parents = units_collector
            .prospective_parents(NodeIndex(0))
            .expect("we should be able to retrieve parents");
        assert_eq!(parents.item_count(), 4);

        let new_units: Vec<_> = units[0]
            .iter()
            .map(|unit| (unit.hash(), unit.round()))
            .collect();
        let selected_parents: Vec<_> = parents.values().cloned().collect();
        assert_eq!(new_units, selected_parents);
    }

    #[test]
    fn following_fails_without_parents() {
        let n_members = NodeCount(4);
        let initial_units_collector = UnitsCollector::<Hasher64>::new_initial(n_members);
        let units_collector = UnitsCollector::from_previous(&initial_units_collector);

        let err = units_collector
            .prospective_parents(NodeIndex(0))
            .expect_err("should fail without parents");
        assert_eq!(err, ConstraintError::NotEnoughParents);
    }

    #[test]
    fn following_fails_with_too_few_parents() {
        let n_members = NodeCount(4);
        let initial_units_collector = UnitsCollector::<Hasher64>::new_initial(n_members);
        let mut units_collector = UnitsCollector::from_previous(&initial_units_collector);
        let units = random_full_parent_units_up_to(1, n_members, 43);
        units_collector.add_unit(&units[1][0]);

        let err = units_collector
            .prospective_parents(NodeIndex(0))
            .expect_err("should fail without parents");
        assert_eq!(err, ConstraintError::NotEnoughParents);
    }

    #[test]
    fn following_fails_with_too_old_parents() {
        let n_members = NodeCount(4);
        let initial_units_collector = UnitsCollector::<Hasher64>::new_initial(n_members);
        let mut units_collector = UnitsCollector::from_previous(&initial_units_collector);
        let units = random_full_parent_units_up_to(0, n_members, 43);
        for unit in &units[0] {
            units_collector.add_unit(unit);
        }

        let err = units_collector
            .prospective_parents(NodeIndex(0))
            .expect_err("should fail without parents");
        assert_eq!(err, ConstraintError::NotEnoughParents);
    }

    #[test]
    fn following_fails_without_own_parent() {
        let n_members = NodeCount(4);
        let initial_units_collector = UnitsCollector::<Hasher64>::new_initial(n_members);
        let mut units_collector = UnitsCollector::from_previous(&initial_units_collector);
        let units = random_full_parent_units_up_to(1, n_members, 43);
        for unit in units[1].iter().skip(1) {
            units_collector.add_unit(unit);
        }

        let err = units_collector
            .prospective_parents(NodeIndex(0))
            .expect_err("should fail without parents");
        assert_eq!(err, ConstraintError::MissingOwnParent);
    }

    #[test]
    fn following_fails_with_too_old_own_parent() {
        let n_members = NodeCount(4);
        let initial_units_collector = UnitsCollector::<Hasher64>::new_initial(n_members);
        let mut units_collector = UnitsCollector::from_previous(&initial_units_collector);
        let units = random_full_parent_units_up_to(1, n_members, 43);
        for unit in units[1].iter().skip(1) {
            units_collector.add_unit(unit);
        }
        units_collector.add_unit(&units[0][0]);

        let err = units_collector
            .prospective_parents(NodeIndex(0))
            .expect_err("should fail without parents");
        assert_eq!(err, ConstraintError::MissingOwnParent);
    }

    #[test]
    fn following_successfully_computes_minimal_parents() {
        let n_members = NodeCount(4);
        let initial_units_collector = UnitsCollector::<Hasher64>::new_initial(n_members);
        let mut units_collector = UnitsCollector::from_previous(&initial_units_collector);
        let units = random_full_parent_units_up_to(1, n_members, 43);
        for unit in units[1].iter().take(3) {
            units_collector.add_unit(unit);
        }

        let parents = units_collector
            .prospective_parents(NodeIndex(0))
            .expect("we should be able to retrieve parents");
        assert_eq!(parents.item_count(), 3);

        let new_units: Vec<_> = units[1]
            .iter()
            .take(3)
            .map(|unit| (unit.hash(), unit.round()))
            .collect();
        let selected_parents: Vec<_> = parents.values().cloned().collect();
        assert_eq!(new_units, selected_parents);
    }

    #[test]
    fn following_successfully_computes_minimal_parents_with_ancient() {
        let n_members = NodeCount(4);
        let initial_units_collector = UnitsCollector::<Hasher64>::new_initial(n_members);
        let mut units_collector = UnitsCollector::from_previous(&initial_units_collector);
        let units = random_full_parent_units_up_to(1, n_members, 43);
        for unit in units[1].iter().take(3) {
            units_collector.add_unit(unit);
        }
        units_collector.add_unit(&units[0][3]);

        let parents = units_collector
            .prospective_parents(NodeIndex(0))
            .expect("we should be able to retrieve parents");
        assert_eq!(parents.item_count(), 4);

        let mut new_units: Vec<_> = units[1]
            .iter()
            .take(3)
            .map(|unit| (unit.hash(), unit.round()))
            .collect();
        new_units.push((units[0][3].hash(), units[0][3].round()));
        let selected_parents: Vec<_> = parents.values().cloned().collect();
        assert_eq!(new_units, selected_parents);
    }

    #[test]
    fn following_successfully_computes_full_parents() {
        let n_members = NodeCount(4);
        let initial_units_collector = UnitsCollector::<Hasher64>::new_initial(n_members);
        let mut units_collector = UnitsCollector::from_previous(&initial_units_collector);
        let units = random_full_parent_units_up_to(1, n_members, 43);
        for unit in &units[1] {
            units_collector.add_unit(unit);
        }

        let parents = units_collector
            .prospective_parents(NodeIndex(0))
            .expect("we should be able to retrieve parents");
        assert_eq!(parents.item_count(), 4);

        let new_units: Vec<_> = units[1]
            .iter()
            .map(|unit| (unit.hash(), unit.round()))
            .collect();
        let selected_parents: Vec<_> = parents.values().cloned().collect();
        assert_eq!(new_units, selected_parents);
    }

    #[test]
    fn following_inherits_units() {
        let n_members = NodeCount(4);
        let mut initial_units_collector = UnitsCollector::<Hasher64>::new_initial(n_members);
        let units = random_full_parent_units_up_to(1, n_members, 43);
        for unit in &units[0] {
            initial_units_collector.add_unit(unit);
        }
        let mut units_collector = UnitsCollector::from_previous(&initial_units_collector);
        for unit in units[1].iter().take(3) {
            units_collector.add_unit(unit);
        }

        let parents = units_collector
            .prospective_parents(NodeIndex(0))
            .expect("we should be able to retrieve parents");
        assert_eq!(parents.item_count(), 4);

        let mut new_units: Vec<_> = units[1]
            .iter()
            .take(3)
            .map(|unit| (unit.hash(), unit.round()))
            .collect();
        new_units.push((units[0][3].hash(), units[0][3].round()));
        let selected_parents: Vec<_> = parents.values().cloned().collect();
        assert_eq!(new_units, selected_parents);
    }
}
