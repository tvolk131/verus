//! Checked reference interfaces and nonvacuity goals, not cryptographic algorithms.
use super::*;
verus! {
#[derive(Copy, Clone)]
pub struct ValidationExampleKeychain { pub count: NodeCount }
impl Index for ValidationExampleKeychain {
    open spec fn lawful_index(&self) -> bool { true }
    open spec fn observed_index(&self) -> NodeIndex { NodeIndex(0) }
    fn index(&self) -> NodeIndex { NodeIndex(0) }
}
impl Keychain for ValidationExampleKeychain {
    type Signature = u8;
    open spec fn lawful_verification(&self) -> bool { true }
    open spec fn members(&self) -> NodeCount { self.count }
    open spec fn accepted(&self, bytes: Seq<u8>, signature: u8, index: NodeIndex) -> bool { signature == 37 }
    fn node_count(&self) -> NodeCount { self.count }
    fn sign(&self, msg: &[u8]) -> u8 { 37 }
    fn verify(&self, msg: &[u8], signature: &u8, index: NodeIndex) -> bool {
        index.0 < self.count.0 && *signature == 37
    }
}

pub struct Packet { pub index: NodeIndex, pub bytes: [u8; 1] }
impl Index for Packet {
    open spec fn lawful_index(&self) -> bool { true }
    open spec fn observed_index(&self) -> NodeIndex { self.index }
    fn index(&self) -> NodeIndex { self.index }
}
impl Signable for Packet {
    type Hash = [u8; 1];
    fn hash(&self) -> [u8; 1] { self.bytes }
}

pub fn validation_example_input<T: Signable>(value: T, signature: u8) -> (result: UncheckedSigned<T, u8>)
    ensures result@ == (value, signature),
{ UncheckedSigned { signable: value, signature } }

pub fn accepts(packet: Packet, keychain: ValidationExampleKeychain) -> (result: Result<Signed<Packet, ValidationExampleKeychain>, SignatureError<Packet, u8>>)
    requires packet.index.0 < keychain.count.0,
    ensures match result { Ok(signed) => signed@ == (packet, 37u8), _ => false },
{ validation_example_input(packet, 37).check(&keychain) }

pub fn rejects(packet: Packet, keychain: ValidationExampleKeychain, signature: u8) -> (result: Result<Signed<Packet, ValidationExampleKeychain>, SignatureError<Packet, u8>>)
    requires signature != 37 || packet.index.0 >= keychain.count.0,
    ensures match result { Err(error) => error@ == (packet, signature), _ => false },
{ validation_example_input(packet, signature).check(&keychain) }
}
