//! Universal application goals over native implementations.
use crate::{NodeCount, NodeIndex, NodeMap};
use vstd::prelude::*;
#[cfg(verus_keep_ghost)]
use vstd::std_specs::clone::{CloneIdentity, lemma_cloned_identity};

verus! {
broadcast use lemma_cloned_identity;

pub fn quorum_domain(n: NodeCount) -> (q: NodeCount)
    requires n.0 <= usize::MAX / 2,
    ensures q.0 as int == (2 * n.0 as int) / 3 + 1,
{ n.consensus_threshold() }

pub fn quorum_exact_domain(n: NodeCount) {
    // The two conjuncts are the fixed engine's certified native helper domain.
    // This goal normalizes that reported formula, without a callable assumption.
    assert((((n.0 as int * 2) <= usize::MAX) &&
        ((((n.0 as int * 2) / 3) as usize) as int + 1 <= usize::MAX))
        == (n.0 <= usize::MAX / 2));
}

pub fn empty_map<T: Clone>(n: NodeCount) -> (m: NodeMap<T>)
    ensures m@.len() == n.0,
        forall|i: int| 0 <= i < m@.len() ==> m@[i].is_none(),
{ NodeMap::with_size(n) }

pub fn positional_insert<T>(m: &mut NodeMap<T>, i: NodeIndex, value: T)
    requires i.0 < old(m)@.len(),
    ensures final(m)@ == old(m)@.update(i.0 as int, Some(value)),
{ m.insert(i, value); }

pub fn positional_get<T>(m: &NodeMap<T>, i: NodeIndex) -> (r: Option<&T>)
    requires i.0 < m@.len(),
    ensures r.is_some() == m@[i.0 as int].is_some(),
        r.is_some() ==> *r.unwrap() == m@[i.0 as int].unwrap(),
{ m.get(i) }

pub fn map_size<T>(m: &NodeMap<T>) -> (n: NodeCount)
    ensures n.0 == m@.len(),
{ m.size() }
}

#[verus_infer]
pub fn clone_content<T: CloneIdentity>(m: &NodeMap<T>) -> NodeMap<T> {
    m.clone()
}

verus! {
pub fn clone_preserves<T: CloneIdentity>(m: &NodeMap<T>) -> (r: NodeMap<T>)
    ensures r@ == m@,
{ clone_content(m) }
}
