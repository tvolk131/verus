import hashlib
import json
import datetime
import os
import pathlib
import sys

root = pathlib.Path('/Users/tommyvolk/.t3/worktrees/verus/t3-60978068')
manifest_path = pathlib.Path(__file__).with_name('INPUTS.json')
manifest = json.loads(manifest_path.read_text()) if manifest_path.exists() else {}
if sys.argv[1] == 'seal':
    for name in sys.argv[2:]:
        path = pathlib.Path(name) if name.startswith('/') else root / name
        content = path.read_bytes()
        observed = {'sha256': hashlib.sha256(content).hexdigest(), 'bytes': len(content)}
        if name in manifest and manifest[name] != observed:
            raise RuntimeError('INPUT DRIFT: ' + name)
        manifest[name] = observed
        print(observed['sha256'], observed['bytes'], name)
    manifest_path.write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
elif sys.argv[1] in ('check', 'finalize'):
    changed = []
    for name, expected in manifest.items():
        path = pathlib.Path(name) if name.startswith('/') else root / name
        actual = hashlib.sha256(path.read_bytes()).hexdigest() if path.exists() else 'MISSING'
        if actual != expected['sha256']:
            changed.append({'path': name, 'expected': expected['sha256'], 'actual': actual})
    print(json.dumps({'files': len(manifest), 'bytes': sum(item['bytes'] for item in manifest.values()), 'changed': changed, 'manifest_sha256': hashlib.sha256(manifest_path.read_bytes()).hexdigest()}, sort_keys=True))
    if sys.argv[1] == 'finalize':
        scratch = pathlib.Path(__file__).parent
        report = scratch / 'REPORT.md'
        now = datetime.datetime.now(datetime.timezone.utc)
        started = datetime.datetime.fromisoformat('2026-11-08T03:05:20+00:00')
        storage = os.statvfs(scratch)
        receipt = {'started_utc': started.isoformat(), 'finished_utc': now.isoformat(), 'elapsed_seconds': (now - started).total_seconds(), 'input_files': len(manifest), 'input_bytes': sum(item['bytes'] for item in manifest.values()), 'input_changes': changed, 'manifest_sha256': hashlib.sha256(manifest_path.read_bytes()).hexdigest(), 'report_bytes': report.stat().st_size, 'report_sha256': hashlib.sha256(report.read_bytes()).hexdigest(), 'hash_utility_sha256': hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(), 'free_disk_bytes': storage.f_bavail * storage.f_frsize, 'scratch_file_bytes_before_receipt': sum(path.stat().st_size for path in scratch.iterdir() if path.is_file()), 'builds_tests_verifier_solver_native_network_gitwrites_delegations': 0, 'parent_edits': 0, 'all18': 'OPEN'}
        assert not changed
        assert receipt['report_bytes'] <= 12288
        assert receipt['free_disk_bytes'] > 17179869184
        assert receipt['scratch_file_bytes_before_receipt'] < 8388608
        assert receipt['elapsed_seconds'] < 600
        receipt['metadata_failures'] = {'report_size_finalization_rejections': 2, 'failed_report_patch': 1}
        (scratch / 'EXIT.json').write_text(json.dumps(receipt, indent=2, sort_keys=True) + '\n')
        print(json.dumps(receipt, sort_keys=True))
