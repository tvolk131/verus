import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
PARENT = Path('/Users/tommyvolk/.t3/worktrees/verus/t3-60978068')
LEAF = Path('/private/tmp/verus-crash-consistency94-20261105/native-leaf-lookup-007')
RUNTIME = LEAF / 'midpoint-runtime-proposal/runtime'
SYSROOT = Path('/Users/tommyvolk/.rustup/toolchains/1.99.1-aarch64-apple-darwin')
BASELINE = Path('/private/tmp/verus-review94-byte-step-20261105-UyVDNcAR/preservation-baseline.json')
START = 1794098609.0

def digest(path):
    hasher = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            hasher.update(block)
    return hasher.hexdigest()

def record(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

def bounds():
    elapsed = time.time() - START
    size = sum(path.stat().st_size for path in ROOT.rglob('*') if path.is_file())
    free = shutil.disk_usage(ROOT).free
    status = dict(elapsed_seconds=elapsed, scratch_bytes=size, free_bytes=free)
    with (ROOT / 'resources.jsonl').open('a') as stream:
        stream.write(json.dumps(status) + '\n')
    if elapsed >= 900 or size >= 128 * 1024**2 or free <= 16 * 1024**3:
        raise RuntimeError('BOUND EXHAUSTED: ' + str(status))
    return status

def expected_bindings():
    expected = {}
    for line in (PARENT / 'evidence/redb-leaf-admission101/DESIGN-INPUTS.sha256').read_text().splitlines():
        value, name = line.split('  ', 1)
        expected[name] = value
    for name, value in [('DESIGN-REPORT.md', 'f754863bad0ec406f837aeccb8bd154c5b0130ed776726273e94c4bc195d1d5e'),
                        ('DESIGN-INPUTS.sha256', 'f07a77740a208cc7304709cef3e42f8b0bb5124ad93ec7bc3bdd10228ef08300')]:
        expected[str(PARENT / 'evidence/redb-leaf-admission101' / name)] = value
    binding = json.loads((LEAF / 'midpoint-runtime-proposal/runtime-binding.json').read_text())
    for name, value in binding['runtime'].items():
        expected[str(RUNTIME / name)] = value
    for name, value in binding['private_vstd_sources'].items():
        expected[str(LEAF / 'midpoint-runtime-proposal/source' / name)] = value
    historical = json.loads(BASELINE.read_text())
    for name, row in historical['sysroot_files'].items():
        expected[str(SYSROOT / name)] = row['sha256']
    invocation = json.loads((LEAF / 'runs/attempt-011/invocation.json').read_text())
    assert invocation['runtime'] == binding['runtime']
    assert binding['sysroot'] == str(SYSROOT)
    expected.update(invocation['inputs'])
    for ordinal in [9, 10, 11]:
        directory = LEAF / f'runs/attempt-{ordinal:03}'
        for artifact in directory.glob('*.rlib'):
            name = str(artifact)
            if name not in expected:
                expected[name] = digest(artifact)
    expected[str(BASELINE)] = digest(BASELINE)
    expected[str(PARENT / 'evidence/redb-leaf-admission101/PLAN.md')] = digest(PARENT / 'evidence/redb-leaf-admission101/PLAN.md')
    return expected

def authenticate(stage):
    bounds()
    inventory = ROOT / 'expected-bindings.json'
    expected = json.loads(inventory.read_text()) if inventory.exists() else expected_bindings()
    observed = {name: digest(name) for name in expected}
    mismatches = [name for name in expected if expected[name] != observed[name]]
    record(ROOT / f'authentication-{stage}.json', dict(expected_count=len(expected), observed=observed, mismatches=mismatches,
        sysroot_baseline_origin='historical preservation-baseline.json; independently hashed at entry',
        assessment_input_count=25))
    if mismatches:
        raise RuntimeError('AUTHENTICATION MISMATCH: ' + str(mismatches))
    if not inventory.exists():
        record(inventory, expected)
    bounds()

def run(label, source):
    ledger = ROOT / 'launches.jsonl'
    rows = ledger.read_text().splitlines() if ledger.exists() else []
    ordinal = len(rows) + 1
    if ordinal > 16:
        raise RuntimeError('APPLICATION LIMIT')
    output = ROOT / f'attempt-{ordinal:03}-{label}'
    output.mkdir()
    shutil.copyfile(source, output / 'input.rs')
    authenticate(f'pre-{ordinal:03}')
    original = json.loads((LEAF / 'runs/attempt-011/invocation.json').read_text())
    environment = original['environment'].copy()
    for variable, name in [('HOME', 'home'), ('TMPDIR', 'tmp'), ('CARGO_HOME', 'cargo-home'),
                           ('RUSTUP_HOME', 'rustup-home'), ('CARGO_TARGET_DIR', 'target'),
                           ('XDG_CACHE_HOME', 'cache'), ('VERUS_INFER_CACHE', 'cache')]:
        directory = output / name
        directory.mkdir(exist_ok=True)
        environment[variable] = str(directory)
    argv = [str(RUNTIME / 'verus'), '--sysroot', str(SYSROOT), '--edition=2024', '--crate-type=lib',
        '--crate-name', 'admission', '--no-cheating', '--triggers-mode', 'silent', '--multiple-errors', '12',
        '--rlimit', '60', '--num-threads', '1', '--output-json', '-C', 'debug-assertions=no']
    for name, ordinal_import, vir in [('leaf_decoder', 9, 'leaf-final.vir'),
                                      ('builder_step', 10, 'builder-final.vir'),
                                      ('lookup_client', 11, 'client-final.vir')]:
        argv += ['--extern', f'{name}={LEAF}/runs/attempt-{ordinal_import:03}/lib{name}.rlib',
                 '--import', f'{name}={LEAF}/{vir}']
    for ordinal_import in [9, 10, 11]:
        argv += ['-L', f'dependency={LEAF}/runs/attempt-{ordinal_import:03}']
    argv.append(str(output / 'input.rs'))
    invocation = dict(ordinal=ordinal, label=label, argv=argv, environment=environment, cwd=str(output),
        source_sha256=digest(output / 'input.rs'), timeout_seconds=60, full_scope=True,
        environment_delta='only writable storage paths relocated to fresh scratch; logical/release/sysroot/runtime bindings unchanged',
        resources=bounds(), input_inventory_sha256=digest(ROOT / 'expected-bindings.json'))
    record(output / 'invocation.json', invocation)
    with ledger.open('a') as stream:
        stream.write(json.dumps(invocation) + '\n')
    started = time.monotonic()
    try:
        process = subprocess.run(argv, cwd=output, env=environment, capture_output=True, timeout=60)
        stdout, stderr, code = process.stdout, process.stderr, process.returncode
    except subprocess.TimeoutExpired as failure:
        stdout, stderr, code = failure.stdout or b'', failure.stderr or b'', 'TIMEOUT'
    except OSError as failure:
        stdout, stderr, code = b'', str(failure).encode(), 'SPAWN_ERROR'
    (output / 'stdout.raw').write_bytes(stdout)
    (output / 'stderr.raw').write_bytes(stderr)
    result = dict(returncode=code, seconds=time.monotonic()-started, source_sha256=invocation['source_sha256'], resources=bounds())
    try:
        parsed = json.loads(stdout)
        record(output / 'verifier.json', parsed)
    except (ValueError, UnicodeDecodeError):
        result['stdout_json_parse'] = False
    record(output / 'result.json', result)
    print(json.dumps(dict(attempt=output.name, **result)))
    print(stderr.decode(errors='replace')[-16000:])
    print(stdout.decode(errors='replace')[-7000:])
    if code in ['TIMEOUT', 'SPAWN_ERROR']:
        raise RuntimeError('resource/spawn failure: no semantic credit')
    return code

if __name__ == '__main__':
    try:
        if sys.argv[1] == 'auth':
            authenticate(sys.argv[2])
            print('AUTHENTICATED')
        else:
            run(sys.argv[1], Path(sys.argv[2]))
    except Exception as failure:
        with (ROOT / 'setup-failures.jsonl').open('a') as stream:
            stream.write(json.dumps(dict(argv=sys.argv, error=repr(failure), time=time.time())) + '\n')
        raise
