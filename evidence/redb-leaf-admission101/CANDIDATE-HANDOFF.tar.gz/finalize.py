import difflib
import hashlib
import json
from pathlib import Path
import re
import shutil
import sys
import time

sys.dont_write_bytecode = True
from runner import ROOT, LEAF, PARENT, START, authenticate, bounds, digest, record

authenticate('exit')
bounds()
positive = ROOT / 'attempt-005-bitvector-witness-corrected/input.rs'
restored = ROOT / 'attempt-009-restored-full-positive/input.rs'
assert positive.read_bytes() == restored.read_bytes() == (ROOT / 'candidate.rs').read_bytes()
summary = []
required = ['leaf_split_required', 'leaf_fits_one_page', 'fit_then_lookup']
for directory in sorted(ROOT.glob('attempt-*')):
    invocation = json.loads((directory / 'invocation.json').read_text())
    result = json.loads((directory / 'result.json').read_text())
    data = json.loads((directory / 'stdout.raw').read_text())
    verification = data['verification-results']
    scope = data['verus-infer']['verification_scope']
    for name in required:
        assert any(row['rust_function'] == name and row['selected'] for row in scope['native_functions'])
    assert verification['is-verifying-entire-crate']
    assert not any(flag.startswith('--verify-') or flag in ['--compile', '--export'] for flag in invocation['argv'])
    assert invocation['argv'][invocation['argv'].index('--num-threads') + 1] == '1'
    summary.append(dict(attempt=directory.name, returncode=result['returncode'], seconds=result['seconds'],
        source_sha256=result['source_sha256'], verification=verification,
        checked_exec_bodies=scope['checked_exec_bodies'], checked_proof_bodies=scope['checked_proof_bodies'],
        failed_functions=data['verus-infer']['failed_functions'], full_scope_names=[row['rust_function'] for row in scope['native_functions']]))
    if invocation['ordinal'] in [1, 5, 9]:
        assert result['returncode'] == 0 and verification['success'] and verification['errors'] == 0
    if invocation['ordinal'] in [5, 9]:
        assert verification['verified'] == 8 and scope['checked_exec_bodies'] == 6

controls = []
for ordinal, label, original_assertion, wrong_assertion, expected_line in [
    (6, 'exact-fit', 'assert(equality);', 'assert(!equality);', 83),
    (7, 'count-cap', 'assert(!above);', 'assert(above);', 87),
    (8, 'singleton', 'assert(!split && !fits);', 'assert(!split ==> fits);', 90)]:
    directory = next(ROOT.glob(f'attempt-{ordinal:03}-*'))
    source = (directory / 'input.rs').read_text()
    expected = positive.read_text().replace(original_assertion, wrong_assertion)
    assert source == expected
    stderr = (directory / 'stderr.raw').read_text()
    assert stderr.count('error: assertion failed') == 1
    assert f'input.rs:{expected_line}:' in stderr
    assert wrong_assertion in stderr
    assert not re.search(r'precondition|panicked|timeout|error\[|unsupported|not supported', stderr, re.I)
    data = json.loads((directory / 'stdout.raw').read_text())
    assert data['verification-results']['verified'] == 7 and data['verification-results']['errors'] == 1
    assert data['verus-infer']['failed_functions'] == ['admission::scalar_boundaries']
    delta = ''.join(difflib.unified_diff(positive.read_text().splitlines(True), source.splitlines(True), fromfile='full-positive', tofile=directory.name))
    (ROOT / f'negative-{label}.diff').write_text(delta)
    controls.append(dict(label=label, baseline='attempt-005-bitvector-witness-corrected', negative=directory.name,
        only_delta='one ghost assertion; all executable calls/arguments/contracts/imports unchanged',
        intended_backend_assertion_line=expected_line, isolated_backend_failure=True, positive_assertion=original_assertion,
        negative_assertion=wrong_assertion))

snapshots = ROOT / 'source-context'
snapshots.mkdir()
copies = {
    'PLAN.md': PARENT / 'evidence/redb-leaf-admission101/PLAN.md',
    'DESIGN-REPORT.md': PARENT / 'evidence/redb-leaf-admission101/DESIGN-REPORT.md',
    'DESIGN-INPUTS.sha256': PARENT / 'evidence/redb-leaf-admission101/DESIGN-INPUTS.sha256',
    'native-btree_base.rs': LEAF / 'recovered-native/redb/src/tree_store/btree_base.rs',
    'imported-builder-reference.rs': LEAF.parent / 'native-builder-prefix-006/reference.rs',
    'imported-lookup-consumer.rs': LEAF / 'consumer.rs',
    'imported-leaf.rs': LEAF / 'leaf.rs',
}
for name, source in copies.items():
    shutil.copyfile(source, snapshots / name)
    assert digest(source) == digest(snapshots / name)
record(ROOT / 'source-context.json', {name: dict(original=str(source), sha256=digest(source)) for name, source in copies.items()})
resources = [json.loads(line) for line in (ROOT / 'resources.jsonl').read_text().splitlines()]
accounting = dict(verifier_applications=len(summary), maximum_applications=16, positive_applications=3,
    intended_semantic_negative_applications=3, ordinary_correction_applications=3,
    frontend_failures=1, witness_backend_correction_failures=2, spawn_failures=0, timeouts=0,
    runner_setup_failures=0, authentication_failures=0, metadata_correction_failures=0,
    diagnostic_missing_path_reads=[dict(path=str(LEAF / 'runner.py'), operation='sed read',
        outcome='missing path; corrected to existing run.py; nothing executed', setup_credit=False)],
    optional_absent_instruction_probes=['/private/AGENTS.md', '/private/tmp/AGENTS.md'],
    diagnostic_output_truncations='Two overbroad JSON prints were truncated by tool output; corrected with bounded key extraction, not verifier outcomes.',
    maximum_application_seconds=max(row['seconds'] for row in summary), total_application_seconds=sum(row['seconds'] for row in summary),
    elapsed_seconds=time.time()-START, sampled_peak_scratch_bytes=max(row['scratch_bytes'] for row in resources),
    sampled_minimum_free_bytes=min(row['free_bytes'] for row in resources), worker_process_limit=1,
    git_writes=0, network_actions=0, compiler_builds=0, cargo_builds=0, vstd_builds=0,
    native_application_executions=0, runtime_toolchain_cache_copies=0, subdelegations=0)
assert len(summary) == 9
record(ROOT / 'RESULTS.json', dict(status='BOUNDED_CONDITIONAL_CHECKED_BRIDGE_REVIEW_PENDING_NOT_ADOPTED',
    all18_final_redb_cells='OPEN', final_source_sha256=digest(ROOT / 'candidate.rs'),
    restored_byte_identical=True, attempts=summary, semantic_controls=controls, accounting=accounting,
    authentication=dict(expected_bindings=3517, assessment_inputs=25, phases='entry, every preexecution, exit',
        historical_sysroot_files=3340, private_vstd_source_files=141,
        additional_sysroot_anchor='Historical preservation-baseline.json as referenced by original run.py; this additional read-only input was content-hashed at entry and exit, not represented as one of the parent-authenticated 25.',
        source_context='Snapshots only; external runtime/toolchain/import binaries remain read-only in place.')))
print(json.dumps(accounting, indent=2))
