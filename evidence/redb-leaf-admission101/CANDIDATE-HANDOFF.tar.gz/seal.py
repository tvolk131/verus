import json
from pathlib import Path
import sys
import time

sys.dont_write_bytecode = True
from runner import ROOT, START, authenticate, bounds, digest, record

authenticate('exit-seal')
resource = bounds()
assert not list(ROOT.rglob('*.rlib'))
assert not list(ROOT.rglob('*.vir'))
results = json.loads((ROOT / 'RESULTS.json').read_text())
results['accounting']['final_preseal_elapsed_seconds'] = time.time() - START
results['accounting']['final_preseal_scratch_bytes'] = resource['scratch_bytes']
results['accounting']['sampled_peak_scratch_bytes'] = max(resource['scratch_bytes'], results['accounting']['sampled_peak_scratch_bytes'])
record(ROOT / 'RESULTS.json', results)
files = sorted(path for path in ROOT.rglob('*') if path.is_file() and path.name not in ['MANIFEST.sha256', 'SEAL.json'])
manifest = ROOT / 'MANIFEST.sha256'
manifest.write_text(''.join(f'{digest(path)}  {path.relative_to(ROOT)}\n' for path in files))
for line in manifest.read_text().splitlines():
    value, relative = line.split('  ', 1)
    assert digest(ROOT / relative) == value
record(ROOT / 'SEAL.json', dict(status='CONTENT_SEALED_REVIEW_PENDING_NO_ADOPTION',
    manifest_sha256=digest(manifest), manifest_entries=len(files), final_source_sha256=digest(ROOT / 'candidate.rs'),
    applications=9, complete_positive_obligations='8 verified / 0 errors', checked_exec_bodies=6,
    isolated_semantic_negatives=3, restored_byte_identical=True, all18='OPEN',
    elapsed_seconds=time.time()-START,
    scratch_bytes_before_seal_record=sum(path.stat().st_size for path in ROOT.rglob('*') if path.is_file()),
    free_bytes=resource['free_bytes'], cryptographic_signature=False,
    runtime_import_toolchain_distribution=False, parent_integration=False))
seal_hash = digest(ROOT / 'SEAL.json')
total = sum(path.stat().st_size for path in ROOT.rglob('*') if path.is_file())
assert total < 128 * 1024**2 and time.time() - START < 900
for path in ROOT.rglob('*'):
    if path.is_file():
        path.chmod(0o444)
for path in sorted((path for path in ROOT.rglob('*') if path.is_dir()), key=lambda path: len(path.parts), reverse=True):
    path.chmod(0o555)
ROOT.chmod(0o555)
print(json.dumps(dict(root=str(ROOT), seal_sha256=seal_hash, manifest_sha256=digest(manifest),
    total_bytes=total, elapsed_seconds=time.time()-START, application_count=9), indent=2))
