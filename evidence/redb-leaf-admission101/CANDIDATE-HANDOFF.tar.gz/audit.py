import hashlib
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent
NATIVE = Path('/private/tmp/verus-crash-consistency94-20261105/native-leaf-lookup-007/recovered-native/redb/src/tree_store/btree_base.rs')

def digest(data):
    return hashlib.sha256(data).hexdigest()

def body(source, name):
    start = source.index('fn ' + name + '(')
    opening = source.index('{', start)
    depth = 1
    position = opening + 1
    while depth:
        depth += (source[position] == '{') - (source[position] == '}')
        position += 1
    return source[opening:position], source.count('\n', 0, start) + 1

def tokens(source):
    return re.findall(r'[A-Za-z_][A-Za-z_0-9]*|[0-9]+|::|&&|<=|>=|==|!=|->|[^\s]', source)

native = NATIVE.read_text()
assert digest(NATIVE.read_bytes()) == 'c3a1f5ca0cefdde0bc7d1b40536bc4f2d68a8bce852115433621a8b37fb9ec60'
rows = []
sources = sorted(ROOT.glob('attempt-*/input.rs')) + [ROOT / 'candidate.rs']
for source_path in sources:
    source = source_path.read_text()
    assert not re.search(r'\b(assume|admit|axiom|external_body|assume_specification|external_fn_specification)\b', source)
    results = {}
    for name, expected_line in [('leaf_split_required', 1017), ('leaf_fits_one_page', 1034)]:
        original, line = body(native, name)
        candidate, candidate_line = body(source, name)
        assert line == expected_line
        assert original == candidate
        assert tokens(original) == tokens(candidate)
        results[name] = dict(native_line=line, candidate_line=candidate_line,
            body_byte_identical=True, proof_erased_tokens_identical=True,
            token_count=len(tokens(original)), body_sha256=digest(original.encode()),
            tokens_sha256=digest(json.dumps(tokens(original), separators=(',', ':')).encode()))
    assert 'fn fit_then_lookup' in source
    rows.append(dict(source=str(source_path), sha256=digest(source_path.read_bytes()), helpers=results))
report = dict(native_pin='c82ab865bb362bc4af067d332adc44978ff64813', native_sha256=digest(NATIVE.read_bytes()),
    method='Independent balanced-body extraction and lexical tokenization from authenticated complete original helper ranges; bodies contain no ghost code and are also byte-identical.',
    allowed_delta='pub(super) to pub; bool result binder; checked requires/ensures only. Native helper bodies have NO delta.',
    short_circuit_order='split evaluates !leaf_fits_one_page before num_pairs>1; fit evaluates imported required_bytes, capacity comparison, then u16::try_from(num_pairs).is_ok() only on capacity success.',
    gate='AUTHORED fit_then_lookup; native fit called with original page.len(); failed branch (false,None); successful branch asserts existing request in proof block and passes original page borrow unchanged to imported build_then_lookup.',
    new_trust_scan='no assume/admit/axiom/external_body/specification-binding tokens in any candidate', rows=rows)
(ROOT / 'native-preservation-audit.json').write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
print('AUDIT PASSED:', len(rows), 'complete source files')
