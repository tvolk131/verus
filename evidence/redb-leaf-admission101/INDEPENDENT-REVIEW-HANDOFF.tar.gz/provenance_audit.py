import hashlib
import json
from pathlib import Path

ROOT = Path('/private/tmp/verus-leaf-admission101-Vx4zWoSH')
OUT = Path(__file__).parent
LEAF = Path('/private/tmp/verus-crash-consistency94-20261105/native-leaf-lookup-007')
SYSROOT = Path('/Users/tommyvolk/.rustup/toolchains/1.99.1-aarch64-apple-darwin')

def digest(filename):
    return hashlib.sha256(Path(filename).read_bytes()).hexdigest()

expected = json.loads((ROOT / 'expected-bindings.json').read_text())
for row in json.loads((ROOT / 'source-context.json').read_text()).values():
    assert row['original'] not in expected or expected[row['original']] == row['sha256']
    expected[row['original']] = row['sha256']
binding = json.loads((LEAF / 'midpoint-runtime-proposal/runtime-binding.json').read_text())
baseline = json.loads(Path('/private/tmp/verus-review94-byte-step-20261105-UyVDNcAR/preservation-baseline.json').read_text())
classes = {}
for label, prefix, inventory in [
    ('runtime', LEAF / 'midpoint-runtime-proposal/runtime', binding['runtime']),
    ('private_vstd_sources', LEAF / 'midpoint-runtime-proposal/source', binding['private_vstd_sources']),
    ('historical_sysroot', SYSROOT, {name: row['sha256'] for name, row in baseline['sysroot_files'].items()}),
]:
    rows = {str(prefix / relative): checksum for relative, checksum in inventory.items()}
    assert all(expected[filename] == checksum for filename, checksum in rows.items())
    classes[label] = dict(count=len(rows), pins=rows)
assessment = {}
for line in (ROOT / 'source-context/DESIGN-INPUTS.sha256').read_text().splitlines():
    checksum, filename = line.split('  ', 1)
    assert expected[filename] == checksum
    assessment[filename] = checksum
assert len(assessment) == 25
provider_rows = []
for ordinal, crate, source in [
    (9, 'leaf_decoder', ROOT / 'source-context/imported-leaf.rs'),
    (10, 'builder_step', ROOT / 'source-context/imported-builder-reference.rs'),
    (11, 'lookup_client', ROOT / 'source-context/imported-lookup-consumer.rs'),
]:
    directory = LEAF / f'runs/attempt-{ordinal:03}'
    invocation = json.loads((directory / 'invocation.json').read_text())
    receipt = json.loads((directory / 'receipt.json').read_text())
    raw = json.loads((directory / 'stdout.txt').read_text())
    assert invocation['runtime'] == binding['runtime']
    assert digest(directory / 'input.rs') == digest(source) == invocation['input_sha256']
    assert receipt['returncode'] == 0 and receipt['runtime_unchanged']
    assert receipt['stdout_sha256'] == digest(directory / 'stdout.txt')
    assert receipt['stderr_sha256'] == digest(directory / 'stderr.txt')
    assert raw['verification-results']['success']
    assert all(expected[filename] == checksum for filename, checksum in invocation['inputs'].items())
    artifact = directory / ('lib' + crate + '.rlib')
    assert digest(artifact) == expected[str(artifact)]
    provider_rows.append(dict(ordinal=ordinal, crate=crate, source_sha256=digest(source),
                              invocation_sha256=digest(directory / 'invocation.json'),
                              receipt_sha256=digest(directory / 'receipt.json'),
                              runtime_equal=True, verification=raw['verification-results'],
                              artifacts=receipt['artifacts'], inputs=invocation['inputs']))
review = Path('/private/tmp/verus-leaf007-independent-review-tOKSrsOe/REPORT.md')
assert digest(review) == expected[str(review)]
preservation = json.loads((review.parent / 'preservation-comparison.json').read_text())
inherited_preservation = {key: preservation[key] for key in [
    'native_guard_count', 'original_native_path_preservation', 'original_native_git_metadata_continuity',
    'historical_shared_git_objectstore', 'recovered_content_matches',
    'symlink_referents_materialized_not_metadata_preserved']}
result = dict(classes=classes, assessment_pins=assessment, providers=provider_rows,
              inherited_review_sha256=digest(review), inherited_preservation=inherited_preservation,
              source_authentication_not_implementation_proof=True, runtime_adoption=False, all18='OPEN')
(OUT / 'dependency-provenance.json').write_text(json.dumps(result, sort_keys=True, indent=2) + '\n')
print('CLASSES', {label: row['count'] for label, row in classes.items()})
print('PROVIDER_SOURCES',[(row['crate'],row['source_sha256'],row['verification']) for row in provider_rows])
print('INHERITED_PRESERVATION',inherited_preservation)
print('PROVENANCE_SHA256',digest(OUT / 'dependency-provenance.json'))
