import datetime
import hashlib
import json
from pathlib import Path
import shutil
import stat
import sys
import tarfile

ROOT = Path('/private/tmp/verus-leaf-admission101-Vx4zWoSH')
OUT = Path(__file__).parent
PARENT = Path('/Users/tommyvolk/.t3/worktrees/verus/t3-60978068')

def digest_file(filename):
    digest = hashlib.sha256()
    with Path(filename).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()

expected = {}
for line in (ROOT / 'MANIFEST.sha256').read_text().splitlines():
    checksum, filename = line.split('  ', 1)
    assert filename not in expected and not filename.startswith('/') and '..' not in Path(filename).parts
    expected[filename] = checksum
assert len(expected) == 89
expected.update({
    'SEAL.json': '0fad372880af73d5a2ead948c597c6f7e79e471978dbb8524262e7d7c00a4ade',
    'MANIFEST.sha256': 'be580c234a6cafed157e8fae842a59467a5d9f3e827ad1ac81e38c255daeb046',
})
assert expected['candidate.rs'] == 'dbde2c19907bb6e579b593f8a0bc148f0e9325a8fcfc012999a5eed1895445ee'
assert expected['REPORT.md'] == '5db180799f2f5106d2888b3259ebed07bb5e8f9f59c2f07f904101175cbc262a'
members = {}
unusual = []
writable = []
for filename in ROOT.rglob('*'):
    mode = filename.lstat().st_mode
    if not stat.S_ISREG(mode) and not stat.S_ISDIR(mode):
        unusual.append(str(filename))
    if mode & 0o222:
        writable.append(str(filename))
    if stat.S_ISREG(mode):
        members[str(filename.relative_to(ROOT))] = digest_file(filename)
assert members == expected, 'candidate membership/hash mismatch'
assert not unusual and not writable
bindings = json.loads((ROOT / 'expected-bindings.json').read_text())
observed = {filename: digest_file(filename) for filename in bindings}
drift = {filename: {'historical': bindings[filename], 'current': observed[filename]}
         for filename in bindings if bindings[filename] != observed[filename]}
status = str(PARENT / 'evidence/redb-crash-consistency94/STATUS.json')
assert set(drift) <= {status}, drift
historical_auth = {}
for filename in sorted(ROOT.glob('authentication-*.json')):
    record = json.loads(filename.read_text())
    assert record['observed'] == bindings and record['mismatches'] == []
    assert record['expected_count'] == len(bindings)
    historical_auth[filename.name] = digest_file(filename)
archive = PARENT / 'evidence/redb-leaf-admission101/CANDIDATE-HANDOFF.tar.gz'
archived = {}
with tarfile.open(archive, 'r:gz') as bundle:
    for member in bundle.getmembers():
        if member.isfile():
            stream = bundle.extractfile(member)
            checksum = hashlib.sha256(stream.read()).hexdigest()
            parts = Path(member.name).parts
            relative = '/'.join(parts[1:]) if parts[0] == ROOT.name else member.name
            assert relative not in archived
            archived[relative] = checksum
assert archived == expected, ('archive mismatch', len(archived))
snapshot_originals = json.loads((ROOT / 'source-context.json').read_text())
for relative, row in snapshot_originals.items():
    assert digest_file(ROOT / 'source-context' / relative) == row['sha256']
    assert digest_file(row['original']) == row['sha256']
retained = {}
for local, source in [('CANDIDATE-REPORT.md', 'REPORT.md'), ('CANDIDATE-RESULTS.json', 'RESULTS.json'), ('candidate.rs', 'candidate.rs')]:
    retained[local] = digest_file(PARENT / 'evidence/redb-leaf-admission101' / local)
    assert retained[local] == expected[source]
free = shutil.disk_usage(OUT).free
scratch = sum(filename.stat().st_size for filename in OUT.rglob('*') if filename.is_file())
assert free > 16 * 1024**3 and scratch < 64 * 1024**2
record = dict(stage=sys.argv[1], utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              candidate_members=members, candidate_payloads=89, total_candidate_files=len(members),
              unexpected_members=unusual, writable_members=writable,
              historical_binding_count=len(bindings), immutable_matches=len(bindings)-len(drift),
              historical_bindings_sha256=digest_file(ROOT / 'expected-bindings.json'),
              current_bindings=observed, historical_metadata_drift=drift,
              historical_authentication_records=historical_auth, retained_copies=retained,
              archive_sha256=digest_file(archive), archive_all_91_byte_exact=True,
              source_context_originals=snapshot_originals, free_bytes=free, scratch_bytes=scratch,
              candidate_programs_executed=0, sealed_runners_executed=0, all18='OPEN')
destination = OUT / ('authentication-' + sys.argv[1] + '.json')
destination.write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
print(json.dumps({key: value for key, value in record.items() if key not in ['candidate_members', 'current_bindings', 'source_context_originals']}, indent=2))
print('AUTHENTICATION_RECORD_SHA256', digest_file(destination))
