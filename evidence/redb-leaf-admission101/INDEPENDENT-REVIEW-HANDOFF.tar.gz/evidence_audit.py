import difflib
import hashlib
import json
from pathlib import Path
import re

ROOT = Path('/private/tmp/verus-leaf-admission101-Vx4zWoSH')
OUT = Path(__file__).parent
LEAF = Path('/private/tmp/verus-crash-consistency94-20261105/native-leaf-lookup-007')

def digest(data):
    return hashlib.sha256(data).hexdigest()

def extract_body(source, name):
    match = re.search(r'\bfn\s+' + name + r'(?:<[^>]*>)?\s*\(', source)
    assert match
    opening = source.index('{', match.start())
    depth = 1
    ending = opening + 1
    while depth:
        depth += (source[ending] == '{') - (source[ending] == '}')
        ending += 1
    return source[opening:ending], source.count('\n', 0, match.start()) + 1

def tokens(source):
    return re.findall(r'[A-Za-z_][A-Za-z_0-9]*|[0-9]+|::|&&|<=|>=|==|!=|->|[^\s]', source)

def normalize_environment(environment, directory):
    return {key: value.replace(str(directory), '<ATTEMPT>') for key, value in environment.items()}

native = (ROOT / 'source-context/native-btree_base.rs').read_text()
candidate = (ROOT / 'candidate.rs').read_text()
helpers = {}
for name, original_line in [('leaf_split_required', 1017), ('leaf_fits_one_page', 1034)]:
    original_body, observed_line = extract_body(native, name)
    assert observed_line == original_line
    helpers[name] = dict(original_line=original_line, body_sha256=digest(original_body.encode()),
                         tokens=tokens(original_body), tokens_sha256=digest(json.dumps(tokens(original_body), separators=(',', ':')).encode()))
sources = sorted(ROOT.glob('attempt-*/input.rs')) + [ROOT / 'candidate.rs']
for filename in sources:
    source = filename.read_text()
    assert not re.search(r'\b(assume|admit|axiom|external_body|assume_specification|external_fn_specification|trusted|cfg)\b', source)
    for name in helpers:
        body, position = extract_body(source, name)
        original_body, ignored = extract_body(native, name)
        assert body.encode() == original_body.encode() and tokens(body) == tokens(original_body)
    assert extract_body(source, 'fit_then_lookup')[0] == extract_body(candidate, 'fit_then_lookup')[0]
provider = json.loads((LEAF / 'runs/attempt-011/invocation.json').read_text())
binding = json.loads((LEAF / 'midpoint-runtime-proposal/runtime-binding.json').read_text())
assert provider['runtime'] == binding['runtime']
baseline = json.loads((ROOT / 'attempt-005-bitvector-witness-corrected/invocation.json').read_text())
normalized_argv = baseline['argv'][:-1]
normalized_environment = normalize_environment(baseline['environment'], ROOT / 'attempt-005-bitvector-witness-corrected')
storage_names = {'HOME','TMPDIR','CARGO_HOME','RUSTUP_HOME','CARGO_TARGET_DIR','VERUS_INFER_CACHE','XDG_CACHE_HOME'}
rows = []
directories = sorted(ROOT.glob('attempt-*'))
assert len(directories) == 9
launches = [json.loads(line) for line in (ROOT / 'launches.jsonl').read_text().splitlines()]
assert len(launches) == 9
for ordinal, directory in enumerate(directories, 1):
    source_bytes = (directory / 'input.rs').read_bytes()
    source = source_bytes.decode()
    invocation = json.loads((directory / 'invocation.json').read_text())
    result = json.loads((directory / 'result.json').read_text())
    stdout = (directory / 'stdout.raw').read_bytes()
    stderr = (directory / 'stderr.raw').read_text()
    raw = json.loads(stdout)
    parsed = json.loads((directory / 'verifier.json').read_text())
    assert raw == parsed
    assert invocation['source_sha256'] == result['source_sha256'] == digest(source_bytes)
    assert invocation['ordinal'] == ordinal and invocation['full_scope'] is True
    assert launches[ordinal - 1] == invocation
    assert invocation['cwd'] == str(directory) and invocation['argv'][-1] == str(directory / 'input.rs')
    assert invocation['argv'][:-1] == normalized_argv
    assert normalize_environment(invocation['environment'], directory) == normalized_environment
    assert set(invocation['environment']) == set(provider['environment'])
    differences = {key for key in invocation['environment'] if invocation['environment'][key] != provider['environment'][key]}
    assert differences <= storage_names, differences
    assert all(invocation['environment'][key].startswith(str(directory) + '/') for key in differences)
    assert not any(flag.startswith(('--compile','--export','--verify-function','--verify-module','--verify-only','--no-verify')) for flag in invocation['argv'])
    assert invocation['timeout_seconds'] == 60 and result['seconds'] < 60
    assert invocation['input_inventory_sha256'] == digest((ROOT / 'expected-bindings.json').read_bytes())
    assert not result.get('timeout') and not result.get('spawn_error')
    inference = raw['verus-infer']
    scope = inference['verification_scope']
    verification = raw['verification-results']
    functions = scope['native_functions']
    expected_names = {'fit_then_lookup','leaf_fits_one_page','leaf_split_required','scalar_boundaries'}
    if ordinal > 1:
        expected_names |= {'caller_witness','concrete_caller_cases','caller_witness::__VERUS_REVEAL_INTERNAL__'}
    assert {item['rust_function'] for item in functions} == expected_names
    assert all(item['selected'] for item in functions)
    assert verification['is-verifying-entire-crate'] and scope['native_collection_completed']
    assert inference['requested_functions'] == 0 and inference['trusted_models'] == []
    assert inference['functions'] == [] and inference['generated_functions'] == 0
    assert inference['imported_inference_dependencies'] == []
    assert all(not any(notes.values()) for notes in raw['func-details'].values())
    assert not verification['encountered-vir-error']
    for key, value in inference.items():
        if key.endswith('_assistance'):
            assert not value
    if ordinal in [1, 5, 9]:
        expected_verified = 4 if ordinal == 1 else 8
        expected_bodies = 4 if ordinal == 1 else 6
        assert verification['success'] and verification['verified'] == expected_verified and verification['errors'] == 0
        assert scope['complete_selected_scope_verified'] and scope['checked_exec_bodies'] == expected_bodies
        assert result['returncode'] == 0 and not stderr
    else:
        assert not verification['success'] and not scope['complete_selected_scope_verified']
        assert scope['checked_exec_bodies'] == 0 and result['returncode'] == 1
    if ordinal in [6, 7, 8]:
        assert verification['verified'] == 7 and verification['errors'] == 1
        assert inference['failed_functions'] == ['admission::scalar_boundaries']
        assert stderr.count('error: assertion failed') == 1 and stderr.count('error: aborting') == 1
        old, new, line = {
            6: ('assert(equality);', 'assert(!equality);', 83),
            7: ('assert(!above);', 'assert(above);', 87),
            8: ('assert(!split && !fits);', 'assert(!split ==> fits);', 90),
        }[ordinal]
        assert source == candidate.replace(old, new, 1) and candidate.count(old) == 1
        assert f'input.rs:{line}:12' in stderr
    if ordinal in [3, 4]:
        assert verification['verified'] == 5 and verification['errors'] == 1
        assert inference['failed_functions'] == ['admission::caller_witness']
    if ordinal == 2:
        assert verification['verified'] == 0 and verification['errors'] == 0
        assert stderr.count('error[E0308]') == 3
    if ordinal in [5, 9]:
        assert source_bytes == (ROOT / 'candidate.rs').read_bytes()
        reveal = [item for item in functions if item['rust_function'].endswith('__VERUS_REVEAL_INTERNAL__')]
        assert len(reveal) == 1 and reveal[0]['body_status'] == 'selected_item_without_translated_body'
    delta = ''.join(difflib.unified_diff(candidate.splitlines(True), source.splitlines(True), fromfile='candidate.rs', tofile=directory.name + '/input.rs'))
    rows.append(dict(attempt=directory.name, ordinal=ordinal, source_sha256=digest(source_bytes),
                     invocation_sha256=digest((directory / 'invocation.json').read_bytes()),
                     result_sha256=digest((directory / 'result.json').read_bytes()),
                     stdout_sha256=digest(stdout), stderr_sha256=digest(stderr.encode()),
                     full_stderr=stderr, raw_verification=verification, raw_scope=scope,
                     runtime=raw['verus'], inference_status=inference['status'],
                     failed_functions=inference['failed_functions'], source_delta=delta,
                     source_body_identity=True, invocation_unfiltered=True,
                     environment_changed_keys=sorted(differences), seconds=result['seconds']))
report = dict(method='Independent data-only source/raw evidence inspection; no imports or execution of sealed code',
              helpers=helpers, all_ten_sources_preserve_complete_helper_bytes=True,
              all_ten_sources_same_authored_gate_body=True, no_new_candidate_trust_tokens=True,
              provider_runtime_equal=True, provider_environment_changes_only_scratch_storage=True,
              all_attempts_unfiltered=True, compile_export_requested=False,
              runtime_hashes=binding['runtime'], private_vstd_source_count=len(binding['private_vstd_sources']),
              midpoint_boundary=binding['new_trusted_boundary'], attempts=rows, all18='OPEN')
(OUT / 'source-and-attempt-audit.json').write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
for row in rows:
    print(row['attempt'], row['raw_verification'], 'checked_exec', row['raw_scope']['checked_exec_bodies'])
print('HELPERS',json.dumps(helpers))
print('AUDIT_SHA256',digest((OUT / 'source-and-attempt-audit.json').read_bytes()))
