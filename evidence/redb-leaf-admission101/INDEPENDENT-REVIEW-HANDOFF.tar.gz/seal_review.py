import datetime
import hashlib
import json
from pathlib import Path
import shutil

ROOT = Path(__file__).parent

def digest(filename):
    return hashlib.sha256(Path(filename).read_bytes()).hexdigest()

def write_record(filename, value):
    (ROOT / filename).write_text(json.dumps(value, sort_keys=True, indent=2) + '\n')

entry = json.loads((ROOT / 'authentication-entry.json').read_text())
exit_record = json.loads((ROOT / 'authentication-exit.json').read_text())
for key in ['candidate_members','current_bindings','historical_metadata_drift',
            'retained_copies','archive_sha256','source_context_originals']:
    assert entry[key] == exit_record[key]
assert len(entry['candidate_members']) == 91
assert entry['immutable_matches'] == exit_record['immutable_matches'] == 3516
assert (ROOT / 'REPORT.md').stat().st_size <= 24 * 1024
now = datetime.datetime.now(datetime.timezone.utc)
start = datetime.datetime(2026,11,8,1,2,50,tzinfo=datetime.timezone.utc)
elapsed = (now - start).total_seconds()
free = shutil.disk_usage(ROOT).free
assert 0 < elapsed < 720 and free > 16 * 1024**3
write_record('HANDOFF.json', dict(
    verdict='NO_NEW_BLOCKING_SOURCE_EVIDENCE_MISMATCH_FOR_CONDITIONAL_BRIDGE_ONLY',
    review_type='fresh independent source/evidence; no proof replay', all18='OPEN',
    original_native_path_preservation='FAILED', original_native_git_continuity='UNAVAILABLE',
    review_report_sha256=digest(ROOT / 'REPORT.md'),
    entry_authentication_sha256=digest(ROOT / 'authentication-entry.json'),
    exit_authentication_sha256=digest(ROOT / 'authentication-exit.json'),
    source_attempt_audit_sha256=digest(ROOT / 'source-and-attempt-audit.json'),
    dependency_provenance_sha256=digest(ROOT / 'dependency-provenance.json'),
    candidate_root='/private/tmp/verus-leaf-admission101-Vx4zWoSH',
    candidate_seal_sha256=entry['candidate_members']['SEAL.json'],
    candidate_manifest_sha256=entry['candidate_members']['MANIFEST.sha256'],
    candidate_source_sha256=entry['candidate_members']['candidate.rs'],
    author_report_sha256=entry['candidate_members']['REPORT.md'],
    candidate_members_authenticated_each_endpoint=91, payloads_authenticated_each_endpoint=89,
    historical_binding_count=3517, matching_immutable_historical_bindings=3516,
    historical_metadata_drift=entry['historical_metadata_drift'],
    candidate_and_current_operational_pins_equal_between_endpoints=True,
    runtime_files=9, private_vstd_sources=141, historical_sysroot_paths=3340,
    author_applications=9, review_verifier_solver_compiler_build_test_native_executions=0,
    full_positives=[5,9], positive_backend_verified=8, positive_checked_exec_bodies=6,
    selected_items=7, generated_bodyless_items=1,
    ordinary_correction_failures=[2,3,4], isolated_semantic_negatives=[6,7,8],
    negative_backend_verified=7, negative_backend_errors=1, negative_certified_bodies=0,
    compile_export_requested_by_admission101=False, unrequested_absence_is_export_refusal=False,
    parent_retention_is_acceptance=False, native_acceptance=False, final_acceptance=False,
    runtime_trust_adoption=False, parent_integration=False, cryptographic_signature=False,
    utc=now.isoformat(), conservative_start_utc=start.isoformat(), elapsed_seconds=elapsed,
    free_bytes=free, report_bytes=(ROOT / 'REPORT.md').stat().st_size,
    output_root=str(ROOT), no_network_git_writes_or_subdelegation=True))
files = sorted(filename for filename in ROOT.rglob('*') if filename.is_file())
assert not any(filename.name in ['MANIFEST.sha256','SEAL.json'] for filename in files)
manifest = ''.join(digest(filename) + '  ' + str(filename.relative_to(ROOT)) + '\n' for filename in files)
(ROOT / 'MANIFEST.sha256').write_text(manifest)
scratch = sum(filename.stat().st_size for filename in ROOT.rglob('*') if filename.is_file())
assert scratch < 64 * 1024**2
write_record('SEAL.json', dict(
    status='SEALED_INDEPENDENT_SOURCE_EVIDENCE_REVIEW_NO_ADOPTION_ALL18_OPEN',
    manifest_sha256=digest(ROOT / 'MANIFEST.sha256'), manifest_entries=len(files),
    report_sha256=digest(ROOT / 'REPORT.md'), handoff_sha256=digest(ROOT / 'HANDOFF.json'),
    entry_authentication_sha256=digest(ROOT / 'authentication-entry.json'),
    exit_authentication_sha256=digest(ROOT / 'authentication-exit.json'),
    utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), elapsed_seconds=elapsed,
    scratch_bytes_before_seal=scratch, free_bytes=free, cryptographic_signature=False,
    verifier_solver_compiler_build_test_native_executions=0, all18='OPEN'))
for line in (ROOT / 'MANIFEST.sha256').read_text().splitlines():
    checksum, relative = line.split('  ', 1)
    assert digest(ROOT / relative) == checksum
assert len(list(ROOT.rglob('*'))) == len(files) + 2
for filename in ROOT.iterdir():
    filename.chmod(0o444)
ROOT.chmod(0o555)
print('ROOT', ROOT)
for name in ['REPORT.md','HANDOFF.json','MANIFEST.sha256','SEAL.json']:
    print(name,digest(ROOT / name))
print('RESOURCES', json.dumps(dict(elapsed_seconds=elapsed, scratch_bytes=sum(filename.stat().st_size for filename in ROOT.iterdir()), free_bytes=free, report_bytes=(ROOT / 'REPORT.md').stat().st_size)))
