# Revision2 source-validator correction

The first revision2 validator application failed before any formatter operation:
its source-only prohibition on the text `tcx` also matched the harmless Rust
lifetime name `'tcx`. This was an overly broad audit predicate, not an executed
compiler/native failure or a semantic-negative control. The validator now checks
explicit query/context-use shapes instead. Those textual checks are not a Rust
AST or compiler-query proof.

Original raw exception remains in tool output chunk2576d1:

```
File "validate_origin113.py", line 64, in main
    assert forbidden not in raw_capture, forbidden
AssertionError: tcx
```

The Python application failed, although the enclosing shell returned0 because
its subsequent date command succeeded. No success is inferred from that wrapper.
This file is a documentary excerpt, not a reconstructed raw log. The corrected
application retains direct stdout/stderr and propagates the Python exit status.
