# Retained non-verifier exploration qualifications

Two guessed read paths did not exist:

- drop-effects-parent-002/handoff/source/rust_verify/src/checked_normal_drop.rs
- drop-effects-parent-002/handoff/fixtures/normal_writeback.rs

The actual bound engine source was read from staged/source/rust_verify/src/
checked_normal_drop.rs. The existing live fixture was inspected only to identify
the historical no_unwind/mask syntax; it was not run or claimed as native
evidence. Both failed reads are visible in the tool transcript. They launched
no verifier and changed no input.

The first authored runner snapshots had one extra terminal newline because the
apply_patch construction appended an empty split line. Their initial SHA256s
were 79417cd2face7b2fbf84fbf5e6024a38662516d819b74935df8fdbe7ae98eb65
and 8fc2aaeac0a57f20681741961e192344d16d6def1c05e178ddfc41003e9aa033.
Removing only that added blank line restored the exact executed script bytes:
runner-v1.py ac282126bd1b44f58b8974970446f0ec3ddf80d52a8fb8a154220cb842109d37;
runner-v2.py 0ab766b16711b93541d7e5feae394d837c14d9cee9208e82fae15afa285ecdc2.
The failed snapshot bytes are exactly each retained version plus one LF byte;
this has no proof or verifier-result significance.

Several combined tool responses were display-truncated. The five verifier
stdout/stderr files were never truncated on disk, and each was parsed in full
when producing APPLICATION-SUMMARY.json. No failed application was discarded.
