import difflib
import hashlib
import json
from pathlib import Path
import subprocess
import sys

sys.dont_write_bytecode = True
import runner

ROOT = runner.ROOT

def save(name, data):
    runner.save(ROOT / name, data)

def digest(data):
    return hashlib.sha256(data).hexdigest()

def extracted(source, marker):
    start = source.index(marker)
    opening = source.index('{', start)
    level = 1
    end = opening + 1
    while level:
        level += (source[end] == '{') - (source[end] == '}')
        end += 1
    return source[start:end], start, opening, end

def observations():
    assert not (ROOT / 'SEAL.json').exists()
    final = runner.authenticate(ROOT / 'authentication-final-exit.json')
    final_map = {x['path']: x for x in final['records']}
    applications = []
    source = (ROOT / 'native_lifecycle_nominal.rs').read_text()
    annotated = (ROOT / 'native_lifecycle_nominal_annotated.rs').read_text()
    restored = (ROOT / 'native_lifecycle_nominal_restored.rs').read_bytes()
    assert source.encode() == restored
    (ROOT / 'annotation.patch').write_text(''.join(difflib.unified_diff(
        source.splitlines(keepends=True), annotated.splitlines(keepends=True),
        fromfile='native_lifecycle_nominal.rs', tofile='native_lifecycle_nominal_annotated.rs')))
    for attempt in sorted(ROOT.glob('attempt-*')):
        raw = json.loads((attempt / 'stdout.txt').read_text())
        scope = raw['verus-infer']['verification_scope']
        phases = {}
        for phase in ['entry', 'preexecution', 'exit']:
            auth = json.loads((attempt / ('authentication-' + phase + '.json')).read_text())
            mismatches = [x['path'] for x in auth['records']
                          if final_map[x['path']]['sha256'] != x['sha256']]
            phases[phase] = {'count': len(auth['records']), 'mismatches_against_final': mismatches,
                             'runner_sha256': auth['runner']['sha256']}
            assert not mismatches
        result = json.loads((attempt / 'result.json').read_text())
        assert result['exit_code'] == 1 and not result['timed_out']
        assert not (attempt / 'candidate.vir').exists()
        assert scope['checked_exec_bodies'] == scope['checked_proof_bodies'] == 0
        applications.append({'directory': str(attempt), 'result': raw['verification-results'],
            'scope': scope, 'authentication': phases, 'elapsed_seconds': result['elapsed_seconds'],
            'export_exists': result['export_exists'], 'stderr_sha256': digest((attempt / 'stderr.txt').read_bytes())})
    save('APPLICATION-SUMMARY.json', {'applications': applications, 'charged': len(applications),
        'maximum': 12, 'original_native_executable_bodies_checked': 0,
        'authored_proof_bodies_checked': 0, 'authored_contract_clauses_attempted': 3,
        'backend_semantic_negatives': 0, 'positive_correspondence_results': 0,
        'restoration_byte_identical': True})

    native_records = []
    for snapshot in sorted((ROOT / 'native-snapshot').rglob('*.rs')):
        original = runner.NATIVE / snapshot.relative_to(ROOT / 'native-snapshot')
        same = snapshot.read_bytes() == original.read_bytes()
        native_records.append({'original': runner.identity(original),
                               'snapshot': runner.identity(snapshot), 'byte_identical': same})
        assert same
    save('NATIVE-SNAPSHOT.json', native_records)
    cached = (runner.NATIVE / 'tree_store/page_store/cached_file.rs').read_text()
    lru = (runner.NATIVE / 'tree_store/page_store/lru_cache.rs').read_text()
    fast = (runner.NATIVE / 'tree_store/page_store/fast_hash.rs').read_text()
    checks = []
    for native, marker in [(cached, 'pub(super) struct WritablePage'),
                           (cached, 'struct LRUWriteCache'),
                           (lru, 'pub struct LRUCache<T>'),
                           (fast, '    pub(crate) struct FastHasher64')]:
        block, start, _, end = extracted(native, marker)
        checks.append({'kind': 'layout', 'marker': marker, 'native_line': native[:start].count('\n') + 1,
                       'sha256': digest(block.encode()), 'baseline_contains_exact_text': block in source,
                       'annotated_contains_exact_text': block in annotated})
        assert block in source and block in annotated
    for native, marker in [(cached, '    pub(super) fn mem('),
                           (cached, '    pub(super) fn mem_mut('),
                           (cached, '    fn drop('),
                           (cached, '    fn return_value('),
                           (cached, '    fn take_value('),
                           (lru, '    pub(crate) fn get_mut('),
                           (fast, '        fn finish('),
                           (fast, '        fn write('),
                           (fast, '        fn write_u64(')]:
        block, start, opening, end = extracted(native, marker)
        body = native[opening:end]
        checks.append({'kind': 'executable_body', 'marker': marker,
                       'native_line': native[:start].count('\n') + 1,
                       'body_sha256': digest(body.encode()), 'baseline_contains_exact_body': body in source,
                       'annotated_contains_exact_body': body in annotated})
        assert body in source and body in annotated
    save('SOURCE-PRESERVATION.json', {'checks': checks, 'projected_native_exec_bodies': 9,
        'original_header_body_compiled': False, 'original_paged_write_body_compiled': False,
        'different_probe_crate_identity': True,
        'note': 'Exact layouts and executable text; dependency-cone projection, not original crate/glue identity.'})

    parent = json.loads((runner.REPO / 'evidence/redb-writablepage-lifecycle113/ENTRY-INPUTS.json').read_text())
    reconciliation = json.loads((runner.REPO / 'evidence/redb-writablepage-lifecycle113/DOCUMENT-RECONCILIATION.json').read_text())
    updates = {x['path']: x for x in reconciliation['expected_document_updates']}
    entry = json.loads((ROOT / 'parent-entry-audit.json').read_text())
    old = {x['actual']['path']: x['actual']['sha256'] for x in entry['records']}
    records = []
    for record in parent['records']:
        actual = runner.identity(record['path'])
        expected = updates.get(record['path'], {}).get('after_sha256', record['sha256'])
        records.append({'actual': actual, 'matches_entry': old[actual['path']] == actual['sha256'],
                        'matches_reconciled': actual['sha256'] == expected})
    save('parent-exit-audit.json', {'utc': runner.now().isoformat(), 'records': records,
        'count': len(records), 'mismatches': [x['actual']['path'] for x in records
                                           if not x['matches_entry'] or not x['matches_reconciled']]})
    assert all(x['matches_entry'] and x['matches_reconciled'] for x in records)
    argv = ['/usr/bin/otool', '-L', str(runner.RUNTIME / 'rust_verify'),
            str(runner.RUNTIME / 'z3'), str(runner.RUNTIME / 'libverus_builtin_macros.dylib')]
    cp = subprocess.run(argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    (ROOT / 'dependencies-stdout.txt').write_bytes(cp.stdout)
    (ROOT / 'dependencies-stderr.txt').write_bytes(cp.stderr)
    save('dependencies-invocation.json', {'argv': argv, 'exit_code': cp.returncode,
        'executable': runner.identity('/usr/bin/otool'),
        'note': 'Mach-O load names, not process tracing or an exhaustive shared-cache authentication.'})
    save('BOUNDARY-OBSERVATIONS.json', {'utc': runner.now().isoformat(), 'resources': runner.resources(),
        'baseline_source': runner.identity(ROOT / 'native_lifecycle_nominal.rs'),
        'annotated_source': runner.identity(ROOT / 'native_lifecycle_nominal_annotated.rs'),
        'restored_source': runner.identity(ROOT / 'native_lifecycle_nominal_restored.rs'),
        'first_clock': '2026-11-08T14:30:38Z', 'deadline': runner.DEADLINE.isoformat(),
        'first_verifier_application_utc': json.loads((ROOT / 'APPLICATIONS.json').read_text())[0]['utc'],
        'goal_service': 'BLOCKED last observed; not queried or resumed', 'all18': 'OPEN'})
    print(json.dumps({'applications': len(applications), 'parent_records': len(records),
                      'parent_mismatches': 0, 'primary_records_final': len(final['records']),
                      'resources': runner.resources()}))

def seal():
    assert (ROOT / 'REPORT.md').exists()
    assert runner.now() < runner.DEADLINE
    assert not (ROOT / 'SEAL.json').exists()
    records = [runner.identity(p) for p in sorted(ROOT.rglob('*')) if p.is_file()]
    data = {'schema': 'redb-writablepage113-lane-A-seal-v1', 'utc': runner.now().isoformat(),
            'records': records, 'resources': runner.resources(),
            'claim': 'Integrity handoff only; no native correctness or build proof.'}
    save('SEAL.json', data)
    (ROOT / 'SEAL.sha256').write_text(runner.identity(ROOT / 'SEAL.json')['sha256'] + '  SEAL.json\n')
    print(json.dumps({'seal': runner.identity(ROOT / 'SEAL.json'), 'payloads': len(records),
                      'resources': runner.resources()}))

if __name__ == '__main__':
    if sys.argv[1] == 'observe':
        observations()
    else:
        seal()
