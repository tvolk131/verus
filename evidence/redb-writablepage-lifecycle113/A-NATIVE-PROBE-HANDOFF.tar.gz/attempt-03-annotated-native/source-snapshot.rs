extern crate alloc;
use vstd::prelude::*;
#[path = "/private/tmp/verus-crash-consistency94-20261105/native-leaf-lookup-007/recovered-native/redb/src/sync.rs"]
mod sync;
pub mod tree_store {
    pub mod page_store {
        pub mod fast_hash {
            use core::hash::{BuildHasherDefault, Hasher};
            use std::collections::HashMap;
            use vstd::prelude::*;
            const K: u64 = 0xf135_7aea_2e62_a9c5;
            pub(crate) type FastHashMapU64<V> = HashMap<u64, V, BuildHasherDefault<FastHasher64>>;
            verus! {
            #[derive(Copy, Clone, Default, Eq, PartialEq)]
    pub(crate) struct FastHasher64 {
        hash: u64,
    }
    impl Hasher for FastHasher64 {
        fn finish(&self) -> u64 {
            #[cfg(target_pointer_width = "64")]
            const ROTATE: u32 = 26;
            #[cfg(target_pointer_width = "32")]
            const ROTATE: u32 = 15;

            self.hash.rotate_left(ROTATE)
        }

        fn write(&mut self, _bytes: &[u8]) {
            unreachable!("Only hashing 8 bytes is supported");
        }

        fn write_u64(&mut self, x: u64) {
            debug_assert_eq!(self.hash, 0);
            self.hash = x.wrapping_mul(K);
        }
    }
            }
        }
        pub mod lru_cache {
            use crate::tree_store::page_store::fast_hash::FastHashMapU64;
            use alloc::collections::VecDeque;
            use core::sync::atomic::{AtomicBool, Ordering};
            use vstd::prelude::*;
            verus! {
pub struct LRUCache<T> {
    // AtomicBool is the second chance flag. The u32 is the sequence number of the key's live
    // entry in lru_queue. remove() leaves the queue entry behind, and a later insert() of the
    // same key pushes a new one, so a queue entry whose sequence number does not match is stale.
    cache: FastHashMapU64<(T, AtomicBool, u32)>,
    lru_queue: VecDeque<(u64, u32)>,
    // Wrapping is harmless: a stale entry could only be mistaken for a live one if it survived
    // 2^32 inserts, and the queue is bounded to a small multiple of the cache size.
    next_seq: u32,
}
                impl<T> LRUCache<T> {
    pub(crate) fn get_mut(&mut self, key: u64) -> Option<&mut T> {
        if let Some((value, second_chance, _)) = self.cache.get_mut(&key) {
            second_chance.store(true, Ordering::Release);
            Some(value)
        } else {
            None
        }
    }
                }
            }
        }
        pub mod cached_file {
            use crate::sync::Mutex;
            use crate::tree_store::page_store::lru_cache::LRUCache;
            use alloc::sync::Arc;
            use vstd::prelude::*;
            verus! {
pub(super) struct WritablePage {
    buffer: Arc<Mutex<LRUWriteCache>>,
    offset: u64,
    data: Arc<[u8]>,
}
impl WritablePage {
    pub(super) fn mem(&self) -> &[u8] {
        &self.data
    }

    pub(super) fn mem_mut(&mut self) -> (result: &mut [u8])
        ensures
            result@ == (*old(self).data)@,
            (*final(self).data)@ == final(result)@,
            final(self).offset == old(self).offset,
    {
        Arc::get_mut(&mut self.data).unwrap()
    }
}
impl Drop for WritablePage {
    fn drop(&mut self) {
        self.buffer
            .lock()
            .unwrap()
            .return_value(self.offset, self.data.clone());
    }
}
struct LRUWriteCache {
    cache: LRUCache<Option<Arc<[u8]>>>,
}
                impl LRUWriteCache {
    fn return_value(&mut self, key: u64, value: Arc<[u8]>) {
        assert!(self.cache.get_mut(key).unwrap().replace(value).is_none());
    }
    fn take_value(&mut self, key: u64) -> Option<Arc<[u8]>> {
        if let Some(value) = self.cache.get_mut(key) {
            let result = value.take().unwrap();
            return Some(result);
        }
        None
    }
                }
            }
        }
    }
}

