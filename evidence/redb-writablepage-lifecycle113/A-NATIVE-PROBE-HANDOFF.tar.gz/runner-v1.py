import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
REPO = Path('/Users/tommyvolk/.t3/worktrees/verus/t3-60978068')
HIST = Path('/private/tmp/verus-crash-consistency94-20261105')
DROP = HIST / 'drop-effects-parent-002'
NATIVE = HIST / 'native-leaf-lookup-007/recovered-native/redb/src'
SYSROOT = Path('/Users/tommyvolk/.rustup/toolchains/1.99.1-aarch64-apple-darwin')
RUNTIME = DROP / 'runtime'
DEADLINE = datetime.datetime(2026, 11, 8, 14, 50, 38, tzinfo=datetime.timezone.utc)

def now():
    return datetime.datetime.now(datetime.timezone.utc)

def save(path, obj):
    path.write_text(json.dumps(obj, indent=2, sort_keys=True) + '\n')

def identity(path):
    path = Path(path)
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    stat = path.stat()
    return {'path': str(path), 'resolved': str(path.resolve()), 'bytes': stat.st_size,
            'sha256': h.hexdigest(), 'mode': oct(stat.st_mode & 0o777)}

def resources():
    used = sum(p.stat().st_size for p in ROOT.rglob('*') if p.is_file())
    free = shutil.disk_usage('/private/tmp').free
    result = {'utc': now().isoformat(), 'scratch_bytes': used, 'global_free_bytes': free}
    assert used <= 512 * 1024 * 1024, result
    assert free > 16 * 1024 * 1024 * 1024, result
    return result

def inputs():
    paths = [REPO / 'evidence/redb-writablepage-lifecycle113' / name for name in
             ['AUTHORIZATION.md', 'PLAN.md', 'ENTRY-INPUTS.json', 'DOCUMENT-RECONCILIATION.json']]
    paths += [REPO / 'evidence/redb-native-frontier112/DECISION-REPORT.md',
              REPO / 'evidence/redb-header-recovery111/PLAN.md',
              Path('/private/tmp/redb-header-recovery111-20261108T051418Z/COMBINED-INPUTS.json'),
              Path('/private/tmp/redb-header-recovery111-H-20261108T052400Z/runner.py'),
              Path('/private/tmp/redb-header-recovery111-H-20261108T052400Z/attempt-12-restored-positive/invocation.json'),
              HIST / 'native-recovery-reencoding-021/verifier-template.json',
              HIST / 'review-normal-drop-20261105-1956/REPORT.md', DROP / 'runtime-binding.json',
              DROP / 'handoff/normal-on-005/invocation.json',
              NATIVE.parent / 'AGENTS.md', NATIVE / 'sync.rs']
    paths += [NATIVE / 'tree_store/page_store' / name for name in
              ['cached_file.rs', 'page_manager.rs', 'lru_cache.rs', 'fast_hash.rs']]
    paths += [DROP / 'staged/source/rust_verify/src' / name for name in
              ['checked_normal_drop.rs', 'verifier.rs', 'driver.rs', 'rust_to_vir.rs']]
    paths += [REPO / 'source/vir/src/native_resource.rs',
              REPO / 'source/rust_verify/src/verifier.rs',
              REPO / 'source/rust_verify/src/import_export.rs']
    paths += sorted(RUNTIME.iterdir())
    paths += [Path(sys.executable), SYSROOT / 'bin/rustc']
    # The directly loaded compiler and proc-macro executable code is authenticated too.
    paths += list((SYSROOT / 'lib').glob('librustc_driver*.dylib'))
    paths += list((SYSROOT / 'libexec').glob('*proc-macro*'))
    paths += list((SYSROOT / 'lib/rustlib/aarch64-apple-darwin/lib').glob('libstd-*.dylib'))
    paths += [Path('/bin/zsh'), Path('/usr/bin/env'), Path('/usr/bin/otool'), Path('/usr/bin/shasum')]
    return sorted(set(p for p in paths if p.is_file()))

def authenticate(destination):
    records = [identity(p) for p in inputs()]
    candidate_sources = [identity(p) for p in sorted(ROOT.glob('*.rs'))]
    binding = json.loads((DROP / 'runtime-binding.json').read_text())
    checks = []
    for filename, expected in binding['runtime'].items():
        actual = identity(RUNTIME / filename)
        checks.append({'path': actual['path'], 'matches': actual['sha256'] == expected})
    for record in records:
        prefix = str(DROP / 'staged') + '/'
        if record['path'].startswith(prefix):
            key = record['path'][len(prefix):]
            expected = binding['source'].get(key)
            checks.append({'path': record['path'], 'matches': expected == record['sha256']})
    obj = {'utc': now().isoformat(), 'records': records, 'candidate_sources': candidate_sources,
           'runner': identity(Path(__file__)), 'binding_checks': checks,
           'resources': resources(), 'atomic_snapshot': False}
    save(destination, obj)
    assert all(c['matches'] for c in checks), checks
    return obj

def parent_audit():
    manifest = json.loads((REPO / 'evidence/redb-writablepage-lifecycle113/ENTRY-INPUTS.json').read_text())
    reconciliation = json.loads((REPO / 'evidence/redb-writablepage-lifecycle113/DOCUMENT-RECONCILIATION.json').read_text())
    updates = {v['path']: v for v in reconciliation['expected_document_updates']}
    records = []
    for old in manifest['records']:
        actual = identity(old['path'])
        expected = updates.get(old['path'], {}).get('after_sha256', old['sha256'])
        records.append({'expected': old, 'actual': actual, 'matches_reconciled': actual['sha256'] == expected})
    save(ROOT / 'parent-entry-audit.json', {'utc': now().isoformat(), 'records': records,
        'count': len(records), 'mismatches': [x['actual']['path'] for x in records if not x['matches_reconciled']]})

def run(label, source_name):
    ledger_path = ROOT / 'APPLICATIONS.json'
    ledger = json.loads(ledger_path.read_text()) if ledger_path.exists() else []
    assert len(ledger) < 12
    assert now() < DEADLINE - datetime.timedelta(seconds=95)
    directory = ROOT / ('attempt-%02d-%s' % (len(ledger) + 1, label))
    directory.mkdir()
    ledger.append({'number': len(ledger) + 1, 'label': label, 'utc': now().isoformat(),
                   'charged': True, 'directory': str(directory)})
    save(ledger_path, ledger)
    authenticate(directory / 'authentication-entry.json')
    for name in ['tmp', 'cache', 'cargo', 'target', 'rustup']:
        (directory / name).mkdir()
    source = ROOT / source_name
    # This is an evidence snapshot, not a source rewrite.
    (directory / 'source-snapshot.rs').write_bytes(source.read_bytes())
    export = directory / 'candidate.vir'
    assert not export.exists()
    argv = [str(RUNTIME / 'rust_verify'), '--sysroot', str(SYSROOT), '--edition=2024',
            '--target', 'aarch64-apple-darwin', '--crate-type=lib', '--crate-name',
            'native_lifecycle113', '--no-cheating', '--output-json', '--num-threads', '1',
            '--multiple-errors', '6', '--triggers-mode', 'silent', '--rlimit', '20']
    for name, file in [('vstd', 'libvstd.rlib'), ('verus_builtin', 'libverus_builtin.rlib'),
                       ('verus_builtin_macros', 'libverus_builtin_macros.dylib'),
                       ('verus_state_machines_macros', 'libverus_state_machines_macros.dylib')]:
        argv += ['--extern', name + '=' + str(RUNTIME / file)]
    argv += ['-L', 'dependency=' + str(RUNTIME), '--import', 'vstd=' + str(RUNTIME / 'vstd.vir'),
             '--experimental-checked-normal-drop', '--log', 'vir', '--log', 'vir-sst',
             '--export', str(export), str(source)]
    env = {'PATH': '/usr/bin:/bin:/usr/sbin:/sbin', 'RUSTC_BOOTSTRAP': '1',
           'DYLD_LIBRARY_PATH': str(SYSROOT / 'lib') + ':' + str(SYSROOT / 'lib/rustlib/aarch64-apple-darwin/lib'),
           'VERUS_Z3_PATH': str(RUNTIME / 'z3'), 'VERUS_IN_VARGO': '1', 'VERUS_USE_RUSTUP': '0',
           'RUSTUP_TOOLCHAIN': SYSROOT.name, 'RUSTUP_NO_UPDATE_CHECK': '1',
           'RUSTUP_HOME': str(directory / 'rustup'), 'TMPDIR': str(directory / 'tmp'),
           'XDG_CACHE_HOME': str(directory / 'cache'), 'CARGO_HOME': str(directory / 'cargo'),
           'CARGO_TARGET_DIR': str(directory / 'target'), 'CARGO_NET_OFFLINE': 'true',
           'GIT_CONFIG_GLOBAL': '/dev/null', 'GIT_CONFIG_NOSYSTEM': '1', 'GIT_OPTIONAL_LOCKS': '0',
           'RUST_MIN_STACK': '20971520', 'PYTHONDONTWRITEBYTECODE': '1'}
    save(directory / 'invocation.json', {'argv': argv, 'cwd': str(directory), 'environment': env,
        'timeout_seconds': 90, 'export_fresh_absent': True, 'source': identity(source),
        'no_internal_test_mode': True, 'builds': 0, 'no_scope_filter': True})
    authenticate(directory / 'authentication-preexecution.json')
    started = time.monotonic()
    with (directory / 'stdout.txt').open('wb') as out, (directory / 'stderr.txt').open('wb') as err:
        proc = subprocess.Popen(argv, cwd=directory, env=env, stdout=out, stderr=err, start_new_session=True)
        timed_out = False
        try:
            code = proc.wait(timeout=90)
        except subprocess.TimeoutExpired:
            timed_out = True
            os.killpg(proc.pid, signal.SIGKILL)
            code = proc.wait()
    authenticate(directory / 'authentication-exit.json')
    outputs = [identity(p) for p in sorted(directory.rglob('*')) if p.is_file()]
    result = {'utc': now().isoformat(), 'exit_code': code, 'timed_out': timed_out,
              'elapsed_seconds': time.monotonic() - started,
              'export_exists': export.exists(), 'outputs': outputs, 'resources': resources()}
    save(directory / 'result.json', result)
    print(json.dumps({'directory': str(directory), 'exit_code': code, 'export_exists': export.exists()}))
    print((directory / 'stderr.txt').read_text())
    print((directory / 'stdout.txt').read_text()[-6000:])

if __name__ == '__main__':
    if sys.argv[1] == 'entry':
        authenticate(ROOT / 'authentication-initial.json')
        parent_audit()
        print(json.dumps(resources()))
    elif sys.argv[1] == 'auth':
        authenticate(ROOT / ('authentication-' + sys.argv[2] + '.json'))
        print(json.dumps(resources()))
    else:
        run(sys.argv[1], sys.argv[2])
