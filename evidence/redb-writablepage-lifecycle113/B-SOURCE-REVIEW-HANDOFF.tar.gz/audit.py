import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import re

ROOT = Path(__file__).parent

def identity(path):
    candidate = Path(path)
    result = {"path": str(candidate), "realpath": os.path.realpath(candidate)}
    try:
        digest = hashlib.sha256()
        count = 0
        with candidate.open("rb") as stream:
            for payload in iter(lambda: stream.read(1024 * 1024), b""):
                digest.update(payload)
                count += len(payload)
        result.update(bytes=count, sha256=digest.hexdigest())
    except OSError as error:
        result["error"] = str(error)
    return result

def capture(label, argv):
    completed = subprocess.run(argv, capture_output=True, text=True)
    record = {"argv": argv, "returncode": completed.returncode,
              "stdout": completed.stdout, "stderr": completed.stderr}
    (ROOT / (label + ".json")).write_text(json.dumps(record, indent=2) + "\n")
    print(completed.stdout)
    print(completed.stderr)
    return record

phase = sys.argv[1]
paths = (ROOT / "INPUTS.txt").read_text().splitlines()
executables = ["/bin/zsh", "/bin/cat", "/bin/df", "/usr/bin/du",
               "/usr/bin/sed", "/usr/bin/nl", "/usr/bin/stat", "/usr/bin/mktemp",
               "/usr/bin/wc", "/usr/bin/find", "/usr/bin/file", "/usr/bin/readlink",
               "/usr/bin/otool", "/usr/bin/shasum", "/usr/bin/perl",
               "/usr/bin/git", "/Library/Developer/CommandLineTools/usr/bin/git",
               "/usr/bin/python3", sys.executable,
               "/Library/Developer/CommandLineTools/usr/bin/otool",
               "/Library/Developer/CommandLineTools/usr/bin/llvm-otool",
               "/Library/Developer/CommandLineTools/Library/Frameworks/Python3.framework/Versions/3.9/bin/python3.9",
               "/Library/Developer/CommandLineTools/Library/Frameworks/Python3.framework/Versions/3.9/Python3",
               "/Users/tommyvolk/.codex/packages/standalone/releases/0.166.0-aarch64-apple-darwin/codex-path/rg"]
result = {"phase": phase, "utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
          "python_executable": sys.executable, "inputs": [identity(path) for path in paths],
          "executables": [identity(path) for path in dict.fromkeys(executables)],
          "environment": {name: os.environ.get(name) for name in ["PATH", "SHELL", "LANG", "LC_ALL", "TMPDIR"]},
          "forbidden_executions": 0, "verifier_applications": 0}
(ROOT / (phase + "-identities.json")).write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({"phase": phase, "utc": result["utc"], "inputs": len(paths),
                  "input_errors": [entry for entry in result["inputs"] if "error" in entry],
                  "python_executable": sys.executable}, indent=2))
capture(phase + "-disk", ["/bin/df", "-k", "/private/tmp"])
if phase == "entry":
    capture("tool-load-commands", ["/usr/bin/otool", "-L"] + list(dict.fromkeys(executables)))
if phase == "inspect":
    for label, source, ranges in json.loads((ROOT / "READS.json").read_text()):
        lines = Path(source).read_text().splitlines()
        output = "SOURCE " + source + "\n" + json.dumps(identity(source)) + "\n"
        for start, end in ranges:
            output += "".join(str(index) + "\t" + lines[index - 1] + "\n"
                              for index in range(start, min(end, len(lines)) + 1))
        (ROOT / (label + ".txt")).write_text(output)
        print(label, len(output.encode()), "bytes retained")
if phase == "inventory":
    original = Path("/private/tmp/verus-crash-consistency94-20261105/native-recovery-reencoding-021")
    binding = json.loads((original / "runtime-binding.json").read_text())
    print("RECOVERY RUNTIME", json.dumps(binding["runtime"], indent=2))
    print("RECOVERY SOURCE ROOT CANDIDATES")
    for field, value in binding["inherited_binding"].items():
        if field != "private_vstd_sources":
            print(field, json.dumps(value)[:1000])
    capture("native-alias-search", [executables[-1], "-n", "write_header|read\\(0|read_direct\\(0|invalidate_cache\\(0|lock_header_exclusive|lock_stripes", paths[8], paths[9]])
    capture("recovery-source-search", [executables[-1], "-n", "source|vstd|root", str(original / "source-inputs.json"), str(original / "reproduce.py")])
if phase in ["boundaries", "boundaries-exit"]:
    parent = json.loads(Path(paths[2]).read_text())
    reconciliation = json.loads(Path(paths[3]).read_text())
    updates = {item["path"]: item for item in reconciliation["expected_document_updates"]}
    comparisons = []
    for expected in parent["records"]:
        actual = identity(expected["path"])
        actual["expected_sha256"] = expected["sha256"]
        actual["match"] = actual.get("sha256") == expected["sha256"]
        if not actual["match"] and expected["path"] in updates:
            actual["reconciled_document_update"] = actual.get("sha256") == updates[expected["path"]]["after_sha256"]
        comparisons.append(actual)
    prefix = "exit-" if phase == "boundaries-exit" else ""
    (ROOT / (prefix + "parent-baseline-comparison.json")).write_text(json.dumps(comparisons, indent=2) + "\n")
    print("PARENT", len(comparisons), "records", sum(item["match"] for item in comparisons), "matches",
          sum(item.get("reconciled_document_update", False) for item in comparisons), "reconciled",
          sum(not item["match"] and not item.get("reconciled_document_update", False) for item in comparisons), "unexpected")
    comparisons = []
    for kind in ["drop-effects-parent-002", "native-recovery-reencoding-021"]:
        base = Path("/private/tmp/verus-crash-consistency94-20261105") / kind
        binding = json.loads((base / "runtime-binding.json").read_text())
        for name, expected in binding["runtime"].items():
            actual = identity(base / "runtime" / name)
            actual.update(expected_sha256=expected, match=actual.get("sha256") == expected, role="not_executed_runtime")
            comparisons.append(actual)
        if "dependencies" in binding:
            for name, expected in binding["dependencies"].items():
                actual = identity(base / "artifacts" / name)
                actual.update(expected_sha256=expected, match=actual.get("sha256") == expected, role="not_imported_provider")
                comparisons.append(actual)
        source_map = binding.get("source", binding.get("inherited_binding", {}).get("source", {}))
        for path in paths:
            if "/staged/" in path and kind == "drop-effects-parent-002":
                relative = path.split("/staged/", 1)[1]
            elif "/midpoint-runtime-proposal/" in path and kind == "native-recovery-reencoding-021":
                relative = path.split("/midpoint-runtime-proposal/", 1)[1]
            else:
                continue
            actual = identity(path)
            expected = source_map.get(relative)
            actual.update(expected_sha256=expected, match=actual.get("sha256") == expected, role="selected_declared_source_binding")
            comparisons.append(actual)
    (ROOT / (prefix + "frozen-binding-comparison.json")).write_text(json.dumps(comparisons, indent=2) + "\n")
    print("BINDINGS", len(comparisons), "records", sum(item["match"] for item in comparisons), "matches")
    module_files = sorted({os.path.realpath(module.__file__) for module in list(sys.modules.values())
                           if getattr(module, "__file__", None) and Path(module.__file__).is_file()})
    modules = [identity(path) for path in module_files]
    (ROOT / (prefix + "python-loaded-module-identities.json")).write_text(json.dumps(modules, indent=2) + "\n")
    capture(prefix + "direct-load-commands", ["/Library/Developer/CommandLineTools/usr/bin/llvm-otool", "-L"] +
            list(dict.fromkeys(executables)) + [path for path in module_files if path.endswith(".so")])
    print("MODULES", len(modules))
if phase == "seal":
    entries = [identity(path) for path in sorted(ROOT.rglob("*")) if path.is_file() and path.name != "SEAL.json"]
    report_size = (ROOT / "REPORT.md").stat().st_size
    scratch_bytes = sum(entry.get("bytes", 0) for entry in entries)
    free_bytes = os.statvfs(ROOT).f_bavail * os.statvfs(ROOT).f_frsize
    assert report_size <= 20 * 1024
    assert scratch_bytes <= 128 * 1024 * 1024
    assert free_bytes > 16 * 1024 ** 3
    seal = {"utc": datetime.datetime.now(datetime.timezone.utc).isoformat(), "files": entries,
            "report_bytes": report_size, "scratch_payload_bytes": scratch_bytes, "free_bytes": free_bytes,
            "verifier_applications": 0, "builds": 0, "native_application_executions": 0}
    (ROOT / "SEAL.json").write_text(json.dumps(seal, indent=2) + "\n")
    print(json.dumps({key: value for key, value in seal.items() if key != "files"}, indent=2))

