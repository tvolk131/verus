# Parent113: original temporary-origin capture and fail-closed refusal candidate

## Status: partial, unbuilt source implementation; native bridge OPEN

This is a three-file scratch overlay on the historical normal-drop compiler
source, not an integrated engine or a new native producer. It implements the
concrete next action recommended by lane B: capture original anonymous drop
sites and Builder temporary/scope origins before the scalar normalizer rejects
them, then refuse to synthesize any resource effect. The actual requested
header-write-to-pending-cache correspondence remains unproved.

## Actual source changes

1. `checked_drop_origins.rs` retains per-definition, typed THIR ExprId/MIR Local
   observations from the existing actual Builder. Scope observations separately
   record their actual enclosing expression, nested expression and HirId. They
   are not joined by names/spans or merged merely because a local was reused.
   The two existing begin phases reset temporary observations. The existing
   named-local map and public get API are retained unchanged.
2. `as_temp.rs` records the original temporary after expr_into_dest, and records
   Scope origins around the unchanged recursive lowering. It retains the same
   BlockAnd result, storage/value scheduling and original temporary place. No
   explicit Rust drop is inserted and no native source statement is rewritten.
3. `checked_normal_drop.rs` inspects the actual elaborated body before normalize.
   Unbound drop roots retain block/place/projection/type observations, any
   available typed Builder origins, actual resolved destructor/drop-glue
   identities where monomorphic, and normal/cleanup/async/replace successors.
   Generic glue is explicitly unresolved. Missing temporary origins are not
   guessed: an unbound drop site is not automatically called a proven original
   temporary. Any such site produces program Err before the inherited prepare
   path can rewrite a body, generate its checked call/HasResolved assumption,
   retain a successful program or claim correspondence.

Capture identity and string rendering are diagnostic data, not an established
MIR-to-VIR/AstId/resource join. All raw unbound sites are refused. No capture
descriptor licenses Arc uniqueness, Mutex access, nested-field glue, Option
return, custom-hasher validity, cache identity or durable bytes. The inherited
scalar normal-drop rule remains experimental and unadopted; it is not broadened.

## Validation actually performed

`VALIDATION.json` records direct rustfmt syntax parsing for all three candidate
files, each exit0 with unchanged input hashes. These formatter operations are
not compiler typechecks, builds, verifier/solver runs, proof or native execution.
The direct formatter is endpoint-hashed before/after discovery; its complete
shared-library/OS/bootstrap closure is not authenticated. Raw stdout/stderr and
argv/environment are retained. Formatted stdout is not installed as source.

The source audit compares nine inherited function bodies byte-for-byte:
supported_type, drop_impl, normalize, account, rewrite_block,
checked_reference_frames, prepare, check_native and elaborated. The comparison
uses targeted function-body extraction, not a Rust AST equivalence checker.
It also checks typed expression/scope capture, disabled-mode guards, successor
inventory, refusal-before-normalize shape and absence of newly added assumed
resource effects. These are structural source assertions, not semantic controls.

All1483 selected parent baseline records reconcile:1481 exact matches and only
the two previously recorded GOAL/STATUS updates. The three historical source
files also match their saved baselines. Parent/native source and old sealed
evidence are unchanged. Capture of the original method-chain has NOT been
executed. Original native bodies checked0; verifier/solver applications0;
compiler builds/typechecks0; native semantic-negative controls0; new trust0.

## Remaining engineering and review questions

The candidate has not been typechecked against pinned rustc APIs or built into
the frozen compiler. An independent source review must examine the new query
ordering/glue resolution, scope/deduplicated-temp observations, missing-origin
handling, phase resets and strict-subset preservation. Actual source-coupled
positive and mutation controls, emitted provenance, GHOST/erased-EXEC agreement,
resource authority and admission remain missing. Existing type-translation
blockers can prevent the original method from even reaching this hook.

The meaningful next step is review of this exact source overlay and lane A's
actual native probe, followed by the smallest justified engine repair. A build
or integration is still separately outside authority; no assumption may replace
missing semantics. This is neither final acceptance nor completion of E2 or a
database cell. All18 remain OPEN; original-path FAILED, Git UNAVAILABLE,
compiler/source UNESTABLISHED and inherited TCB qualifications are unchanged.

## Accounting and preservation

Parent source investigation began14:40:30Z, inside round113's14:27:06–15:17:06Z
window. Only three existing source files were copied, not a compiler/toolchain/
runtime/cache. Parent source edits and builds are forbidden and were not done.
New authored content uses apply_patch. The candidate and report will be frozen
before independent review; later small corrections, if any, need a separate
recorded delta. Every source/probe failure remains retained. A targeted read of
nonexistent historical rustc_middle source returned missing-path diagnostics;
no compiler or proof failure is inferred. No subdelegation by this source script.
