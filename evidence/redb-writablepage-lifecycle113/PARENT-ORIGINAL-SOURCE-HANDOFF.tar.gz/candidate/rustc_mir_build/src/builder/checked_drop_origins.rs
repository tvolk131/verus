use rustc_hir::HirId;
use rustc_hir::def_id::LocalDefId;
use rustc_middle::mir::Local;
use rustc_middle::thir::ExprId;
use std::collections::HashMap;
use std::sync::Mutex;
use std::sync::atomic::{AtomicBool, Ordering};

static ENABLED: AtomicBool = AtomicBool::new(false);
static NATIVE: AtomicBool = AtomicBool::new(false);
static ORIGINS: Mutex<Option<HashMap<LocalDefId, Vec<(HirId, Local)>>>> = Mutex::new(None);
static TEMPORARIES: Mutex<Option<HashMap<LocalDefId, Vec<TemporaryOrigin>>>> = Mutex::new(None);

#[derive(Clone, Debug)]
pub struct TemporaryOrigin {
    pub expression: ExprId,
    pub local: Local,
    pub scope: Option<TemporaryScope>,
}

#[derive(Clone, Debug)]
pub struct TemporaryScope {
    pub hir_id: HirId,
    pub nested_expression: ExprId,
}

pub fn begin(native: bool) {
    *ORIGINS.lock().unwrap() = Some(HashMap::new());
    *TEMPORARIES.lock().unwrap() = Some(HashMap::new());
    NATIVE.store(native, Ordering::SeqCst);
    ENABLED.store(true, Ordering::SeqCst);
}

pub fn native() -> bool {
    NATIVE.load(Ordering::SeqCst)
}

pub fn get(def: LocalDefId) -> Option<Vec<(HirId, Local)>> {
    ORIGINS.lock().unwrap().as_ref()?.get(&def).cloned()
}

pub fn get_temporaries(def: LocalDefId) -> Option<Vec<TemporaryOrigin>> {
    TEMPORARIES.lock().unwrap().as_ref()?.get(&def).cloned()
}

pub(super) fn retain_temporary(def: LocalDefId, expression: ExprId, local: Local) {
    if !ENABLED.load(Ordering::SeqCst) {
        return;
    }
    TEMPORARIES.lock().unwrap().as_mut().unwrap().entry(def).or_default()
        .push(TemporaryOrigin { expression, local, scope: None });
}

pub(super) fn retain_temporary_scope(
    def: LocalDefId,
    expression: ExprId,
    nested_expression: ExprId,
    local: Local,
    hir_id: HirId,
) {
    if !ENABLED.load(Ordering::SeqCst) {
        return;
    }
    TEMPORARIES.lock().unwrap().as_mut().unwrap().entry(def).or_default()
        .push(TemporaryOrigin {
            expression,
            local,
            scope: Some(TemporaryScope { hir_id, nested_expression }),
        });
}

pub(super) fn retain(builder: &super::Builder<'_, '_>) {
    if !ENABLED.load(Ordering::SeqCst) {
        return;
    }
    let origins = builder.var_indices.iter().filter_map(|(var, locals)| {
        match locals {
            super::LocalsForNode::One(local) => Some((var.0, *local)),
            super::LocalsForNode::ForGuard { .. } => None,
        }
    }).collect();
    let previous = ORIGINS.lock().unwrap().as_mut().unwrap().insert(builder.def_id, origins);
    assert!(previous.is_none());
}
