use rustc_hir::HirId;
use rustc_hir::def_id::LocalDefId;
use rustc_middle::mir::Local;
use std::collections::HashMap;
use std::sync::Mutex;
use std::sync::atomic::{AtomicBool, Ordering};

static ENABLED: AtomicBool = AtomicBool::new(false);
static NATIVE: AtomicBool = AtomicBool::new(false);
static ORIGINS: Mutex<Option<HashMap<LocalDefId, Vec<(HirId, Local)>>>> = Mutex::new(None);

pub fn begin(native: bool) {
    *ORIGINS.lock().unwrap() = Some(HashMap::new());
    NATIVE.store(native, Ordering::SeqCst);
    ENABLED.store(true, Ordering::SeqCst);
}

pub fn native() -> bool {
    NATIVE.load(Ordering::SeqCst)
}

pub fn get(def: LocalDefId) -> Option<Vec<(HirId, Local)>> {
    ORIGINS.lock().unwrap().as_ref()?.get(&def).cloned()
}

pub(super) fn retain(builder: &super::Builder<'_, '_>) {
    if !ENABLED.load(Ordering::SeqCst) {
        return;
    }
    let origins = builder.var_indices.iter().filter_map(|(var, locals)| {
        match locals {
            super::LocalsForNode::One(local) => Some((var.0, *local)),
            super::LocalsForNode::ForGuard { .. } => None,
        }
    }).collect();
    let previous = ORIGINS.lock().unwrap().as_mut().unwrap().insert(builder.def_id, origins);
    assert!(previous.is_none());
}
