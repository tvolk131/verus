use crate::context::Context;
use rustc_hir::HirId;
use rustc_hir::def_id::{DefId, LocalDefId};
use rustc_middle::mir::{self, Body, Operand, PlaceElem, Rvalue, StatementKind, TerminatorKind};
use rustc_middle::ty::{self, Ty, TyCtxt};
use rustc_mir_build_verus::builder::checked_drop_origins;
use std::collections::{HashMap, HashSet};
use std::sync::Mutex;
use vir::ast::*;
use vir::def::Spanned;
use vir::messages::{AstId, Span};

#[derive(Clone, Debug, PartialEq, Eq)]
enum Type {
    Unit,
    U64,
    Ref(Box<Type>),
    Struct(String),
}

#[derive(Clone, Debug, PartialEq, Eq, Hash)]
enum Projection {
    Deref,
    Field(usize),
}

#[derive(Clone, Debug, PartialEq, Eq, Hash)]
struct Place {
    root: usize,
    projection: Vec<Projection>,
}

#[derive(Clone, Debug, PartialEq, Eq)]
enum Value {
    Copy(Place),
    Move(Place),
    Number(u64),
    Ref(Place),
    Struct(String, Vec<Value>),
}

#[derive(Clone, Debug, PartialEq, Eq)]
enum Operation {
    Assign(Place, Value),
    Drop(Place, String),
    Return,
}

#[derive(Clone, Debug, PartialEq, Eq)]
struct Program {
    types: Vec<Type>,
    arg_count: usize,
    operations: Vec<Operation>,
}

#[derive(Clone)]
struct Capture {
    program: Result<Program, String>,
    origins: HashMap<HirId, usize>,
}

#[derive(Default)]
struct State {
    enabled: bool,
    native: bool,
    captures: HashMap<String, Capture>,
    expected: HashMap<String, Program>,
    effects: usize,
    correspondence: bool,
}

static STATE: Mutex<Option<State>> = Mutex::new(None);

fn identity(tcx: TyCtxt<'_>, def: DefId) -> String {
    format!("{:?}", tcx.def_path_hash(def))
}

pub(crate) fn begin() {
    *STATE.lock().unwrap() = Some(State { enabled: true, ..State::default() });
    checked_drop_origins::begin(false);
}

pub(crate) fn enabled() -> bool {
    STATE.lock().unwrap().as_ref().is_some_and(|state| state.enabled)
}

pub(crate) fn begin_native() {
    let mut guard = STATE.lock().unwrap();
    let state = guard.as_mut().unwrap();
    state.native = true;
    state.captures.clear();
    checked_drop_origins::begin(true);
}

pub(crate) fn effects_used() -> bool {
    STATE.lock().unwrap().as_ref().is_some_and(|state| state.effects != 0)
}

pub(crate) fn correspondence_checked() -> bool {
    STATE.lock().unwrap().as_ref().is_some_and(|state| state.correspondence)
}

fn supported_type<'tcx>(tcx: TyCtxt<'tcx>, typ: Ty<'tcx>) -> Result<Type, String> {
    match typ.kind() {
        ty::Tuple(fields) if fields.is_empty() => Ok(Type::Unit),
        ty::Uint(ty::UintTy::U64) => Ok(Type::U64),
        ty::Ref(_, inner, mir::Mutability::Mut) => {
            Ok(Type::Ref(Box::new(supported_type(tcx, *inner)?)))
        }
        ty::Adt(adt, args) if adt.is_struct() && !adt.repr().packed()
            && args.iter().all(|arg| matches!(arg.kind(), ty::GenericArgKind::Lifetime(_))) =>
        {
            for field in &adt.non_enum_variant().fields {
                match field.ty(tcx, args).skip_norm_wip().kind() {
                    ty::Uint(ty::UintTy::U64) => {}
                    ty::Ref(_, inner, mir::Mutability::Mut)
                        if matches!(inner.kind(), ty::Uint(ty::UintTy::U64)) => {}
                    _ => return Err("only u64 and &mut u64 fields without field glue are supported".into()),
                }
            }
            Ok(Type::Struct(identity(tcx, adt.did())))
        }
        _ => Err(format!("unsupported checked normal destruction type: {typ:?}")),
    }
}

struct Normalizer<'a, 'tcx> {
    tcx: TyCtxt<'tcx>,
    body: &'a Body<'tcx>,
    locals: HashMap<mir::Local, usize>,
    types: Vec<Type>,
    aliases: HashMap<mir::Local, Value>,
    ghost: HashSet<mir::Local>,
}

impl<'a, 'tcx> Normalizer<'a, 'tcx> {
    fn local(&mut self, local: mir::Local) -> Result<usize, String> {
        if let Some(index) = self.locals.get(&local) {
            return Ok(*index);
        }
        let typ = supported_type(self.tcx, self.body.local_decls[local].ty)?;
        let index = self.types.len();
        self.types.push(typ);
        self.locals.insert(local, index);
        Ok(index)
    }

    fn place(&mut self, place: mir::Place<'tcx>) -> Result<Place, String> {
        if self.ghost.contains(&place.local) {
            return Err("ghost place reaches executable destruction".into());
        }
        if let Some(alias) = self.aliases.get(&place.local).cloned() {
            let (mut base, skip) = match alias {
                Value::Ref(base) if matches!(place.projection.first(), Some(PlaceElem::Deref)) => (base, 1),
                Value::Copy(base) | Value::Move(base) => (base, 0),
                _ => return Err("unsupported reborrow alias projection".into()),
            };
            for element in place.projection.iter().skip(skip) {
                base.projection.push(match element {
                    PlaceElem::Deref => Projection::Deref,
                    PlaceElem::Field(index, _) => Projection::Field(index.as_usize()),
                    _ => return Err("unsupported reborrow projection".into()),
                });
            }
            return Ok(base);
        }
        let root = self.local(place.local)?;
        let projection = place.projection.iter().map(|element| match element {
            PlaceElem::Deref => Ok(Projection::Deref),
            PlaceElem::Field(index, _) => Ok(Projection::Field(index.as_usize())),
            _ => Err("unsupported destruction place projection".into()),
        }).collect::<Result<Vec<_>, String>>()?;
        Ok(Place { root, projection })
    }

    fn operand(&mut self, operand: &Operand<'tcx>) -> Result<Value, String> {
        if let Operand::Copy(place) | Operand::Move(place) = operand {
            if place.projection.is_empty() {
                if let Some(alias) = self.aliases.get(&place.local) {
                    return Ok(alias.clone());
                }
            }
        }
        match operand {
            Operand::Copy(place) => Ok(Value::Copy(self.place(*place)?)),
            Operand::Move(place) => Ok(Value::Move(self.place(*place)?)),
            Operand::Constant(constant) => {
                if !matches!(constant.const_.ty().kind(), ty::Uint(ty::UintTy::U64)) {
                    return Err("only literal u64 constructor operands are supported".into());
                }
                let scalar = constant.const_.try_to_scalar_int().ok_or("nonliteral constructor operand")?;
                Ok(Value::Number(scalar.to_u64()))
            }
            _ => Err("unsupported destruction operand".into()),
        }
    }

    fn value(&mut self, value: &Rvalue<'tcx>) -> Result<Value, String> {
        match value {
            Rvalue::Use(operand, _) => self.operand(operand),
            Rvalue::Ref(_, mir::BorrowKind::Mut { .. }, place) => Ok(Value::Ref(self.place(*place)?)),
            Rvalue::Aggregate(kind, operands) => {
                let mir::AggregateKind::Adt(def, variant, args, _, active_field) = &**kind else {
                    return Err("unsupported aggregate in destruction path".into());
                };
                if variant.as_usize() != 0 || active_field.is_some() {
                    return Err("enum/union destruction is unsupported".into());
                }
                let typ = self.tcx.adt_def(*def);
                supported_type(self.tcx, Ty::new_adt(self.tcx, typ, args))?;
                Ok(Value::Struct(identity(self.tcx, *def), operands.iter()
                    .map(|operand| self.operand(operand)).collect::<Result<_, _>>()?))
            }
            _ => Err(format!("unsupported operation in destruction path: {value:?}")),
        }
    }

    fn ghost_operand(&self, operand: &Operand<'tcx>) -> bool {
        match operand {
            Operand::Copy(place) | Operand::Move(place) => self.ghost.contains(&place.local)
                || place.ty(&self.body.local_decls, self.tcx).ty.is_unit(),
            Operand::Constant(constant) => constant.const_.ty().is_unit(),
            _ => false,
        }
    }

    fn ghost_value(&self, value: &Rvalue<'tcx>) -> bool {
        match value {
            Rvalue::Use(operand, _) => self.ghost_operand(operand),
            Rvalue::Ref(_, _, place) => self.ghost.contains(&place.local),
            Rvalue::Aggregate(_, operands) => operands.iter().all(|operand| self.ghost_operand(operand)),
            _ => false,
        }
    }
}

fn drop_impl<'tcx>(tcx: TyCtxt<'tcx>, typ: Ty<'tcx>) -> Result<DefId, String> {
    supported_type(tcx, typ)?;
    let ty::Adt(adt, args) = typ.kind() else {
        return Err("only whole concrete struct drops are supported".into());
    };
    let destructor = adt.destructor(tcx).ok_or("missing custom destructor")?;
    if !destructor.did.is_local() {
        return Err("imported destructors are unsupported".into());
    }
    for field in &adt.non_enum_variant().fields {
        if field.ty(tcx, args).skip_norm_wip().needs_drop(tcx, ty::TypingEnv::fully_monomorphized()) {
            return Err("nested field drop glue is unsupported".into());
        }
    }
    let instance = ty::Instance::resolve_drop_glue(tcx, typ);
    let glue = tcx.instance_mir(instance.def);
    let mut seen = HashSet::new();
    let mut block = mir::START_BLOCK;
    let mut calls = 0;
    let mut receivers = HashSet::new();
    loop {
        if !seen.insert(block) {
            return Err("cyclic drop glue".into());
        }
        let data = &glue.basic_blocks[block];
        for statement in &data.statements {
            match &statement.kind {
                StatementKind::Assign(assignment) => match &assignment.1 {
                    Rvalue::Ref(_, mir::BorrowKind::Mut { .. }, place)
                        if place.local == mir::Local::from_usize(1)
                        && place.projection.as_ref() == [PlaceElem::Deref]
                        && assignment.0.projection.is_empty() => { receivers.insert(assignment.0.local); }
                    Rvalue::Use(Operand::Copy(place) | Operand::Move(place), _)
                        if place.local == mir::Local::from_usize(1)
                        && place.projection.is_empty() && assignment.0.projection.is_empty() =>
                    { receivers.insert(assignment.0.local); }
                    _ => return Err("unsupported instructions in concrete drop glue".into()),
                },
                StatementKind::StorageLive(_) | StatementKind::StorageDead(_)
                | StatementKind::Nop => {}
                _ => return Err("unsupported statements in concrete drop glue".into()),
            }
        }
        match &data.terminator().kind {
            TerminatorKind::Call { func, target: Some(target), args, .. } => {
                let ty::FnDef(def, substitutions) = func.ty(&glue.local_decls, tcx).kind() else {
                    return Err("indirect drop glue call".into());
                };
                let resolved = ty::Instance::try_resolve(tcx, ty::TypingEnv::fully_monomorphized(),
                    *def, substitutions.skip_binder()).ok().flatten().ok_or("unresolved concrete destructor call")?;
                if resolved.def_id() != destructor.did || args.len() != 1 {
                    return Err("drop glue does not call the actual destructor exactly".into());
                }
                if !matches!(&args[0].node, Operand::Move(place) | Operand::Copy(place)
                    if place.projection.is_empty() && receivers.contains(&place.local))
                {
                    return Err("drop glue receiver is not the original dropped place".into());
                }
                calls += 1;
                block = *target;
            }
            TerminatorKind::Goto { target } => block = *target,
            TerminatorKind::Return if calls == 1 => return Ok(destructor.did),
            _ => return Err("unsupported concrete drop glue control flow".into()),
        }
    }
}

fn normalize<'tcx>(tcx: TyCtxt<'tcx>, body: &Body<'tcx>) -> Result<(Program, HashMap<mir::Local, usize>), String> {
    let mut normalizer = Normalizer { tcx, body, locals: HashMap::new(), types: vec![],
        aliases: HashMap::new(), ghost: HashSet::new() };
    for index in 0..=body.arg_count {
        normalizer.local(mir::Local::from_usize(index))?;
    }
    let mut operations = vec![];
    let mut visited = HashSet::new();
    let mut block = mir::START_BLOCK;
    loop {
        if !visited.insert(block) {
            return Err("loops/conditional destruction are unsupported".into());
        }
        let data = &body.basic_blocks[block];
        if data.is_cleanup {
            return Err("normal path enters cleanup".into());
        }
        for statement in &data.statements {
            match &statement.kind {
                StatementKind::Assign(assignment) => {
                    if assignment.0.ty(&body.local_decls, tcx).ty.is_unit() {
                        continue;
                    }
                    if normalizer.ghost.contains(&assignment.0.local) {
                        continue;
                    }
                    if normalizer.ghost_value(&assignment.1) {
                        if !assignment.0.projection.is_empty() || normalizer.locals.contains_key(&assignment.0.local) {
                            return Err("ghost write reaches executable state".into());
                        }
                        normalizer.ghost.insert(assignment.0.local);
                        continue;
                    }
                    if matches!(assignment.0.ty(&body.local_decls, tcx).ty.kind(), ty::Ref(..)) {
                        if !assignment.0.projection.is_empty() {
                            return Err("replacing a borrowed reference field is unsupported".into());
                        }
                        let value = normalizer.value(&assignment.1)?;
                        normalizer.aliases.insert(assignment.0.local, value);
                        continue;
                    }
                    let place = normalizer.place(assignment.0)?;
                    let value = normalizer.value(&assignment.1)?;
                    operations.push(Operation::Assign(place, value));
                }
                StatementKind::StorageLive(_) | StatementKind::StorageDead(_)
                | StatementKind::Nop
                | StatementKind::FakeRead(..) | StatementKind::PlaceMention(..) => {}
                _ => return Err(format!("unsupported destruction statement: {:?}", statement.kind)),
            }
        }
        match &data.terminator().kind {
            TerminatorKind::Goto { target } => block = *target,
            TerminatorKind::Call { func, args, destination, target: Some(target), .. } => {
                let ty::FnDef(def, _) = func.ty(&body.local_decls, tcx).kind() else {
                    return Err("indirect destruction-path call".into());
                };
                let Some((erased, shadow, tie)) = rustc_mir_build_verus::verus::checked_drop_erasure_helpers() else {
                    return Err("calls in erased execution destruction paths are unsupported".into());
                };
                if (*def == erased || *def == shadow) && destination.projection.is_empty()
                    && args.iter().all(|arg| normalizer.ghost_operand(&arg.node))
                    && !normalizer.locals.contains_key(&destination.local)
                {
                    normalizer.ghost.insert(destination.local);
                } else if *def == tie && args.len() == 2 && destination.projection.is_empty()
                    && normalizer.ghost_operand(&args[1].node)
                    && !normalizer.locals.contains_key(&destination.local)
                {
                    let value = normalizer.operand(&args[0].node)?;
                    if !matches!(value, Value::Ref(_)) {
                        return Err("tie does not retain an actual original reference".into());
                    }
                    normalizer.aliases.insert(destination.local, value);
                } else {
                    return Err("unsupported call or non-ghost erasure-helper operands".into());
                }
                block = *target;
            }
            TerminatorKind::Drop { place, target, .. } => {
                if normalizer.ghost.contains(&place.local) {
                    block = *target;
                    continue;
                }
                if !place.projection.is_empty() {
                    return Err("projected destruction is unsupported".into());
                }
                let destructor = drop_impl(tcx, place.ty(&body.local_decls, tcx).ty)?;
                operations.push(Operation::Drop(normalizer.place(*place)?, identity(tcx, destructor)));
                block = *target;
            }
            TerminatorKind::Return => {
                operations.push(Operation::Return);
                break;
            }
            _ => return Err(format!("unsupported normal destruction terminator: {:?}", data.terminator().kind)),
        }
    }
    for (index, data) in body.basic_blocks.iter_enumerated() {
        if !data.is_cleanup && !visited.contains(&index) {
            return Err("unaccounted normal destruction block".into());
        }
    }
    Ok((Program { types: normalizer.types, arg_count: body.arg_count, operations }, normalizer.locals))
}

pub(crate) fn capture<'tcx>(tcx: TyCtxt<'tcx>, def: LocalDefId, body: &Body<'tcx>) {
    if !enabled() {
        return;
    }
    let normalized = normalize(tcx, body);
    let capture = match normalized {
        Ok((program, locals)) => Capture {
            program: Ok(program),
            origins: checked_drop_origins::get(def).unwrap_or_default().into_iter()
                .filter_map(|(hir, local)| locals.get(&local).map(|index| (hir, *index))).collect(),
        },
        Err(error) => Capture { program: Err(error), origins: HashMap::new() },
    };
    STATE.lock().unwrap().as_mut().unwrap().captures.insert(identity(tcx, def.to_def_id()), capture);
}

#[derive(Clone, Debug, PartialEq, Eq)]
enum InitialValue {
    Argument(usize),
    Borrow(usize),
    Number(u64),
    Owner(usize),
}

#[derive(Clone, Debug, PartialEq, Eq)]
enum Event {
    Initialize { local: usize, typ: String, fields: Vec<InitialValue> },
    Destroy { local: usize, destructor: String },
}

fn account(program: &Program) -> Result<Vec<Event>, String> {
    if program.types.first() != Some(&Type::Unit) {
        return Err("returning values from destruction contexts is unsupported".into());
    }
    let mut locals = HashMap::new();
    let mut live = HashSet::new();
    let mut events = vec![];
    for index in 1..=program.arg_count {
        locals.insert(index, InitialValue::Argument(index - 1));
        if program.types[index] != Type::U64 && program.types[index] != Type::Ref(Box::new(Type::U64)) {
            return Err("owner arguments, escapes and nested references are unsupported".into());
        }
    }
    fn evaluate(value: &Value, locals: &mut HashMap<usize, InitialValue>) -> Result<InitialValue, String> {
        match value {
            Value::Number(number) => Ok(InitialValue::Number(*number)),
            Value::Copy(place) | Value::Move(place) if place.projection.is_empty() => {
                let value = locals.get(&place.root).ok_or("read of unaccounted local")?.clone();
                if matches!(value, InitialValue::Owner(_)) {
                    return Err("moving/copying a destruction owner is unsupported".into());
                }
                if matches!(value, InitialValue::Borrow(_)) {
                    locals.remove(&place.root);
                }
                Ok(value)
            }
            Value::Ref(place) if place.projection == [Projection::Deref] => {
                match locals.get(&place.root) {
                    Some(InitialValue::Argument(index)) | Some(InitialValue::Borrow(index)) => Ok(InitialValue::Borrow(*index)),
                    _ => Err("borrow is not rooted in an original argument".into()),
                }
            }
            _ => Err("unsupported constructor operand/escape".into()),
        }
    }
    for operation in &program.operations {
        match operation {
            Operation::Assign(place, value) if place.projection.is_empty() => {
                if live.contains(&place.root) {
                    return Err("overwriting a live destruction owner is unsupported".into());
                }
                if let Value::Struct(typ, operands) = value {
                    let fields = operands.iter().map(|operand| evaluate(operand, &mut locals))
                        .collect::<Result<Vec<_>, _>>()?;
                    events.push(Event::Initialize { local: place.root, typ: typ.clone(), fields });
                    locals.insert(place.root, InitialValue::Owner(place.root));
                    live.insert(place.root);
                } else {
                    let value = evaluate(value, &mut locals)?;
                    locals.insert(place.root, value);
                }
            }
            Operation::Drop(place, destructor) if place.projection.is_empty() => {
                if !live.remove(&place.root) {
                    return Err("duplicate or uninitialized destruction".into());
                }
                locals.remove(&place.root);
                events.push(Event::Destroy { local: place.root, destructor: destructor.clone() });
            }
            Operation::Return if live.is_empty() => {}
            Operation::Return => return Err("missing destruction or ownership escape".into()),
            _ => return Err("unsupported write or control flow around destruction".into()),
        }
    }
    Ok(events)
}

fn error(span: &Span, message: impl AsRef<str>) -> VirErr {
    vir::messages::error(span, format!("checked normal destruction declined: {}", message.as_ref()))
}

fn original_argument(ctxt: &Context<'_>, capture: &Capture, function: &Function,
                     place: &vir::ast::Place) -> Result<usize, VirErr> {
    let PlaceX::Local(name) = &place.x else {
        return Err(error(&place.span, "initializer is not a parameter place"));
    };
    let index = function.x.params.iter().position(|param| &param.x.name == name)
        .ok_or_else(|| error(&place.span, "initializer refers to a nonparameter local"))?;
    let use_hir = ctxt.erasure_info.borrow().local_hir_vir_ids.iter()
        .find_map(|(hir, ast)| (*ast == place.span.id).then_some(*hir).flatten())
        .ok_or_else(|| error(&place.span, "missing exact original-reference AstId/HirId"))?;
    let rustc_hir::Node::Expr(expression) = ctxt.tcx.hir_node(use_hir) else {
        return Err(error(&place.span, "original-reference origin is not an expression"));
    };
    let rustc_hir::ExprKind::Path(path) = &expression.kind else {
        return Err(error(&place.span, "original-reference origin is not a local path"));
    };
    let rustc_hir::def::Res::Local(binder) = ctxt.tcx.typeck(use_hir.owner.def_id).qpath_res(path, use_hir) else {
        return Err(error(&place.span, "original-reference path does not resolve to a binder"));
    };
    if capture.origins.get(&binder) != Some(&(index + 1)) {
        return Err(error(&place.span, "original-reference binder does not map to the actual MIR argument"));
    }
    Ok(index)
}

fn vir_initial(ctxt: &Context<'_>, capture: &Capture, expr: &Expr, function: &Function) -> Result<InitialValue, VirErr> {
    match &expr.x {
        ExprX::Const(Constant::Int(number)) => number.to_string().parse::<u64>()
            .map(InitialValue::Number).map_err(|_| error(&expr.span, "non-u64 literal")),
        ExprX::BorrowMut(place) | ExprX::TwoPhaseBorrowMut(place) => {
            if let PlaceX::DerefMut(reference) = &place.x {
                return original_argument(ctxt, capture, function, reference).map(InitialValue::Borrow);
            }
            Err(error(&expr.span, "reference initializer is not an original parameter reborrow"))
        }
        ExprX::ReadPlace(place, _) => {
            if matches!(place.x, PlaceX::Local(_)) {
                return original_argument(ctxt, capture, function, place).map(InitialValue::Argument);
            }
            Err(error(&expr.span, "unsupported initializer read"))
        }
        _ => Err(error(&expr.span, "unsupported initializer expression")),
    }
}

fn rewrite_block(
    ctxt: &Context<'_>, krate: &Krate, function: &Function, expr: &Expr, capture: &Capture,
    binders: &HashMap<AstId, HirId>, destructors: &HashMap<String, Fun>,
    expected: &mut Vec<Event>,
) -> Result<Expr, VirErr> {
    let ExprX::Block(statements, tail) = &expr.x else {
        return Err(error(&expr.span, "only ordinary straight-line lexical blocks are supported"));
    };
    let mut result = vec![];
    let mut owners = vec![];
    for statement in statements.iter() {
        match &statement.x {
            StmtX::Expr(child) => {
                let child = rewrite_block(ctxt, krate, function, child, capture, binders, destructors, expected)?;
                result.push(Spanned::new(statement.span.clone(), StmtX::Expr(child)));
            }
            StmtX::Decl { pattern, mode: Some((Mode::Exec, _)), init: Some(init), els: None, .. } => {
                let PatternX::Var(binding) = &pattern.x else {
                    return Err(error(&pattern.span, "only simple owner binders are supported"));
                };
                if binding.by_ref != ByRef::No {
                    return Err(error(&pattern.span, "reference patterns are outside the owner subset"));
                }
                let hir = binders.get(&pattern.span.id).ok_or_else(|| error(&pattern.span, "missing exact binder AstId/HirId"))?;
                let local = *capture.origins.get(hir).ok_or_else(|| error(&pattern.span, "missing retained THIR binder/MIR local"))?;
                let PlaceX::Temporary(initializer) = &init.x else {
                    return Err(error(&init.span, "owner transfer is unsupported"));
                };
                let ExprX::Ctor(Dt::Path(path), _, fields, None) = &initializer.x else {
                    return Err(error(&initializer.span, "only direct owner construction is supported"));
                };
                let def = *ctxt.name_def_id_map.borrow().get(path).ok_or_else(|| error(&initializer.span, "missing datatype identity"))?;
                let adt = ctxt.tcx.adt_def(def);
                let typ = identity(ctxt.tcx, def);
                let field_values = adt.non_enum_variant().fields.iter().map(|field| {
                    let value = fields.iter().find(|binder| binder.name.as_str() == field.name.as_str())
                        .ok_or_else(|| error(&initializer.span, "constructor field mismatch"))?;
                    vir_initial(ctxt, capture, &value.a, function)
                }).collect::<Result<Vec<_>, _>>()?;
                if field_values.len() != fields.len() {
                    return Err(error(&initializer.span, "unaccounted constructor field"));
                }
                expected.push(Event::Initialize { local, typ, fields: field_values });
                owners.push((local, binding.name.clone(), pattern.typ.clone(), pattern.span.clone()));
                result.push(statement.clone());
            }
            _ => return Err(error(&statement.span, "conditional initialization/unsupported declaration")),
        }
    }
    if let Some(tail) = tail {
        result.push(Spanned::new(tail.span.clone(), StmtX::Expr(
            rewrite_block(ctxt, krate, function, tail, capture, binders, destructors, expected)?)));
    }
    for (local, name, typ, span) in owners.into_iter().rev() {
        let program = capture.program.as_ref().unwrap();
        let destructor = program.operations.iter().find_map(|operation| match operation {
            Operation::Drop(place, destructor) if place.root == local => Some(destructor),
            _ => None,
        }).ok_or_else(|| error(&span, "missing authoritative destruction event"))?;
        let fun = destructors.get(destructor).ok_or_else(|| error(&span, "actual Drop is not universally checked locally"))?;
        expected.push(Event::Destroy { local, destructor: destructor.clone() });
        let consumed = VarIdent(std::sync::Arc::new("checked_drop_owner".to_string()),
            VarIdentDisambiguate::VirTemp(ctxt.spans.get_next_span_id()));
        let fresh_span = || {
            let mut generated = span.clone();
            generated.id = ctxt.spans.get_next_span_id();
            generated
        };
        let original = SpannedTyped::new(&fresh_span(), &typ, PlaceX::Local(name));
        let moved = SpannedTyped::new(&fresh_span(), &typ, ExprX::ReadPlace(original,
            UnfinalizedReadKind { preliminary_kind: ReadKind::Move,
                id: ctxt.spans.get_next_span_id() }));
        let initializer = SpannedTyped::new(&fresh_span(), &typ, PlaceX::Temporary(moved));
        let pattern = SpannedTyped::new(&fresh_span(), &typ, PatternX::Var(PatternBinding {
            name: consumed.clone(), by_ref: ByRef::No, typ: typ.clone(), user_mut: None,
            copy: false,
        }));
        result.push(Spanned::new(fresh_span(), StmtX::Decl {
            pattern, mode: Some((Mode::Exec, DeclProph::Default)), init: Some(initializer),
            els: None, assert_irrefutable: false,
        }));
        let mut place_span = span.clone();
        place_span.id = ctxt.spans.get_next_span_id();
        let place = SpannedTyped::new(&place_span, &typ, PlaceX::Local(consumed.clone()));
        let mut borrow_span = span.clone();
        borrow_span.id = ctxt.spans.get_next_span_id();
        let borrow = SpannedTyped::new(&borrow_span, &std::sync::Arc::new(TypX::MutRef(typ.clone())), ExprX::TwoPhaseBorrowMut(place));
        let mut call_span = span.clone();
        call_span.id = ctxt.spans.get_next_span_id();
        let call = SpannedTyped::new(&call_span, &vir::ast_util::unit_typ(), ExprX::Call {
            target: CallTarget::Fun(CallTargetKind::Static, fun.clone(), std::sync::Arc::new(vec![]),
                std::sync::Arc::new(vec![]), CallTargetAttrs { autospec: AutospecUsage::Final,
                    const_var: false, assume_external_allowed: false }),
            args: std::sync::Arc::new(vec![borrow]), post_args: None, body: None,
        });
        call_span.id = ctxt.spans.get_next_span_id();
        result.push(Spanned::new(call_span, StmtX::Expr(call)));
        result.extend(retire_consumed_reference_fields(ctxt, krate, &typ, &consumed, &span)?);
    }
    Ok(SpannedTyped::new(&expr.span, &expr.typ, ExprX::Block(std::sync::Arc::new(result), None)))
}

fn retire_consumed_reference_fields(
    ctxt: &Context<'_>, krate: &Krate, typ: &Typ, consumed: &VarIdent, span: &Span,
) -> Result<Vec<Stmt>, VirErr> {
    let TypX::Datatype(owner, arguments, _) = &**typ else {
        return Err(error(span, "consumed destructor owner is not a datatype"));
    };
    if !arguments.is_empty() {
        return Err(error(span, "generic field retirement is unsupported"));
    }
    let datatype = krate.datatypes.iter().find(|datatype| &datatype.x.name == owner)
        .ok_or_else(|| error(span, "missing consumed destructor datatype"))?;
    let [variant] = datatype.x.variants.as_slice() else {
        return Err(error(span, "enum field retirement is unsupported"));
    };
    let fresh_span = || {
        let mut generated = span.clone();
        generated.id = ctxt.spans.get_next_span_id();
        generated
    };
    let mut statements = vec![];
    for field in variant.fields.iter() {
        let TypX::MutRef(pointee) = &*field.a.0 else { continue };
        if !matches!(&**pointee, TypX::Int(IntRange::U(64))) || field.a.1 != Mode::Exec {
            return Err(error(span, "unsupported consumed reference field"));
        }
        let owner_place = SpannedTyped::new(&fresh_span(), typ, PlaceX::Local(consumed.clone()));
        let field_place = SpannedTyped::new(&fresh_span(), &field.a.0, PlaceX::Field(FieldOpr {
            datatype: owner.clone(), variant: variant.name.clone(), field: field.name.clone(),
            get_variant: false, check: VariantCheck::None,
        }, owner_place));
        let value = SpannedTyped::new(&fresh_span(), &field.a.0,
            ExprX::ReadPlace(field_place, UnfinalizedReadKind {
                preliminary_kind: ReadKind::Spec, id: ctxt.spans.get_next_span_id(),
            }));
        let resolved = SpannedTyped::new(&fresh_span(), &std::sync::Arc::new(TypX::Bool),
            ExprX::UnaryOpr(UnaryOpr::HasResolved(field.a.0.clone()), value));
        let unit = vir::ast_util::unit_typ();
        let assumption = SpannedTyped::new(&fresh_span(), &unit, ExprX::AssertAssume {
            is_assume: true, expr: resolved, msg: None,
        });
        let proof = SpannedTyped::new(&fresh_span(), &unit,
            ExprX::Ghost { alloc_wrapper: false, tracked: false, expr: assumption });
        statements.push(Spanned::new(fresh_span(), StmtX::Expr(proof)));
    }
    Ok(statements)
}

fn checked_reference_frames(ctxt: &Context<'_>, krate: &Krate, function: &Function)
    -> Result<Function, VirErr>
{
    let [receiver] = function.x.params.as_slice() else {
        return Err(error(&function.span, "destructor receiver signature is unsupported"));
    };
    let TypX::MutRef(owner_typ) = &*receiver.x.typ else {
        return Err(error(&function.span, "destructor requires a mutable receiver"));
    };
    let TypX::Datatype(owner, arguments, _) = &**owner_typ else {
        return Err(error(&function.span, "destructor receiver must be a concrete datatype"));
    };
    if !arguments.is_empty() {
        return Err(error(&function.span, "generic destructor frames are unsupported"));
    }
    let datatype = krate.datatypes.iter().find(|datatype| &datatype.x.name == owner)
        .ok_or_else(|| error(&function.span, "missing local destructor datatype"))?;
    let [variant] = datatype.x.variants.as_slice() else {
        return Err(error(&function.span, "enum destructor frames are unsupported"));
    };
    let mut ensures = function.x.ensure.0.as_ref().clone();
    for field in variant.fields.iter() {
        let TypX::MutRef(pointee) = &*field.a.0 else { continue };
        if !matches!(&**pointee, TypX::Int(IntRange::U(64))) {
            return Err(error(&function.span, "only u64 reference-field frames are supported"));
        }
        let fresh_expr = |typ: &Typ, value: ExprX| {
            let mut span = function.span.clone();
            span.id = ctxt.spans.get_next_span_id();
            SpannedTyped::new(&span, typ, value)
        };
        let before = fresh_expr(&receiver.x.typ, ExprX::Var(receiver.x.name.clone()));
        let after = fresh_expr(&receiver.x.typ, ExprX::Var(receiver.x.name.clone()));
        let before = fresh_expr(owner_typ, ExprX::Unary(UnaryOp::MutRefCurrent, before));
        let after = fresh_expr(owner_typ,
            ExprX::Unary(UnaryOp::MutRefFuture(MutRefFutureSourceName::Final), after));
        let projection = FieldOpr {
            datatype: owner.clone(), variant: variant.name.clone(), field: field.name.clone(),
            get_variant: false, check: VariantCheck::None,
        };
        let project = |value: Expr| {
            let mut span = function.span.clone();
            span.id = ctxt.spans.get_next_span_id();
            let owner_place = SpannedTyped::new(&span, owner_typ, PlaceX::Temporary(value));
            span.id = ctxt.spans.get_next_span_id();
            let field_place = SpannedTyped::new(&span, &field.a.0,
                PlaceX::Field(projection.clone(), owner_place));
            fresh_expr(&field.a.0, ExprX::ReadPlace(field_place, UnfinalizedReadKind {
                preliminary_kind: ReadKind::Spec, id: ctxt.spans.get_next_span_id(),
            }))
        };
        let before = project(before);
        let after = project(after);
        let before = fresh_expr(pointee,
            ExprX::Unary(UnaryOp::MutRefFuture(MutRefFutureSourceName::Final), before));
        let after = fresh_expr(pointee,
            ExprX::Unary(UnaryOp::MutRefFuture(MutRefFutureSourceName::Final), after));
        ensures.push(fresh_expr(&std::sync::Arc::new(TypX::Bool),
            ExprX::Binary(BinaryOp::Eq(Mode::Spec), before, after)));
    }
    let mut replacement = (**function).clone();
    replacement.x.ensure.0 = std::sync::Arc::new(ensures);
    Ok(std::sync::Arc::new(replacement))
}

pub(crate) fn prepare(ctxt: &Context<'_>, krate: &Krate) -> Result<Vec<Function>, VirErr> {
    let tcx = ctxt.tcx;
    let ids = ctxt.name_def_id_map.borrow().clone();
    let mut destructors = HashMap::new();
    let mut destructor_ids = HashSet::new();
    for function in &krate.functions {
        let Some(def) = ids.get(&function.x.name.path).copied() else { continue };
        let Some(impl_def) = tcx.impl_of_assoc(def) else { continue };
        if tcx.trait_impl_of_assoc(def).is_none()
            || Some(tcx.impl_trait_ref(impl_def).skip_binder().def_id) != tcx.lang_items().drop_trait() {
            continue;
        }
        if function.x.body.is_none() || function.x.attrs.is_external_body
            || !function.x.require.is_empty() || !matches!(function.x.unwind_spec, Some(UnwindSpec::NoUnwind))
            || !matches!(&function.x.mask_spec, Some(MaskSpec::InvariantOpens(_, names)) if names.is_empty())
        {
            return Err(error(&function.span, "Drop must retain a local unconditional checked body, mask none and no_unwind"));
        }
        destructors.insert(identity(tcx, def), function.x.name.clone());
        destructor_ids.insert(def);
    }
    let binders = ctxt.erasure_info.borrow().binder_hir_vir_ids.iter()
        .filter_map(|(hir, ast)| hir.map(|hir| (*ast, hir))).collect::<HashMap<_, _>>();
    let mut replacements = vec![];
    let mut retained = HashMap::new();
    for function in &krate.functions {
        if function.x.mode != Mode::Exec || function.x.body.is_none() {
            continue;
        }
        let def = *ids.get(&function.x.name.path).ok_or_else(|| error(&function.span, "missing function identity"))?;
        let local = def.as_local().ok_or_else(|| error(&function.span, "imported function"))?;
        let _ = tcx.mir_drops_elaborated_and_const_checked(local);
        let key = identity(tcx, def);
        let capture = STATE.lock().unwrap().as_ref().unwrap().captures.get(&key).cloned()
            .ok_or_else(|| error(&function.span, "missing authoritative elaborated query capture"))?;
        if destructor_ids.contains(&def) {
            let program = capture.program.as_ref().map_err(|message| error(&function.span, message))?;
            if program.operations.iter().any(|op| matches!(op, Operation::Drop(..))) {
                return Err(error(&function.span, "nested destructor behavior is unsupported"));
            }
            let writes = program.operations.iter().filter_map(|op| match op {
                Operation::Assign(place, _) if !place.projection.is_empty() => Some(place),
                _ => None,
            }).collect::<Vec<_>>();
            if writes.len() > 1 {
                return Err(error(&function.span, "multiple destructor memory writes are outside this first subset"));
            }
            retained.insert(key, program.clone());
            replacements.push(checked_reference_frames(ctxt, krate, function)?);
            continue;
        }
        let program = capture.program.as_ref().map_err(|message| error(&function.span, message))?;
        let has_owner = program.types.iter().any(|typ| matches!(typ, Type::Struct(_)));
        if !has_owner {
            continue;
        }
        if function.x.attrs.infer || !function.x.typ_params.is_empty() || !function.x.typ_bounds.is_empty() {
            return Err(error(&function.span, "generic/inferred destruction contexts are unsupported"));
        }
        let actual = account(program).map_err(|message| error(&function.span, message))?;
        let mut expected = vec![];
        let body = rewrite_block(ctxt, krate, function, function.x.body.as_ref().unwrap(), &capture,
                                 &binders, &destructors, &mut expected)?;
        if actual != expected {
            return Err(error(&function.span, format!("lexical events/original-reference ownership mismatch: actual {actual:?}; expected {expected:?}")));
        }
        let mut replacement = (**function).clone();
        replacement.x.body = Some(body);
        replacements.push(std::sync::Arc::new(replacement));
        retained.insert(key, program.clone());
    }
    let mut guard = STATE.lock().unwrap();
    let state = guard.as_mut().unwrap();
    state.effects = replacements.len();
    state.expected = retained;
    Ok(replacements)
}

pub(crate) fn check_native(tcx: TyCtxt<'_>) -> Result<(), String> {
    let expected = STATE.lock().unwrap().as_ref().unwrap().expected.clone();
    let mut seen = HashSet::new();
    for def in tcx.hir_body_owners() {
        let key = identity(tcx, def.to_def_id());
        if expected.contains_key(&key) {
            let _ = tcx.mir_drops_elaborated_and_const_checked(def);
            seen.insert(key);
        }
    }
    let mut guard = STATE.lock().unwrap();
    let state = guard.as_mut().unwrap();
    if seen.len() != expected.len() {
        return Err("GHOST/EXEC destructor or caller missing from erased execution".into());
    }
    for (key, program) in expected {
        let native = state.captures.get(&key).ok_or("missing EXEC elaborated capture")?;
        let native = native.program.as_ref().map_err(|message| format!("EXEC correspondence declined: {message}"))?;
        if *native != program {
            return Err(format!("GHOST/EXEC authoritative operation mismatch for {key}: GHOST {program:?}; EXEC {native:?}"));
        }
    }
    state.correspondence = true;
    Ok(())
}

pub(crate) fn elaborated<'tcx>(tcx: TyCtxt<'tcx>, def: LocalDefId)
    -> &'tcx rustc_data_structures::steal::Steal<Body<'tcx>>
{
    let result = (rustc_interface::DEFAULT_QUERY_PROVIDERS.queries.mir_drops_elaborated_and_const_checked)(tcx, def);
    capture(tcx, def, &result.borrow());
    result
}

#[cfg(test)]
mod tests {
    use super::*;

    fn actual_program() -> Program {
        Program { types: vec![Type::Unit, Type::Ref(Box::new(Type::U64)), Type::Struct("actual-type".into())],
            arg_count: 1,
            operations: vec![
                Operation::Assign(Place { root: 2, projection: vec![] }, Value::Struct("actual-type".into(), vec![
                    Value::Ref(Place { root: 1, projection: vec![Projection::Deref] }), Value::Number(7),
                ])),
                Operation::Drop(Place { root: 2, projection: vec![] }, "actual-checked-impl".into()),
                Operation::Return,
            ],
        }
    }

    #[test]
    fn exact_original_loan_and_consumption() {
        let events = account(&actual_program()).unwrap();
        assert_eq!(events, vec![
            Event::Initialize { local: 2, typ: "actual-type".into(),
                fields: vec![InitialValue::Borrow(0), InitialValue::Number(7)] },
            Event::Destroy { local: 2, destructor: "actual-checked-impl".into() },
        ]);
    }

    #[test]
    fn deleted_drop_leaves_live_owner() {
        let mut mutant = actual_program();
        mutant.operations.remove(1);
        assert!(account(&mutant).unwrap_err().contains("missing destruction"));
    }

    #[test]
    fn duplicated_drop_cannot_consume_twice() {
        let mut mutant = actual_program();
        mutant.operations.insert(1, mutant.operations[1].clone());
        assert!(account(&mutant).unwrap_err().contains("duplicate"));
    }

    #[test]
    fn changed_original_reference_cannot_match_authority() {
        let actual = actual_program();
        let mut mutant = actual.clone();
        if let Operation::Assign(_, Value::Struct(_, fields)) = &mut mutant.operations[0] {
            fields[0] = Value::Ref(Place { root: 2, projection: vec![Projection::Deref] });
        }
        assert_ne!(mutant, actual);
        assert!(account(&mutant).is_err());
    }

    #[test]
    fn changed_order_and_impl_cannot_match_authority() {
        let actual = actual_program();
        let mut mutant = actual.clone();
        mutant.operations.swap(0, 1);
        assert_ne!(mutant, actual);
        assert!(account(&mutant).is_err());
        mutant = actual.clone();
        mutant.operations[1] = Operation::Drop(Place { root: 2, projection: vec![] }, "different-impl".into());
        assert_ne!(mutant, actual);
        assert_ne!(account(&mutant).unwrap(), account(&actual).unwrap());
    }
}
