import datetime
import difflib
import hashlib
import json
from pathlib import Path
import shutil
import subprocess


ROOT = Path(__file__).resolve().parent
REPOSITORY = Path('/Users/tommyvolk/.t3/worktrees/verus/t3-60978068')
RUSTFMT = Path('/Users/tommyvolk/.rustup/toolchains/1.99.1-aarch64-apple-darwin/bin/rustfmt')


def identity(filename):
    payload = filename.read_bytes()
    return {'path': str(filename), 'bytes': len(payload),
            'sha256': hashlib.sha256(payload).hexdigest()}


def function_body(source, name):
    import re
    matched = re.search(r'(?m)^(?:pub(?:\([^)]*\))? )?fn ' + re.escape(name) + r"(?:[<'(])", source)
    if matched is None:
        raise ValueError(name)
    opening = source.index('{', matched.start())
    balance = 1
    cursor = opening + 1
    while balance:
        if source[cursor] == '{':
            balance += 1
        elif source[cursor] == '}':
            balance -= 1
        cursor += 1
    return source[matched.start():cursor]


def main():
    assert shutil.disk_usage(ROOT).free > 16 * 1024 ** 3
    original = json.loads((ROOT / 'BASELINE.json').read_text())['records']
    for record in original:
        actual = identity(Path(record['path']))
        assert actual['sha256'] == record['sha256'] and actual['bytes'] == record['bytes']
        assert (ROOT / 'baseline' / record['relative_path']).read_bytes() == Path(record['path']).read_bytes()
    names = [record['relative_path'] for record in original]
    delta = []
    for name in names:
        delta.extend(difflib.unified_diff((ROOT / 'baseline' / name).read_text().splitlines(keepends=True),
                                         (ROOT / 'candidate' / name).read_text().splitlines(keepends=True),
                                         fromfile='a/source/' + name, tofile='b/source/' + name))
    (ROOT / 'candidate.patch').write_text(''.join(delta))
    before = (ROOT / 'baseline/rust_verify/src/checked_normal_drop.rs').read_text()
    after = (ROOT / 'candidate/rust_verify/src/checked_normal_drop.rs').read_text()
    unchanged = ['supported_type', 'drop_impl', 'normalize', 'account', 'rewrite_block',
                 'checked_reference_frames', 'prepare', 'check_native', 'elaborated']
    for name in unchanged:
        assert function_body(before, name) == function_body(after, name), name
    capture = function_body(after, 'capture')
    assert capture.index('original_unbound_drops(tcx, def, body)') < capture.index('normalize(tcx, body)')
    assert 'if original_unbound_drops.is_empty()' in capture
    assert 'Err(format!("unbound destruction site captured but declined:' in capture
    assert before.count('MutRefHasResolved') == after.count('MutRefHasResolved')
    added = '\n'.join(line[1:] for line in delta if line.startswith('+') and not line.startswith('+++'))
    for forbidden in ['ExprX::Assume', 'external_body', 'assume_specification', 'axiom', 'admit(']:
        assert forbidden not in added, forbidden
    origins = (ROOT / 'candidate/rustc_mir_build/src/builder/checked_drop_origins.rs').read_text()
    assert 'pub expression: ExprId' in origins and 'pub nested_expression: ExprId' in origins
    assert 'origin.local == local' not in origins
    assert 'pub scope: Option<TemporaryScope>' in origins
    for name in ['retain_temporary', 'retain_temporary_scope']:
        retained = function_body(origins, name)
        assert retained.index('if !ENABLED.load') < retained.index('TEMPORARIES.lock()')
    for required in ['projections: place.projection.iter()', 'cleanup: data.is_cleanup',
                     'native_phase: checked_drop_origins::native()', 'normal_target: target.as_usize()',
                     'mir::UnwindAction::Cleanup(target)', 'async_drop_target: drop.map',
                     'typ.has_non_region_param() || typ.has_bound_vars()']:
        assert required in after, required
    formatter_before = identity(RUSTFMT)
    formatter_runs = []
    environment = {'LANG': 'C', 'LC_ALL': 'C', 'TZ': 'UTC'}
    for index, name in enumerate(names):
        filename = ROOT / 'candidate' / name
        source_before = identity(filename)
        argv = [str(RUSTFMT), '--edition', '2024', '--emit', 'stdout', str(filename)]
        stdout = ROOT / ('syntax-' + str(index) + '.stdout')
        stderr = ROOT / ('syntax-' + str(index) + '.stderr')
        with stdout.open('wb') as output, stderr.open('wb') as errors:
            result = subprocess.run(argv, cwd=ROOT, env=environment, stdout=output,
                                    stderr=errors, timeout=30)
        formatter_runs.append({'argv': argv, 'environment': environment,
                               'exit_code': result.returncode, 'source': source_before,
                               'stdout': identity(stdout), 'stderr': identity(stderr)})
        assert identity(filename) == source_before
        assert result.returncode == 0, name
    assert identity(RUSTFMT) == formatter_before
    baseline = json.loads((REPOSITORY / 'evidence/redb-writablepage-lifecycle113/ENTRY-INPUTS.json').read_text())['records']
    expected = json.loads((REPOSITORY / 'evidence/redb-writablepage-lifecycle113/DOCUMENT-RECONCILIATION.json').read_text())['expected_document_updates']
    expected = {record['path']: record['after_sha256'] for record in expected}
    matches = 0
    reconciled = 0
    for record in baseline:
        actual = identity(Path(record['path']))
        if actual['sha256'] == record['sha256']:
            matches += 1
        else:
            assert actual['sha256'] == expected.get(record['path']), record['path']
            reconciled += 1
    result = {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'classification': 'UNBUILT_SOURCE_AND_FORMATTER_SYNTAX_CHECKS_ONLY',
              'unchanged_legacy_functions': unchanged, 'formatter': formatter_before,
              'formatter_runs': formatter_runs, 'parent_exact_matches': matches,
              'expected_parent_document_updates': reconciled, 'baseline_records': len(baseline),
              'source_only_assertions_passed': True, 'compiler_builds': 0,
              'compiler_typecheck_or_verifier_runs': 0, 'native_original_bodies_checked': 0,
              'semantic_controls_run': 0, 'all18': 'OPEN', 'new_trust': False,
              'free_bytes': shutil.disk_usage(ROOT).free,
              'function_preservation_oracle': 'TARGETED_EXACT_SOURCE_BODY_COMPARISON_NOT_AST_EQUIVALENCE',
              'formatter_provenance': 'DIRECT_TOOL_ENDPOINT_HASHES_AFTER_DISCOVERY_NOT_OS_OR_SHARED_LIBRARY_CLOSURE'}
    (ROOT / 'VALIDATION.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'syntax_files': len(formatter_runs), 'unchanged_legacy_functions': len(unchanged),
                      'parent_exact_matches': matches, 'expected_document_updates': reconciled,
                      'native_original_bodies_checked': 0, 'all18': 'OPEN'}, sort_keys=True))


if __name__ == '__main__':
    main()
