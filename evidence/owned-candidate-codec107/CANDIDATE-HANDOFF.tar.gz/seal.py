import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path('/private/tmp/verus-owned-codec107-20261107-kcJbs7')
STARTED = datetime.fromisoformat('2026-11-08T02:42:01+00:00')

def record(path):
    content = path.read_bytes()
    return {'path': str(path), 'bytes': len(content),
            'sha256': hashlib.sha256(content).hexdigest()}

tested = []
for crate in ('vir', 'air', 'vir_macros'):
    tested.extend(sorted(path for path in (ROOT / 'source' / crate).rglob('*') if path.is_file()))
tested.extend([ROOT / 'source/Cargo.toml', ROOT / 'source/Cargo.lock', ROOT / 'run-focused.sh',
               ROOT / 'target/debug/deps/vir-b95bba01b14f0825',
               Path('/Users/tommyvolk/.rustup/toolchains/1.99.1-aarch64-apple-darwin/bin/rustc'),
               Path('/Users/tommyvolk/.rustup/toolchains/1.99.1-aarch64-apple-darwin/bin/cargo')])
(ROOT / 'TESTED_MANIFEST.json').write_text(json.dumps([record(path) for path in tested], indent=2) + '\n')
now = datetime.now(timezone.utc)
disk = subprocess.check_output(['df', '-k', '/private/tmp'], text=True)
usage = subprocess.check_output(['du', '-sk', str(ROOT)], text=True)
free_kib = int(disk.splitlines()[-1].split()[3])
scratch_kib = int(usage.split()[0])
assert free_kib > 16 * 1024 * 1024
assert scratch_kib <= 3 * 1024 * 1024
assert (now - STARTED).total_seconds() < 20 * 60
ledger = {'started_utc': STARTED.isoformat(), 'sealed_utc': now.isoformat(),
          'elapsed_seconds': (now - STARTED).total_seconds(), 'scratch_kib': scratch_kib,
          'free_disk_kib': free_kib, 'disk_raw': disk, 'scratch_raw': usage,
          'rust_build_invocations': 1, 'cargo_jobs': 2, 'test_threads': 1,
          'rust_compile_seconds_reported': 30.54, 'time_real_seconds_reported': 31.08,
          'time_user_seconds_reported': 40.18, 'time_sys_seconds_reported': 5.74,
          'maximum_rss': None, 'maximum_rss_reason': 'time -l sysctl denied by sandbox',
          'build_wrapper_exit_code': int((ROOT / 'logs/build.exit-code').read_text()),
          'cargo_child_exit_code': None, 'tests_passed': 9, 'tests_failed': 0,
          'tests_filtered': 192, 'patch_dry_run_exit_code': 0,
          'parent_edits': 0, 'git_writes': 0, 'network_downloads': 0,
          'verifier_solver_invocations': 0, 'compiler_binary_builds': 0,
          'vstd_runtime_builds': 0, 'native_target_app_executions': 0,
          'strict_persisted_warm_gate': 'UNMET', 'redb_open': 18,
          'independent_review_required': True}
(ROOT / 'RESOURCE_LEDGER.json').write_text(json.dumps(ledger, indent=2) + '\n')
artifacts = [ROOT / name for name in ('REPORT.md', 'COMMANDS.md', 'candidate.patch',
    'capture-inputs.py', 'run-focused.sh', 'seal.py', 'INPUT_MANIFEST.json',
    'TESTED_MANIFEST.json', 'RESOURCE_LEDGER.json')]
artifacts.extend(sorted((ROOT / 'logs').glob('*')))
artifacts.extend([ROOT / 'source/vir/src/infer/owned.rs', ROOT / 'source/vir/src/infer/owned/candidate_data.rs'])
(ROOT / 'OUTPUT_MANIFEST.json').write_text(json.dumps({'excludes_self': True,
    'artifacts': [record(path) for path in artifacts]}, indent=2) + '\n')
print(json.dumps(ledger, indent=2))
print('SEALED: candidate only; warm gate UNMET; all 18 redb OPEN; independent review required')
