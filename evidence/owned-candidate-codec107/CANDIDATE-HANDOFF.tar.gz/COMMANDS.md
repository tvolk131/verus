# Substantive command record

These commands are records, not authorization to perform another build in this
lane. Read-only evidence/source inspections are additionally retained in the
parent tool transcript. All authored files were created with `apply_patch`;
only rustfmt's configured formatting changed candidate source afterward.

## Preparation

```
pwd
date -u '+%Y-%m-%dT%H:%M:%SZ'
df -k /private/tmp
find source evidence -name AGENTS.md -print
mktemp -d /private/tmp/verus-owned-codec107-20261107-XXXXXX
mkdir -p "$scratch/source" "$scratch/baseline" "$scratch/logs"
cp source/Cargo.toml source/Cargo.lock "$scratch/source/"
cp -R source/vir source/air source/vir_macros "$scratch/source/"
cp source/vir/src/infer/owned.rs "$scratch/baseline/owned.rs"
```

`$scratch` resolved to `/private/tmp/verus-owned-codec107-20261107-kcJbs7`.
No root/scoped AGENTS.md existed in the inspected ancestor/source/evidence or
fresh scratch scopes. Three original source crates total approximately 4.5 MiB.

## Format, authenticate, build (one invocation)

```
mkdir -p /private/tmp/verus-owned-codec107-20261107-kcJbs7/tmp
python3 /private/tmp/verus-owned-codec107-20261107-kcJbs7/capture-inputs.py
rustup run 1.99.1 rustfmt --edition 2024 --config skip_children=true /private/tmp/verus-owned-codec107-20261107-kcJbs7/source/vir/src/infer/owned/candidate_data.rs
sh /private/tmp/verus-owned-codec107-20261107-kcJbs7/run-focused.sh
```

`run-focused.sh` contains the exact full `/usr/bin/time -l /usr/bin/env -i ...
cargo test --offline ... --jobs 2 -- --test-threads=1` command. Environment is
explicitly allowlisted there; no inherited secret/environment dump is retained.
The target directory and TMPDIR are inside fresh scratch. Original `.cargo`
workspace configuration is not copied into this reduced workspace.

## Patch and final validation

```
root=/private/tmp/verus-owned-codec107-20261107-kcJbs7
diff -u --label a/source/vir/src/infer/owned.rs --label b/source/vir/src/infer/owned.rs "$root/baseline/owned.rs" "$root/source/vir/src/infer/owned.rs" > "$root/candidate.patch"
diff -u --label /dev/null --label b/source/vir/src/infer/owned/candidate_data.rs /dev/null "$root/source/vir/src/infer/owned/candidate_data.rs" >> "$root/candidate.patch"
mkdir -p "$root/patch-check/source/vir/src/infer/owned"
cp "$root/baseline/owned.rs" "$root/patch-check/source/vir/src/infer/owned.rs"
patch --dry-run -p1 -d "$root/patch-check" < "$root/candidate.patch" > "$root/logs/patch-dry-run.stdout" 2> "$root/logs/patch-dry-run.stderr"
python3 "$root/capture-inputs.py"
rustup which --toolchain 1.99.1 rustc
rustup which --toolchain 1.99.1 cargo
df -k /private/tmp
du -sk "$root"
```

Both `diff` commands return 1 for expected differences; patch dry-run returns 0.
Final sealing is performed by `seal.py` and emits JSON hash/resource manifests.
