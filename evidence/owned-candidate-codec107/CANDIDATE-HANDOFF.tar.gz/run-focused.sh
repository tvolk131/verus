#!/bin/sh
set -eu
ROOT=/private/tmp/verus-owned-codec107-20261107-kcJbs7
cd "$ROOT/source"
date -u '+%Y-%m-%dT%H:%M:%SZ' > "$ROOT/logs/build-start.txt"
df -k /private/tmp > "$ROOT/logs/disk-before-build.txt"
du -sk "$ROOT" > "$ROOT/logs/scratch-before-build.txt"
set +e
/usr/bin/time -l /usr/bin/env -i \
  HOME=/Users/tommyvolk \
  PATH=/Users/tommyvolk/.cargo/bin:/usr/bin:/bin:/usr/sbin:/sbin \
  CARGO_HOME=/Users/tommyvolk/.cargo \
  RUSTUP_HOME=/Users/tommyvolk/.rustup \
  RUSTUP_TOOLCHAIN=1.99.1 \
  CARGO_NET_OFFLINE=true CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 \
  CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 \
  CARGO_TARGET_DIR="$ROOT/target" TMPDIR="$ROOT/tmp/" \
  RUSTFLAGS= RUST_MIN_STACK=20971520 \
  cargo test --offline --manifest-path "$ROOT/source/Cargo.toml" \
  -p vir --lib infer::owned::candidate_data::tests --jobs 2 -- --test-threads=1 \
  > "$ROOT/logs/build.stdout" 2> "$ROOT/logs/build.stderr"
result=$?
set -e
printf '%s\n' "$result" > "$ROOT/logs/build.exit-code"
date -u '+%Y-%m-%dT%H:%M:%SZ' > "$ROOT/logs/build-end.txt"
df -k /private/tmp > "$ROOT/logs/disk-after-build.txt"
du -sk "$ROOT" > "$ROOT/logs/scratch-after-build.txt"
printf 'focused build exit=%s\n' "$result"
tail -75 "$ROOT/logs/build.stderr"
cat "$ROOT/logs/build.stdout"
exit "$result"
