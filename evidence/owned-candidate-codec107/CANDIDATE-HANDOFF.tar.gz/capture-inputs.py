import hashlib
import json
from pathlib import Path

PARENT = Path('/Users/tommyvolk/.t3/worktrees/verus/t3-60978068')
ROOT = Path('/private/tmp/verus-owned-codec107-20261107-kcJbs7')
FILES = [PARENT / 'evidence/parallel-advancement107/PLAN.md',
         PARENT / 'evidence/hex-cache-diagnosis99/REPORT.md',
         PARENT / 'evidence/hex-cache-diagnosis99/README.md',
         Path('/private/tmp/verus-hex130-warm-gate-research-20261107-H5Lgfp/REPORT.md'),
         PARENT / 'source/Cargo.toml', PARENT / 'source/Cargo.lock', PARENT / 'rust-toolchain.toml']
for crate in ('vir', 'air', 'vir_macros'):
    FILES.extend(sorted((PARENT / 'source' / crate).rglob('*')))
records = []
for path in FILES:
    if path.is_file():
        content = path.read_bytes()
        records.append({'path': str(path), 'bytes': len(content),
                        'sha256': hashlib.sha256(content).hexdigest()})
manifest = ROOT / 'INPUT_MANIFEST.json'
if manifest.exists():
    original = json.loads(manifest.read_text())
    assert records == original, 'Parent inputs changed during candidate work'
    (ROOT / 'logs/input-reauthentication.txt').write_text(f'PASS {len(records)} input files unchanged\n')
else:
    manifest.write_text(json.dumps(records, indent=2) + '\n')
print(f'{len(records)} authenticated source/evidence input files')
