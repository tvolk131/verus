use super::*;
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};

const SCHEMA: &str = "owned-proposal-loop-free-v1";
const MAX_BYTES: usize = 262_144;
const MAX_NODES: usize = 2048;
const MAX_EXPANDED: usize = 4096;
const MAX_DEPTH: usize = 32;
const MAX_TYPES: usize = 128;
type CodecResult<Value> = Result<Value, &'static str>;
type Shape = Vec<(Ident, Vec<(Ident, Typ)>)>;

#[derive(Clone, Debug)]
struct Policy {
    compiler: String,
    configuration: String,
    target: String,
    trust: String,
    models: String,
}

#[derive(Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct Wire {
    schema: String,
    key: String,
    dependencies: Vec<String>,
    nodes: Vec<NodeData>,
    pre: usize,
    post: usize,
}

#[derive(Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct NodeData {
    typ: usize,
    data: Data,
}

#[derive(Clone, Serialize, Deserialize)]
#[serde(tag = "kind", content = "args", deny_unknown_fields)]
enum Data {
    Bool(bool),
    Integer(String),
    Parameter(usize),
    Result,
    Unary(UnaryOp, usize),
    Binary(BinaryOp, usize, usize),
    Logical(LogicalOp, usize, usize),
    If(usize, usize, usize),
    Constructor(String, Vec<usize>),
    Variant(String, usize),
    Field(String, usize, usize),
    Observation(usize, Vec<usize>),
}

impl Data {
    fn children(&self) -> Vec<usize> {
        match self {
            Self::Unary(_, operand) | Self::Variant(_, operand) | Self::Field(_, _, operand) => {
                vec![*operand]
            }
            Self::Binary(_, left, right) | Self::Logical(_, left, right) => vec![*left, *right],
            Self::If(condition, yes, no) => vec![*condition, *yes, *no],
            Self::Constructor(_, fields) | Self::Observation(_, fields) => fields.clone(),
            _ => vec![],
        }
    }
}

struct Context<'source> {
    function: &'source Function,
    datatypes: &'source [Datatype],
    observations: &'source [Function],
    types: Vec<Typ>,
    dependencies: Vec<String>,
    key: String,
}

fn digest(value: &str) -> String {
    Sha256::digest(value.as_bytes())
        .iter()
        .map(|byte| format!("{byte:02x}"))
        .collect()
}

fn leaf_body(function: &Function, observation: bool) -> CodecResult<()> {
    let body = function.x.body.as_ref().ok_or("missing current body")?;
    let mut remaining = MAX_EXPANDED;
    crate::ast_visitor::expr_visitor_check(body, &mut |_, expression| {
        remaining = remaining
            .checked_sub(1)
            .ok_or_else(|| unsupported(&expression.span, "codec source budget"))?;
        let forbidden = matches!(
            &expression.x,
            ExprX::Loop { .. }
                | ExprX::Closure(..)
                | ExprX::Quant(..)
                | ExprX::WithTriggers { .. }
                | ExprX::AssertAssume { .. }
        );
        let call = match &expression.x {
            ExprX::Call {
                target: CallTarget::Fun(_, name, ..),
                ..
            } => observation || name == &function.x.name,
            ExprX::Call { .. } => true,
            _ => false,
        };
        if forbidden || call {
            Err(unsupported(
                &expression.span,
                "codec requires loop-free nonrecursive source",
            ))
        } else {
            Ok(())
        }
    })
    .map_err(|_| "unsupported current body")
}

impl<'source> Context<'source> {
    fn new(
        function: &'source Function,
        datatypes: &'source [Datatype],
        observations: &'source [Function],
        dependencies: &[String],
        policy: &Policy,
    ) -> CodecResult<Self> {
        if [
            &policy.compiler,
            &policy.configuration,
            &policy.target,
            &policy.trust,
            &policy.models,
        ]
        .iter()
        .any(|component| component.is_empty() || component.len() > 16_384)
            || dependencies.len() > 128
            || observations.len() > 32
            || datatypes.len() > 128
        {
            return Err("invalid identity inputs");
        }
        let mut dependencies = dependencies.to_vec();
        dependencies.sort();
        if dependencies.iter().any(|key| {
            key.len() != 64
                || !key
                    .bytes()
                    .all(|byte| byte.is_ascii_digit() || (b'a'..=b'f').contains(&byte))
        }) || dependencies.windows(2).any(|pair| pair[0] == pair[1])
        {
            return Err("invalid dependency keys");
        }
        let all = observations
            .iter()
            .map(|item| (item.x.name.clone(), item.clone()))
            .collect();
        validate_signature(function, &all, datatypes).map_err(|_| "ineligible owned source")?;
        if !function.x.typ_params.is_empty() || !function.x.typ_bounds.is_empty() {
            return Err("generic source unsupported");
        }
        leaf_body(function, false)?;
        for (index, observation) in observations.iter().enumerate() {
            if !is_pure_observation(observation)
                || !observation.x.typ_params.is_empty()
                || !observation.x.typ_bounds.is_empty()
                || observation.x.proxy.is_some()
                || observation.x.attrs.is_external_body
                || observation
                    .x
                    .params
                    .iter()
                    .any(|parameter| parameter.x.mode != Mode::Spec)
                || observations[..index]
                    .iter()
                    .any(|prior| prior.x.name == observation.x.name)
                || observation.x.name == function.x.name
            {
                return Err("unapproved observation");
            }
            leaf_body(observation, true)?;
        }
        for (index, parameter) in function.x.params.iter().enumerate() {
            if parameter.x.name == function.x.inner_ret.x.name
                || function.x.params[..index]
                    .iter()
                    .any(|prior| prior.x.name == parameter.x.name)
            {
                return Err("ambiguous signature slots");
            }
        }
        let key = digest(&format!(
            "{SCHEMA}:{function:?}:{datatypes:?}:{observations:?}:{dependencies:?}:{policy:?}"
        ));
        let mut context = Self {
            function,
            datatypes,
            observations,
            types: vec![],
            dependencies,
            key,
        };
        context.add_type(&bool_typ(), &mut vec![])?;
        context.add_type(&int_typ(), &mut vec![])?;
        for parameter in function.x.params.iter() {
            context.add_type(&parameter.x.typ, &mut vec![])?;
        }
        context.add_type(&function.x.inner_ret.x.typ, &mut vec![])?;
        for observation in observations {
            for parameter in observation.x.params.iter() {
                context.add_type(&parameter.x.typ, &mut vec![])?;
            }
            context.add_type(&observation.x.inner_ret.x.typ, &mut vec![])?;
        }
        Ok(context)
    }

    fn shape(&self, typ: &Typ) -> CodecResult<Shape> {
        let TypX::Datatype(datatype, arguments, _) = &**typ else {
            return Err("not a structural value");
        };
        if let Dt::Tuple(arity) = datatype {
            if *arity != arguments.len() || *arity > 8 {
                return Err("tuple arity");
            }
            return Ok(vec![(
                crate::def::prefix_tuple_variant(*arity),
                arguments
                    .iter()
                    .enumerate()
                    .map(|(index, typ)| (crate::def::positional_field_ident(index), typ.clone()))
                    .collect(),
            )]);
        }
        if let Some(payload) = option(typ) {
            return Ok(vec![
                (Arc::new("None".into()), vec![]),
                (
                    Arc::new("Some".into()),
                    vec![(crate::def::positional_field_ident(0), payload.clone())],
                ),
            ]);
        }
        if let Some((success, failure)) = sums::result(typ) {
            return Ok(vec![
                (
                    Arc::new("Ok".into()),
                    vec![(crate::def::positional_field_ident(0), success.clone())],
                ),
                (
                    Arc::new("Err".into()),
                    vec![(crate::def::positional_field_ident(0), failure.clone())],
                ),
            ]);
        }
        if let Some(variants) = records::shape::variants(typ, self.datatypes) {
            return Ok(variants);
        }
        if let Some(fields) = records::shape::fields(typ, self.datatypes) {
            if let Some((first, _)) = fields.first() {
                return Ok(vec![(
                    first.variant.clone(),
                    fields
                        .iter()
                        .map(|(field, typ)| (field.field.clone(), typ.clone()))
                        .collect(),
                )]);
            }
        }
        Err("unsupported datatype")
    }

    fn add_type(&mut self, typ: &Typ, active: &mut Vec<Typ>) -> CodecResult<()> {
        if active.len() >= 12 || active.iter().any(|ancestor| same(ancestor, typ)) {
            return Err("recursive or deep type");
        }
        if self.types.iter().any(|known| same(known, typ)) {
            return Ok(());
        }
        if self.types.len() >= MAX_TYPES {
            return Err("type budget");
        }
        active.push(typ.clone());
        match &**typ {
            TypX::Bool
            | TypX::Int(
                IntRange::Int
                | IntRange::Nat
                | IntRange::USize
                | IntRange::ISize
                | IntRange::U(8 | 16 | 32 | 64 | 128)
                | IntRange::I(8 | 16 | 32 | 64 | 128),
            ) => {}
            TypX::Datatype(..) => {
                for (_, fields) in self.shape(typ)? {
                    for (_, field_type) in fields {
                        self.add_type(&field_type, active)?;
                    }
                }
            }
            _ => return Err("unsupported type"),
        }
        active.pop();
        if self.types.len() >= MAX_TYPES {
            return Err("type budget");
        }
        self.types.push(typ.clone());
        Ok(())
    }

    fn slot(&self, typ: &Typ) -> CodecResult<usize> {
        self.types
            .iter()
            .position(|current| same(current, typ))
            .ok_or("type outside current context")
    }

    fn variant(&self, typ: &Typ, name: &str) -> CodecResult<Vec<(Ident, Typ)>> {
        self.shape(typ)?
            .into_iter()
            .find(|(variant, _)| variant.as_str() == name)
            .map(|(_, fields)| fields)
            .ok_or("unknown variant")
    }

    fn encode_expression(
        &self,
        expression: &Expr,
        nodes: &mut Vec<NodeData>,
        depth: usize,
    ) -> CodecResult<usize> {
        if depth >= MAX_DEPTH || nodes.len() >= MAX_NODES {
            return Err("expression budget");
        }
        let mut child = |operand: &Expr| self.encode_expression(operand, nodes, depth + 1);
        let data = match &expression.x {
            ExprX::Const(Constant::Bool(value)) => Data::Bool(*value),
            ExprX::Const(Constant::Int(value)) if value.bits() <= 256 => {
                Data::Integer(value.to_string())
            }
            ExprX::Var(name) => {
                if name == &self.function.x.inner_ret.x.name {
                    Data::Result
                } else {
                    Data::Parameter(
                        self.function
                            .x
                            .params
                            .iter()
                            .position(|parameter| &parameter.x.name == name)
                            .ok_or("unbound variable")?,
                    )
                }
            }
            ExprX::Unary(operator, operand) => Data::Unary(*operator, child(operand)?),
            ExprX::Binary(operator, left, right) => {
                Data::Binary(*operator, child(left)?, child(right)?)
            }
            ExprX::Logical(operator, left, right) => {
                Data::Logical(*operator, child(left)?, child(right)?)
            }
            ExprX::If(condition, yes, Some(no)) => {
                Data::If(child(condition)?, child(yes)?, child(no)?)
            }
            ExprX::Ctor(datatype, variant, fields, None) => {
                if !matches!(&*expression.typ, TypX::Datatype(current, ..) if current == datatype) {
                    return Err("constructor datatype mismatch");
                }
                let layout = self.variant(&expression.typ, variant)?;
                if fields.len() != layout.len()
                    || fields
                        .iter()
                        .zip(&layout)
                        .any(|(field, (name, typ))| &field.name != name || !same(&field.a.typ, typ))
                {
                    return Err("constructor fields mismatch");
                }
                Data::Constructor(
                    variant.to_string(),
                    fields
                        .iter()
                        .map(|field| child(&field.a))
                        .collect::<CodecResult<_>>()?,
                )
            }
            ExprX::UnaryOpr(UnaryOpr::IsVariant { datatype, variant }, operand) => {
                if !matches!(&*operand.typ, TypX::Datatype(current, ..) if current == datatype) {
                    return Err("variant datatype mismatch");
                }
                Data::Variant(variant.to_string(), child(operand)?)
            }
            ExprX::UnaryOpr(UnaryOpr::Field(field), operand) => {
                if field.get_variant
                    || field.check != VariantCheck::None
                    || !matches!(&*operand.typ, TypX::Datatype(current, ..) if current == &field.datatype)
                {
                    return Err("unsupported field operation");
                }
                let layout = self.variant(&operand.typ, &field.variant)?;
                let index = layout
                    .iter()
                    .position(|(name, _)| name == &field.field)
                    .ok_or("unknown field")?;
                Data::Field(field.variant.to_string(), index, child(operand)?)
            }
            ExprX::Call {
                target:
                    CallTarget::Fun(CallTargetKind::Static, name, types, implementations, attributes),
                args,
                post_args: None,
                body: None,
            } if types.is_empty()
                && implementations.is_empty()
                && !attributes.const_var
                && !attributes.assume_external_allowed
                && attributes.autospec == AutospecUsage::Final =>
            {
                let index = self
                    .observations
                    .iter()
                    .position(|observation| &observation.x.name == name)
                    .ok_or("unapproved call")?;
                Data::Observation(
                    index,
                    args.iter().map(&mut child).collect::<CodecResult<_>>()?,
                )
            }
            _ => return Err("unsupported expression"),
        };
        if nodes.len() >= MAX_NODES {
            return Err("node budget");
        }
        let index = nodes.len();
        nodes.push(NodeData {
            typ: self.slot(&expression.typ)?,
            data,
        });
        Ok(index)
    }

    fn encode(&self, contract: &Contract) -> CodecResult<Vec<u8>> {
        let mut nodes = vec![];
        let pre = self.encode_expression(&contract.pre, &mut nodes, 0)?;
        let post = self.encode_expression(&contract.post, &mut nodes, 0)?;
        let wire = Wire {
            schema: SCHEMA.into(),
            key: self.key.clone(),
            dependencies: self.dependencies.clone(),
            nodes,
            pre,
            post,
        };
        let bytes = serde_json::to_vec(&wire).map_err(|_| "serialization")?;
        self.decode(&bytes)?;
        Ok(bytes)
    }

    fn decode(&self, bytes: &[u8]) -> CodecResult<Contract> {
        if bytes.is_empty() || bytes.len() > MAX_BYTES {
            return Err("byte budget");
        }
        let wire: Wire = serde_json::from_slice(bytes).map_err(|_| "malformed wire data")?;
        if wire.schema != SCHEMA || wire.key != self.key || wire.dependencies != self.dependencies {
            return Err("schema, key or dependency mismatch");
        }
        if wire.nodes.is_empty() || wire.nodes.len() > MAX_NODES {
            return Err("node budget");
        }
        if serde_json::to_vec(&wire).map_err(|_| "canonicalization")? != bytes {
            return Err("noncanonical data or unknown fields");
        }
        let mut terms: Vec<Term> = vec![];
        let mut depths: Vec<usize> = vec![];
        let mut uses_result = vec![];
        let span = &self.function.span;
        for (index, node) in wire.nodes.iter().enumerate() {
            let typ = self.types.get(node.typ).ok_or("unknown type slot")?;
            let children = node.data.children();
            if children.len() > 8 || children.iter().any(|child| *child >= index) {
                return Err("forward, recursive or oversized node");
            }
            let depth = 1 + children
                .iter()
                .map(|child| depths[*child])
                .max()
                .unwrap_or(0);
            let size = children
                .iter()
                .try_fold(1usize, |size, child| size.checked_add(terms[*child].size))
                .ok_or("expanded size overflow")?;
            if depth > MAX_DEPTH || size > MAX_EXPANDED {
                return Err("expanded expression budget");
            }
            let term_at = |child: usize| terms[child].clone();
            let expr_at = |child: usize| terms[child].expr.clone();
            let expression = match &node.data {
                Data::Bool(value) if matches!(&**typ, TypX::Bool) => {
                    ExprX::Const(Constant::Bool(*value))
                }
                Data::Integer(decimal) => {
                    if decimal.len() > 79 {
                        return Err("integer size");
                    }
                    let value: BigInt = decimal.parse().map_err(|_| "invalid integer")?;
                    if value.bits() > 256
                        || value.to_string() != *decimal
                        || !integer_fits(&value, typ)
                    {
                        return Err("integer type or canonicality");
                    }
                    ExprX::Const(Constant::Int(value))
                }
                Data::Parameter(slot) => {
                    let parameter = self
                        .function
                        .x
                        .params
                        .get(*slot)
                        .ok_or("unknown parameter slot")?;
                    if !same(typ, &parameter.x.typ) {
                        return Err("parameter type mismatch");
                    }
                    ExprX::Var(parameter.x.name.clone())
                }
                Data::Result => {
                    if !same(typ, &self.function.x.inner_ret.x.typ) {
                        return Err("result type mismatch");
                    }
                    ExprX::Var(self.function.x.inner_ret.x.name.clone())
                }
                Data::Unary(operator, operand) => {
                    if !matches!(
                        operator,
                        UnaryOp::Not | UnaryOp::BitNot(_) | UnaryOp::Clip { .. }
                    ) {
                        return Err("unsupported unary operator");
                    }
                    let built = summary::unary(span, *operator, term_at(*operand))
                        .map_err(|_| "unary type mismatch")?;
                    if !same(typ, &built.expr.typ) {
                        return Err("unary result mismatch");
                    }
                    built.expr.x.clone()
                }
                Data::Binary(
                    operator @ (BinaryOp::Eq(Mode::Spec | Mode::Exec) | BinaryOp::Ne),
                    left,
                    right,
                ) => {
                    if !matches!(&**typ, TypX::Bool)
                        || !same(&terms[*left].expr.typ, &terms[*right].expr.typ)
                    {
                        return Err("equality type mismatch");
                    }
                    ExprX::Binary(*operator, expr_at(*left), expr_at(*right))
                }
                Data::Binary(operator, left, right) => {
                    let built = summary::binary(span, *operator, term_at(*left), term_at(*right))
                        .map_err(|_| "binary type mismatch")?;
                    if !same(typ, &built.expr.typ) {
                        return Err("binary result mismatch");
                    }
                    built.expr.x.clone()
                }
                Data::Logical(operator, left, right) => {
                    if !matches!(&**typ, TypX::Bool)
                        || !matches!(&*terms[*left].expr.typ, TypX::Bool)
                        || !matches!(&*terms[*right].expr.typ, TypX::Bool)
                    {
                        return Err("logical type mismatch");
                    }
                    ExprX::Logical(*operator, expr_at(*left), expr_at(*right))
                }
                Data::If(condition, yes, no) => {
                    if !matches!(&*terms[*condition].expr.typ, TypX::Bool)
                        || !same(typ, &terms[*yes].expr.typ)
                        || !same(typ, &terms[*no].expr.typ)
                    {
                        return Err("conditional type mismatch");
                    }
                    ExprX::If(expr_at(*condition), expr_at(*yes), Some(expr_at(*no)))
                }
                Data::Constructor(variant, values) => {
                    let layout = self.variant(typ, variant)?;
                    if layout.len() != values.len()
                        || layout
                            .iter()
                            .zip(values)
                            .any(|((_, expected), value)| !same(expected, &terms[*value].expr.typ))
                    {
                        return Err("constructor arity or type");
                    }
                    let TypX::Datatype(datatype, ..) = &**typ else {
                        return Err("constructor type");
                    };
                    let fields = layout
                        .iter()
                        .zip(values)
                        .map(|((name, _), value)| {
                            crate::ast_util::ident_binder(name, &expr_at(*value))
                        })
                        .collect();
                    ExprX::Ctor(
                        datatype.clone(),
                        Arc::new(variant.clone()),
                        Arc::new(fields),
                        None,
                    )
                }
                Data::Variant(variant, value) => {
                    self.variant(&terms[*value].expr.typ, variant)?;
                    if !matches!(&**typ, TypX::Bool) {
                        return Err("variant result type");
                    }
                    let TypX::Datatype(datatype, ..) = &*terms[*value].expr.typ else {
                        return Err("variant input type");
                    };
                    ExprX::UnaryOpr(
                        UnaryOpr::IsVariant {
                            datatype: datatype.clone(),
                            variant: Arc::new(variant.clone()),
                        },
                        expr_at(*value),
                    )
                }
                Data::Field(variant, field, value) => {
                    let layout = self.variant(&terms[*value].expr.typ, variant)?;
                    let (name, expected) = layout.get(*field).ok_or("unknown field")?;
                    if !same(typ, expected) {
                        return Err("field type mismatch");
                    }
                    let TypX::Datatype(datatype, ..) = &*terms[*value].expr.typ else {
                        return Err("field input type");
                    };
                    ExprX::UnaryOpr(
                        UnaryOpr::Field(FieldOpr {
                            datatype: datatype.clone(),
                            variant: Arc::new(variant.clone()),
                            field: name.clone(),
                            get_variant: false,
                            check: VariantCheck::None,
                        }),
                        expr_at(*value),
                    )
                }
                Data::Observation(slot, arguments) => {
                    let observation = self
                        .observations
                        .get(*slot)
                        .ok_or("unapproved observation slot")?;
                    if !same(typ, &observation.x.inner_ret.x.typ)
                        || arguments.len() != observation.x.params.len()
                        || arguments.iter().zip(observation.x.params.iter()).any(
                            |(argument, parameter)| {
                                !same(&terms[*argument].expr.typ, &parameter.x.typ)
                            },
                        )
                    {
                        return Err("observation signature mismatch");
                    }
                    ExprX::Call {
                        target: CallTarget::Fun(
                            CallTargetKind::Static,
                            observation.x.name.clone(),
                            Arc::new(vec![]),
                            Arc::new(vec![]),
                            CallTargetAttrs {
                                autospec: AutospecUsage::Final,
                                const_var: false,
                                assume_external_allowed: false,
                            },
                        ),
                        args: Arc::new(
                            arguments
                                .iter()
                                .map(|argument| expr_at(*argument))
                                .collect(),
                        ),
                        post_args: None,
                        body: None,
                    }
                }
                _ => return Err("unsupported data or type"),
            };
            uses_result.push(
                matches!(node.data, Data::Result)
                    || children.iter().any(|child| uses_result[*child]),
            );
            terms.push(Term {
                view: None,
                expr: SpannedTyped::new(span, typ, expression),
                size,
            });
            depths.push(depth);
        }
        let pre = terms.get(wire.pre).ok_or("invalid pre root")?;
        let post = terms.get(wire.post).ok_or("invalid post root")?;
        if uses_result[wire.pre] {
            return Err("result in precondition");
        }
        let mut reachable = vec![false; wire.nodes.len()];
        reachable[wire.pre] = true;
        reachable[wire.post] = true;
        for index in (0..wire.nodes.len()).rev() {
            if reachable[index] {
                for child in wire.nodes[index].data.children() {
                    reachable[child] = true;
                }
            }
        }
        if reachable.iter().any(|used| !used) {
            return Err("orphan data");
        }
        Contract::new(pre.expr.clone(), post.expr.clone()).map_err(|_| "nonboolean roots")
    }
}

fn integer_fits(value: &BigInt, typ: &Typ) -> bool {
    let positive = value >= &BigInt::from(0);
    match &**typ {
        TypX::Int(IntRange::Int) => true,
        TypX::Int(IntRange::Nat) => positive,
        TypX::Int(IntRange::U(bits)) => positive && value.bits() <= u64::from(*bits),
        TypX::Int(IntRange::I(bits)) => {
            let bound = BigInt::from(1) << (*bits - 1);
            value >= &(-bound.clone()) && value < &bound
        }
        _ => false,
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::infer::tests::{function, input, span};

    #[path = "/private/tmp/verus-codec107-review-20261107-t9U1yK/reviewer_tests.rs"]
    mod reviewer_tests;

    fn policy() -> Policy {
        Policy {
            compiler: "source-bound-library-prototype".into(),
            configuration: "cfg=fixture;features=none;exact;safety=checked;export=/scratch/a"
                .into(),
            target: "aarch64-apple-darwin;word_bits=64".into(),
            trust: "no-added-trust".into(),
            models: "current-vocabulary-and-dependency-policy".into(),
        }
    }

    fn named_type(krate: CrateId, segments: &[&str], arguments: Vec<Typ>) -> Typ {
        Arc::new(TypX::Datatype(
            Dt::Path(Arc::new(PathX {
                krate,
                segments: Arc::new(
                    segments
                        .iter()
                        .map(|segment| Arc::new((*segment).into()))
                        .collect(),
                ),
            })),
            Arc::new(arguments),
            Arc::new(vec![]),
        ))
    }

    fn constructor(typ: &Typ, variant: &str, values: Vec<(&str, Expr)>) -> Expr {
        let TypX::Datatype(datatype, ..) = &**typ else {
            panic!("fixture datatype");
        };
        SpannedTyped::new(
            &span(),
            typ,
            ExprX::Ctor(
                datatype.clone(),
                Arc::new(variant.into()),
                Arc::new(
                    values
                        .into_iter()
                        .map(|(name, value)| {
                            crate::ast_util::ident_binder(&Arc::new(name.into()), &value)
                        })
                        .collect(),
                ),
                None,
            ),
        )
    }

    fn fixture() -> (Function, Vec<Datatype>) {
        let byte = input("x").typ.clone();
        let pair = crate::ast_util::mk_tuple_typ(&Arc::new(vec![byte.clone(), byte.clone()]));
        let inner = named_type(
            CrateId::Core,
            &["result", "Result"],
            vec![byte.clone(), pair],
        );
        let optional = named_type(CrateId::Core, &["option", "Option"], vec![byte.clone()]);
        let nested = named_type(
            CrateId::Core,
            &["result", "Result"],
            vec![optional, inner.clone()],
        );
        let output = named_type(
            CrateId::Id(Arc::new("codec_fixture".into()), 1),
            &["Envelope"],
            vec![],
        );
        let TypX::Datatype(datatype, ..) = &*output else {
            unreachable!()
        };
        let visibility = Visibility {
            restricted_to: None,
        };
        let declaration = crate::def::Spanned::new(
            span(),
            DatatypeX {
                name: datatype.clone(),
                proxy: None,
                owning_module: None,
                visibility: visibility.clone(),
                transparency: DatatypeTransparency::WhenVisible(visibility.clone()),
                typ_params: Arc::new(vec![]),
                typ_bounds: Arc::new(vec![]),
                variants: Arc::new(vec![Variant {
                    name: Arc::new("Envelope".into()),
                    fields: Arc::new(vec![
                        crate::ast_util::ident_binder(
                            &Arc::new("payload".into()),
                            &(nested.clone(), Mode::Exec, visibility.clone()),
                        ),
                        crate::ast_util::ident_binder(
                            &Arc::new("tag".into()),
                            &(byte, Mode::Exec, visibility),
                        ),
                    ]),
                    ctor_style: CtorPrintStyle::Braces,
                }]),
                mode: Mode::Exec,
                ext_equal: false,
                user_defined_invariant_fn: None,
                sized_constraint: None,
                destructor: false,
            },
        );
        let failure = constructor(
            &inner,
            "Err",
            vec![(
                "0",
                crate::ast_util::mk_tuple(&span(), &Arc::new(vec![input("x"), input("y")])),
            )],
        );
        let payload = constructor(&nested, "Err", vec![("0", failure)]);
        let body = constructor(
            &output,
            "Envelope",
            vec![("payload", payload), ("tag", input("x"))],
        );
        let original = function("codec_fixture", body);
        let mut definition = original.x.clone();
        let mut result = definition.inner_ret.x.clone();
        result.typ = output;
        definition.inner_ret = definition.inner_ret.new_x(result);
        definition.outer_ret = definition.inner_ret.clone();
        Arc::make_mut(&mut definition.attrs).infer_owned = true;
        (original.new_x(definition), vec![declaration])
    }

    fn contract(function: &Function) -> Contract {
        let result = SpannedTyped::new(
            &function.span,
            &function.x.inner_ret.x.typ,
            ExprX::Var(function.x.inner_ret.x.name.clone()),
        );
        Contract::new(
            boolean(&function.span, true).expr,
            SpannedTyped::new(
                &function.span,
                &bool_typ(),
                ExprX::Binary(
                    BinaryOp::Eq(Mode::Spec),
                    result,
                    function.x.body.clone().unwrap(),
                ),
            ),
        )
        .unwrap()
    }

    fn mutate(context: &Context<'_>, bytes: &[u8], change: impl FnOnce(&mut Wire)) {
        let mut wire: Wire = serde_json::from_slice(bytes).unwrap();
        change(&mut wire);
        assert!(context.decode(&serde_json::to_vec(&wire).unwrap()).is_err());
    }

    #[test]
    fn real_vir_nested_result_error_tuple_roundtrip_is_lossless() {
        let (source, datatypes) = fixture();
        let context = Context::new(&source, &datatypes, &[], &[], &policy()).unwrap();
        let original = contract(&source);
        let bytes = context.encode(&original).unwrap();
        let decoded = context.decode(&bytes).unwrap();
        assert_eq!(format!("{:?}", original.pre), format!("{:?}", decoded.pre));
        assert_eq!(
            format!("{:?}", original.post),
            format!("{:?}", decoded.post)
        );
        assert_eq!(bytes, context.encode(&decoded).unwrap());
        let wire: Wire = serde_json::from_slice(&bytes).unwrap();
        assert_eq!(
            wire.nodes
                .iter()
                .filter(|node| matches!(&node.data, Data::Constructor(name, _) if name == "Err"))
                .count(),
            2
        );
        assert!(
            wire.nodes.iter().any(
                |node| matches!(&node.data, Data::Constructor(_, values) if values.len() == 2)
            )
        );
    }

    #[test]
    fn schema_key_dependencies_and_authority_fields_are_rejected() {
        let (source, datatypes) = fixture();
        let context =
            Context::new(&source, &datatypes, &[], &[digest("callee")], &policy()).unwrap();
        let bytes = context.encode(&contract(&source)).unwrap();
        mutate(&context, &bytes, |wire| wire.schema.push_str("-stale"));
        mutate(&context, &bytes, |wire| wire.key = digest("other"));
        mutate(&context, &bytes, |wire| wire.dependencies.clear());
        mutate(&context, &bytes, |wire| {
            wire.dependencies.push(digest("callee"))
        });
        for authority in ["accepted", "proved", "solver_outcome", "certificate"] {
            let mut value: serde_json::Value = serde_json::from_slice(&bytes).unwrap();
            value[authority] = serde_json::json!(true);
            assert!(
                context
                    .decode(&serde_json::to_vec(&value).unwrap())
                    .is_err()
            );
        }
        let text = String::from_utf8(bytes).unwrap();
        for forbidden in [
            "accepted",
            "proved",
            "solver_outcome",
            "certificate",
            "raw_span",
        ] {
            assert!(!text.contains(forbidden));
        }
    }

    #[test]
    fn malformed_oversized_truncated_unknown_and_noncanonical_input_fail_closed() {
        let (source, datatypes) = fixture();
        let context = Context::new(&source, &datatypes, &[], &[], &policy()).unwrap();
        let bytes = context.encode(&contract(&source)).unwrap();
        for length in 0..bytes.len() {
            assert!(context.decode(&bytes[..length]).is_err());
        }
        assert!(context.decode(&vec![b' '; MAX_BYTES + 1]).is_err());
        assert!(context.decode(b"{broken}").is_err());
        let mut unknown: serde_json::Value = serde_json::from_slice(&bytes).unwrap();
        unknown["nodes"][0]["data"]["kind"] = serde_json::json!("InjectExecutableBody");
        assert!(
            context
                .decode(&serde_json::to_vec(&unknown).unwrap())
                .is_err()
        );
        let mut trailing = bytes.clone();
        trailing.extend_from_slice(b"{}");
        assert!(context.decode(&trailing).is_err());
        let mut whitespace = bytes;
        whitespace.push(b' ');
        assert!(context.decode(&whitespace).is_err());
    }

    #[test]
    fn type_slot_parameter_result_constructor_and_projection_mismatches_fail_closed() {
        let (source, datatypes) = fixture();
        let context = Context::new(&source, &datatypes, &[], &[], &policy()).unwrap();
        let bytes = context.encode(&contract(&source)).unwrap();
        mutate(&context, &bytes, |wire| wire.nodes[0].typ = usize::MAX);
        mutate(&context, &bytes, |wire| wire.pre = usize::MAX);
        mutate(&context, &bytes, |wire| {
            wire.nodes[0].data = Data::Parameter(usize::MAX)
        });
        mutate(&context, &bytes, |wire| wire.nodes[0].data = Data::Result);
        mutate(&context, &bytes, |wire| {
            wire.pre = wire.post;
        });
        mutate(&context, &bytes, |wire| {
            let node = wire
                .nodes
                .iter_mut()
                .find(|node| matches!(node.data, Data::Constructor(..)))
                .unwrap();
            node.data = Data::Constructor("NotAVariant".into(), vec![]);
        });
        mutate(&context, &bytes, |wire| {
            let node = wire
                .nodes
                .iter_mut()
                .find(
                    |node| matches!(&node.data, Data::Constructor(_, fields) if fields.len() == 2),
                )
                .unwrap();
            if let Data::Constructor(_, fields) = &mut node.data {
                fields.pop();
            }
        });
        mutate(&context, &bytes, |wire| {
            wire.nodes[wire.post].data = Data::Field("Envelope".into(), 99, 1)
        });
        mutate(&context, &bytes, |wire| {
            wire.nodes[wire.post].data = Data::Variant("Bogus".into(), 1)
        });
        mutate(&context, &bytes, |wire| {
            wire.nodes[wire.post].data = Data::Observation(0, vec![])
        });
    }

    #[test]
    fn forward_recursive_orphan_deep_and_expanding_graphs_are_rejected() {
        let (source, datatypes) = fixture();
        let context = Context::new(&source, &datatypes, &[], &[], &policy()).unwrap();
        let bytes = context.encode(&contract(&source)).unwrap();
        mutate(&context, &bytes, |wire| {
            wire.nodes[0].data = Data::Unary(UnaryOp::Not, 0)
        });
        mutate(&context, &bytes, |wire| {
            wire.nodes[0].data = Data::Unary(UnaryOp::Not, usize::MAX)
        });
        mutate(&context, &bytes, |wire| {
            wire.nodes.push(wire.nodes[0].clone())
        });
        mutate(&context, &bytes, |wire| {
            wire.nodes = vec![wire.nodes[0].clone(); MAX_NODES + 1]
        });
        mutate(&context, &bytes, |wire| {
            let bool_slot = context.slot(&bool_typ()).unwrap();
            wire.nodes = vec![NodeData {
                typ: bool_slot,
                data: Data::Bool(true),
            }];
            for index in 0..MAX_DEPTH {
                wire.nodes.push(NodeData {
                    typ: bool_slot,
                    data: Data::Unary(UnaryOp::Not, index),
                });
            }
            wire.pre = 0;
            wire.post = wire.nodes.len() - 1;
        });
        mutate(&context, &bytes, |wire| {
            let bool_slot = context.slot(&bool_typ()).unwrap();
            wire.nodes = vec![NodeData {
                typ: bool_slot,
                data: Data::Bool(true),
            }];
            for index in 0..13 {
                wire.nodes.push(NodeData {
                    typ: bool_slot,
                    data: Data::Logical(LogicalOp::And, index, index),
                });
            }
            wire.pre = 0;
            wire.post = wire.nodes.len() - 1;
        });
    }

    #[test]
    fn integers_operators_binders_and_unapproved_calls_are_restricted() {
        let (source, datatypes) = fixture();
        let context = Context::new(&source, &datatypes, &[], &[], &policy()).unwrap();
        let bytes = context.encode(&contract(&source)).unwrap();
        for decimal in [
            "01".to_string(),
            "-0".into(),
            "not-int".into(),
            "9".repeat(80),
            "256".into(),
            "-1".into(),
        ] {
            mutate(&context, &bytes, |wire| {
                let node = wire
                    .nodes
                    .iter_mut()
                    .find(|node| matches!(node.data, Data::Parameter(_)))
                    .unwrap();
                node.data = Data::Integer(decimal);
            });
        }
        mutate(&context, &bytes, |wire| {
            wire.nodes[wire.post].data = Data::Unary(UnaryOp::Not, 1)
        });
        mutate(&context, &bytes, |wire| {
            wire.nodes[wire.post].data = Data::Binary(BinaryOp::StrGetChar, 0, 0)
        });
        let unsupported_formula = boolean(&span(), true).expr.new_x(ExprX::WithTriggers {
            triggers: Arc::new(vec![]),
            body: boolean(&span(), true).expr,
        });
        assert!(
            context
                .encode(&Contract::new(unsupported_formula, boolean(&span(), true).expr).unwrap())
                .is_err()
        );
        let call = SpannedTyped::new(
            &span(),
            &bool_typ(),
            ExprX::Call {
                target: CallTarget::AssumeExternal,
                args: Arc::new(vec![]),
                post_args: None,
                body: None,
            },
        );
        assert!(
            context
                .encode(&Contract::new(call, boolean(&span(), true).expr).unwrap())
                .is_err()
        );
    }

    #[test]
    fn all_identity_components_and_output_paths_remain_keyed() {
        let (source, datatypes) = fixture();
        let baseline_policy = policy();
        let baseline = Context::new(&source, &datatypes, &[], &[], &baseline_policy).unwrap();
        for field in 0..5 {
            let mut changed = baseline_policy.clone();
            match field {
                0 => changed.compiler.push('!'),
                1 => changed.configuration.push_str(";export=/scratch/b"),
                2 => changed.target.push('!'),
                3 => changed.trust.push('!'),
                _ => changed.models.push('!'),
            }
            assert_ne!(
                baseline.key,
                Context::new(&source, &datatypes, &[], &[], &changed)
                    .unwrap()
                    .key
            );
        }
        assert_ne!(
            baseline.key,
            Context::new(
                &source,
                &datatypes,
                &[],
                &[digest("dependency")],
                &baseline_policy
            )
            .unwrap()
            .key
        );
        let changed_body = source.new_x(FunctionX {
            body: Some(source.x.body.as_ref().unwrap().new_x(ExprX::If(
                boolean(&span(), true).expr,
                source.x.body.clone().unwrap(),
                Some(source.x.body.clone().unwrap()),
            ))),
            ..source.x.clone()
        });
        assert_ne!(
            baseline.key,
            Context::new(&changed_body, &datatypes, &[], &[], &baseline_policy)
                .unwrap()
                .key
        );
        let mut changed_declaration = datatypes[0].x.clone();
        changed_declaration.ext_equal = !changed_declaration.ext_equal;
        let changed_datatypes = vec![datatypes[0].new_x(changed_declaration)];
        assert_ne!(
            baseline.key,
            Context::new(&source, &changed_datatypes, &[], &[], &baseline_policy)
                .unwrap()
                .key
        );
        assert!(
            Context::new(
                &source,
                &datatypes,
                &[],
                &["bad-key".into()],
                &baseline_policy
            )
            .is_err()
        );
        assert!(
            Context::new(
                &source,
                &datatypes,
                &[],
                &[digest("same"), digest("same")],
                &baseline_policy
            )
            .is_err()
        );
    }

    #[test]
    fn current_source_eligibility_and_recursive_types_fail_closed() {
        let (source, datatypes) = fixture();
        for field in 0..4 {
            let mut changed = source.x.clone();
            match field {
                0 => Arc::make_mut(&mut changed.attrs).infer_allow_approx = true,
                1 => Arc::make_mut(&mut changed.attrs).is_external_body = true,
                2 => changed.require = Arc::new(vec![boolean(&span(), true).expr]),
                _ => changed.body = None,
            }
            assert!(Context::new(&source.new_x(changed), &datatypes, &[], &[], &policy()).is_err());
        }
        let mut recursive = datatypes[0].x.clone();
        let fields = &mut Arc::make_mut(&mut recursive.variants)[0].fields;
        Arc::make_mut(&mut Arc::make_mut(fields)[0]).a.0 = source.x.inner_ret.x.typ.clone();
        assert!(
            Context::new(
                &source,
                &[datatypes[0].new_x(recursive)],
                &[],
                &[],
                &policy()
            )
            .is_err()
        );
        let mut context = Context::new(&source, &datatypes, &[], &[], &policy()).unwrap();
        let unsupported = Arc::new(TypX::Decorate(
            TypDecoration::Ref,
            None,
            input("x").typ.clone(),
        ));
        assert!(context.add_type(&unsupported, &mut vec![]).is_err());
        let mut deep = input("x").typ.clone();
        for _ in 0..13 {
            deep = named_type(CrateId::Core, &["option", "Option"], vec![deep]);
        }
        assert!(context.add_type(&deep, &mut vec![]).is_err());
    }

    #[test]
    fn approved_leaf_observations_and_projections_rebind_current_typed_nodes() {
        let (source, datatypes) = fixture();
        let base = function("digit_observation", input("x"));
        let mut definition = base.x.clone();
        definition.mode = Mode::Spec;
        definition.params = Arc::new(
            definition
                .params
                .iter()
                .map(|parameter| {
                    parameter.new_x(ParamX {
                        mode: Mode::Spec,
                        ..parameter.x.clone()
                    })
                })
                .collect(),
        );
        definition.inner_ret = definition.inner_ret.new_x(ParamX {
            mode: Mode::Spec,
            ..definition.inner_ret.x.clone()
        });
        definition.outer_ret = definition.inner_ret.clone();
        Arc::make_mut(&mut definition.attrs).infer = false;
        let observations = vec![base.new_x(definition)];
        let context = Context::new(&source, &datatypes, &observations, &[], &policy()).unwrap();
        let call = SpannedTyped::new(
            &span(),
            &input("x").typ,
            ExprX::Call {
                target: CallTarget::Fun(
                    CallTargetKind::Static,
                    observations[0].x.name.clone(),
                    Arc::new(vec![]),
                    Arc::new(vec![]),
                    CallTargetAttrs {
                        autospec: AutospecUsage::Final,
                        const_var: false,
                        assume_external_allowed: false,
                    },
                ),
                args: Arc::new(vec![input("x"), input("y")]),
                post_args: None,
                body: None,
            },
        );
        let pre = SpannedTyped::new(
            &span(),
            &bool_typ(),
            ExprX::Binary(BinaryOp::Eq(Mode::Spec), call, input("x")),
        );
        let proposed = Contract::new(pre, contract(&source).post).unwrap();
        let bytes = context.encode(&proposed).unwrap();
        assert_eq!(
            bytes,
            context.encode(&context.decode(&bytes).unwrap()).unwrap()
        );
        let mut changed = observations[0].x.clone();
        changed.body = Some(input("y"));
        let changed_observations = vec![observations[0].new_x(changed)];
        let other =
            Context::new(&source, &datatypes, &changed_observations, &[], &policy()).unwrap();
        assert_ne!(context.key, other.key);
        assert!(other.decode(&bytes).is_err());
        mutate(&context, &bytes, |wire| {
            let node = wire
                .nodes
                .iter_mut()
                .find(|node| matches!(node.data, Data::Observation(..)))
                .unwrap();
            node.data = Data::Observation(0, vec![]);
        });
        let mut recursive = observations[0].x.clone();
        recursive.body = Some(proposed.pre.clone());
        assert!(
            Context::new(
                &source,
                &datatypes,
                &[observations[0].new_x(recursive)],
                &[],
                &policy()
            )
            .is_err()
        );
    }
}
