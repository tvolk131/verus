import datetime
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tarfile

from review_control import ROOT, authenticate, identity

authenticate('exit')
tested = json.loads((ROOT / 'review-tested-source-manifest.json').read_text())
for record in tested:
    assert identity(Path(record['path'])) == record, record['path']
source_copy = json.loads((ROOT / 'source-copy-manifest.json').read_text())
modified_sources = [record['path'] for record in source_copy if identity(Path(record['path'])) != record]
assert modified_sources == [str(ROOT / 'source/vir/src/infer/owned/candidate_data.rs')]
binary_candidates = [filename for filename in (ROOT / 'target/debug/deps').glob('vir-*') if filename.is_file() and not filename.suffix and filename.stat().st_mode & 0o111]
assert len(binary_candidates) == 1
accounting = {
    'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'review_start_utc': '2026-11-08T02:59:48+00:00',
    'build_count': 1,
    'cargo_child_exit': int((ROOT / 'logs/cargo.exit-code').read_text()),
    'scratch_kib': int(subprocess.check_output(['/usr/bin/du', '-sk', str(ROOT)]).split()[0]),
    'global_free_bytes': shutil.disk_usage('/private/tmp').free,
    'tested_source_records_unchanged': len(tested),
    'modified_sources_relative_to_candidate': modified_sources,
    'executed_test_binary': identity(binary_candidates[0]),
    'parent_candidate_edits': False,
    'git_writes': False,
    'network_or_downloads': False,
}
assert accounting['scratch_kib'] < 3 * 1024 * 1024
assert accounting['global_free_bytes'] > 16 * 1024 ** 3
(ROOT / 'FINAL_ACCOUNTING.json').write_text(json.dumps(accounting, indent=2) + '\n')
payloads = [ROOT / name for name in ['REVIEW.md', 'review_control.py', 'reviewer_tests.rs', 'seal_review.py', 'entry-authentication.json', 'exit-authentication.json', 'source-copy-manifest.json', 'review-tested-source-manifest.json', 'lock-comparison.json', 'FINAL_ACCOUNTING.json', 'source/vir/src/infer/owned.rs', 'source/vir/src/infer/owned/candidate_data.rs', 'source/Cargo.toml', 'source/Cargo.lock']]
payloads.extend(sorted((ROOT / 'logs').glob('*')))
manifest = {'excludes_self_and_archive': True, 'artifacts': [identity(filename) for filename in payloads]}
(ROOT / 'REVIEW_OUTPUT_MANIFEST.json').write_text(json.dumps(manifest, indent=2) + '\n')
with tarfile.open(ROOT / 'REVIEW-HANDOFF.tar.gz', 'w:gz') as archive:
    for filename in payloads + [ROOT / 'REVIEW_OUTPUT_MANIFEST.json']:
        archive.add(filename, arcname=str(filename.relative_to(ROOT)), recursive=False)
with tarfile.open(ROOT / 'REVIEW-HANDOFF.tar.gz', 'r:gz') as archive:
    for member in archive.getmembers():
        assert archive.extractfile(member).read() == (ROOT / member.name).read_bytes()
for filename in [ROOT / 'REVIEW.md', ROOT / 'REVIEW_OUTPUT_MANIFEST.json', ROOT / 'REVIEW-HANDOFF.tar.gz']:
    print(json.dumps(identity(filename)))
print(json.dumps(accounting, indent=2))
