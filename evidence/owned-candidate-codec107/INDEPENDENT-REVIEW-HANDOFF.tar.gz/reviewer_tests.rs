use super::*;

fn equality(left: Expr, right: Expr) -> Expr {
    SpannedTyped::new(&span(), &bool_typ(), ExprX::Binary(BinaryOp::Eq(Mode::Spec), left, right))
}

fn roundtrip(context: &Context<'_>, expression: Expr) {
    let proposed = Contract::new(expression, contract(context.function).post).unwrap();
    let bytes = context.encode(&proposed).unwrap();
    let decoded = context.decode(&bytes).unwrap();
    assert_eq!(format!("{:?}", proposed.pre), format!("{:?}", decoded.pre));
    assert_eq!(format!("{:?}", proposed.post), format!("{:?}", decoded.post));
    assert_eq!(bytes, context.encode(&decoded).unwrap());
}

fn projection(context: &Context<'_>, value: Expr, variant: &str, field_index: usize) -> Expr {
    let layout = context.variant(&value.typ, variant).unwrap();
    let (name, field_type) = &layout[field_index];
    let TypX::Datatype(datatype, ..) = &*value.typ else { panic!("datatype") };
    SpannedTyped::new(&span(), field_type, ExprX::UnaryOpr(UnaryOpr::Field(FieldOpr {
        datatype: datatype.clone(), variant: Arc::new(variant.into()), field: name.clone(),
        get_variant: false, check: VariantCheck::None,
    }), value))
}

fn observation_definition() -> Function {
    let base = function("review_observation", input("x"));
    let mut definition = base.x.clone();
    definition.mode = Mode::Spec;
    definition.params = Arc::new(definition.params.iter().map(|parameter| {
        parameter.new_x(ParamX { mode: Mode::Spec, ..parameter.x.clone() })
    }).collect());
    definition.inner_ret = definition.inner_ret.new_x(ParamX { mode: Mode::Spec, ..definition.inner_ret.x.clone() });
    definition.outer_ret = definition.inner_ret.clone();
    Arc::make_mut(&mut definition.attrs).infer = false;
    base.new_x(definition)
}

fn static_call(observation: &Function) -> Expr {
    SpannedTyped::new(&span(), &observation.x.inner_ret.x.typ, ExprX::Call {
        target: CallTarget::Fun(CallTargetKind::Static, observation.x.name.clone(), Arc::new(vec![]), Arc::new(vec![]), CallTargetAttrs {
            autospec: AutospecUsage::Final, const_var: false, assume_external_allowed: false,
        }),
        args: Arc::new(vec![input("x"), input("y")]), post_args: None, body: None,
    })
}

#[test]
fn positive_option_variant_projection_and_conditionals() {
    let (source, datatypes) = fixture();
    let context = Context::new(&source, &datatypes, &[], &[], &policy()).unwrap();
    let option_type = context.types.iter().find(|typ| option(typ).is_some()).unwrap();
    let some = constructor(option_type, "Some", vec![("0", input("x"))]);
    let none = constructor(option_type, "None", vec![]);
    roundtrip(&context, equality(some.clone(), some.clone()));
    roundtrip(&context, equality(none.clone(), none.clone()));
    let TypX::Datatype(datatype, ..) = &**option_type else { panic!("option") };
    let variant = SpannedTyped::new(&span(), &bool_typ(), ExprX::UnaryOpr(UnaryOpr::IsVariant {
        datatype: datatype.clone(), variant: Arc::new("Some".into()),
    }, some.clone()));
    roundtrip(&context, variant.clone());
    let payload = projection(&context, some.clone(), "Some", 0);
    roundtrip(&context, equality(payload, input("x")));
    let conditional = SpannedTyped::new(&span(), option_type, ExprX::If(variant, some, Some(none)));
    roundtrip(&context, equality(conditional.clone(), conditional));
    let record = source.x.body.clone().unwrap();
    let outer_error = projection(&context, record, "Envelope", 0);
    let inner_error = projection(&context, outer_error, "Err", 0);
    let tuple = projection(&context, inner_error, "Err", 0);
    let tuple_variant = context.shape(&tuple.typ).unwrap()[0].0.clone();
    let second = projection(&context, tuple, &tuple_variant, 1);
    roundtrip(&context, equality(second, input("y")));
}

#[test]
fn positive_arithmetic_bitwise_unary_and_logical() {
    let (source, datatypes) = fixture();
    let context = Context::new(&source, &datatypes, &[], &[], &policy()).unwrap();
    let operand = || Term { view: None, expr: input("x"), size: 1 };
    let arithmetic = summary::binary(&span(), BinaryOp::Arith(ArithOp::Add(OverflowBehavior::Allow)), operand(), operand()).unwrap().expr;
    roundtrip(&context, equality(arithmetic.clone(), arithmetic));
    let bitwise = summary::binary(&span(), BinaryOp::Bitwise(BitwiseOp::BitXor, BitshiftBehavior::Allow), operand(), operand()).unwrap().expr;
    roundtrip(&context, equality(bitwise.clone(), bitwise));
    let inverted = summary::unary(&span(), UnaryOp::BitNot(Some(IntegerTypeBitwidth::Width(8))), operand()).unwrap().expr;
    roundtrip(&context, equality(inverted.clone(), inverted));
    let clipped = summary::unary(&span(), UnaryOp::Clip { range: IntRange::Int, truncate: false }, operand()).unwrap().expr;
    roundtrip(&context, equality(clipped.clone(), clipped));
    let logical = SpannedTyped::new(&span(), &bool_typ(), ExprX::Logical(LogicalOp::And, boolean(&span(), true).expr, boolean(&span(), false).expr));
    roundtrip(&context, SpannedTyped::new(&span(), &bool_typ(), ExprX::Unary(UnaryOp::Not, logical)));
}

#[test]
fn positive_value_enum_construction_and_variant() {
    let (source, datatypes) = fixture();
    let mut definition = datatypes[0].x.clone();
    Arc::make_mut(&mut definition.variants).push(Variant {
        name: Arc::new("Empty".into()), fields: Arc::new(vec![]), ctor_style: CtorPrintStyle::Braces,
    });
    let declarations = vec![datatypes[0].new_x(definition)];
    let context = Context::new(&source, &declarations, &[], &[], &policy()).unwrap();
    let empty = constructor(&source.x.inner_ret.x.typ, "Empty", vec![]);
    roundtrip(&context, equality(empty.clone(), empty.clone()));
    let TypX::Datatype(datatype, ..) = &*empty.typ else { panic!("enum") };
    roundtrip(&context, SpannedTyped::new(&span(), &bool_typ(), ExprX::UnaryOpr(UnaryOpr::IsVariant {
        datatype: datatype.clone(), variant: Arc::new("Empty".into()),
    }, empty)));
}

#[test]
fn integer_boundaries_and_result_taint_under_conditionals() {
    let (source, datatypes) = fixture();
    let mut context = Context::new(&source, &datatypes, &[], &[], &policy()).unwrap();
    let signed = Arc::new(TypX::Int(IntRange::I(8)));
    context.add_type(&signed, &mut vec![]).unwrap();
    for decimal in ["-128", "127"] {
        let value = SpannedTyped::new(&span(), &signed, ExprX::Const(Constant::Int(decimal.parse().unwrap())));
        roundtrip(&context, equality(value.clone(), value));
    }
    for decimal in ["-129", "128"] {
        let value = SpannedTyped::new(&span(), &signed, ExprX::Const(Constant::Int(decimal.parse().unwrap())));
        assert!(context.encode(&Contract::new(equality(value.clone(), value), contract(&source).post).unwrap()).is_err());
    }
    let bytes = context.encode(&contract(&source)).unwrap();
    let mut wire: Wire = serde_json::from_slice(&bytes).unwrap();
    let condition = wire.pre;
    let result_test = wire.post;
    let root = wire.nodes.len();
    wire.nodes.push(NodeData { typ: context.slot(&bool_typ()).unwrap(), data: Data::If(condition, condition, result_test) });
    wire.pre = root;
    assert_eq!(context.decode(&serde_json::to_vec(&wire).unwrap()).err(), Some("result in precondition"));
}

#[test]
fn probe_nonstatic_observation_is_currently_accepted_as_static() {
    let (source, datatypes) = fixture();
    let original = observation_definition();
    let mut definition = original.x.clone();
    definition.kind = FunctionKind::TraitMethodDecl { trait_path: original.x.name.path.clone(), has_default: true };
    let observations = vec![original.new_x(definition)];
    let context = Context::new(&source, &datatypes, &observations, &[], &policy()).unwrap();
    roundtrip(&context, equality(static_call(&observations[0]), input("x")));
    println!("REVIEW FINDING: nonstatic TraitMethodDecl observation accepted and reconstructed as Static call");
}

#[test]
fn probe_resolved_recursive_from_source_is_currently_accepted() {
    let (source, datatypes) = fixture();
    let path_for = |segments: &[&str]| Arc::new(PathX { krate: CrateId::Core, segments: Arc::new(segments.iter().map(|segment| Arc::new((*segment).into())).collect()) });
    let method = Arc::new(FunX { path: path_for(&["convert", "From", "from"]) });
    let mut definition = source.x.clone();
    definition.params = Arc::new(vec![definition.params[0].clone()]);
    definition.kind = FunctionKind::TraitMethodImpl {
        method: method.clone(), impl_path: source.x.name.path.clone(), trait_path: path_for(&["convert", "From"]),
        trait_typ_args: Arc::new(vec![source.x.inner_ret.x.typ.clone(), input("x").typ.clone()]), inherit_body_from: None,
    };
    definition.body = Some(SpannedTyped::new(&span(), &source.x.inner_ret.x.typ, ExprX::Call {
        target: CallTarget::Fun(CallTargetKind::DynamicResolved {
            resolved: source.x.name.clone(), typs: Arc::new(vec![]), impl_paths: Arc::new(vec![]), is_trait_default: false,
        }, method, Arc::new(vec![]), Arc::new(vec![]), CallTargetAttrs { autospec: AutospecUsage::Final, const_var: false, assume_external_allowed: false }),
        args: Arc::new(vec![input("x")]), post_args: None, body: None,
    }));
    let recursive = source.new_x(definition);
    assert!(wrapper_traits::kind(&recursive) == Some(wrapper_traits::Kind::From));
    assert!(Context::new(&recursive, &datatypes, &[], &[], &policy()).is_ok());
    println!("REVIEW FINDING: eligible From source self-recursion through DynamicResolved accepted");
}
