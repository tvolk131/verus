import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tarfile
import time

ROOT = Path('/private/tmp/verus-codec107-review-20261107-t9U1yK')
CANDIDATE = Path('/private/tmp/verus-owned-codec107-20261107-kcJbs7')
PARENT = Path('/Users/tommyvolk/.t3/worktrees/verus/t3-60978068')
ARCHIVE = PARENT / 'evidence/owned-candidate-codec107/CANDIDATE-HANDOFF.tar.gz'

def identity(filename):
    content = filename.read_bytes()
    return {'path': str(filename), 'bytes': len(content), 'sha256': hashlib.sha256(content).hexdigest()}

def authenticate(stage):
    checked = {}
    for name in ['INPUT_MANIFEST.json', 'TESTED_MANIFEST.json', 'OUTPUT_MANIFEST.json']:
        records = json.loads((CANDIDATE / name).read_text())
        if isinstance(records, dict):
            records = records['artifacts']
        for record in records:
            assert identity(Path(record['path'])) == record, record['path']
        checked[name] = len(records)
    expected = {
        'OUTPUT_MANIFEST.json': '40c5c029b16088004c519d84c97fe9fcdc979560d7d6fcdee9b397a5ba3348a2',
        'candidate.patch': '9fec2bce61c0bbe6d7e7f51ac3d13ac94c25e96ab49860cf98a79bc92490a4ab',
        'REPORT.md': '040de0a0ba809f185ae54d6f76ddaf08eb3ff492dd4ea323d11ad660bd6426a5',
    }
    for name, digest in expected.items():
        assert identity(CANDIDATE / name)['sha256'] == digest, name
    assert identity(ARCHIVE)['sha256'] == '1c3593aa605890b3240965a9e8e567fb258d74c187471d406c88632896834eac'
    with tarfile.open(ARCHIVE, 'r:gz') as archive:
        members = archive.getmembers()
        assert len(members) == 25
        for member in members:
            assert member.isfile() and not Path(member.name).is_absolute()
            assert '..' not in Path(member.name).parts
            assert archive.extractfile(member).read() == (CANDIDATE / member.name).read_bytes(), member.name
    checked['archive_byte_exact_members'] = len(members)
    checked['utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    (ROOT / f'{stage}-authentication.json').write_text(json.dumps(checked, indent=2) + '\n')
    print(json.dumps(checked))

def prepare():
    authenticate('entry')
    (ROOT / 'source').mkdir()
    (ROOT / 'logs').mkdir()
    (ROOT / 'tmp').mkdir()
    for crate in ['air', 'vir', 'vir_macros']:
        shutil.copytree(PARENT / 'source' / crate, ROOT / 'source' / crate)
    for name in ['Cargo.toml', 'Cargo.lock']:
        shutil.copyfile(CANDIDATE / 'source' / name, ROOT / 'source' / name)
    for name in ['vir/src/infer/owned.rs', 'vir/src/infer/owned/candidate_data.rs']:
        shutil.copyfile(CANDIDATE / 'source' / name, ROOT / 'source' / name)
    tested = json.loads((CANDIDATE / 'TESTED_MANIFEST.json').read_text())
    comparisons = []
    for record in tested:
        filename = Path(record['path'])
        if filename.is_relative_to(CANDIDATE / 'source'):
            copied = ROOT / 'source' / filename.relative_to(CANDIDATE / 'source')
            actual = identity(copied)
            assert actual['bytes'] == record['bytes'] and actual['sha256'] == record['sha256']
            comparisons.append(actual)
    (ROOT / 'source-copy-manifest.json').write_text(json.dumps(comparisons, indent=2) + '\n')
    def packages(filename):
        return [dict(re.findall(r'^(name|version|source|checksum) = "([^"]*)"$', section, re.MULTILINE)) for section in filename.read_text().split('[[package]]')[1:]]
    original = packages(PARENT / 'source/Cargo.lock')
    resolved = packages(CANDIDATE / 'source/Cargo.lock')
    key = lambda package: (package['name'], package['version'], package.get('source', ''), package.get('checksum', ''))
    originals = {key(package) for package in original}
    resolutions = {key(package) for package in resolved}
    locks = {'original_identity': identity(PARENT / 'source/Cargo.lock'), 'resolved_identity': identity(CANDIDATE / 'source/Cargo.lock'), 'original_packages': len(original), 'resolved_packages': len(resolved), 'removed': sorted(originals - resolutions), 'added': sorted(resolutions - originals)}
    (ROOT / 'lock-comparison.json').write_text(json.dumps(locks, indent=2) + '\n')
    print('Authenticated copied source files:', len(comparisons))
    print('Lock packages original/resolved:', len(original), len(resolved), 'removed/added:', len(originals - resolutions), len(resolutions - originals))

def build():
    assert not (ROOT / 'logs/cargo-launch.json').exists(), 'One build only'
    environment = {'HOME': '/Users/tommyvolk', 'PATH': '/Users/tommyvolk/.cargo/bin:/usr/bin:/bin:/usr/sbin:/sbin', 'CARGO_HOME': '/Users/tommyvolk/.cargo', 'RUSTUP_HOME': '/Users/tommyvolk/.rustup', 'RUSTUP_TOOLCHAIN': '1.99.1', 'CARGO_NET_OFFLINE': 'true', 'CARGO_BUILD_JOBS': '2', 'CARGO_INCREMENTAL': '0', 'CARGO_PROFILE_DEV_DEBUG': '0', 'CARGO_PROFILE_TEST_DEBUG': '0', 'CARGO_TARGET_DIR': str(ROOT / 'target'), 'TMPDIR': str(ROOT / 'tmp') + '/', 'RUSTFLAGS': '', 'RUST_MIN_STACK': '20971520'}
    arguments = ['/Users/tommyvolk/.cargo/bin/cargo', 'test', '--offline', '--locked', '--manifest-path', str(ROOT / 'source/Cargo.toml'), '-p', 'vir', '--lib', 'infer::owned::candidate_data::tests', '--jobs', '2', '--', '--test-threads=1', '--nocapture']
    source_records = [identity(filename) for filename in sorted((ROOT / 'source').rglob('*')) if filename.is_file()]
    (ROOT / 'review-tested-source-manifest.json').write_text(json.dumps(source_records, indent=2) + '\n')
    start = time.monotonic()
    launch = {'argv': arguments, 'env': environment, 'cwd': str(ROOT / 'source'), 'utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
    (ROOT / 'logs/cargo-launch.json').write_text(json.dumps(launch, indent=2) + '\n')
    samples = []
    stop_reason = None
    with (ROOT / 'logs/cargo.stdout').open('wb') as stdout, (ROOT / 'logs/cargo.stderr').open('wb') as stderr:
        child = subprocess.Popen(arguments, cwd=ROOT / 'source', env=environment, stdout=stdout, stderr=stderr, start_new_session=True)
        while child.poll() is None:
            scratch_kib = int(subprocess.check_output(['/usr/bin/du', '-sk', str(ROOT)]).split()[0])
            free_bytes = shutil.disk_usage('/private/tmp').free
            elapsed = time.monotonic() - start
            samples.append({'elapsed_seconds': elapsed, 'scratch_kib': scratch_kib, 'global_free_bytes': free_bytes})
            if scratch_kib > 3 * 1024 * 1024 or free_bytes <= 16 * 1024 ** 3 or elapsed > 360:
                stop_reason = 'resource or six-minute build budget'
                os.killpg(child.pid, 15)
                try:
                    child.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    os.killpg(child.pid, 9)
                break
            time.sleep(1)
        result = child.wait()
    outcome = {'cargo_child_exit': result, 'stop_reason': stop_reason, 'elapsed_seconds': time.monotonic() - start, 'samples': samples, 'final_scratch_kib': int(subprocess.check_output(['/usr/bin/du', '-sk', str(ROOT)]).split()[0]), 'final_global_free_bytes': shutil.disk_usage('/private/tmp').free, 'utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
    (ROOT / 'logs/cargo-result.json').write_text(json.dumps(outcome, indent=2) + '\n')
    (ROOT / 'logs/cargo.exit-code').write_text(str(result) + '\n')
    print(json.dumps({key: value for key, value in outcome.items() if key != 'samples'}))
    sys.exit(result if result >= 0 else 1)

if __name__ == '__main__':
    if sys.argv[1] == 'prepare':
        prepare()
    elif sys.argv[1] == 'build':
        build()
    else:
        authenticate(sys.argv[1])
