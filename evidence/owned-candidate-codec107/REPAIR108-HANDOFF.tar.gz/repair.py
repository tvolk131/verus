import datetime
import difflib
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile
import time


ROOT = Path(__file__).resolve().parent
CANDIDATE = Path('/private/tmp/verus-owned-codec107-20261107-kcJbs7')
REVIEW = Path('/private/tmp/verus-codec107-review-20261107-t9U1yK')
PARENT = Path('/Users/tommyvolk/.t3/worktrees/verus/t3-60978068')
TOOLCHAIN = Path('/Users/tommyvolk/.rustup/toolchains/1.99.1-aarch64-apple-darwin/bin')


def identity(filename):
    content = filename.read_bytes()
    return {'path': str(filename), 'bytes': len(content), 'sha256': hashlib.sha256(content).hexdigest()}


def write_json(filename, value):
    filename.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def authenticate(stage):
    counts = {}
    for name in ['INPUT_MANIFEST.json', 'TESTED_MANIFEST.json', 'OUTPUT_MANIFEST.json']:
        records = json.loads((CANDIDATE / name).read_text())
        if isinstance(records, dict):
            records = records['artifacts']
        for record in records:
            assert identity(Path(record['path'])) == record, record['path']
        counts[name] = len(records)
    records = json.loads((REVIEW / 'REVIEW_OUTPUT_MANIFEST.json').read_text())['artifacts']
    for record in records:
        assert identity(Path(record['path'])) == record, record['path']
    assert identity(REVIEW / 'REVIEW-HANDOFF.tar.gz')['sha256'] == '8910f176847c87ed3f69dc6729a0c60bc815f754bbfaa7e7915e8609dc94e27c'
    with tarfile.open(REVIEW / 'REVIEW-HANDOFF.tar.gz', 'r:gz') as archive:
        for member in archive.getmembers():
            assert member.isfile() and not Path(member.name).is_absolute()
            assert '..' not in Path(member.name).parts
            assert archive.extractfile(member).read() == (REVIEW / member.name).read_bytes()
    counts['review_payloads'] = len(records)
    counts['utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    write_json(ROOT / f'{stage}-authentication.json', counts)
    print(json.dumps(counts))


def prepare():
    authenticate('entry')
    for directory in ['source', 'logs', 'tmp']:
        (ROOT / directory).mkdir()
    for crate in ['air', 'vir', 'vir_macros']:
        shutil.copytree(CANDIDATE / 'source' / crate, ROOT / 'source' / crate)
    for name in ['Cargo.toml', 'Cargo.lock']:
        shutil.copyfile(CANDIDATE / 'source' / name, ROOT / 'source' / name)
    shutil.copyfile(REVIEW / 'reviewer_tests.rs', ROOT / 'reviewer_tests.rs')
    records = json.loads((CANDIDATE / 'TESTED_MANIFEST.json').read_text())
    copied = []
    for record in records:
        filename = Path(record['path'])
        if filename.is_relative_to(CANDIDATE / 'source'):
            actual = identity(ROOT / 'source' / filename.relative_to(CANDIDATE / 'source'))
            assert actual['sha256'] == record['sha256'] and actual['bytes'] == record['bytes']
            copied.append(actual)
    write_json(ROOT / 'BASELINE-SOURCE.json', copied)
    print('Copied byte-exact source records:', len(copied))


def run(stage):
    assert stage in ['red', 'green', 'broad', 'final']
    assert not (ROOT / f'logs/{stage}-launch.json').exists()
    authenticate(f'{stage}-pre')
    assert shutil.disk_usage(ROOT).free > 16 * 1024**3
    source = [identity(filename) for filename in sorted((ROOT / 'source').rglob('*')) if filename.is_file()]
    source.append(identity(ROOT / 'reviewer_tests.rs'))
    write_json(ROOT / f'{stage}-tested-source.json', source)
    tools = [identity(TOOLCHAIN / name) for name in ['cargo', 'rustc', 'rustdoc']]
    write_json(ROOT / f'{stage}-tools.json', tools)
    environment = {
        'HOME': '/Users/tommyvolk', 'PATH': str(TOOLCHAIN) + ':/usr/bin:/bin:/usr/sbin:/sbin',
        'CARGO_HOME': '/Users/tommyvolk/.cargo', 'CARGO_NET_OFFLINE': 'true',
        'CARGO_BUILD_JOBS': '2', 'CARGO_INCREMENTAL': '0', 'CARGO_PROFILE_DEV_DEBUG': '0',
        'CARGO_PROFILE_TEST_DEBUG': '0', 'CARGO_TARGET_DIR': str(ROOT / 'target'),
        'TMPDIR': str(ROOT / 'tmp') + '/', 'RUSTFLAGS': '', 'RUST_MIN_STACK': '20971520',
        'RUSTC': str(TOOLCHAIN / 'rustc'), 'RUSTDOC': str(TOOLCHAIN / 'rustdoc'),
        'LANG': 'C', 'LC_ALL': 'C', 'TZ': 'UTC',
    }
    if stage == 'final':
        binaries = [filename for filename in (ROOT / 'target/debug/deps').glob('vir-*') if filename.is_file() and os.access(filename, os.X_OK)]
        assert len(binaries) == 1
        tools.append(identity(binaries[0]))
        write_json(ROOT / f'{stage}-tools.json', tools)
        arguments = [str(binaries[0]), 'infer::', '--test-threads=1', '--nocapture']
    else:
        arguments = [str(TOOLCHAIN / 'cargo'), 'test', '--offline', '--locked', '--manifest-path', str(ROOT / 'source/Cargo.toml'), '-p', 'vir', '--lib']
        if stage != 'broad':
            arguments.append('infer::owned::candidate_data::tests')
        arguments += ['--jobs', '2', '--', '--test-threads=1', '--nocapture']
    write_json(ROOT / f'logs/{stage}-launch.json', {'argv': arguments, 'environment': environment, 'cwd': str(ROOT / 'source'), 'utc': datetime.datetime.now(datetime.timezone.utc).isoformat()})
    started = time.monotonic()
    with (ROOT / f'logs/{stage}.stdout').open('wb') as stdout, (ROOT / f'logs/{stage}.stderr').open('wb') as stderr:
        child = subprocess.Popen(arguments, cwd=ROOT / 'source', env=environment, stdout=stdout, stderr=stderr, start_new_session=True)
        try:
            status = child.wait(timeout=240)
        except BaseException:
            os.killpg(child.pid, 9)
            child.wait()
            raise
    for record in source + tools:
        assert identity(Path(record['path'])) == record, record['path']
    result = {'cargo_child_exit': status if stage != 'final' else None, 'test_child_exit': status if stage == 'final' else None, 'elapsed_seconds': time.monotonic() - started, 'scratch_kib': int(subprocess.check_output(['/usr/bin/du', '-sk', str(ROOT)]).split()[0]), 'free_bytes': shutil.disk_usage(ROOT).free, 'source_reauthenticated': len(source), 'tools_reauthenticated': len(tools)}
    write_json(ROOT / f'logs/{stage}-result.json', result)
    print(json.dumps(result))
    print((ROOT / f'logs/{stage}.stdout').read_text()[-6000:])
    print((ROOT / f'logs/{stage}.stderr').read_text()[-2000:])
    assert result['free_bytes'] > 16 * 1024**3 and result['scratch_kib'] < 1024**2
    return status


def seal():
    authenticate('exit')
    stages = {stage: json.loads((ROOT / f'logs/{stage}-result.json').read_text()) for stage in ['red', 'green', 'broad', 'final']}
    assert [stages[stage]['cargo_child_exit'] for stage in ['red', 'green', 'broad']] == [101, 0, 128]
    assert stages['final']['test_child_exit'] == 0
    assert '13 passed; 5 failed;' in (ROOT / 'logs/red.stdout').read_text()
    assert '18 passed; 0 failed;' in (ROOT / 'logs/green.stdout').read_text()
    assert '174 passed; 0 failed;' in (ROOT / 'logs/final.stdout').read_text()
    assert (ROOT / 'source/Cargo.lock').read_bytes() == (CANDIDATE / 'source/Cargo.lock').read_bytes()
    names = ['source/vir/src/infer/owned.rs', 'source/vir/src/infer/owned/candidate_data.rs', 'source/vir/src/infer/owned/candidate_data_regressions.rs']
    patches = []
    repair = []
    for name in names:
        final = (ROOT / name).read_text().splitlines(keepends=True)
        baseline_file = PARENT / name
        original_file = CANDIDATE / name
        baseline = baseline_file.read_text().splitlines(keepends=True) if baseline_file.exists() else []
        original = original_file.read_text().splitlines(keepends=True) if original_file.exists() else []
        patches.extend(difflib.unified_diff(baseline, final, fromfile='a/' + name if baseline_file.exists() else '/dev/null', tofile='b/' + name))
        repair.extend(difflib.unified_diff(original, final, fromfile='a/' + name if original_file.exists() else '/dev/null', tofile='b/' + name))
    (ROOT / 'candidate.patch').write_text(''.join(patches))
    (ROOT / 'repair-only.patch').write_text(''.join(repair))
    result = {
        'schema': 'owned-codec108-parent-repair-v1', 'status': 'PARENT_SCRATCH_REPAIR_VALIDATED_NOT_INTEGRATED',
        'original_independent_review_verdict': 'REQUEST_CHANGES', 'independent_repair_review': False,
        'findings': ['R1_STATIC_OBSERVATION_DEFINITION', 'R2_RESOLVED_SELF_TARGET', 'R3_MEMOIZED_TYPE_HEIGHT'],
        'red_regression_failures': 5, 'green_focused_passes': 18, 'final_codec_passes': 19,
        'final_inference_tests_passed': 174, 'final_inference_tests_filtered_out': 37,
        'full_vir_suite': 'NOT_COMPLETED_MISSING_Z3_EXIT128', 'cargo_invocations': 3, 'direct_unit_executions': 1,
        'runs': stages, 'source': [identity(ROOT / name) for name in names],
        'candidate_patch': identity(ROOT / 'candidate.patch'), 'repair_delta': identity(ROOT / 'repair-only.patch'),
        'parent_source_integration': False, 'persistence_wiring': False, 'trust_adoption': False,
        'compiler_builds': 0, 'vstd_builds': 0, 'solver_proof_credit': 0, 'redb_open_cells': 18,
        'warm_cache_gate': 'UNMET', 'three_fresh_certificates_required': True,
        'native_storage_refinement108_authorized': False, 'diagnostic107_D1_authorized': False,
    }
    write_json(ROOT / 'RESULTS.json', result)
    payloads = [ROOT / name for name in names] + [ROOT / name for name in ['repair.py', 'reviewer_tests.rs', 'REPORT.md', 'RESULTS.json', 'candidate.patch', 'repair-only.patch', 'BASELINE-SOURCE.json']]
    payloads += sorted(ROOT.glob('*-authentication.json')) + sorted(ROOT.glob('*-tested-source.json')) + sorted(ROOT.glob('*-tools.json'))
    payloads += [filename for filename in sorted((ROOT / 'logs').iterdir()) if filename.is_file()]
    assert len(set(payloads)) == len(payloads)
    write_json(ROOT / 'OUTPUT_MANIFEST.json', {'excludes_self_and_archive': True, 'artifacts': [identity(filename) for filename in payloads]})
    with tarfile.open(ROOT / 'REPAIR-HANDOFF.tar.gz', 'w:gz') as archive:
        for filename in payloads + [ROOT / 'OUTPUT_MANIFEST.json']:
            archive.add(filename, arcname=str(filename.relative_to(ROOT)), recursive=False)
    with tarfile.open(ROOT / 'REPAIR-HANDOFF.tar.gz', 'r:gz') as archive:
        for member in archive.getmembers():
            assert archive.extractfile(member).read() == (ROOT / member.name).read_bytes()
    destination = PARENT / 'evidence/owned-candidate-codec107'
    for source, name in [
        (REVIEW / 'REVIEW.md', 'INDEPENDENT-REVIEW.md'),
        (REVIEW / 'REVIEW-HANDOFF.tar.gz', 'INDEPENDENT-REVIEW-HANDOFF.tar.gz'),
        (ROOT / 'REPORT.md', 'REPAIR108-REPORT.md'), (ROOT / 'RESULTS.json', 'REPAIR108-RESULTS.json'),
        (ROOT / 'candidate.patch', 'REPAIR108-CANDIDATE.patch'), (ROOT / 'repair-only.patch', 'REPAIR108-DELTA.patch'),
        (ROOT / 'REPAIR-HANDOFF.tar.gz', 'REPAIR108-HANDOFF.tar.gz'),
    ]:
        assert not (destination / name).exists(), name
        shutil.copyfile(source, destination / name)
        assert source.read_bytes() == (destination / name).read_bytes()
    review_members = len(tarfile.open(REVIEW / 'REVIEW-HANDOFF.tar.gz', 'r:gz').getmembers())
    retention = {
        'original_review_verdict': 'REQUEST_CHANGES', 'review_report': identity(REVIEW / 'REVIEW.md'),
        'review_archive': identity(REVIEW / 'REVIEW-HANDOFF.tar.gz'), 'review_archive_members_byte_compared': review_members,
        'repair_archive': identity(ROOT / 'REPAIR-HANDOFF.tar.gz'), 'repair_payloads': len(payloads),
        'repair_archive_members_byte_compared': len(payloads) + 1, 'repair_source_integration': False,
        'original_reviewer_test_result': {'cargo_exit': 101, 'passed': 13, 'failed': 2},
        'review_findings_parent_repaired': True, 'repair_independently_reviewed': False,
        'warm_cache_gate': 'UNMET', 'redb_open_cells': 18,
    }
    write_json(destination / 'REVIEW-RESULTS.json', retention)
    print(json.dumps(retention, indent=2))


if __name__ == '__main__':
    if sys.argv[1] == 'prepare':
        prepare()
    elif sys.argv[1] in ['red', 'green', 'broad', 'final']:
        sys.exit(run(sys.argv[1]))
    elif sys.argv[1] == 'seal':
        seal()
    else:
        authenticate(sys.argv[1])
