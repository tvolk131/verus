use super::*;

fn equality(left: Expr, right: Expr) -> Expr {
    SpannedTyped::new(
        &span(),
        &bool_typ(),
        ExprX::Binary(BinaryOp::Eq(Mode::Spec), left, right),
    )
}

fn roundtrip(context: &Context<'_>, expression: Expr) {
    let proposed = Contract::new(expression, contract(context.function).post).unwrap();
    let bytes = context.encode(&proposed).unwrap();
    let decoded = context.decode(&bytes).unwrap();
    assert_eq!(format!("{:?}", proposed.pre), format!("{:?}", decoded.pre));
    assert_eq!(
        format!("{:?}", proposed.post),
        format!("{:?}", decoded.post)
    );
    assert_eq!(bytes, context.encode(&decoded).unwrap());
}

fn projection(context: &Context<'_>, value: Expr, variant: &str, field_index: usize) -> Expr {
    let layout = context.variant(&value.typ, variant).unwrap();
    let (name, field_type) = &layout[field_index];
    let TypX::Datatype(datatype, ..) = &*value.typ else {
        panic!("datatype")
    };
    SpannedTyped::new(
        &span(),
        field_type,
        ExprX::UnaryOpr(
            UnaryOpr::Field(FieldOpr {
                datatype: datatype.clone(),
                variant: Arc::new(variant.into()),
                field: name.clone(),
                get_variant: false,
                check: VariantCheck::None,
            }),
            value,
        ),
    )
}

fn observation_definition() -> Function {
    observation_from_body("review_observation", input("x"))
}

fn observation_from_body(name: &str, body: Expr) -> Function {
    let return_type = body.typ.clone();
    let base = function(name, body);
    let mut definition = base.x.clone();
    definition.mode = Mode::Spec;
    definition.params = Arc::new(
        definition
            .params
            .iter()
            .map(|parameter| {
                parameter.new_x(ParamX {
                    mode: Mode::Spec,
                    ..parameter.x.clone()
                })
            })
            .collect(),
    );
    definition.inner_ret = definition.inner_ret.new_x(ParamX {
        mode: Mode::Spec,
        typ: return_type,
        ..definition.inner_ret.x.clone()
    });
    definition.outer_ret = definition.inner_ret.clone();
    Arc::make_mut(&mut definition.attrs).infer = false;
    base.new_x(definition)
}

fn value_enum_fixture() -> (Function, Vec<Datatype>) {
    let (source, datatypes) = fixture();
    let mut declaration = datatypes[0].x.clone();
    declaration.variants = Arc::new(vec![
        Variant {
            name: Arc::new("Value".into()),
            fields: Arc::new(vec![crate::ast_util::ident_binder(
                &crate::def::positional_field_ident(0),
                &(
                    input("x").typ.clone(),
                    Mode::Exec,
                    declaration.visibility.clone(),
                ),
            )]),
            ctor_style: CtorPrintStyle::Parens,
        },
        Variant {
            name: Arc::new("Empty".into()),
            fields: Arc::new(vec![]),
            ctor_style: CtorPrintStyle::Braces,
        },
    ]);
    let mut definition = source.x.clone();
    definition.body = Some(constructor(
        &definition.inner_ret.x.typ,
        "Value",
        vec![("0", input("x"))],
    ));
    (
        source.new_x(definition),
        vec![datatypes[0].new_x(declaration)],
    )
}

fn static_call(observation: &Function) -> Expr {
    SpannedTyped::new(
        &span(),
        &observation.x.inner_ret.x.typ,
        ExprX::Call {
            target: CallTarget::Fun(
                CallTargetKind::Static,
                observation.x.name.clone(),
                Arc::new(vec![]),
                Arc::new(vec![]),
                CallTargetAttrs {
                    autospec: AutospecUsage::Final,
                    const_var: false,
                    assume_external_allowed: false,
                },
            ),
            args: Arc::new(vec![input("x"), input("y")]),
            post_args: None,
            body: None,
        },
    )
}

#[test]
fn positive_option_variant_projection_and_conditionals() {
    let (source, datatypes) = fixture();
    let context = Context::new(&source, &datatypes, &[], &[], &policy()).unwrap();
    let option_type = context
        .types
        .iter()
        .find(|typ| option(typ).is_some())
        .unwrap();
    let some = constructor(option_type, "Some", vec![("0", input("x"))]);
    let none = constructor(option_type, "None", vec![]);
    roundtrip(&context, equality(some.clone(), some.clone()));
    roundtrip(&context, equality(none.clone(), none.clone()));
    let TypX::Datatype(datatype, ..) = &**option_type else {
        panic!("option")
    };
    let variant = SpannedTyped::new(
        &span(),
        &bool_typ(),
        ExprX::UnaryOpr(
            UnaryOpr::IsVariant {
                datatype: datatype.clone(),
                variant: Arc::new("Some".into()),
            },
            some.clone(),
        ),
    );
    roundtrip(&context, variant.clone());
    let payload = projection(&context, some.clone(), "Some", 0);
    roundtrip(&context, equality(payload, input("x")));
    let conditional = SpannedTyped::new(&span(), option_type, ExprX::If(variant, some, Some(none)));
    roundtrip(&context, equality(conditional.clone(), conditional));
    let record = source.x.body.clone().unwrap();
    let outer_error = projection(&context, record, "Envelope", 0);
    let inner_error = projection(&context, outer_error, "Err", 0);
    let tuple = projection(&context, inner_error, "Err", 0);
    let tuple_variant = context.shape(&tuple.typ).unwrap()[0].0.clone();
    let second = projection(&context, tuple, &tuple_variant, 1);
    roundtrip(&context, equality(second, input("y")));
}

#[test]
fn positive_arithmetic_bitwise_unary_and_logical() {
    let (source, datatypes) = fixture();
    let context = Context::new(&source, &datatypes, &[], &[], &policy()).unwrap();
    let operand = || Term {
        view: None,
        expr: input("x"),
        size: 1,
    };
    let arithmetic = summary::binary(
        &span(),
        BinaryOp::Arith(ArithOp::Add(OverflowBehavior::Allow)),
        operand(),
        operand(),
    )
    .unwrap()
    .expr;
    roundtrip(&context, equality(arithmetic.clone(), arithmetic));
    let bitwise = summary::binary(
        &span(),
        BinaryOp::Bitwise(BitwiseOp::BitXor, BitshiftBehavior::Allow),
        operand(),
        operand(),
    )
    .unwrap()
    .expr;
    roundtrip(&context, equality(bitwise.clone(), bitwise));
    let inverted = summary::unary(
        &span(),
        UnaryOp::BitNot(Some(IntegerTypeBitwidth::Width(8))),
        operand(),
    )
    .unwrap()
    .expr;
    roundtrip(&context, equality(inverted.clone(), inverted));
    let clipped = summary::unary(
        &span(),
        UnaryOp::Clip {
            range: IntRange::Int,
            truncate: false,
        },
        operand(),
    )
    .unwrap()
    .expr;
    roundtrip(&context, equality(clipped.clone(), clipped));
    let logical = SpannedTyped::new(
        &span(),
        &bool_typ(),
        ExprX::Logical(
            LogicalOp::And,
            boolean(&span(), true).expr,
            boolean(&span(), false).expr,
        ),
    );
    roundtrip(
        &context,
        SpannedTyped::new(&span(), &bool_typ(), ExprX::Unary(UnaryOp::Not, logical)),
    );
}

#[test]
fn positive_value_enum_construction_and_variant() {
    let (source, datatypes) = value_enum_fixture();
    let context = Context::new(&source, &datatypes, &[], &[], &policy()).unwrap();
    let empty = constructor(&source.x.inner_ret.x.typ, "Empty", vec![]);
    roundtrip(&context, equality(empty.clone(), empty.clone()));
    let TypX::Datatype(datatype, ..) = &*empty.typ else {
        panic!("enum")
    };
    roundtrip(
        &context,
        SpannedTyped::new(
            &span(),
            &bool_typ(),
            ExprX::UnaryOpr(
                UnaryOpr::IsVariant {
                    datatype: datatype.clone(),
                    variant: Arc::new("Empty".into()),
                },
                empty,
            ),
        ),
    );
}

#[test]
fn integer_boundaries_and_result_taint_under_conditionals() {
    let (source, datatypes) = fixture();
    let mut context = Context::new(&source, &datatypes, &[], &[], &policy()).unwrap();
    let signed = Arc::new(TypX::Int(IntRange::I(8)));
    context.add_type(&signed, &mut vec![]).unwrap();
    for decimal in ["-128", "127"] {
        let value = SpannedTyped::new(
            &span(),
            &signed,
            ExprX::Const(Constant::Int(decimal.parse().unwrap())),
        );
        roundtrip(&context, equality(value.clone(), value));
    }
    for decimal in ["-129", "128"] {
        let value = SpannedTyped::new(
            &span(),
            &signed,
            ExprX::Const(Constant::Int(decimal.parse().unwrap())),
        );
        assert!(context
            .encode(&Contract::new(equality(value.clone(), value), contract(&source).post).unwrap())
            .is_err());
    }
    let bytes = context.encode(&contract(&source)).unwrap();
    let mut wire: Wire = serde_json::from_slice(&bytes).unwrap();
    let condition = wire.pre;
    let result_test = wire.post;
    let root = wire.nodes.len();
    wire.nodes.push(NodeData {
        typ: context.slot(&bool_typ()).unwrap(),
        data: Data::If(condition, condition, result_test),
    });
    wire.pre = root;
    assert_eq!(
        context.decode(&serde_json::to_vec(&wire).unwrap()).err(),
        Some("result in precondition")
    );
}

#[test]
fn nonstatic_observation_is_rejected_before_static_reconstruction() {
    let (source, datatypes) = fixture();
    let original = observation_definition();
    let mut definition = original.x.clone();
    definition.kind = FunctionKind::TraitMethodDecl {
        trait_path: original.x.name.path.clone(),
        has_default: true,
    };
    let observations = vec![original.new_x(definition)];
    assert_eq!(
        Context::new(&source, &datatypes, &observations, &[], &policy()).err(),
        Some("unapproved observation")
    );
}

#[test]
fn resolved_self_recursion_is_rejected_after_source_signature_acceptance() {
    let (source, datatypes) = value_enum_fixture();
    let path_for = |segments: &[&str]| {
        Arc::new(PathX {
            krate: CrateId::Core,
            segments: Arc::new(
                segments
                    .iter()
                    .map(|segment| Arc::new((*segment).into()))
                    .collect(),
            ),
        })
    };
    let method = Arc::new(FunX {
        path: path_for(&["convert", "From", "from"]),
    });
    let mut definition = source.x.clone();
    definition.params = Arc::new(vec![definition.params[0].clone()]);
    definition.kind = FunctionKind::TraitMethodImpl {
        method: method.clone(),
        impl_path: source.x.name.path.clone(),
        trait_path: path_for(&["convert", "From"]),
        trait_typ_args: Arc::new(vec![
            source.x.inner_ret.x.typ.clone(),
            input("x").typ.clone(),
        ]),
        inherit_body_from: None,
    };
    let nonrecursive = source.new_x(definition.clone());
    assert!(wrapper_traits::kind(&nonrecursive) == Some(wrapper_traits::Kind::From));
    assert!(Context::new(&nonrecursive, &datatypes, &[], &[], &policy()).is_ok());
    definition.body = Some(SpannedTyped::new(
        &span(),
        &source.x.inner_ret.x.typ,
        ExprX::Call {
            target: CallTarget::Fun(
                CallTargetKind::DynamicResolved {
                    resolved: source.x.name.clone(),
                    typs: Arc::new(vec![]),
                    impl_paths: Arc::new(vec![]),
                    is_trait_default: false,
                },
                method,
                Arc::new(vec![]),
                Arc::new(vec![]),
                CallTargetAttrs {
                    autospec: AutospecUsage::Final,
                    const_var: false,
                    assume_external_allowed: false,
                },
            ),
            args: Arc::new(vec![input("x")]),
            post_args: None,
            body: None,
        },
    ));
    let recursive = source.new_x(definition);
    assert!(wrapper_traits::kind(&recursive) == Some(wrapper_traits::Kind::From));
    assert!(validate_signature(&recursive, &HashMap::new(), &datatypes).is_ok());
    assert_eq!(
        Context::new(&recursive, &datatypes, &[], &[], &policy()).err(),
        Some("unsupported current body")
    );
}

#[test]
fn observations_require_ordinary_items_and_specification_returns() {
    let (source, datatypes) = fixture();
    let original = observation_definition();
    let observations = vec![original.clone()];
    let context = Context::new(&source, &datatypes, &observations, &[], &policy()).unwrap();
    roundtrip(&context, equality(static_call(&original), input("x")));
    for variation in 0..5 {
        let mut definition = original.x.clone();
        match variation {
            0 => definition.item_kind = ItemKind::Const,
            1 => definition.item_kind = ItemKind::Static,
            2 => {
                definition.inner_ret = definition.inner_ret.new_x(ParamX {
                    mode: Mode::Exec,
                    ..definition.inner_ret.x.clone()
                })
            }
            3 => {
                definition.outer_ret = definition.outer_ret.new_x(ParamX {
                    mode: Mode::Exec,
                    ..definition.outer_ret.x.clone()
                })
            }
            _ => {
                definition.outer_ret = definition.outer_ret.new_x(ParamX {
                    typ: bool_typ(),
                    ..definition.outer_ret.x.clone()
                })
            }
        }
        assert_eq!(
            Context::new(
                &source,
                &datatypes,
                &[original.new_x(definition)],
                &[],
                &policy()
            )
            .err(),
            Some("unapproved observation"),
            "variation {variation}"
        );
    }
}

#[test]
fn memoized_types_obey_the_combined_structural_depth_bound() {
    let (source, datatypes) = fixture();
    let mut context = Context::new(&source, &datatypes, &[], &[], &policy()).unwrap();
    let mut nested = input("x").typ.clone();
    for _ in 0..11 {
        nested = named_type(CrateId::Core, &["option", "Option"], vec![nested]);
        assert!(context.add_type(&nested, &mut vec![]).is_ok());
    }
    assert!(context.add_type(&nested, &mut vec![]).is_ok());
    let too_deep = named_type(CrateId::Core, &["option", "Option"], vec![nested]);
    assert_eq!(
        context.add_type(&too_deep, &mut vec![]).err(),
        Some("recursive or deep type")
    );
}

#[test]
fn sequential_observation_signatures_cannot_hide_memoized_type_depth() {
    let (source, datatypes) = fixture();
    let mut body = input("x");
    let mut observations = vec![];
    for depth in 1..=12 {
        let nested = named_type(CrateId::Core, &["option", "Option"], vec![body.typ.clone()]);
        body = constructor(&nested, "Some", vec![("0", body)]);
        observations.push(observation_from_body(
            &format!("nested_observation_{depth}"),
            body.clone(),
        ));
    }
    assert!(Context::new(&source, &datatypes, &observations[..11], &[], &policy()).is_ok());
    assert_eq!(
        Context::new(&source, &datatypes, &observations, &[], &policy()).err(),
        Some("recursive or deep type")
    );
}

#[test]
fn source_calls_use_resolved_targets_and_refuse_unknown_dispatch() {
    let (source, datatypes) = value_enum_fixture();
    let other = function("other_enum_source", input("x")).x.name.clone();
    let cases = vec![
        (CallTargetKind::Static, source.x.name.clone(), false),
        (CallTargetKind::Static, other.clone(), true),
        (CallTargetKind::Dynamic, other.clone(), false),
        (CallTargetKind::ExternalTraitDefault, other.clone(), false),
        (
            CallTargetKind::ProofFn(Arc::new(vec![Mode::Proof]), Mode::Proof),
            other.clone(),
            false,
        ),
        (
            CallTargetKind::DynamicResolved {
                resolved: other,
                typs: Arc::new(vec![]),
                impl_paths: Arc::new(vec![]),
                is_trait_default: false,
            },
            source.x.name.clone(),
            true,
        ),
    ];
    for (kind, nominal, accepted) in cases {
        let mut definition = source.x.clone();
        definition.body = Some(SpannedTyped::new(
            &span(),
            &source.x.inner_ret.x.typ,
            ExprX::Call {
                target: CallTarget::Fun(
                    kind.clone(),
                    nominal,
                    Arc::new(vec![]),
                    Arc::new(vec![]),
                    CallTargetAttrs {
                        autospec: AutospecUsage::Final,
                        const_var: false,
                        assume_external_allowed: false,
                    },
                ),
                args: Arc::new(vec![input("x"), input("y")]),
                post_args: None,
                body: None,
            },
        ));
        assert_eq!(
            Context::new(&source.new_x(definition), &datatypes, &[], &[], &policy()).is_ok(),
            accepted,
            "{kind:?}"
        );
    }
}
