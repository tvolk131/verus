import difflib
import json
from pathlib import Path
import runner

root = runner.ROOT
checks = []

def check(name, passed, detail=None):
    checks.append(dict(name=name, passed=bool(passed), detail=detail))

def load(name):
    return json.loads((root / name).read_text())

def body(document, suffix):
    return next(value for name, value in document['bodies'].items() if name.endswith(suffix))

original = load('original-final.json')
control = original
restored = load('control-restored.json')
negative = load('negative-final.json')
for name, document in [('original', original), ('control', control), ('restored', restored), ('negative', negative)]:
    check(name + '_no_certificate', document['all18'] == 'OPEN' and document['native_bodies_proved'] == 0
        and document['laws_adopted'] == 0 and document['native_certificate'] is False)
check('restoration_is_byte_identical_original_source', runner.inventory(root / 'redb-source-control') == runner.inventory(runner.ORIGINAL))
check('entire_restored_result_byte_identical_including_open_obligations', (root / 'original-final.json').read_bytes() == (root / 'control-restored.json').read_bytes())
check('seven_selected_original_bodies', len(original['bodies']) == 7)
check('six_ordinary_bodies_translated_not_verified', sum('Ok' in value['ordinary_frontend'] for value in original['bodies'].values()) == 6)
header = body(original, '::write_header')
header_lowered = header['native_lowering']['Ok']
requirements = header_lowered['requirements']
check('actual_empty_cleanup_terminator_loan_ends', any('LoanEndWriteback' in item and 'bb24[0]' in item and 'cleanup: true' in item for item in requirements))
check('normal_copy_effect_distinguished', any('LoanEndWriteback' in item and 'NormalCopy' in item and 'cleanup: false' in item for item in requirements))
check('unwind_prefix_effect_distinguished', any('LoanEndWriteback' in item and 'UnwindPrefix' in item and 'cleanup: true' in item for item in requirements))
expected = ['NRE143_COPY_HAS_NO_EXACT_RETURNED_LOAN_ORIGIN', 'NRE143_DROP_WITH_OUTSTANDING_RETURNED_LOAN',
    'NRE143_COPY_EXACT_FULL_PROJECTED_RETURNED_PLACE', 'NRE143_WRITEBACK_HAS_NO_NATIVE_COPY_EVENT']
negatives = header['cfg_semantic_negatives']
check('all_four_typed_cfg_controls_reach_intended_new_checks', len(negatives) == 4 and all(code in result.get('Err', '') for code, result in zip(expected, negatives)), negatives)
negative_header = body(negative, '::write_header')
check('real_source_mutant_ordinary_frontend_succeeds', 'Ok' in negative_header['ordinary_frontend'])
check('real_source_mutant_reaches_returned_loan_check', negative_header['native_lowering'].get('Err') == expected[0])
mem = body(original, '::mem_mut')['native_lowering']['Ok']
check('original_arc_get_mut_and_unwrap_pending_outcomes', any(item.startswith('ArcGetMutOutcomes') for item in mem['requirements']) and any(item.startswith('UnwrapOutcomes') for item in mem['requirements']))
check('actual_returned_loan_original_arc_root_chain_checked', any(item.startswith('ReturnedLoanTransfer') and 'std::sync::Arc<[u8]>' in item for item in mem['requirements']))
write = body(original, '::write')
check('original_write_assert_semantics_refused', 'NRE143_ASSERT_SEMANTICS_OPEN' in write['native_lowering'].get('Err', ''))
check('original_macro_for_loop_frontend_refusal_preserved', 'for` loops produced by a macro expansion' in write['ordinary_frontend'].get('Err', ''))
returned = body(original, '::return_value')['native_lowering']['Ok']
taken = body(original, '::take_value')['native_lowering']['Ok']
check('return_value_terminator_endpoint_is_processed', any(item.startswith('LoanEndWriteback') and 'bb4[0]' in item for item in returned['requirements']))
cache = [item for value in [returned, taken] for item in value['requirements'] if item.startswith('CacheReservation')]
check('actual_take_and_replace_reservation_obligations_exist', len(cache) == 2 and any('replacing: true' in item for item in cache) and any('replacing: false' in item for item in cache), cache)
check('exit_frames_remain_explicitly_open', any(item.startswith('ExitFrame') for item in requirements))
proof_scopes = []
for value in original['bodies'].values():
    lowering = value['native_lowering'].get('Ok')
    if lowering is None:
        continue
    proof = lowering['original_body_proof_lowering'].get('Ok')
    if proof is not None:
        proof_scopes.append(dict(owner=value['owner'], assertions=proof['source_bound_open_assertions'],
            well_formed_scope=proof['well_formed_scope'], verifier_scope=proof['verifier_scope']))
        check('erasure_preserves_original_' + value['owner'], proof['proof_erasure_reproduces_entire_original_vir_body'] and proof['export'] == 'REFUSED')
check('baseline140_native_adapter_unchanged', runner.sha(root / 'candidate/source/vir/src/native_resource/native.rs') == '85ef1774e8d2790a91d08801479b736217b86d9179f5242ff9fab3f1d74ed7cd')
commands = load('commands.json')
for entry in commands:
    if entry['kind'] == 'setup' or entry['name'] == 'validate-final':
        continue
    receipt = load(entry['name'] + '.receipt.json')
    check('group_reaped_' + entry['name'], receipt['owned_group_absent'])
feature_off = load('feature-required-refusal.receipt.json')
check('binary_default_off_admission_refused', feature_off['returncode'] != 0 and 'requires the features' in (root / 'feature-required-refusal.stderr').read_text())
identities = [load(name + '.receipt.json')['executable_sha256'] for name in ['negative-final', 'control-restored', 'original-final']]
check('original_mutant_and_restoration_use_identical_executable', len(set(identities)) == 1)
original_file = runner.ORIGINAL / 'src/tree_store/page_store/page_manager.rs'
negative_file = root / 'negative-page_manager.rs'
(root / 'semantic-negative.patch').write_text(''.join(difflib.unified_diff(original_file.read_text().splitlines(keepends=True), negative_file.read_text().splitlines(keepends=True), fromfile='original/page_manager.rs', tofile='semantic-negative/page_manager.rs')))
result = dict(scope='receipt and compiler-constraint validation, NOT native byte/resource verification', checks=checks,
    failures=[item for item in checks if not item['passed']], proof_scopes=proof_scopes,
    cache_reservation_scope='pending exact place/key/outcome obligations only; no None reservation ownership or runtime law established',
    original_native_bodies_proved=0, primitive_laws_adopted=0, all18='OPEN')
runner.write('validation-summary.json', result)
print(json.dumps(dict(checks=len(checks), failures=result['failures'], all18='OPEN', native_proofs=0), indent=2))
raise SystemExit(bool(result['failures']))
