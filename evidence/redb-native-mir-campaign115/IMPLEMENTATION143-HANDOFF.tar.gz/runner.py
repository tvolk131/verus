import datetime
import difflib
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import stat
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
BASE = Path('/private/tmp/implementation140-20261108-RdrUQDUb/candidate')
HANDOFF = BASE.parent
ORIGINAL = Path('/private/tmp/redb-original-crate-preflight115/redb')
PARENT = Path('/Users/tommyvolk/.t3/worktrees/verus/t3-60978068')
TC = Path('/Users/tommyvolk/.rustup/toolchains/1.99.1-aarch64-apple-darwin')
DEADLINE = datetime.datetime.fromisoformat('2026-11-08T20:56:00+00:00').timestamp()

def sha(filename):
    digest = hashlib.sha256()
    with Path(filename).open('rb') as stream:
        for chunk in iter(lambda: stream.read(4194304), b''):
            digest.update(chunk)
    return digest.hexdigest()

def write(filename, value):
    (ROOT / filename).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

def inventory(directory):
    result = []
    for filename in sorted(Path(directory).rglob('*')):
        status = filename.lstat()
        if stat.S_ISDIR(status.st_mode):
            continue
        if not stat.S_ISREG(status.st_mode):
            raise RuntimeError('unsafe artifact: ' + str(filename))
        result.append(dict(path=str(filename.relative_to(directory)), bytes=status.st_size, sha256=sha(filename)))
    return sorted(result, key=lambda entry: entry['path'])

def resources():
    logical = allocated = 0
    for directory, children, files in os.walk(ROOT):
        for name in files:
            status = (Path(directory) / name).lstat()
            logical += status.st_size
            allocated += status.st_blocks * 512
    free = shutil.disk_usage(ROOT).free
    result = dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), logical=logical, allocated=allocated, free=free)
    assert max(logical, allocated) <= 4 * 1024**3 and free > 16 * 1024**3, result
    return result

def authenticate(phase):
    selected = json.loads((ROOT / 'inputs.json').read_text())
    failed = [entry['path'] for entry in selected if sha(entry['path']) != entry['sha256']]
    result = dict(phase=phase, selected=len(selected), failures=failed, resource=resources())
    write('authentication-' + phase + '.json', result)
    assert not failed, failed

def supplemental():
    paths = [HANDOFF / 'original-checkout-final.launch.json']
    review = Path('/private/tmp/review144-20261108-zvUvswJB')
    repair = Path('/private/tmp/redb-provenance-repair145-20261108-R61d8D')
    assert sha(review / 'SEAL.json') == '0c2a23fc004f3e48049f9260dca95cc868dd75e30a299729a9560302b8547cd3'
    assert sha(repair / 'MANIFEST.json') == 'f55358676b799b34f50cd9b4bb50aaf2d3cf51063de466d47cac31e2a2804081'
    assert sha(repair / 'repair.patch') == '841c2f730da91130b1860a2f8ae8f4f1d792c15cfc11ba3100d4e2e2abb16fc2'
    assert sha(repair / 'native.rs') == 'f05872a5d642ed028145f605e24d849c362863c1cc1a48baea989d69a923f720'
    paths += [review / name for name in ('REPORT.md', 'SEAL.json')]
    paths += [repair / name for name in ('HANDOFF.md', 'MANIFEST.json', 'repair.patch', 'native.rs')]
    entries = [dict(path=str(filename), bytes=filename.stat().st_size, sha256=sha(filename)) for filename in paths]
    write('supplemental-inputs.json', dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        custody='First selected authentication here; no retroactive preexecution claim for earlier reads or use of original launch template', entries=entries,
        repair145='HANDOFF read; patch and staged native.rs hashed only, not consumed or applied'))
    selected = json.loads((ROOT / 'inputs.json').read_text())
    selected += [entry for entry in entries if entry['path'] not in {item['path'] for item in selected}]
    write('inputs.json', selected)
    authenticate('supplemental')

def initialize():
    assert sha(HANDOFF / 'SEAL.json') == 'd80fcfca63c352e6ed1ebb3bd254291234dc03dc8bbf05972430934c6ee4eefc'
    assert sha(HANDOFF / 'candidate-final.json') == '470b1fb019f203d6b65fdced729bc1602d41dea4a4f7459801fa7f2422acbab8'
    manifest = json.loads((HANDOFF / 'candidate-final.json').read_text())
    assert inventory(BASE) == manifest
    paths = [BASE / entry['path'] for entry in manifest]
    paths += [ORIGINAL / entry['path'] for entry in inventory(ORIGINAL)]
    paths += [HANDOFF / name for name in ('SEAL.json', 'candidate-final.json', 'candidate.patch', 'README.md', 'CHANNEL-PORT.md', 'build10.receipt.json')]
    paths += [PARENT / 'evidence/redb-native-mir-campaign115' / name for name in ('AUTHORIZATION139.md', 'FIRST-CELL139.md', 'NEXT-NATIVE-LOWERING143.md', 'PRIMITIVE141-REVIEW142.json')]
    paths += [Path('/private/tmp/redb-source-review142-20261108-EYIM0YgI/REPORT.md')]
    paths += [TC / 'bin' / name for name in ('cargo', 'rustc', 'rustdoc')]
    paths += sorted((TC / 'lib').glob('librustc_driver*'))
    paths += [Path('/private/tmp/redb-native-mir115-20261108T160243Z/target/debug/deps/liblibc-709064e59816a9f7.rlib')]
    write('inputs.json', [dict(path=str(filename), bytes=filename.stat().st_size, sha256=sha(filename)) for filename in paths])
    write('baseline.json', manifest)
    authenticate('entry')
    shutil.copytree(BASE, ROOT / 'candidate')
    (ROOT / 'tmp').mkdir()
    write('commands.json', [dict(number=1, name='setup-zsh-path-failure', kind='setup', returncode=127, detail='read-only loop used zsh special path variable; commands unavailable; retained conservatively as charged setup failure'), dict(number=2, name='setup-manifest-order-failure', kind='setup', returncode=1, detail='manifest list order mismatch, all file hashes unchanged; corrected path-string sort')])
    print(json.dumps(dict(candidate_files=len(manifest), resource=resources())))

def run(name, kind, seconds, argv):
    commands = json.loads((ROOT / 'commands.json').read_text())
    assert len(commands) < 36
    assert seconds <= (600 if kind == 'build' else 120)
    seconds = min(seconds, DEADLINE - time.time() - 90)
    assert seconds > 0
    authenticate('preexecution-' + name)
    source = inventory(ROOT / 'candidate')
    write(name + '.source.json', source)
    environment = dict(json.loads((HANDOFF / 'build10.receipt.json').read_text())['environment'])
    for variable in ('CARGO_TARGET_DIR', 'CARGO_BUILD_BUILD_DIR'):
        environment[variable] = str(ROOT / 'target')
    environment['TMPDIR'] = str(ROOT / 'tmp')
    environment['VERUS_SOURCE_SNAPSHOT_SHA256'] = hashlib.sha256(json.dumps(source, sort_keys=True).encode()).hexdigest()
    entry = dict(number=len(commands) + 1, name=name, kind=kind, argv=argv, cwd=str(ROOT / 'candidate/source'), environment=environment,
                 executable_sha256=sha(argv[0]), before=resources(), timeout=seconds)
    entry['argv_regular_inputs'] = [dict(path=argument, bytes=Path(argument).stat().st_size, sha256=sha(argument)) for argument in argv[1:] if Path(argument).is_file()]
    commands.append(entry)
    write('commands.json', commands)
    write(name + '.launch.json', entry)
    started = time.monotonic()
    process = None
    cause = None
    try:
        with (ROOT / (name + '.stdout')).open('wb') as output, (ROOT / (name + '.stderr')).open('wb') as error, (ROOT / (name + '.resources.jsonl')).open('w') as samples:
            process = subprocess.Popen(argv, cwd=entry['cwd'], env=environment, stdout=output, stderr=error, start_new_session=True)
            entry.update(pid=process.pid, pgid=process.pid)
            write(name + '.launch.json', entry)
            while process.poll() is None:
                samples.write(json.dumps(resources()) + '\n')
                samples.flush()
                if time.monotonic() - started >= seconds:
                    cause = 'TIMEOUT'
                    break
                time.sleep(1)
    except BaseException as exception:
        cause = repr(exception)
    finally:
        if process is not None:
            try:
                os.killpg(process.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
            try:
                process.wait(timeout=3)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait()
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            try:
                os.killpg(process.pid, 0)
                entry['owned_group_absent'] = False
            except ProcessLookupError:
                entry['owned_group_absent'] = True
            entry['returncode'] = process.returncode
        entry.update(cause=cause, elapsed=time.monotonic() - started, after=resources())
        entry['candidate_source_unchanged_during_command'] = inventory(ROOT / 'candidate') == source
        for stream in ('stdout', 'stderr'):
            filename = ROOT / (name + '.' + stream)
            if filename.exists():
                entry[stream] = dict(bytes=filename.stat().st_size, sha256=sha(filename))
        write(name + '.receipt.json', entry)
        print(json.dumps(entry))
    assert entry.get('owned_group_absent')
    return 0 if cause is None and entry.get('returncode') == 0 else 1

def seal():
    authenticate('exit')
    baseline = {entry['path']: entry for entry in json.loads((ROOT / 'baseline.json').read_text())}
    candidate = inventory(ROOT / 'candidate')
    write('candidate-final.json', candidate)
    delta = []
    patch = []
    for entry in candidate:
        relative = entry['path']
        if baseline.get(relative) != entry:
            delta.append(dict(path=relative, baseline=baseline.get(relative), candidate=entry))
            before = (BASE / relative).read_text().splitlines(keepends=True) if relative in baseline else []
            after = (ROOT / 'candidate' / relative).read_text().splitlines(keepends=True)
            patch += difflib.unified_diff(before, after, fromfile='baseline140/' + relative, tofile='candidate143/' + relative)
    (ROOT / 'candidate.patch').write_text(''.join(patch))
    write('source-delta.json', delta)
    commands = json.loads((ROOT / 'commands.json').read_text())
    receipts = [json.loads((ROOT / (entry['name'] + '.receipt.json')).read_text()) for entry in commands if entry['kind'] != 'setup']
    assert all(entry['owned_group_absent'] for entry in receipts)
    assert candidate == json.loads((ROOT / 'build-final-expiry-17.source.json').read_text())
    validation = json.loads((ROOT / 'validation-summary.json').read_text())
    assert not validation['failures']
    def classification(entry):
        filename = ROOT / (entry['name'] + '.stderr')
        error = filename.read_text() if filename.exists() else ''
        if 'NRE143_OPEN_NATIVE_PROOF_OBLIGATIONS' in error:
            return 'expected OPEN refusal; inspect raw output for any additional failure'
        if entry['name'] == 'feature-required-refusal':
            return 'expected feature barrier'
        return 'actual retained failure'
    write('failures-and-refusals.json', [dict(number=entry['number'], name=entry['name'], kind=entry['kind'],
        returncode=entry.get('returncode'), cause=entry.get('cause'), stderr=entry.get('stderr'),
        classification=classification(entry))
        for entry in commands[:2] + receipts if entry.get('returncode') != 0 or entry.get('cause')])
    samples = [entry[phase] for entry in receipts for phase in ('before', 'after')]
    for filename in ROOT.glob('*.resources.jsonl'):
        samples += [json.loads(line) for line in filename.read_text().splitlines() if line]
    write('seal-summary.json', dict(charged=len(commands), limit=36, resource=resources(), deadline='2026-11-08T20:56:00Z', within_deadline=time.time() < DEADLINE,
        peak_logical=max(entry['logical'] for entry in samples), peak_allocated=max(entry['allocated'] for entry in samples),
        minimum_free=min(entry['free'] for entry in samples), compiled_scope='feature-enabled native-resource143 binary',
        native_bodies_proved=0, validation_scope='typed original-source constraints and receipt checks, NOT SST/AIR/native verification',
        compiler_slot='RELEASED', live_owned_groups=0, all18='OPEN', laws_adopted=0, native_application_executed=False))
    (ROOT / 'RELEASE.md').write_text('# RELEASE\n\nimplementation143 explicitly RELEASES the sole compiler/build/verifier slot at ' + datetime.datetime.now(datetime.timezone.utc).isoformat() + '. All owned groups terminated and reaped; no automatic followup. All eighteen cells remain OPEN. Historical140 24/24 and interrupted116 unchanged.\n')
    artifacts = []
    for filename in ROOT.iterdir():
        if filename.name in ('target', 'candidate', 'tmp', 'SEAL.json', 'SEAL.sha256'):
            continue
        status = filename.lstat()
        if stat.S_ISDIR(status.st_mode):
            artifacts += [dict(entry, path=filename.name + '/' + entry['path']) for entry in inventory(filename)]
        else:
            assert stat.S_ISREG(status.st_mode), filename
            artifacts.append(dict(path=filename.name, bytes=status.st_size, sha256=sha(filename)))
    artifacts.sort(key=lambda entry: entry['path'])
    write('SEAL.json', artifacts)
    (ROOT / 'SEAL.sha256').write_text(sha(ROOT / 'SEAL.json') + '  SEAL.json\n')
    print(json.dumps(dict(seal=sha(ROOT / 'SEAL.json'), charged=len(commands), resource=resources())))

if __name__ == '__main__':
    if sys.argv[1] == 'init':
        initialize()
    elif sys.argv[1] == 'run':
        sys.exit(run(sys.argv[2], sys.argv[3], float(sys.argv[4]), sys.argv[5:]))
    elif sys.argv[1] == 'seal':
        seal()
    elif sys.argv[1] == 'supplemental':
        supplemental()
    elif sys.argv[1] == 'select-late':
        filename = HANDOFF / 'outputs/original-checkout-final.json'
        entry = dict(path=str(filename), bytes=filename.stat().st_size, sha256=sha(filename))
        write('late-planning-input.json', dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), entry=entry,
            scope='Read after entry for source planning of typed projection handling only, never consumed by native143 lowerer; no retroactive custody claimed'))
        selected = json.loads((ROOT / 'inputs.json').read_text())
        selected.append(entry)
        write('inputs.json', selected)
        authenticate('late-planning-input')
