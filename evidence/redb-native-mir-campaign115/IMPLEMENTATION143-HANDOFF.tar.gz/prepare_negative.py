import shutil
import runner

destination = runner.ROOT / 'redb-source-control'
shutil.copytree(runner.ORIGINAL, destination)
source = runner.inventory(runner.ORIGINAL)
assert runner.inventory(destination) == source
runner.write('negative-source-entry.json', source)
print('Byte-identical original source control prepared; no executable run')
