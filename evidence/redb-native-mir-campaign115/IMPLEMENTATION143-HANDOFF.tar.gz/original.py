import json
from pathlib import Path
import sys
import runner

name = sys.argv[1]
arguments = json.loads((runner.HANDOFF / 'original-checkout-final.launch.json').read_text())['argv']
arguments[0] = str(runner.ROOT / 'target/debug/native-resource143')
arguments[1] = '--native-proof-output'
arguments[2] = str(runner.ROOT / (name + '.json'))
output_index = arguments.index('-o') + 1
arguments[output_index] = str(runner.ROOT / (name + '.rmeta'))
source = Path(sys.argv[2]) if len(sys.argv) > 2 else runner.ORIGINAL
arguments[-1] = str(source / 'src/lib.rs')
runner.write(name + '.original-source.json', runner.inventory(source))
sys.exit(runner.run(name, 'check', 120, arguments))
