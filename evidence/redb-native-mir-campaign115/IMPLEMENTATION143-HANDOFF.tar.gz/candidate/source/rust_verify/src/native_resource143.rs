use crate::context::{Context, ContextX, ErasureInfo};
use rustc_borrowck::consumers::{
    self, BodyWithBorrowckFacts, BorrowIndex, ConsumerOptions, TwoPhaseActivation,
};
use rustc_hir::def_id::{DefId, LOCAL_CRATE, LocalDefId};
use rustc_hir::{ExprKind as HirExprKind, HirId};
use rustc_middle::mir::{self, Operand, Place, TerminatorKind};
use rustc_middle::ty::{self, TyCtxt};
use rustc_mir_build_verus::builder::native_resource_origins;
use serde_json::{Value, json};
use std::cell::{Cell, RefCell};
use std::collections::{BTreeMap, BTreeSet, HashMap, VecDeque};
use std::rc::Rc;
use std::sync::Arc;
use std::sync::atomic::{AtomicBool, Ordering};
use vir::ast::{Expr, Mode, ParamX};

mod ledger;

static ENABLED: AtomicBool = AtomicBool::new(false);

thread_local! {
    static EXPRESSIONS: RefCell<HashMap<(DefId, HirId), Expr>> = RefCell::new(HashMap::new());
    static RESULTS: RefCell<BTreeMap<String, Value>> = RefCell::new(BTreeMap::new());
}

pub(crate) fn retain_expression(owner: DefId, hir: HirId, expression: &Expr) {
    if ENABLED.load(Ordering::SeqCst) {
        EXPRESSIONS.with(|expressions| {
            expressions
                .borrow_mut()
                .insert((owner, hir), expression.clone());
        });
    }
}

fn selected(tcx: TyCtxt<'_>, owner: LocalDefId) -> bool {
    if tcx.def_kind(owner) != rustc_hir::def::DefKind::AssocFn {
        return false;
    }
    let signature = tcx.fn_sig(owner).instantiate_identity().skip_binder();
    let Some(receiver) = signature.inputs().first() else {
        return false;
    };
    let ty::Adt(adt, _) = receiver.peel_refs().kind() else {
        return false;
    };
    if !adt.did().is_local() {
        return false;
    }
    let name = tcx.item_name(adt.did());
    let method = tcx.item_name(owner.to_def_id());
    matches!(
        (name.as_str(), method.as_str()),
        ("WritablePage", "mem_mut" | "drop")
            | ("LRUWriteCache", "take_value" | "return_value")
            | ("LRUCache", "get_mut")
            | ("PagedCachedFile", "write")
            | ("TransactionalMemory", "write_header")
    )
}

fn context(tcx: TyCtxt<'_>) -> Context<'_> {
    let erasure = ErasureInfo {
        local_hir_vir_ids: vec![],
        binder_hir_vir_ids: vec![],
        ctor_hir_vir_ids: vec![],
        resolved_calls: vec![],
        resolved_pats: vec![],
        direct_var_modes: vec![],
        ignored_functions: vec![],
        bodies: vec![],
        shadow_check: vec![],
        extra_erase_ast_ids: vec![],
        local_invariant_bodies: vec![],
    };
    let spans = crate::spans::SpanContextX::new(
        tcx,
        tcx.stable_crate_id(LOCAL_CRATE),
        tcx.sess.source_map(),
        HashMap::new(),
        None,
    );
    let mut context = ContextX::new(
        Arc::new(crate::config::ArgsX::new()),
        tcx,
        Rc::new(RefCell::new(erasure)),
        spans,
        Arc::new(crate::verus_items::from_diagnostic_items(tcx)),
        false,
        crate::rust_to_vir_base::mk_crate_id(tcx, LOCAL_CRATE),
    );
    context.arch_word_bits = Some(vir::ast::ArchWordBits::Either32Or64);
    Rc::new(context)
}

fn translate<'tcx>(ctxt: &Context<'tcx>, owner: LocalDefId) -> Result<Expr, String> {
    let body = ctxt
        .tcx
        .hir_maybe_body_owned_by(owner)
        .ok_or("no HIR body")?;
    let body_id = body.id();
    let signature = ctxt.tcx.fn_sig(owner).instantiate_identity().skip_binder();
    let mut parameters = Vec::new();
    for (parameter, typ) in body.params.iter().zip(signature.inputs()) {
        let name = crate::rust_to_vir_expr::pat_to_var(parameter.pat)
            .map_err(|error| error.note.to_string())?;
        let typ = ctxt
            .mid_ty_to_vir(owner.to_def_id(), parameter.span, typ, None)
            .map_err(|error| error.note.to_string())?;
        parameters.push(vir::def::Spanned::new(
            ctxt.spans.to_air_span(parameter.span),
            ParamX {
                name,
                typ,
                mode: Mode::Exec,
                user_mut: false,
                unwrapped_info: None,
            },
        ));
    }
    crate::rust_to_vir_func::body_to_vir(
        ctxt,
        owner.to_def_id(),
        &body_id,
        body,
        Mode::Exec,
        false,
        &None,
        None,
        &parameters,
        None,
        false,
    )
    .map(|result| result.0)
    .map_err(|error| error.note.to_string())
}

struct Occurrence<'tcx> {
    location: mir::Location,
    instance: ty::Instance<'tcx>,
    hir: HirId,
    translated: Expr,
    destination: Place<'tcx>,
}

fn resolve<'tcx>(
    tcx: TyCtxt<'tcx>,
    owner: LocalDefId,
    typ: ty::Ty<'tcx>,
) -> Result<ty::Instance<'tcx>, String> {
    let ty::FnDef(definition, arguments) = *typ.kind() else {
        return Err("NRE143_INDIRECT_CALL_OPEN".into());
    };
    ty::Instance::try_resolve(
        tcx,
        ty::TypingEnv::post_analysis(tcx, owner),
        definition,
        arguments.skip_binder(),
    )
    .map_err(|_| "NRE143_INSTANCE_RESOLUTION_OPEN".to_string())?
    .ok_or_else(|| "NRE143_INSTANCE_UNRESOLVED_OPEN".into())
}

fn bind<'tcx>(
    ctxt: &Context<'tcx>,
    owner: LocalDefId,
    facts: &BodyWithBorrowckFacts<'tcx>,
    body: &Expr,
) -> Result<Vec<Result<Occurrence<'tcx>, String>>, String> {
    let tcx = ctxt.tcx;
    let origins = native_resource_origins::get(owner);
    let types = tcx.typeck(owner);
    let mut bound = Vec::new();
    for (block, data) in facts.body.basic_blocks.iter_enumerated() {
        let terminator = data.terminator();
        let TerminatorKind::Call {
            func, destination, ..
        } = &terminator.kind
        else {
            continue;
        };
        let result = (|| {
            let matching = origins
                .iter()
                .filter(|origin| origin.scope == terminator.source_info.scope)
                .collect::<Vec<_>>();
            if matching.len() != 1 {
                return Err(format!(
                    "NRE143_EXACT_BUILDER_ORIGIN_OPEN {block:?}: {} origins",
                    matching.len()
                ));
            }
            let origin = matching[0];
            let rustc_hir::Node::Expr(hir_expression) = tcx.hir_node(origin.hir) else {
                return Err("NRE143_HIR_NOT_EXPRESSION".into());
            };
            let hir_type = match hir_expression.kind {
                HirExprKind::Call(callee, _) => types.expr_ty(callee),
                HirExprKind::MethodCall(..) => {
                    let definition = types
                        .type_dependent_def_id(origin.hir)
                        .ok_or("NRE143_HIR_INSTANCE_OPEN")?;
                    ty::Ty::new_fn_def(
                        tcx,
                        definition,
                        ty::Binder::dummy(types.node_args(origin.hir)),
                    )
                }
                _ => return Err("NRE143_HIR_CALL_KIND_OPEN".into()),
            };
            let instance = resolve(tcx, owner, func.ty(&facts.body.local_decls, tcx))?;
            if tcx.erase_and_anonymize_regions(instance)
                != tcx.erase_and_anonymize_regions(resolve(tcx, owner, hir_type)?)
            {
                return Err("NRE143_HIR_MIR_INSTANCE_MISMATCH".into());
            }
            let translated = EXPRESSIONS
                .with(|expressions| {
                    expressions
                        .borrow()
                        .get(&(owner.to_def_id(), origin.hir))
                        .cloned()
                })
                .ok_or("NRE143_REAL_VIR_OCCURRENCE_OPEN")?;
            let present = Cell::new(0);
            vir::ast_visitor::ast_visitor_check(
                body,
                &mut (),
                &mut |_, _, node| {
                    if Arc::ptr_eq(node, &translated) {
                        present.set(present.get() + 1);
                    }
                    Ok::<_, String>(())
                },
                &mut |_, _, _| Ok(()),
                &mut |_, _, _| Ok(()),
                &mut |_, _, _, _| Ok(()),
                &mut |_, _, _| Ok(()),
            )?;
            if present.get() != 1 {
                return Err("NRE143_VIR_OCCURRENCE_NOT_IN_REAL_BODY".into());
            }
            let vir::ast::ExprX::Call {
                target: vir::ast::CallTarget::Fun(kind, function, _, _, attributes),
                ..
            } = &translated.x
            else {
                return Err("NRE143_EXACT_VIR_CALL_TARGET_OPEN".into());
            };
            let function = match kind {
                vir::ast::CallTargetKind::Static => function,
                vir::ast::CallTargetKind::DynamicResolved { resolved, .. } => resolved,
                _ => return Err("NRE143_VIR_CALL_DISPATCH_OPEN".into()),
            };
            if attributes.assume_external_allowed
                || function.path != ctxt.def_id_to_vir_path(instance.def_id())
            {
                return Err("NRE143_TYPED_VIR_MIR_CALL_TARGET_MISMATCH".into());
            }
            let expected_type = ctxt
                .mid_ty_to_vir(
                    owner.to_def_id(),
                    hir_expression.span,
                    &destination.ty(&facts.body.local_decls, tcx).ty,
                    None,
                )
                .map_err(|error| error.note.to_string())?;
            if !vir::ast_util::types_equal(&expected_type, &translated.typ) {
                return Err("NRE143_VIR_OCCURRENCE_TYPE_MISMATCH".into());
            }
            Ok(Occurrence {
                location: mir::Location {
                    block,
                    statement_index: data.statements.len(),
                },
                instance,
                hir: origin.hir,
                translated,
                destination: *destination,
            })
        })();
        bound.push(result);
    }
    Ok(bound)
}

#[derive(Clone, Debug, PartialEq, Eq)]
enum Phase {
    ReceiverSuspended,
    Returned,
    Mutated(mir::Location),
    WrittenBack(mir::Location),
}

#[derive(Clone)]
struct LoanEntry<'tcx> {
    loan: BorrowIndex,
    receiver: Place<'tcx>,
    returned: Place<'tcx>,
    activation: mir::Location,
    ends: BTreeSet<mir::Location>,
    phase: Phase,
}

#[derive(Clone, Copy, PartialEq, Eq)]
enum Challenge {
    None,
    WrongReceiver,
    PrematureReturn,
    StaleWriteback,
    DuplicateLoan,
}

fn operand_place<'tcx>(operand: &Operand<'tcx>) -> Option<Place<'tcx>> {
    match operand {
        Operand::Copy(place) | Operand::Move(place) => Some(*place),
        _ => None,
    }
}

fn reachable(body: &mir::Body<'_>, from: mir::Location, to: mir::Location) -> bool {
    if from.block == to.block && from.statement_index <= to.statement_index {
        return true;
    }
    let mut queue = VecDeque::from_iter(body.basic_blocks[from.block].terminator().successors());
    let mut visited = BTreeSet::new();
    while let Some(block) = queue.pop_front() {
        if !visited.insert(block) {
            continue;
        }
        if block == to.block {
            return true;
        }
        queue.extend(body.basic_blocks[block].terminator().successors());
    }
    false
}

struct Ledger<'facts, 'tcx> {
    facts: &'facts BodyWithBorrowckFacts<'tcx>,
    entries: BTreeMap<BorrowIndex, LoanEntry<'tcx>>,
}

impl<'facts, 'tcx> Ledger<'facts, 'tcx> {
    fn new(facts: &'facts BodyWithBorrowckFacts<'tcx>) -> Self {
        Self {
            facts,
            entries: BTreeMap::new(),
        }
    }

    fn suspend(&mut self, entry: LoanEntry<'tcx>) -> Result<(), String> {
        let loan = &self.facts.borrow_set[entry.loan];
        if loan.borrowed_place() != entry.receiver || loan.assigned_place() != entry.returned {
            return Err("NRE143_LEDGER_EXACT_RECEIVER".into());
        }
        if self
            .entries
            .values()
            .any(|live| live.receiver == entry.receiver)
            || self.entries.contains_key(&entry.loan)
        {
            return Err("NRE143_LEDGER_DUPLICATE_AUTHORITY".into());
        }
        if loan.activation_location() != TwoPhaseActivation::ActivatedAt(entry.activation) {
            return Err("NRE143_LEDGER_EXACT_ACTIVATION".into());
        }
        self.entries.insert(entry.loan, entry);
        Ok(())
    }

    fn issue(&mut self, loan: BorrowIndex, at: mir::Location) -> Result<(), String> {
        let entry = self
            .entries
            .get_mut(&loan)
            .ok_or("NRE143_LEDGER_MISSING_SUSPENSION")?;
        if at != entry.activation || entry.phase != Phase::ReceiverSuspended {
            return Err("NRE143_LEDGER_ACTIVATION_ORDER".into());
        }
        entry.phase = Phase::Returned;
        Ok(())
    }

    fn mutate(
        &mut self,
        loan: BorrowIndex,
        receiver: Place<'tcx>,
        at: mir::Location,
    ) -> Result<(), String> {
        let entry = self
            .entries
            .get_mut(&loan)
            .ok_or("NRE143_LEDGER_UNISSUED_MUTATION")?;
        if entry.returned != receiver || entry.phase != Phase::Returned || at != entry.activation {
            return Err("NRE143_LEDGER_MUTATION_RECEIVER".into());
        }
        entry.phase = Phase::Mutated(at);
        Ok(())
    }

    fn writeback(
        &mut self,
        loan: BorrowIndex,
        endpoint: mir::Location,
        version: mir::Location,
    ) -> Result<(), String> {
        let entry = self
            .entries
            .get_mut(&loan)
            .ok_or("NRE143_LEDGER_UNISSUED_WRITEBACK")?;
        if !entry.ends.contains(&endpoint)
            || entry.phase != Phase::Mutated(version)
            || !reachable(&self.facts.body, version, endpoint)
        {
            return Err("NRE143_LEDGER_LOAN_END_POST_MUTATION_WRITEBACK".into());
        }
        entry.phase = Phase::WrittenBack(endpoint);
        Ok(())
    }
}

fn header_loan<'tcx>(
    tcx: TyCtxt<'tcx>,
    facts: &BodyWithBorrowckFacts<'tcx>,
    challenge: Challenge,
) -> Result<Value, String> {
    let body = &facts.body;
    let mut copies = Vec::new();
    for (block, data) in body.basic_blocks.iter_enumerated() {
        let TerminatorKind::Call { func, args, .. } = &data.terminator().kind else {
            continue;
        };
        let ty::FnDef(definition, arguments) = *func.ty(&body.local_decls, tcx).kind() else {
            continue;
        };
        if tcx.item_name(definition).as_str() != "copy_from_slice"
            || tcx.crate_name(definition.krate).as_str() != "core"
        {
            continue;
        }
        let signature = tcx
            .fn_sig(definition)
            .instantiate(tcx, arguments.skip_binder())
            .skip_binder();
        if !matches!(signature.inputs()[0].kind(), ty::Ref(_, inner, rustc_ast::Mutability::Mut)
            if matches!(inner.kind(), ty::Slice(element) if *element == tcx.types.u8))
        {
            continue;
        }
        copies.push((
            mir::Location {
                block,
                statement_index: data.statements.len(),
            },
            operand_place(&args[0].node).ok_or("NRE143_COPY_RECEIVER_NOT_PLACE")?,
        ));
    }
    if copies.len() != 1 {
        return Err(format!("NRE143_EXACT_NATIVE_COPY_OPEN {}", copies.len()));
    }
    let (activation, returned) = copies[0];
    let loans = facts
        .borrow_set
        .iter_enumerated()
        .filter(|(_, loan)| {
            loan.assigned_place() == returned
                && loan.activation_location() == TwoPhaseActivation::ActivatedAt(activation)
        })
        .collect::<Vec<_>>();
    if loans.len() != 1 {
        return Err("NRE143_COPY_LOAN_NOT_EXACT".into());
    }
    let (loan, data) = loans[0];
    let all_ends = consumers::calculate_borrows_out_of_scope_at_location(
        body,
        &facts.region_inference_context,
        &facts.borrow_set,
    );
    let ends = all_ends
        .iter()
        .filter(|(_, loans)| loans.contains(&loan))
        .map(|(location, _)| *location)
        .collect::<BTreeSet<_>>();
    if ends.is_empty() {
        return Err("NRE143_NATIVE_NLL_END_OPEN".into());
    }
    let mut entry = LoanEntry {
        loan,
        receiver: data.borrowed_place(),
        returned,
        activation,
        ends: ends.clone(),
        phase: Phase::ReceiverSuspended,
    };
    if challenge == Challenge::WrongReceiver {
        entry.receiver = mir::Place::from(mir::RETURN_PLACE);
    }
    let mut ledger = Ledger::new(facts);
    ledger.suspend(entry.clone())?;
    if challenge == Challenge::DuplicateLoan {
        ledger.suspend(entry)?;
    }
    if challenge == Challenge::PrematureReturn {
        ledger.writeback(loan, *ends.iter().next().unwrap(), activation)?;
    }
    ledger.issue(loan, activation)?;
    ledger.mutate(loan, returned, activation)?;
    for endpoint in &ends {
        let mut branch = Ledger {
            facts,
            entries: ledger.entries.clone(),
        };
        let version = if challenge == Challenge::StaleWriteback {
            data.reserve_location()
        } else {
            activation
        };
        branch.writeback(loan, *endpoint, version)?;
    }
    Ok(
        json!({"constraint": "exact receiver suspension/activation/mutation/NLL writeback shape checked",
        "loan": format!("{loan:?}"), "receiver": format!("{:?}", data.borrowed_place()),
        "returned": format!("{returned:?}"), "activation": format!("{activation:?}"), "ends": format!("{ends:?}"),
        "byte_authority": "OPEN: no incoming checkout or native slice-copy relation is assumed",
        "cleanup_partial_mutation_frame": "OPEN: prefix bytes, panic, unwind and abort are not rollback"}),
    )
}

fn proof_assertion(span: &vir::messages::Span, label: &str) -> Result<Expr, String> {
    use vir::ast::{Constant, ExprX, SpannedTyped};
    let predicate = SpannedTyped::new(
        span,
        &vir::ast_util::bool_typ(),
        ExprX::Const(Constant::Bool(false)),
    );
    let assertion = SpannedTyped::new(
        span,
        &vir::ast_util::unit_typ(),
        ExprX::AssertAssume {
            is_assume: false,
            expr: predicate,
            msg: Some(vir::messages::error(span, label)),
        },
    );
    let ExprX::AssertAssume {
        is_assume: false,
        expr,
        ..
    } = &assertion.x
    else {
        return Err("NRE143_GENERATED_PROOF_KIND".into());
    };
    if !vir::ast_util::type_is_bool(&expr.typ)
        || !matches!(expr.x, ExprX::Const(Constant::Bool(false)))
        || !vir::ast_util::types_equal(&assertion.typ, &vir::ast_util::unit_typ())
    {
        return Err("NRE143_GENERATED_PROOF_WELL_FORMEDNESS".into());
    }
    Ok(assertion)
}

fn lower_original_proof<'tcx>(
    tcx: TyCtxt<'tcx>,
    owner: LocalDefId,
    facts: &BodyWithBorrowckFacts<'tcx>,
    body: &Expr,
    occurrences: &[Result<Occurrence<'tcx>, String>],
    lowering: &ledger::Lowering<'tcx>,
) -> Result<Value, String> {
    use ledger::{Effect, Requirement};
    use vir::ast::{ExprX, SpannedTyped, StmtX};
    let validation = lowering
        .requirements
        .iter()
        .map(|requirement| requirement.validate(tcx, owner, facts))
        .collect::<Vec<_>>();
    let mut before: BTreeMap<mir::Location, Vec<String>> = BTreeMap::new();
    let mut after: BTreeMap<mir::Location, Vec<String>> = BTreeMap::new();
    let mut open = Vec::new();
    for requirement in &lowering.requirements {
        match requirement {
            Requirement::OriginalCall { at, instance, .. } => {
                before.entry(*at).or_default().push(format!(
                    "NRE143_CHECKED_NATIVE_CALLEE_OPEN {}",
                    tcx.def_path_str(instance.def_id())
                ));
            }
            Requirement::IncomingCheckout { at, .. } => {
                before.entry(*at).or_default().push("NRE143_INCOMING_CHECKOUT_BYTE_AUTHORITY_OPEN: constructor/cache None reservation/complete loan inventory/Arc eligibility are not proved".into());
            }
            Requirement::ByteMutation {
                at,
                effect: Effect::NormalCopy(_),
                ..
            } => {
                after
                    .entry(*at)
                    .or_default()
                    .push("NRE143_NATIVE_COPY_BYTES_AND_MUTATION_FRAME_OPEN".into());
            }
            Requirement::LoanEndWriteback {
                at,
                effect: Effect::NormalCopy(copy),
                cleanup: false,
                ..
            } => {
                let TerminatorKind::Call {
                    target: Some(target),
                    ..
                } = facts.body.basic_blocks[copy.block].terminator().kind
                else {
                    return Err("NRE143_WRITEBACK_COPY_NOT_CALL".into());
                };
                if at.block != target || at.statement_index != 0 {
                    open.push(format!("NRE143_NONIMMEDIATE_VIR_LOAN_END_OPEN {at:?}"));
                } else {
                    after.entry(*copy).or_default().push(format!("NRE143_EXACT_LOAN_END_BYTE_WRITEBACK_AND_RECEIVER_RESUMPTION_OPEN {requirement:?}"));
                }
            }
            Requirement::LoanEndWriteback {
                at, cleanup: true, ..
            } => open.push(format!(
                "NRE143_CLEANUP_VIR_WRITEBACK_OPEN {at:?}: {requirement:?}"
            )),
            _ => open.push(format!(
                "NRE143_UNDISCHARGED_NATIVE_REQUIREMENT {requirement:?}"
            )),
        }
    }
    let anchors = occurrences
        .iter()
        .filter_map(|occurrence| occurrence.as_ref().ok())
        .collect::<Vec<_>>();
    for at in before.keys().chain(after.keys()) {
        if !anchors.iter().any(|occurrence| occurrence.location == *at) {
            open.push(format!("NRE143_UNBOUND_REAL_VIR_PROOF_OCCURRENCE {at:?}"));
        }
    }
    let wrappers = RefCell::new(Vec::new());
    let assertion_count = Cell::new(0);
    let lowered = vir::ast_visitor::map_expr_with_original(body, &|original, mapped| {
        let Some(occurrence) = anchors
            .iter()
            .find(|occurrence| Arc::ptr_eq(&occurrence.translated, original))
        else {
            return Ok(mapped.clone());
        };
        let pre = before
            .get(&occurrence.location)
            .cloned()
            .unwrap_or_default();
        let post = after.get(&occurrence.location).cloned().unwrap_or_default();
        if pre.is_empty() && post.is_empty() {
            return Ok(mapped.clone());
        }
        if !post.is_empty() && !vir::ast_util::types_equal(&mapped.typ, &vir::ast_util::unit_typ())
        {
            return Err(vir::messages::error(
                &mapped.span,
                "NRE143_POSTPROOF_NONUNIT_ORIGINAL_CALL_OPEN",
            ));
        }
        let mut statements = Vec::new();
        for label in &pre {
            let proof = proof_assertion(&mapped.span, label)
                .map_err(|error| vir::messages::error(&mapped.span, error))?;
            assertion_count.set(assertion_count.get() + 1);
            statements.push(vir::def::Spanned::new(
                proof.span.clone(),
                StmtX::Expr(proof),
            ));
        }
        let tail = if post.is_empty() {
            Some(mapped.clone())
        } else {
            statements.push(vir::def::Spanned::new(
                mapped.span.clone(),
                StmtX::Expr(mapped.clone()),
            ));
            for label in &post {
                let proof = proof_assertion(&mapped.span, label)
                    .map_err(|error| vir::messages::error(&mapped.span, error))?;
                assertion_count.set(assertion_count.get() + 1);
                statements.push(vir::def::Spanned::new(
                    proof.span.clone(),
                    StmtX::Expr(proof),
                ));
            }
            None
        };
        let wrapped = SpannedTyped::new(
            &mapped.span,
            &mapped.typ,
            ExprX::Block(Arc::new(statements), tail),
        );
        wrappers
            .borrow_mut()
            .push((wrapped.clone(), pre.len(), !post.is_empty()));
        Ok(wrapped)
    })
    .map_err(|error| error.note.to_string())?;
    let restored = vir::ast_visitor::map_expr_with_original(&lowered, &|original, mapped| {
        let wrappers = wrappers.borrow();
        let Some((_, prefix, post)) = wrappers
            .iter()
            .find(|(wrapper, _, _)| Arc::ptr_eq(wrapper, original))
        else {
            return Ok(mapped.clone());
        };
        let ExprX::Block(statements, tail) = &mapped.x else {
            return Err(vir::messages::error(
                &mapped.span,
                "NRE143_PROOF_ERASURE_SHAPE",
            ));
        };
        if *post {
            let StmtX::Expr(original) = &statements[*prefix].x else {
                return Err(vir::messages::error(
                    &mapped.span,
                    "NRE143_PROOF_ERASURE_CALL",
                ));
            };
            Ok(original.clone())
        } else {
            tail.clone()
                .ok_or_else(|| vir::messages::error(&mapped.span, "NRE143_PROOF_ERASURE_TAIL"))
        }
    })
    .map_err(|error| error.note.to_string())?;
    if serde_json::to_vec(&restored).unwrap() != serde_json::to_vec(body).unwrap() {
        return Err("NRE143_ORIGINAL_EXECUTABLE_CHANGED".into());
    }
    Ok(
        json!({"body": lowered, "source_bound_open_assertions": assertion_count.get(),
        "typed_constraint_validation": validation, "unlowered_or_open": open,
        "proof_erasure_reproduces_entire_original_vir_body": true,
        "well_formed_scope": "generated closed bool/unit assertions only; full original function/dependency VIR well-formedness remains OPEN",
        "verifier_scope": "not SST/AIR verified; false debt assertions are NOT byte/resource semantics or a proof", "export": "REFUSED"}),
    )
}

fn inspect<'tcx>(
    tcx: TyCtxt<'tcx>,
    owner: LocalDefId,
    facts: &BodyWithBorrowckFacts<'tcx>,
) -> Value {
    let ctxt = context(tcx);
    let translated = translate(&ctxt, owner);
    let bindings = match &translated {
        Ok(body) => bind(&ctxt, owner, facts, body),
        Err(error) => Err(format!("NRE143_ORDINARY_FRONTEND_OPEN {error}")),
    };
    let mut obligations = Vec::new();
    for (block, data) in facts.body.basic_blocks.iter_enumerated() {
        match &data.terminator().kind {
            TerminatorKind::Assert { .. } => obligations.push(json!({"block": format!("{block:?}"), "kind": "OPEN_ASSERT_SEMANTICS", "requires": "condition/normal/failure/panic-hook/unwind/abort prefix effects; successors are NOT a semantics proof"})),
            TerminatorKind::Call { func, .. } => {
                if let Ok(instance) = resolve(tcx, owner, func.ty(&facts.body.local_decls, tcx)) {
                    obligations.push(json!({"block": format!("{block:?}"), "callee": tcx.def_path_str(instance.def_id()),
                        "kind": if instance.def_id().is_local() { "CHECKED_ORIGINAL_BODY_REQUIRED" } else { "UNADOPTED_NATIVE_OPERATION_REQUIRED" }}));
                }
            }
            _ => {}
        }
    }
    let method = tcx.item_name(owner.to_def_id());
    let cfg_negatives = if method.as_str() == "write_header" {
        use ledger::Challenge;
        json!(
            [
                Challenge::LostReturnedOrigin,
                Challenge::MissingTerminatorEnds,
                Challenge::WrongProjection,
                Challenge::StaleWriteback
            ]
            .iter()
            .map(
                |challenge| ledger::lower_with_challenge(tcx, owner, facts, *challenge)
                    .map(|_| "BUG: perturbed native ledger accepted".to_string())
            )
            .collect::<Vec<_>>()
        )
    } else {
        Value::Null
    };
    let native_lowering = ledger::lower(tcx, owner, facts).map(|lowering| {
        let original_proof = match (&translated, &bindings) {
            (Ok(body), Ok(occurrences)) => lower_original_proof(tcx, owner, facts, body, occurrences, &lowering),
            _ => Err("NRE143_ORDINARY_VIR_BODY_BINDING_OPEN".into()),
        };
        json!({
        "requirements": lowering.requirements.iter().map(|requirement| format!("{requirement:?}")).collect::<Vec<_>>(),
        "exact_copy_paths": lowering.exact_copy_paths, "returned_loans": lowering.returned_loans,
        "visited_occurrences": lowering.visited_occurrences,
        "original_body_proof_lowering": original_proof,
        "status": "typed native constraints generated; every semantic resource requirement remains OPEN"})});
    let ledger = if method.as_str() == "write_header" {
        json!({"original": header_loan(tcx, facts, Challenge::None),
            "wrong_receiver": header_loan(tcx, facts, Challenge::WrongReceiver),
            "premature_return": header_loan(tcx, facts, Challenge::PrematureReturn),
            "stale_writeback": header_loan(tcx, facts, Challenge::StaleWriteback),
            "duplicate_loan": header_loan(tcx, facts, Challenge::DuplicateLoan)})
    } else {
        Value::Null
    };
    json!({"owner": tcx.def_path_str(owner), "ordinary_frontend": translated.as_ref().map(|_| "body translated, not function verified").map_err(Clone::clone),
        "vir_body": translated.ok().map(|expression| serde_json::to_value(expression).unwrap()),
        "occurrences": bindings.map(|occurrences| occurrences.iter().map(|occurrence| match occurrence {
            Ok(occurrence) => json!({"Ok": {"location": format!("{:?}", occurrence.location),
                "instance": format!("{:?}", occurrence.instance), "hir": format!("{:?}", occurrence.hir),
                "vir_ast_id": occurrence.translated.span.id, "destination": format!("{:?}", occurrence.destination)}}),
            Err(error) => json!({"Err": error}),
        }).collect::<Vec<_>>()),
        "local_shape_controls_not_authority": ledger, "cfg_semantic_negatives": cfg_negatives,
        "native_lowering": native_lowering, "obligations": obligations,
        "checkout": "OPEN: actual constructor, take_value/get_mut mutation, reserved None ownership across unlock, reused-or-zero bytes and complete handle inventory",
        "status": "OPEN; no native export, no primitive adoption, no first-cell closure"})
}

fn capture(tcx: TyCtxt<'_>, owner: LocalDefId) {
    let bodies =
        consumers::get_bodies_with_borrowck_facts(tcx, owner, ConsumerOptions::PoloniusInputFacts);
    if let Some(facts) = bodies.get(&owner) {
        let result = inspect(tcx, owner, facts);
        RESULTS.with(|results| {
            results.borrow_mut().insert(tcx.def_path_str(owner), result);
        });
    }
}

struct Callbacks {
    output: String,
}

impl rustc_driver::Callbacks for Callbacks {
    fn config(&mut self, configuration: &mut rustc_interface::interface::Config) {
        native_resource_origins::begin();
        ENABLED.store(true, Ordering::SeqCst);
        configuration.override_queries = Some(|_, providers| {
            providers.queries.mir_built = |tcx, owner| {
                tcx.alloc_steal_mir(rustc_mir_build_verus::builder::build_mir_inner_impl(
                    tcx, owner,
                ))
            };
            providers.queries.mir_borrowck = |tcx, owner| {
                if selected(tcx, owner) {
                    capture(tcx, owner);
                }
                (rustc_interface::DEFAULT_QUERY_PROVIDERS
                    .queries
                    .mir_borrowck)(tcx, owner)
            };
        });
    }

    fn after_analysis<'tcx>(
        &mut self,
        compiler: &rustc_interface::interface::Compiler,
        tcx: TyCtxt<'tcx>,
    ) -> rustc_driver::Compilation {
        for owner in tcx.hir_body_owners() {
            if selected(tcx, owner) {
                tcx.ensure_done().mir_borrowck(owner);
            }
        }
        let results = RESULTS.with(|results| json!(*results.borrow()));
        std::fs::write(&self.output, serde_json::to_vec_pretty(&json!({"schema": "native143-typed-lowering-open-v1", "bodies": results,
            "native_bodies_proved": 0, "native_certificate": false, "laws_adopted": 0, "all18": "OPEN"})).unwrap()).unwrap();
        compiler.sess.dcx().err("NRE143_OPEN_NATIVE_PROOF_OBLIGATIONS: incoming authority/primitive relations/complete original bodies not proved; export refused");
        rustc_driver::Compilation::Stop
    }
}

pub fn main() -> std::process::ExitCode {
    let mut arguments = std::env::args().collect::<Vec<_>>();
    if arguments.len() < 3 || arguments[1] != "--native-proof-output" {
        eprintln!(
            "native-resource143 --native-proof-output FILE [original rustc arguments]; OPEN-only, no export"
        );
        return std::process::ExitCode::FAILURE;
    }
    let output = arguments.remove(2);
    arguments.remove(1);
    let result = rustc_driver::catch_fatal_errors(|| {
        rustc_driver::run_compiler(&arguments, &mut Callbacks { output })
    });
    if result.is_ok() {
        std::process::ExitCode::SUCCESS
    } else {
        std::process::ExitCode::FAILURE
    }
}
