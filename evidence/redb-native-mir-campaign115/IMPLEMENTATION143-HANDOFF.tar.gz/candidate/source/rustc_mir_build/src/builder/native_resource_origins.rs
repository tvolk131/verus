use rustc_hir::HirId;
use rustc_hir::def_id::LocalDefId;
use rustc_middle::mir::{SourceInfo, SourceScope};
use rustc_middle::thir::{ExprId, ExprKind};
use std::collections::HashMap;
use std::sync::Mutex;
use std::sync::atomic::{AtomicBool, Ordering};

static ENABLED: AtomicBool = AtomicBool::new(false);
static CALLS: Mutex<Option<HashMap<LocalDefId, Vec<CallOrigin>>>> = Mutex::new(None);

#[derive(Clone, Debug)]
pub struct CallOrigin {
    pub hir: HirId,
    pub thir: ExprId,
    pub scope: SourceScope,
}

pub fn begin() {
    *CALLS.lock().unwrap() = Some(HashMap::new());
    ENABLED.store(true, Ordering::SeqCst);
}

pub fn get(owner: LocalDefId) -> Vec<CallOrigin> {
    CALLS
        .lock()
        .unwrap()
        .as_ref()
        .and_then(|calls| calls.get(&owner))
        .cloned()
        .unwrap_or_default()
}

pub(super) fn call_scope(
    builder: &mut super::Builder<'_, '_>,
    expression: ExprId,
    source: SourceInfo,
) -> SourceInfo {
    if !ENABLED.load(Ordering::SeqCst) {
        return source;
    }
    let mut candidates = Vec::new();
    for scope in builder.thir.exprs.iter() {
        let ExprKind::Scope {
            hir_id, mut value, ..
        } = scope.kind
        else {
            continue;
        };
        loop {
            if value == expression {
                if !candidates.contains(&hir_id) {
                    candidates.push(hir_id);
                }
                break;
            }
            value = match builder.thir[value].kind {
                ExprKind::Borrow { arg, .. } | ExprKind::Deref { arg } => arg,
                ExprKind::Use { source }
                | ExprKind::PointerCoercion { source, .. }
                | ExprKind::NeverToAny { source } => source,
                _ => break,
            };
        }
    }
    if candidates.len() != 1 {
        return source;
    }
    let hir = candidates[0];
    let scope = builder.new_source_scope(source.span, super::scope::LintLevel::Explicit(hir));
    CALLS
        .lock()
        .unwrap()
        .as_mut()
        .unwrap()
        .entry(builder.def_id)
        .or_default()
        .push(CallOrigin {
            hir,
            thir: expression,
            scope,
        });
    SourceInfo { scope, ..source }
}
