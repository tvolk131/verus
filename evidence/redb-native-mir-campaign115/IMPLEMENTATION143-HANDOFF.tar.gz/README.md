# Implementation143: partial original-body lowering, native export REFUSED

The requested complete original-body occurrence/resource proof lowering is NOT
achieved. This is a distinct, compiled compiler implementation and checked loan
constraint increment, not a durability proof, adopted primitive law, or accepted
native resource certificate. All eighteen cells remain OPEN. Original native
bodies proved: 0. Primitive laws adopted: 0. No SST/AIR/SMT proof was run.

## Source custody and reconstruction

Work is confined to `/private/tmp/implementation143-20261108-LpJjrIbt`.
The candidate is copied from the authenticated 1100-file sealed140 candidate at
`/private/tmp/implementation140-20261108-RdrUQDUb/candidate`, not candidate141.
The parent seal SHA256 is
`d80fcfca63c352e6ed1ebb3bd254291234dc03dc8bbf05972430934c6ee4eefc`;
its candidate-final manifest SHA256 is
`470b1fb019f203d6b65fdced729bc1602d41dea4a4f7459801fa7f2422acbab8`.
All baseline files matched before copying. `candidate.patch` and
`source-delta.json` are the exact baseline140-relative delta, including newly
authored files. `candidate-final.json` authenticates the entire final candidate.
They are generated at seal; no Git operation or shell checkout was used.

`inputs.json`, entry/preexecution/exit authentication receipts, launch source
inventories, and supplemental custody receipts distinguish first authentication
times. In particular the140 original-launch template and review144 inputs were
selected after their initial use/read; no retroactive custody is claimed.
The old140 serialized output was subsequently inspected only to plan typed Option
projection handling; it is not read by the143 compiler or used as a certificate.

Original redb at `/private/tmp/redb-original-crate-preflight115/redb` remains
byte-identical and read-only. Its applicable AGENTS instructions were read.
No original/native application was executed. Compiler sessions analyze original
crate source and stop with an error; they do not execute redb or produce a
successful native library. The final source-control snapshot is an exact copy of
the entire authenticated original source tree, not an alternative/shadow body.

## Implemented compiler scope

- A feature-required `native-resource143` binary obtains rustc typed MIR and
  borrow facts. It does not consume140 serialized/debug graph identities.
- The MIR builder retains a unique actual THIR/HIR call origin in a dedicated
  SourceScope while constructing the original call. Executable MIR operations
  are not replaced. Ambiguous/missing origins remain OPEN.
- The ordinary frontend's actual `body_to_vir` translates original HIR. Its real
  Expr nodes are retained by owner/HirId. Binding checks exact Arc membership in
  that original VIR body, HIR/MIR resolved Instance agreement, destination type,
  and actual VIR static/resolved call target path. Spans, local numbers, labels,
  digests and output strings are not the in-memory binding certificates.
- A compiler-owned, full-Place keyed ledger handles destructive destinations,
  moved inputs including unknown/aggregate rvalues, storage reuse, unknown
  statements, supported exact reborrows, call outcomes, and loan origin expiry.
  It checks actual reserve/activation locations and NLL region containment.
- Original `mem_mut` is followed through actual Arc::get_mut, Option::unwrap,
  reborrows and return `_0`, back to the original `self.data` Arc place. These
  are pending outcome/returned-loan obligations, not Arc uniqueness authority.
- Original header `mem_mut` is connected to the actual copy receiver, active
  returned loan and full projected borrowed place. Normal complete-copy and
  unwind-prefix effects are distinct. NLL ends are processed before every
  statement AND terminator, including header empty cleanup bb24:0 and
  return_value bb4:0. Loan-end obligations include receiver resumption/writeback;
  they are not discharged by removing a pending value or printing an endpoint.
- Actual LRU get_mut, nominal Option Some projections, unwrap and exact reborrow
  paths carry cache/key/slot identity to original take and replace. Both final
  CacheReservation obligations retain their actual getter/key/receiver origin.
  They do NOT establish successful checkout or ownership of a cache None slot.
- Actual retained VIR calls are wrapped with closed, type-checked bool/unit
  false-assertion proof debts, never assumptions. Erasing these wrappers is
  checked against the entire original VIR body. No arbitrary relation vectors,
  fabricated executable body, trusted opaque native call or primitive law is
  installed. Assertions express missing authority, NOT byte/resource semantics.

The compiler's JSON is only a serialization of results produced by these typed
checks; the serialization is not consumed as proof authority. The old140
native.rs remains byte-identical and is not the143 lowerer's authority.

## Compiled, lowered, checked, and NOT proved

The final feature-enabled binary builds offline, locked, jobs1 (final build
receipt `build-final-expiry-17`). Seven original methods are selected. Six
ordinary bodies translate. Exact actual VIR call bindings include original
mem_mut's Arc/unwrap and header's write/mem_mut/copy. Other adjusted/implicit
occurrences explicitly remain unbound. No claim of full-function/dependency VIR
well-formedness is made: only generated closed proof-debt leaves get the local
bool/unit check. Original nominal datatypes are preserved, but a complete checked
declaration/import environment, function WF, modes, SST and AIR are missing.

Original PagedCachedFile::write still fails ordinary frontend translation at a
macro-expanded for loop. Independently its MIR Assert bb0:12 is explicitly
refused because condition/failure/panic/unwind/abort semantics are not lowered.
Recording successors is not a proof of those semantics. No original statements
or types were rewritten to admit this method.

Cleanup VIR proof placement, byte mutation/frame semantics, incoming checkout
authority, constructor/eligibility, complete ownership inventory, panic effects,
cache/map/LRU/hasher/callback/backend bodies, and Arc/Mutex/atomic runtime laws
remain OPEN checked obligations. A type or Instance selector is NOT a runtime
binding or legal-execution certificate. There is no latest-load, successful-lock,
unwrap, inert-callback, panic-rollback or weak-CAS-progress assumption. Unknown
exit frames remain OPEN even when tracked pending maps happen to be empty.
The path enumerator refuses loops/resource invariants; it is not a complete
alias-aware multi-resource affine verifier. Native export unconditionally fails.

## Validation and exact negatives

`original-final`, `negative-final`, and `control-restored` analyze the same
scratch source-control path with the same final executable. The source mutant
retains original storage.write but sends the actual copy to unrelated header
bytes instead of its returned page slice. Its ordinary header frontend succeeds
and the new typed check rejects with
`NRE143_COPY_HAS_NO_EXACT_RETURNED_LOAN_ORIGIN`; this is not an unrelated frontend
failure. `semantic-negative.patch` and the preserved negative source record the
exact mutation. The original source tree is never edited. The scratch source is
then restored byte-for-byte and the entire repeated result, including OPEN
obligations, is compared byte-for-byte in `validation-summary.json`.

Four additional fault-injection controls operate on the actual original typed
ledger transfers: lost origin, missing terminator ends, wrong full projection,
and stale writeback event. They target the new checks, but are NOT four changed
source programs or four native proofs. Older local shape controls are explicitly
labelled not authority and are not the milestone. Generated assertion counts
also are not proof counts. See raw JSON and validation summary for exact scope.

The feature-required binary barrier is tested without the enabling feature.
An ordinary default-off library rebuild is NOT run in the remaining allowance.
Existing native/import/export/Infer/S0/full-scope/purity admission paths are not
changed or weakened. There is no trust adoption or parent integration.

## Failures, limits and release

`commands.json`, every `.launch.json`, `.source.json`, `.receipt.json`, raw
`.stdout`/`.stderr` and `.resources.jsonl` retain exact argv/environment/source
and executable identities, return codes, failures and bounded group teardown.
`failures-and-refusals.json` separates intended OPEN/feature refusals from actual
build/setup failures. The first two setup failures are conservatively charged.
Retained compiler failures include HirId Ord, pinned rustc API incompatibilities,
missing rustc_private, unknown arch_word_bits panic, lifetime/visitor issues,
misplaced negative block, Operand Eq, and incorrect Call pattern. None is hidden
or credited as a proof. The final formatter intentionally changes source; all
subsequent compiler source identities are retained. Earlier driver versions are
not retroactively authenticated by the final driver hash.

Review144 is source-only. The145 handoff is read and its staged artifacts are
authenticated, but its patch/native.rs and ten synthetic helper tests are NOT
consumed, compiled or run. Equivalent full-place/endpoint rules are implemented
independently in143 typed code. No independent closure of R144 findings is
claimed. Candidate141 remains rejected and unconsumed.

At most36 charged commands, jobs1, <=600-second builds, <=120-second checks,
<=4GiB fresh scratch, >16GiB free disk, and the conservative20:56UTC deadline
are enforced by the driver. All owned process groups are bounded, terminated
and reaped. `seal-summary.json`, `SEAL.json`, `SEAL.sha256` and `RELEASE.md`
record final resources, command usage and explicit compiler-slot release.
Historical140's24/24 exhaustion and interrupted116 remain unchanged. There is
no network, Git write, destructive cleanup, subdelegation, goal operation,
native application execution, automatic followup or permission/law adoption.

## Final accounting caveats

The allowance is exhausted at36/36, including two conservatively charged setup
failures. No further compiler/check/proof command is authorized or run. Final
receipt validation succeeds, including raw byte-identical original/restored
results, the real-source negative's intended new failure, actual terminator
endpoints, all four typed CFG controls, and default-off binary refusal. Those
receipt checks are not a solver proof. The final compiler source is exactly the
source inventory of the successful final build.

The first two setup failures have retained narrative records, not independently
saved exact raw shell argv/environment/stdout/stderr. Full raw compiler/build/
check receipts begin at command3. Read-only exploratory misses (an initially
wrong receipts subdirectory and an initially wrong140 output path) were not
compiler sessions; neither changes the allowance. Late supplemental custody is
explicitly recorded, not backdated. Driver source identity is exact at final
seal and, for final validation, in argv_regular_inputs; earlier unrecorded driver
versions are not falsely claimed to have per-command source hashes.

The remaining native semantic authority, full original-function/dependency WF,
and cleanup proof-lowering gaps are substantive. This worker does not recommend
consumption as a native proof or adoption as a trusted API relation package.
Independent source review and explicit parent disposition would still be needed
before any such use. No review or automatic followup is started here.
