import base64
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile
import time

ROOT = Path('/private/tmp/redb-native-mir115-20261108T160243Z')
ORACLE = Path('/private/tmp/redb-native-mir-campaign115-oracle-20261108T160308Z')
FROZEN = Path('/private/tmp/redb-compiler-validation114-worker-20261108T151020Z/snapshot')
OUT = Path(__file__).resolve().parent
EXPECTED_MANIFEST = 'eaa4adc70825d3b43cfb3b55020c7d8bbee73f65241b3c5715b1c4bd8d89f920'
EXPECTED_ARCHIVE = '0d8beff0e8b6741cc3f30a3bf6efacba5666a37e5b945296590febe358a526b5'
EXPECTED_FROZEN = 'c9cb297436ab24053c254ed95bd4e520ef6fca5b86832d217b37302cb5ad7b23'
EXPECTED_FINAL = 'a5ea05ccd4ecd04f5fc0fde6963cdfaaf7e29543a1c7def511a23e6d22f8ee81'
EXPECTED_BINARY = '876136841ad6938783d06a4d6751b9bffd268cb04d4626c20cff90b79167a951'

def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(4 * 1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()

def digest_records(records):
    return hashlib.sha256(json.dumps(records, sort_keys=True, separators=(',', ':')).encode()).hexdigest()

def inventory(root):
    records = []
    for base, directories, filenames in os.walk(root, followlinks=False):
        directories.sort()
        for filename in sorted(filenames):
            path = Path(base) / filename
            record = {'path': str(path.relative_to(root)), 'bytes': path.stat().st_size, 'sha256': sha(path)}
            if path.is_symlink():
                record.update(symlink=os.readlink(path), resolved=str(path.resolve()))
            records.append(record)
    return sorted(records, key=lambda record: record['path'])

def save_text(name, text):
    destination = OUT / name
    if destination.exists():
        raise RuntimeError('Refusing to overwrite evidence: ' + str(destination))
    if text and not text.endswith('\n'):
        raise RuntimeError('apply_patch capture needs final newline: ' + name)
    patch = '*** Begin Patch\n*** Add File: ' + str(destination) + '\n'
    patch += ''.join('+' + line + '\n' for line in text.splitlines())
    patch += '*** End Patch\n'
    result = subprocess.run(['apply_patch'], input=patch, text=True, capture_output=True)
    if result.returncode:
        raise RuntimeError(result.stdout + result.stderr)

def save_json(name, data):
    save_text(name, json.dumps(data, sort_keys=True, indent=2) + '\n')

def resources():
    stat = os.statvfs(OUT)
    records = [path.stat() for path in OUT.rglob('*') if path.is_file()]
    result = {'free_bytes': stat.f_bavail * stat.f_frsize,
              'scratch_logical_bytes': sum(record.st_size for record in records),
              'scratch_allocated_bytes': sum(record.st_blocks * 512 for record in records)}
    assert result['free_bytes'] > 16 * 1024 ** 3, result
    assert result['scratch_allocated_bytes'] < 128 * 1024 ** 2, result
    return result

def authenticate(phase):
    start_ns = time.time_ns()
    seal = json.loads((ROOT / 'SEAL.json').read_text())
    manifest_sha = sha(ROOT / 'SEALED-MANIFEST.json')
    archive_sha = sha(ROOT / 'SOURCE-AND-RECEIPTS.tar.gz')
    assert manifest_sha == seal['manifest_sha256'] == EXPECTED_MANIFEST
    assert archive_sha == seal['archive_sha256'] == EXPECTED_ARCHIVE
    manifest = json.loads((ROOT / 'SEALED-MANIFEST.json').read_text())
    records = manifest['records']
    assert len(records) == seal['manifest_payload_files'] == 3920
    assert len({record['path'] for record in records}) == len(records)
    for record in records:
        relative = Path(record['path'])
        assert not relative.is_absolute() and '..' not in relative.parts
        path = ROOT / relative
        assert path.stat().st_size == record['bytes'], record
        assert sha(path) == record['sha256'], record
    assert digest_records(records) == manifest['fingerprint']
    actual_paths = {str(path.relative_to(ROOT)) for path in ROOT.rglob('*') if path.is_file()}
    assert actual_paths == {record['path'] for record in records} | set(manifest['exclusions'])
    bundled = {record['path']: record for record in records
               if Path(record['path']).parts[0] not in ('target', 'artifacts', 'tmp')}
    bundled['SEALED-MANIFEST.json'] = {'bytes': (ROOT / 'SEALED-MANIFEST.json').stat().st_size, 'sha256': manifest_sha}
    archive_seen = set()
    with tarfile.open(ROOT / 'SOURCE-AND-RECEIPTS.tar.gz', 'r:gz') as archive:
        for member in archive:
            assert member.isfile() and member.name not in archive_seen
            archive_seen.add(member.name)
            expected = bundled[member.name]
            stream = archive.extractfile(member)
            digest = hashlib.sha256()
            for chunk in iter(lambda: stream.read(4 * 1024 * 1024), b''):
                digest.update(chunk)
            assert member.size == expected['bytes'] and digest.hexdigest() == expected['sha256']
    assert archive_seen == set(bundled) and len(archive_seen) == seal['archive_files_verified']
    frozen = inventory(FROZEN)
    final = inventory(ROOT / 'snapshot')
    assert len(frozen) == 1095 and digest_records(frozen) == EXPECTED_FROZEN
    assert len(final) == 1095 and digest_records(final) == EXPECTED_FINAL
    frozen_map = {record['path']: record for record in frozen}
    final_map = {record['path']: record for record in final}
    changed = [path for path in sorted(set(frozen_map) | set(final_map)) if frozen_map.get(path) != final_map.get(path)]
    assert changed == ['source/rust_verify/src/checked_normal_drop.rs', 'source/rustc_mir_build/src/builder/expr/as_temp.rs']
    assert sha(ROOT / 'target/debug/rust_verify') == EXPECTED_BINARY
    oracle_seal = json.loads((ORACLE / 'SEAL.json').read_text())
    assert sha(ORACLE / 'CONTENT-MANIFEST.json') == oracle_seal['manifest_sha256']
    oracle_manifest = json.loads((ORACLE / 'CONTENT-MANIFEST.json').read_text())
    for record in oracle_manifest['records']:
        path = ORACLE / record['path']
        assert path.stat().st_size == record['bytes'] and sha(path) == record['sha256']
    result = {'phase': phase, 'start_epoch_ns': start_ns, 'end_epoch_ns': time.time_ns(),
              'seal_sha256': sha(ROOT / 'SEAL.json'), 'manifest_sha256': manifest_sha,
              'payload_count': len(records), 'manifest_fingerprint': manifest['fingerprint'],
              'archive_sha256': archive_sha, 'archive_members_checked': len(archive_seen),
              'frozen_files': len(frozen), 'frozen_fingerprint': digest_records(frozen),
              'final_files': len(final), 'final_fingerprint': digest_records(final),
              'source_changed_paths': changed, 'binary_sha256': EXPECTED_BINARY,
              'oracle_seal_sha256': sha(ORACLE / 'SEAL.json'), 'oracle_payloads_checked': len(oracle_manifest['records']),
              'oracle_manifest_sha256': sha(ORACLE / 'CONTENT-MANIFEST.json'),
              'review_script_sha256': sha(__file__), 'python_executable': sys.executable,
              'python_sha256': sha(Path(sys.executable).resolve()), 'resources': resources(),
              'authentication_kind': 'Content consistency against user-pinned manifest/archive/source/binary digests; no cryptographic signature or producer trust asserted'}
    save_json('authentication-' + phase + '.json', result)
    print(json.dumps(result, sort_keys=True), flush=True)

if __name__ == '__main__':
    authenticate(sys.argv[1])
