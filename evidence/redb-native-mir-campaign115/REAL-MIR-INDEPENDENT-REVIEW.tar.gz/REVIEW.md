# Independent campaign115 review

## Bounded verdict

The authenticated checkpoint supports its **diagnostic-only** claims about real
elaborated MIR and the existing narrow scalar-owner subset. I found no added
admission, normalizer, owner-accounting, resource, or import/export semantics in
the frozen-to-final source delta. This is **not** an independent-oracle pass,
approval of the proposed mapping, native-resource correspondence, original-redb
verification, adoption, or permission for native-source integration.

All18 remain OPEN; native proof0; trust adoption0. No automatic follow-on.
The parent's freshly active goal state is the authoritative supplied observation;
the sealed worker's BLOCKED text is historical/stale, not a service reversal.
No goal tool was called and no service state was changed.

## Findings and objections

1. **Oracle acceptance remains unavailable.** Historical receipts have no actual
   epoch-ns launch/end boundaries or timestamped output-state observations.
   Neither ISO timestamp conversion nor the later byte index repairs that.
   I did not retrofit or evaluate those receipts. Fresh rechecks record real
   launcher clock samples and actual output observations, but there is still no
   independently registered expectation or approved modified-source mapping.
   The raw diagnostic stderr also contains Builder lines and TASK115_CAPTURE
   JSON with repeated refusal text, not merely the strict oracle's refusal
   envelope. No stream filtering, noise waiver, contract edit, or synthesized
   passing expectation was used. Fresh non-export runs request an out-directory,
   not the oracle's single registered output file; I have not misrepresented
   them as schema-complete receipt/output-state objects.

2. **`native_collection_completed:true` is not native-phase completion.** In
   `snapshot/source/rust_verify/src/infer_report.rs:121` it means only that the
   selected-function inventory is present. The inventory is populated in
   `verifier.rs:2867`, before preparation can fail. Anonymous, scoped, export,
   and feature-off failures still report this flag. The source's driver gate
   (`driver.rs:343`) and raw captures establish that the anonymous/scoped
   refusals stop before `begin_native`. Use actual `native_phase:true` records
   and the operation-check record, together with successful status and checked
   scope, for the positive controls. This ambiguity is inherited, not introduced
   by this patch, and is not evidence of an admission change.

3. **The named-binder success does not close the anonymous/native/resource gap.**
   The correction changes exactly fixture line20 from an anonymous constructor
   expression to `let corrected_owner = ...` at the same lexical scope. It
   selects the existing binder-supported route; it does not make anonymous
   provenance acceptable. The normalized native check compares supported
   straight-line `Program` operations, not all cleanup/unwind behavior, native
   resources, or raw local identities across phases. Verifier-phase matched
   local7/local11 versus native-phase local2 must not be read as identical
   compiler locals or globally unique destruction events.

4. **Scope and diagnostic-format limits remain real.** The new scope call-site
   logging path is source-audited but unreached in these fixtures; there is no
   retained `scope: Some` observation. A Remainder lifetime is not that record.
   Normal and cleanup drops can match the same retained local/origin. The bare
   native error in `driver.rs:159` still has no fixture/body source span. The
   proposed mapping must not turn that hypothetical unscoped native failure
   into an accepted refusal. No such native refusal was observed here.

5. **Failure accounting is qualified, not universally raw-complete.** The worker
   preserves all30 bounded receipt pairs, including the accidental initial
   missing-vstd setup failure. Its earlier inspection/patch failures are
   transcribed rather than separately captured raw, as disclosed in
   ENTRY-SETUP-NOTES.md. My own read-only search also named one nonexistent
   source path and exited2; see INSPECTION-ACCOUNTING.md. None is silently
   promoted to an expected compiler refusal. All five fresh verifier attempts,
   including all four nonzero exits, have exact raw streams and full receipts.

## Authentication and endpoint scope

Both entry and exit independently re-read all3920 manifest payloads, checked
sizes and SHA256, rejected path/set mismatches, verified the canonical manifest
records fingerprint, and streamed all2462 archive members without extraction.
There are no manifest symlink records. Endpoint reports are
`authentication-entry.json` and `authentication-exit.json`.

Pinned identities:

- SEAL.json SHA256: bcd1b0e18b3243508640ed25459e6bc475f9a3780c3f619e2f8f5b5d9142315d
- SEALED-MANIFEST.json: eaa4adc70825d3b43cfb3b55020c7d8bbee73f65241b3c5715b1c4bd8d89f920
- SOURCE-AND-RECEIPTS.tar.gz: 0d8beff0e8b6741cc3f30a3bf6efacba5666a37e5b945296590febe358a526b5
- Frozen114 fingerprint,1095 files: c9cb297436ab24053c254ed95bd4e520ef6fca5b86832d217b37302cb5ad7b23
- Final fingerprint,1095 files: a5ea05ccd4ecd04f5fc0fde6963cdfaaf7e29543a1c7def511a23e6d22f8ee81
- Final target/debug/rust_verify: 876136841ad6938783d06a4d6751b9bffd268cb04d4626c20cff90b79167a951

SEAL is a hash-binding document, not a signed producer attestation. Its supplied
manifest/archive digests authenticate the payloads; no signature or producer
trust is inferred. The archive contains2461 payloads plus the manifest and
deliberately excludes1459 compiled-output payloads, which were checked in place.

Exactly two source files differ from the independently inventoried frozen114
tree: `source/rust_verify/src/checked_normal_drop.rs` and
`source/rustc_mir_build/src/builder/expr/as_temp.rs`. An independently generated
unified diff equals source-diagnostic-only.patch byte-for-byte. All added blocks
are gated on VERUS_TASK115_DIAGNOSTICS equaling1 and only inspect/format/log.
Both environment value0 and unset controls historically succeed without these
diagnostic lines. Enabled diagnostics add locking/copy/format/I/O overhead;
this is not a claim of observationally identical stderr or timing.

The separate oracle manifest and all8 payloads are authenticated at both
endpoints, including cross-bindings from the sealed candidate. Its30 passing
tests are authenticated synthetic-test claims, not re-executed actual-MIR
validation. Proposed mapping SHA256 is
5a2a054df0fb874d5a853c2709bcc6402d1ce84f383fdf4ebabf185bf5d96795.
Its18 site fields agree with UnestablishedDropSite, its origin/scope field names
agree with the retained structs, and its two envelope strings agree with source.
This is a source-format audit only: mapping approval=false, oracle verdict=null.
The mapping describes the Debug refusal, not the surrounding new JSON protocol.

## Retention, phase, and controls

`checked_drop_origins.rs:58` and `checked_drop_origins.rs:74` return early when
capture is disabled. The newly added Builder prints occur after these calls,
whether they retained anything or not. The fresh feature-off run prints23
Builder lines but has zero elaborated capture records and zero native checks;
its postcondition fails. Those lines alone prove no retention.

By contrast, the enabled anonymous capture comes through the actual elaborated
query wrapper (`checked_normal_drop.rs:1044`). `TemporaryCapture.complete` is
set on completed Builder retention (`checked_drop_origins.rs:98`), and the
captured error/drop records are inserted into STATE (`checked_normal_drop.rs:585`).
The real anonymous body has binder CompleteWithoutLocalMatch observations2 and
temporary CompleteWithLocalMatches observations8/matches1. Its retained
e19/local7 joins the Builder constructor span at anonymous_temporary.rs:20:7,
and MIR bb3 drops that local with normal successor and Cleanup(bb5) unwind.
All these observations are native_phase=false. The retained destructor/glue
labels remain explicitly NOT_QUERIED/UNESTABLISHED; no resource identity is
inferred. The refusal prevents an anonymous native-phase capture.

The borrowed temporary has e19/local8, observations9/matches1, actual Remainder
lifetime, and scope:None. Both bb4 normal and bb6 cleanup sites refer to that same
retained origin. They are not two owners or unique destruction occurrences.

Historical named-owner and matched-binder positives each verify exactly two
selected Exec bodies with both real phases and expected2/seen2 operation checks.
The first named-owner attempt instead failed with nine E0433 missing-vstd
errors because `--cfg verus_no_vstd` was absent. The macro's cfg_no_vstd source
explains the correction. That attempt is setup failure, not an intended
provenance negative and not evidence of broken engine compilation.

Two authenticated historical engine builds exited0 with matching before/after
source inventories, exact Cargo build argv, and Finished-dev raw log markers:
90.941439917s and13.004181875s. Build01's reconstructed1095-file source equals
its original prebuild inventory; it is explicitly a reconstruction, not an
original-time copy. Its binary SHA256 is
154ab68a6598f23ee5b4fc2d40e60385cccba07442124b30a0d6bbb502d69e07.
The read-only cache last-use warning and two inherited dead-code warnings are
preserved. I ran neither build nor any compiler/Cargo test command.

The backend negative fails the deliberately incorrect20-versus19 postcondition;
the frontend missing-no_unwind control and unsupported std::fs::File control
fail before capture. The File error's suggested external_type_specification is
diagnostic advice, not an approved fallback; none was added. No fallback wording
was used as a success/provenance/native verdict. The strict result/scope fields
and actual error headers remain controlling.

## Five fresh selected rechecks

The existing final pinned engine and companion libraries ran in place, one
sequential worker, with no original-redb application execution. All attempt
commands, exact allowlisted environments, cwd, source fingerprint, source/tool
identities, launch/completion epoch-ns and monotonic samples, child status,
unchanged tool hashes, raw streams, and stream hashes are retained below this
review root. The launcher and parser sources are also retained and hashed.

- matched-binder: exit0,0.299577625s; exactly two checked Exec bodies; four
  captures including two native-phase records; expected2/seen2 comparison.
- anonymous-export: exit1,0.041124792s; actual e19/local7/observations8/matches1
  provenance refusal; no native-phase record/check; effect.vir absent before
  and after using true timestamped lstat observations.
- scoped-temporary: exit1,0.036595042s; repeated e19/local8 normal+cleanup
  observations and provenance refusal; no native phase/check.
- feature-off: exit1,0.083497250s; postcondition failure;23 Builder lines,
  zero capture/native-check records; no retention credited.
- named-export: exit1,0.036216167s at the existing explicit metadata export
  barrier; effect.vir absent before and after with real timestamped observations.

All direct children were reaped. All five owned process groups were also absent
at a separately timestamped later sample, not retroactively claimed absent at
the launch endpoint. No fresh timeout, signal, cancellation, spawn failure,
unexpected tool error, panic, or ICE was observed. No sixth verifier/diagnostic
invocation, oracle CLI, Cargo, compiler build/test, network, Git, subdelegate,
goal operation, parent edit, or candidate edit was performed.

Fresh clocks cannot repair historical clocks. The anonymous export attempt
stops at provenance refusal, so it alone does not exercise the export barrier;
the named export attempt does. Output absence is local engineering evidence,
not a signed ownership assertion or a passing oracle verdict.

## Precise checked-body scope

Historical named_owner.rs:8 and named_owner.rs:17 cover
`named_owner::Flush::drop` and `named_owner::named_owner`; matched_binder.rs:8
and matched_binder.rs:17 cover `matched_binder::Flush::drop` and
`matched_binder::anonymous_temporary`, including the fresh matched-binder run.
These are the local Flush destructor and scalar writeback caller ensuring19,
with `opens_invariants none` and `no_unwind`, not redb bodies. The historical
empty_control.rs:5 is one verified no-drop body. Diagnostic-off/unset controls
repeat the named-owner two-body scope.

Anonymous, scoped, frontend, native-resource and export refusals certify zero
checked Exec bodies in their reported failed full runs. Backend-negative and
feature-off report an individually verified body but no successful complete
selected scope and checked_exec_bodies0. Neither individual partial success nor
the selected-function inventory is silently upgraded to full-body certification.

The feature requires full verification, lifetime and erased EXEC checks and
refuses function/module filters, no_verify/no_lifetime/no_erasure_check,
non-vstd imports, Cargo metadata routes and infer_goals (`verifier.rs:2914`).
The existing effectful export refusal remains at verifier.rs:2935. Source-audit
of these guards is not a claim that every flag combination was re-executed.
Supported owner fields are only u64 and &mut u64; normalizer cleanup, branching,
loop, projected-destruction and other limits remain unchanged. No native File,
Arc/Mutex, cache reservation, redb lifecycle, final-cell or whole-crate theorem
was checked. Original-native-path FAILED and bootstrap correspondence
UNESTABLISHED remain inherited qualifications, not repaired results.

## Evidence and resources

`INDEPENDENT-FACTS.json` independently checks all30 historical receipt stream
bindings/source inventories and30 body stream byte offsets, the exact source
diff, the one-line binder change, reconstructed build01 inventory, mapping
field names, and every fresh receipt/stream. Fresh assertion checks all pass.
Authored scripts and this report use apply_patch only; even generated report
and raw-stream text persistence goes through apply_patch and is byte-checked.
No authored evidence was overwritten and no failed verifier attempt discarded.

Started November8,2026 at16:35:21Z, deadline16:50:21Z. Resource samples remain
strictly above16GiB free and below128MiB fresh scratch. The final handoff index
contains the finishing clock, resource sample and complete scratch file hashes.
This is sampled local accounting, not a guarantee about other concurrent work.
