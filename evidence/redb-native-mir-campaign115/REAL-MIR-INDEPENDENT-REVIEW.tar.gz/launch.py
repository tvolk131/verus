import datetime
import hashlib
import json
import os
from pathlib import Path
import shlex
import signal
import stat
import subprocess
import time

import review

ROOT = review.ROOT
OUT = review.OUT
ATTEMPTS = [
    ('matched-binder', 'matched-binder-final'),
    ('anonymous-export', 'anonymous-export-refusal'),
    ('scoped-temporary', 'scoped-temporary-final'),
    ('feature-off', 'named-feature-off'),
    ('named-export', 'named-export-refusal'),
]

def identity(path):
    path = Path(path)
    return {'path': str(path), 'resolved': str(path.resolve()), 'bytes': path.stat().st_size, 'sha256': review.sha(path)}

def observe(path):
    sampled_ns = time.time_ns()
    for parent in path.parents:
        if parent.is_symlink():
            raise RuntimeError('symlink parent: ' + str(parent))
    try:
        information = path.lstat()
    except FileNotFoundError:
        return {'kind': 'absent', 'sampled_ns': sampled_ns, 'size': None, 'sha256': None, 'mtime_ns': None, 'ctime_ns': None}
    if not stat.S_ISREG(information.st_mode):
        return {'kind': 'not_regular', 'sampled_ns': sampled_ns}
    with path.open('rb') as stream:
        opened = os.fstat(stream.fileno())
        digest = hashlib.sha256(stream.read()).hexdigest()
        finished = os.fstat(stream.fileno())
    assert information == opened == finished == path.lstat()
    return {'kind': 'regular_file', 'sampled_ns': sampled_ns, 'size': information.st_size, 'sha256': digest,
            'mtime_ns': information.st_mtime_ns, 'ctime_ns': information.st_ctime_ns,
            'device': information.st_dev, 'inode': information.st_ino}

def execute(name, historical_name):
    review.resources()
    assert time.time_ns() < 1794156621000000000
    directory = OUT / name
    review.save_text(name + '/tmp/.keep', '')
    review.save_text(name + '/output/.keep', '')
    historical = json.loads((ROOT / (historical_name + '.receipt.json')).read_text())
    argv = list(historical['argv'])
    argv[argv.index('--out-dir') + 1] = str(directory / 'output')
    requested_output = None
    if '--export' in argv:
        requested_output = directory / 'effect.vir'
        argv[argv.index('--export') + 1] = str(requested_output)
    environment = dict(historical['environment'])
    for key in ('CARGO_BUILD_BUILD_DIR', 'CARGO_TARGET_DIR'):
        environment[key] = str(directory / 'unused-cargo-target')
    environment['TMPDIR'] = str(directory / 'tmp')
    environment['PYTHONDONTWRITEBYTECODE'] = '1'
    bound_paths = [argv[0], ROOT / 'fixtures' / Path(argv[-1]).name,
                   ROOT / 'target/debug/libverus_builtin.rlib', ROOT / 'target/debug/libverus_builtin_macros.dylib',
                   environment['VERUS_Z3_PATH'], Path(__file__), Path(review.__file__)]
    platform = json.loads((ROOT / 'platform-support-identities.json').read_text())['records']
    bound_paths.extend(record['path'] for record in platform if record.get('exists') and record['path'].endswith('.dylib'))
    before_identities = [identity(path) for path in bound_paths]
    assert before_identities[0]['sha256'] == review.EXPECTED_BINARY
    for record in platform:
        if record.get('exists') and record['path'].endswith('.dylib'):
            assert review.sha(record['path']) == record['sha256']
    output_before = observe(requested_output) if requested_output else None
    launch = {'name': name, 'argv': argv, 'cwd': str(directory), 'environment': environment,
              'exact_shell_equivalent': 'cd ' + shlex.quote(str(directory)) + ' && env -i ' + ' '.join(shlex.quote(key + '=' + value) for key, value in sorted(environment.items())) + ' ' + shlex.join(argv),
              'identities_before': before_identities, 'requested_output_before': output_before,
              'limits': {'wall_seconds': 90, 'workers': 1, 'total_selected_invocations': 5},
              'source_fingerprint': review.EXPECTED_FINAL, 'resource_before': review.resources()}
    review.save_json(name + '/launch.json', launch)
    stdout = b''
    stderr = b''
    process = None
    spawn_error = None
    timed_out = False
    started_monotonic_ns = time.monotonic_ns()
    started_ns = time.time_ns()
    try:
        process = subprocess.Popen(argv, cwd=directory, env=environment, stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True)
        try:
            stdout, stderr = process.communicate(timeout=90)
        except subprocess.TimeoutExpired:
            timed_out = True
            os.killpg(process.pid, signal.SIGKILL)
            stdout, stderr = process.communicate()
    except OSError as error:
        spawn_error = repr(error)
    ended_ns = time.time_ns()
    ended_monotonic_ns = time.monotonic_ns()
    output_after = observe(requested_output) if requested_output else None
    code = process.returncode if process else None
    for stream_name, data in [('stdout', stdout), ('stderr', stderr)]:
        text = data.decode('utf-8')
        review.save_text(name + '/' + stream_name, text)
        assert (directory / stream_name).read_bytes() == data
    artifacts = []
    for path in sorted(directory.rglob('*')):
        if path.is_file() and path.name not in ('.keep', 'launch.json', 'stdout', 'stderr'):
            artifacts.append({'path': str(path), 'observation': observe(path)})
    receipt = {**launch, 'started_ns': started_ns, 'ended_ns': ended_ns,
               'started_monotonic_ns': started_monotonic_ns, 'ended_monotonic_ns': ended_monotonic_ns,
               'elapsed_seconds': (ended_monotonic_ns - started_monotonic_ns) / 1e9,
               'status': 'spawn_failure' if spawn_error else 'timeout' if timed_out else 'exited',
               'completed': process is not None and process.returncode is not None, 'reaped': process is not None and process.returncode is not None,
               'pid': process.pid if process else None, 'process_group': process.pid if process else None,
               'exit_code': code if code is not None and code >= 0 else None,
               'signal': -code if code is not None and code < 0 else None,
               'timed_out': timed_out, 'cancelled': False, 'spawn_error': spawn_error,
               'stdout_sha256': hashlib.sha256(stdout).hexdigest(), 'stdout_bytes': len(stdout),
               'stderr_sha256': hashlib.sha256(stderr).hexdigest(), 'stderr_bytes': len(stderr),
               'requested_output_after': output_after, 'artifacts_after': artifacts,
               'identities_after': [identity(path) for path in bound_paths],
               'resource_after': review.resources(),
               'oracle_verdict': None,
               'oracle_limit': 'No independently registered expectation or approved modified-source mapping. Non-export controls model --out-dir, not one requested output path. No contract waiver or synthetic epoch-ns retrofit.'}
    assert receipt['identities_before'] == receipt['identities_after']
    review.save_json(name + '/receipt.json', receipt)
    print(json.dumps({'name': name, 'status': receipt['status'], 'exit_code': receipt['exit_code'], 'elapsed_seconds': receipt['elapsed_seconds'], 'stdout_bytes': len(stdout), 'stderr_bytes': len(stderr), 'output_after': output_after}), flush=True)

if __name__ == '__main__':
    for attempt in ATTEMPTS:
        execute(*attempt)
