# Inspection and execution accounting

Review root: /private/tmp/campaign115-independent-review-20261108T163521Z.
No original application, compiler build, Cargo or test command was executed.
Five verifier invocations are completely retained in their per-attempt launch,
receipt, stdout and stderr files. All four nonzero verifier exits were retained
and distinguished by their real failure reason, not classified from exit alone.

One read-only search used a nonexistent verus_infer.rs path. The exact failed
shell command was:

```sh
printf '\n--- capture decline and lifecycle ---\n'; nl -ba /private/tmp/redb-native-mir115-20261108T160243Z/snapshot/source/rust_verify/src/checked_normal_drop.rs | sed -n '137,182p;530,610p'; printf '\n--- enabled phase calls ---\n'; rg -n -C 3 'checked_drop_origins::begin|begin_native|normal_drop::begin|native_collection_completed|falling back|fallback' /private/tmp/redb-native-mir115-20261108T160243Z/snapshot/source/rust_verify/src/{driver.rs,verifier.rs,verus_infer.rs,main.rs,checked_normal_drop.rs}
```

The shell exited2. The literal error was:

```text
rg: /private/tmp/redb-native-mir115-20261108T160243Z/snapshot/source/rust_verify/src/verus_infer.rs: No such file or directory (os error 2)
```

The tool transcript retains the command and displayed output; the broad stdout
display was truncated. It was not separately captured raw, and I do not claim
complete historical byte retention for that read-only inspection. Nothing was
modified and no failed compiler/verifier invocation was hidden. Later targeted
reads used the actual infer_report.rs source. Another broad stdout search
matched a large preflight metadata JSON line and was display-truncated with
exit0; it is not verifier failure or oracle evidence.

Main offline execution commands (all exited0):

```sh
PYTHONDONTWRITEBYTECODE=1 python3 /private/tmp/campaign115-independent-review-20261108T163521Z/review.py entry
PYTHONDONTWRITEBYTECODE=1 python3 /private/tmp/campaign115-independent-review-20261108T163521Z/launch.py
PYTHONDONTWRITEBYTECODE=1 python3 /private/tmp/campaign115-independent-review-20261108T163521Z/facts.py
PYTHONDONTWRITEBYTECODE=1 python3 /private/tmp/campaign115-independent-review-20261108T163521Z/review.py exit
```

The exact verifier argv/env/cwd and native status are recorded per attempt, not
inferred from these wrapper commands' exit0. The environment variable shown
here suppresses Python cache writes. The full inherited shell environment of
read-only inspection commands was not separately recorded; no universal shell
audit is claimed. Each verifier receives the complete explicitly recorded env
dictionary, not an unrecorded inherited shell environment. Source/fixture/tool
hashes are retained in receipts, endpoint authentication and the handoff index.
