import datetime
import json
from pathlib import Path
import time

import review

entry = json.loads((review.OUT / 'authentication-entry.json').read_text())
exit_auth = json.loads((review.OUT / 'authentication-exit.json').read_text())
for field in ('seal_sha256', 'manifest_sha256', 'payload_count', 'manifest_fingerprint', 'archive_sha256',
              'archive_members_checked', 'frozen_fingerprint', 'final_fingerprint', 'binary_sha256',
              'oracle_seal_sha256', 'oracle_manifest_sha256'):
    assert entry[field] == exit_auth[field]
facts = json.loads((review.OUT / 'INDEPENDENT-FACTS.json').read_text())
assert len(facts['fresh_invocations']) == 5
for attempt in facts['fresh_invocations'].values():
    receipt = attempt['receipt']
    assert entry['end_epoch_ns'] < receipt['started_ns'] <= receipt['ended_ns'] < exit_auth['start_epoch_ns']
    assert attempt['group_absent_at_later_sample']
assert not list(review.OUT.rglob('__pycache__'))
completed_ns = time.time_ns()
started_ns = 1794155721000000000
deadline_ns = 1794156621000000000
assert completed_ns < deadline_ns
index = {'version': 1, 'status': 'COMPLETE_INDEPENDENT_REVIEW_DIAGNOSTIC_ONLY',
         'started_utc': '2026-11-08T16:35:21Z',
         'completed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
         'completed_epoch_ns': completed_ns,
         'elapsed_seconds_from_first_clock': (completed_ns - started_ns) / 1e9,
         'deadline_utc': '2026-11-08T16:50:21Z',
         'endpoint_authentication_consistent': True, 'historical_receipts_checked': 30,
         'historical_body_offsets_checked': 30, 'fresh_verifier_invocations': 5,
         'fresh_invocations_sequential': True, 'max_fresh_wall_seconds': max(attempt['receipt']['elapsed_seconds'] for attempt in facts['fresh_invocations'].values()),
         'expected_fresh_nonzero_attempts': [name for name, attempt in facts['fresh_invocations'].items() if attempt['receipt']['exit_code'] != 0],
         'oracle_verdict': None, 'mapping_approved': False, 'historical_receipt_retrofit': False,
         'adoption': 0, 'native_proof': 0, 'trust_adoption': 0, 'all18': 'OPEN',
         'compiler_cargo_build_test_commands': 0, 'original_redb_executions': 0,
         'network_git_goal_operations': 0, 'subdelegation': 0,
         'parent_candidate_edits': 0, 'automatic_follow_on': False,
         'resources': review.resources(),
         'records': review.inventory(review.OUT),
         'index_self_excluded': True,
         'inspection_limit': 'One failed read-only source search and display-truncated broad reads are disclosed; not universally raw-captured shell inspections. All five verifier attempts have full exact command/env/status/raw-output bindings.'}
review.save_json('HANDOFF-INDEX.json', index)
print(json.dumps({'status': index['status'], 'completed_utc': index['completed_utc'],
                  'elapsed_seconds': index['elapsed_seconds_from_first_clock'],
                  'resources': review.resources(), 'payloads': len(index['records']),
                  'handoff_index_sha256': review.sha(review.OUT / 'HANDOFF-INDEX.json'),
                  'review_report_sha256': review.sha(review.OUT / 'REVIEW.md')}, sort_keys=True))
