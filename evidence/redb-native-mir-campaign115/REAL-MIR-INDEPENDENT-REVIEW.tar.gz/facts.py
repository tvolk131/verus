import difflib
import hashlib
import json
import os
from pathlib import Path
import re
import time
import traceback

import review

ROOT = review.ROOT
OUT = review.OUT

def json_file(path):
    return json.loads(path.read_text())

def captures(stderr):
    result = []
    for line in stderr.splitlines():
        if line.startswith('TASK115_CAPTURE '):
            observation = json.loads(line[len('TASK115_CAPTURE '):])
            assert type(observation['native_phase']) is bool
            assert observation['mir_phase'] == 'Runtime(PostCleanup)'
            result.append(observation)
    return result

def summarize(stdout, stderr):
    document = json.loads(stdout)
    observations = captures(stderr)
    return {'verification_results': document['verification-results'],
            'verification_scope': document['verus-infer']['verification_scope'],
            'infer_status': document['verus-infer']['status'],
            'compiler_metadata': document['verus'], 'captures': observations,
            'builder_line_count': sum(line.startswith('TASK115_BUILDER_') for line in stderr.splitlines()),
            'scope_builder_line_count': sum(line.startswith('TASK115_BUILDER_SCOPE ') for line in stderr.splitlines()),
            'native_checks': [json.loads(line[len('TASK115_NATIVE_CHECK '):]) for line in stderr.splitlines() if line.startswith('TASK115_NATIVE_CHECK ')],
            'primary_error_headers': [line for line in stderr.splitlines() if re.match(r'^error(?:\[[^\]]+\])?: ', line) and not line.startswith('error: aborting')],
            'panic_or_ice_markers': [marker for marker in ('internal compiler error', 'panicked at', 'query stack during panic') if marker in stderr.lower()]}

def main():
    results = json_file(ROOT / 'RESULTS.json')['records']
    result_map = {record['name']: record for record in results}
    historical = {}
    ledger = json_file(ROOT / 'COMMAND-LEDGER.json')
    assert len(ledger) == len(list(ROOT.glob('*.receipt.json'))) == 30
    for record in ledger:
        name = record['name']
        receipt_path = ROOT / (name + '.receipt.json')
        receipt = json_file(receipt_path)
        assert review.sha(receipt_path) == record['receipt_sha256']
        assert receipt['status'] == record['status'] == 'COMPLETED'
        assert receipt['child_exit_code'] == record['exit']
        for stream in ('stdout', 'stderr'):
            assert review.sha(ROOT / (name + '.' + stream)) == receipt[stream + '_sha256']
        source_before = json_file(ROOT / (name + '.source-before.json'))
        assert review.digest_records(source_before['records']) == source_before['fingerprint'] == receipt['source_digest'] == receipt['source_after_digest']
        item = {'receipt_sha256': review.sha(receipt_path), 'receipt': receipt}
        if name in result_map:
            item['raw_analysis'] = summarize((ROOT / (name + '.stdout')).read_text(), (ROOT / (name + '.stderr')).read_text())
            raw = item['raw_analysis']
            assert len(raw['captures']) == result_map[name]['capture_count']
            assert sum(capture['native_phase'] for capture in raw['captures']) == result_map[name]['native_capture_count']
        historical[name] = item
    indexed = 0
    bindings = json_file(ROOT / 'SCOPE-AND-STREAM-BINDINGS.json')
    for record in bindings['records']:
        name = record['attempt_name']
        assert record['launcher_receipt_sha256'] == review.sha(ROOT / (name + '.receipt.json'))
        stderr = (ROOT / (name + '.stderr')).read_bytes()
        assert len(stderr) == record['stderr_bytes'] and hashlib.sha256(stderr).hexdigest() == record['stderr_sha256']
        for observation in record['actual_body_observations']:
            line = stderr[observation['byte_offset']:observation['byte_offset'] + observation['byte_length']]
            assert hashlib.sha256(line).hexdigest() == observation['line_sha256']
            assert stderr.splitlines(keepends=True)[observation['stderr_line'] - 1] == line
            actual = json.loads(line[len(b'TASK115_CAPTURE '):])
            for key in ('definition', 'definition_hash', 'definition_span', 'native_phase', 'mir_phase'):
                assert actual[key] == observation[key]
            indexed += 1
        assert not any(record[key] for key in ('oracle_normalizable', 'started_epoch_ns_available', 'ended_epoch_ns_available', 'output_before_after_epoch_ns_available', 'atomic_compiler_epoch_claimed'))
    build01_records = review.inventory(ROOT / 'source-build01-reconstructed')
    assert build01_records == json_file(ROOT / 'build-engine-01.source-before.json')['records']
    assert review.digest_records(build01_records) == 'd0632f7e3044a8d70e50a07d0bc7abf1e39216aed4a93c62ef011dec5c699ff8'
    assert review.sha(ROOT / 'artifacts/rust_verify-build01') == '154ab68a6598f23ee5b4fc2d40e60385cccba07442124b30a0d6bbb502d69e07'
    generated_patch = ''
    for path in ('source/rust_verify/src/checked_normal_drop.rs', 'source/rustc_mir_build/src/builder/expr/as_temp.rs'):
        generated_patch += ''.join(difflib.unified_diff((review.FROZEN / path).read_text().splitlines(keepends=True), (ROOT / 'snapshot' / path).read_text().splitlines(keepends=True), fromfile='baseline/' + path, tofile='task115/' + path))
    assert generated_patch == (ROOT / 'source-diagnostic-only.patch').read_text()
    anonymous_lines = (ROOT / 'fixtures/anonymous_temporary.rs').read_text().splitlines()
    matched_lines = (ROOT / 'fixtures/matched_binder.rs').read_text().splitlines()
    fixture_changes = [{'line': index + 1, 'anonymous': before, 'matched': after} for index, (before, after) in enumerate(zip(anonymous_lines, matched_lines)) if before != after]
    assert len(anonymous_lines) == len(matched_lines) and len(fixture_changes) == 1 and fixture_changes[0]['line'] == 20
    mapping = json_file(ROOT / 'oracle-diagnostic-mapping.PROPOSED.json')
    source = (ROOT / 'snapshot/source/rust_verify/src/checked_normal_drop.rs').read_text()
    block = re.search(r'struct UnestablishedDropSite \{(.*?)\n\}', source, re.S).group(1)
    actual_site_fields = re.findall(r'^    ([a-z_]+):', block, re.M)
    assert set(actual_site_fields) == set(mapping['site_fields'].values()) and len(actual_site_fields) == 18
    assert mapping['source_fingerprint'] == review.EXPECTED_FINAL
    assert all(key == value for key, value in mapping['site_fields'].items())
    for record in json_file(ROOT / 'oracle-read-only-input-identities.json'):
        assert review.sha(record['path']) == record['sha256']
    fresh = {}
    for name in ('matched-binder', 'anonymous-export', 'scoped-temporary', 'feature-off', 'named-export'):
        directory = OUT / name
        receipt = json_file(directory / 'receipt.json')
        for stream in ('stdout', 'stderr'):
            path = directory / stream
            assert review.sha(path) == receipt[stream + '_sha256'] and path.stat().st_size == receipt[stream + '_bytes']
        assert receipt['status'] == 'exited' and receipt['completed'] and receipt['reaped'] and not receipt['timed_out']
        assert receipt['elapsed_seconds'] < 90 and receipt['started_ns'] <= receipt['ended_ns']
        assert receipt['signal'] is None and receipt['spawn_error'] is None
        assert receipt['identities_before'] == receipt['identities_after']
        if receipt['requested_output_before'] is not None:
            assert receipt['requested_output_before']['kind'] == receipt['requested_output_after']['kind'] == 'absent'
            assert receipt['requested_output_before']['sampled_ns'] <= receipt['started_ns'] <= receipt['ended_ns'] <= receipt['requested_output_after']['sampled_ns']
        group_sample_ns = time.time_ns()
        try:
            os.killpg(receipt['process_group'], 0)
        except ProcessLookupError:
            group_absent = True
        else:
            group_absent = False
        fresh[name] = {'receipt_sha256': review.sha(directory / 'receipt.json'), 'receipt': receipt,
                       'group_absence_sample_epoch_ns': group_sample_ns, 'group_absent_at_later_sample': group_absent,
                       'raw_analysis': summarize((directory / 'stdout').read_text(), (directory / 'stderr').read_text())}
    anonymous = fresh['anonymous-export']['raw_analysis']
    site = next(capture for capture in anonymous['captures'] if capture['definition'] == 'anonymous_temporary')['drop_sites'][0]
    assert site['local'] == 7 and site['block'] == 3 and site['temporary_status'] == 'CompleteWithLocalMatches { observations: 8, matches: 1 }'
    assert 'expression: e19, local: _7' in site['builder_origins'] and anonymous['native_checks'] == []
    assert all(not capture['native_phase'] for capture in anonymous['captures'])
    feature_off = fresh['feature-off']['raw_analysis']
    assert feature_off['captures'] == [] and feature_off['builder_line_count'] == 23
    matched = fresh['matched-binder']['raw_analysis']
    assert fresh['matched-binder']['receipt']['exit_code'] == 0 and matched['verification_scope']['checked_exec_bodies'] == 2
    assert len(matched['captures']) == 4 and sum(capture['native_phase'] for capture in matched['captures']) == 2
    assert len(matched['native_checks']) == 1 and matched['native_checks'][0]['expected_functions'] == matched['native_checks'][0]['seen_functions'] == 2
    scoped = fresh['scoped-temporary']['raw_analysis']
    scoped_sites = next(capture for capture in scoped['captures'] if capture['definition'] == 'scoped_temporary')['drop_sites']
    assert [(site['block'], site['local'], site['cleanup']) for site in scoped_sites] == [(4, 8, False), (6, 8, True)]
    assert scoped_sites[0]['builder_origins'] == scoped_sites[1]['builder_origins']
    assert all(item['raw_analysis']['scope_builder_line_count'] == 0 for item in fresh.values())
    for name in ('named-diagnostics-off', 'named-diagnostics-unset'):
        assert historical[name]['raw_analysis']['captures'] == [] and historical[name]['raw_analysis']['builder_line_count'] == 0
    result = {'historical_receipts_checked': len(historical), 'historical_body_stream_offsets_checked': indexed,
              'historical': historical, 'fresh_invocations': fresh, 'fixture_binder_change': fixture_changes,
              'source_patch_exact': True, 'mapping_source_format_fields_match': True,
              'mapping_sha256': review.sha(ROOT / 'oracle-diagnostic-mapping.PROPOSED.json'),
              'mapping_approved': False, 'independent_oracle_verdict': None,
              'oracle_30_tests': 'Authenticated handoff reports 30 passing synthetic tests; not rerun and not real-MIR validation',
              'scope_limit': 'Scalar u64/&mut u64 straight-line checked-owner fixtures only, never original redb execution or a native-resource theorem',
              'all18': 'OPEN', 'native_proof': 0, 'trust_adoption': 0,
              'review_tools': [identity for identity in (fresh['matched-binder']['receipt']['identities_before']) if identity['path'].startswith(str(OUT))],
              'facts_script_sha256': review.sha(__file__), 'resource_sample': review.resources()}
    review.save_json('INDEPENDENT-FACTS.json', result)
    print(json.dumps({'historical_receipts_checked': len(historical), 'historical_body_stream_offsets_checked': indexed, 'fresh_invocations_checked': len(fresh), 'mapping_approved': False, 'oracle_verdict': None, 'resources': review.resources()}, sort_keys=True))

if __name__ == '__main__':
    try:
        main()
    except BaseException:
        failure = traceback.format_exc()
        review.save_text('facts-failed-attempt.txt', failure)
        raise
