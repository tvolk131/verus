#![feature(rustc_private)]

extern crate rustc_data_structures;
extern crate rustc_driver;
extern crate rustc_hir;
extern crate rustc_interface;
extern crate rustc_middle;

use rustc_hir::def_id::LocalDefId;
use rustc_middle::mir::{Body, TerminatorKind};
use rustc_middle::thir::ExprId;
use rustc_middle::ty::TyCtxt;
use rustc_mir_build_verus::builder::checked_drop_origins;
use serde_json::{Value, json};
use std::fs::OpenOptions;
use std::io::Write;
use std::path::PathBuf;
use std::sync::Mutex;

struct State {
    definition: String,
    captures: Vec<Value>,
    selected: Vec<String>,
    named_candidates: Vec<Value>,
    after_analysis: bool,
    elaboration_queries_total: usize,
    body_owners_total: usize,
    explicit_selected_queries: usize,
}

static STATE: Mutex<Option<State>> = Mutex::new(None);

fn scope_state(
    capture: Option<&checked_drop_origins::ThirScopeCapture>,
    session: Option<checked_drop_origins::ThirScopeSession>,
    body: LocalDefId,
    edge_count: usize,
) -> &'static str {
    match capture {
        None => "MISSING",
        Some(capture) if Some(capture.session) != session || capture.body != body => "KEY_MISMATCH",
        Some(capture) if !capture.complete => "INCOMPLETE",
        Some(_) if edge_count == 0 => "COMPLETE_EMPTY",
        Some(_) => "COMPLETE_NONEMPTY",
    }
}

fn scope_edge(edge: &checked_drop_origins::ThirScopeEdge) -> Value {
    json!({
        "scope_expression": format!("{:?}", edge.scope_expression),
        "value_expression": format!("{:?}", edge.value_expression),
        "hir_id": format!("{:?}", edge.hir_id),
        "region_scope": format!("{:?}", edge.region_scope),
    })
}

fn matching_scope_edges(
    capture: Option<&checked_drop_origins::ThirScopeCapture>,
    session: Option<checked_drop_origins::ThirScopeSession>,
    body: LocalDefId,
    expression: ExprId,
) -> Value {
    let matching = capture.filter(|capture| {
        Some(capture.session) == session && capture.body == body
    }).map(|capture| capture.edges.iter()
        .filter(|edge| edge.value_expression == expression)
        .map(scope_edge).collect::<Vec<_>>());
    json!({
        "relation": "scope.value_expression == temporary.expression",
        "temporary_expression": format!("{expression:?}"),
        "capture_status": scope_state(capture, session, body, capture.map_or(0, |capture| capture.edges.len())),
        "matching_status": scope_state(capture, session, body, matching.as_ref().map_or(0, Vec::len)),
        "expected_session_generation": session.map(|session| session.generation),
        "expected_body": format!("{body:?}"),
        "expected_native_capture_phase": session.map(|session| session.native),
        "session_generation": capture.map(|capture| capture.session.generation),
        "body": capture.map(|capture| format!("{:?}", capture.body)),
        "native_capture_phase": capture.map(|capture| capture.session.native),
        "edges": matching,
        "reachability_uniqueness_ownership": "NOT_ESTABLISHED",
        "hir_vir_mapping_approved": false,
    })
}

fn selected(tcx: TyCtxt<'_>, def: LocalDefId) -> bool {
    let state = STATE.lock().unwrap();
    tcx.opt_item_name(def.to_def_id()).is_some()
        && tcx.def_path_str(def.to_def_id()) == state.as_ref().unwrap().definition
}

fn observe<'tcx>(tcx: TyCtxt<'tcx>, def: LocalDefId, body: &Body<'tcx>) {
    if !selected(tcx, def) {
        return;
    }
    let bindings = checked_drop_origins::get(def);
    let temporaries = checked_drop_origins::get_temporaries(def);
    let scope_session = checked_drop_origins::thir_scope_session();
    let scopes = checked_drop_origins::get_thir_scopes(def);
    let mut drops = Vec::new();
    for (block, data) in body.basic_blocks.iter_enumerated() {
        let TerminatorKind::Drop { place, target, unwind, replace, drop } =
            &data.terminator().kind else {
                continue;
            };
        let origins = temporaries.as_ref().map(|capture| {
            capture.origins.iter().filter(|origin| origin.local == place.local)
                .map(|origin| json!({
                    "expression": format!("{:?}", origin.expression),
                    "local": origin.local.as_usize(),
                    "temp_lifetime": format!("{:?}", origin.temp_lifetime),
                    "exact_thir_scope_edges_with_value_equal_to_expression": matching_scope_edges(
                        scopes.as_ref(), scope_session, def, origin.expression,
                    ),
                    "scope": origin.scope.as_ref().map(|scope| json!({
                        "hir_id": format!("{:?}", scope.hir_id),
                        "nested_expression": format!("{:?}", scope.nested_expression),
                        "region_scope": format!("{:?}", scope.region_scope),
                    })),
                })).collect::<Vec<_>>()
        });
        drops.push(json!({
            "block": block.as_usize(),
            "cleanup": data.is_cleanup,
            "local": place.local.as_usize(),
            "place": format!("{place:?}"),
            "projection": format!("{:?}", place.projection),
            "root_type": body.local_decls[place.local].ty.to_string(),
            "binder_capture_present": bindings.is_some(),
            "binder_matches": bindings.as_ref().map(|bindings| bindings.iter()
                .filter(|(_, local)| *local == place.local).count()),
            "temporary_capture_present": temporaries.is_some(),
            "temporary_capture_complete": temporaries.as_ref().map(|capture| capture.complete),
            "temporary_observations_total": temporaries.as_ref().map(|capture| capture.origins.len()),
            "matching_temporary_observations": origins,
            "normal_target": target.as_usize(),
            "replace_assignment_origin": replace,
            "async_cancellation_cleanup_target": drop.map(|target| target.as_usize()),
            "unwind": format!("{unwind:?}"),
            "destructor_identity": "NOT_QUERIED",
            "drop_glue_identity": "NOT_QUERIED",
            "resource_effects": "NOT_CHECKED",
            "unique_occurrence": "NOT_ESTABLISHED",
        }));
    }
    let locals = body.local_decls.iter_enumerated().map(|(local, declaration)| json!({
        "local": local.as_usize(),
        "type": declaration.ty.to_string(),
        "span": format!("{:?}", declaration.source_info.span),
    })).collect::<Vec<_>>();
    let calls = body.basic_blocks.iter_enumerated().filter_map(|(block, data)| {
        let TerminatorKind::Call { func, .. } = &data.terminator().kind else {
            return None;
        };
        let function_type = func.ty(&body.local_decls, tcx);
        let callee = match *function_type.kind() {
            rustc_middle::ty::FnDef(callee, _) => Some(tcx.def_path_str(callee)),
            _ => None,
        };
        Some(json!({
            "block": block.as_usize(),
            "cleanup": data.is_cleanup,
            "callee_definition": callee,
            "function_type": function_type.to_string(),
            "terminator": format!("{:?}", data.terminator()),
            "source_span": format!("{:?}", data.terminator().source_info.span),
            "resource_correspondence": "NOT_ESTABLISHED",
        }))
    }).collect::<Vec<_>>();
    let typed_temporaries = temporaries.as_ref().map(|capture| capture.origins.iter().map(|origin| json!({
        "local": origin.local.as_usize(),
        "type": body.local_decls[origin.local].ty.to_string(),
        "origin": format!("{origin:?}"),
        "expression": format!("{:?}", origin.expression),
        "exact_thir_scope_edges_with_value_equal_to_expression": matching_scope_edges(
            scopes.as_ref(), scope_session, def, origin.expression,
        ),
    })).collect::<Vec<_>>());
    let entry = json!({
        "def_path": tcx.def_path_str(def.to_def_id()),
        "def_path_hash": format!("{:?}", tcx.def_path_hash(def.to_def_id())),
        "definition_span": format!("{:?}", tcx.def_span(def)),
        "mir_phase": format!("{:?}", body.phase),
        "native_capture_phase": checked_drop_origins::native(),
        "binder_capture_present": bindings.is_some(),
        "temporary_capture_present": temporaries.is_some(),
        "temporary_capture_complete": temporaries.as_ref().map(|capture| capture.complete),
        "thir_scope_capture": {
            "status": scope_state(scopes.as_ref(), scope_session, def, scopes.as_ref().map_or(0, |capture| capture.edges.len())),
            "capture_present": scopes.is_some(),
            "complete": scopes.as_ref().map(|capture| capture.complete),
            "edge_count": scopes.as_ref().map(|capture| capture.edges.len()),
            "observer_process_id": std::process::id(),
            "current_session_generation": scope_session.map(|session| session.generation),
            "current_session_native_phase": scope_session.map(|session| session.native),
            "capture_session_generation": scopes.as_ref().map(|capture| capture.session.generation),
            "capture_native_phase": scopes.as_ref().map(|capture| capture.session.native),
            "expected_body": format!("{def:?}"),
            "capture_body": scopes.as_ref().map(|capture| format!("{:?}", capture.body)),
            "body_def_path_hash": format!("{:?}", tcx.def_path_hash(def.to_def_id())),
            "observed_mir_phase": format!("{:?}", body.phase),
            "capture_site": "BUILDER_FINISH_RETAIN_THIR_ARENA",
            "expression_count": scopes.as_ref().and_then(|capture| capture.expression_count),
            "all_raw_scope_edges": scopes.as_ref().map(|capture| capture.edges.iter().map(scope_edge).collect::<Vec<_>>()),
            "reachability_uniqueness_ownership": "NOT_ESTABLISHED",
            "hir_vir_mapping_approved": false,
        },
        "locals": locals,
        "drops": drops,
        "calls": calls,
        "raw_elaborated_body_debug": format!("{body:#?}"),
        "raw_builder_bindings_debug": format!("{bindings:#?}"),
        "raw_builder_temporary_capture_debug": format!("{temporaries:#?}"),
        "all_typed_builder_temporary_observations": typed_temporaries,
        "native_resource_correspondence": false,
    });
    STATE.lock().unwrap().as_mut().unwrap().captures.push(entry);
}

fn elaborated<'tcx>(tcx: TyCtxt<'tcx>, def: LocalDefId)
    -> &'tcx rustc_data_structures::steal::Steal<Body<'tcx>>
{
    STATE.lock().unwrap().as_mut().unwrap().elaboration_queries_total += 1;
    let result = (rustc_interface::DEFAULT_QUERY_PROVIDERS.queries.mir_drops_elaborated_and_const_checked)(tcx, def);
    observe(tcx, def, &result.borrow());
    result
}

struct Callbacks;

impl rustc_driver::Callbacks for Callbacks {
    fn config(&mut self, config: &mut rustc_interface::interface::Config) {
        config.override_queries = Some(|_session, providers| {
            providers.hooks.build_mir_inner_impl = rustc_mir_build_verus::builder::build_mir_inner_impl;
            providers.queries.mir_drops_elaborated_and_const_checked = elaborated;
        });
    }

    fn after_analysis<'tcx>(&mut self, _compiler: &rustc_interface::interface::Compiler,
                            tcx: TyCtxt<'tcx>) -> rustc_driver::Compilation {
        let targets = tcx.hir_body_owners().filter(|def| selected(tcx, *def)).collect::<Vec<_>>();
        {
            let mut state = STATE.lock().unwrap();
            let state = state.as_mut().unwrap();
            let name = state.definition.rsplit("::").next().unwrap();
            state.named_candidates = tcx.hir_body_owners().filter(|def| {
                tcx.opt_item_name(def.to_def_id()).is_some_and(|candidate| candidate.as_str() == name)
            }).map(|def| json!({
                "def_path": tcx.def_path_str(def.to_def_id()),
                "definition_span": format!("{:?}", tcx.def_span(def)),
            })).collect();
            state.selected = targets.iter().map(|def| tcx.def_path_str(def.to_def_id())).collect();
            state.after_analysis = true;
            state.body_owners_total = tcx.hir_body_owners().count();
            state.explicit_selected_queries = usize::from(targets.len() == 1);
        }
        if targets.len() == 1 {
            let _ = tcx.mir_drops_elaborated_and_const_checked(targets[0]);
        }
        rustc_driver::Compilation::Stop
    }
}

fn main() {
    let arguments = std::env::args().skip(1).collect::<Vec<_>>();
    if arguments.len() != 10 || arguments[0] != "--report" || arguments[2] != "--definition"
        || arguments[4] != "--crate-source" || arguments[6] != "--libc"
        || arguments[8] != "--sysroot" || !arguments[3].contains("::") {
        eprintln!("usage: observer --report NEW.json --definition EXACT_DEF_PATH --crate-source LIB.rs --libc LIB.rmeta --sysroot ROOT");
        std::process::exit(64);
    }
    let destination = PathBuf::from(&arguments[1]);
    if !destination.is_absolute() || destination.extension().is_none_or(|extension| extension != "json") {
        eprintln!("diagnostic requires an absolute JSON report destination");
        std::process::exit(64);
    }
    match destination.symlink_metadata() {
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => {},
        _ => {
            eprintln!("diagnostic report destination must not exist");
            std::process::exit(64);
        },
    }
    let Some(parent) = destination.parent() else { std::process::exit(64) };
    if parent.canonicalize().ok().as_deref() != Some(parent) {
        eprintln!("diagnostic requires a canonical report parent");
        std::process::exit(64);
    }
    let source = PathBuf::from(&arguments[5]);
    let libc = PathBuf::from(&arguments[7]);
    let sysroot = PathBuf::from(&arguments[9]);
    if !source.is_absolute() || !source.is_file() || !libc.is_absolute() || !libc.is_file()
        || !sysroot.is_absolute() || !sysroot.is_dir() {
        eprintln!("diagnostic requires existing absolute source, libc metadata and sysroot inputs");
        std::process::exit(64);
    }
    let staging = parent.join(format!(".{}.observer-stage-{}", destination.file_name().unwrap().to_string_lossy(), std::process::id()));
    let mut output = match OpenOptions::new().write(true).create_new(true).open(&staging) {
        Ok(output) => output,
        Err(error) => {
            eprintln!("diagnostic staging reservation failed: {error}");
            std::process::exit(64);
        }
    };
    *STATE.lock().unwrap() = Some(State {
        definition: arguments[3].clone(), captures: Vec::new(), selected: Vec::new(),
        named_candidates: Vec::new(),
        after_analysis: false,
        elaboration_queries_total: 0, body_owners_total: 0, explicit_selected_queries: 0,
    });
    checked_drop_origins::begin(true);
    let rustc_arguments = vec![
        "redb-native-mir-observer".to_string(), "--crate-name".to_string(), "redb".to_string(),
        "--crate-type".to_string(), "lib".to_string(), "--edition=2024".to_string(),
        "--emit=metadata".to_string(), "--cfg".to_string(), "feature=\"default\"".to_string(),
        "-Cdebuginfo=0".to_string(),
        "--cfg".to_string(), "feature=\"std\"".to_string(), "--sysroot".to_string(),
        sysroot.to_string_lossy().into_owned(), "--extern".to_string(),
        format!("libc={}", libc.display()), "-L".to_string(),
        format!("dependency={}", libc.parent().unwrap().display()),
        source.to_string_lossy().into_owned(),
    ];
    let compiler_result = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
        rustc_driver::run_compiler(&rustc_arguments, &mut Callbacks);
    }));
    let compiler_completed = compiler_result.is_ok();
    let state = STATE.lock().unwrap().take().unwrap();
    let observed = compiler_completed && state.after_analysis && state.selected.len() == 1
        && state.captures.len() == 1;
    let value = json!({
        "schema": "redb.native-mir-observer.diagnostic-only",
        "schema_version": 2,
        "compiler_completed_without_panic": compiler_completed,
        "after_analysis_reached": state.after_analysis,
        "target_definition": state.definition,
        "selected_definitions": state.selected,
        "same_name_definitions_discovered": state.named_candidates,
        "same_name_discovery_does_not_establish_query_history": true,
        "captures": state.captures,
        "elaboration_provider_invocations_total": state.elaboration_queries_total,
        "whole_crate_hir_body_owners_enumerated": state.body_owners_total,
        "explicit_selected_query_requests": state.explicit_selected_queries,
        "native_checked_proof_bodies": 0,
        "compiler_argv": rustc_arguments,
        "compiler_argument_profile": "FIXED_REDB_DEFAULT_STD_METADATA_NO_USER_COMPILER_FLAGS",
        "report_staging_path_retained": staging,
        "explicit_query_requires_unique_exact_definition": true,
        "elaboration_query_forced_if_not_already_cached": true,
        "exactly_one_definition_observed": observed,
        "classification": if !compiler_completed {
            "COMPILER_DID_NOT_COMPLETE_RAW_EVIDENCE_ONLY"
        } else if !observed {
            "TARGET_NOT_UNIQUELY_OBSERVED"
        } else {
            "RAW_MIR_CAPTURE_NOT_NATIVE_PROOF"
        },
        "proof_acceptance": false,
        "native_resource_correspondence": false,
        "native_proof_credit": 0,
        "resource_credit": 0,
        "trust_credit": 0,
        "all18": "OPEN",
        "resource_semantics_checked": false,
        "interface_exported": false,
        "code_generation_requested_by_observer": false,
    });
    let published = serde_json::to_vec_pretty(&value).and_then(|bytes| {
        output.write_all(&bytes).map_err(serde_json::Error::io)
    }).is_ok() && output.flush().is_ok() && output.sync_all().is_ok()
        && std::fs::hard_link(&staging, &destination).is_ok();
    if !published || !compiler_completed {
        std::process::exit(70);
    }
    if !observed {
        std::process::exit(65);
    }
    eprintln!("native proof refused; raw MIR diagnostic retained");
    std::process::exit(2);
}
