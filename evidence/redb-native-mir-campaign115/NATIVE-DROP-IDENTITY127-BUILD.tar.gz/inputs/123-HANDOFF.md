# candidate123: sealed SOURCE-ONLY diagnostic observer

## Decision and limits

Implementation only; **UNBUILT / UNEXECUTED / UNREVIEWED BY COMPILER**. No compiler,
Cargo, rustfmt, verifier, tests, diagnostics, native execution, network, Git,
integration, cleanup, or subdelegation occurred. Task122 was not inspected or
polled; it retains the sole execution slot. All18 OPEN; native/resource/trust
credit0. No mapping, ownership, reachability, dynamic uniqueness, drop-order,
effects, Arc/Mutex/cache correspondence, admission or primitive-law conclusion.
Worker116 remains interrupted at 2026-11-08T17:02:52.937Z, without its final
worker seal/report. No historical allowance or status is reset.

## Deliverables and authentication

- `source/main.rs` is the complete baseline-derived observer.
- `source/identity.rs` is its new standalone diagnostic-only companion module.
- `candidate123-baseline.patch` is the generated minimal baseline-relative diff;
  it includes the entire new module. No parent/frozen/native source is edited.
- `INPUTS.json` inventories exact selected inputs and authoritative API files.
- `MANIFEST.json` and `SEAL.json` inventory/pin this handoff after final readback.
- `versions/v001/source` preserves the initial unexecuted authored version. It
  is NOT the handoff candidate: its provisional status fields and fixed resolver
  count were corrected, its first-match raw-context lookup replaced by a retained
  exact-cardinality array, and sidecar freshness rechecked before query startup.
  No build failure or runtime outcome exists to preserve; none is invented.

Parent main SHA256:
`2f5b92ba4be0f14a654034d5c943b407d7e0749697945de59c66bbbd9e70093a`.
Parent manifest SHA256:
`18e3567fb7660e704500b75f0b6a493a49ea38c63a31c9605947a571967ff3b7`.
Audit121 manifest SHA256:
`ca437d9a212f6ec63cd2cf7ebb5c5f5c47642d1edf61f75db25ffb520f9ae565`.
The full REPORT.md and DECISION.json were read in bounded chunks, including
previously truncated passages; both match that manifest. Selected audit exit
records and independent116 REVIEW.md/header report match their authenticated
manifests. Independent116 manifest SHA256:
`6579eda1d8ba02be33bee1954aca7f19fb313dd78085ff27b1126717a31d9197`.
Helper120 remains unchanged, SHA256:
`1aa55b6d95997e1950cc548119ae6b9b83ff3c69af98c36f0790cff895c0ca79`.
Original native source pin supplied by parent:
`c82ab865bb362bc4af067d332adc44978ff64813`; no Git verification is claimed.
The audit and this handoff observe **no actual resolved Instance**.

Final main SHA256:
`b03b2bc43440a36bd87280d8f38139fe8f4ec71f05f6f126e6d1840a4f9c7830`.
Final identity module SHA256:
`a2c81a5e084bbeca67c390c69ce0a4b84b607e52c1b408457ebe2dd7e9718d7f`.
Final patch SHA256:
`1236a2eee14d3de7df8f358442160088d3658ea4f55b7d07092347fef8e0b6c1`.

## Exact option grammar and lifecycle

Old mode accepts precisely the existing five ordered flag/value pairs. New mode
adds exactly `--raw-before-query /ABS/NEW.json --identity-sidecar /ABS/OTHER.json`
in that order. No arbitrary compiler flags, linking controls, response files,
test-injection options or alternate query-owner selectors are added. The started
record is deterministically derived as `OTHER.started.json`. Every optional final
and staging path must be fresh and distinct from every report/optional path;
parents must already exist and be canonical, excluding symlinked parents.

Under the existing Steal borrow, only owned context and same-session LocalDefId /
ADT DefId / checked-empty-args tokens are retained. No Ty, Body, guard, unsafe,
transmute or cross-session token loader is introduced. All raw drops are retained.
The selector requires exactly two drops, local20/e78, empty projection, native
Runtime(PostCleanup), the authenticated owner hash/source, matching complete scope
session/body capture, bb16 normal->bb17/unwind Cleanup(bb20), and bb19 cleanup->bb20/
unwind Terminate(InCleanup). Extra/partial/mismatched records remain explicit.

After the selected explicit provider returns, the callback releases MIR and state
guards, serializes the complete raw capture and explicit refusal with outcome
PENDING, flushes/fsyncs a create-new staging file, hard-links no-clobber, syncs the
parent directory and reads back exact bytes. Any failure refuses optional queries.
Staging and failure artifacts are retained; no reuse or cleanup is attempted.
Next it durably publishes STARTED_INCOMPLETE before optional identity API calls.
The started record binds the raw/refusal snapshot by its **entire exact UTF-8
contents and byte length**, not by an invented runtime cryptographic digest.
This is an explicit implementation choice relative to audit121's suggested digest
binding; handoff files themselves have SHA256 authentication. Missing final sidecar
after a started record means incomplete, never success or clean absence.

Only then, in the same live tcx, source-owned ADT metadata and zero generic count
are checked, the empty-args ADT reconstructed, unresolved/alias/error/binder/region
states rejected, and TypingEnv::post_analysis uses the captured ORIGINAL OWNER.
Optional DropGlue lang-item lookup precedes at most one Instance::try_resolve;
actual kind (full Debug), args, Some(T)/None payload and equality checks are recorded.
Actual adt.destructor definition is checked against original cached_file.rs:41,
its impl at :40, associated-method kind, and exact nongeneric impl Self type. No
destructor Instance query or MIR/shim/codegen/execution request is added. The same
actual result record attaches to BOTH separately retained CFG contexts; no unique
event or independently repeated site resolution is claimed.

## Design/status/control matrix (all controls UNEXECUTED)

| Dimension/control | Required/implemented source behavior |
|---|---|
| Old five-pair mode | Existing argv, selection/cardinality, final report and refusal remain unchanged; no optional keys/files. |
| Exact header | Exact typed tokens and both CFG contexts; raw/refusal durable first, then same-tcx identity query. |
| Wrong/ambiguous owner | Explicit refusal; no optional identity lookup or alternate-body request. |
| Wrong type/local/projection/site/phase/origin | Explicit mismatch/partial/extra status; no optional resolver. |
| Generic/scalar outside selector | Unsupported/mismatched typed capture; never widened to a control resolver. |
| Seeded/symlinked/aliased report/raw/start/sidecar/staging | Preflight refusal; no clobber; no stale stage reuse. |
| Extra/link/response arguments | Exact grammar refusal before compiler invocation. |
| Raw/start write, flush, sync, link or readback failure | Optional queries refused; partial files retained, I/O failure explicit. |
| Lang item missing | MISSING_DROP_GLUE_LANG_ITEM, not resolver None or empty glue. |
| Resolver Ok(Some) | Actual full kind/args and payload retained; expected-target equality checked. |
| Empty DropGlue payload | RESOLVED_EMPTY_GLUE; expected WritablePage identity does NOT match. |
| Resolver Ok(None) / Err | UNRESOLVED_OR_LIMITED / QUERY_ERROR are distinct. |
| Destructor None | MISSING_EXPECTED_DESTRUCTOR_COMPILER_PENDING or ERROR_TAINTED_INCOMPLETE; never target success. |
| Panic after durable gate | QUERY_PANIC, partial state and sidecar attempted; panic rethrown to outer compiler catch. |
| Abort/kill/fatal preventing sidecar | Immutable raw/refusal plus started record survive if gate succeeded; incomplete remains incomplete. |
| Both native sites | Equal typed ADT tokens required; shared actual result attached twice, distinct contexts retained. |
| Compiler completion | Immutable callback outputs remain PENDING; main records actual run_compiler return/panic only after return. |
| Errors/finality | Emitted errors and delayed bugs separately sampled; no post-tcx clean-error-finality or absence claim. |

## UNEXECUTED build/runtime plan and risks

1. Parent source review first. After task122 explicitly releases its slot, schedule
   a DISTINCT bounded build of these two final source files with the unchanged,
   authenticated helper120 and pinned installed compiler APIs. Reuse the parent's
   pinned dependency recipe; no new package/dependency or Cargo manifest is supplied.
2. Do not run rustfmt, type-check, compile, verifier, tests or the observer in this
   task. Initial build may expose API/type/borrow/visibility/warning issues: pinned
   LangItem path, Ty constructors, GenericArgs equality, impl_of_assoc/type_of,
   source span formatting and metadata availability were source-inspected only.
   Record a new version and preserve every failed build before corrections.
3. Run unchanged-old-mode and exact-header controls with separately fresh paths,
   source/toolchain/input hashes and externally captured compiler termination.
   Inspect two distinct contexts and actual identity equality, not expected shapes.
4. Independently run wrong owner/type/site, generic/scalar, seeded/aliased/symlinked
   path and extra/link/response-argument controls. Use separately registered control
   fixtures or source copies; do not modify frozen/original input sources or broaden
   the candidate's exact selector to manufacture coverage.
5. Test durable-gate failures separately. A source-instrumented CLONE may inject a
   panic only AFTER raw/start publication; label it SYNTHETIC in external receipts,
   preserve its altered source hash, and never call it a real compiler query error.
   Separately retain any genuinely reproduced Instance resolver Err/panic/abort
   from the uninstrumented pinned candidate and identify its actual compiler error.
   If no real query-failure reproducer is available, mark that control UNEXECUTED;
   an injected panic or process kill is not a real resolver failure.
6. No complete transitive compiler query closure is proven. Directory fsync may
   reject the platform/filesystem, causing intentional query refusal. Caller-owned
   output directories are assumed not to be concurrently renamed/replaced by an
   adversary; std-only canonicalization/path checks do not provide openat-style
   hostile-filesystem confinement. A concurrent final sidecar collision after the
   durable-start preflight may still prevent final publication; raw/start remain.
   Files are immutable by observer policy/no-clobber publication, not OS write-once.
7. Sidecar snapshots deliberately remain compiler-PENDING and cannot independently
   certify final compiler outcome. The normal final main report or an external
   termination receipt is required. No semantic or proof status is promoted.

This task stops at the sealed source-only handoff. Parent review/build is future
work; it is not authorized to overlap task122 and is not executed here.
