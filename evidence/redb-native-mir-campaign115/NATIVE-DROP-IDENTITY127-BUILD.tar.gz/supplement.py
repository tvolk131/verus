import json
from pathlib import Path
import shlex
import sys
import time

import lane

root = lane.ROOT
preexecution = [lane.read(root / ('BUILD' + str(number) + '-PREEXECUTION-AUTHENTICATION.json')) for number in [1, 2]]
known = {}
for snapshot in preexecution:
    for record in snapshot['records'] + snapshot['staged_sources'] + snapshot['python_modules_current']:
        known[str(Path(record['path']).resolve())] = record
paths = set()
for depfile in (root / 'target').rglob('*.d'):
    for line in depfile.read_text(errors='replace').replace('\\\n', ' ').splitlines():
        if ': ' not in line or line.startswith('#'):
            continue
        for token in shlex.split(line.split(': ', 1)[1]):
            path = Path(token)
            if not path.is_absolute():
                path = root / 'stage/observer' / path
            if path.is_file():
                paths.add(str(path.resolve()))
used = []
for path in sorted(paths):
    record = lane.identity(path)
    prior = known.get(path)
    record['preexecution_sha256'] = prior['sha256'] if prior else None
    record['matches_preexecution'] = record['sha256'] == prior['sha256'] if prior else None
    record['scope'] = 'generated current-scratch input; final identity only' if str(root / 'target') in path else 'source input'
    used.append(record)
lane.write('USED-DEPFILE-INPUTS.json', {'epoch_ns': time.time_ns(), 'records': used,
           'unbound_external_source_inputs': [record for record in used if record['preexecution_sha256'] is None and record['scope'] == 'source input'],
           'mismatches': [record for record in used if record['matches_preexecution'] is False]})
cached = set()
for module in list(sys.modules.values()):
    path = getattr(module, '__cached__', None)
    if path and Path(path).is_file():
        cached.add(str(Path(path).resolve()))
lane.write('PYTHON-CACHE-EXIT-IDENTITY.json', {'epoch_ns': time.time_ns(),
           'scope': 'current cache endpoints only, not preexecution custody',
           'records': [lane.identity(path) for path in sorted(cached)]})
initial = lane.read(root / 'STAGED-INITIAL-SOURCE-IDENTITY.json')['records']
current = {record['path']: record for record in lane.inventory(root / 'stage')}
changes = [{'path': record['path'], 'before_sha256': record['sha256'], 'after_sha256': current[record['path']]['sha256']}
           for record in initial if current[record['path']]['sha256'] != record['sha256']]
lane.write('FINAL-SOURCE-DELTA-VALIDATION.json', {'epoch_ns': time.time_ns(), 'changes': changes,
           'exactly_one_changed_file': len(changes) == 1 and changes[0]['path'].endswith('/identity.rs'),
           'main_matches_candidate': lane.identity(root / 'stage/observer/src/main.rs')['sha256'] == 'b03b2bc43440a36bd87280d8f38139fe8f4ec71f05f6f126e6d1840a4f9c7830',
           'helper_matches_helper120': lane.identity(root / 'stage/source/rustc_mir_build/src/builder/checked_drop_origins.rs')['sha256'] == '1aa55b6d95997e1950cc548119ae6b9b83ff3c69af98c36f0790cff895c0ca79'})
print('SUPPLEMENT', len(used), 'depfile inputs;', len(cached), 'Python cache endpoints;', len(changes), 'source correction')
