use crate::rustc_index::Idx;
use crate::thir::cx::ThirBuildCx;
// use crate::thir::pattern::pat_from_hir;
use hir::HirId;
use itertools::Itertools;
use rustc_hir as hir;
use rustc_hir::QPath;
use rustc_hir::def::Res;
use rustc_hir::def_id::{DefId, LocalDefId};
use rustc_middle::hir::place::{Place, Projection, ProjectionKind};
use rustc_middle::middle::region;
use rustc_middle::mir::FakeReadCause;
use rustc_middle::thir::{
    AdtExprBase, Arm, ArmId, Block, BlockId, BlockSafety, Expr, ExprId, ExprKind, LocalVarId, Pat,
    PatKind, Stmt, StmtId, StmtKind,
};
use rustc_middle::ty;
use rustc_middle::ty::{
    Binder, BoundRegion, BoundRegionKind, BoundVar, BoundVarIndexKind, BoundVariableKind,
    CapturedPlace, FnSigKind, GenericArg, Mutability, Ty, TyCtxt, TyKind, TypeSuperFoldable,
    UpvarCapture, adjustment::DerefAdjustKind,
};
use rustc_middle::ty::{TypeFoldable, TypeFolder, UpvarArgs};
use rustc_span::Span;
use std::collections::{HashMap, HashSet};
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::{Arc, RwLock};

#[derive(Debug, PartialEq, Eq, Clone, Copy)]
pub enum VarErasure {
    /// Erase this var binding or var use.
    Erase,
    /// Keep this var binding or var use.
    Keep,
    /// Replace this var use with a use of the shadow var.
    /// (See verus_time_travel_prevention.rs)
    Shadow,
}

/// Do we erase a given node (no bearing on whether we erase its subexpressions)
/// When we erase a node `call(x1, x2)` but not the subexpressions x1, x2, it will look like:
/// { x1; x2; arbitrary_ghost_value() }
#[derive(Debug, PartialEq, Eq, Clone)]
pub enum NodeErase {
    Erase,
    Keep,
}

#[derive(Debug, PartialEq, Eq, Clone)]
pub enum TreeErase {
    /// Check match exhaustiveness and emit shadow vars if necessary.
    /// Suitable for pure spec expressions with no side effects (e.g., assert).
    IncludeBasicChecks,
    /// Erase the tree entirely.
    EraseAbsolutely,
}

#[derive(Debug, PartialEq, Eq, Clone)]
pub enum CallErasure {
    /// Erase the call and ALL subexpressions. This can only be used when the node is guaranteed
    /// to have no proof code in the subtree (e.g., consired 'pure' by modes.rs)
    EraseTree(TreeErase),
    Call(NodeErase),
}

/// Information for a body (function or closure).
#[derive(Debug, PartialEq, Eq, Clone, Copy)]
pub struct BodyErasure {
    pub erase_body: bool,
    pub ret_spec: bool,
}

/// Set of program locations relative to a Loop expressions.
/// For a loop, if we mark the two points A and B: `loop { A; body }; B`
/// then: A = BodyStart and B = PostLoop
#[derive(Debug, PartialEq, Eq, Clone, Copy)]
pub enum LoopSpecEvaluationLocation {
    BodyStart,
    PostLoop,
    BodyStartAndPostLoop,
}

/// Information for a loop.
#[derive(Debug, Clone)]
pub struct LoopErasure {
    pub specs: Vec<(HirId, LoopSpecEvaluationLocation)>,
}

/// Information about a LocalInvariant open block
#[derive(Debug, Clone)]
pub struct LocalInvariantBody {
    pub inner_block_hir_id: HirId,
    pub span: rustc_span::Span,
    pub guard_var: LocalVarId,
}

/// Global context with all information across the krate.
/// This is created after mode-checking and passed here via the VERUS_ERASURE_CTXT global.
#[derive(Debug)]
pub struct VerusErasureCtxt {
    /// For a given var use, should we erase it?
    pub locals: HashMap<HirId, VarErasure>,

    /// For a given binder (from a pattern), should we erase it?
    pub binders: HashMap<HirId, VarErasure>,

    /// For a call, how do we handle it?
    /// This includes struct constructors as well. The "args" go in source order,
    /// i.e., same order as the fields on the Struct node.
    /// If there's a '..struct_tail' in the ctor, it's the last argument.
    /// The bool indicates if we should force the return type to be treated as inhabited.
    pub calls: HashMap<HirId, (CallErasure, bool)>,

    /// Loop headers require special handling. This maps every loop expression to
    /// a list of all its headers. (Note: the headers themselves should be marked
    /// EraseAbsolutely so they don't end up being double-handled.)
    pub loop_erasure: HashMap<HirId, LoopErasure>,

    pub bodies: HashMap<LocalDefId, BodyErasure>,

    pub local_invariant_bodies: HashMap<HirId, LocalInvariantBody>,

    /// Some DefIds from builtin that we'll need to handle directly
    pub erased_ghost_value_fn_def_id: DefId,
    pub shadow_ghost_value_fn_def_id: DefId,
    pub dummy_capture_struct_def_id: DefId,
    pub mutable_reference_tie_fn_def_id: DefId,
    pub two_phase_mutable_reference_tie_fn_def_id: DefId,
    pub get_first_fn_def_id: DefId,
}

/// Used to communicate the set of LocalDefIds that may require erasure.
static VERUS_AWARE_DEF_IDS: RwLock<Option<Arc<HashSet<LocalDefId>>>> = RwLock::new(None);

/// Used to communicate the VerusErasureCtxt
static VERUS_ERASURE_CTXT: RwLock<Option<Arc<VerusErasureCtxt>>> = RwLock::new(None);

/// Used to store the ExtraThir so MIR lowering can pick it up
static EXTRA_THIR: RwLock<Option<HashMap<LocalDefId, Arc<ExtraThir>>>> = RwLock::new(None);

pub fn set_verus_aware_def_ids(ids: Arc<HashSet<LocalDefId>>) {
    let v: &mut Option<Arc<HashSet<LocalDefId>>> = &mut VERUS_AWARE_DEF_IDS.write().unwrap();
    if v.is_some() {
        panic!("VERUS_AWARE_DEF_IDS has already been set");
    }
    *v = Some(ids);
}

pub fn set_verus_erasure_ctxt(erasure_ctxt: Arc<VerusErasureCtxt>) {
    let v: &mut Option<Arc<VerusErasureCtxt>> = &mut VERUS_ERASURE_CTXT.write().unwrap();
    if v.is_some() {
        panic!("VERUS_ERASURE_CTXT has already been set");
    }
    *v = Some(erasure_ctxt);
}

fn get_verus_erasure_ctxt() -> Arc<VerusErasureCtxt> {
    VERUS_ERASURE_CTXT
        .read()
        .unwrap()
        .as_ref()
        .expect("Expected VerusErasureCtxt for THIR modification pass")
        .clone()
}

pub(crate) fn get_verus_erasure_ctxt_option() -> Option<Arc<VerusErasureCtxt>> {
    VERUS_ERASURE_CTXT.read().unwrap().clone()
}

pub fn checked_drop_erasure_helpers() -> Option<(DefId, DefId, DefId)> {
    if crate::builder::checked_drop_origins::native() {
        return None;
    }
    let ctxt = get_verus_erasure_ctxt_option()?;
    Some((ctxt.erased_ghost_value_fn_def_id, ctxt.shadow_ghost_value_fn_def_id,
          ctxt.mutable_reference_tie_fn_def_id))
}

pub(crate) fn get_extra_thir(local_def_id: LocalDefId) -> Option<Arc<ExtraThir>> {
    if crate::builder::checked_drop_origins::native() {
        return None;
    }
    let opt_map: &Option<HashMap<LocalDefId, Arc<ExtraThir>>> = &EXTRA_THIR.read().unwrap();
    match opt_map {
        Some(map) => map.get(&local_def_id).cloned(),
        None => None,
    }
}

/// Our erasure scheme will fail if this query runs too early, before we initialize the
/// VerusErasureCtxt. However, there are some items where this happens
/// intentionally (e.g., for consts, which may be evaluated during type-checking).
///
/// rust_verify needs to follow the scheme:
///
///  1. Compute the set of LocalDefIds that require erasure, and initialize the VERUS_AWARE_DEF_IDS
///  2. Run hir_typeck, compute mode info
///  3. initialize the VERUS_ERASURE_CTXT
///  4. Run lifetime checking
///
/// As a result, thir_body is able to sanity check we're in a consistent state.
/// If the VERUS_ERASURE_CTXT hasn't been initialized yet, we check that the given
/// item is one that doesn't need it.
pub(crate) fn check_this_query_isnt_running_early(local_def_id: LocalDefId) {
    if get_verus_erasure_ctxt_option().is_none() {
        match VERUS_AWARE_DEF_IDS.read().unwrap().clone() {
            Some(m) => {
                if m.contains(&local_def_id) {
                    panic!(
                        "Internal Verus Error: The thir_body query is running for item {:?} which may require erasure, but the VerusErasureCtxt has not been initialized. Please file a github issue for this error and consider using `--no-lifetime` as a temperary measure to work around the issue.",
                        local_def_id
                    );
                }
            }
            None => {
                panic!(
                    "Internal Verus Error: The thir_body query is running for item {:?}, but the VerusAwareDefIds map has not been initialized. Please file a github issue for this error and consider using `--no-lifetime` as a temporary measure to work around the issue.",
                    local_def_id
                );
            }
        }
    }
}

/// Extra information we'd like to add to THIR so that the MIR builder also has access to it
pub(crate) struct ExtraThir {
    /// Maps ExprId (Call node or a Loop) -> LocalInvariant bodies it is contained in
    pub local_invs_for_node: HashMap<ExprId, Vec<LocalInvariantBody>>,
    /// Treat this call as having an inhabited return type (i.e., don't prune the CFG)
    pub force_treat_inhabited: HashSet<ExprId>,
}

/// Per-body context (i.e., one for each function or closure).
pub(crate) struct VerusThirBuildCtxt {
    pub(crate) ctxt: Option<Arc<VerusErasureCtxt>>,
    closure_overrides: HashMap<LocalDefId, ClosureOverrides>,
    pub(crate) do_time_travel_prevention: bool,
    pub(crate) guard_pattern_vars: Vec<Vec<LocalVarId>>,
    pub(crate) local_invariants: Vec<usize>,
    pub(crate) extra_thir: ExtraThir,
    pub(crate) local_def_id: LocalDefId,
}

impl VerusThirBuildCtxt {
    pub(crate) fn new<'tcx>(tcx: TyCtxt<'tcx>, local_def_id: LocalDefId) -> Self {
        let fn_local_def_id = enclosing_fn_local_def_id(tcx, local_def_id);
        let verus_aware =
            VERUS_AWARE_DEF_IDS.read().unwrap().clone().unwrap().contains(&fn_local_def_id);
        let ctxt = get_verus_erasure_ctxt_option();

        let do_time_travel_prevention = verus_aware && ctxt.is_some();

        VerusThirBuildCtxt {
            ctxt: get_verus_erasure_ctxt_option(),
            closure_overrides: HashMap::new(),
            do_time_travel_prevention,
            guard_pattern_vars: vec![],
            local_invariants: vec![],
            extra_thir: ExtraThir {
                local_invs_for_node: HashMap::new(),
                force_treat_inhabited: HashSet::new(),
            },
            local_def_id: local_def_id,
        }
    }

    pub(crate) fn skip_closure<'tcx>(&self, local_def_id: LocalDefId) -> bool {
        match &self.ctxt {
            None => false,
            Some(ctxt) => match ctxt.bodies.get(&local_def_id) {
                Some(b) => b.erase_body,
                None => false,
            },
        }
    }

    pub(crate) fn finish(self) {
        let opt_map: &mut Option<HashMap<LocalDefId, Arc<ExtraThir>>> =
            &mut EXTRA_THIR.write().unwrap();
        let map = opt_map.get_or_insert_with(|| HashMap::new());
        let found = map.insert(self.local_def_id, Arc::new(self.extra_thir));
        assert!(found.is_none());
    }
}

pub(crate) fn enclosing_fn_local_def_id<'tcx>(
    tcx: TyCtxt<'tcx>,
    local_def_id: LocalDefId,
) -> LocalDefId {
    if tcx.is_closure_like(local_def_id.into()) {
        let hir_id = tcx.local_def_id_to_hir_id(local_def_id);
        let parent_owner_id = tcx.hir_get_parent_item(hir_id);
        parent_owner_id.def_id
    } else {
        local_def_id
    }
}

impl NodeErase {
    pub(crate) fn should_erase(&self) -> bool {
        match self {
            NodeErase::Erase => true,
            NodeErase::Keep => false,
        }
    }
}

impl CallErasure {
    pub fn keep_all() -> Self {
        CallErasure::Call(NodeErase::Keep)
    }

    pub(crate) fn should_erase(&self) -> bool {
        match self {
            CallErasure::EraseTree(_) => panic!("EraseTree should be handled by mirror_expr_opt"),
            CallErasure::Call(node_erase) => node_erase.should_erase(),
        }
    }
}

pub(crate) fn handle_call<'tcx>(
    verus_ctxt: &VerusThirBuildCtxt,
    expr: &'tcx hir::Expr<'tcx>,
) -> (CallErasure, bool) {
    let Some(erasure_ctxt) = verus_ctxt.ctxt.clone() else {
        return (CallErasure::keep_all(), false);
    };

    match erasure_ctxt.calls.get(&expr.hir_id) {
        None => (CallErasure::keep_all(), false),
        Some(call_erasure) => call_erasure.clone(),
    }
}

pub(crate) fn handle_local<'tcx>(
    cx: &mut ThirBuildCx<'tcx>,
    expr: &'tcx hir::Expr<'tcx>,
    var_hir_id: HirId,
) -> Option<ExprKind<'tcx>> {
    let Some(erasure_ctxt) = cx.verus_ctxt.ctxt.clone() else {
        return None;
    };
    match erasure_ctxt.locals.get(&expr.hir_id) {
        None | Some(VarErasure::Keep) => None,
        Some(VarErasure::Shadow)
            if cx.verus_ctxt.do_time_travel_prevention
                && !cx.is_upvar(var_hir_id)
                && !crate::verus_expr::is_bound_via_pattern_guard(cx, var_hir_id) =>
        {
            Some(crate::verus_time_travel_prevention::shadow_var_use(
                cx,
                &erasure_ctxt,
                expr,
                var_hir_id,
            ))
        }
        Some(VarErasure::Erase | VarErasure::Shadow) => {
            let ty = cx.typeck_results.expr_ty(expr);
            Some(erased_ghost_value_kind(cx, &erasure_ctxt, expr.hir_id, expr.span, ty))
        }
    }
}

pub(crate) fn expr_id_from_kind<'tcx>(
    cx: &mut ThirBuildCx<'tcx>,
    kind: ExprKind<'tcx>,
    hir_id: HirId,
    span: Span,
    ty: Ty<'tcx>,
) -> ExprId {
    let e = Expr { temp_scope_id: hir_id.local_id, ty, span: span, kind };
    cx.thir.exprs.push(e)
}

/// erase_tree
/// This erases the expression and all HIR subexpressions.
/// (Mostly. It also keeps expressions that need pattern-exhaustiveness checking.)
pub(crate) fn erase_tree<'tcx>(
    cx: &mut ThirBuildCx<'tcx>,
    hir_expr: &'tcx hir::Expr<'tcx>,
    t: TreeErase,
) -> ExprId {
    let kind = erase_tree_kind(cx, hir_expr, hir_expr.hir_id, t);
    let ty = cx.typeck_results.expr_ty(hir_expr);

    let expr = Expr { temp_scope_id: hir_expr.hir_id.local_id, ty, span: hir_expr.span, kind };

    let expr_scope =
        region::Scope { local_id: hir_expr.hir_id.local_id, data: region::ScopeData::Node };
    let expr = Expr {
        temp_scope_id: expr.temp_scope_id,
        ty: expr.ty,
        span: hir_expr.span,
        kind: ExprKind::Scope {
            hir_id: hir_expr.hir_id,
            region_scope: expr_scope,
            value: cx.thir.exprs.push(expr),
        },
    };
    cx.thir.exprs.push(expr)
}

pub(crate) fn erase_tree_kind<'tcx>(
    cx: &mut ThirBuildCx<'tcx>,
    expr: &'tcx hir::Expr<'tcx>,
    root_hir_id: HirId,
    t: TreeErase,
) -> ExprKind<'tcx> {
    let Some(erasure_ctxt) = cx.verus_ctxt.ctxt.clone() else {
        panic!("erased_expr_id_from_expr called without erasure ctxt");
    };

    let exprs = match t {
        TreeErase::IncludeBasicChecks => {
            // We have to preserve all match statements
            let (mut exprs, local_uses) =
                get_all_stmts_with_pattern_checking(cx, &erasure_ctxt, expr, root_hir_id);
            if cx.verus_ctxt.do_time_travel_prevention {
                exprs.append(&mut crate::verus_time_travel_prevention::shadow_var_uses(
                    cx,
                    &erasure_ctxt,
                    local_uses,
                ));
            }
            exprs
        }
        TreeErase::EraseAbsolutely => vec![],
    };

    let ty = cx.typeck_results.expr_ty(expr);
    erased_ghost_value_kind_with_args(cx, &erasure_ctxt, expr.hir_id, expr.span, ty, exprs)
}

/// erase_node
/// This erases a single node but not the children.
/// We create a value `erased_ghost_value::<T>::((args...))` where `args` contains anything
/// that needs checking from the subexpressions.
pub(crate) fn erase_node_unadjusted<'tcx>(
    cx: &mut ThirBuildCx<'tcx>,
    hir_expr: &'tcx hir::Expr<'tcx>,
    kind: ExprKind<'tcx>,
) -> ExprKind<'tcx> {
    let ty = cx.typeck_results.expr_ty(hir_expr);
    erase_node(cx, hir_expr, ty, kind)
}

pub(crate) fn erase_node<'tcx>(
    cx: &mut ThirBuildCx<'tcx>,
    hir_expr: &'tcx hir::Expr<'tcx>,
    ty: Ty<'tcx>,
    kind: ExprKind<'tcx>,
) -> ExprKind<'tcx> {
    let Some(erasure_ctxt) = cx.verus_ctxt.ctxt.clone() else {
        panic!("erase_node called for const value");
    };

    let expr_ids = match kind {
        ExprKind::Call { ty: _, fun, args, from_hir_call: _, fn_span: _ } => {
            let mut v = vec![];
            v.push(fun);
            for arg in args.iter() {
                v.push(*arg);
            }
            v
        }
        ExprKind::Adt(adt) => {
            let mut v = vec![];
            for f in adt.fields.iter() {
                v.push(f.expr);
            }
            match adt.base {
                AdtExprBase::None => {}
                AdtExprBase::Base(fru) => {
                    v.push(fru.base);
                }
                AdtExprBase::DefaultFields(_tys) => {}
            }
            v
        }
        ExprKind::Borrow { borrow_kind: _, arg } => {
            vec![arg]
        }
        ExprKind::Deref { arg } => {
            vec![arg]
        }
        ExprKind::Field { lhs, variant_index: _, name: _ } => {
            vec![lhs]
        }
        ExprKind::NeverToAny { source } => {
            vec![source]
        }
        _ => {
            panic!("erase_node got unexpected kind");
        }
    };

    let expr_ids = expr_ids
        .iter()
        .map(|e| {
            erased_ghost_value_remove_type_if_possible(
                cx,
                &erasure_ctxt,
                *e,
                hir_expr.hir_id,
                hir_expr.span,
            )
            .unwrap_or(*e)
        })
        .collect::<Vec<_>>();

    erased_ghost_value_kind_with_args(
        cx,
        &erasure_ctxt,
        hir_expr.hir_id,
        hir_expr.span,
        ty,
        expr_ids,
    )
}

/// We have to be careful to not emit any `erased_ghost_value::<T>(...)` expressions where `T`
/// is unsized. An example of where this matters is in something like `&*"abc"`.
/// Note here that:
///     "abc" is &str
///     *"abc" is str
///     &*"abc" is &str
/// The middle one is problematic. Luckily, whenever this happens, it will always be as
/// the intermediary in some expression like this. i.e., if *"abc" is getting erased,
/// then &*"abc" is getting erased too (or something like it).
/// Thus, we can resolve this issue by always erasing the type on any intermediary.
/// So, for example, if we are creating `erased_ghost_value::<T>()` where one of the arguments is
/// `erased_ghost_value::<S>()`, we replace the latter with `erased_ghost_value::<()>()`.
/// The type param only matters for the return value anyway, which doesn't matter in this
/// context.
fn erased_ghost_value_remove_type_if_possible<'tcx>(
    cx: &mut ThirBuildCx<'tcx>,
    erasure_ctxt: &VerusErasureCtxt,
    e: ExprId,
    hir_id: HirId,
    span: Span,
) -> Option<ExprId> {
    match &cx.thir.exprs[e].kind {
        ExprKind::Call { fun, args, .. } => match cx.thir.exprs[*fun].ty.kind() {
            TyKind::FnDef(fn_def_id, _)
                if *fn_def_id == erasure_ctxt.erased_ghost_value_fn_def_id
                    || *fn_def_id == erasure_ctxt.shadow_ghost_value_fn_def_id =>
            {
                let tup_arg = args[0];
                let args = match &cx.thir.exprs[tup_arg].kind {
                    ExprKind::Tuple { fields } => fields.clone().into_vec(),
                    _ => {
                        panic!(
                            "erased_ghost_value should only be constructed with a tuple argument"
                        );
                    }
                };
                Some(some_ghost_value_with_args(
                    cx,
                    hir_id,
                    span,
                    Ty::new_tup(cx.tcx, &[]),
                    args,
                    *fn_def_id,
                ))
            }
            _ => None,
        },
        ExprKind::Scope { region_scope, value, hir_id } => {
            let region_scope = *region_scope;
            let hir_id = *hir_id;
            let value = *value;
            let value =
                erased_ghost_value_remove_type_if_possible(cx, erasure_ctxt, value, hir_id, span);
            match value {
                Some(v) => {
                    let mut expr = cx.thir.exprs[e].clone();
                    expr.kind = ExprKind::Scope { region_scope, value: v, hir_id };
                    expr.ty = cx.thir.exprs[v].ty;
                    Some(cx.thir.exprs.push(expr))
                }
                None => None,
            }
        }
        _ => None,
    }
}

/// Is the given THIR node the result of erasure or shadow?
fn is_erased_or_shadow<'tcx>(
    cx: &ThirBuildCx<'tcx>,
    erasure_ctxt: &VerusErasureCtxt,
    expr_kind: &rustc_middle::thir::ExprKind<'tcx>,
) -> bool {
    match expr_kind {
        ExprKind::Call { fun, args: _, .. } => match cx.thir.exprs[*fun].ty.kind() {
            TyKind::FnDef(fn_def_id, _) => {
                *fn_def_id == erasure_ctxt.erased_ghost_value_fn_def_id
                    || *fn_def_id == erasure_ctxt.shadow_ghost_value_fn_def_id
            }
            _ => false,
        },
        ExprKind::Scope { region_scope: _, value, hir_id: _ } => {
            is_erased_or_shadow(cx, erasure_ctxt, &cx.thir.exprs[*value].kind)
        }
        _ => false,
    }
}

/// Given an expression like `&x`, `*x` or `x.field`, determine if it should be erased
/// by looking at if `x` is erased.
pub(crate) fn is_node_with_single_arg_erased_or_shadow<'tcx>(
    cx: &ThirBuildCx<'tcx>,
    erasure_ctxt: &VerusErasureCtxt,
    expr_kind: &rustc_middle::thir::ExprKind<'tcx>,
) -> bool {
    match expr_kind {
        ExprKind::Call { ty: _, fun: _, args, from_hir_call: _, fn_span: _ } => {
            assert!(args.len() == 1);
            is_erased_or_shadow(cx, erasure_ctxt, &cx.thir.exprs[args[0]].kind)
        }
        ExprKind::Borrow { borrow_kind: _, arg }
        | ExprKind::RawBorrow { mutability: _, arg }
        | ExprKind::Deref { arg }
        | ExprKind::NeverToAny { source: arg }
        | ExprKind::Field { lhs: arg, .. } => {
            is_erased_or_shadow(cx, erasure_ctxt, &cx.thir.exprs[*arg].kind)
        }
        _ => {
            panic!("is_node_with_single_arg_erased got unexpected kind");
        }
    }
}

/// Produce an expression `builtin::erased_ghost_value::<T>(())`
/// The hir_id is used for the scope so it needs to correspond to something that will
/// get a scope in the final THIR.
pub(crate) fn erased_ghost_value<'tcx>(
    cx: &mut ThirBuildCx<'tcx>,
    erasure_ctxt: &VerusErasureCtxt,
    hir_id: HirId,
    span: Span,
    ty: Ty<'tcx>,
) -> ExprId {
    let kind = erased_ghost_value_kind(cx, erasure_ctxt, hir_id, span, ty);
    expr_id_from_kind(cx, kind, hir_id, span, ty)
}

fn erased_ghost_value_kind<'tcx>(
    cx: &mut ThirBuildCx<'tcx>,
    erasure_ctxt: &VerusErasureCtxt,
    hir_id: HirId,
    span: Span,
    ty: Ty<'tcx>,
) -> ExprKind<'tcx> {
    erased_ghost_value_kind_with_args(cx, erasure_ctxt, hir_id, span, ty, vec![])
}

fn some_ghost_value_with_args<'tcx>(
    cx: &mut ThirBuildCx<'tcx>,
    hir_id: HirId,
    span: Span,
    ty: Ty<'tcx>,
    expr_args: Vec<ExprId>,
    fn_def_id: DefId,
) -> ExprId {
    let kind = some_ghost_value_kind_with_args(cx, hir_id, span, ty, expr_args, fn_def_id);
    expr_id_from_kind(cx, kind, hir_id, span, ty)
}

pub(crate) fn shadow_ghost_value_kind_with_args<'tcx>(
    cx: &mut ThirBuildCx<'tcx>,
    erasure_ctxt: &VerusErasureCtxt,
    hir_id: HirId,
    span: Span,
    ty: Ty<'tcx>,
    expr_args: Vec<ExprId>,
) -> ExprKind<'tcx> {
    some_ghost_value_kind_with_args(
        cx,
        hir_id,
        span,
        ty,
        expr_args,
        erasure_ctxt.shadow_ghost_value_fn_def_id,
    )
}

pub(crate) fn erased_ghost_value_kind_with_args<'tcx>(
    cx: &mut ThirBuildCx<'tcx>,
    erasure_ctxt: &VerusErasureCtxt,
    hir_id: HirId,
    span: Span,
    ty: Ty<'tcx>,
    expr_args: Vec<ExprId>,
) -> ExprKind<'tcx> {
    some_ghost_value_kind_with_args(
        cx,
        hir_id,
        span,
        ty,
        expr_args,
        erasure_ctxt.erased_ghost_value_fn_def_id,
    )
}

pub(crate) fn some_ghost_value_kind_with_args<'tcx>(
    cx: &mut ThirBuildCx<'tcx>,
    hir_id: HirId,
    span: Span,
    ty: Ty<'tcx>,
    expr_args: Vec<ExprId>,
    fn_def_id: DefId,
) -> ExprKind<'tcx> {
    let tup_tys = expr_args.iter().map(|e| cx.thir.exprs[*e].ty).collect::<Vec<_>>();
    let tup_ty = Ty::new_tup(cx.tcx, &tup_tys);

    let arg1 = GenericArg::from(tup_ty);
    let arg2 = GenericArg::from(ty);
    let args = cx.tcx.mk_args(&[arg1, arg2]);
    let fn_ty =
        cx.tcx.mk_ty_from_kind(TyKind::FnDef(fn_def_id, rustc_middle::ty::Binder::dummy(args)));

    let fun_expr_kind = ExprKind::ZstLiteral { user_ty: None };
    let fun_expr = expr_id_from_kind(cx, fun_expr_kind, hir_id, span, fn_ty);

    let arg_expr_kind = ExprKind::Tuple { fields: expr_args.into_boxed_slice() };
    let arg_expr = expr_id_from_kind(cx, arg_expr_kind, hir_id, span, tup_ty);

    ExprKind::Call {
        ty: fn_ty,
        fun: fun_expr,
        args: Box::new([arg_expr]),
        from_hir_call: false,
        fn_span: span,
    }
}

pub(crate) fn erase_body<'tcx>(cx: &mut ThirBuildCx<'tcx>, local_def_id: LocalDefId) -> bool {
    let Some(erasure_ctxt) = cx.verus_ctxt.ctxt.clone() else {
        return false;
    };
    matches!(erasure_ctxt.bodies.get(&local_def_id), Some(BodyErasure { erase_body: true, .. }))
}

pub(crate) fn erase_closure_body_for_closure_captures<'tcx>(local_def_id: LocalDefId) -> bool {
    let erasure_ctxt = get_verus_erasure_ctxt();
    matches!(erasure_ctxt.bodies.get(&local_def_id), Some(BodyErasure { erase_body: true, .. }))
}

pub(crate) static ATOMIC_CLOSURE_CAPTURE_SHADOW: AtomicBool = AtomicBool::new(false);

pub(crate) fn erase_var_for_closure_captures<'tcx>(hir_id: HirId) -> bool {
    let erasure_ctxt = get_verus_erasure_ctxt();
    let capture_shadow = ATOMIC_CLOSURE_CAPTURE_SHADOW.load(Ordering::SeqCst);
    if capture_shadow {
        matches!(erasure_ctxt.locals.get(&hir_id), Some(VarErasure::Erase))
    } else {
        matches!(erasure_ctxt.locals.get(&hir_id), Some(VarErasure::Erase | VarErasure::Shadow))
    }
}

pub(crate) fn erase_binder_for_closure_captures<'tcx>(hir_id: HirId) -> bool {
    let erasure_ctxt = get_verus_erasure_ctxt();
    let capture_shadow = ATOMIC_CLOSURE_CAPTURE_SHADOW.load(Ordering::SeqCst);
    if capture_shadow {
        matches!(erasure_ctxt.binders.get(&hir_id), Some(VarErasure::Erase))
    } else {
        matches!(erasure_ctxt.binders.get(&hir_id), Some(VarErasure::Erase | VarErasure::Shadow))
    }
}

/// Remove all ghost-variable binders from the pattern
pub(crate) fn erase_pat<'tcx>(cx: &mut ThirBuildCx<'tcx>, pat: Box<Pat<'tcx>>) -> Box<Pat<'tcx>> {
    let Some(erasure_ctxt) = cx.verus_ctxt.ctxt.clone() else {
        return pat;
    };

    let mut p = pat;
    // Only ghost code uses the `__verus_param_N @` the macros add to complex parameter patterns
    // of functions, so we can strip them.
    if let PatKind::Binding { var, subpattern: subpattern @ Some(_), .. } = &mut p.kind
        && is_verus_param_binder(&cx.tcx.hir_ident(var.0))
        && match cx.tcx.parent_hir_node(var.0) {
            hir::Node::Param(_) => {
                matches!(
                    cx.tcx.def_kind(cx.body_owner),
                    hir::def::DefKind::Fn | hir::def::DefKind::AssocFn
                )
            }
            hir::Node::LetStmt(local) => matches!(local.source, hir::LocalSource::AsyncFn),
            _ => false,
        }
    {
        p = subpattern.take().unwrap();
    }
    erase_pat_rec(&PatBindingEraserMode::EraseGhost(erasure_ctxt), &mut p);
    p
}

/// Remove ALL binders from the pattern
pub(crate) fn erase_pat_all_binders<'tcx>(pat: Box<Pat<'tcx>>) -> Box<Pat<'tcx>> {
    let mut p = pat;
    erase_pat_rec(&PatBindingEraserMode::EraseAll, &mut p);
    p
}

enum PatBindingEraserMode {
    EraseAll,
    EraseGhost(Arc<VerusErasureCtxt>),
}

/// Prefix used for naming complex parameter patterns
const VERUS_PARAM: &str = "__verus_param_";

pub fn is_verus_param_binder(ident: &rustc_span::symbol::Ident) -> bool {
    ident.as_str().starts_with(VERUS_PARAM)
        && !ident.span.ctxt().normalize_to_macros_2_0().is_root()
}

fn erase_pat_rec<'tcx>(emode: &PatBindingEraserMode, p: &mut Pat<'tcx>) {
    match &mut p.kind {
        PatKind::Missing => {}
        PatKind::Wild => {}
        PatKind::Binding {
            name: _,
            mode: _,
            var,
            ty: _,
            subpattern,
            is_primary: _,
            is_shorthand: _,
        } => {
            if let Some(subpat) = subpattern {
                erase_pat_rec(emode, subpat);
            }

            let erase_binder = match emode {
                PatBindingEraserMode::EraseAll => true,
                PatBindingEraserMode::EraseGhost(erasure_ctxt) => {
                    matches!(erasure_ctxt.binders.get(&var.0), Some(VarErasure::Erase))
                }
            };

            if erase_binder {
                // To remove the binder:
                //  - If there's a subpattern, just return the subpattern.
                //  - If there is no subpattern, return a wildcard.
                if subpattern.is_some() {
                    let mut subpat = None;
                    std::mem::swap(subpattern, &mut subpat);
                    let subpat = *subpat.unwrap();
                    *p = subpat;
                } else {
                    p.kind = PatKind::Wild;
                }
            }
        }
        PatKind::Variant { adt_def: _, args: _, variant_index: _, subpatterns }
        | PatKind::Leaf { subpatterns } => {
            for field_pat in subpatterns.iter_mut() {
                erase_pat_rec(emode, &mut field_pat.pattern);
            }
        }
        PatKind::Deref { subpattern, pin: _ } => {
            erase_pat_rec(emode, subpattern);
        }
        PatKind::DerefPattern { subpattern, borrow: _ } => {
            erase_pat_rec(emode, subpattern);
        }
        PatKind::Constant { value: _ } => {}
        PatKind::Range(_pat_range) => {}
        PatKind::Slice { prefix, slice, suffix } | PatKind::Array { prefix, slice, suffix } => {
            for p in prefix.iter_mut() {
                erase_pat_rec(emode, p);
            }
            if let Some(sl) = slice {
                erase_pat_rec(emode, sl);
            }
            for p in suffix.iter_mut() {
                erase_pat_rec(emode, p);
            }
        }
        PatKind::Or { pats } => {
            for p in pats.iter_mut() {
                erase_pat_rec(emode, p);
            }
        }
        PatKind::Guard { subpattern, condition: _ } => erase_pat_rec(emode, subpattern),
        PatKind::Never => {}
        PatKind::Error(_error_guaranteed) => {}
    }
}

pub(crate) struct Proj<'tcx> {
    pub ty: Ty<'tcx>,
    pub kind: ProjKind,
}

pub(crate) enum ProjKind {
    Deref,
    Field(rustc_abi::VariantIdx, rustc_abi::FieldIdx),
}

pub(crate) struct LocalUse<'tcx> {
    pub local: LocalVarId,
    pub hir_id: HirId,
    pub root_hir_id: HirId,
    pub span: Span,
    pub ty: Ty<'tcx>,
    pub projs: Vec<Proj<'tcx>>,
}

/// Get all nodes that need pattern checking (match expressions and let stmts)
fn get_all_stmts_with_pattern_checking<'tcx>(
    cx: &mut ThirBuildCx<'tcx>,
    erasure_ctxt: &VerusErasureCtxt,
    expr: &'tcx hir::Expr<'tcx>,
    root_hir_id: HirId,
) -> (Vec<ExprId>, Vec<LocalUse<'tcx>>) {
    use crate::rustc_hir::intravisit::Visitor;

    // We use two visitors, one that visits closure bodies and one that doesn't.

    let mut vis = VisitTreeForPats { cx, erasure_ctxt, root_hir_id, output_exprs: vec![] };
    vis.visit_expr(expr);
    let output_exprs = vis.output_exprs;

    let mut vis2 =
        VisitTreeForLocalUses { cx, erasure_ctxt, root_hir_id, output_local_uses: vec![] };
    vis2.visit_expr(expr);

    (output_exprs, vis2.output_local_uses)
}

struct VisitTreeForPats<'a, 'tcx> {
    cx: &'a mut ThirBuildCx<'tcx>,
    erasure_ctxt: &'a VerusErasureCtxt,
    root_hir_id: HirId,
    output_exprs: Vec<ExprId>,
}

impl<'a, 'tcx> rustc_hir::intravisit::Visitor<'tcx> for VisitTreeForPats<'a, 'tcx> {
    // Don't recurse into other items or closure bodies
    type NestedFilter = rustc_hir::intravisit::IgnoreNested;

    fn visit_expr(&mut self, expr: &'tcx hir::Expr<'tcx>) {
        match &expr.kind {
            hir::ExprKind::Call(..) | hir::ExprKind::MethodCall(..) => {
                if matches!(
                    self.erasure_ctxt.calls.get(&expr.hir_id),
                    Some((CallErasure::EraseTree(TreeErase::EraseAbsolutely), _))
                ) {
                    return;
                }
            }
            hir::ExprKind::Match(..) => {
                self.output_exprs.push(erase_match_for_pattern_checking(
                    self.cx,
                    self.erasure_ctxt,
                    self.root_hir_id,
                    expr,
                ));
            }
            hir::ExprKind::Block(_block, _) => {
                if let Some(b) = erase_block_for_pattern_checking(
                    self.cx,
                    self.erasure_ctxt,
                    self.root_hir_id,
                    expr,
                ) {
                    self.output_exprs.push(b);
                }
            }
            _ => {}
        }

        rustc_hir::intravisit::walk_expr(self, expr);
    }
}

struct VisitTreeForLocalUses<'a, 'tcx> {
    cx: &'a mut ThirBuildCx<'tcx>,
    erasure_ctxt: &'a VerusErasureCtxt,
    root_hir_id: HirId,
    output_local_uses: Vec<LocalUse<'tcx>>,
}

impl<'a, 'tcx> rustc_hir::intravisit::Visitor<'tcx> for VisitTreeForLocalUses<'a, 'tcx> {
    // Recurse into closures
    type NestedFilter = rustc_middle::hir::nested_filter::OnlyBodies;

    fn maybe_tcx(&mut self) -> TyCtxt<'tcx> {
        self.cx.tcx
    }

    fn visit_expr(&mut self, expr: &'tcx hir::Expr<'tcx>) {
        match &expr.kind {
            hir::ExprKind::Call(..) | hir::ExprKind::MethodCall(..) => {
                if matches!(
                    self.erasure_ctxt.calls.get(&expr.hir_id),
                    Some((CallErasure::EraseTree(TreeErase::EraseAbsolutely), _))
                ) {
                    return;
                }
            }
            _ => {
                if let Some(lu) = self.try_unadjusted(expr) {
                    self.output_local_uses.push(lu);
                    return;
                }
            }
        }

        rustc_hir::intravisit::walk_expr(self, expr);
    }
}

impl<'a, 'tcx> VisitTreeForLocalUses<'a, 'tcx> {
    fn try_unadjusted(&self, expr: &'tcx hir::Expr<'tcx>) -> Option<LocalUse<'tcx>> {
        match &expr.kind {
            hir::ExprKind::Path(QPath::Resolved(
                None,
                rustc_hir::Path { res: Res::Local(id), .. },
            )) => Some(LocalUse {
                local: LocalVarId(*id),
                span: expr.span,
                ty: self.cx.typeck_results.expr_ty(expr),
                hir_id: expr.hir_id,
                root_hir_id: self.root_hir_id,
                projs: vec![],
            }),
            hir::ExprKind::Field(inner, _f) => {
                let mut lu = self.try_adjusted(inner)?;
                lu.projs.push(Proj {
                    ty: self.cx.typeck_results.expr_ty(expr),
                    kind: ProjKind::Field(
                        rustc_abi::FIRST_VARIANT,
                        self.cx.typeck_results.field_index(expr.hir_id),
                    ),
                });
                Some(lu)
            }
            hir::ExprKind::Unary(rustc_hir::UnOp::Deref, inner) => {
                let mut lu = self.try_adjusted(inner)?;
                lu.projs
                    .push(Proj { ty: self.cx.typeck_results.expr_ty(expr), kind: ProjKind::Deref });
                Some(lu)
            }
            _ => None,
        }
    }

    fn try_adjusted(&self, expr: &'tcx hir::Expr<'tcx>) -> Option<LocalUse<'tcx>> {
        let mut projs = vec![];
        let adjustments = self.cx.typeck_results.expr_adjustments(expr);
        for adjustment in adjustments.iter() {
            if let rustc_middle::ty::adjustment::Adjust::Deref(DerefAdjustKind::Builtin) =
                &adjustment.kind
            {
                projs.push(Proj { ty: adjustment.target, kind: ProjKind::Deref });
            } else {
                return None;
            }
        }
        let mut lu = self.try_unadjusted(expr)?;
        lu.projs.extend(projs);
        Some(lu)
    }
}

fn erase_block_for_pattern_checking<'tcx>(
    cx: &mut ThirBuildCx<'tcx>,
    erasure_ctxt: &VerusErasureCtxt,
    root_hir_id: HirId,
    expr: &'tcx hir::Expr<'tcx>,
) -> Option<ExprId> {
    let hir::ExprKind::Block(block, _) = expr.kind else {
        unreachable!();
    };

    let mut stmts = vec![];
    for stmt in block.stmts.iter() {
        match &stmt.kind {
            hir::StmtKind::Let(..) => {
                stmts.push(erase_let_for_pattern_checking(
                    cx,
                    erasure_ctxt,
                    root_hir_id,
                    stmt,
                    block.hir_id.local_id,
                    stmts.len(),
                ));
            }
            _ => {}
        }
    }

    if stmts.len() == 0 {
        None
    } else {
        let block = Block {
            targeted_by_break: false,
            region_scope: region::Scope {
                local_id: block.hir_id.local_id,
                data: region::ScopeData::Node,
            },
            span: block.span,
            stmts: stmts.into_boxed_slice(),
            expr: None,
            safety_mode: BlockSafety::Safe,
        };
        let block = cx.thir.blocks.push(block);
        let kind = ExprKind::Block { block };
        Some(expr_id_from_kind(cx, kind, expr.hir_id, expr.span, Ty::new_tup(cx.tcx, &[])))
    }
}

fn erase_let_for_pattern_checking<'tcx>(
    cx: &mut ThirBuildCx<'tcx>,
    erasure_ctxt: &VerusErasureCtxt,
    root_hir_id: HirId,
    stmt: &'tcx hir::Stmt<'tcx>,
    block_id: hir::ItemLocalId,
    index: usize,
) -> StmtId {
    let hir::StmtKind::Let(local) = stmt.kind else {
        unreachable!();
    };
    let rustc_hir::LetStmt { super_: _, pat, ty: _, init, els, hir_id, span, source: _ } = local;
    if els.is_some() {
        panic!("erase_let_for_pattern_checking: let-else statement not expected in erased code");
    }

    let pattern = erase_pat_all_binders(cx.pattern_from_hir(pat));

    let init_ty = pattern.ty;
    let init =
        init.map(|init| erased_ghost_value(cx, erasure_ctxt, root_hir_id, init.span, init_ty));

    let remainder_scope = region::Scope {
        local_id: block_id,
        data: region::ScopeData::Remainder(region::FirstStatementIndex::new(index)),
    };
    let stmt = Stmt {
        kind: StmtKind::Let {
            hir_id: *hir_id,
            remainder_scope,
            init_scope: region::Scope { local_id: hir_id.local_id, data: region::ScopeData::Node },
            pattern,
            initializer: init,
            else_block: None,
            span: *span,
        },
    };
    cx.thir.stmts.push(stmt)
}

fn erase_match_for_pattern_checking<'tcx>(
    cx: &mut ThirBuildCx<'tcx>,
    erasure_ctxt: &VerusErasureCtxt,
    root_hir_id: HirId,
    expr: &'tcx hir::Expr<'tcx>,
) -> ExprId {
    let hir::ExprKind::Match(discr, arms, match_source) = expr.kind else {
        unreachable!();
    };

    let scrutinee_ty = cx.typeck_results.expr_ty_adjusted(discr);
    let match_ty = cx.typeck_results.expr_ty(expr);

    let scrutinee = erased_ghost_value(cx, erasure_ctxt, root_hir_id, discr.span, scrutinee_ty);

    let kind = ExprKind::Match {
        scrutinee,
        arms: arms
            .iter()
            .map(|a| erase_arm_for_pattern_checking(cx, erasure_ctxt, root_hir_id, a, match_ty))
            .collect(),
        match_source,
    };
    expr_id_from_kind(cx, kind, expr.hir_id, expr.span, match_ty)
}

fn erase_arm_for_pattern_checking<'tcx>(
    cx: &mut ThirBuildCx<'tcx>,
    erasure_ctxt: &VerusErasureCtxt,
    root_hir_id: HirId,
    arm: &'tcx hir::Arm<'tcx>,
    match_ty: Ty<'tcx>,
) -> ArmId {
    let pattern = erase_pat_all_binders(cx.pattern_from_hir(&arm.pat));
    let guard = arm.guard.map(|guard| {
        let bool_ty = cx.tcx.mk_ty_from_kind(TyKind::Bool);
        erased_ghost_value(cx, erasure_ctxt, root_hir_id, guard.span, bool_ty)
    });

    let body = erased_ghost_value(cx, erasure_ctxt, root_hir_id, arm.body.span, match_ty);

    let arm = Arm {
        hir_id: arm.hir_id,
        pattern,
        guard,
        body,
        scope: region::Scope { local_id: arm.hir_id.local_id, data: region::ScopeData::Node },
        span: arm.span,
    };
    cx.thir.arms.push(arm)
}

/*////// Closures

Welcome to closure handling.

The tricky thing about closures is that erasure might change the *capture set* for the closure.
For example, if we have:

|| {
    proof { assert(foo(x)); }
    let y = &x.a;
}

then Rust would ordinarily infer a capture set of { MOVE x }. Whereas what we actually want,
i.e., post-erasure, is the capture set of { REF x.a }.

To make matters worse, Rust computes the capture set *during type checking*
(i.e., in rustc_hir_typeck). This is because the capture set influences the types:
the types of captured variables all go into the closure type, which then influences
marker traits, FnOnce/FnMut/Fn, etc.

See:

 - https://doc.rust-lang.org/beta/nightly-rustc/rustc_middle/ty/struct.ClosureArgs.html

Now, we're going to just leave the types as-is since changing them at this point is basically
impossible. That means if Rust decides the closure needs to capture a variable which is !Sync,
and then Verus decides it doesn't really need to be captured, then ... oh well.

However, we still want to make sure variables used in ghost code don't affect *lifetime checking*.
So we need to do two things:

 1. Compute the "post-erasure" capture set. (We'll call this the "Verus capture set" in contrast
    to the "Rust capture set"

 2. Generate well-formed THIR/MIR that uses the Verus capture set instead of the Rust capture set.

Both of these things are somewhat nontrivial.
*/

// Step 1: Get the Verus capture set
pub(crate) fn get_closure_captures_accounting_for_ghost<'tcx>(
    cx: &mut ThirBuildCx<'tcx>,
    closure_expr: &'tcx hir::Expr<'tcx>,
    closure_def_id: LocalDefId,
    capture_shadow: bool,
) -> (
    &'tcx rustc_middle::ty::List<&'tcx CapturedPlace<'tcx>>,
    Vec<Ty<'tcx>>,
    Vec<(rustc_middle::hir::place::Place<'tcx>, rustc_middle::mir::FakeReadCause, HirId)>,
) {
    let tcx = cx.tcx;

    ATOMIC_CLOSURE_CAPTURE_SHADOW.store(capture_shadow, Ordering::SeqCst);
    let capture_results = crate::upvar::compute_captures_accounting_for_ghost(
        tcx,
        cx.typing_env.param_env,
        closure_expr,
        closure_def_id,
        cx.typeck_results,
    );

    let closure_min_captures = capture_results.closure_min_captures;
    let closure_min_captures = Box::leak(Box::new(closure_min_captures));
    let closure_min_captures = closure_min_captures.values().flat_map(|v| v.iter());

    let captures = tcx.mk_captures_from_iter(closure_min_captures);

    (captures, capture_results.upvar_tys, capture_results.fake_reads)
}

/*
Generating the THIR using the Verus capture set:

Normally what happens, is that we pass the captures as arguments to the closure expression.
e.g., if the closure captures x.a by reference, then we'd pass &x.a as an argument.
We're in the situation where the closure expression expects certain arguments (determined
by its type, which is pre-determined by the Rust capture set), but the arguments we *want*
to pass in are determined by the Verus capture set.

We only want to lifetime-check this code, not run it, which simplifies our work greatly.
This allows us to create nonsense conversions that aren't implementable as long as they have
the right type signature.

However, it's important that this coercion propagates lifetime variables correctly.
So for example if the Rust capture set is { t: T<'a> }
and the Verus capture set is { t: T<'a> }, we need to make
sure these are actually hooked up to each other, and that we aren't just coercing from
T<'a> to T<'b> for some other lifetime <'b>.

This gets more complicated when we consider projections. Maybe Rust captures { t: T<'a> } while
Verus captures something more precise, { t.a: S<'a> }. This isn't difficult to handle because
we can substitute args to compute the type of the projections.

Now, the gist of what we're going to do is:
 - Make a fake function with a synthesized type signature which
   is quantified over some lifetime variables
 - Pass all the Verus-captures as input to the function
 - Take the output of that function call and pass it to the closure.

Again, we don't need to implement the function, we just need the desired signature and
then we can conjure the function out of nowhere.

There are a few annoying corner cases. The main one is when the Verus capture set contains a reference
that the Rust capture doesn't contain. For example:

|| {
    proof { assert(foo(x)); }
    let y = &x;
}

Rust capture set: { MOVE x }
Verus capture set: { REF x }

Thus, we need to coerce &x of type &T to type T. The problem is that &x has a lifetime variable
(&'a x) that has nowhere to go. To resolve this, we make sure every closure always captures
at least one variable with a lifetime parameter. We call this the "dummy capture". Specifically,
the syntax macro encodes the closure like this:

```
{
    let _verus_internal_dummy_capture = ::builtin::dummy_capture_new();
    || {
        ::builtin::dummy_capture_consume(_verus_internal_dummy_capture);
        // ...
    }
}
```

The _verus_internal_dummy_capture has type DummyCapture<'a>. Thus, we can always map the
lifetime variable of the reference to some lifetime parameter that the closure is bounded by,
which then makes sure the reference does actually outlive the closure.

So if we take this example again:

```
{
    let _verus_internal_dummy_capture = ::builtin::dummy_capture_new();
    || {
        ::builtin::dummy_capture_consume(_verus_internal_dummy_capture);
        proof { assert(foo(x)); }
        let y = &x;
    }
}
```

The Rust capture set will be [ MOVE _verus_internal_dummy_capture, MOVE x ] while
the Verus capture set will be [ REF x ]. If x has type T<'b>, then we're going to synthesize
a coercion function:

MAGIC_COERCION: for<'a, 'b> (&'a T<'b>) -> (DummyCapture<'a>, T<'b>)

It may seem a little dodgy that we lose the implict ('b: 'a) bound as a result of splitting up the
&'a T<'b> type. However, this is actually fine, since there is no way to "destruct" the closure
or access its innards except from within, and this requires all its type variables to be live
(i.e., both 'a and 'b').

Now, the resulting THIR looks like this:

```
{
    let _tmp = MAGIC_COERCION(&x);
    CLOSURE(_tmp.0, _tmp.1)
}
```

(We reuse the _verus_internal_dummy_capture local ID in the _tmp variable for convenience,
but of course this variable is going to have a different type than the original source.)
*/

type ClosureOverrides = (Box<[ExprId]>, Vec<(ExprId, FakeReadCause, HirId)>);

pub(crate) fn set_override_closure_kind<'tcx>(
    cx: &mut ThirBuildCx<'tcx>,
    local_def_id: LocalDefId,
    overrides: ClosureOverrides,
) {
    cx.verus_ctxt.closure_overrides.insert(local_def_id, overrides);
}

pub(crate) fn get_override_closure_kind<'tcx>(
    cx: &ThirBuildCx<'tcx>,
    local_def_id: LocalDefId,
) -> Option<ClosureOverrides> {
    cx.verus_ctxt.closure_overrides.get(&local_def_id).cloned()
}

// Utilities to replace Region::ReErased with bound regions

struct ReErasedReplacer<'tcx> {
    tcx: TyCtxt<'tcx>,
    current_index: rustc_middle::ty::DebruijnIndex,
    current_var: usize,
}

impl<'tcx> ReErasedReplacer<'tcx> {
    fn new(tcx: TyCtxt<'tcx>) -> Self {
        ReErasedReplacer { tcx, current_index: rustc_middle::ty::INNERMOST, current_var: 0 }
    }
}

impl<'tcx> TypeFolder<TyCtxt<'tcx>> for ReErasedReplacer<'tcx> {
    fn cx(&self) -> TyCtxt<'tcx> {
        self.tcx
    }

    fn fold_binder<T: TypeFoldable<TyCtxt<'tcx>>>(
        &mut self,
        t: rustc_middle::ty::Binder<'tcx, T>,
    ) -> rustc_middle::ty::Binder<'tcx, T> {
        self.current_index.shift_in(1);
        let t = t.super_fold_with(self);
        self.current_index.shift_out(1);
        t
    }

    fn fold_region(&mut self, r: rustc_middle::ty::Region<'tcx>) -> rustc_middle::ty::Region<'tcx> {
        match r.kind() {
            rustc_middle::ty::ReErased => {
                let var = self.current_var;
                self.current_var += 1;

                rustc_middle::ty::Region::new_bound(
                    self.tcx,
                    self.current_index,
                    BoundRegion { var: BoundVar::from_usize(var), kind: BoundRegionKind::Anon },
                )
            }
            rustc_middle::ty::ReBound(BoundVarIndexKind::Bound(debruijn), _br) => {
                assert!(debruijn < self.current_index);
                r
            }
            _ => r,
        }
    }
}

enum VerusCaptureKind<'tcx> {
    DummyCapture,
    ArgToMagicFn,
    FakeRead((Place<'tcx>, FakeReadCause, HirId)),
}

/// Create the type signature of the 'magic coercion function' described above
fn mk_closure_magic_coercion_fn<'tcx, 'a>(
    tcx: TyCtxt<'tcx>,
    rust_captured_places: &[&CapturedPlace<'tcx>],
    verus_captured_places: &[&CapturedPlace<'tcx>],
    rust_fake_reads: &Vec<(Place<'tcx>, FakeReadCause, HirId)>,
    expected_tys: &[Ty<'tcx>],
    upvar_dc_idx: usize,
    ty_dc_idx: usize,
) -> (Ty<'tcx>, Vec<VerusCaptureKind<'tcx>>) {
    // The general form of the type signature is going to be
    // for<'a, 'b, ...> fn(A, B, ...) -> (X, Y, ...)
    // where the inputs corresponds to Verus captures (minus the DummyCapture)
    // and the outputs correspond to Rust captures

    // Go through the types of each Rust capture and replace free region variables
    // with bound variables.
    let mut replacer = ReErasedReplacer::new(tcx);
    let mut output_tys = vec![];
    for ty in expected_tys.iter() {
        let t = ty.fold_with(&mut replacer);
        output_tys.push(t);
    }

    // As explained above, we may need to use the lifetime variable of the dummy capture argument
    let dc_default_region = match output_tys[ty_dc_idx].kind() {
        TyKind::Ref(region, _, _) => *region,
        TyKind::Adt(_, args) => args[0].as_region().unwrap(),
        _ => panic!("ty_dc_idx should have given DummyCapture type"),
    };

    let mut input_tys = vec![];
    let mut kinds = vec![];
    for (i, verus_captured_place) in verus_captured_places.iter().enumerate() {
        if i == upvar_dc_idx {
            kinds.push(VerusCaptureKind::DummyCapture);
            continue;
        }

        // For each input, find the corresponding output, which should be some ancestor.
        // E.g., if the input is `x.a.b.c`, the corresponding output might be `x.a`.
        //
        // Since Verus captures can only be more precise than Rust captures, the corresponding
        // Rust capture should always exist UNLESS it was a fake read in the Rust capture set.

        let idx_opt = rust_captured_places.iter().position(|rust_captured_place| {
            is_ancestor(&rust_captured_place.place, &verus_captured_place.place)
        });
        if let Some(idx) = idx_opt {
            // Case: we found the ancestor in the capture set

            let output_ty = output_tys[idx];
            let rust_captured_place = &rust_captured_places[idx];

            // Now apply the projections to get the input type.

            let output_uses_ref = match rust_captured_place.info.capture_kind {
                UpvarCapture::ByRef(_borrow_kind) => true,
                _ => false,
            };
            let (output_ty_no_ref, region_opt) = if output_uses_ref {
                match output_ty.kind() {
                    TyKind::Ref(r, t, _mutability) => (*t, Some(*r)),
                    _ => panic!("Expected type to be a reference"),
                }
            } else {
                (output_ty, None)
            };

            let mut input_ty = output_ty_no_ref;
            for proj in verus_captured_place.place.projections
                [rust_captured_place.place.projections.len()..]
                .iter()
            {
                input_ty = apply_projection(tcx, proj, input_ty);
            }

            let input_ty = match &verus_captured_place.info.capture_kind {
                UpvarCapture::ByValue | UpvarCapture::ByUse => input_ty,
                UpvarCapture::ByRef(kind) => {
                    let region = match region_opt {
                        Some(r) => r,
                        None => dc_default_region,
                    };
                    Ty::new_ref(tcx, region, input_ty, kind.to_mutbl_lossy())
                }
            };

            kinds.push(VerusCaptureKind::ArgToMagicFn);
            input_tys.push(input_ty);
        } else {
            // Case: we didn't find any ancestor in the capture set.
            // In this case there should be a fake read from the Rust capture set.

            // Check this assumption:
            let found_fake_read = rust_fake_reads
                .iter()
                .position(|(place, _, _)| is_ancestor(place, &verus_captured_place.place));
            if found_fake_read.is_none() {
                panic!(
                    "Verus captured place doesn't correspond to Rust captured place or fake read"
                );
            }
            let idx = found_fake_read.unwrap();
            let (_, cause, hir_id) = rust_fake_reads[idx];

            kinds.push(VerusCaptureKind::FakeRead((
                verus_captured_place.place.clone(),
                cause,
                hir_id,
            )));
        }
    }

    // Wrap it all up into a FnPtr type

    let output_ty = Ty::new_tup(tcx, &output_tys);
    let inputs_and_output =
        tcx.mk_type_list_from_iter(input_tys.iter().cloned().chain(std::iter::once(output_ty)));

    let mut bound_var_kinds = vec![];
    for _i in 0..replacer.current_var {
        bound_var_kinds.push(BoundVariableKind::Region(BoundRegionKind::Anon));
    }
    let bound_var_kinds = tcx.mk_bound_variable_kinds(&bound_var_kinds);

    let fnty = tcx.mk_ty_from_kind(TyKind::FnPtr(
        Binder::bind_with_vars(rustc_middle::ty::FnSigTys { inputs_and_output }, bound_var_kinds),
        rustc_middle::ty::FnHeader {
            fn_sig_kind: FnSigKind::new(
                rustc_abi::ExternAbi::Rust,
                rustc_hir::Safety::Safe,
                false,
                None,
                input_tys.len(),
            )
            .expect("valid signature"),
        },
    ));

    (fnty, kinds)
}

pub(crate) fn apply_projection<'tcx>(
    tcx: TyCtxt<'tcx>,
    projection: &Projection<'tcx>,
    ty: Ty<'tcx>,
) -> Ty<'tcx> {
    match &projection.kind {
        ProjectionKind::Deref => match ty.kind() {
            TyKind::Ref(_, ty, _) => *ty,
            TyKind::Adt(adt, args) if Some(adt.did()) == tcx.lang_items().owned_box() => {
                args[0].as_type().unwrap()
            }
            _ => {
                panic!("apply_projection: unexpected type");
            }
        },
        ProjectionKind::Field(field_idx, variant_idx) => match ty.kind() {
            TyKind::Tuple(tys) => tys[field_idx.as_usize()],
            TyKind::Adt(adt, args) =>
            // TODO(1.97.1): do we need to normalize here?
            {
                adt.variant(*variant_idx).fields[*field_idx].ty(tcx, args).skip_normalization()
            }
            _ => {
                panic!("apply_projection: unexpected type");
            }
        },
        _ => {
            panic!("apply_projection: unexpected projection");
        }
    }
}

fn is_ancestor<'tcx>(p1: &Place<'tcx>, p2: &Place<'tcx>) -> bool {
    let Place { base_ty: _, base: b1, projections: proj1 } = p1;
    let Place { base_ty: _, base: b2, projections: proj2 } = p2;
    b1 == b2 && proj1.len() <= proj2.len() && proj1[..] == proj2[..proj1.len()]
}

fn captures_subtract<'tcx>(
    c1: &'tcx rustc_middle::ty::List<&'tcx CapturedPlace<'tcx>>,
    c2: &'tcx rustc_middle::ty::List<&'tcx CapturedPlace<'tcx>>,
) -> Vec<&'tcx CapturedPlace<'tcx>> {
    let mut v = vec![];
    for c in c1.iter() {
        if !c2.iter().any(|d| is_ancestor(&d.place, &c.place)) {
            v.push(c);
        }
    }
    v
}

pub(crate) fn possibly_handle_complex_closure_block<'tcx>(
    cx: &mut ThirBuildCx<'tcx>,
    block: &'tcx hir::Block<'tcx>,
) -> Option<BlockId> {
    // Check if this block has the form
    // { let _verus_internal_dummy_capture = ::builtin::dummy_capture_new(); || { ... } }

    let Some(erasure_ctxt) = cx.verus_ctxt.ctxt.clone() else {
        return None;
    };

    if !(block.stmts.len() == 1 && block.expr.is_some()) {
        return None;
    }
    let rustc_hir::StmtKind::Let(let_stmt) = &block.stmts[0].kind else {
        return None;
    };
    let Some(let_stmt_init) = &let_stmt.init else {
        return None;
    };

    let let_ty = cx.typeck_results.expr_ty(let_stmt_init);
    if !ty_is_dummy_capture(&erasure_ctxt, let_ty) {
        return None;
    }

    let expr = get_closure_expr(&block.expr.unwrap());
    let rustc_hir::ExprKind::Closure(_closure) = &expr.kind else {
        return None;
    };

    let tcx = cx.tcx;

    let closure_ty = cx.typeck_results.expr_ty(expr);
    let (def_id, args, _movability) = match *closure_ty.kind() {
        ty::Closure(def_id, args) => (def_id, UpvarArgs::Closure(args), None),
        ty::Coroutine(def_id, args) => {
            (def_id, UpvarArgs::Coroutine(args), Some(tcx.coroutine_movability(def_id)))
        }
        ty::CoroutineClosure(def_id, args) => (def_id, UpvarArgs::CoroutineClosure(args), None),
        _ => {
            panic!("closure expr w/o closure type: {:?}", closure_ty);
        }
    };
    let def_id = def_id.expect_local();

    // generate the coercion

    let rust_closure_captures = cx.tcx.closure_captures(def_id);
    let emp = vec![];
    let rust_fake_reads = cx.typeck_results.closure_fake_reads.get(&def_id).unwrap_or(&emp);
    let rust_upvar_tys = args.upvar_tys();

    let (verus_closure_captures, verus_upvar_tys, verus_fake_reads) =
        crate::verus::get_closure_captures_accounting_for_ghost(cx, expr, def_id, false);

    let mut stmts = vec![];

    if cx.verus_ctxt.do_time_travel_prevention {
        // Compute all captures *including* shadow captures. For any place which is
        // shadow-captured but not actually captured, we emit an extra use here.
        let (verus_closure_captures_shadow, _verus_upvar_tys_shadow, _verus_fake_reads_shadow) =
            crate::verus::get_closure_captures_accounting_for_ghost(cx, expr, def_id, true);
        let verus_closure_captures_shadow =
            captures_subtract(&verus_closure_captures_shadow, &verus_closure_captures);
        for capt in verus_closure_captures_shadow.iter() {
            let var_hir_id = match capt.place.base {
                crate::expr_use_visitor::PlaceBase::Upvar(upvar_id) => upvar_id.var_path.hir_id,
                _ => panic!("Verus internal error: Expected an Upvar"),
            };
            if cx.is_upvar(var_hir_id) {
                continue;
            }
            if crate::verus_expr::is_bound_via_pattern_guard(cx, var_hir_id) {
                continue;
            }
            let place_expr = cx.convert_captured_hir_place(expr, capt.place.clone());
            let place_expr = cx.thir.exprs.push(place_expr);
            let shadow_place = crate::verus_time_travel_prevention::shadow_place(
                cx,
                expr.hir_id,
                expr.span,
                place_expr,
            );
            if let Some(shadow_place) = shadow_place {
                stmts.push(crate::verus_time_travel_prevention::shadow_use_stmt(
                    cx,
                    &erasure_ctxt,
                    expr,
                    shadow_place,
                ));
            }
        }
    }

    assert!(verus_fake_reads.len() == 0);

    let verus_upvars = verus_closure_captures
        .iter()
        .zip_eq(verus_upvar_tys.iter())
        .map(|(captured_place, ty)| {
            let upvars = cx.capture_upvar(expr, captured_place, *ty);
            cx.thir.exprs.push(upvars)
        })
        .collect::<Vec<_>>();

    let upvar_dc_idx = get_upvar_dummy_capture_idx(cx, &erasure_ctxt, &verus_upvars);
    let ty_dc_idx = get_ty_dummy_capture_idx(&erasure_ctxt, rust_upvar_tys);

    let (coercion_fn_ty, verus_capture_kinds) = mk_closure_magic_coercion_fn(
        cx.tcx,
        rust_closure_captures,
        verus_closure_captures,
        rust_fake_reads,
        &rust_upvar_tys,
        upvar_dc_idx,
        ty_dc_idx,
    );

    let mut magic_fn_args = vec![];
    let mut verus_fake_reads_final = vec![];
    for (i, k) in verus_capture_kinds.iter().enumerate() {
        match k {
            VerusCaptureKind::DummyCapture => {}
            VerusCaptureKind::ArgToMagicFn => {
                magic_fn_args.push(verus_upvars[i]);
            }
            VerusCaptureKind::FakeRead((place, cause, hir_id)) => {
                let expr = cx.convert_captured_hir_place(expr, place.clone());
                let fake_read = (cx.thir.exprs.push(expr), *cause, *hir_id);
                verus_fake_reads_final.push(fake_read);
            }
        }
    }

    let rust_upvar_tys_tuple = Ty::new_tup(tcx, &rust_upvar_tys);
    let call_result = make_fake_call(
        cx,
        &erasure_ctxt,
        expr.hir_id,
        expr.span,
        coercion_fn_ty,
        magic_fn_args,
        rust_upvar_tys_tuple,
    );
    let (dc_id, stmt) = make_let(cx, &block.stmts[0], block.hir_id.local_id, call_result);

    let mut forged_upvars = vec![];
    for i in 0..rust_upvar_tys.len() {
        forged_upvars.push(make_dc_tuple_index(
            cx,
            expr.span,
            expr.hir_id,
            rust_upvar_tys_tuple,
            rust_upvar_tys[i],
            dc_id,
            i,
        ));
    }

    // Store the computed ClosureKind in a map, then recurse.
    // The walk will pick up the new ClosureKind when we get there
    set_override_closure_kind(
        cx,
        def_id,
        (forged_upvars.into_boxed_slice(), verus_fake_reads_final),
    );
    let expr = cx.mirror_expr(block.expr.unwrap());

    stmts.push(stmt);
    let block = Block {
        targeted_by_break: false,
        region_scope: region::Scope {
            local_id: block.hir_id.local_id,
            data: region::ScopeData::Node,
        },
        span: block.span,
        stmts: stmts.into_boxed_slice(),
        expr: Some(expr),
        safety_mode: BlockSafety::Safe,
    };

    Some(cx.thir.blocks.push(block))
}

pub(crate) fn get_closure_expr<'tcx>(e: &'tcx hir::Expr<'tcx>) -> &'tcx hir::Expr<'tcx> {
    // NOTE: We expect every closuse to have exactly this form:
    //
    // {
    //     let _verus_internal_dummy_capture = ::builtin::dummy_capture_new();
    //     || { ... }
    // }
    //
    // This function is invoked when we detect the capture dummy, and tries
    // to find the corresponding closure expression. If there are any other
    // statements in the block, this function will fail.

    match &e.kind {
        hir::ExprKind::Closure(_) => e,
        hir::ExprKind::Call(_f, args) => get_closure_expr(&args[0]),
        _ => panic!("get_closure_expr failed"),
    }
}

/// Generate a fake function call by using 'erased_ghost_value' to create the *function*
/// then call the function.
pub(crate) fn make_fake_call<'tcx>(
    cx: &mut ThirBuildCx<'tcx>,
    erasure_ctxt: &VerusErasureCtxt,
    hir_id: HirId,
    span: Span,
    fn_ty: Ty<'tcx>,
    args: Vec<ExprId>,
    result_ty: Ty<'tcx>,
) -> ExprId {
    let kind = make_fake_call_kind(cx, erasure_ctxt, hir_id, span, fn_ty, args);
    expr_id_from_kind(cx, kind, hir_id, span, result_ty)
}

pub(crate) fn make_fake_call_kind<'tcx>(
    cx: &mut ThirBuildCx<'tcx>,
    erasure_ctxt: &VerusErasureCtxt,
    hir_id: HirId,
    span: Span,
    fn_ty: Ty<'tcx>,
    args: Vec<ExprId>,
) -> ExprKind<'tcx> {
    let f = erased_ghost_value(cx, erasure_ctxt, hir_id, span, fn_ty);

    ExprKind::Call {
        ty: fn_ty,
        fun: f,
        args: args.into_boxed_slice(),
        from_hir_call: false,
        fn_span: span,
    }
}

pub(crate) fn make_let<'tcx>(
    cx: &mut ThirBuildCx<'tcx>,
    stmt: &rustc_hir::Stmt,
    block_id: hir::ItemLocalId,
    e: ExprId,
) -> (LocalVarId, StmtId) {
    let hir::StmtKind::Let(let_stmt) = &stmt.kind else {
        panic!("expected Let");
    };
    let ident = match &let_stmt.pat.kind {
        hir::PatKind::Binding(_, _, ident, _) => ident,
        _ => panic!("expected Binding"),
    };

    let ty = cx.thir.exprs[e].ty;
    let var = LocalVarId(let_stmt.pat.hir_id);
    let pattern = Box::new(Pat {
        ty: ty,
        span: stmt.span,
        kind: PatKind::Binding {
            name: ident.name,
            mode: rustc_hir::BindingMode(rustc_hir::ByRef::No, Mutability::Not),
            var,
            ty,
            subpattern: None,
            is_primary: true,
            is_shorthand: false,
        },
        extra: None,
    });

    let remainder_scope = region::Scope {
        local_id: block_id,
        data: region::ScopeData::Remainder(region::FirstStatementIndex::new(0)),
    };
    let stmt = Stmt {
        kind: StmtKind::Let {
            hir_id: let_stmt.hir_id,
            remainder_scope,
            init_scope: region::Scope {
                local_id: stmt.hir_id.local_id,
                data: region::ScopeData::Node,
            },
            pattern,
            initializer: Some(e),
            else_block: None,
            span: stmt.span,
        },
    };
    let stmt = cx.thir.stmts.push(stmt);
    (var, stmt)
}

pub(crate) fn make_dc_tuple_index<'tcx>(
    cx: &mut ThirBuildCx<'tcx>,
    span: Span,
    hir_id: HirId,
    tup_ty: Ty<'tcx>,
    my_ty: Ty<'tcx>,
    id: LocalVarId,
    idx: usize,
) -> ExprId {
    let kind = ExprKind::VarRef { id };
    let e = expr_id_from_kind(cx, kind, hir_id, span, tup_ty);

    let kind = ExprKind::Field {
        lhs: e,
        variant_index: rustc_abi::VariantIdx::from_usize(0),
        name: rustc_abi::FieldIdx::from_usize(idx),
    };
    expr_id_from_kind(cx, kind, hir_id, span, my_ty)
}

fn ty_is_dummy_capture<'tcx>(erasure_ctxt: &VerusErasureCtxt, ty: Ty<'tcx>) -> bool {
    match ty.kind() {
        TyKind::Adt(adt_def, _) => {
            if adt_def.did() == erasure_ctxt.dummy_capture_struct_def_id {
                return true;
            }
        }
        _ => {}
    }
    false
}

fn ty_is_dummy_capture_or_ref<'tcx>(erasure_ctxt: &VerusErasureCtxt, ty: Ty<'tcx>) -> bool {
    let ty = match ty.kind() {
        TyKind::Ref(_region, ty, _mutability) => *ty,
        _ => ty,
    };
    ty_is_dummy_capture(erasure_ctxt, ty)
}

fn get_upvar_dummy_capture_idx<'tcx>(
    cx: &ThirBuildCx<'tcx>,
    erasure_ctxt: &VerusErasureCtxt,
    upvars: &Vec<ExprId>,
) -> usize {
    for i in 0..upvars.len() {
        let ty = cx.thir.exprs[upvars[i]].ty;
        if ty_is_dummy_capture_or_ref(erasure_ctxt, ty) {
            return i;
        }
    }
    panic!("MISSING DummyCapture (upvar)");
}

fn get_ty_dummy_capture_idx<'tcx>(erasure_ctxt: &VerusErasureCtxt, tys: &'tcx [Ty<'tcx>]) -> usize {
    for i in 0..tys.len() {
        let ty = tys[i];
        if ty_is_dummy_capture_or_ref(erasure_ctxt, ty) {
            return i;
        }
    }
    panic!("MISSING DummyCapture (ty)");
}
