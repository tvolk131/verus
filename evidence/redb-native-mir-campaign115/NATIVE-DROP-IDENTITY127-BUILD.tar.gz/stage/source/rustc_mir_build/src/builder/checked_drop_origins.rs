use rustc_hir::HirId;
use rustc_hir::def_id::LocalDefId;
use rustc_middle::middle::region::{Scope, TempLifetime};
use rustc_middle::mir::Local;
use rustc_middle::thir::{ExprId, ExprKind};
use std::collections::HashMap;
use std::sync::Mutex;
use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};

static ENABLED: AtomicBool = AtomicBool::new(false);
static NATIVE: AtomicBool = AtomicBool::new(false);
static ORIGINS: Mutex<Option<HashMap<LocalDefId, Vec<(HirId, Local)>>>> = Mutex::new(None);
static TEMPORARIES: Mutex<Option<HashMap<LocalDefId, TemporaryCapture>>> = Mutex::new(None);
static THIR_SCOPES: Mutex<Option<ThirScopeTable>> = Mutex::new(None);
static NEXT_SCOPE_SESSION: AtomicU64 = AtomicU64::new(1);

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct ThirScopeSession {
    pub generation: u64,
    pub native: bool,
}

#[derive(Clone, Debug)]
pub struct ThirScopeEdge {
    pub scope_expression: ExprId,
    pub value_expression: ExprId,
    pub hir_id: HirId,
    pub region_scope: Scope,
}

#[derive(Clone, Debug)]
pub struct ThirScopeCapture {
    pub session: ThirScopeSession,
    pub body: LocalDefId,
    pub complete: bool,
    pub expression_count: Option<usize>,
    pub edges: Vec<ThirScopeEdge>,
}

struct ThirScopeTable {
    session: ThirScopeSession,
    bodies: HashMap<LocalDefId, ThirScopeCapture>,
}

#[derive(Clone, Debug, Default)]
pub struct TemporaryCapture {
    pub complete: bool,
    pub origins: Vec<TemporaryOrigin>,
}

#[derive(Clone, Debug)]
pub struct TemporaryOrigin {
    pub expression: ExprId,
    pub local: Local,
    pub temp_lifetime: TempLifetime,
    pub scope: Option<TemporaryScope>,
}

#[derive(Clone, Debug)]
pub struct TemporaryScope {
    pub hir_id: HirId,
    pub nested_expression: ExprId,
    pub region_scope: Scope,
}

pub fn begin(native: bool) {
    *ORIGINS.lock().unwrap() = Some(HashMap::new());
    *TEMPORARIES.lock().unwrap() = Some(HashMap::new());
    *THIR_SCOPES.lock().unwrap() = Some(ThirScopeTable {
        session: ThirScopeSession {
            generation: NEXT_SCOPE_SESSION.fetch_update(
                Ordering::SeqCst, Ordering::SeqCst, |generation| generation.checked_add(1),
            ).expect("THIR scope diagnostic session counter exhausted"),
            native,
        },
        bodies: HashMap::new(),
    });
    NATIVE.store(native, Ordering::SeqCst);
    ENABLED.store(true, Ordering::SeqCst);
}

pub fn native() -> bool {
    NATIVE.load(Ordering::SeqCst)
}

pub fn get(def: LocalDefId) -> Option<Vec<(HirId, Local)>> {
    ORIGINS.lock().unwrap().as_ref()?.get(&def).cloned()
}

pub fn get_temporaries(def: LocalDefId) -> Option<TemporaryCapture> {
    TEMPORARIES.lock().unwrap().as_ref()?.get(&def).cloned()
}

pub fn thir_scope_session() -> Option<ThirScopeSession> {
    Some(THIR_SCOPES.lock().unwrap().as_ref()?.session)
}

pub fn get_thir_scopes(def: LocalDefId) -> Option<ThirScopeCapture> {
    THIR_SCOPES.lock().unwrap().as_ref()?.bodies.get(&def).cloned()
}

fn note_thir_scope_body(def: LocalDefId) {
    let mut scopes = THIR_SCOPES.lock().unwrap();
    let scopes = scopes.as_mut().unwrap();
    let session = scopes.session;
    scopes.bodies.entry(def).or_insert_with(|| ThirScopeCapture {
        session,
        body: def,
        complete: false,
        expression_count: None,
        edges: Vec::new(),
    });
}

pub(super) fn retain_temporary(
    def: LocalDefId, expression: ExprId, local: Local, temp_lifetime: TempLifetime,
) {
    if !ENABLED.load(Ordering::SeqCst) {
        return;
    }
    note_thir_scope_body(def);
    TEMPORARIES.lock().unwrap().as_mut().unwrap().entry(def).or_default()
        .origins.push(TemporaryOrigin { expression, local, temp_lifetime, scope: None });
}

pub(super) fn retain_temporary_scope(
    def: LocalDefId,
    expression: ExprId,
    nested_expression: ExprId,
    local: Local,
    hir_id: HirId,
    region_scope: Scope,
    temp_lifetime: TempLifetime,
) {
    if !ENABLED.load(Ordering::SeqCst) {
        return;
    }
    note_thir_scope_body(def);
    TEMPORARIES.lock().unwrap().as_mut().unwrap().entry(def).or_default()
        .origins.push(TemporaryOrigin {
            expression,
            local,
            temp_lifetime,
            scope: Some(TemporaryScope { hir_id, nested_expression, region_scope }),
        });
}

pub(super) fn retain(builder: &super::Builder<'_, '_>) {
    if !ENABLED.load(Ordering::SeqCst) {
        return;
    }
    let origins = builder.var_indices.iter().filter_map(|(var, locals)| {
        match locals {
            super::LocalsForNode::One(local) => Some((var.0, *local)),
            super::LocalsForNode::ForGuard { .. } => None,
        }
    }).collect();
    let previous = ORIGINS.lock().unwrap().as_mut().unwrap().insert(builder.def_id, origins);
    assert!(previous.is_none());
    TEMPORARIES.lock().unwrap().as_mut().unwrap().entry(builder.def_id).or_default()
        .complete = true;
    let edges = builder.thir.exprs.iter_enumerated().filter_map(|(scope_expression, expression)| {
        let ExprKind::Scope { value, hir_id, region_scope } = expression.kind else {
            return None;
        };
        Some(ThirScopeEdge {
            scope_expression,
            value_expression: value,
            hir_id,
            region_scope,
        })
    }).collect();
    let mut scopes = THIR_SCOPES.lock().unwrap();
    let scopes = scopes.as_mut().unwrap();
    let session = scopes.session;
    scopes.bodies.insert(builder.def_id, ThirScopeCapture {
        session,
        body: builder.def_id,
        complete: true,
        expression_count: Some(builder.thir.exprs.len()),
        edges,
    });
}
