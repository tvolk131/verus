use rustc_hir::attrs::lang_items::LangItem;
use rustc_hir::def::DefKind;
use rustc_hir::def_id::{DefId, LocalDefId};
use rustc_middle::mir::{Body, TerminatorKind};
use rustc_middle::ty::{self, Instance, InstanceKind, ShimKind, Ty, TyCtxt, TypeVisitableExt};
use serde_json::{Value, json};
use std::fs::{File, OpenOptions};
use std::io::{self, Write};
use std::path::{Path, PathBuf};
use std::sync::Mutex;

const OWNER: &str = "tree_store::page_store::page_manager::TransactionalMemory::write_header";
const ADT: &str = "tree_store::page_store::cached_file::WritablePage";
const OWNER_HASH: &str = "DefPathHash(Fingerprint(10476043313273028918, 2904618018494555106))";
const ORIGINAL: &str = "/private/tmp/redb-original-crate-preflight115/redb/src/tree_store/page_store";

#[derive(Clone)]
struct Paths {
    raw: PathBuf,
    started: PathBuf,
    sidecar: PathBuf,
}

#[derive(Clone)]
struct Site {
    adt: Option<DefId>,
    checked_empty_args: bool,
    context: Value,
}

#[derive(Clone)]
struct Capture {
    owner: LocalDefId,
    ordinal: usize,
    sites: Vec<Site>,
}

struct Diagnostic {
    paths: Paths,
    captures: Vec<Capture>,
    compiler_argv: Vec<String>,
    status: Value,
    io_failed: bool,
}

static DIAGNOSTIC: Mutex<Option<Diagnostic>> = Mutex::new(None);

fn stage(path: &Path) -> PathBuf {
    path.parent().unwrap().join(format!(
        ".{}.candidate123-stage-{}", path.file_name().unwrap().to_string_lossy(),
        std::process::id(),
    ))
}

fn fresh(path: &Path) -> io::Result<()> {
    if !path.is_absolute() || path.extension().is_none_or(|extension| extension != "json") {
        return Err(io::Error::other("absolute fresh JSON path required"));
    }
    let parent = path.parent().ok_or_else(|| io::Error::other("missing parent"))?;
    if parent.canonicalize()?.as_path() != parent {
        return Err(io::Error::other("noncanonical or symlinked parent"));
    }
    match path.symlink_metadata() {
        Err(error) if error.kind() == io::ErrorKind::NotFound => Ok(()),
        _ => Err(io::Error::other("output or symlink already exists")),
    }
}

pub fn configure(arguments: &[String], report: &Path, report_stage: &Path) -> io::Result<()> {
    if arguments.len() == 10 {
        return Ok(());
    }
    if arguments.len() != 14 || arguments[10] != "--raw-before-query"
        || arguments[12] != "--identity-sidecar" {
        return Err(io::Error::other("only the two ordered explicit identity paths are accepted"));
    }
    let raw = PathBuf::from(&arguments[11]);
    let sidecar = PathBuf::from(&arguments[13]);
    let started = sidecar.with_file_name(format!(
        "{}.started.json", sidecar.file_stem().unwrap_or_default().to_string_lossy(),
    ));
    let paths = Paths { raw, started, sidecar };
    let mut names = vec![report.to_path_buf(), report_stage.to_path_buf()];
    for path in [&paths.raw, &paths.started, &paths.sidecar] {
        fresh(path)?;
        let staging = stage(path);
        match staging.symlink_metadata() {
            Err(error) if error.kind() == io::ErrorKind::NotFound => {},
            _ => return Err(io::Error::other("staging exists; reuse forbidden")),
        }
        names.push(path.clone());
        names.push(staging);
    }
    for (index, path) in names.iter().enumerate() {
        if names[index + 1..].contains(path) {
            return Err(io::Error::other("aliased report/raw/started/sidecar/staging paths"));
        }
    }
    *DIAGNOSTIC.lock().unwrap() = Some(Diagnostic {
        paths, captures: Vec::new(), compiler_argv: Vec::new(), io_failed: false,
        status: json!({
            "mode": "EXPLICIT_DIAGNOSTIC_IDENTITY_ONLY",
            "selection": "PENDING",
            "raw_persistence": "NOT_ATTEMPTED",
            "refusal": "NATIVE_PROOF_REFUSED_NOT_YET_DURABLE",
            "query_started": "NOT_STARTED",
            "glue": {"status": "NOT_QUERIED"},
            "glue_resolver_invocations": 0,
            "destructor": {"status": "NOT_QUERIED"},
            "destructor_instance": "NOT_REQUESTED",
            "partial": "INCOMPLETE",
            "errors": "NOT_OBSERVED",
            "compiler_completion": "PENDING",
            "sidecar_publication": "NOT_ATTEMPTED",
            "proof_acceptance": false,
            "native_resource_correspondence": false,
            "hir_vir_mapping_approved": false,
            "all18": "OPEN", "native_credit": 0, "resource_credit": 0, "trust_credit": 0,
        }),
    });
    Ok(())
}

pub fn enabled() -> bool {
    DIAGNOSTIC.lock().unwrap().is_some()
}

pub fn compiler_arguments(arguments: &[String]) {
    if let Some(diagnostic) = DIAGNOSTIC.lock().unwrap().as_mut() {
        diagnostic.compiler_argv = arguments.to_vec();
    }
}

pub fn capture(owner: LocalDefId, body: &Body<'_>, raw: &Value) {
    if !enabled() {
        return;
    }
    let sites = body.basic_blocks.iter_enumerated().filter_map(|(block, data)| {
        let TerminatorKind::Drop { place, .. } = &data.terminator().kind else {
            return None;
        };
        let (adt, checked_empty_args) = match *body.local_decls[place.local].ty.kind() {
            ty::Adt(definition, args) => (Some(definition.did()), args.is_empty()),
            _ => (None, false),
        };
        let context = json!({
            "block": block.as_usize(), "local": place.local.as_usize(),
            "empty_projection": place.projection.is_empty(),
            "phase": raw["mir_phase"], "native": raw["native_capture_phase"],
            "scope_capture": raw["thir_scope_capture"],
            "site_records": raw["drops"].as_array().map(|drops| drops.iter()
                .filter(|site| site["block"] == json!(block.as_usize()))
                .cloned().collect::<Vec<_>>()),
        });
        Some(Site { adt, checked_empty_args, context })
    }).collect();
    let mut guard = DIAGNOSTIC.lock().unwrap();
    let diagnostic = guard.as_mut().unwrap();
    let ordinal = diagnostic.captures.len();
    diagnostic.captures.push(Capture { owner, ordinal, sites });
}

fn change(update: impl FnOnce(&mut Value)) {
    let mut guard = DIAGNOSTIC.lock().unwrap();
    update(&mut guard.as_mut().unwrap().status);
}

fn error_state(tcx: TyCtxt<'_>) -> Value {
    json!({
        "emitted_errors": tcx.dcx().has_errors().is_some(),
        "errors_or_delayed_bugs": tcx.dcx().has_errors_or_delayed_bugs().is_some(),
        "compiler_outcome": "PENDING",
        "clean_absence_permitted": false,
    })
}

fn tokens(captures: &[Capture]) -> Value {
    json!(captures.iter().map(|capture| json!({
        "owner_same_session": format!("{:?}", capture.owner),
        "capture_ordinal": capture.ordinal,
        "sites": capture.sites.iter().map(|site| json!({
            "adt_same_session": site.adt.map(|definition| format!("{definition:?}")),
            "checked_empty_args": site.checked_empty_args,
            "context": site.context,
        })).collect::<Vec<_>>(),
    })).collect::<Vec<_>>())
}

fn select(raw: &Value, captures: &[Capture]) -> &'static str {
    if raw["target_definition"] != OWNER || raw["selected_definitions"] != json!([OWNER]) {
        return "WRONG_OR_AMBIGUOUS_OWNER";
    }
    if raw["explicit_selected_query_requests"] != 1 || captures.len() != 1
        || raw["captures"].as_array().is_none_or(|values| values.len() != 1) {
        return "INCOMPLETE_OR_EXTRA_TYPED_CAPTURE";
    }
    let entry = &raw["captures"][0];
    if entry["def_path"] != OWNER || entry["def_path_hash"] != OWNER_HASH
        || !entry["definition_span"].as_str().is_some_and(|span|
            span.starts_with(&format!("{ORIGINAL}/page_manager.rs:1617:5:")))
        || entry["mir_phase"] != "Runtime(PostCleanup)" || entry["native_capture_phase"] != true
        || entry["temporary_capture_complete"] != true {
        return "OWNER_PHASE_OR_CAPTURE_MISMATCH";
    }
    let scope = &entry["thir_scope_capture"];
    if scope["complete"] != true || scope["current_session_native_phase"] != true
        || scope["capture_native_phase"] != true
        || scope["current_session_generation"].is_null()
        || scope["current_session_generation"] != scope["capture_session_generation"]
        || scope["expected_body"] != scope["capture_body"]
        || !matches!(scope["status"].as_str(), Some("COMPLETE_EMPTY" | "COMPLETE_NONEMPTY")) {
        return "INCOMPLETE_OR_MISMATCHED_SCOPE_CAPTURE";
    }
    let capture = &captures[0];
    let Some(drops) = entry["drops"].as_array() else { return "MISSING_SITES" };
    if drops.len() != 2 || capture.sites.len() != 2 {
        return "PARTIAL_OR_EXTRA_SITES";
    }
    for (block, cleanup, target, unwind) in [
        (16, false, 17, "Cleanup(bb20)"), (19, true, 20, "Terminate(InCleanup)"),
    ] {
        let matching = drops.iter().filter(|site| site["block"] == block).collect::<Vec<_>>();
        if matching.len() != 1 { return "PARTIAL_OR_DUPLICATE_SITES"; }
        let site = matching[0];
        let origins = site["matching_temporary_observations"].as_array();
        if site["cleanup"] != cleanup || site["normal_target"] != target
            || site["unwind"] != unwind || site["local"] != 20 || site["place"] != "_20"
            || site["projection"] != "[]" || site["root_type"] != ADT
            || site["replace_assignment_origin"] != false
            || !site["async_cancellation_cleanup_target"].is_null()
            || origins.is_none_or(|values| values.len() != 1
                || values[0]["expression"] != "e78" || values[0]["local"] != 20) {
            return "TYPE_PLACE_OR_SITE_MISMATCH";
        }
        let typed = capture.sites.iter().filter(|site| site.context["block"] == block)
            .collect::<Vec<_>>();
        if typed.len() != 1 || typed[0].adt.is_none() || !typed[0].checked_empty_args
            || typed[0].context["empty_projection"] != true
            || typed[0].context["site_records"] != json!([site]) {
            return "UNSUPPORTED_OR_MISMATCHED_TYPED_CAPTURE";
        }
    }
    if capture.sites[0].adt != capture.sites[1].adt {
        return "SITE_ADT_IDENTITY_MISMATCH";
    }
    "EXACT_TWO_DISTINCT_CFG_CONTEXTS"
}

fn publish(path: &Path, value: &Value) -> io::Result<Vec<u8>> {
    fresh(path)?;
    let staging = stage(path);
    let bytes = serde_json::to_vec_pretty(value).map_err(io::Error::other)?;
    let mut output = OpenOptions::new().write(true).create_new(true).open(&staging)?;
    output.write_all(&bytes)?;
    output.flush()?;
    output.sync_all()?;
    drop(output);
    std::fs::hard_link(&staging, path)?;
    File::open(path.parent().unwrap())?.sync_all()?;
    if std::fs::read(path)? != bytes {
        return Err(io::Error::other("published snapshot readback mismatch"));
    }
    Ok(bytes)
}

fn definition(tcx: TyCtxt<'_>, did: DefId) -> Value {
    let span = tcx.def_span(did);
    let location = tcx.sess.source_map().lookup_char_pos(span.lo());
    json!({
        "same_session_def_id": format!("{did:?}"),
        "def_path": tcx.def_path_str(did),
        "def_path_hash": format!("{:?}", tcx.def_path_hash(did)),
        "span": format!("{span:?}"),
        "local": did.is_local(),
        "source_file": location.file.name.prefer_local_unconditionally().to_string(),
        "source_line": location.line,
    })
}

fn at_source(record: &Value, file: &str, line: usize) -> bool {
    record["local"] == true && record["source_file"] == format!("{ORIGINAL}/{file}")
        && record["source_line"] == line
}

fn resolve(tcx: TyCtxt<'_>, capture: &Capture) {
    change(|status| status["query_stage"] = json!("SOURCE_OWNED_ADT_VALIDATION"));
    let owner = definition(tcx, capture.owner.to_def_id());
    let adt_did = capture.sites[0].adt.unwrap();
    let adt_identity = definition(tcx, adt_did);
    change(|status| {
        status["owner"] = owner.clone(); status["adt"] = adt_identity.clone();
    });
    if owner["def_path"] != OWNER || owner["def_path_hash"] != OWNER_HASH
        || !at_source(&owner, "page_manager.rs", 1617)
        || adt_identity["def_path"] != ADT || !at_source(&adt_identity, "cached_file.rs", 24) {
        change(|status| status["selection"] = json!("SOURCE_IDENTITY_MISMATCH"));
        return;
    }
    let adt = tcx.adt_def(adt_did);
    if tcx.generics_of(adt_did).count() != 0 {
        change(|status| status["selection"] = json!("UNRESOLVED_GENERIC"));
        return;
    }
    let exact_ty = Ty::new_adt(tcx, adt, tcx.mk_args(&[]));
    if exact_ty.has_aliases() || exact_ty.has_param() || exact_ty.has_infer()
        || exact_ty.has_placeholders() || exact_ty.references_error()
        || exact_ty.has_escaping_bound_vars() || exact_ty.has_regions() {
        change(|status| status["selection"] = json!("UNSUPPORTED_TYPE_STATE"));
        return;
    }
    let owner_env = ty::TypingEnv::post_analysis(tcx, capture.owner);
    change(|status| {
        status["exact_type"] = json!(format!("{exact_ty:?}"));
        status["typing_environment"] = json!(format!("{owner_env:?}"));
        status["errors_before_identity_queries"] = error_state(tcx);
        status["query_stage"] = json!("DROP_GLUE_LANG_ITEM");
    });
    let mut glue_matches = false;
    match tcx.lang_items().get(LangItem::DropGlue) {
        None => change(|status| status["glue"] = json!({"status": "MISSING_DROP_GLUE_LANG_ITEM"})),
        Some(glue_did) => {
            let requested_args = tcx.mk_args(&[exact_ty.into()]);
            let lang_item = definition(tcx, glue_did);
            change(|status| {
                status["query_stage"] = json!("INSTANCE_TRY_RESOLVE");
                status["glue_resolver_invocations"] = json!(1);
                status["glue"] = json!({
                    "status": "STARTED_INCOMPLETE", "lang_item": lang_item,
                    "requested_args": format!("{requested_args:?}"),
                    "requested_type": format!("{exact_ty:?}"),
                });
            });
            let result = match Instance::try_resolve(tcx, owner_env, glue_did, requested_args) {
                Ok(None) => json!({"status": "UNRESOLVED_OR_LIMITED", "resolver_result": "Ok(None)"}),
                Err(error) => json!({"status": "QUERY_ERROR", "resolver_result": "Err", "error": format!("{error:?}")}),
                Ok(Some(instance)) => {
                    let args_match = instance.args == requested_args;
                    let (shape, payload, kind_matches) = match instance.def {
                        InstanceKind::Shim(ShimKind::DropGlue(did, Some(actual_ty))) => (
                            "RESOLVED_NONEMPTY_GLUE", json!({
                                "variant": "Some", "type": format!("{actual_ty:?}"),
                                "type_equal_requested": actual_ty == exact_ty,
                                "glue_def_id_equal_lang_item": did == glue_did,
                            }), did == glue_did && actual_ty == exact_ty,
                        ),
                        InstanceKind::Shim(ShimKind::DropGlue(did, None)) => (
                            "RESOLVED_EMPTY_GLUE", json!({
                                "variant": "None", "glue_def_id_equal_lang_item": did == glue_did,
                            }), false,
                        ),
                        _ => ("UNEXPECTED_INSTANCE_KIND", Value::Null, false),
                    };
                    glue_matches = args_match && kind_matches;
                    json!({
                        "status": shape, "resolver_result": "Ok(Some)",
                        "full_instance_kind": format!("{:?}", instance.def),
                        "full_instance": format!("{instance:?}"),
                        "returned_args": format!("{:?}", instance.args),
                        "requested_returned_args_equal": args_match,
                        "drop_glue_payload": payload,
                        "expected_target_identity_matches": glue_matches,
                    })
                },
            };
            change(|status| {
                status["glue"]["status"] = result["status"].clone();
                status["glue"]["actual_result"] = result;
            });
        },
    }
    change(|status| {
        status["query_stage"] = json!("ADT_DESTRUCTOR_DEFINITION");
        status["destructor"] = json!({"status": "STARTED_INCOMPLETE", "errors_before": error_state(tcx)});
    });
    let mut destructor_matches = false;
    let destructor = match adt.destructor(tcx) {
        None => json!({
            "status": if tcx.dcx().has_errors_or_delayed_bugs().is_some() {
                "ERROR_TAINTED_INCOMPLETE"
            } else { "MISSING_EXPECTED_DESTRUCTOR_COMPILER_PENDING" },
            "clean_absence": false,
        }),
        Some(destructor) => {
            let actual = definition(tcx, destructor.did);
            let implementation = tcx.impl_of_assoc(destructor.did);
            let implementation_identity = implementation.map(|did| definition(tcx, did));
            let self_matches = implementation.is_some_and(|did|
                tcx.generics_of(did).count() == 0
                    && tcx.type_of(did).instantiate_identity().skip_norm_wip() == exact_ty);
            destructor_matches = at_source(&actual, "cached_file.rs", 41)
                && tcx.def_kind(destructor.did) == DefKind::AssocFn
                && tcx.opt_item_name(destructor.did).is_some_and(|name| name.as_str() == "drop")
                && implementation_identity.as_ref().is_some_and(|record|
                    at_source(record, "cached_file.rs", 40)) && self_matches;
            json!({
                "status": if destructor_matches { "DEFINITION_OBSERVED_SOURCE_MATCH" } else { "IDENTITY_MISMATCH" },
                "definition": actual, "implementation": implementation_identity,
                "implementation_self_type_equal_exact_adt": self_matches,
                "compiler_outcome": "PENDING",
            })
        },
    };
    change(|status| {
        status["destructor"]["status"] = destructor["status"].clone();
        status["destructor"]["actual_result"] = destructor;
        status["errors"] = error_state(tcx);
        let error_tainted = tcx.dcx().has_errors_or_delayed_bugs().is_some();
        status["partial"] = json!(if glue_matches && destructor_matches && !error_tainted {
            "IDENTITIES_OBSERVED_COMPILER_COMPLETION_PENDING"
        } else { "PARTIAL_ERROR_OR_IDENTITY_MISMATCH" });
        status["query_stage"] = json!("IDENTITY_QUERIES_RETURNED");
        let shared = json!({"glue": status["glue"], "destructor": status["destructor"]});
        status["site_results"] = json!(capture.sites.iter().map(|site| json!({
            "context": site.context, "shared_actual_identity_result": shared,
        })).collect::<Vec<_>>());
        status["site_identity_comparison"] = json!({
            "status": "ONE_SHARED_RESULT_RECORD_ATTACHED_TO_TWO_DISTINCT_CONTEXTS",
            "query_count_per_type_environment": status["glue_resolver_invocations"],
            "both_site_adt_tokens_equal": capture.sites[0].adt == capture.sites[1].adt,
            "distinct_cfg_contexts": true, "unique_dynamic_event": "NOT_ESTABLISHED",
        });
    });
}

fn io_failure(dimension: &str, error: io::Error) {
    let mut guard = DIAGNOSTIC.lock().unwrap();
    let diagnostic = guard.as_mut().unwrap();
    diagnostic.io_failed = true;
    diagnostic.status[dimension] = json!({"status": "IO_FAILURE", "error": error.to_string()});
}

fn publish_sidecar(paths: &Paths) {
    let snapshot = {
        let guard = DIAGNOSTIC.lock().unwrap();
        let diagnostic = guard.as_ref().unwrap();
        json!({
            "schema": "redb.candidate123.identity.diagnostic-only.v1",
            "status": diagnostic.status, "tokens": tokens(&diagnostic.captures),
            "raw_path": paths.raw, "started_path": paths.started,
            "compiler_completion": "PENDING",
            "publication_note": "complete JSON; successful publication does not imply compiler completion",
        })
    };
    match publish(&paths.sidecar, &snapshot) {
        Ok(_) => change(|status| status["sidecar_publication"] = json!("DURABLE_NO_CLOBBER")),
        Err(error) => io_failure("sidecar_publication", error),
    }
}

pub fn after_analysis(tcx: TyCtxt<'_>, raw: Value) {
    let (paths, captures, argv) = {
        let guard = DIAGNOSTIC.lock().unwrap();
        let diagnostic = guard.as_ref().unwrap();
        (diagnostic.paths.clone(), diagnostic.captures.clone(), diagnostic.compiler_argv.clone())
    };
    let selection = select(&raw, &captures);
    change(|status| { status["selection"] = json!(selection); status["errors"] = error_state(tcx); });
    let snapshot = json!({
        "schema": "redb.candidate123.raw-before-identity.diagnostic-only.v1",
        "compiler_completion": "PENDING", "compiler_argv": argv,
        "raw_capture": raw, "typed_identity_tokens": tokens(&captures),
        "selection": selection,
        "native_proof_refusal_snapshot": {
            "classification": "NATIVE_PROOF_REFUSED_PENDING_DIAGNOSTIC", "proof_acceptance": false,
            "native_resource_correspondence": false, "resource_semantics_checked": false,
            "interface_exported": false, "hir_vir_mapping_approved": false,
            "all18": "OPEN", "native_credit": 0, "resource_credit": 0, "trust_credit": 0,
        },
        "query_started": "NOT_STARTED", "compiler_error_snapshot": error_state(tcx),
    });
    let raw_bytes = match publish(&paths.raw, &snapshot) {
        Ok(bytes) => bytes,
        Err(error) => {
            io_failure("raw_persistence", error);
            change(|status| status["query_started"] = json!("REFUSED_RAW_REFUSAL_PERSISTENCE_FAILED"));
            publish_sidecar(&paths);
            return;
        },
    };
    change(|status| {
        status["raw_persistence"] = json!("DURABLE_NO_CLOBBER");
        status["refusal"] = json!("NATIVE_PROOF_REFUSED_DURABLE");
    });
    if selection != "EXACT_TWO_DISTINCT_CFG_CONTEXTS" {
        change(|status| status["query_started"] = json!("REFUSED_SELECTION_MISMATCH"));
        publish_sidecar(&paths);
        return;
    }
    if let Err(error) = fresh(&paths.sidecar) {
        io_failure("sidecar_publication", error);
        change(|status| status["query_started"] = json!("REFUSED_SIDECAR_PREFLIGHT_FAILED"));
        return;
    }
    let started = json!({
        "schema": "redb.candidate123.identity-started.v1", "query_started": "STARTED_INCOMPLETE",
        "query_scope": "IDENTITY_PREFLIGHT_MAY_NOT_HAVE_REACHED_RESOLVER",
        "compiler_completion": "PENDING", "raw_path": paths.raw,
        "raw_binding": "EXACT_COMPLETE_UTF8_BYTES_NOT_A_DIGEST",
        "raw_bytes": raw_bytes.len(), "raw_complete_utf8": String::from_utf8_lossy(&raw_bytes),
        "typed_identity_tokens": tokens(&captures), "proof_acceptance": false,
        "missing_final_sidecar_means": "STARTED_INCOMPLETE_NOT_SUCCESS_NOT_ABSENCE",
    });
    if let Err(error) = publish(&paths.started, &started) {
        io_failure("query_started", error);
        publish_sidecar(&paths);
        return;
    }
    change(|status| status["query_started"] = json!("STARTED_DURABLE"));
    let result = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| resolve(tcx, &captures[0])));
    match &result {
        Ok(()) => change(|status| status["query_started"] = json!("RETURNED")),
        Err(_) => change(|status| {
            status["query_started"] = json!("QUERY_PANIC");
            status["partial"] = json!("STARTED_INCOMPLETE_PANIC");
            status["errors"] = error_state(tcx);
        }),
    }
    publish_sidecar(&paths);
    if let Err(payload) = result {
        std::panic::resume_unwind(payload);
    }
}

pub fn finish(report: &mut Value, compiler_completed: bool) -> bool {
    let mut guard = DIAGNOSTIC.lock().unwrap();
    let Some(diagnostic) = guard.as_mut() else { return true };
    diagnostic.status["compiler_completion"] = json!(if compiler_completed {
        "RUN_COMPILER_RETURNED_WITHOUT_PANIC"
    } else { "RUN_COMPILER_DID_NOT_RETURN_NORMALLY" });
    diagnostic.status["compiler_error_finality"] = json!("NO_LIVE_TCX_AFTER_RETURN_ERROR_FINALITY_NOT_ASSERTED");
    report["optional_identity"] = json!({
        "status": diagnostic.status,
        "raw_path": diagnostic.paths.raw, "started_path": diagnostic.paths.started,
        "identity_sidecar_path": diagnostic.paths.sidecar,
        "immutable_pre_return_snapshots_remain_pending": true,
    });
    !diagnostic.io_failed
}
