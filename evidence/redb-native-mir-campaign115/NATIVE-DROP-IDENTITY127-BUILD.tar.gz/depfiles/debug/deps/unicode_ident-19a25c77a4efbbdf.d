/private/tmp/redb-build127-20261108TZZvZKo/target/debug/deps/unicode_ident-19a25c77a4efbbdf.d: /Users/tommyvolk/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/unicode-ident-1.0.27/src/lib.rs /Users/tommyvolk/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/unicode-ident-1.0.27/src/tables.rs

/private/tmp/redb-build127-20261108TZZvZKo/target/debug/deps/libunicode_ident-19a25c77a4efbbdf.rlib: /Users/tommyvolk/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/unicode-ident-1.0.27/src/lib.rs /Users/tommyvolk/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/unicode-ident-1.0.27/src/tables.rs

/private/tmp/redb-build127-20261108TZZvZKo/target/debug/deps/libunicode_ident-19a25c77a4efbbdf.rmeta: /Users/tommyvolk/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/unicode-ident-1.0.27/src/lib.rs /Users/tommyvolk/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/unicode-ident-1.0.27/src/tables.rs

/Users/tommyvolk/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/unicode-ident-1.0.27/src/lib.rs:
/Users/tommyvolk/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/unicode-ident-1.0.27/src/tables.rs:
