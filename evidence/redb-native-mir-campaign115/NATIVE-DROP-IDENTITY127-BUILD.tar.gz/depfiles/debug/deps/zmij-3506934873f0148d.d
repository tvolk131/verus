/private/tmp/redb-build127-20261108TZZvZKo/target/debug/deps/zmij-3506934873f0148d.d: /Users/tommyvolk/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/zmij-1.0.23/src/lib.rs /Users/tommyvolk/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/zmij-1.0.23/src/traits.rs

/private/tmp/redb-build127-20261108TZZvZKo/target/debug/deps/libzmij-3506934873f0148d.rlib: /Users/tommyvolk/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/zmij-1.0.23/src/lib.rs /Users/tommyvolk/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/zmij-1.0.23/src/traits.rs

/private/tmp/redb-build127-20261108TZZvZKo/target/debug/deps/libzmij-3506934873f0148d.rmeta: /Users/tommyvolk/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/zmij-1.0.23/src/lib.rs /Users/tommyvolk/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/zmij-1.0.23/src/traits.rs

/Users/tommyvolk/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/zmij-1.0.23/src/lib.rs:
/Users/tommyvolk/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/zmij-1.0.23/src/traits.rs:
