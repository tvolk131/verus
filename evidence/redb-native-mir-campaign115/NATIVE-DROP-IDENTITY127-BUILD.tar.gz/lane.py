import collections
import difflib
import hashlib
import json
import os
from pathlib import Path
import resource
import shutil
import signal
import subprocess
import sys
import tarfile
import time
import traceback

ROOT = Path(__file__).resolve().parent
OLD = Path('/private/tmp/redb-scope-validation122-20261108T174715Z')
CANDIDATE = Path('/private/tmp/redb-drop-instance-candidate123-20261108T175244Z')
HELPER = Path('/private/tmp/redb-thir-scope-capture-20261108T173322Z/candidate/source/rustc_mir_build/src/builder/checked_drop_origins.rs')
DEADLINE = 1794162660
FLOOR = 16 * 1024 ** 3
CEILING = 3 * 1024 ** 3
PINS = {
    str(CANDIDATE / 'MANIFEST.json'): '3c2dcb406419f9f1ab9e57d98c9901ef3901f6ddf156a9a772d0e165d1e18841',
    str(OLD / 'SEALED-MANIFEST.json'): 'a27928a39bc5a6f08e5958f7520d5328c4e26a7167664fd30841964bc7ffc65f',
    str(OLD / 'BUILD-BINDING.json'): '33f2038b7f3b568b3675d561e45719845529f688055b8722705c397ba52cb5bc',
    str(OLD / 'plans/build1.json'): 'd67c32c69484b2b897d746a48a89eaa8f2f7d5e0d965a24c9df00a07e48d7853',
    str(OLD / 'BUILD1-SOURCE-IDENTITY.json'): '8f282899e6aad6fe43ab5cea5838fb9b3207b2c75e3cdec215ae252cc56e0dae',
    str(HELPER): '1aa55b6d95997e1950cc548119ae6b9b83ff3c69af98c36f0790cff895c0ca79',
}


def write(name, value):
    path = ROOT / name
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x') as handle:
        json.dump(value, handle, indent=2, sort_keys=True)
        handle.write('\n')


def read(path):
    return json.loads(Path(path).read_text())


def identity(path):
    path = Path(path)
    before = path.stat()
    digest = hashlib.sha256()
    with path.open('rb') as handle:
        while True:
            block = handle.read(1024 * 1024)
            if not block:
                break
            digest.update(block)
    after = path.stat()
    if (before.st_size, before.st_mtime_ns, before.st_ino) != (after.st_size, after.st_mtime_ns, after.st_ino):
        raise RuntimeError('changed while hashing: ' + str(path))
    return {'path': str(path), 'realpath': str(path.resolve()), 'bytes': after.st_size,
            'sha256': digest.hexdigest(), 'mtime_ns': after.st_mtime_ns}


def check(record):
    observed = identity(record['path'])
    observed['expected_sha256'] = record['sha256']
    observed['matches'] = observed['sha256'] == record['sha256'] and observed['bytes'] == record.get('bytes', observed['bytes'])
    return observed


def inventory(directory):
    return [identity(path) for path in sorted(Path(directory).rglob('*')) if path.is_file()]


def resources():
    logical = 0
    allocated = 0
    for base, directories, files in os.walk(ROOT):
        for name in files:
            stat = (Path(base) / name).stat()
            logical += stat.st_size
            allocated += stat.st_blocks * 512
    stat = os.statvfs(ROOT)
    return {'epoch_ns': time.time_ns(), 'free_bytes': stat.f_bavail * stat.f_frsize,
            'scratch_logical_bytes': logical, 'scratch_allocated_bytes': allocated}


def guard():
    observation = resources()
    if observation['free_bytes'] <= FLOOR + 512 * 1024 ** 2:
        raise RuntimeError('conservative disk stop threshold reached: ' + str(observation))
    if max(observation['scratch_logical_bytes'], observation['scratch_allocated_bytes']) >= CEILING - 256 * 1024 ** 2:
        raise RuntimeError('conservative scratch stop threshold reached: ' + str(observation))
    if time.time() >= DEADLINE - 75:
        raise RuntimeError('seal reserve reached')
    return observation


def python_inputs():
    paths = {str(Path(sys.executable).resolve()), sys.executable, str(Path(__file__).resolve())}
    for module in list(sys.modules.values()):
        value = getattr(module, '__file__', None)
        if value and Path(value).is_file():
            paths.add(str(Path(value).resolve()))
            if value.endswith('.pyc') and Path(value[:-1]).is_file():
                paths.add(str(Path(value[:-1]).resolve()))
    for value in ['/usr/bin/cc', '/usr/bin/ld', '/usr/bin/ar', '/usr/bin/xcrun', '/bin/sh', '/bin/zsh',
                  '/usr/bin/shasum', '/usr/bin/sed', '/usr/bin/mktemp', '/bin/ls', '/bin/df', '/bin/date',
                  '/Library/Developer/CommandLineTools/usr/bin/clang', '/Library/Developer/CommandLineTools/usr/bin/ld',
                  '/Library/Developer/CommandLineTools/usr/bin/ar', shutil.which('apply_patch'), shutil.which('rg')]:
        if value and Path(value).is_file():
            paths.add(value)
    framework = Path('/Library/Developer/CommandLineTools/Library/Frameworks/Python3.framework/Versions/3.9/Python3')
    if framework.is_file():
        paths.add(str(framework))
    return [identity(path) for path in sorted(paths)]


def authenticate(records):
    observed = []
    for index, record in enumerate(records):
        try:
            result = check(record)
        except Exception as error:
            result = {'path': record['path'], 'matches': False, 'error': repr(error)}
        observed.append(result)
        if index % 200 == 0:
            guard()
    return observed


def prepare():
    write('COMPILER-SLOT-ACQUIRED.json', {'epoch_ns': time.time_ns(), 'task': 127,
          'authority': 'user assigns sole compiler-heavy slot; completed review125 released it',
          'other_workers_inspected_or_polled': False, 'deadline_epoch_seconds': DEADLINE,
          'deadline_basis': 'conservative 18:15:00Z start plus 16 minutes; initial shell preflight precedes receipt',
          'observation': guard()})
    pins = [check({'path': path, 'sha256': digest}) for path, digest in PINS.items()]
    write('PIN-AUTHENTICATION.json', {'epoch_ns': time.time_ns(), 'records': pins})
    if not all(record['matches'] for record in pins):
        raise RuntimeError('explicit pin mismatch')
    sealed = read(OLD / 'SEALED-MANIFEST.json')
    sealed_map = {record['relative_path']: record for record in sealed['records']}
    for name in ['ENTRY-AUTHENTICATION.json', 'source.patch', 'PATCH-INDEX.json']:
        record = check(sealed_map[name])
        if not record['matches']:
            raise RuntimeError('sealed recipe payload mismatch: ' + name)
    candidate_records = [{'path': str(CANDIDATE / item['path']), 'sha256': item['sha256'], 'bytes': item['bytes']}
                         for item in read(CANDIDATE / 'MANIFEST.json')['records']]
    candidate_check = authenticate(candidate_records)
    write('CANDIDATE-ENTRY.json', {'epoch_ns': time.time_ns(), 'records': candidate_check})
    if len(candidate_check) != 9 or not all(record['matches'] for record in candidate_check):
        raise RuntimeError('candidate payload authentication failed')
    previous = read(OLD / 'ENTRY-AUTHENTICATION.json')['records']
    baseline = read(OLD / 'BUILD1-SOURCE-IDENTITY.json')['records']
    previous_check = authenticate(previous)
    source_check = authenticate(baseline)
    write('ENTRY-AUTHENTICATION.json', {'epoch_ns': time.time_ns(), 'historical122_records': previous_check,
          'source122_records': source_check, 'python_and_setup_tools': python_inputs(),
          'historical_custody': 'current endpoint content equality only; no historical continuous custody retrofit',
          'observed_resource': guard()})
    if not all(record['matches'] for record in previous_check + source_check):
        raise RuntimeError('entry authentication mismatch; no compiler authorized')
    for record in baseline:
        source = Path(record['path'])
        relative = source.relative_to(OLD)
        if relative.parts[0] != 'stage':
            raise RuntimeError('non-stage source in baseline')
        destination = ROOT / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, destination)
    inputs = ROOT / 'inputs'
    inputs.mkdir()
    for name in ['SEALED-MANIFEST.json', 'BUILD-BINDING.json', 'BUILD1-SOURCE-IDENTITY.json',
                 'ENTRY-AUTHENTICATION.json', 'source.patch', 'PATCH-INDEX.json', 'plans/build1.json']:
        destination = inputs / ('122-' + name.replace('/', '-'))
        shutil.copyfile(OLD / name, destination)
    for name in ['HANDOFF.md', 'MANIFEST.json', 'candidate123-baseline.patch']:
        shutil.copyfile(CANDIDATE / name, inputs / ('123-' + name))
    shutil.copyfile(OLD / 'stage/observer/src/main.rs', inputs / 'baseline-main.rs')
    for name in ['main.rs', 'identity.rs']:
        shutil.copyfile(CANDIDATE / 'source' / name, ROOT / 'stage/observer/src' / name)
        shutil.copyfile(CANDIDATE / 'source' / name, inputs / ('initial-' + name))
    (ROOT / 'tmp').mkdir()
    (ROOT / 'target').mkdir()
    staged = inventory(ROOT / 'stage')
    write('STAGED-INITIAL-SOURCE-IDENTITY.json', {'epoch_ns': time.time_ns(), 'records': staged,
          'baseline_records': 53, 'staged_records': len(staged),
          'only_substitutions': ['stage/observer/src/main.rs', 'stage/observer/src/identity.rs'],
          'target_or_cache_artifacts_copied': False})
    write('PREPARATION-OBSERVATIONS.json', {'epoch_ns': time.time_ns(),
          'initial_read_failure': 'preflight attempted nonexistent 122/stage/source/rustc_mir_build/build.rs; FileNotFoundError; no build attempted',
          'output_display': 'some combined initial inspection output truncated; HANDOFF reread in bounded sections; authenticated full bytes retained',
          'git_metadata': 'unchanged explicit unversioned digest adaptation in authenticated source.patch; no Git command or invented metadata',
          'baseline_helper_controls_source': 'copied unchanged because exact Cargo build includes default bins; never executed'})
    print('PREPARED', ROOT, len(previous_check), 'historical records;', len(staged), 'staged records', flush=True)


def snapshot(name):
    entry = read(ROOT / 'ENTRY-AUTHENTICATION.json')
    unique = {}
    for record in entry['historical122_records'] + entry['source122_records'] + entry['python_and_setup_tools']:
        if 'sha256' in record:
            unique[record['path']] = record
    for path, digest in PINS.items():
        unique[path] = {'path': path, 'sha256': digest}
    records = authenticate(list(unique.values()))
    staged = inventory(ROOT / 'stage')
    write(name, {'epoch_ns': time.time_ns(), 'records': records, 'staged_sources': staged,
          'python_modules_current': python_inputs(), 'resource_observation': guard(),
          'historical_scope': 'current entry/preexecution/exit endpoint hashes, not continuous or prior historical custody'})
    if not all(record['matches'] for record in records):
        raise RuntimeError('endpoint authentication changed: ' + name)


def stop_group(process):
    observations = []
    for sig in [signal.SIGTERM, signal.SIGKILL]:
        try:
            os.killpg(process.pid, sig)
            observations.append({'signal': sig.name, 'epoch_ns': time.time_ns(), 'sent': True})
        except ProcessLookupError:
            observations.append({'signal': sig.name, 'epoch_ns': time.time_ns(), 'already_absent': True})
        if sig == signal.SIGTERM:
            try:
                process.wait(timeout=2)
            except subprocess.TimeoutExpired:
                pass
    process.wait()
    return observations


def build(number):
    if number not in [1, 2] or (ROOT / ('records/build' + str(number))).exists():
        raise RuntimeError('build allowance violation')
    if number == 2 and not (ROOT / 'records/build1/receipt.json').exists():
        raise RuntimeError('missing first-build receipt')
    if number == 2 and read(ROOT / 'records/build1/receipt.json')['returncode'] == 0:
        raise RuntimeError('unnecessary second build')
    snapshot('BUILD' + str(number) + '-PREEXECUTION-AUTHENTICATION.json')
    original = read(OLD / 'plans/build1.json')
    environment = {key: value.replace(str(OLD), str(ROOT)) for key, value in original['environment'].items()}
    argv = [value.replace(str(OLD), str(ROOT)) for value in original['argv']]
    cwd = original['cwd'].replace(str(OLD), str(ROOT))
    timeout = min(480, max(0, int(DEADLINE - time.time() - 95)))
    if timeout < 30:
        raise RuntimeError('insufficient reserved time for build')
    plan = {'argv': argv, 'cwd': cwd, 'environment': environment, 'timeout_seconds': timeout,
            'source_identity': str(ROOT / ('BUILD' + str(number) + '-PREEXECUTION-AUTHENTICATION.json')),
            'recipe': str(OLD / 'plans/build1.json'), 'only_environment_changes': 'scratch root substitution'}
    write('plans/build' + str(number) + '.json', plan)
    directory = ROOT / ('records/build' + str(number))
    directory.mkdir(parents=True)
    before = resource.getrusage(resource.RUSAGE_CHILDREN)
    observations = [guard()]
    started = time.time_ns()
    process = None
    stopped = []
    reason = None
    prior_handlers = {}
    def interrupted(signum, frame):
        raise InterruptedError('cancellation signal ' + str(signum))
    for signum in [signal.SIGTERM, signal.SIGINT, signal.SIGHUP]:
        prior_handlers[signum] = signal.signal(signum, interrupted)
    try:
        with (directory / 'stdout.raw').open('xb') as stdout, (directory / 'stderr.raw').open('xb') as stderr:
            process = subprocess.Popen(argv, cwd=cwd, env=environment, stdout=stdout, stderr=stderr, start_new_session=True)
            write('records/build' + str(number) + '/process.json', {'epoch_ns': time.time_ns(), 'pid': process.pid, 'pgid': process.pid})
            while process.poll() is None:
                observations.append(guard())
                if (time.time_ns() - started) / 1e9 >= timeout:
                    raise TimeoutError('per-command timeout')
                try:
                    process.wait(timeout=1)
                except subprocess.TimeoutExpired:
                    pass
            process.wait()
    except BaseException as error:
        reason = repr(error)
        if process is not None:
            stopped = stop_group(process)
    finally:
        for signum, handler in prior_handlers.items():
            signal.signal(signum, handler)
        ended = time.time_ns()
        after = resource.getrusage(resource.RUSAGE_CHILDREN)
        group_absent = None
        if process is not None:
            try:
                os.killpg(process.pid, 0)
                stopped.extend(stop_group(process))
                try:
                    os.killpg(process.pid, 0)
                    group_absent = False
                except ProcessLookupError:
                    group_absent = True
            except ProcessLookupError:
                group_absent = True
        observations.append(resources())
        receipt = dict(plan, start_epoch_ns=started, end_epoch_ns=ended,
                       returncode=process.returncode if process is not None else None, stop_reason=reason,
                       process_group_absent=group_absent, process_reaped=process is not None and process.returncode is not None,
                       signals=stopped, resource_observations=observations,
                       child_usage={'user_seconds': after.ru_utime - before.ru_utime,
                                    'system_seconds': after.ru_stime - before.ru_stime,
                                    'maxrss_platform_native': after.ru_maxrss},
                       raw_outputs=[identity(directory / name) for name in ['stdout.raw', 'stderr.raw']])
        write('records/build' + str(number) + '/receipt.json', receipt)
    print('BUILD', number, 'returncode', receipt['returncode'], 'reason', reason, 'reaped', receipt['process_reaped'], flush=True)


def seal():
    snapshot('EXIT-AUTHENTICATION.json')
    entry_candidate = read(ROOT / 'CANDIDATE-ENTRY.json')['records']
    write('CANDIDATE-EXIT.json', {'epoch_ns': time.time_ns(), 'records': authenticate(entry_candidate)})
    records = inventory(ROOT / 'stage')
    write('TESTED-SOURCE-IDENTITY.json', {'epoch_ns': time.time_ns(), 'records': records})
    source_diff = []
    for name in ['main.rs', 'identity.rs']:
        before = (ROOT / 'inputs/baseline-main.rs').read_text().splitlines(True) if name == 'main.rs' else []
        after = (ROOT / 'stage/observer/src' / name).read_text().splitlines(True)
        source_diff.extend(difflib.unified_diff(before, after, fromfile='baseline/observer/src/' + name, tofile='tested/observer/src/' + name))
    (ROOT / 'baseline-to-tested.patch').write_text(''.join(source_diff))
    artifacts = inventory(ROOT / 'target')
    write('ARTIFACT-IDENTITIES.json', {'epoch_ns': time.time_ns(), 'records': artifacts,
          'all_artifacts_retained': True, 'excluded_from_archive': 'entire target directory; identities retained'})
    depfiles = [record for record in artifacts if record['path'].endswith('.d')]
    depdir = ROOT / 'depfiles'
    depdir.mkdir()
    for record in depfiles:
        relative = Path(record['path']).relative_to(ROOT / 'target')
        destination = depdir / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(record['path'], destination)
    write('DEPFILE-INDEX.json', {'epoch_ns': time.time_ns(), 'records': depfiles,
          'compiler_source_identity': str(ROOT / 'TESTED-SOURCE-IDENTITY.json'),
          'scope': 'actual Cargo/Rust depfiles retained, no transitive dynamic compiler-query closure or runtime behavior claim'})
    receipts = [read(path) for path in sorted((ROOT / 'records').glob('build*/receipt.json'))]
    outcome = 'BUILD_SUCCESS' if receipts and receipts[-1]['returncode'] == 0 and receipts[-1]['stop_reason'] is None else 'BUILD_BLOCKED'
    binding = {'epoch_ns': time.time_ns(), 'outcome': outcome, 'build_receipts': [identity(path) for path in sorted((ROOT / 'records').glob('build*/receipt.json'))],
               'source_identity': identity(ROOT / 'TESTED-SOURCE-IDENTITY.json'), 'helper': identity(ROOT / 'stage/source/rustc_mir_build/src/builder/checked_drop_origins.rs'),
               'binaries': [record for record in artifacts if Path(record['path']).name in ['redb-native-mir-observer', 'helper-controls']],
               'depfile_index': identity(ROOT / 'DEPFILE-INDEX.json'), 'candidate_immutable': all(item['matches'] for item in read(ROOT / 'CANDIDATE-EXIT.json')['records']),
               'runtime_validation': False, 'provenance_mapping_approval': False, 'native_semantics_or_adoption': False,
               'all18': 'OPEN', 'native_credit': 0, 'resource_credit': 0, 'trust_credit': 0}
    write('BUILD-BINDING.json', binding)
    warnings = []
    for path in sorted((ROOT / 'records').glob('build*/stderr.raw')):
        warnings.extend(line for line in path.read_text(errors='replace').splitlines() if 'warning:' in line or 'error[' in line or line.startswith('error:'))
    write('WARNINGS-AND-ERRORS.json', {'lines': warnings, 'raw_stderr_authoritative': True})
    write('COMPILER-SLOT-RELEASED.json', {'epoch_ns': time.time_ns(), 'compiler_slot': 'EXPLICITLY_RELEASED',
          'all_owned_compiler_groups_reaped': all(item['process_reaped'] and item['process_group_absent'] for item in receipts),
          'no_followup': True, 'authority_scope': 'task127 build/typecheck only', 'observation': resources()})
    accounting = {'epoch_ns': time.time_ns(), 'outcome': outcome, 'cargo_build_check_allowance': 2,
                  'cargo_commands_used': len(receipts), 'commands_preserved': True, 'no_116_reset': True,
                  'runtime_commands': 0, 'network_commands': 0, 'git_commands': 0, 'subdelegations': 0,
                  'native_execution': False, 'verifier_solver_execution': False, 'observer_callbacks_invoked': False,
                  'resource': resources(), 'resource_measurement': 'one-second build samples, conservative stop headroom; not a proof of continuous external free-disk state',
                  'deadline_epoch_seconds': DEADLINE, 'all18': 'OPEN', 'native_credit': 0, 'resource_credit': 0, 'trust_credit': 0}
    write('ACCOUNTING.json', accounting)
    report = '# task127: sealed candidate123 BUILD/TYPECHECK handoff\n\n'
    report += 'Outcome: ' + outcome + '. Cargo commands: ' + str(len(receipts)) + '/2. Compiler slot explicitly released.\n\n'
    report += 'Only fresh scratch staged sources were compiled. Candidate123 and completed122 remain unchanged. '
    report += 'Exact authenticated 122 Cargo argv/environment reused with scratch-root substitution only. '
    report += '53 baseline stage records plus new identity module; unchanged helper120. '
    report += 'Baseline-to-tested patch includes the new module; 122 source.patch retains original explicit unversioned digest adaptation. No Git metadata invented.\n\n'
    report += 'All 4903 historical122 entry records were content-authenticated at current entry, preexecution and exit. '
    report += 'This establishes present endpoint equality, not prior historical custody or continuous immutability. '
    report += 'Actual selected sources, toolchain/sysroot, locked dependency sources, Python loaded modules/framework and selected platform tools are pinned. '
    report += 'No complete operating-system/SDK/dynamic-loader input closure is claimed. No runtime/compiler diagnostic fixture was executed.\n\n'
    report += 'Preparation attempted to read nonexistent 122 rustc_mir_build/build.rs and received FileNotFoundError; no Cargo allowance consumed. '
    report += 'Initial combined display truncation is recorded; full authenticated handoff bytes were retained and bounded sections read. '
    report += 'All raw stderr/stdout, plans, epoch-nanosecond receipts, reap and sampled resources are preserved. '
    report += 'Warnings/errors: see WARNINGS-AND-ERRORS.json and authoritative records/build*/stderr.raw.\n\n'
    report += 'No produced binary, observer callback, identity query, helper control, native redb, verifier/solver or runtime diagnostic fixture was run. '
    report += 'Build success is not runtime validation, provenance mapping approval, native semantics or adoption. All18 OPEN; native/resource/trust credit0. '
    report += 'Worker116 historical command/allowance/status remains untouched; no failed allowance reset.\n\n'
    report += 'Full current target artifacts remain in scratch and are hashed in ARTIFACT-IDENTITIES.json; bulky target content is excluded from the handoff archive. '
    report += 'Depfiles are copied into the small handoff and indexed. Compiler slot is released; no followup.\n'
    (ROOT / 'REPORT.md').write_text(report)
    payloads = [path for path in sorted(ROOT.rglob('*')) if path.is_file() and 'target' not in path.relative_to(ROOT).parts]
    manifest = {'epoch_ns': time.time_ns(), 'outcome': outcome, 'compiler_slot': 'EXPLICITLY_RELEASED',
                'all18': 'OPEN', 'native_credit': 0, 'resource_credit': 0, 'trust_credit': 0,
                'exclusions': ['target/** (identities retained)', 'SEALED-MANIFEST.json', 'HANDOFF.tar.gz', 'SEAL.json'],
                'records': [dict(identity(path), relative_path=str(path.relative_to(ROOT))) for path in payloads]}
    write('SEALED-MANIFEST.json', manifest)
    failures = [record for record in manifest['records'] if not check(record)['matches']]
    if failures:
        raise RuntimeError('manifest readback failed')
    archive = ROOT / 'HANDOFF.tar.gz'
    with tarfile.open(archive, 'w:gz') as handle:
        for path in payloads + [ROOT / 'SEALED-MANIFEST.json']:
            handle.add(path, arcname=str(path.relative_to(ROOT)), recursive=False)
    with tarfile.open(archive, 'r:gz') as handle:
        expected = {record['relative_path']: record['sha256'] for record in manifest['records']}
        expected['SEALED-MANIFEST.json'] = identity(ROOT / 'SEALED-MANIFEST.json')['sha256']
        for member in handle.getmembers():
            if hashlib.sha256(handle.extractfile(member).read()).hexdigest() != expected.pop(member.name):
                raise RuntimeError('archive readback failed: ' + member.name)
        if expected:
            raise RuntimeError('archive missing payload')
    write('SEAL.json', {'epoch_ns': time.time_ns(), 'manifest': identity(ROOT / 'SEALED-MANIFEST.json'),
          'archive': identity(archive), 'manifest_and_archive_readback': 'all payload hashes match',
          'resource': resources(), 'compiler_slot': 'EXPLICITLY_RELEASED', 'outcome': outcome})
    print('SEALED', outcome, identity(ROOT / 'SEALED-MANIFEST.json')['sha256'], identity(archive)['sha256'], flush=True)


if __name__ == '__main__':
    try:
        mode = sys.argv[1]
        if mode == 'prepare':
            prepare()
        elif mode == 'build':
            build(int(sys.argv[2]))
        elif mode == 'seal':
            seal()
        else:
            raise ValueError('unknown mode')
    except BaseException:
        failure = ROOT / ('FAILURE-' + str(time.time_ns()) + '.txt')
        failure.write_text(traceback.format_exc())
        raise
