# Precise custody and receipt scope

The 4903 authenticated historical122 records are checked now against their
authenticated recorded hashes, not treated as proof of continuous historical
custody. Candidate and selected original staged sources are authenticated before
copy/use. Both Cargo invocations have their own complete argv, exact environment,
raw stdout/stderr, epoch-nanosecond interval, resource observations and reap status.
The produced observer and helper-controls binaries were never invoked.

Cargo build2 reuses only build1-generated artifacts inside this new scratch root.
No old target/cache artifacts were copied. Those generated intermediates were
not separately hashed immediately before build2; they are hashed at final exit,
along with fingerprints, depfiles and both binaries. Do not treat their final
hashes as retroactive preexecution custody of generated artifacts. Selected
external dependency sources, compiler and helper were pinned at all endpoints.

Python executable/framework, loaded module source/shared objects and selected
platform tools were hashed at entry/preexecution/exit. Python was invoked with
-B, which prevents bytecode writes but can still read existing bytecode caches.
Loaded modules' existing __cached__ files are separately inventoried at final
receipt time; no preexecution cache-byte identity claim is made. No complete
OS/SDK/dynamic-loader closure or continuously observed free-disk proof is claimed.
One-second samples use conservative 512MiB free-space and 256MiB scratch headroom.

Initial shell exploratory reads preceded persistent acquisition recording.
Acquisition explicitly records this fact and uses the conservative 18:15:00Z
start/deadline, earlier than the first fresh-root timestamp (18:16:39Z).
The setup attempt to read nonexistent 122 rustc_mir_build/build.rs raised
FileNotFoundError. It consumed no Cargo allowance. The combined shell continued
to subsequent sed reads and therefore returned zero; this does not erase the
Python failure. Initial combined display output was truncated by the tool, so
that displayed output is not represented as a complete raw setup receipt.
Complete raw output capture applies to both actual Cargo commands. The failed
setup read and truncated displays remain explicit, not silently reclassified.

Only one compiler-required staged source correction was made: the Unnormalized
wrapper extraction at identity.rs:389. The first failure, initial source, exact
correction patch and two command allowances are retained. The unchanged helper120
deprecation warning remains unresolved by design. All18 OPEN; all credits zero.
