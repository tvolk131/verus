# One narrowly compiler-required correction

Build1 returned 101 with a single E0308 at staged identity.rs:389. The installed
type_of(...).instantiate_identity() API returns Unnormalized<TyCtxt, Ty>, not Ty.
The only staged source correction adds .skip_norm_wip() before the existing
equality comparison. The authenticated installed rustc_type_ir/src/unnormalized.rs
defines that method as returning its contained value. Existing authenticated
rustc_mir_build source uses the identical API chain. No extra normalization query,
resolver call, persistence, selection, query owner or admission behavior is added.
This is a wrapper/type compatibility correction, not semantic validation.

The candidate remains immutable. Its exact initial two files are retained in
inputs/initial-main.rs and inputs/initial-identity.rs, and the complete initial
54-record stage inventory is STAGED-INITIAL-SOURCE-IDENTITY.json. Build1 raw output,
source pins and receipt are retained; build1 consumes the first of two allowances.
Only one staged line is corrected, once, for build2; no further correction/build
is authorized. Helper120 and main.rs remain byte-identical.
