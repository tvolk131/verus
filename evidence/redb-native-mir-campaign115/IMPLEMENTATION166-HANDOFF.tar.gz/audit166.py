import hashlib
import json
from pathlib import Path
import tarfile

from receipt166 import ROOT, inventory, sha, write

BASE = Path('/private/tmp/redb-native-adapter164-20261109-004200')
EXPECTED = {
    'HANDOFF164.json': 'ca8691451a59a2ce81acd3e0b438b443dfbcb684fb44fa0b2dd40d1f8cc1357e',
    'HANDOFF164.tar.gz': '3bd20e516bfda56de3377caf29637e1796cb1cc4179db450445e8d69f0a9b133',
    'MANIFEST164.json': 'd4042d23dea2fcaf56af5fa6f7bfeef303ec66ea6bceb3b7f5a21370efeef7c4',
}
RUNTIME = BASE / 'runtime/native-adapter164-built33'
RUNTIME_SHA = '7a68ac1999cad3f6088fc6cb4004295d309a2b6de6c8643d570ef085e90b5962'
LAW = Path('/private/tmp/redb-primitive158-20261108-234646/LAW158.md')
LAW_SHA = '0e95e3c2a8182c12573c57d71d4b93162a1162de343580ff896b45f5bdf8443f'


def authenticate():
    for name, expected in EXPECTED.items():
        assert sha(BASE / name) == expected, name
    manifest = json.loads((BASE / 'MANIFEST164.json').read_bytes())
    records = {entry['path']: entry for entry in manifest['files']}
    assert len(records) == len(manifest['files'])
    seen = set()
    with tarfile.open(BASE / 'HANDOFF164.tar.gz', 'r:gz') as archive:
        for member in archive:
            assert member.isfile() and member.name not in seen, member.name
            assert not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
            seen.add(member.name)
            data = archive.extractfile(member).read()
            assert (BASE / member.name).read_bytes() == data, member.name
            if member.name != 'MANIFEST164.json':
                entry = records[member.name]
                assert len(data) == entry['bytes'] and hashlib.sha256(data).hexdigest() == entry['sha256']
    assert seen == set(records) | {'MANIFEST164.json'} and len(seen) == 1508
    baseline = [dict(path=entry['path'][10:], bytes=entry['bytes'], sha256=entry['sha256'])
                for entry in manifest['files'] if entry['path'].startswith('candidate/')]
    current = {entry['path']: entry for entry in inventory()}
    changed = [entry['path'] for entry in baseline if current.get(entry['path']) != entry]
    assert len(baseline) == 1120
    assert sha(RUNTIME) == RUNTIME_SHA
    assert sha(LAW) == LAW_SHA
    for name in ['REPORT164.md', 'IMPLEMENTATION164.md', 'HANDOFF164.json', 'MANIFEST164.json']:
        assert (ROOT / 'inputs' / name).read_bytes() == (BASE / name).read_bytes()
    authority = Path('/Users/tommyvolk/.t3/worktrees/verus/t3-60978068/evidence/redb-native-mir-campaign115')
    for name in ['AUTHORIZATION139.md', 'FIRST-CELL139.md', 'ALLOCATOR-LAW-DISPOSITION159.md', 'CONTINUATION164.md']:
        assert (ROOT / 'inputs' / name).read_bytes() == (authority / name).read_bytes()
    assert (ROOT / 'inputs/LAW158.md').read_bytes() == LAW.read_bytes()
    return dict(inputs=EXPECTED, members=len(seen), candidate_files=len(baseline),
                regular_unique_byte_readback=True, candidate_equals_baseline164=not changed,
                changed_source=sorted(changed),
                law_sha256=LAW_SHA, inherited_runtime_sha256=RUNTIME_SHA,
                inherited_runtime_executed=False)


def evidence(path, anchors):
    source = ROOT / 'candidate' / path
    lines = source.read_text().splitlines()
    selected = []
    for anchor in anchors:
        matches = [index + 1 for index, line in enumerate(lines) if anchor in line]
        assert matches, (path, anchor)
        selected.append(dict(anchor=anchor, lines=matches))
    return dict(path=path, sha256=sha(source), anchors=selected)


if __name__ == '__main__':
    authentication = authenticate()
    anchors = [
        evidence('source/rust_verify/src/native_adapter164.rs', [
            'struct State164 { values:', 'fn has_resources(',
            'fn raw_allocator(', 'let mut state = State164::default();',
            'target: CallTarget::NativeAllocator164,',
            'args: Arc::new(vec![size.expression, numeric])',
            'result.bundle.unwrap_or(result.expression)',
        ]),
        evidence('source/vir/src/native_resource/adapter164.rs', [
            'functions: vec![function], reveal_groups: vec![], datatypes: vec![]',
            'review harness has no verifier-loaded vstd',
            'fun: crate::sst::CallTarget::NativeAllocator164,',
        ]),
        evidence('source/vir/src/modes.rs', ['Ok((Mode::Exec, Proph::No))',
            'ExprX::Call { target: CallTarget::NativeAllocator164']),
        evidence('source/vir/src/sst_to_air.rs', [
            'StmX::Call { fun: crate::sst::CallTarget::NativeAllocator164',
            'return Err(crate::native_resource::adapter164::admission_error(&stm.span));',
        ]),
        evidence('source/rust_verify/src/verifier.rs', [
            'fn run_lifetime_checks_on_verus_aware_items',
            'tcx.ensure_ok().mir_borrowck(def_id);',
        ]),
        evidence('source/vir/src/native_resource/continuation160.rs', [
            'pub enum NativeSemanticWitness160 {}',
            'pub fn from_datatypes(datatypes: &[Datatype])',
        ]),
        evidence('source/rust_verify/src/allocation_selection160.rs', [
            'actual raw payload projection required',
        ]),
        evidence('source/vstd/raw_ptr.rs', ['pub tracked struct PointsToRaw',
            'pub tracked struct Dealloc', 'pub fn allocate(size: usize, align: usize)']),
    ]
    result = dict(authentication=authentication, source_anchors=anchors,
                  kind='SOURCE_ONLY_BOUNDARY_AUDIT_NOT_A_COMPILER_OR_SEMANTIC_TEST',
                  compiler_builds=0, wf_mode_runs=0, air_shape_runs=0, solver_runs=0,
                  actual_issuance=0, native_acceptance=0, original_application_executions=0)
    write('BOUNDARY-AUDIT166.json', result)
    print(json.dumps(result, indent=2, sort_keys=True))
