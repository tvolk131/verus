# Exploration receipt limitation and failures166

Before the instrumented diagnostic runner, setup/source discovery used17 shell
tool calls. Their complete tool calls and outputs remain in this conversation's
tool transcript. They were not durably captured as raw streams at the time.
Do not treat this file as an exact reconstruction of those streams or clocks.

Observed discovery failures included:

- `ls -ld /private/tmp/AGENTS.md /private/AGENTS.md` returned failure when those
  files were absent; stderr was redirected to `/dev/null` by that exploration
  command. The surrounding shell tool call exited1. No instruction file was
  found in the extracted candidate either; root/ancestor instruction paths
  were checked before extraction.
- zsh reported `no matches found: candidate/source/rust_verify/src/lifetime*`
  on a guessed source-file glob. The relevant checking code was subsequently
  located directly in `source/rust_verify/src/verifier.rs`; the guessed file
  family was not fabricated or modified.
- zsh reported `no matches found: /private/tmp/redb-*/*/vstd.vir` while checking
  guessed library artifact locations. No vstd artifact was loaded and no
  fabricated matching datatypes were substituted.
- Some exploration output was truncated by the terminal tool. Targeted source
  reads and the durable audit retain the actual anchors used by the boundary
  report. A truncated read is not treated as checked compiler behavior.

No compiler, verifier, test runner, original program, allocator or native issuer
was spawned during these initial calls. The initial extraction authenticated
the archive and wrote only the new scratch candidate/inputs/authentication
artifacts and the standalone preparation script in `/private/tmp`.

The preparation result's `command_count_at_setup=5` is a conservative manual
shell-call count, not a machine-observed runtime command ledger. The final
handoff separately reports charged calls and this qualification. Any later
instrumented diagnostic failure remains in its actual receipt/raw streams.
