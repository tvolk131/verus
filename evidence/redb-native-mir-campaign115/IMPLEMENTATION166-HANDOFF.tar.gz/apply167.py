import difflib
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile

from receipt166 import ROOT, sha, write

BASE = Path('/private/tmp/redb-quarantine167')
assert sha(BASE / 'HANDOFF167.json') == '697779aba9a49c0bca85ee8eda5c41eb03c53eea7cd228080db9c0a0c068a7b2'
assert sha(BASE / 'HANDOFF167.tar.gz') == 'ddbe05e21018057a4af112ce35d383d74cd4249319c3f2b46106c3b7c51027a6'
assert sha(BASE / 'payload/repair167.patch') == '779921543a427f0ffe13ee3b4129f670364410cb972f57a476ee9d48c1f700db'
handoff = json.loads((BASE / 'HANDOFF167.json').read_bytes())
entries = {}
with tarfile.open(BASE / 'HANDOFF167.tar.gz', 'r:gz') as archive:
    for member in archive:
        assert member.isfile() and member.name not in entries
        assert not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
        data = archive.extractfile(member).read()
        assert (BASE / 'payload' / member.name).read_bytes() == data, member.name
        entries[member.name] = data
assert len(entries) == 9
assert hashlib.sha256(entries['MANIFEST167.json']).hexdigest() == handoff['manifest_sha256']
manifest = json.loads(entries['MANIFEST167.json'])
records = manifest if isinstance(manifest, list) else manifest['files']
if isinstance(records, dict):
    records = [dict(path=name, **record) for name, record in records.items()]
for entry in records:
    data = entries[entry['path']]
    assert hashlib.sha256(data).hexdigest() == entry['sha256']
    assert len(data) == entry.get('bytes', entry.get('size', len(data)))
destination = ROOT / 'inputs167'
destination.mkdir()
for name, data in entries.items():
    target = destination / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
(destination / 'HANDOFF167.json').write_bytes((BASE / 'HANDOFF167.json').read_bytes())
patch = ['*** Begin Patch\n']
for name in ['vir/src/native_resource.rs', 'vir/src/native_resource/adapter164.rs', 'vir/src/native_resource/tests.rs']:
    target = ROOT / 'candidate/source' / name
    data = entries['source/' + name]
    changes = list(difflib.unified_diff(target.read_text().splitlines(keepends=True),
                                      data.decode().splitlines(keepends=True)))[2:]
    assert changes
    patch.append('*** Update File: ' + str(target) + '\n')
    patch.extend('@@\n' if line.startswith('@@') else line for line in changes)
patch.append('*** End Patch\n')
encoded = ''.join(patch).encode()
(ROOT / 'apply167.apply_patch').write_bytes(encoded)
result = subprocess.run(['/Users/tommyvolk/.t3/userdata/providers/codex/codex_095eca24-b4b7-4a15-8759-9d8964dbd03a/shadow/tmp/arg0-macos/codex-arg0pyHCn8/apply_patch'], input=encoded, check=False)
assert result.returncode == 0
for name in ['vir/src/native_resource.rs', 'vir/src/native_resource/adapter164.rs', 'vir/src/native_resource/tests.rs']:
    assert (ROOT / 'candidate/source' / name).read_bytes() == entries['source/' + name]
write('AUTHENTICATION167-IN166.json', dict(archive_members=9, regular_unique_byte_readback=True,
      handoff_sha256=sha(BASE / 'HANDOFF167.json'), archive_sha256=sha(BASE / 'HANDOFF167.tar.gz'),
      patch_sha256=sha(BASE / 'payload/repair167.patch'), applied_to_fresh166_only=True))
print('Authenticated and applied sealed167 to fresh166 candidate only')
