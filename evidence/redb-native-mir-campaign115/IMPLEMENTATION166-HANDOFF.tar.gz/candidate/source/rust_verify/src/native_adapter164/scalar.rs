use super::*;

fn core_name<'tcx>(tcx: TyCtxt<'tcx>, typ: Ty<'tcx>, expected: &str) -> bool {
    matches!(*typ.kind(), ty::Adt(definition, _) if
        tcx.crate_name(definition.did().krate).as_str() == "core"
        && tcx.item_name(definition.did()).as_str() == expected)
}

pub(super) fn word_type<'tcx>(tcx: TyCtxt<'tcx>, typ: Ty<'tcx>) -> bool {
    if typ == tcx.types.usize { return true; }
    if !(core_name(tcx, typ, "Alignment") || core_name(tcx, typ, "AlignmentEnum")
        || core_name(tcx, typ, "NonZero")) { return false; }
    let Ok(layout) = tcx.layout_of(ty::TypingEnv::fully_monomorphized().as_query_input(typ)) else {
        return false;
    };
    layout.size.bits() == tcx.data_layout.pointer_size().bits()
}

pub(super) fn transmute_preserves_validity<'tcx>(tcx: TyCtxt<'tcx>, source: Ty<'tcx>, destination: Ty<'tcx>) -> bool {
    word_type(tcx, source) && word_type(tcx, destination)
        && (source == destination || destination == tcx.types.usize)
}

fn field_word<'tcx>(tcx: TyCtxt<'tcx>, mut typ: Ty<'tcx>, projections: &[mir::PlaceElem<'tcx>])
    -> Result<Ty<'tcx>, String>
{
    for projection in projections {
        let mir::ProjectionElem::Field(index, field_type) = projection else {
            return Err("unsupported scalar projection (not a checked transparent field)".into());
        };
        let layout = tcx.layout_of(ty::TypingEnv::fully_monomorphized().as_query_input(typ))
            .map_err(|_| "scalar layout unavailable")?;
        if !word_type(tcx, typ) || !word_type(tcx, *field_type)
            || index.as_usize() != 0 || layout.fields.count() != 1
            || layout.fields.offset(0).bytes() != 0 {
            return Err("scalar field is not an equal-width offset-zero word".into());
        }
        typ = *field_type;
    }
    Ok(typ)
}

pub(super) fn read_word<'tcx>(tcx: TyCtxt<'tcx>, owner: ty::Instance<'tcx>, body: &mir::Body<'tcx>,
    values: &BTreeMap<mir::Local, Expr>, operand: &mir::Operand<'tcx>) -> Result<Expr, String>
{
    match operand {
        mir::Operand::Copy(place) | mir::Operand::Move(place) => {
            let base = native_type(tcx, owner, body.local_decls[place.local].ty);
            if !word_type(tcx, base) { return Err("operand is not a checked native word".into()); }
            field_word(tcx, base, &place.projection)?;
            values.get(&place.local).cloned().ok_or_else(|| "uninitialized scalar operand".into())
        }
        mir::Operand::Constant(constant) => {
            let typ = native_type(tcx, owner, constant.const_.ty());
            if !word_type(tcx, typ) { return Err("constant is not a supported native word".into()); }
            let scalar = constant.const_.try_eval_scalar_int(tcx, ty::TypingEnv::fully_monomorphized())
                .ok_or("native word constant did not evaluate")?;
            Ok(number(scalar.to_bits(tcx.data_layout.pointer_size())))
        }
        _ => Err("unsupported scalar operand".into()),
    }
}

fn permitted_method<'tcx>(tcx: TyCtxt<'tcx>, method: ty::Instance<'tcx>) -> bool {
    tcx.crate_name(method.def_id().krate).as_str() == "core"
        && matches!(tcx.item_name(method.def_id()).as_str(), "as_usize" | "as_nonzero_usize" | "get")
        && tcx.is_mir_available(method.def_id())
}

pub(super) fn evaluate_method<'tcx>(tcx: TyCtxt<'tcx>, method: ty::Instance<'tcx>, argument: Expr,
    depth: usize) -> Result<Expr, String>
{
    if depth > 8 || !permitted_method(tcx, method) {
        return Err("unsupported or recursive scalar method".into());
    }
    let body = tcx.instance_mir(method.def);
    if body.arg_count != 1 { return Err("scalar method must have one actual operand".into()); }
    let input_type = native_type(tcx, method, body.local_decls[mir::Local::from_usize(1)].ty);
    let output_type = native_type(tcx, method, body.return_ty());
    if !word_type(tcx, input_type) || !word_type(tcx, output_type) {
        return Err("scalar method signature is not word-preserving".into());
    }
    let mut values = BTreeMap::from([(mir::Local::from_usize(1), argument)]);
    let mut block = mir::START_BLOCK;
    let mut visited = BTreeSet::new();
    loop {
        if !visited.insert(block) || visited.len() > 32 {
            return Err("scalar method loop/oversized body unsupported".into());
        }
        let data = &body.basic_blocks[block];
        if data.is_cleanup { return Err("scalar cleanup unsupported".into()); }
        for statement in &data.statements {
            match &statement.kind {
                mir::StatementKind::Assign(assignment) => {
                    let (destination, rvalue) = &**assignment;
                    let Some(local) = destination.as_local() else {
                        return Err("scalar projected write unsupported".into());
                    };
                    let result_type = native_type(tcx, method, body.local_decls[local].ty);
                    if !word_type(tcx, result_type) { return Err("non-word scalar temporary".into()); }
                    let expression = match rvalue {
                        mir::Rvalue::Use(operand, _) => read_word(tcx, method, body, &values, operand)?,
                        mir::Rvalue::Cast(mir::CastKind::Transmute, operand, destination_type) => {
                            let source_type = native_type(tcx, method, operand.ty(&body.local_decls, tcx));
                            let destination_type = native_type(tcx, method, *destination_type);
                            if !word_type(tcx, source_type)
                                || !word_type(tcx, destination_type) {
                                return Err("transmute is not a checked equal-width scalar reinterpretation".into());
                            }
                            if !transmute_preserves_validity(tcx, source_type, destination_type) {
                                return Err("scalar transmute into a restricted-validity word requires checked path validity".into());
                            }
                            read_word(tcx, method, body, &values, operand)?
                        }
                        _ => return Err(format!("unsupported scalar MIR rvalue: {rvalue:?}")),
                    };
                    values.insert(local, expression);
                }
                mir::StatementKind::StorageDead(local) => { values.remove(local); }
                mir::StatementKind::StorageLive(_) | mir::StatementKind::Nop => {}
                _ => return Err(format!("unsupported scalar MIR statement: {:?}", statement.kind)),
            }
        }
        match &data.terminator().kind {
            mir::TerminatorKind::Return => return values.remove(&mir::RETURN_PLACE)
                .ok_or_else(|| "scalar method has no initialized result".into()),
            mir::TerminatorKind::Goto { target } => block = *target,
            mir::TerminatorKind::Call { func, args, destination, target: Some(target), unwind, .. }
                if args.len() == 1 && matches!(unwind, mir::UnwindAction::Unreachable | mir::UnwindAction::Continue) => {
                let callee = resolved_call(tcx, method, body, func)?;
                let argument = read_word(tcx, method, body, &values, &args[0].node)?;
                let result = evaluate_method(tcx, callee, argument, depth + 1)?;
                values.insert(destination.as_local().ok_or("projected scalar call output")?, result);
                block = *target;
            }
            _ => return Err(format!("unsupported scalar method terminator: {:?}", data.terminator().kind)),
        }
    }
}

pub(super) fn alignment_as_usize<'tcx>(tcx: TyCtxt<'tcx>, actual_type: Ty<'tcx>, actual: Expr)
    -> Result<Expr, String>
{
    let ty::Adt(definition, arguments) = *actual_type.kind() else {
        return Err("alignment operand is not native Alignment".into());
    };
    if tcx.crate_name(definition.did().krate).as_str() != "core"
        || tcx.def_path_str(definition.did()) != "core::mem::alignment::Alignment" {
        return Err("alignment operand has the wrong nominal definition".into());
    }
    let methods = tcx.inherent_impls(definition.did()).iter().flat_map(|implementation|
        tcx.associated_items(*implementation).in_definition_order()).filter(|item|
            item.name().as_str() == "as_usize").collect::<Vec<_>>();
    if methods.len() != 1 { return Err("ambiguous native Alignment::as_usize".into()); }
    let method = ty::Instance::try_resolve(tcx, ty::TypingEnv::fully_monomorphized(),
        methods[0].def_id, arguments).map_err(|_| "as_usize resolution failed")?
        .ok_or("as_usize has no native instance")?;
    let signature = tcx.fn_sig(method.def_id()).instantiate(tcx, method.args).skip_binder();
    if signature.inputs() != [actual_type] || signature.output() != tcx.types.usize {
        return Err("native as_usize signature mismatch".into());
    }
    evaluate_method(tcx, method, actual, 0)
}
