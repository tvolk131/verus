# Preserved166 failures, updated before final seal

## boundary-audit19

The child diagnostic failed an inventory-list comparison: native `Path` ordering
and string ordering differed. The captured source-entry hash was the correct
sealed164 hash. The child stderr is retained verbatim. The runner then raised
`PermissionError: [Errno 1] Operation not permitted: '/bin/ps'` after waiting the
child, losing its in-memory final return-code receipt. Runner exit1 is known
from the tool transcript; child failure is visible in stderr, but its numerical
exit status is NOT reconstructed as a retained observation. No audit pass or
compiler result is credited. Launch, raw stdout/stderr, and entry inventory
remain at their original paths.

The required ps command was retried via the explicit sandbox escalation flow,
then later receipt commands run with explicit approval. The repaired runner
persists status even if a post-reap audit fails. No signal is sent on a reaped
process group. The inventory diagnostic now compares records by path rather
than asserting inconsistent list order.

## apply167-26

The first167 authentication command assumed a dict-shaped manifest, but the
authenticated manifest is a list. Exact receipt records child exit1, reaped,
owned group absent, and unchanged candidate source. Raw stderr preserves the
TypeError. All outer hashes and archive regular/readback checks preceded that
parse failure; no167 source was applied by this failed command. The parser is
corrected in the following command, with a separate receipt. No allowance is
restarted and no old receipt/artifact is overwritten.

## Other discovery limitations

## quarantine-feature-on32: overbroad test filter

The `native_resource::` filter also selected inherited solver-dependent tests.
The test binary printed CheckValid attempts, then exited128 because z3 was
absent from the allowlisted PATH. Raw streams/actual status/source binding are
retained. No z3 process was executed, no solver acceptance occurred, and this
failed broad run is not called a pass even though individual serialization
tests printed `ok`. The final feature-on rerun selects only `serialized_`
regressions, with no solver-dependent tests. Z3 is not installed or retried.

## Other discovery limitations (continued)

## validity-assert38: fixture coverage did not reach the assumed handlers

The initial compiler-only fixture run37 exited0 and retained exact selected MIR.
Its assertion command38 exited1. The maximum-valid alignment expression used
runtime arithmetic in MIR at optimization0 and was rejected before transmute;
local helper calls were refused by the existing core-only scalar-method filter.
The failed assertions were wrong about which handler those cases reached. The
candidate compiler was not broadened to admit arbitrary helpers or arithmetic.

The initial fixture, output, assertion script and raw failure remain unchanged.
A separate final fixture uses a rustc-evaluated named constant for the actual
maximum-valid word, and actual core constructors/get/as_usize rather than local
helpers. Final reporting distinguishes direct native transmute guard coverage
from earlier fail-closed constructor refusals; it does NOT claim the scalar
transmute handler was dynamically reached by a restricted-destination negative.
Both handlers share the same conservative source guard. No safety/equivalence
theorem, unsafe fixture execution or native issuer credit follows.

## prepare-handoff44: wrong expected review-seal member count

The first preparation command authenticated/captured each165 seal payload but
incorrectly expected three records. The actual pinned seal contains the four
records named by the parent, including seal165.py. Command44 exited1, reaped,
group absent; its actual stderr and receipt are retained. The assertion is
corrected to four, no review input or candidate compiler source changes, and
the retry has a new label/receipt. No failure is deleted or called a pass.

EXPLORATION-QUALIFICATION166.md retains the initial path/glob failures and raw
receipt limitation. A later source lookup also guessed an absent
`lib/rustlib/src` directory under the pinned toolchain and a nonexistent
`selected-runtime*` glob. These are discovery errors, not compiler failures.
The review165 report's supplied hash was authenticated before use.
