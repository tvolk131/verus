# Implementation164: real scalar MIR interpretation; native issuance core incomplete

This is an honest partial implementation, NOT the requested completed native
execution-to-proof allocator adapter. No G1/G2 or original cell is closed. The
genuine native activation/event, full-spec-pointer, allocation-generation and
initialized affine resource correspondence is still unimplemented. Another
suspended opcode is not a substitute for that missing core.

## Actual implemented semantic subset

`source/rust_verify/src/native_adapter164.rs` interprets the selected rustc
instance's actual MIR statements and control successors into ordinary scoped
VIR expressions. Its entry is in canonical `rust_to_vir_func.rs`, behind the
default-off `native-resource-adapter164` Cargo feature; the diagnostic binary
calls that same entry. It is NOT wired into normal native admission or export.

The supported values are native 64-bit scalar words, bool, unit and the
canonical VIR raw-pointer type. Scalar `Alignment`, `AlignmentEnum` and
`NonZero` representations must pass the compiler's actual equal-word-size
layout checks. Transparent field reads must additionally be the only field,
at offset zero, with a supported equal-width field type. This is a restricted
representation translation, not permission to reinterpret arbitrary values.

`native_adapter164/scalar.rs` resolves and recursively interprets the actual
`Alignment::as_usize` method MIR and finite supported core scalar callees.
It supports word-preserving uses and checked equal-width scalar transmutes;
unsupported body operations, projected writes, signatures, calls, cycles and
cleanup refuse. There is no uninterpreted method equation or fresh numeric
output parameter. Numeric results are initialized local declarations, with
fresh names AND fresh canonical temporary-mode identities. The actual input
operand is substituted through the interpreted method body. Constant operands
are evaluated by rustc's constant evaluator, not replaced with a chosen8.

The old160 `AlignmentAsUsize160` descriptor path is NOT converted into this
interpreter: it remains a disabled descriptor with its old limitations. Thus
164 demonstrates an actual replacement lowering path for a semantic subset,
not repaired applicability of the original160 producer/application.

The new translator interprets actual `Assign`, `StorageLive`, `StorageDead`,
scalar `Use`/comparison/transmute, local borrow creation, `Goto`, finite
`SwitchInt`, selected scalar method calls and `Return`. Its state tracks
holders, moves, copies, local loans and overwrites. Destruction overlapping a
live root loan refuses. Lexical storage death ends a holder's loan. CFG joins
are represented by full path-specific suffix lowering into VIR `If`, not a
global Instance-set traversal; incompatible return shapes refuse. Cycles and
excessive expansion refuse instead of receiving a loop invariant or totality
assumption. References are not dereferenced or retagged by an invented memory
model. Native pointer/aggregate equality is explicitly refused: executable
address equality must not become canonical full-spec-pointer equality. Scalar
`Continue` unwind edges are allowed only after the finite callee
body is recursively interpreted using supported nonfaulting scalar operations;
arbitrary calls and cleanup do NOT receive a no-unwind summary.

Canonical review runs initial/per-function WF, mode checking, simplification
and AST-to-SST, stopping before AIR and solver. The internal review wrapper has
the existing native-resource refusal marker. No review result is exportable
native proof evidence.

## Incomplete allocator instruction, explicitly not issuance

An internal, fixed-signature unit opcode `NativeAllocator164` is threaded
through canonical VIR visitors, modes, AST-to-SST and SST call representation.
It has two usize operands and the fixed result type
`(*mut u8, Tracked<PointsToRaw>, Tracked<Dealloc>)`. No supplied body/relation
or arbitrary user equation is accepted. There is no source builtin that mints
it. Native MIR selection checks the actual resolved alloc DefId path and typed
operands, and interprets the actual Alignment operand as described above.

The AST-to-SST boundary requires the actual verifier-loaded vstd datatype
definitions, not only nominal resource names. The minimal review harness has
no such definitions and explicitly refuses allocator instructions. SST-to-AIR
UNCONDITIONALLY refuses this opcode. Opcode detection is part of the existing
native-resource import/export marker check, including serialized bodies where
the attribute marker was removed. Default-off validation rejects the opcode.

`Value164.bundle` follows pointer moves and refuses copying its suspended pair,
discarding it or leaking it across return. This is compiler bookkeeping around
an unimplemented output, NOT genuine affine resource issuance. It does not
establish tracked ownership, full-pointer identity, allocation-generation
freshness or a dynamic native witness. It is not an adapter to `Point160` /
`check_flow`, and no such connection is claimed. Ordinary supported scalar/loan
effects do reach canonical VIR/modes/SST; allocator resource effects do not yet
reach an initialized canonical resource continuation.

There is no observed successful original/raw-allocator trace through164.
The native allocator fixture is refused at its unsupported actual `Layout`
entry type. No actual nonnull-success branch, positivity/valid-layout premise,
native event interpretation or ghost issuance is established by this run.

## Precise unavailable core and remaining gates

1. A checked correspondence between the same executable native invocation and
   its logical dynamic activation/event, distinguishing normal-nonnull success
   from null/error/unwind/abort/divergence and optimized/elided physical calls.
2. Interpretation of that same native return as the canonical full pointer,
   including provenance and allocation generation. A `Primitive::Ptr` type is
   not that interpretation; neither a site ID, counter nor non-Clone host node
   can supply it.
3. Creation of the real vstd `PointsToRaw` and `Dealloc` outputs in that same
   continuation, once, with the exact domain, provenance, ownership and end
   bounds of LAW158. No source-callable mint, caller token or second execution
   of `vstd::raw_ptr::allocate` is used. There are no schema equations installed
   for the new opcode. Replacing these missing interpretations by assumptions
   would be extra trust, not faithful implementation of the adopted schema.
4. Actual native-to-resource effect interpretation for the original body,
   including initialized tracked modes, destructive aliases/borrows, consuming
   raw-pointer operations and deallocation. Local pending-bundle bookkeeping
   does not discharge this. Unsupported MIR/native constructs fail closed.
5. Checked selected allocator AND deallocator, concrete ABI/cfg/profile/runtime
   and actual positive valid S/A. This artifact is tested only on the pinned
   aarch64 Apple toolchain. 64-bit scalar checking is not allocator ABI/runtime
   binding or portability evidence.
6. Any transported prior allocation, initialized bytes, live loan or caller
   state needs its actual ownership/frame interpretation. The code refuses an
   allocator with incoming bundle/loan state but does not infer that native
   memory is empty or provide an ambient frame. No frame law is added.
7. Independent exact-code producer/issuer review and explicit parent
   disposition BEFORE even one operative issuer/solver/native/export use.

The unchanged downstream work includes layout/array/pad/metadata/iterator and
prior values, Arc and resource conservation, native callers and cleanup,
buffer/backend events, public acknowledgement, physical/logical histories and
recovery. First-cell priority remains two-phase acknowledged durability;
all eighteen original cells remain OPEN.

## Trusted versus checked boundary

| Boundary | Status in164 |
| --- | --- |
| Exact LAW158 normal-success issuance schema | One conditionally adopted mathematical schema from159; no application |
| Native activation/event/full-pointer/frame interpretation | Unimplemented; no axiom or assertion installed |
| Scalar MIR interpreter | Executable compiler implementation, layout/type/body checks; needs independent exact-code review, not a formal compiler-correctness theorem |
| MIR scalar/loan/CFG regression results | Ordinary canonical WF/modes/SST checks and serialized-VIR evaluation; no native application execution or equivalence theorem |
| Fixed allocator opcode | Structural type/lowering tests only; unconditional AIR refusal |
| Real affine raw/Dealloc issuance | Zero; nominal/tracked type plumbing is not ownership evidence |
| Original applicability / G1 / G2 / eighteen cells | Unestablished / OPEN / OPEN / all OPEN |
| Infer / S0 / import / export / native admission | Existing refusal boundaries retained; no operative acceptance |

Native runtime erasure and `vstd/raw_ptr.rs` implementation are unchanged.
No allocator axiom is added. No new owned-memory frame, no-unwind, totality,
error rollback, Arc/layout/iterator/cache/caller/prior-value gift is made.
