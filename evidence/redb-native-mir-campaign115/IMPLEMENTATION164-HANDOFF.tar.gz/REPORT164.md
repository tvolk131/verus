# Report164 — requested native issuance core NOT completed

The delivered semantic subset actually interprets Alignment/native scalar MIR,
holder moves/loans and finite CFG into ordinary VIR and canonical WF/modes/SST.
It is not the requested genuine native event/full-pointer/initialized-resource
adapter. See IMPLEMENTATION164.md for code boundaries, trust map and missing
core. No component completion or original applicability is claimed.

## Exact final validation

- Final full rust_verify diagnostic binary build: native-build33, exit0/reaped.
- Final source inventory SHA256: 55dfcba0c24fe60598d7fb3234768a04d6548d8645bcd18298cfec5d24f6f47b.
- Retained runtime binary: /private/tmp/redb-native-adapter164-20261109-004200/runtime/native-adapter164-built33.
- Runtime binary SHA256: 7a68ac1999cad3f6088fc6cb4004295d309a2b6de6c8643d570ef085e90b5962.
- native-subset34: seven actual MIR→VIR→WF/modes→SST cases and eight refusals.
- vir-semantics39: 50 serialized-VIR evaluations, fresh initialized binders,
  actual first/second Alignment operands and actual constant1/16 controls.
  This is not native application execution or a compiler-equivalence theorem.
- structural36: three new fixed-opcode/serialization/type structural tests pass.
- parent-regressions37:27 corrected parent163 structural tests pass on final164.
- default-off38: one default-off refusal test passes.
- All final commands bind the same candidate source inventory. Final34/39 also
  pin existing regular command-line files at entry and exit. Selected toolchain
  exit endpoints are not loader/bootstrap/runtime/allocator attestation.

## Preserved failures and qualifications

- Builds2,3,11,14,22 fail with retained raw diagnostics; no failure is reset.
- Test35 fails because its pointer-equality fixture expected the new equality
  guard, but the actual MIR is refused earlier at pointer retag. The corrected
  assertion is rerun as39; the equality guard itself has source, not observed
  fixture-path coverage. The original35 failure/raw stderr remain retained.
- Command4's monitor failed after wait at a denied post-reap signal0 probe;
  actual root exit status and test result were lost and remain UNESTABLISHED.
  Trace/raw streams/recovery record/later group absence remain retained.
- Diagnostics7,13,16 and21 return process0 but include incomplete/refused
  positive fixtures at their own endpoints. They are not final passing runs.
- Diagnostic9 predates canonical WF/modes; its three SST outputs are not
  inherited as WF/modes proof. Final34 is the applicable observed endpoint.
- Source-only prepare failure exposed command28's false input-mutation flag:
  it counted its newly created output JSON as a changed input set. Original28
  is unchanged; the corrected monitor is used in the new final executions.
- Final source review found unsupported raw-pointer equality would use ordinary
  VIR equality without an established executable-address/full-pointer relation.
  It now explicitly refuses, with a native pointer-equality negative fixture.
- Initial163-consumption path failure and missing installed rust-library source
  tree are retained/documented; neither is a successful source/bootstrap proof.
- Historical15817/32 failed strict2GiB and16019/32 failed disk budgets stay
  sealed and separate. No old target is changed, reused for writes or deleted.
- Earlier runtime binaries were overwritten by Cargo; only launch hashes and
  raw receipts remain for them, except the separately retained built23 binary.
  The final built33 binary is retained uniquely
  at the runtime path, outside the archive. No historical byte retention claim.

## Patch and boundary

source-relative164.patch is exact relative to authenticated sealed160;
distinct164-on-repair163.patch isolates164 after the authenticated four-file163
repair. Both undergo independent unified-hunk byte reconstruction. There are
21 combined changed/new files, 17 distinct164 files.
No parent/shared/native source integration, Git write, network, cleanup,
subdelegation or original application execution occurs.

One mathematical schema remains conditionally adopted, operative laws0,
issuer applications0, solver runs0, native acceptance0, native export REFUSED.
G1/G2 OPEN; all18 OPEN; two-phase acknowledged durability remains first.
Independent exact-code review and explicit parent disposition are mandatory
before any operative issuer use. No native event/pointer/frame assumptions are
silently installed to make this partial adapter appear nonempty.
