import hashlib
import json
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parent
BASE = Path('/private/tmp/redb-continuation160-20261109-001100')


def sha(data):
    return hashlib.sha256(data).hexdigest()


expected = {
    'HANDOFF160.json': 'be55df205b4506ddcc30fbe60a7e1fb1bd26b191a9e5853be369d44d1bc2ca5e',
    'HANDOFF160.tar.gz': 'bdfae6498df1a48822229657fca60ece8e1a424eab80fa32cdea4883a69fd1dd',
}
for name, digest in expected.items():
    assert sha((BASE / name).read_bytes()) == digest, name
manifest = json.loads((BASE / 'MANIFEST160.json').read_text())
records = {item['path']: item for item in manifest['files']}
members = set()
with tarfile.open(BASE / 'HANDOFF160.tar.gz', 'r:gz') as archive:
    for member in archive:
        assert member.isfile() and member.name not in members, member.name
        members.add(member.name)
        data = archive.extractfile(member).read()
        assert (BASE / member.name).read_bytes() == data, member.name
        if member.name == 'MANIFEST160.json':
            continue
        item = records[member.name]
        assert len(data) == item['bytes'] and sha(data) == item['sha256'], member.name
assert members == set(records) | {'MANIFEST160.json'}
output = dict(baseline=expected, members=len(members), errors=[],
              original158='17/32 SEALED FAILED strict2GiB, unchanged',
              original160='19/32 SEALED FAILED global-disk preflight18, unchanged')
(ROOT / 'AUTHENTICATION164.json').write_text(json.dumps(output, indent=2) + '\n')
(ROOT / 'baseline-source164.json').write_text(json.dumps(
    [dict(path=item['path'].removeprefix('candidate/'), bytes=item['bytes'], sha256=item['sha256'])
     for item in manifest['files'] if item['path'].startswith('candidate/')], indent=2) + '\n')
print(json.dumps(output, indent=2))
