struct AllocationCut156 {
    header: u64,
    align: u64,
    record: Value,
}

fn normal_dominates156(body: &Body<'_>, dominator: rustc_middle::mir::BasicBlock, target: rustc_middle::mir::BasicBlock) -> bool {
    let mut queue = VecDeque::from([rustc_middle::mir::START_BLOCK]);
    let mut visited = BTreeSet::new();
    while let Some(block) = queue.pop_front() {
        if block == dominator || !visited.insert(block.as_usize()) { continue; }
        if block == target { return false; }
        for successor in body.basic_blocks[block].terminator().successors() {
            if !body.basic_blocks[successor].is_cleanup { queue.push_back(successor); }
        }
    }
    true
}

fn resolved_calls156<'tcx>(tcx: TyCtxt<'tcx>, instance: ty::Instance<'tcx>) -> Vec<(ty::Instance<'tcx>, usize, Value)> {
    let body = tcx.instance_mir(instance.def);
    let mut calls = Vec::new();
    for (block, data) in body.basic_blocks.iter_enumerated() {
        let TerminatorKind::Call { func, args, destination, target, unwind, .. } = &data.terminator().kind else { continue };
        let function_type = instantiate(tcx, instance, func.ty(&body.local_decls, tcx));
        let ty::FnDef(definition, arguments) = *function_type.kind() else { continue };
        let resolved = ty::Instance::try_resolve(tcx, ty::TypingEnv::fully_monomorphized(), definition, arguments.skip_binder());
        if let Ok(Some(callee)) = resolved {
            calls.push((callee, block.as_usize(), json!({
                "caller": format!("{instance:?}"), "callee": format!("{callee:?}"),
                "substitutions": format!("{:?}", callee.args), "block": block.as_usize(),
                "arguments": format!("{args:?}"), "destination": format!("{destination:?}"),
                "normal_target": format!("{target:?}"), "unwind": format!("{unwind:?}"), "cleanup": data.is_cleanup,
                "source": format!("{:?}", data.terminator().source_info),
            })));
        }
    }
    calls
}

fn allocation_cut156<'tcx>(tcx: TyCtxt<'tcx>, store: &TypedStore<'tcx>) -> AllocationCut156 {
    let allocations = resolved_calls156(tcx, store.instance).into_iter().filter(|(callee, _, _)| {
        tcx.crate_name(callee.def_id().krate).as_str() == "alloc"
            && tcx.opt_item_name(callee.def_id()).is_some_and(|name| name.as_str() == "allocate_for_slice")
    }).collect::<Vec<_>>();
    assert_eq!(allocations.len(), 1, "unique source-connected Arc allocation required");
    let (slice, allocation_block, initial) = &allocations[0];
    let store_body = tcx.instance_mir(store.instance.def);
    let TerminatorKind::Call { destination, target, .. } = &store_body.basic_blocks.iter().nth(*allocation_block).unwrap().terminator().kind else { unreachable!() };
    let allocation_local = destination.as_local().expect("allocation destination local");
    assert!(target.is_some());
    let (base_block, base_statement, base_definition) = unique_definition(store_body, store.base);
    let (store_block, _, _) = unique_definition(store_body, store.pointer);
    let base_basic_block = store_body.basic_blocks.iter_enumerated().find(|(block, _)| block.as_usize() == base_block).unwrap().0;
    let store_basic_block = store_body.basic_blocks.iter_enumerated().find(|(block, _)| block.as_usize() == store_block).unwrap().0;
    assert!(normal_dominates156(store_body, target.unwrap(), base_basic_block));
    assert!(normal_dominates156(store_body, base_basic_block, store_basic_block));
    let Rvalue::Cast(_, Operand::Copy(raw_payload), _) = base_definition else { panic!("payload thin-pointer cast required") };
    let (payload_block, payload_statement, payload_definition) = unique_definition(store_body, raw_payload.as_local().expect("raw payload local"));
    assert_eq!(base_block, payload_block);
    assert!(payload_statement < base_statement);
    let Rvalue::RawPtr(_, payload_place) = payload_definition else { panic!("actual raw payload projection required") };
    assert_eq!(payload_place.local, allocation_local);
    assert_eq!(payload_place.projection.len(), 2);
    assert!(matches!(payload_place.projection[0], ProjectionElem::Deref));
    let ProjectionElem::Field(payload_field, _) = payload_place.projection[1] else { panic!("payload field required") };
    assert_eq!(payload_field.as_usize(), 2);
    assert_eq!(instantiate(tcx, store.instance, payload_place.ty(&store_body.local_decls, tcx).ty), Ty::new_slice(tcx, tcx.types.u8));
    let definitions = store_body.basic_blocks.iter().flat_map(|data| data.statements.iter()).filter(|statement| {
        matches!(&statement.kind, StatementKind::Assign(assignment) if assignment.0.as_local() == Some(allocation_local))
    }).count();
    assert_eq!(definitions, 0, "allocation result must not be replaced by a statement assignment");
    let call_definitions = store_body.basic_blocks.iter().filter(|data| matches!(&data.terminator().kind,
        TerminatorKind::Call { destination, .. } if destination.as_local() == Some(allocation_local))).count();
    assert_eq!(call_definitions, 1);
    assert_eq!(slice.args.type_at(0), tcx.types.u8);
    let body = tcx.instance_mir(slice.def);
    let return_type = instantiate(tcx, *slice, body.local_decls[RETURN_PLACE].ty);
    let ty::RawPtr(inner, mutability) = return_type.kind() else { panic!("ArcInner pointer required") };
    assert!(mutability.is_mut());
    let ty::Adt(definition, arguments) = inner.kind() else { panic!("ArcInner ADT required") };
    assert_eq!(tcx.crate_name(definition.did().krate).as_str(), "alloc");
    assert_eq!(tcx.item_name(definition.did()).as_str(), "ArcInner");
    assert_eq!(arguments.type_at(0), Ty::new_slice(tcx, tcx.types.u8));
    let fields = &definition.non_enum_variant().fields;
    assert_eq!(fields.len(), 3);
    let field_names = fields.iter().map(|field| tcx.item_name(field.did).as_str().to_owned()).collect::<Vec<_>>();
    assert_eq!(field_names, vec!["strong", "weak", "data"]);
    let layout = tcx.layout_of(ty::TypingEnv::fully_monomorphized().as_query_input(*inner)).expect("compiler ArcInner DST layout");
    let header = layout.fields.offset(2).bytes();
    let align = layout.align.abi.bytes();
    assert!(header > 0 && align.is_power_of_two() && header % align == 0);
    let mut queue = VecDeque::from([(*slice, vec![initial.clone()], 0usize, Vec::new())]);
    let mut traversed = 0usize;
    let mut records = Vec::new();
    let mut backend_paths = Vec::new();
    while let Some((instance, path, depth, mut ancestors)) = queue.pop_front() {
        traversed += 1;
        assert!(traversed <= 350 && depth <= 14, "allocation connection bound exhausted");
        assert!(!ancestors.contains(&instance), "recursive allocation connection unsupported");
        ancestors.push(instance);
        if !tcx.is_mir_available(instance.def_id()) { continue; }
        let name = tcx.opt_item_name(instance.def_id()).map(|name| name.as_str().to_owned()).unwrap_or_default();
        let body = tcx.instance_mir(instance.def);
        records.push(json!({"instance": format!("{instance:?}"), "name": name,
            "source_span": format!("{:?}", tcx.def_span(instance.def_id())),
            "mir_sha256": digest(format!("{body:#?}").as_bytes()), "mir": format!("{body:#?}"), "path": path}));
        for (callee, call_block, call) in resolved_calls156(tcx, instance) {
            let mut next_path = path.clone();
            next_path.push(call);
            let callee_name = tcx.opt_item_name(callee.def_id()).map(|name| name.as_str().to_owned()).unwrap_or_default();
            if tcx.crate_name(callee.def_id().krate).as_str() == "alloc" && callee_name == "alloc_impl_runtime" {
                let caller_body = tcx.instance_mir(instance.def);
                let TerminatorKind::Call { args, .. } = &caller_body.basic_blocks.iter().nth(call_block).unwrap().terminator().kind else { unreachable!() };
                assert_eq!(args.len(), 2);
                let Operand::Constant(constant) = &args[1].node else { panic!("actual nonzeroed constant required") };
                assert_eq!(constant.const_.try_eval_scalar_int(tcx, ty::TypingEnv::fully_monomorphized()).expect("zeroed boolean constant").to_u8(), 0);
            }
            if tcx.crate_name(callee.def_id().krate).as_str() == "alloc" && callee_name == "__rust_alloc" {
                let event_body = tcx.instance_mir(instance.def);
                let event_data = event_body.basic_blocks.iter().nth(call_block).unwrap();
                let TerminatorKind::Call { args, destination, target, .. } = &event_data.terminator().kind else { unreachable!() };
                assert_eq!(args.len(), 2);
                assert_eq!(instantiate(tcx, instance, args[0].node.ty(&event_body.local_decls, tcx)), tcx.types.usize);
                assert_eq!(instantiate(tcx, instance, destination.ty(&event_body.local_decls, tcx).ty), Ty::new_mut_ptr(tcx, tcx.types.u8));
                assert!(!event_data.is_cleanup && target.is_some());
                let scope = &event_body.source_scopes[event_data.terminator().source_info.scope];
                let (inline_instance, _) = scope.inlined.expect("inlined alloc owner required");
                assert_eq!(tcx.crate_name(inline_instance.def_id().krate).as_str(), "alloc");
                assert_eq!(tcx.item_name(inline_instance.def_id()).as_str(), "alloc");
                backend_paths.push(json!({"instance": format!("{callee:?}"), "path": next_path,
                    "inlined_alloc_owner": format!("{inline_instance:?}"), "source_scope": format!("{scope:?}"),
                    "destination_type": "*mut u8", "size_type": "usize", "event_resource_issuance": "OPEN_NOT_TRUSTED"}));
            }
            if matches!(callee_name.as_str(), "allocate_for_layout" | "initialize_arcinner" | "arcinner_layout_for_value_layout"
                | "allocate" | "alloc_impl" | "alloc_impl_runtime" | "alloc" | "call_once" | "" ) {
                if depth < 14 { queue.push_back((callee, next_path, depth + 1, ancestors.clone())); }
            }
        }
    }
    assert_eq!(backend_paths.len(), 1, "exact native nonzero nonzeroed allocator event required");
    AllocationCut156 { header, align, record: json!({
        "schema": "allocation156-fixed-unadopted-source-connected-cut", "entry_call": initial,
        "arcinner_type": format!("{inner:?}"), "compiler_layout": format!("{layout:?}"),
        "payload_offset": header, "allocation_align": align,
        "strong_offset": layout.fields.offset(0).bytes(), "weak_offset": layout.fields.offset(1).bytes(),
        "payload_reaching_definition": format!("{payload_definition:?}"), "payload_cast": format!("{base_definition:?}"),
        "actual_allocation_result": format!("{allocation_local:?}"), "actual_payload_base": format!("{:?}", store.base),
        "actual_offset_index": format!("{:?}", store.index),
        "typed_instances_and_paths": records, "native_alloc_backend_paths": backend_paths,
        "original_event_resource_correspondence": "OPEN_UNADOPTED_NO_NATIVE_PERMISSION_ISSUED",
        "iterator_index_bound": "OPEN_NOT_INFERRED_FROM_SOME", "header_initialization": "OPEN_RETAINED_RAW_HEADER_IS_NOT_NATIVE_INITIALIZATION",
        "allocation_reuse": "CONDITIONALLY_PERMITTED155_G1_G2_OPEN_NOT_INSTALLED_AS_NATIVE_RULE",
    }) }
}

