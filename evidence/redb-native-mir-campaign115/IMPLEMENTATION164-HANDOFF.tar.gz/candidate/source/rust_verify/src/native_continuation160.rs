include!("selection160.rs");

use rustc_middle::mir::visit::{PlaceContext, Visitor};
use std::collections::{HashMap, HashSet};
use std::sync::Arc;
use vir::ast::{self, Expr, ExprX, IntRange, Primitive, SpannedTyped, TypX, VarIdent, VarIdentDisambiguate};
use vir::native_resource::continuation160::{
    ActualValues160, AlignmentAsUsize160, Applicability160, NativeProgram160, NativeReturn160, Refusal160,
    ResourceBindings160, ResourceTypes160, SelectedCall160,
};

#[derive(Clone, Copy, PartialEq, Eq, Hash)]
struct Origin160<'tcx> {
    owner: ty::Instance<'tcx>,
    callee: ty::Instance<'tcx>,
    location: rustc_middle::mir::Location,
}

struct NativePoint160<'tcx> {
    location: rustc_middle::mir::Location,
    cleanup: bool,
    moved: Vec<Place<'tcx>>,
    overwritten: Vec<Place<'tcx>>,
}

struct Destructive160<'tcx> {
    moved: Vec<Place<'tcx>>,
    overwritten: Vec<Place<'tcx>>,
}

impl<'tcx> Visitor<'tcx> for Destructive160<'tcx> {
    fn visit_operand(&mut self, operand: &Operand<'tcx>, location: rustc_middle::mir::Location) {
        if let Operand::Move(place) = operand { self.moved.push(*place); }
        self.super_operand(operand, location);
    }

    fn visit_place(&mut self, place: &Place<'tcx>, context: PlaceContext, location: rustc_middle::mir::Location) {
        if context.is_mutating_use() { self.overwritten.push(*place); }
        self.super_place(place, context, location);
    }
}

fn span160() -> vir::messages::Span {
    vir::messages::Span { raw_span: Arc::new(()), id: 0, data: vec![],
        as_string: "compiler-owned original native allocation continuation160".into() }
}

fn mir_value160<'tcx>(tcx: TyCtxt<'tcx>, owner: ty::Instance<'tcx>, body: &Body<'tcx>,
    operand: &Operand<'tcx>) -> Result<Expr, Refusal160>
{
    if instantiate(tcx, owner, operand.ty(&body.local_decls, tcx)) != tcx.types.usize {
        return Err(Refusal160::WrongValueType);
    }
    let typ = Arc::new(TypX::Int(IntRange::USize));
    let expression = match operand {
        Operand::Copy(place) | Operand::Move(place) if place.projection.is_empty() => {
            ExprX::Var(VarIdent(Arc::new("native_mir_local".into()),
                VarIdentDisambiguate::RustcId(place.local.as_usize())))
        }
        Operand::Constant(value) => {
            let scalar = value.const_.try_eval_scalar_int(tcx, ty::TypingEnv::fully_monomorphized())
                .ok_or(Refusal160::WrongValueType)?;
            let integer = scalar.to_target_usize(tcx);
            if integer == 0 { return Err(Refusal160::UnsupportedOutcome); }
            ExprX::Const(ast::Constant::Int(integer.into()))
        }
        _ => return Err(Refusal160::WrongValueType),
    };
    Ok(SpannedTyped::new(&span160(), &typ, expression))
}

fn collect_native_points160<'tcx>(body: &Body<'tcx>) -> Vec<NativePoint160<'tcx>> {
    let mut points = vec![];
    for (block, data) in body.basic_blocks.iter_enumerated() {
        for statement_index in 0..=data.statements.len() {
            let location = rustc_middle::mir::Location { block, statement_index };
            let mut effects = Destructive160 { moved: vec![], overwritten: vec![] };
            if statement_index < data.statements.len() {
                let statement = &data.statements[statement_index];
                effects.visit_statement(statement, location);
                match statement.kind {
                    StatementKind::StorageDead(local) | StatementKind::StorageLive(local) =>
                        effects.overwritten.push(Place::from(local)),
                    _ => {}
                }
            } else {
                effects.visit_terminator(data.terminator(), location);
            }
            points.push(NativePoint160 { location, cleanup: data.is_cleanup,
                moved: effects.moved, overwritten: effects.overwritten });
        }
    }
    points
}

fn check_coverage160(body: &Body<'_>, points: &[NativePoint160<'_>]) -> Result<(), Refusal160> {
    let expected = body.basic_blocks.iter_enumerated().flat_map(|(block, data)|
        (0..=data.statements.len()).map(move |statement_index|
            rustc_middle::mir::Location { block, statement_index })).collect::<HashSet<_>>();
    let mut actual = HashSet::new();
    for point in points {
        if !actual.insert(point.location) { return Err(Refusal160::DuplicateOccurrence); }
        if point.cleanup != body.basic_blocks[point.location.block].is_cleanup {
            return Err(Refusal160::WrongNormalEdge);
        }
    }
    if actual != expected { return Err(Refusal160::MissingCoverage); }
    Ok(())
}

fn same_operand160<'tcx>(left: &Operand<'tcx>, right: &Operand<'tcx>) -> bool {
    match (left, right) {
        (Operand::Copy(left), Operand::Copy(right)) | (Operand::Move(left), Operand::Move(right)) => left == right,
        (Operand::Constant(left), Operand::Constant(right)) => left.const_ == right.const_,
        _ => false,
    }
}

fn check_selected160<'tcx>(tcx: TyCtxt<'tcx>, selected: &SelectedNative160<'tcx>) -> Result<(), Refusal160> {
    let body = tcx.instance_mir(selected.owner.def);
    let data = &body.basic_blocks[selected.block];
    let TerminatorKind::Call { func, args, destination, target, .. } = &data.terminator().kind else {
        return Err(Refusal160::WrongNormalEdge);
    };
    if data.is_cleanup || *target != Some(selected.continuation)
        || body.basic_blocks[selected.continuation].is_cleanup || *destination != selected.result
        || args.len() != 2 || !same_operand160(&args[0].node, &selected.size)
        || !same_operand160(&args[1].node, &selected.align)
    { return Err(Refusal160::WrongNormalEdge); }
    let typ = instantiate(tcx, selected.owner, func.ty(&body.local_decls, tcx));
    let ty::FnDef(definition, arguments) = *typ.kind() else { return Err(Refusal160::WrongNormalEdge); };
    let instance = ty::Instance::try_resolve(tcx, ty::TypingEnv::fully_monomorphized(), definition, arguments.skip_binder())
        .map_err(|_| Refusal160::WrongNormalEdge)?.ok_or(Refusal160::WrongNormalEdge)?;
    if instance != selected.callee { return Err(Refusal160::WrongNormalEdge); }
    if selected.result.projection.len() != 0 || instantiate(tcx, selected.owner,
        selected.result.ty(&body.local_decls, tcx).ty) != Ty::new_mut_ptr(tcx, tcx.types.u8)
    { return Err(Refusal160::WrongValueType); }
    Ok(())
}

enum BoundOperand160<'tcx> {
    ActualSize(Operand<'tcx>),
    AlignmentAsUsize { actual: Operand<'tcx>, method: ty::Instance<'tcx> },
}

type Edge160<'tcx> = NativeReturn160<Origin160<'tcx>, BoundOperand160<'tcx>, Place<'tcx>>;

fn alignment_as_usize160<'tcx>(tcx: TyCtxt<'tcx>, owner: ty::Instance<'tcx>, body: &Body<'tcx>,
    actual: &Operand<'tcx>, serial: u64) -> Result<(AlignmentAsUsize160, ty::Instance<'tcx>), Refusal160>
{
    let actual_type = instantiate(tcx, owner, actual.ty(&body.local_decls, tcx));
    let ty::Adt(definition, arguments) = *actual_type.kind() else { return Err(Refusal160::WrongValueType); };
    if tcx.crate_name(definition.did().krate).as_str() != "core"
        || tcx.def_path_str(definition.did()) != "core::mem::alignment::Alignment" {
        return Err(Refusal160::WrongValueType);
    }
    let methods = tcx.inherent_impls(definition.did()).iter().flat_map(|implementation|
        tcx.associated_items(*implementation).in_definition_order()).filter(|item|
            item.name().as_str() == "as_usize").collect::<Vec<_>>();
    if methods.len() != 1 { return Err(Refusal160::WrongValueType); }
    let method = ty::Instance::try_resolve(tcx, ty::TypingEnv::fully_monomorphized(), methods[0].def_id, arguments)
        .map_err(|_| Refusal160::WrongValueType)?.ok_or(Refusal160::WrongValueType)?;
    let signature = tcx.fn_sig(method.def_id()).instantiate(tcx, method.args).skip_binder();
    if signature.inputs() != [actual_type] || signature.output() != tcx.types.usize
        || !tcx.is_mir_available(method.def_id()) { return Err(Refusal160::WrongValueType); }
    let local = match actual {
        Operand::Copy(place) | Operand::Move(place) if place.projection.is_empty() => place.local,
        _ => return Err(Refusal160::WrongValueType),
    };
    let typ = Arc::new(TypX::Datatype(ast::Dt::Path(Arc::new(ast::PathX { krate: ast::CrateId::Core,
        segments: Arc::new(vec![Arc::new("mem".into()), Arc::new("alignment".into()), Arc::new("Alignment".into())]) })), Arc::new(vec![]), Arc::new(vec![])));
    let operand = SpannedTyped::new(&span160(), &typ, ExprX::Var(VarIdent(Arc::new("native_mir_local".into()),
        VarIdentDisambiguate::RustcId(local.as_usize()))));
    let projection = AlignmentAsUsize160::new(operand, VarIdent(Arc::new("actual_alignment_as_usize160".into()),
        VarIdentDisambiguate::NativeResource(serial + 2)))?;
    Ok((projection, method))
}

fn lower_selected160<'tcx>(tcx: TyCtxt<'tcx>, selected: SelectedNative160<'tcx>,
    types: &ResourceTypes160) -> Result<Edge160<'tcx>, Refusal160>
{
    check_selected160(tcx, &selected)?;
    let body = tcx.instance_mir(selected.owner.def);
    let size = mir_value160(tcx, selected.owner, body, &selected.size)?;
    let serial = selected.block.as_usize() as u64 * 3;
    let (alignment, method) = alignment_as_usize160(tcx, selected.owner, body, &selected.align, serial)?;
    let pointer_type = Arc::new(TypX::Primitive(Primitive::Ptr,
        Arc::new(vec![Arc::new(TypX::Int(IntRange::U(8)))])));
    let full_pointer = SpannedTyped::new(&span160(), &pointer_type,
        ExprX::Var(VarIdent(Arc::new("native_mir_local".into()),
            VarIdentDisambiguate::RustcId(selected.result.local.as_usize()))));
    let resources = ResourceBindings160::new(&span160(), types,
        VarIdent(Arc::new("native_raw160".into()), VarIdentDisambiguate::NativeResource(serial)),
        VarIdent(Arc::new("native_dealloc160".into()), VarIdentDisambiguate::NativeResource(serial + 1)))?;
    let call = SelectedCall160 {
        origin: Origin160 { owner: selected.owner, callee: selected.callee,
            location: rustc_middle::mir::Location { block: selected.block, statement_index: body.basic_blocks[selected.block].statements.len() } },
        size: BoundOperand160::ActualSize(selected.size),
        align: BoundOperand160::AlignmentAsUsize { actual: selected.align, method }, result: selected.result,
        normal: selected.continuation.as_usize(), call_point: selected.block.as_usize(),
    };
    NativeReturn160::lower(call, ActualValues160 { size, alignment, full_pointer }, resources, Applicability160::pending())
}

fn lower_original160<'tcx>(tcx: TyCtxt<'tcx>, store: &TypedStore<'tcx>, allocation: &AllocationCut156, enabled: bool) -> Value {
    if !enabled { return json!({"status":"DEFAULT_OFF", "issuance_gate":"PENDING_REVIEW", "native_export":"REFUSED"}); }
    let selected = select_original160(tcx, store, allocation);
    check_selected160(tcx, &selected).unwrap();
    let owner = selected.owner;
    let body = tcx.instance_mir(owner.def);
    let points = collect_native_points160(body);
    check_coverage160(body, &points).unwrap();
    let types = ResourceTypes160::unresolved_native_ports();
    let mut controls = Vec::new();
    let mut wrong = select_original160(tcx, store, allocation);
    wrong.continuation = wrong.block;
    controls.push(("actual_wrong_normal_edge", check_selected160(tcx, &wrong).err()));
    let mut wrong = select_original160(tcx, store, allocation);
    std::mem::swap(&mut wrong.size, &mut wrong.align);
    controls.push(("actual_swapped_size_align", check_selected160(tcx, &wrong).err()));
    let mut wrong = select_original160(tcx, store, allocation);
    wrong.result = Place::from(RETURN_PLACE);
    controls.push(("actual_wrong_result_place", check_selected160(tcx, &wrong).err()));
    let mut incomplete = collect_native_points160(body);
    incomplete.pop();
    controls.push(("missing_actual_statement_or_terminator", check_coverage160(body, &incomplete).err()));
    let mut duplicate = collect_native_points160(body);
    let duplicate_first = NativePoint160 { location: duplicate[0].location, cleanup: duplicate[0].cleanup,
        moved: duplicate[0].moved.clone(), overwritten: duplicate[0].overwritten.clone() };
    duplicate.push(duplicate_first);
    controls.push(("duplicate_actual_statement_or_terminator", check_coverage160(body, &duplicate).err()));
    let mut wrong_cleanup = collect_native_points160(body);
    wrong_cleanup[0].cleanup = !wrong_cleanup[0].cleanup;
    controls.push(("wrong_actual_cleanup_context", check_coverage160(body, &wrong_cleanup).err()));
    for (name, refusal) in &controls { assert!(refusal.is_some(), "negative control did not refuse: {name}"); }
    let edge = lower_selected160(tcx, selected, &types).unwrap();
    let original_origin = edge.call().origin;
    let mut actual_occurrences = HashSet::new();
    for (block, data) in body.basic_blocks.iter_enumerated() {
        let TerminatorKind::Call { func, .. } = &data.terminator().kind else { continue; };
        let function_type = instantiate(tcx, owner, func.ty(&body.local_decls, tcx));
        let ty::FnDef(definition, arguments) = *function_type.kind() else { continue; };
        let resolved = ty::Instance::try_resolve(tcx, ty::TypingEnv::fully_monomorphized(), definition, arguments.skip_binder()).unwrap();
        if resolved == Some(original_origin.callee) {
            actual_occurrences.insert(Origin160 { owner, callee: original_origin.callee,
                location: rustc_middle::mir::Location { block, statement_index: data.statements.len() } });
        }
    }
    let typed_pointer = format!("{:?}", edge.values().full_pointer.typ);
    let typed_ports = edge.resources().parameters().iter().map(|parameter|
        json!({"mode":format!("{:?}",parameter.x.mode),"type":format!("{:?}",parameter.x.typ)})).collect::<Vec<_>>();
    let refusal = format!("{:?}", edge.admit_to_sst().err().unwrap());
    let open = format!("{:?}", edge.applicability().open());
    let program = NativeProgram160::connect(vec![edge], &actual_occurrences).unwrap();
    assert_eq!(program.admit_to_sst(), Err(Refusal160::PendingReview));
    let mut by_location = HashMap::new();
    for point in &points {
        assert!(by_location.insert(point.location, point).is_none());
    }
    json!({
        "task":"implementation160-distinct-from158", "issuance_gate":"PENDING_REVIEW", "native_export":"REFUSED",
        "lowering":"ACTUAL_MIR_CALL_TO_TYPED_NATIVE_RETURN160_OPCODE_NOT_A_RESOURCE_ISSUE",
        "original_static_calls":program.edges().len(), "complete_statement_terminator_points":points.len(),
        "cleanup_points":points.iter().filter(|point|point.cleanup).count(),
        "move_places":points.iter().map(|point|point.moved.len()).sum::<usize>(),
        "destructive_places":points.iter().map(|point|point.overwritten.len()).sum::<usize>(),
        "tracked_nominal_ports":typed_ports, "full_pointer_vir_type":typed_pointer,
        "sst_refusal":refusal, "all_checked_obligations_open":open,
        "native_dynamic_semantic_witness":"UNINHABITED_NO_INTERPRETATION_IMPLEMENTED",
        "dynamic_binder":"PER_NATIVE_ACTIVATION_AND_EACH_CALL_TRAVERSAL_SYMBOLIC_ONLY_NOT_STATIC_ID_AUTHORITY",
        "vstd_type_definition_resolution":"OPEN_ORIGINAL_RUSTC_ANALYSIS_DOES_NOT_LOAD_VERIFIED_VSTD_KRATE",
        "resource_flow":"CONDITIONAL_WF_ONLY_NOT_NATIVE_GLOBAL_AFFINITY_PROOF",
        "negative_controls":controls.iter().map(|(name,refusal)| json!({"name":name,"refusal":format!("{refusal:?}"),
            "classification":"ACTUAL_ORIGINAL_MATCHING_COVERAGE_ADMISSION_PATH_NO_SMT_NOT_SEMANTIC_COUNTEREXAMPLE"})).collect::<Vec<_>>(),
        "alignment_numeric_semantics":"EXACT_TYPED_NATIVE_ALIGNMENT_AS_USIZE_OPCODE_NO_REPR_CAST_NO_ASSUMED_USIZE_VALUE_INTERPRETATION_OPEN",
        "accepted_original_allocations":0,"accepted_original_stores":0,"accepted_original_bodies":0,
        "mathematical_schemas_conditionally_adopted":1,"operative_laws_installed":0,"actual_issuance":0,"all18":"OPEN"
    })
}
