use crate::attributes::{AttrPublish, VerifierAttrs, get_mode, get_ret_mode, get_var_mode};
use crate::automatic_derive::AutomaticDeriveAction;
use crate::context::{BodyCtxt, Context, ContextX, HeaderSetting};
use crate::pre_header::PreHeader;
use crate::resolve_traits::{ResolutionResult, ResolvedItem};
use crate::rust_to_vir::State;
use crate::rust_to_vir_base::{
    check_fn_opaque_ty, check_generics_bounds_no_polarity, def_id_to_vir_path, local_to_var,
    no_body_param_to_var,
};
use crate::rust_to_vir_base::{mk_visibility, qpath_to_ident};
use crate::rust_to_vir_expr::{
    add_param_decls, expr_to_vir_consume, param_pat_to_decl, param_pat_to_destructure,
    param_pat_to_mut_var,
};
use crate::util::{err_span, err_span_bare};
use crate::verus_items::{BuiltinTypeItem, VerusItem};
use crate::{unsupported_err, unsupported_err_unless};
use rustc_hir::{
    Attribute, Body, BodyId, Expr, ExprKind, FnDecl, FnHeader, FnSig, Generics, HeaderSafety,
    HirId, Param, Pat, PatKind, Safety,
};
use rustc_middle::ty::{
    AdtDef, AliasTermKind, AliasTyKind, BoundRegion, BoundRegionKind, BoundVar, Clause, ClauseKind,
    ConstKind, GenericArg, GenericArgKind, GenericArgsRef, IsRigid, Region, RegionExt, RegionKind,
    TyCtxt, TyKind, TypeVisitableExt, TypingEnv, ValTreeKind, Value,
};
use rustc_mir_build_verus::verus::BodyErasure;
use rustc_span::Span;
use rustc_span::def_id::DefId;
use rustc_span::symbol::Ident;
use std::collections::{HashMap, HashSet};
use std::sync::Arc;
use std::vec;
use vir::ast::{
    BodyVisibility, CrateId, Fun, FunX, FunctionAttrsX, FunctionKind, FunctionStubX, FunctionX,
    ItemKind, Mode, OpaqueTypes, Opaqueness, ParamX, Path, Typ, TypDecoration, TypX,
    UnwrapParameter, VarIdent, VirErr, Visibility,
};
use vir::ast_util::{air_unique_var, unit_typ};
use vir::def::{RETURN_VALUE, RETURN_VALUE_ASYNC_FUTURE, Spanned, VERUS_SPEC};
use vir::sst_util::subst_typ;

#[derive(Debug, Clone)]
enum FnOrConstSigEnum<'tcx> {
    Fn(&'tcx FnSig<'tcx>),
    ConstVar(Typ),
}

#[derive(Debug, Clone)]
pub(crate) struct FnOrConstSig<'tcx> {
    span: Span,
    sig: FnOrConstSigEnum<'tcx>,
}

impl<'tcx> FnOrConstSig<'tcx> {
    pub(crate) fn sig(sig: &'tcx FnSig<'tcx>) -> Self {
        FnOrConstSig { span: sig.span, sig: FnOrConstSigEnum::Fn(sig) }
    }

    pub(crate) fn const_var(span: Span, typ: Typ) -> Self {
        FnOrConstSig { span, sig: FnOrConstSigEnum::ConstVar(typ) }
    }

    fn output_span(&self) -> Span {
        match &self.sig {
            FnOrConstSigEnum::Fn(sig) => sig.decl.output.span(),
            FnOrConstSigEnum::ConstVar(_) => self.span,
        }
    }

    fn safety(&self) -> Safety {
        match &self.sig {
            FnOrConstSigEnum::Fn(sig) => match sig.header.safety {
                HeaderSafety::Normal(s) => s,
                _ => Safety::Unsafe,
            },
            FnOrConstSigEnum::ConstVar(_) => Safety::Safe,
        }
    }

    fn asyncness(&self) -> rustc_hir::IsAsync {
        match &self.sig {
            FnOrConstSigEnum::Fn(sig) => sig.header.asyncness,
            FnOrConstSigEnum::ConstVar(_) => rustc_hir::IsAsync::NotAsync,
        }
    }

    fn item_kind(&self) -> ItemKind {
        match &self.sig {
            FnOrConstSigEnum::Fn(..) => ItemKind::Function,
            FnOrConstSigEnum::ConstVar(..) => ItemKind::Const,
        }
    }

    fn override_body_visibility(
        &self,
        publish: Option<AttrPublish>,
        visibility: Visibility,
        body_visibility: BodyVisibility,
    ) -> BodyVisibility {
        match (&self.sig, publish) {
            // REVIEW: syntax.rs currently implements much of the Publish logic by comparing
            // the "open"/"closed" keywords to the "pub" syntax.
            // However, "pub" isn't visible to trait implementations in the syntax,
            // so it would make more sense to move the logic out of syntax.rs and into this file.
            // For now, just implement here the common case where trait consts are open by default
            // (as normal consts are).
            // TODO: handle more Publish variations for trait consts
            (FnOrConstSigEnum::ConstVar(..), None) => BodyVisibility::Visibility(visibility),
            _ => body_visibility,
        }
    }
}

pub(crate) fn autospec_fun(path: &vir::ast::Path, method_name: String) -> vir::ast::Path {
    // turn a::b::c into a::b::method_name
    let mut pathx = (**path).clone();
    let mut segments = (*pathx.segments).clone();
    *segments.last_mut().expect("empty path") = Arc::new(method_name);
    pathx.segments = Arc::new(segments);
    Arc::new(pathx)
}

struct Autospec {
    /// This function should redirect to the following function:
    redirect_to: Option<vir::ast::Fun>,
    /// Which might need to be created
    /// (for when_used_as_spec, the user supplies the function, but for allow_in_spec,
    /// we have to create one from the 'returns' clause)
    new_func: Option<vir::ast::FunctionStub>,
}

fn handle_autospec<'tcx>(
    ctxt: &Context<'tcx>,
    span: Span,
    def_id: DefId,
    vattrs: &VerifierAttrs,
    functionx: &FunctionStubX,
) -> Result<Autospec, VirErr> {
    if let Some(method_name) = &vattrs.autospec {
        if vattrs.allow_in_spec {
            return err_span(
                span,
                format!("a function cannot be marked both 'when_used_as_spec' and 'allow_in_spec'"),
            );
        }
        let mut this_path = crate::rust_to_vir_base::def_id_to_vir_path_ignoring_diagnostic_rename(
            ctxt.tcx, def_id,
        );
        if matches!(&functionx.kind, FunctionKind::TraitMethodImpl { .. }) {
            // pop off impl&%n:: (we want method_name, not Self::method_name)
            this_path = this_path.pop_segment();
        }
        let path = autospec_fun(&this_path, method_name.clone());
        Ok(Autospec { redirect_to: Some(Arc::new(FunX { path })), new_func: None })
    } else if vattrs.allow_in_spec {
        let mut this_path = crate::rust_to_vir_base::def_id_to_vir_path_ignoring_diagnostic_rename(
            ctxt.tcx, def_id,
        );
        if functionx.mode != Mode::Exec {
            return err_span(span, format!("allow_in_spec can only be used on an exec function"));
        }
        if !matches!(&functionx.kind, FunctionKind::Static) {
            return err_span(span, format!("allow_in_spec not supported for trait functions"));
        }

        let mut spec_params = vec![];
        for p in functionx.params.iter() {
            if p.x.unwrapped_info.is_some() {
                return err_span(
                    span,
                    format!(
                        "allow_in_spec not supported for function with wrapped Tracked/Ghost params"
                    ),
                );
            }
            spec_params.push(vir::def::Spanned::new(
                p.span.clone(),
                ParamX {
                    name: p.x.name.clone(),
                    typ: p.x.typ.clone(),
                    mode: Mode::Spec,
                    unwrapped_info: None,
                    user_mut: false,
                },
            ));
        }
        let ret_param = &functionx.outer_ret;
        let spec_ret_param = vir::def::Spanned::new(
            ret_param.span.clone(),
            ParamX {
                name: air_unique_var(RETURN_VALUE),
                typ: ret_param.x.typ.clone(),
                mode: Mode::Spec,
                unwrapped_info: None,
                user_mut: false,
            },
        );

        if functionx.proxy.is_some() {
            // Naively, this_path may contain a mangled _verus_external_fn_specification_ name.
            // Clean this up before sending it to autospec_return_clause_spec_fn_name:
            this_path = this_path.pop_segment().push_segment(functionx.name.path.last_segment());
        }
        let new_func = ctxt.spanned_new(
            span,
            FunctionStubX {
                name: vir::def::autospec_return_clause_spec_fn_name(&this_path),
                proxy: None,
                kind: FunctionKind::Static,
                visibility: functionx.visibility.clone(),
                body_visibility: BodyVisibility::Visibility(functionx.visibility.clone()),
                opaqueness: Opaqueness::Revealed { visibility: functionx.visibility.clone() },
                owning_module: functionx.owning_module.clone(),
                mode: Mode::Spec,
                typ_params: functionx.typ_params.clone(),
                typ_bounds: functionx.typ_bounds.clone(),
                params: Arc::new(spec_params),
                outer_ret: spec_ret_param,
                item_kind: ItemKind::Function,
                attrs: Arc::new(FunctionAttrsX {
                    infer: false,
                    infer_allow_approx: false,
                    infer_precision_rlimit: None,
                    infer_candidate_id: None,
                    infer_sequence_view: false,
                    infer_trait_getter: false,
                    infer_owned: false,
                    infer_clone_contract: false,
                    infer_mutable_selector: false,
                    infer_trait_observation: false,
                    infer_iterator_factory: false,
                    infer_iterator_observation: false,
                    uses_ghost_blocks: vattrs.verus_macro,
                    inline: false,
                    broadcast_forall: false,
                    broadcast_forall_only: false,
                    no_auto_trigger: false,
                    auto_ext_equal: functionx.attrs.auto_ext_equal.clone(),
                    autospec: None,
                    bit_vector: false,
                    atomic: false,
                    integer_ring: false,
                    is_decrease_by: false,
                    check_recommends: false,
                    nonlinear: false,
                    spinoff_prover: false,
                    memoize: false,
                    rlimit: None,
                    print_zero_args: functionx.attrs.print_zero_args,
                    print_as_method: functionx.attrs.print_as_method,
                    prophecy_dependent: false,
                    size_of_broadcast_proof: false,
                    is_type_invariant_fn: false,
                    is_external_body: false,
                    is_unsafe: false,
                    impls_cannot_extend_spec: false,
                    exec_assume_termination: false,
                    exec_allows_no_decreases_clause: false,
                    tracked_swap: false,
                    tracked_take_option: false,
                    is_async: false,
                    is_drop: false,
                }),
                decreases_len: 0,
                returns: false,
            },
        );

        Ok(Autospec { redirect_to: Some(new_func.x.name.clone()), new_func: Some(new_func) })
    } else {
        Ok(Autospec { redirect_to: None, new_func: None })
    }
}

fn finish_autospec<'tcx>(
    span: Span,
    function_main: &vir::ast::Function,
    function_autospec: &vir::ast::FunctionStub,
) -> Result<vir::ast::Function, VirErr> {
    let Some(ret_clause) = &function_main.x.returns else {
        return err_span(
            span,
            format!("allow_in_spec can only be used on a function with a returns clause"),
        );
    };
    let vir::ast::FunctionStubX {
        name,
        proxy,
        kind,
        visibility,
        body_visibility,
        opaqueness,
        owning_module,
        mode,
        typ_params,
        typ_bounds,
        params,
        outer_ret,
        item_kind,
        attrs,
        returns: _,
        decreases_len: _,
    } = function_autospec.x.clone();
    let function_autospec_x = FunctionX {
        name,
        proxy,
        kind,
        visibility,
        body_visibility,
        opaqueness,
        owning_module,
        mode,
        typ_params,
        typ_bounds,
        params,
        outer_ret: outer_ret.clone(),
        inner_ret: outer_ret,
        decrease_by: None,
        item_kind,
        attrs,
        extra_dependencies: vec![],

        body: Some(ret_clause.clone()),
        return_opaque_type_eqs: Arc::new(vec![]),
        require: function_main.x.require.clone(), // requires becomes recommends
        ensure: (Arc::new(vec![]), Arc::new(vec![])),
        returns: None,
        decrease: Arc::new(vec![]),
        decrease_when: None,
        fndef_axioms: None,
        mask_spec: None,
        atomic_update: None,
        unwind_spec: None,
        hidden: Arc::new(vec![]),
    };
    Ok(Spanned::new(function_autospec.span.clone(), function_autospec_x))
}

pub(crate) fn body_id_to_types<'tcx>(
    tcx: TyCtxt<'tcx>,
    id: &BodyId,
) -> &'tcx rustc_middle::ty::TypeckResults<'tcx> {
    tcx.typeck(tcx.hir_body_owner_def_id(*id))
}

fn mk_bctx<'tcx>(
    ctxt: &Context<'tcx>,
    fun_id: DefId,
    body_id: &BodyId,
    mode: Mode,
    external_body: bool,
    external_trait_from_to: &Option<(vir::ast::Path, vir::ast::Path, Option<vir::ast::Path>)>,
    migrate_postcondition_vars: Option<HashSet<VarIdent>>,
    param_names: Vec<VarIdent>,
    external_opaque_type_map: Option<HashMap<Path, Path>>,
) -> BodyCtxt<'tcx> {
    BodyCtxt {
        ctxt: ctxt.clone(),
        types: body_id_to_types(ctxt.tcx, body_id),
        fun_id,
        external_trait_from_to: external_trait_from_to.as_ref().map(|e| Arc::new(e.clone())),
        mode,
        external_body,
        in_ghost: mode != Mode::Exec,
        atomically: None,
        migrate_postcondition_vars,
        in_fn_sig: false,
        in_postcondition: false,
        in_old: false,
        in_explicit_prophecy_node: false,
        params: std::rc::Rc::new(vec![param_names]),
        header_setting: HeaderSetting::Fn,
        external_opaque_type_map,
        label_map: std::rc::Rc::new(std::cell::RefCell::new((HashMap::new(), 0))),
    }
}

#[cfg(feature = "native-resource-adapter164")]
pub fn native_body_to_vir164<'tcx>(
    tcx: rustc_middle::ty::TyCtxt<'tcx>,
    owner: rustc_middle::ty::Instance<'tcx>,
) -> Result<crate::native_adapter164::Lowered164, String> {
    crate::native_adapter164::lower_native_instance(tcx, owner)
}

pub(crate) fn body_to_vir<'tcx>(
    ctxt: &Context<'tcx>,
    fun_id: DefId,
    id: &BodyId,
    body: &Body<'tcx>,
    mode: Mode,
    external_body: bool,
    external_trait_from_to: &Option<(vir::ast::Path, vir::ast::Path, Option<vir::ast::Path>)>,
    migrate_postcondition_vars: Option<HashSet<VarIdent>>,
    params: &[vir::ast::Param],
    external_opaque_type_map: Option<HashMap<Path, Path>>,
    is_async: bool,
) -> Result<(vir::ast::Expr, Vec<(vir::ast::Stmt, vir::ast::Stmt)>), VirErr> {
    let param_names = params.iter().map(|p| p.x.name.clone()).collect();
    let bctx = mk_bctx(
        ctxt,
        fun_id,
        id,
        mode,
        external_body,
        external_trait_from_to,
        migrate_postcondition_vars,
        param_names,
        external_opaque_type_map,
    );
    let body_expr =
        if is_async { extract_desugared_async_body(&bctx.ctxt, body)? } else { &body.value };
    let e = expr_to_vir_consume(&bctx, body_expr)?;

    // Declarations for the bindings of parameter patterns
    let mut param_decls = Vec::new();
    for (param, vir_param) in body.params.iter().zip(params) {
        let ParamX { name, typ, mode: param_mode, .. } = &vir_param.x;
        let pat = peel_verus_param(param.pat);
        let decl = param_pat_to_decl(&bctx, pat, name, typ, *param_mode)?;
        // exec code can only initialize ghost and tracked variables in proof blocks
        if decl.is_some() && mode == Mode::Exec && *param_mode != Mode::Exec {
            return err_span(
                param.pat.span,
                "patterns in ghost or tracked parameters of exec functions are not supported",
            );
        }
        param_decls.extend(decl);
    }

    if external_body {
        match &e.x {
            vir::ast::ExprX::NeverToAny(e) => Ok((e.clone(), param_decls)),
            _ => Ok((e, param_decls)),
        }
    } else {
        Ok((e, param_decls))
    }
}

pub(crate) fn extract_desugared_async_body<'tcx>(
    ctxt: &Context<'tcx>,
    body: &Body<'tcx>,
) -> Result<&'tcx rustc_hir::Expr<'tcx>, VirErr> {
    let async_body_expr = match body.value.kind {
        rustc_hir::ExprKind::Closure(cls)
            if cls.kind
                == rustc_hir::ClosureKind::Coroutine(rustc_hir::CoroutineKind::Desugared(
                    rustc_hir::CoroutineDesugaring::Async,
                    rustc_hir::CoroutineSource::Fn,
                )) =>
        {
            let closure_body = crate::rust_to_vir_func::find_body(ctxt, &cls.body);
            match closure_body.value.kind {
                rustc_hir::ExprKind::Block(block, ..) => {
                    let expr = block.expr.expect("async function block has no expression");
                    match expr.kind {
                        rustc_hir::ExprKind::DropTemps(expr) => expr,
                        _ => {
                            return err_span(
                                body.value.span,
                                format!(
                                    "internal error: async function desugared closure expression is not `DropTemps`"
                                ),
                            );
                        }
                    }
                }
                _ => {
                    return err_span(
                        body.value.span,
                        format!(
                            "internal error: async function desugared closure doesn't have a block"
                        ),
                    );
                }
            }
        }
        _ => {
            return err_span(
                body.value.span,
                format!("internal error: async function desugared body is not a closure"),
            );
        }
    };

    Ok(async_body_expr)
}

fn check_fn_decl<'tcx>(
    span: Span,
    ctxt: &Context<'tcx>,
    id: DefId,
    decl: &'tcx FnDecl<'tcx>,
    attrs: &[Attribute],
    mode: Mode,
    output_ty: rustc_middle::ty::Ty<'tcx>,
    assume_specification_opaque_type_map: Option<&HashMap<Path, Path>>,
) -> Result<Option<(Typ, Mode)>, VirErr> {
    let FnDecl { inputs: _, output, fn_decl_kind } = decl;
    unsupported_err_unless!(!fn_decl_kind.c_variadic(), span, "c_variadic functions");
    match fn_decl_kind.implicit_self() {
        rustc_hir::ImplicitSelfKind::None => {}
        rustc_hir::ImplicitSelfKind::Imm => {}
        rustc_hir::ImplicitSelfKind::RefImm => {}
        rustc_hir::ImplicitSelfKind::RefMut => {}
        rustc_hir::ImplicitSelfKind::Mut => {}
    }
    match output {
        rustc_hir::FnRetTy::DefaultReturn(_) => Ok(None),
        // REVIEW: there's no attribute syntax on return types,
        // so we always return the default mode.
        // The current workaround is to return a struct if the default doesn't work.
        rustc_hir::FnRetTy::Return(_ty) => {
            let typ =
                ctxt.mid_ty_to_vir(id, span, &output_ty, assume_specification_opaque_type_map)?;
            Ok(Some((typ, get_ret_mode(mode, attrs))))
        }
    }
}

pub(crate) fn find_body_krate<'tcx>(tcx: TyCtxt<'tcx>, body_id: &BodyId) -> &'tcx Body<'tcx> {
    tcx.hir_body(*body_id)
}

pub(crate) fn find_body<'tcx>(ctxt: &ContextX<'tcx>, body_id: &BodyId) -> &'tcx Body<'tcx> {
    find_body_krate(ctxt.tcx, body_id)
}

// Check for any obvious type mismatches
fn compare_external_ty_or_true<'tcx>(
    tcx: TyCtxt<'tcx>,
    verus_items: &crate::verus_items::VerusItems,
    from_path: &vir::ast::Path,
    to_path: &vir::ast::Path,
    ty1: &rustc_middle::ty::Ty<'tcx>,
    ty2: &rustc_middle::ty::Ty<'tcx>,
) -> bool {
    use rustc_middle::ty::{GenericArg, GenericArgKind, Ty};
    // TODO, but low priority, since this is just a check for trusted declarations:
    // finish more cases so as to be more precise and report more mismatches.
    // (Note: we used to try to convert to VIR types and compare,
    // but this led to rustc internal errors, since we didn't have the write param_env_src for ty2)
    let check_t = |t1: &Ty<'tcx>, t2: &Ty<'tcx>| -> bool {
        compare_external_ty_or_true(tcx, verus_items, from_path, to_path, t1, t2)
    };
    let check_ts = |ts1: &[Ty<'tcx>], ts2: &[Ty<'tcx>]| -> bool {
        ts1.len() == ts2.len() && ts1.iter().zip(ts2.iter()).all(|(t1, t2)| check_t(t1, t2))
    };
    let check_args = |args1: &[GenericArg<'tcx>], args2: &[GenericArg<'tcx>]| -> bool {
        if args1.len() != args2.len() {
            return false;
        }
        for (arg1, arg2) in args1.iter().zip(args2.iter()) {
            let ok = match (&arg1.kind(), &arg2.kind()) {
                (GenericArgKind::Type(t1), GenericArgKind::Type(t2)) => check_t(t1, t2),
                _ => arg1 == arg2,
            };
            if !ok {
                return false;
            }
        }
        true
    };
    match (ty1.kind(), ty2.kind()) {
        // These cases are complete:
        (TyKind::Bool, _) => ty1 == ty2,
        (TyKind::Uint(_), _) => ty1 == ty2,
        (TyKind::Int(_), _) => ty1 == ty2,
        (TyKind::Char, _) => ty1 == ty2,
        (TyKind::Float(_), _) => ty1 == ty2,
        (TyKind::Closure(..), _) => ty1 == ty2,
        (TyKind::Str, _) => ty1 == ty2,
        (TyKind::Never, _) => ty1 == ty2,
        (TyKind::Param(_), _) => ty1 == ty2,
        (TyKind::Ref(_, t1, m1), TyKind::Ref(_, t2, m2)) => m1 == m2 && check_t(t1, t2),
        (TyKind::Tuple(_), TyKind::Tuple(_)) => check_ts(ty1.tuple_fields(), ty2.tuple_fields()),
        (TyKind::Slice(t1), TyKind::Slice(t2)) => check_t(t1, t2),
        (TyKind::RawPtr(t1, m1), TyKind::RawPtr(t2, m2)) => m1 == m2 && check_t(t1, t2),
        (TyKind::Array(t1, len1), TyKind::Array(t2, len2)) => len1 == len2 && check_t(t1, t2),
        (TyKind::Adt(a1, args1), TyKind::Adt(a2, args2)) => a1 == a2 && check_args(args1, args2),
        (TyKind::Alias(rigid1, t1), TyKind::Alias(rigid2, t2)) => {
            let k1 = t1.kind;
            let k2 = t2.kind;
            if rigid1 != rigid2 {
                return false;
            }
            let (def_id1, def_id2) = match (k1, k2) {
                (
                    AliasTyKind::Projection { def_id: def_id1 },
                    AliasTyKind::Projection { def_id: def_id2 },
                )
                | (
                    AliasTyKind::Inherent { def_id: def_id1 },
                    AliasTyKind::Inherent { def_id: def_id2 },
                )
                | (
                    AliasTyKind::Opaque { def_id: def_id1 },
                    AliasTyKind::Opaque { def_id: def_id2 },
                )
                | (AliasTyKind::Free { def_id: def_id1 }, AliasTyKind::Free { def_id: def_id2 }) => {
                    (def_id1, def_id2)
                }
                (AliasTyKind::Projection { .. }, _)
                | (AliasTyKind::Inherent { .. }, _)
                | (AliasTyKind::Opaque { .. }, _)
                | (AliasTyKind::Free { .. }, _) => return false,
            };
            if tcx.associated_item(def_id1).name() != tcx.associated_item(def_id2).name() {
                return false;
            }
            if !check_args(&t1.args, &t2.args) {
                return false;
            }
            let trait_def1 = tcx.generics_of(def_id1).parent;
            let trait_def2 = tcx.generics_of(def_id2).parent;
            match (trait_def1, trait_def2) {
                (None, None) => true,
                (Some(trait_def1), Some(trait_def2)) => {
                    let mut trait_path1 = def_id_to_vir_path(
                        tcx,
                        verus_items,
                        trait_def1,
                        None::<&mut HashMap<_, _>>,
                    );
                    let trait_path2 = def_id_to_vir_path(
                        tcx,
                        verus_items,
                        trait_def2,
                        None::<&mut HashMap<_, _>>,
                    );
                    if trait_path1 == *from_path {
                        trait_path1 = to_path.clone();
                    }
                    trait_path1 == trait_path2
                }
                _ => false,
            }
        }

        // These cases are incomplete and always return true:
        (TyKind::FnDef(..), _) => true,
        (TyKind::Coroutine(..), _) => true,
        (TyKind::CoroutineWitness(..), _) => true,
        (TyKind::Bound(..), _) => true,
        (TyKind::Placeholder(..), _) => true,
        (TyKind::Infer(..), _) => true,
        (TyKind::Error(..), _) => true,
        (TyKind::CoroutineClosure(..), _) => true,
        (TyKind::Pat(..), _) => true,
        (TyKind::Foreign(..), _) => true,
        (TyKind::FnPtr(..), _) => true,
        (TyKind::Dynamic(..), _) => true,

        _ => false,
    }
}
fn compare_clause_kind<'tcx>(
    tcx: TyCtxt<'tcx>,
    verus_items: &crate::verus_items::VerusItems,
    ck1: &rustc_middle::ty::ClauseKind<'tcx>,
    ck2: &rustc_middle::ty::ClauseKind<'tcx>,
    external_trait_from_to: &Option<(vir::ast::Path, vir::ast::Path, Option<vir::ast::Path>)>,
) -> bool {
    match (ck1, ck2) {
        (
            rustc_middle::ty::ClauseKind::Trait(pred1),
            rustc_middle::ty::ClauseKind::Trait(pred2),
        ) => pred1.trait_ref.def_id == pred2.trait_ref.def_id && pred1.polarity == pred2.polarity,
        (
            rustc_middle::ty::ClauseKind::Projection(pred1),
            rustc_middle::ty::ClauseKind::Projection(pred2),
        ) => {
            let projection_term_eq = pred1.projection_term.expect_projection_def_id()
                == pred2.projection_term.expect_projection_def_id();
            let term_eq =
                if let (rustc_middle::ty::TermKind::Ty(ty1), rustc_middle::ty::TermKind::Ty(ty2)) =
                    (pred1.term.kind(), pred2.term.kind())
                {
                    compare_external_ty(tcx, verus_items, &ty1, &ty2, external_trait_from_to)
                } else {
                    pred1.term == pred2.term
                };
            projection_term_eq && term_eq
        }
        (
            rustc_middle::ty::ClauseKind::RegionOutlives(..),
            rustc_middle::ty::ClauseKind::RegionOutlives(..),
        ) => true,
        (
            rustc_middle::ty::ClauseKind::TypeOutlives(..),
            rustc_middle::ty::ClauseKind::TypeOutlives(..),
        ) => true,
        (
            rustc_middle::ty::ClauseKind::ConstArgHasType(..),
            rustc_middle::ty::ClauseKind::ConstArgHasType(..),
        ) => true,
        (
            rustc_middle::ty::ClauseKind::WellFormed(..),
            rustc_middle::ty::ClauseKind::WellFormed(..),
        ) => true,
        (
            rustc_middle::ty::ClauseKind::ConstEvaluatable(..),
            rustc_middle::ty::ClauseKind::ConstEvaluatable(..),
        ) => true,
        (
            rustc_middle::ty::ClauseKind::HostEffect(..),
            rustc_middle::ty::ClauseKind::HostEffect(..),
        ) => true,
        // Uncomment the following line when upgrading to Rust 1.90.
        // (rustc_middle::ty::ClauseKind::UnstableFeature(..), rustc_middle::ty::ClauseKind::UnstableFeature(..)) => true,
        _ => false,
    }
}
fn compare_external_ty<'tcx>(
    tcx: TyCtxt<'tcx>,
    verus_items: &crate::verus_items::VerusItems,
    ty1: &rustc_middle::ty::Ty<'tcx>,
    ty2: &rustc_middle::ty::Ty<'tcx>,
    external_trait_from_to: &Option<(vir::ast::Path, vir::ast::Path, Option<vir::ast::Path>)>,
) -> bool {
    let compare_generic_args = |generic_args1: &[GenericArg<'tcx>],
                                generic_args2: &[GenericArg<'tcx>]| {
        if generic_args1.len() != generic_args2.len() {
            return false;
        } else {
            for (generic_arg1, generic_arg2) in generic_args1.iter().zip(generic_args2.iter()) {
                match (generic_arg1.as_type(), generic_arg2.as_type()) {
                    (Some(ty1), Some(ty2)) => {
                        if compare_external_ty(tcx, verus_items, &ty1, &ty2, external_trait_from_to)
                        {
                            continue;
                        } else {
                            return false;
                        }
                    }
                    (None, None) => {
                        if generic_arg1 == generic_arg2 {
                            continue;
                        } else {
                            return false;
                        }
                    }
                    _ => {
                        return false;
                    }
                }
            }
            return true;
        }
    };

    if let Some((from_path, to_path, _)) = external_trait_from_to {
        compare_external_ty_or_true(tcx, verus_items, from_path, to_path, ty1, ty2)
    }
    // we recursively reach all the nested opaque types.
    else {
        match (ty1.kind(), ty2.kind()) {
            (
                rustc_middle::ty::TyKind::Alias(is_rigid1, al_ty1),
                rustc_middle::ty::TyKind::Alias(is_rigid2, al_ty2),
            ) if matches!(al_ty1.kind, rustc_middle::ty::AliasTyKind::Opaque { .. })
                && matches!(al_ty2.kind, rustc_middle::ty::AliasTyKind::Opaque { .. }) =>
            {
                assert!(
                    matches!(is_rigid1, IsRigid::No) && matches!(is_rigid2, IsRigid::No),
                    "IsRigid should always be `No` with old trait solver"
                );
                // two opaque types. We compare their trait bounds
                let def_id1 =
                    al_ty1.kind.try_to_opaque().expect("alias kind was checked to be opaque");
                let def_id2 =
                    al_ty2.kind.try_to_opaque().expect("alias kind was checked to be opaque");
                let ty1_bounds = tcx.normalize_erasing_regions(
                    TypingEnv::non_body_analysis(tcx, def_id1),
                    tcx.item_bounds(def_id1).instantiate(tcx, al_ty1.args),
                );
                let ty2_bounds = tcx.normalize_erasing_regions(
                    TypingEnv::non_body_analysis(tcx, def_id2),
                    tcx.item_bounds(def_id2).instantiate(tcx, al_ty2.args),
                );
                if ty1_bounds.len() != ty2_bounds.len() {
                    return false;
                }
                for (bound1, bound2) in ty1_bounds.iter().zip(ty2_bounds.iter()) {
                    if !compare_clause_kind(
                        tcx,
                        verus_items,
                        &bound1.kind().skip_binder(),
                        &bound2.kind().skip_binder(),
                        external_trait_from_to,
                    ) {
                        return false;
                    }
                }
                return true;
            }
            (rustc_middle::ty::TyKind::Tuple(tys1), rustc_middle::ty::TyKind::Tuple(tys2)) => {
                if tys1.len() != tys2.len() {
                    false
                } else {
                    for (ty1, ty2) in tys1.iter().zip(tys2.iter()) {
                        if !compare_external_ty(
                            tcx,
                            verus_items,
                            &ty1,
                            &ty2,
                            external_trait_from_to,
                        ) {
                            return false;
                        }
                    }
                    true
                }
            }
            (
                rustc_middle::ty::TyKind::Array(ty1, const1),
                rustc_middle::ty::TyKind::Array(ty2, const2),
            ) => {
                (const1 == const2 || {
                    // Closed array lengths in standard-library signatures can
                    // retain anonymous const identities (e.g. u64::to_ne_bytes).
                    // Accept only equality proved by Rust's const evaluator.
                    let evaluate = |c: &rustc_middle::ty::Const<'tcx>| {
                        if c.has_non_region_param() || c.has_bound_vars() {
                            return None;
                        }
                        tcx.try_normalize_erasing_regions(
                            TypingEnv::fully_monomorphized(),
                            rustc_middle::ty::Unnormalized::new_wip(*c),
                        )
                        .ok()?
                        .try_to_target_usize(tcx)
                    };
                    matches!((evaluate(const1), evaluate(const2)), (Some(a), Some(b)) if a == b)
                }) && compare_external_ty(tcx, verus_items, &ty1, &ty2, external_trait_from_to)
            }
            (
                rustc_middle::ty::TyKind::Pat(ty1, pat1),
                rustc_middle::ty::TyKind::Pat(ty2, pat2),
            ) => {
                pat1 == pat2
                    && compare_external_ty(tcx, verus_items, &ty1, &ty2, external_trait_from_to)
            }
            (rustc_middle::ty::TyKind::Slice(ty1), rustc_middle::ty::TyKind::Slice(ty2)) => {
                compare_external_ty(tcx, verus_items, &ty1, &ty2, external_trait_from_to)
            }
            (
                rustc_middle::ty::TyKind::RawPtr(ty1, mut1),
                rustc_middle::ty::TyKind::RawPtr(ty2, mut2),
            ) => {
                mut1 == mut2
                    && compare_external_ty(tcx, verus_items, &ty1, &ty2, external_trait_from_to)
            }
            (
                rustc_middle::ty::TyKind::Ref(reg1, ty1, mut1),
                rustc_middle::ty::TyKind::Ref(reg2, ty2, mut2),
            ) => {
                reg1 == reg2
                    && mut1 == mut2
                    && compare_external_ty(tcx, verus_items, &ty1, &ty2, external_trait_from_to)
            }
            (
                rustc_middle::ty::TyKind::Adt(adt_def1, generic_args1),
                rustc_middle::ty::TyKind::Adt(adt_def2, generic_args2),
            ) => (*adt_def1 == *adt_def2) && compare_generic_args(generic_args1, generic_args2),
            (
                rustc_middle::ty::TyKind::FnDef(def_id1, generic_args1),
                rustc_middle::ty::TyKind::FnDef(def_id2, generic_args2),
            ) => match (generic_args1.no_bound_vars(), generic_args2.no_bound_vars()) {
                (Some(generic_args1), Some(generic_args2)) => {
                    (*def_id1 == *def_id2) && compare_generic_args(generic_args1, generic_args2)
                }
                // see fn_def_args
                _ => false,
            },
            (
                rustc_middle::ty::TyKind::Closure(def_id1, generic_args1),
                rustc_middle::ty::TyKind::Closure(def_id2, generic_args2),
            )
            | (
                rustc_middle::ty::TyKind::CoroutineClosure(def_id1, generic_args1),
                rustc_middle::ty::TyKind::CoroutineClosure(def_id2, generic_args2),
            )
            | (
                rustc_middle::ty::TyKind::Coroutine(def_id1, generic_args1),
                rustc_middle::ty::TyKind::Coroutine(def_id2, generic_args2),
            )
            | (
                rustc_middle::ty::TyKind::CoroutineWitness(def_id1, generic_args1),
                rustc_middle::ty::TyKind::CoroutineWitness(def_id2, generic_args2),
            ) => (*def_id1 == *def_id2) && compare_generic_args(generic_args1, generic_args2),
            (
                rustc_middle::ty::TyKind::FnPtr(fn_tys1, fn_header1),
                rustc_middle::ty::TyKind::FnPtr(fn_tys2, fn_header2),
            ) => {
                let input_tys1 = fn_tys1.skip_binder().inputs();
                let input_tys2 = fn_tys2.skip_binder().inputs();

                if input_tys1.len() != input_tys2.len() {
                    return false;
                } else {
                    for (input_ty1, input_ty2) in input_tys1.iter().zip(input_tys2.iter()) {
                        if !compare_external_ty(
                            tcx,
                            verus_items,
                            &input_ty1,
                            &input_ty2,
                            external_trait_from_to,
                        ) {
                            return false;
                        } else {
                            continue;
                        }
                    }
                };
                if !compare_external_ty(
                    tcx,
                    verus_items,
                    &fn_tys1.skip_binder().output(),
                    &fn_tys2.skip_binder().output(),
                    external_trait_from_to,
                ) {
                    return false;
                }
                fn_header1 == fn_header2
            }
            // other cases will not contain nested opaque types.
            _ => ty1 == ty2,
        }
    }
}

fn compare_external_sig<'tcx>(
    tcx: TyCtxt<'tcx>,
    verus_items: &crate::verus_items::VerusItems,
    sig1: &rustc_middle::ty::FnSig<'tcx>,
    sig2: &rustc_middle::ty::FnSig<'tcx>,
    external_trait_from_to: &Option<(vir::ast::Path, vir::ast::Path, Option<vir::ast::Path>)>,
) -> Result<bool, VirErr> {
    use rustc_middle::ty::FnSig;
    // Ignore abi and safety for the sake of comparison
    // Useful for rust-intrinsics
    let FnSig { inputs_and_output: io1, fn_sig_kind: fn_sig_kind1 } = sig1;
    let FnSig { inputs_and_output: io2, fn_sig_kind: fn_sig_kind2 } = sig2;
    let c1 = fn_sig_kind1.c_variadic();
    let c2 = fn_sig_kind2.c_variadic();
    if io1.len() != io2.len() {
        return Ok(false);
    }
    for (ty1, ty2) in io1.iter().zip(io2.iter()) {
        if !compare_external_ty(tcx, verus_items, &ty1, &ty2, external_trait_from_to) {
            return Ok(false);
        }
    }

    Ok(c1 == c2)
}

fn handle_external_fn<'tcx>(
    ctxt: &Context<'tcx>,
    state: &mut State,
    id: DefId,
    kind: FunctionKind,
    visibility: vir::ast::Visibility,
    sig: &FnOrConstSig<'tcx>,
    // (impl generics, impl def_id)
    self_generics: Option<(&'tcx Generics, DefId)>,
    body_id: &CheckItemFnEither<&BodyId, &[Ident]>,
    mode: Mode,
    vattrs: &VerifierAttrs,
    external_trait_from_to: &Option<(vir::ast::Path, vir::ast::Path, Option<vir::ast::Path>)>,
    external_fn_specification_via_external_trait: Option<DefId>,
    // This function is the proxy, and we need to look up the actual path.
) -> Result<
    (vir::ast::Path, vir::ast::Visibility, FunctionKind, bool, Safety, bool, DefId, bool),
    VirErr,
> {
    let is_builtin_external = matches!(
        external_fn_specification_via_external_trait
            .and_then(|d| ctxt.verus_items.id_to_name.get(&d)),
        Some(VerusItem::External(_))
    );
    if mode != Mode::Exec && !is_builtin_external {
        return err_span(
            sig.span,
            format!("an `assume_specification` declaration cannot be marked `{mode:}`"),
        );
    }

    if vattrs.external_body {
        return err_span(
            sig.span,
            format!("an `assume_specification` declaration cannot be marked `external_body`"),
        );
    }

    if self_generics.is_some() && external_fn_specification_via_external_trait.is_none() {
        return err_span(sig.span, "`assume_specification` declaration not supported here");
    }

    let (external_id, kind, is_const) =
        if let Some(external_id) = external_fn_specification_via_external_trait {
            (external_id, kind, false)
        } else {
            let body_id = match body_id {
                CheckItemFnEither::BodyId(body_id) => body_id,
                _ => {
                    return err_span(
                        sig.span,
                        "assume_specification not supported for trait functions",
                    );
                }
            };
            let body = find_body(ctxt, body_id);
            get_external_def_id(ctxt, id, body_id, body, sig)?
        };

    let external_path = ctxt.def_id_to_vir_path(external_id);
    let external_item_visibility = mk_visibility(ctxt, external_id);

    match &external_path.krate {
        CrateId::Id(name, _)
            if name.to_string().as_str() == "verus_builtin"
                && &*external_path.last_segment() != "clone"
                && !is_builtin_external =>
        {
            return err_span(
                sig.span,
                "cannot apply `assume_specification` to Verus verus_builtin functions",
            );
        }
        _ => {}
    }

    let is_async = sig.asyncness().is_async();

    // The comparison is a little tricky because we could have a situation like this:
    //
    // ctxt.tcx.type_of(id) = EarlyBinder {
    //   value: for<'a, 'b> fn(&'a &'b T) -> &'b T {std_specs::clone::ex_ref_clone::<T>},
    // }
    // substs1 = [
    //   T,
    // ]
    //
    // ctxt.tcx.type_of(external_id) = EarlyBinder {
    //   value: for<'a> fn(&'a &T) -> &T {std::clone::impls::<impl std::clone::Clone for &T>::clone},
    // }
    // substs2 = [
    //   ReEarlyBound(DefId(2:54293 ~ core[739c]::clone::impls::{impl#3}::'_), 0, '_),
    //   T,
    // ]
    //
    // In this case, 'b is early-bound when looking at the external_id and late-bound when
    // looking at the proxy. In order to treat these as 'identical', we have to consider
    // the early-binder and the outermost late-binder together.

    let ty1 = ctxt.tcx.type_of(id).skip_binder();
    let ty2 = ctxt.tcx.type_of(external_id).skip_binder();

    if is_const {
        let substs1_early = get_substs_early(ty1, sig.span)?;
        let poly_sig1 = ctxt.tcx.fn_sig(id);
        let poly_sig1x = poly_sig1.instantiate(ctxt.tcx, substs1_early);
        if substs1_early.len() + poly_sig1.skip_binder().bound_vars().len() != 0 {
            return err_span(
                sig.span,
                "generics are not allowed in external specification for const",
            );
        }
        let sig1 = poly_sig1x.skip_binder();
        use rustc_middle::ty::FnSig;
        let FnSig { inputs_and_output: io1, fn_sig_kind: _ } = &sig1;
        if io1.len() != 1 {
            return err_span(sig.span, "external specification for const must have 0 parameters");
        }
        let ty1 = io1[0];
        if !compare_external_ty(ctxt.tcx, &ctxt.verus_items, &ty1, &ty2, external_trait_from_to) {
            return assume_specification_mismatch_type_error(
                ctxt,
                sig.span,
                external_id,
                ty1.to_string(),
                ty2.to_string(),
            );
        }

        return Ok((
            external_path,
            external_item_visibility,
            kind,
            false,
            Safety::Safe,
            true,
            external_id,
            is_async,
        ));
    }

    let substs1_early = get_substs_early(ty1, sig.span)?;
    let substs2_early = get_substs_early(ty2, sig.span)?;

    let poly_sig1 = ctxt.tcx.fn_sig(id);
    let poly_sig2 = ctxt.tcx.fn_sig(external_id);

    let Some((substs1_early, substs2_early, substs1_late, substs2_late)) = equalize_substs(
        ctxt.tcx,
        substs1_early,
        substs2_early,
        poly_sig1.skip_binder().bound_vars().len(),
        poly_sig2.skip_binder().bound_vars().len(),
    ) else {
        return assume_specification_mismatch_type_error(
            ctxt,
            sig.span,
            external_id,
            mismatch_type_error_user_str_early(ctxt, substs1_early, poly_sig1),
            mismatch_type_error_user_str_early(ctxt, substs2_early, poly_sig2),
        );
    };
    let poly_sig1x = poly_sig1.instantiate(ctxt.tcx, substs1_early).skip_norm_wip();
    let poly_sig1x =
        ctxt.tcx.instantiate_bound_regions(poly_sig1x, |br| substs1_late[usize::from(br.var)]).0;

    let poly_sig2x = poly_sig2.instantiate(ctxt.tcx, substs2_early).skip_norm_wip();
    let poly_sig2x =
        ctxt.tcx.instantiate_bound_regions(poly_sig2x, |br| substs2_late[usize::from(br.var)]).0;

    let poly_sig_eq = compare_external_sig(
        ctxt.tcx,
        &ctxt.verus_items,
        &poly_sig1x,
        &poly_sig2x,
        &external_trait_from_to,
    )?;
    if !poly_sig_eq {
        return assume_specification_mismatch_type_error(
            ctxt,
            sig.span,
            external_id,
            mismatch_type_error_user_str_early(ctxt, substs1_early, poly_sig1),
            mismatch_type_error_user_str_early(ctxt, substs2_early, poly_sig2),
        );
    }

    // trait bounds aren't part of the type signature - we have to check those separately
    let mut proxy_preds = all_predicates(ctxt.tcx, id, substs1_early, false);
    let mut external_preds = all_predicates(ctxt.tcx, external_id, substs2_early, true);
    let in_trait = external_fn_specification_via_external_trait.is_some();
    remove_ignored_trait_bounds_from_predicates(
        ctxt,
        in_trait,
        None,
        &[ctxt.tcx.parent(external_id), ctxt.tcx.parent(id)],
        None,
        &mut proxy_preds,
    );
    remove_ignored_trait_bounds_from_predicates(
        ctxt,
        in_trait,
        None,
        &[ctxt.tcx.parent(external_id)],
        None,
        &mut external_preds,
    );
    // TODO, but low priority, since this is just a check for trusted declarations:
    // predicates_match for external_trait case (would need to rename from_path -> to_path)
    let preds_match = external_trait_from_to.is_some()
        || predicates_match(ctxt.tcx, &proxy_preds, &external_preds);
    if !preds_match {
        let err = err_span_bare(
            sig.span,
            "assume_specification trait bound mismatch")
            .help(format!("assume_specification requires function type signatures to match exactly, ignoring any Destruct trait bounds\n\
          but the proxy function's trait bounds are:\n{}\nthe external function's trait bounds are:\n{}",
          proxy_preds.iter().map(|x| format!("  - {x}")).collect::<Vec<_>>().join("\n"),
          external_preds.iter().map(|x| format!("  - {x}")).collect::<Vec<_>>().join("\n")));
        return Err(err);
    }

    if !vir::ast_util::is_visible_to_opt(&visibility, &external_item_visibility.restricted_to) {
        return err_span(
            sig.span,
            "an `assume_specification` declaration must be at least as visible as the function it provides a spec for (try writing `pub assume_specification ...`)",
        );
    }

    let has_self_parameter = has_self_parameter(ctxt, external_id);

    if matches!(kind, FunctionKind::ForeignTraitMethodImpl { .. }) {
        state
            .external_info
            .external_fn_specification_trait_method_impls
            .push((external_id, sig.span));
    }

    let safety = ctxt.tcx.fn_sig(external_id).skip_binder().safety();

    Ok((
        external_path,
        external_item_visibility,
        kind,
        has_self_parameter,
        safety,
        false,
        external_id,
        is_async,
    ))
}

pub(crate) fn get_substs_early<'tcx>(
    ty: rustc_middle::ty::Ty<'tcx>,
    span: Span,
) -> Result<GenericArgsRef<'tcx>, VirErr> {
    match ty.kind() {
        // The following TyKind Variants have a I::GenericArgs of early-bound generic arguments:
        // Adt, FnDef, Coroutine, Closure, CoroutineClosure, CoroutineWitness
        rustc_middle::ty::Adt(_, substs) => Ok(substs),
        rustc_middle::ty::FnDef(_, substs) => crate::rust_to_vir_base::fn_def_args(*substs, span),
        _ => {
            crate::internal_err!(span, "expected Adt or FnDef")
        }
    }
}

fn equalize_substs<'tcx>(
    tcx: TyCtxt<'tcx>,
    substs1_early: GenericArgsRef<'tcx>,
    substs2_early: GenericArgsRef<'tcx>,
    num_late1: usize,
    num_late2: usize,
) -> Option<(GenericArgsRef<'tcx>, GenericArgsRef<'tcx>, Vec<Region<'tcx>>, Vec<Region<'tcx>>)> {
    let mut s2 = vec![];
    let mut l1 = vec![];
    let mut l2 = vec![];

    if substs1_early.len() + num_late1 != substs2_early.len() + num_late2 {
        return None;
    }

    let mut reg = substs1_early.iter().filter(|g| matches!(g.kind(), GenericArgKind::Lifetime(_)));
    let mut other =
        substs1_early.iter().filter(|g| !matches!(g.kind(), GenericArgKind::Lifetime(_)));

    for i in 0..substs2_early.len() {
        match substs2_early[i].kind() {
            GenericArgKind::Type(_) => {
                let Some(arg) = other.next() else {
                    return None;
                };
                if !matches!(arg.kind(), GenericArgKind::Type(_)) {
                    return None;
                }
                s2.push(arg);
            }
            GenericArgKind::Const(_) => {
                let Some(arg) = other.next() else {
                    return None;
                };
                if !matches!(arg.kind(), GenericArgKind::Const(_)) {
                    return None;
                }
                s2.push(arg);
            }
            GenericArgKind::Lifetime(r) => match reg.next() {
                Some(arg) => {
                    s2.push(arg);
                }
                None => {
                    l1.push(r);
                    s2.push(substs2_early[i]);
                }
            },
        }
    }

    if other.next().is_some() {
        return None;
    }

    for arg in reg {
        let GenericArgKind::Lifetime(r) = arg.kind() else {
            unreachable!();
        };
        l2.push(r);
    }

    while l1.len() < num_late1 {
        let idx = l1.len();
        let region = Region::new_bound(
            tcx,
            rustc_middle::ty::INNERMOST,
            BoundRegion { var: BoundVar::from(idx), kind: BoundRegionKind::Anon },
        );
        l1.push(region);
        l2.push(region);
    }

    assert!(l1.len() == num_late1);
    assert!(l2.len() == num_late2);

    Some((substs1_early, tcx.mk_args(&s2), l1, l2))
}

fn assume_specification_mismatch_type_error<'tcx, A>(
    ctxt: &Context<'tcx>,
    span: Span,
    external_def_id: DefId,
    t1: String,
    t2: String,
) -> Result<A, VirErr> {
    let ex = crate::rust_to_vir_base::def_id_to_friendly(
        ctxt.tcx,
        Some(&ctxt.verus_items),
        external_def_id,
    );
    err_span(
        span,
        format!(
            "assume_specification requires function type signature to match `{:}` exactly \n      assume_specification provided: `{:}`\n      expected:                      `{:}`",
            ex, t1, t2
        ),
    )
}

fn mismatch_type_error_user_str_early<'tcx>(
    ctxt: &Context<'tcx>,
    substs: GenericArgsRef<'tcx>,
    poly_sig: rustc_middle::ty::EarlyBinder<'tcx, rustc_middle::ty::PolyFnSig<'tcx>>,
) -> String {
    let mut idx = 0;
    let substs = substs
        .iter()
        .map(|arg| match arg.kind() {
            GenericArgKind::Lifetime(region) => match region.kind() {
                RegionKind::ReEarlyParam(r) => {
                    if r.name.to_string() == "'_" {
                        let mut r = r;
                        r.name = rustc_span::Symbol::intern(&format!("'_{:}", idx));
                        idx += 1;
                        GenericArg::from(Region::new_from_kind(
                            ctxt.tcx,
                            RegionKind::ReEarlyParam(r),
                        ))
                    } else {
                        arg
                    }
                }
                _ => arg,
            },
            _ => arg,
        })
        .collect::<Vec<_>>();
    let substs = ctxt.tcx.mk_args(&substs);

    let early_binder_str = substs_to_string(&substs);

    let poly_sig = poly_sig.instantiate(ctxt.tcx, substs).skip_norm_wip();
    use rustc_middle::ty::FnSig;

    let binder_str = binders_to_string(ctxt.tcx, &poly_sig.bound_vars());

    let mut args: Vec<String> = vec![];
    let FnSig { inputs_and_output: io, fn_sig_kind: _ } = poly_sig.skip_binder();
    for t in io.iter() {
        args.push(format!("{:}", t));
    }

    format!(
        "{:}{:}({:}) -> {:}",
        early_binder_str,
        binder_str,
        args[0..args.len() - 1].join(", "),
        args[args.len() - 1],
    )
}

fn substs_to_string<'tcx>(substs: &GenericArgsRef<'tcx>) -> String {
    if substs.len() == 0 {
        return "".to_string();
    }

    let mut v = vec![];
    for arg in substs.iter() {
        let s = match &arg.kind() {
            GenericArgKind::Lifetime(region) => match region.kind() {
                RegionKind::ReEarlyParam(r) => r.name.to_string(),
                _ => format!("(Region {:?})", region),
            },
            GenericArgKind::Type(ty) => match ty.kind() {
                TyKind::Param(pty) => pty.name.to_string(),
                _ => format!("(Type {:?})", ty),
            },
            GenericArgKind::Const(c) => match c.kind() {
                ConstKind::Param(pc) => pc.name.to_string(),
                _ => format!("(Const {:?})", c),
            },
        };
        v.push(s);
    }
    format!("{:}{:}{:}", "for<", v.join(", "), "> ")
}

fn binders_to_string<'tcx>(
    tcx: TyCtxt<'tcx>,
    l: &rustc_middle::ty::List<rustc_middle::ty::BoundVariableKind>,
) -> String {
    use rustc_middle::ty::BoundTyKind;
    use rustc_middle::ty::BoundVariableKind;
    if l.len() == 0 {
        return "".to_string();
    }
    let mut v = vec![];
    for k in l.iter() {
        let sym;
        let s = match &k {
            BoundVariableKind::Ty(BoundTyKind::Anon) => "_",
            BoundVariableKind::Ty(BoundTyKind::Param(def_id)) => {
                sym = tcx.item_name(*def_id);
                sym.as_str()
            }
            BoundVariableKind::Region(BoundRegionKind::Anon | BoundRegionKind::ClosureEnv) => "'_",
            BoundVariableKind::Region(BoundRegionKind::Named(def_id)) => {
                sym = tcx.item_name(*def_id);
                sym.as_str()
            }
            BoundVariableKind::Region(BoundRegionKind::NamedForPrinting(sym)) => sym.as_str(),
            BoundVariableKind::Const => "CONST",
        };
        v.push(s.to_string());
    }
    format!("{:}{:}{:}", "for<", v.join(", "), "> ")
}

#[derive(Debug, Clone)]
pub enum CheckItemFnEither<A, B> {
    BodyId(A),
    ParamNames(B),
}

fn create_reveal_group<'tcx>(
    ctxt: &Context<'tcx>,
    reveal_groups: Option<&mut Vec<vir::ast::RevealGroup>>,
    name: &Fun,
    visibility: vir::ast::Visibility,
    module_path: &vir::ast::Path,
    vattrs: &VerifierAttrs,
    body: &vir::ast::Expr,
    span: Span,
) -> Result<(), VirErr> {
    if let vir::ast::ExprX::Block(stmts, None) = &body.x {
        let mut members: Vec<Fun> = Vec::new();
        for stmt in stmts.iter() {
            if let vir::ast::StmtX::Expr(expr) = &stmt.x {
                if let vir::ast::ExprX::Fuel(f, 1, _is_broadcast_use) = &expr.x {
                    members.push(f.clone());
                    continue;
                }
            }
            return err_span(span, "reveal_group must consist of reveal statements");
        }
        let broadcast_use_by_default_when_this_crate_is_imported =
            if vattrs.broadcast_use_by_default_when_this_crate_is_imported {
                Some(ctxt.crate_name.clone())
            } else {
                None
            };
        let groupx = vir::ast::RevealGroupX {
            name: name.clone(),
            visibility,
            owning_module: Some(module_path.clone()),
            broadcast_use_by_default_when_this_crate_is_imported,
            members: Arc::new(members),
        };
        if let Some(groups) = reveal_groups {
            groups.push(ctxt.spanned_new(span, groupx));
        } else {
            return err_span(span, "reveal_group not allowed here");
        }
        return Ok(());
    }
    err_span(span, "reveal_group must have block body")
}

fn make_attributes<'tcx>(
    ctxt: &Context<'tcx>,
    def_id: DefId,
    vattrs: &crate::attributes::VerifierAttrs,
    uses_ghost_blocks: bool,
    print_zero_args: bool,
    print_as_method: bool,
    safety: Safety,
    is_async: bool,
    span: Span,
    is_trait_decl_no_default: bool,
    is_drop: bool,
) -> Result<vir::ast::FunctionAttrs, VirErr> {
    if vattrs.nonlinear && vattrs.spinoff_prover {
        return err_span(
            span,
            "#[verifier::spinoff_prover] is implied for assert by nonlinear_arith",
        );
    }
    let fattrs = FunctionAttrsX {
        infer: vattrs.infer,
        infer_allow_approx: vattrs.infer_allow_approx,
        infer_precision_rlimit: vattrs.infer_precision_rlimit,
        infer_candidate_id: None,
        infer_sequence_view: false,
        infer_trait_getter: false,
        infer_owned: false,
        infer_clone_contract: false,
        infer_mutable_selector: false,
        infer_trait_observation: false,
        infer_iterator_factory: false,
        infer_iterator_observation: false,
        uses_ghost_blocks,
        inline: vattrs.inline,
        no_auto_trigger: vattrs.no_auto_trigger,
        broadcast_forall: vattrs.broadcast_forall,
        broadcast_forall_only: false,
        auto_ext_equal: crate::attributes::get_auto_ext_equal_walk_parents(ctxt.tcx, def_id),
        bit_vector: vattrs.bit_vector,
        autospec: None, // filled in later
        atomic: vattrs.atomic,
        integer_ring: vattrs.integer_ring,
        is_decrease_by: vattrs.decreases_by,
        check_recommends: vattrs.check_recommends,
        nonlinear: vattrs.nonlinear,
        spinoff_prover: vattrs.spinoff_prover,
        memoize: vattrs.memoize,
        rlimit: vattrs.rlimit,
        print_zero_args,
        print_as_method,
        prophecy_dependent: vattrs.prophecy_dependent,
        size_of_broadcast_proof: vattrs.size_of_broadcast_proof,
        is_type_invariant_fn: vattrs.type_invariant_fn,
        is_external_body: vattrs.external_body,
        is_unsafe: match safety {
            Safety::Safe => false,
            Safety::Unsafe => true,
        },
        impls_cannot_extend_spec: vattrs.impls_cannot_extend_spec,
        exec_assume_termination: vattrs.assume_termination,
        exec_allows_no_decreases_clause: if !is_trait_decl_no_default {
            crate::attributes::get_allow_exec_allows_no_decreases_clause_walk_parents(
                ctxt.tcx, def_id,
            )
        } else {
            vattrs.exec_allows_no_decreases_clause
        },
        tracked_swap: vattrs.tracked_swap,
        tracked_take_option: vattrs.tracked_take_option,
        is_async: is_async,
        is_drop: is_drop,
    };
    Ok(Arc::new(fattrs))
}

pub(crate) fn fixup_unerased_proxy_path(
    path: &vir::ast::Path,
    span: Span,
) -> Result<vir::ast::Path, VirErr> {
    let id = path.last_segment();
    let prefix = "VERUS_UNERASED_PROXY__";
    if id.starts_with(&prefix) {
        let p = path.pop_segment().push_segment(Arc::new(id[prefix.len()..].to_string()));
        Ok(p)
    } else {
        crate::internal_err!(span, "bad use of unerased_proxy attribute")
    }
}

pub(crate) struct FunctionInfo<'tcx> {
    pub function: vir::ast::FunctionStub,
    pub function_for_autospec: Option<vir::ast::FunctionStub>,

    pub pre_header: PreHeader,
    pub def_id: DefId,
    pub body_id: CheckItemFnEither<BodyId, ()>,
    pub sig: FnOrConstSig<'tcx>,
    pub vattrs: VerifierAttrs,
    pub external_trait_from_to: Option<(vir::ast::Path, vir::ast::Path, Option<vir::ast::Path>)>,
    pub migrate_postcondition_vars: Option<HashSet<VarIdent>>,
    pub assume_specification_opaque_type_map: Option<HashMap<Path, Path>>,
    pub return_opaque_type_eqs: Vec<(Typ, Typ)>,
    pub ret_typ_mode: Option<(Typ, Mode)>,
    pub autoderive_action: Option<AutomaticDeriveAction>,
    pub is_external_const: bool,
}

pub(crate) struct ConstInfo {
    function: vir::ast::FunctionStub,
    function_for_autospec: Option<vir::ast::FunctionStub>,

    pre_header: PreHeader,
    def_id: DefId,
    body_id: BodyId,
    vattrs: VerifierAttrs,
    span: Span,
    body_mode: Mode,
    ret_mode: Mode,
    func_mode: Mode,
    is_static: bool,
}

pub(crate) struct ForeignFunctionInfo {
    pub function_stub: vir::ast::FunctionStub,
    pub function_full: vir::ast::Function,
}

pub(crate) enum FunctionOrConstInfo<'tcx> {
    Function(FunctionInfo<'tcx>),
    ForeignFunction(ForeignFunctionInfo),
    Const(ConstInfo),
}

impl<'tcx> FunctionOrConstInfo<'tcx> {
    pub(crate) fn iter_stubs<'a>(&'a self) -> impl Iterator<Item = &'a vir::ast::FunctionStub> {
        let (f, opt_f) = match self {
            FunctionOrConstInfo::Function(f) => (&f.function, f.function_for_autospec.as_ref()),
            FunctionOrConstInfo::Const(f) => (&f.function, f.function_for_autospec.as_ref()),
            FunctionOrConstInfo::ForeignFunction(f) => (&f.function_stub, None),
        };
        std::iter::once(f).chain(opt_f.into_iter())
    }
}

fn get_pre_header<'tcx>(
    ctxt: &Context<'tcx>,
    vir_params: &[vir::ast::Param],
    body_id: &CheckItemFnEither<&BodyId, &[Ident]>,
    is_async: bool,
) -> Result<PreHeader, VirErr> {
    match body_id {
        CheckItemFnEither::BodyId(body_id) => {
            let body = find_body(ctxt, body_id);
            crate::pre_header::get_preheader(ctxt, vir_params, body, is_async)
        }
        CheckItemFnEither::ParamNames(_) => Ok(crate::pre_header::empty_preheader()),
    }
}

/// Strips the `__verus_param_N @` the macros add to complex parameter patterns,
/// since only ghost code uses the name
fn peel_verus_param<'tcx>(pat: &'tcx Pat<'tcx>) -> &'tcx Pat<'tcx> {
    match pat.kind {
        PatKind::Binding(_, _, ident, Some(sub))
            if rustc_mir_build_verus::verus::is_verus_param_binder(&ident) =>
        {
            sub
        }
        _ => pat,
    }
}

pub(crate) fn check_item_fn<'tcx>(
    ctxt: &Context<'tcx>,
    state: &mut State,
    infos: &mut Vec<FunctionOrConstInfo<'tcx>>,
    reveal_groups: Option<&mut Vec<vir::ast::RevealGroup>>,
    id: DefId,
    kind: FunctionKind,
    visibility: vir::ast::Visibility,
    module_path: &vir::ast::Path,
    attrs: &[Attribute],
    sig: FnOrConstSig<'tcx>,
    // (impl generics, impl def_id)
    self_generics: Option<(&'tcx Generics, DefId)>,
    generics: &'tcx Generics,
    body_id: CheckItemFnEither<&BodyId, &[Ident]>,
    // (target ExternalTraitSpecificationFor name, target external_trait_extension spec trait name)
    external_trait: Option<(DefId, Option<String>)>,
    external_fn_specification_via_external_trait: Option<DefId>,
    autoderive_action: Option<AutomaticDeriveAction>,
    opaque_types: &mut OpaqueTypes,
) -> Result<Option<Fun>, VirErr> {
    let mut this_path = ctxt.def_id_to_vir_path(id);

    let is_verus_spec = this_path.segments.last().expect("segment.last").starts_with(VERUS_SPEC);

    let vattrs = ctxt.get_verifier_attrs(attrs)?;
    let mode = match &sig.sig {
        FnOrConstSigEnum::Fn(..) => get_mode(Mode::Exec, attrs),
        FnOrConstSigEnum::ConstVar(..) => get_mode(Mode::Spec, attrs),
    };

    let do_migration = {
        let migration_attr = crate::attributes::migrate_postconditions_walk_parents(ctxt.tcx, id);
        migration_attr == Some(true)
    };

    if vattrs.encoded_const || vattrs.encoded_static {
        let fn_sig = ctxt.tcx.fn_sig(id).skip_binder();
        if fn_sig.inputs().skip_binder().len() != 0 {
            return err_span(sig.span, "encoded_const must have 0 arguments");
        }

        let body_id = match body_id {
            CheckItemFnEither::BodyId(body_id) => body_id,
            CheckItemFnEither::ParamNames(_) => {
                crate::internal_err!(sig.span, "encoded_const expected CheckItemFnEither::BodyId");
            }
        };

        let ty = fn_sig.output().skip_binder();
        let typ = ctxt.mid_ty_to_vir(id, sig.span, &ty, None)?;

        let fun = check_item_const_or_static(
            ctxt,
            state,
            infos,
            sig.span,
            id,
            visibility,
            module_path,
            attrs,
            &typ,
            body_id,
            vattrs.encoded_static,
            self_generics,
        )?;
        return Ok(Some(fun));
    }

    if vattrs.unerased_proxy {
        this_path = fixup_unerased_proxy_path(&this_path, sig.span)?;
    }

    let external_trait_from_to = if let Some((to_trait_id, to_spec_name)) = external_trait {
        let from_trait_id = ctxt.tcx.parent(id);
        let from_path = ctxt.def_id_to_vir_path(from_trait_id);
        let to_path = ctxt.def_id_to_vir_path(to_trait_id);
        let to_spec_path = if let Some(name) = to_spec_name {
            Some(from_path.pop_segment().push_segment(Arc::new(name.clone())))
        } else {
            None
        };
        Some((from_path, to_path, to_spec_path))
    } else {
        None
    };

    let (
        path,
        proxy,
        visibility,
        kind,
        has_self_param,
        safety,
        is_external_const,
        external_id,
        is_async,
    ) = if vattrs.external_fn_specification
        || external_fn_specification_via_external_trait.is_some()
    {
        if is_verus_spec {
            return err_span(
                sig.span,
                "assume_specification attribute not supported with VERUS_SPEC",
            );
        }

        let (
            external_path,
            external_item_visibility,
            kind,
            has_self_param,
            safety,
            is_const,
            external_id,
            is_async,
        ) = handle_external_fn(
            ctxt,
            state,
            id,
            kind,
            visibility,
            &sig,
            self_generics,
            &body_id,
            mode,
            &vattrs,
            &external_trait_from_to,
            external_fn_specification_via_external_trait,
        )?;

        let proxy = Some((*ctxt.spanned_new(sig.span, this_path.clone())).clone());

        (
            external_path,
            proxy,
            external_item_visibility,
            kind,
            has_self_param,
            safety,
            is_const,
            Some(external_id),
            is_async,
        )
    } else {
        // No proxy.
        let has_self_param = has_self_parameter(ctxt, id);
        let safety = sig.safety();
        let is_async = sig.asyncness().is_async();
        (this_path.clone(), None, visibility, kind, has_self_param, safety, false, None, is_async)
    };

    let collect_hidden_type_eqs = external_id.is_none()
        && matches!(&body_id, CheckItemFnEither::BodyId(_))
        && !vattrs.external_body
        && !vattrs.external_fn_specification;
    let opaque_types_len_before = opaque_types.len();
    let (assume_specification_opaque_type_map, return_opaque_type_eqs) =
        if let Some(external_id) = external_id {
            let (opaque_type_map, _) = check_fn_opaque_ty(
                ctxt,
                opaque_types,
                &external_id,
                sig.output_span(),
                Some(&id),
                false,
            )?;
            (Some(opaque_type_map), Vec::new())
        } else {
            let (_, hidden_type_eqs) = check_fn_opaque_ty(
                ctxt,
                opaque_types,
                &id,
                sig.output_span(),
                None,
                collect_hidden_type_eqs,
            )?;
            (None, hidden_type_eqs)
        };

    if opaque_types.len() > opaque_types_len_before || is_async {
        let reason = if is_async { "async" } else { "impl trait in return position" };
        if mode != Mode::Exec {
            return err_span(sig.span, format!("{reason} is only supported for 'exec' functions"));
        }
        if vattrs.autospec.is_some() {
            return err_span(
                sig.span,
                format!("{reason} is not supported together with `when_used_as_spec`"),
            );
        }
        if vattrs.allow_in_spec {
            return err_span(
                sig.span,
                format!("{reason} is not supported together with `allow_in_spec`"),
            );
        }
    }

    let name = Arc::new(FunX { path: path.clone() });

    let self_typ_params = if let Some((cg, impl_def_id)) = self_generics {
        Some(check_generics_bounds_no_polarity(
            ctxt.tcx,
            &ctxt.verus_items,
            cg.span,
            Some(cg),
            impl_def_id,
            Some(&mut *ctxt.diagnostics.borrow_mut()),
        )?)
    } else {
        None
    };

    let (ret_typ_mode, inputs) = match &sig.sig {
        FnOrConstSigEnum::Fn(FnSig {
            header: FnHeader { safety, constness: _, asyncness: _, abi: _ },
            decl,
            span: _,
        }) => {
            let fn_sig = ctxt.tcx.fn_sig(id).skip_binder();
            let inputs = fn_sig.inputs().skip_binder();
            if mode != Mode::Exec && safety == &HeaderSafety::Normal(Safety::Unsafe) {
                return err_span(
                    sig.span,
                    format!("'unsafe' only makes sense on exec-mode functions"),
                );
            }
            let ret_typ_mode = check_fn_decl(
                sig.span,
                ctxt,
                id,
                decl,
                attrs,
                mode,
                fn_sig.output().skip_binder(),
                assume_specification_opaque_type_map.as_ref(),
            )?;
            (ret_typ_mode, inputs.to_vec())
        }
        FnOrConstSigEnum::ConstVar(typ) => {
            // TODO: generalize beyond default const mode (spec + exec):
            let mode_opt = crate::attributes::get_mode_opt(attrs);
            let ret_mode = get_ret_mode(Mode::Exec, attrs);
            if mode_opt.is_some() || ret_mode != Mode::Exec {
                unsupported_err!(sig.span, "non-default mode on associated const")
            }
            (Some((typ.clone(), Mode::Exec)), vec![])
        }
    };

    let (sig_typ_params, sig_typ_bounds) = check_generics_bounds_no_polarity(
        ctxt.tcx,
        &ctxt.verus_items,
        generics.span,
        Some(generics),
        id,
        Some(&mut *ctxt.diagnostics.borrow_mut()),
    )?;

    let params: Vec<(VarIdent, Span, Option<HirId>, bool)> = match body_id {
        CheckItemFnEither::BodyId(body_id) => {
            let body = find_body(ctxt, body_id);
            let Body { params, value: _ } = body;
            let mut ps = Vec::new();
            for Param { hir_id, pat, ty_span: _, span } in params.iter() {
                let (is_mut_var, name) = param_pat_to_mut_var(peel_verus_param(pat))?;
                // is_mut_var: means a parameter is like `mut x: X`
                // is_mut: means a parameter is like `x: &mut X` or `x: Tracked<&mut X>`
                ps.push((name, *span, Some(*hir_id), is_mut_var));
            }
            ps
        }
        CheckItemFnEither::ParamNames(params) => params
            .iter()
            .enumerate()
            .map(|(i, p)| (no_body_param_to_var(p, i), p.span, None, false))
            .collect(),
    };

    let mut migrate_postcondition_vars: HashSet<VarIdent> = HashSet::new();
    let mut vir_params: Vec<vir::ast::Param> = Vec::new();
    assert!(params.len() == inputs.len());
    for ((name, span, hir_id, is_mut_var), input) in params.into_iter().zip(inputs.iter()) {
        let param_mode = if let Some(hir_id) = hir_id {
            get_var_mode(mode, ctxt.tcx.hir_attrs(hir_id))
        } else {
            assert!(matches!(kind, FunctionKind::TraitMethodDecl { .. }));
            // This case is for a trait method declaration,
            // where the mode will later be overridden by the separate spec method anyway:
            Mode::Exec
        };

        if do_migration {
            if is_mut_ty(ctxt, *input).is_some() {
                migrate_postcondition_vars.insert(name.clone());
            }
        }

        let typ = ctxt.mid_ty_to_vir(id, span, input, None)?;

        if matches!(&*typ, TypX::MutRef(_)) {
            if vattrs.allow_in_spec {
                return err_span(
                    span,
                    format!("allow_in_spec not supported for function with &mut param"),
                );
            }
            if vattrs.autospec.is_some() {
                return err_span(
                    span,
                    format!("when_used_as_spec not supported for function with &mut param"),
                );
            }
        }

        let vir_param = ctxt.spanned_new(
            span,
            ParamX {
                name: name.clone(),
                typ: typ.clone(),
                mode: param_mode,
                unwrapped_info: None,
                user_mut: is_mut_var,
            },
        );

        if is_mut_var {
            if mode == Mode::Spec {
                return err_span(span, format!("mut argument not allowed for spec functions"));
            }
        }

        vir_params.push(vir_param);
    }

    if is_async {
        if let CheckItemFnEither::BodyId(body_id) = body_id {
            vir_params = param_names_for_async_func(ctxt, find_body(ctxt, body_id), &vir_params)?;
        }
    }

    let n_params = vir_params.len();

    if vattrs.reveal_group {
        let CheckItemFnEither::BodyId(body_id) = body_id else {
            return err_span(sig.span, "reveal_group must have body");
        };
        let body = find_body(ctxt, body_id);
        let (vir_body, _) = body_to_vir(
            ctxt,
            id,
            body_id,
            body,
            mode,
            false,
            &external_trait_from_to,
            None,
            &vir_params,
            assume_specification_opaque_type_map.clone(),
            false,
        )?;
        create_reveal_group(
            ctxt,
            reveal_groups,
            &name,
            visibility,
            module_path,
            &vattrs,
            &vir_body,
            sig.span,
        )?;
        return Ok(None);
    }

    let pre_header = get_pre_header(ctxt, &vir_params, &body_id, is_async)?;

    match (&kind, pre_header.no_method_body, is_verus_spec, &body_id) {
        (FunctionKind::TraitMethodDecl { .. }, false, false, _) => {}
        (FunctionKind::TraitMethodDecl { .. }, true, true, _) => {}
        (FunctionKind::TraitMethodDecl { .. }, false, true, _) => {
            return err_span(
                sig.span,
                "trait method declaration body must start with call to no_method_body()",
            );
        }
        (FunctionKind::TraitMethodDecl { .. }, true, false, _) => {
            return err_span(
                sig.span,
                format!(
                    "trait declaration with no_method_body() should start with {:}",
                    VERUS_SPEC
                ),
            );
        }
        (_, _, true, _) => {
            return err_span(
                sig.span,
                format!("{VERUS_SPEC} can only appear in trait method declarations"),
            );
        }
        (_, false, false, CheckItemFnEither::BodyId(_)) => {}
        (_, false, false, CheckItemFnEither::ParamNames(_)) => {
            return err_span(sig.span, "function must have a body");
        }
        (_, true, _, _) => {
            return err_span(
                sig.span,
                "no_method_body can only appear in trait method declarations",
            );
        }
    }

    if mode != Mode::Exec && vattrs.external_fn_specification {
        return err_span(sig.span, "assume_specification should be 'exec'");
    }

    let mut all_param_names: Vec<vir::ast::VarIdent> = Vec::new();
    let mut all_param_name_set: HashSet<vir::ast::VarIdent> = HashSet::new();
    let mut unwrap_param_map: HashMap<vir::ast::VarIdent, UnwrapParameter> = HashMap::new();
    for unwrap in pre_header.unwrap_parameters.iter() {
        all_param_names.push(unwrap.inner_name.clone());
        unwrap_param_map.insert(unwrap.outer_name.clone(), unwrap.clone());
    }

    let migrate_postcondition_vars = if do_migration {
        let mut new = HashSet::new();
        for var in migrate_postcondition_vars.iter() {
            let v = match unwrap_param_map.get(var) {
                Some(unwrap) => unwrap.inner_name.clone(),
                None => var.clone(),
            };
            let inserted = new.insert(v.clone());
            assert!(inserted);
        }
        Some(new)
    } else {
        None
    };

    for param in vir_params.iter_mut() {
        all_param_names.push(param.x.name.clone());
        if let Some(unwrap) = unwrap_param_map.get(&param.x.name) {
            if mode != Mode::Exec {
                return err_span(
                    sig.span,
                    "only exec functions can use Ghost(x) or Tracked(x) parameters",
                );
            }
            let mut paramx = param.x.clone();
            paramx.name = unwrap.inner_name.clone();
            paramx.unwrapped_info = Some((unwrap.mode, unwrap.outer_name.clone()));
            *param = vir::def::Spanned::new(param.span.clone(), paramx);
        }
    }
    for name in all_param_names.iter() {
        if all_param_name_set.contains(name) {
            return err_span(sig.span, format!("duplicate parameter name {}", name));
        }
        all_param_name_set.insert(name.clone());
    }
    let params: vir::ast::Params = Arc::new(vir_params);

    let (ret_name, ret_typ, ret_mode) =
        match (is_async, pre_header.ensure_id.clone(), ret_typ_mode.clone()) {
            (false, None, None) => (air_unique_var(RETURN_VALUE), unit_typ(), mode),
            (false, None, Some((typ, mode))) => (air_unique_var(RETURN_VALUE), typ, mode),
            (false, Some(x), Some((typ, mode))) => (x, typ, mode),
            (true, _, Some((typ, mode))) => (air_unique_var(RETURN_VALUE_ASYNC_FUTURE), typ, mode),
            _ => panic!("internal error: ret_typ"),
        };
    let ret_span = sig.output_span();
    let ret = ctxt.spanned_new(
        ret_span,
        ParamX {
            name: ret_name.clone(),
            typ: ret_typ,
            mode: ret_mode,
            user_mut: false,
            unwrapped_info: None,
        },
    );

    let (typ_params, typ_bounds) = {
        let mut typ_params: Vec<vir::ast::Ident> = Vec::new();
        let mut typ_bounds: Vec<vir::ast::GenericBound> = Vec::new();
        if let FunctionKind::TraitMethodDecl { .. } = kind {
            if !vattrs.external_fn_specification {
                typ_params.push(vir::def::trait_self_type_param());
            }
        }
        if let Some((self_typ_params, self_typ_bounds)) = self_typ_params {
            typ_params.append(&mut (*self_typ_params).clone());
            typ_bounds.append(&mut (*self_typ_bounds).clone());
        }
        typ_params.extend_from_slice(&sig_typ_params[..]);
        typ_bounds.extend_from_slice(&sig_typ_bounds[..]);
        let typ_params = Arc::new(typ_params);
        let mut typ_bounds = Arc::new(typ_bounds);

        if let Some((from_path, to_path, _)) = &external_trait_from_to {
            typ_bounds = vir::traits::rewrite_external_bounds(from_path, to_path, &typ_bounds);
        }
        (typ_params, typ_bounds)
    };

    let has_body = !vattrs.external_body
        && !vattrs.external_fn_specification
        && !pre_header.no_method_body
        && matches!(body_id, CheckItemFnEither::BodyId(_));

    let open_closed_present =
        vattrs.publish == Some(AttrPublish::Open) || vattrs.publish == Some(AttrPublish::Closed);
    match kind {
        FunctionKind::TraitMethodImpl { .. } | FunctionKind::TraitMethodDecl { .. } if has_body => {
            if mode == Mode::Spec
                && visibility.restricted_to.as_ref() != Some(module_path)
                && !open_closed_present
                && !matches!(sig.sig, FnOrConstSigEnum::ConstVar(..))
            {
                return err_span(
                    sig.span,
                    "open/closed is required for implementations of non-private traits",
                );
            }
        }
        FunctionKind::TraitMethodDecl { .. } => {
            if mode == Mode::Spec && open_closed_present && !has_body {
                return err_span(
                    sig.span,
                    "trait function declarations cannot be open or closed, as they don't have a body",
                );
            }
        }
        _ => (),
    }

    if vattrs.nonlinear && vattrs.spinoff_prover {
        return err_span(
            sig.span,
            "#[verifier::spinoff_prover] is implied for assert by nonlinear_arith",
        );
    }

    if vattrs.type_invariant_fn {
        check_generics_for_invariant_fn(ctxt.tcx, id, self_generics, generics, sig.span)?;
    }

    let is_drop = match kind {
        FunctionKind::TraitMethodImpl { ref trait_path, .. } => {
            trait_path == &ctxt.def_id_to_vir_path(ctxt.tcx.lang_items().drop_trait().unwrap())
        }
        _ => false,
    };

    let fattrs = make_attributes(
        ctxt,
        id,
        &vattrs,
        vattrs.verus_macro && !matches!(sig.sig, FnOrConstSigEnum::ConstVar(..)),
        n_params == 0,
        has_self_param,
        safety,
        is_async,
        sig.span,
        matches!(kind, FunctionKind::TraitMethodDecl { has_default: false, .. }),
        is_drop,
    )?;

    // This function is marked 'private' at the source level to prevent the user from
    // calling it. But we translate things to point to it internally, so we need to
    // mark it non-private in order to avoid errors down the line.
    let mut visibility = visibility;
    for b in [true, false] {
        if path == vir::def::nonstatic_call_path(b) {
            visibility.restricted_to = None;
        }
    }

    if path == vir::def::exec_await_path() {
        visibility.restricted_to = None;
    }

    let (publish, mode, item_kind) = match (is_external_const, pre_header.returns) {
        (true, true) => {
            // In an external const declaration, use returns expression as spec function body:
            let private_vis = Visibility { restricted_to: Some(module_path.clone()) };
            let publish = match (visibility == private_vis, &vattrs.publish) {
                (false, None) => Some(AttrPublish::Open),
                _ => vattrs.publish.clone(),
            };
            (publish, Mode::Spec, ItemKind::Const)
        }
        (true, false) => {
            // In an external const declaration, no returns means exec-only:
            assert!(mode == Mode::Exec);
            (vattrs.publish.clone(), mode, ItemKind::Const)
        }
        (_, _) => (vattrs.publish.clone(), mode, sig.item_kind()),
    };

    let (body_visibility, opaqueness) = get_body_visibility_and_fuel(
        sig.span,
        &visibility,
        publish,
        &pre_header.open_visibility_qualifier,
        vattrs.opaque,
        vattrs.opaque_outside_module,
        mode,
        module_path,
        has_body || (is_external_const && pre_header.returns),
    )?;
    let body_visibility =
        sig.override_body_visibility(publish, visibility.clone(), body_visibility);

    ctxt.push_body_erasure(
        id.expect_local(),
        BodyErasure { erase_body: mode == Mode::Spec, ret_spec: ret_mode == Mode::Spec },
    );

    let mut func = FunctionStubX {
        name: name.clone(),
        proxy,
        kind,
        visibility,
        body_visibility,
        opaqueness,
        owning_module: Some(module_path.clone()),
        mode,
        typ_params,
        typ_bounds,
        params,
        outer_ret: ret,
        item_kind,
        attrs: fattrs,
        decreases_len: pre_header.decreases_len,
        returns: pre_header.returns && !is_external_const,
    };

    crate::tuple_clone::adjust_stub(&mut func)?;
    if vattrs.external_fn_specification {
        func = fix_external_fn_specification_trait_method_decl_typs_stub(sig.span, func)?;
    }

    let mut function = ctxt.spanned_new(sig.span, func);

    let autospec = handle_autospec(ctxt, sig.span, id, &vattrs, &function.x)?;
    if autospec.redirect_to.is_some() {
        Arc::make_mut(&mut Arc::make_mut(&mut function).x.attrs).autospec =
            autospec.redirect_to.clone();
    }

    state.insert_fun_warn_config(ctxt, &function.x.name, id);
    if let Some(f) = &autospec.new_func {
        state.insert_fun_warn_config(ctxt, &f.x.name, id);
    }

    infos.push(FunctionOrConstInfo::Function(FunctionInfo {
        function,
        function_for_autospec: autospec.new_func,
        pre_header,

        body_id: match body_id {
            CheckItemFnEither::BodyId(body_id) => CheckItemFnEither::BodyId(*body_id),
            CheckItemFnEither::ParamNames(_) => CheckItemFnEither::ParamNames(()),
        },
        sig,
        vattrs,
        def_id: id,
        external_trait_from_to,
        migrate_postcondition_vars,
        assume_specification_opaque_type_map,
        return_opaque_type_eqs,
        ret_typ_mode,
        autoderive_action: autoderive_action,
        is_external_const,
    }));

    if is_verus_spec { Ok(None) } else { Ok(Some(name)) }
}

pub(crate) fn finish_item<'tcx>(
    ctxt: &Context<'tcx>,
    info: &FunctionOrConstInfo,
    functions: &mut Vec<vir::ast::Function>,
) -> Result<(), VirErr> {
    match info {
        FunctionOrConstInfo::Function(function_info) => {
            finish_function(ctxt, function_info, functions)
        }
        FunctionOrConstInfo::Const(const_info) => {
            finish_const_or_static(ctxt, const_info, functions)
        }
        FunctionOrConstInfo::ForeignFunction(foreign_function_info) => {
            functions.push(foreign_function_info.function_full.clone());
            Ok(())
        }
    }
}

pub(crate) fn finish_function<'tcx>(
    ctxt: &Context<'tcx>,
    function_info: &FunctionInfo,
    functions: &mut Vec<vir::ast::Function>,
) -> Result<(), VirErr> {
    let FunctionInfo {
        ref function,
        ref function_for_autospec,
        ref pre_header,
        ref body_id,
        ref sig,
        ref vattrs,
        def_id,
        ref external_trait_from_to,
        ref migrate_postcondition_vars,
        ref assume_specification_opaque_type_map,
        ref return_opaque_type_eqs,
        ref ret_typ_mode,
        autoderive_action,
        ref is_external_const,
    } = *function_info;
    let vir::ast::FunctionStubX {
        name,
        proxy,
        kind,
        visibility,
        body_visibility,
        opaqueness,
        owning_module,
        mode,
        typ_params,
        typ_bounds,
        params,
        outer_ret,
        item_kind,
        attrs,
        returns: has_returns,
        decreases_len,
    } = function.x.clone();
    let is_async = attrs.is_async;

    let (vir_body, header, body_hir_id) = match &body_id {
        CheckItemFnEither::BodyId(body_id) => {
            let is_async = match sig.asyncness() {
                rustc_hir::IsAsync::NotAsync => false,
                rustc_hir::IsAsync::Async(..) => true,
            };
            let body = find_body(ctxt, body_id);
            let external_body = vattrs.external_body || vattrs.external_fn_specification;

            let (mut vir_body, param_decls) = body_to_vir(
                ctxt,
                def_id,
                body_id,
                body,
                mode,
                external_body,
                &external_trait_from_to,
                migrate_postcondition_vars.clone(),
                &params,
                assume_specification_opaque_type_map.clone(),
                is_async,
            )?;
            let mut header =
                vir::headers::read_header(&mut vir_body, &vir::headers::HeaderAllows::All)?;
            add_param_decls(ctxt, sig.span, &mut header, &mut vir_body, param_decls)?;
            (Some(vir_body), header, Some(body.value.hir_id))
        }
        CheckItemFnEither::ParamNames(_params) => {
            let header =
                vir::headers::read_header_block(&mut vec![], &vir::headers::HeaderAllows::All)?;
            (None, header, None)
        }
    };

    crate::pre_header::sanity_check_preheader(sig.span, &header, &pre_header)?;

    let body = if vattrs.external_body || vattrs.external_fn_specification || header.no_method_body
    {
        None
    } else {
        vir_body
    };

    let mut recommend: Vec<vir::ast::Expr> = (*header.recommend).clone();
    if let Some(decrease_when) = &header.decrease_when {
        // Automatically add decrease_when to recommends
        recommend.push(decrease_when.clone());
    }

    let inner_ret = if !is_async {
        outer_ret.clone()
    } else {
        outer_ret.new_x(ParamX {
            name: match header.ensure_id_typ {
                Some((ref id, _)) => id.clone(),
                None => air_unique_var(RETURN_VALUE),
            },
            typ: get_async_inner_return_typ(ctxt, sig.span, def_id, &body_id)?,
            mode: outer_ret.x.mode,
            user_mut: false,
            unwrapped_info: None,
        })
    };

    if let Some((_, Some(t))) = &header.ensure_id_typ
        && !vir::ast_util::types_equal(t, &inner_ret.x.typ)
    {
        crate::internal_err!(sig.span, "return type does not match binder in ensures")
    }

    let ensure0 = clean_ensures_for_unit_return(ctxt, &inner_ret, &header.ensure.0);
    let ensure1 = clean_ensures_for_unit_return(ctxt, &inner_ret, &header.ensure.1);

    if mode == Mode::Spec
        && (header.require.len() + header.ensure.0.len() + header.ensure.1.len()) > 0
    {
        return err_span(sig.span, "spec functions cannot have requires/ensures");
    }
    if mode == Mode::Spec && header.returns.is_some() && !is_external_const {
        return err_span(sig.span, "spec functions cannot have `returns` clause");
    }
    if mode != Mode::Spec && header.recommend.len() > 0 {
        return err_span(sig.span, "non-spec functions cannot have recommends");
    }
    if mode != Mode::Exec && header.atomic_update.is_some() {
        return err_span(sig.span, "non-exec function cannot have atomic specification");
    }

    let (ensure, returns, body) = match (is_external_const, header.returns) {
        (true, Some(returns)) => {
            // In an external const declaration, use returns expression as spec function body:
            ((Arc::new(vec![]), Arc::new(vec![])), None, Some(returns))
        }
        (true, None) => {
            // In an external const declaration, no returns means exec-only:
            assert!(mode == Mode::Exec);
            ((ensure0, ensure1), None, body)
        }
        (_, returns) => ((ensure0, ensure1), returns, body),
    };
    let return_opaque_type_eqs = if body.is_some() && !is_external_const {
        Arc::new(return_opaque_type_eqs.clone())
    } else {
        Arc::new(vec![])
    };

    if header.ensure.0.len() + header.ensure.1.len() > 0 {
        match (is_async, &header.ensure_id_typ, ret_typ_mode.as_ref()) {
            (_, None, None) => {}
            (_, None, Some(_)) => {}
            (_, Some(_), None) => {
                return err_span(
                    sig.span,
                    "unexpected named return value for function with default return",
                );
            }
            (false, Some((_, Some(typ))), Some((ret_typ, _))) => {
                if !vir::ast_util::types_equal(&typ, &ret_typ) {
                    return err_span(
                        sig.span,
                        format!("return type is {:?}, but ensures expects type {:?}", ret_typ, typ),
                    );
                }
            }
            (true, Some((_, Some(_))), Some((ret_typ, _))) => {
                if !matches!(**ret_typ, TypX::Opaque { .. }) {
                    return err_span(
                        sig.span,
                        format!(
                            "async function must return opaque type (impl Future) {:?}",
                            ret_typ,
                        ),
                    );
                }
            }
            (_, Some(_), Some(_)) => {}
        }
    }

    let mut functionx = FunctionX {
        name,
        proxy,
        kind,
        visibility,
        body_visibility,
        opaqueness,
        owning_module,
        mode,
        typ_params,
        typ_bounds,
        params,
        outer_ret,
        inner_ret,
        require: if mode == Mode::Spec { Arc::new(recommend) } else { header.require },
        returns,
        ensure,
        decrease: header.decrease,
        decrease_by: header.decrease_by,
        decrease_when: header.decrease_when,
        fndef_axioms: None,
        mask_spec: header.invariant_mask,
        atomic_update: header.atomic_update,
        unwind_spec: header.unwind_spec,
        item_kind,
        attrs,
        body,
        return_opaque_type_eqs,
        extra_dependencies: header.extra_dependencies,
        hidden: Arc::new(header.hidden.clone()),
    };

    assert!(functionx.returns.is_some() == has_returns);
    assert!(functionx.decrease.len() == decreases_len);

    if vattrs.external_fn_specification {
        check_external_fn_specification_trait_method_decl_typs(sig.span, &functionx)?;
    }

    if let Some(action) = autoderive_action {
        if body_hir_id.is_some() {
            let inputs = match &sig.sig {
                FnOrConstSigEnum::Fn(..) => {
                    let fn_sig = ctxt.tcx.fn_sig(def_id).skip_binder();
                    fn_sig.inputs().skip_binder().to_vec()
                }
                FnOrConstSigEnum::ConstVar(..) => vec![],
            };

            crate::automatic_derive::modify_derived_item(
                ctxt,
                def_id,
                &inputs,
                sig.span,
                action,
                &mut functionx,
            )?;
        }
    }

    let function = Spanned::new(function.span.clone(), functionx);
    crate::tuple_clone::validate_full(&function)?;
    let function = if let Some((from_path, to_path, to_spec_path)) = &external_trait_from_to {
        vir::traits::rewrite_external_function(from_path, to_path, to_spec_path, &function)
    } else {
        function
    };

    functions.push(function.clone());

    if let Some(f) = &function_for_autospec {
        functions.push(finish_autospec(sig.span, &function, f)?);
    }

    Ok(())
}

fn has_self_parameter<'tcx>(ctxt: &Context<'tcx>, id: DefId) -> bool {
    if let Some(assoc_item) = ctxt.tcx.opt_associated_item(id) {
        assoc_item.is_method()
    } else {
        false
    }
}

fn fix_external_fn_specification_trait_method_decl_typs_stub(
    span: Span,
    func: FunctionStubX,
) -> Result<FunctionStubX, VirErr> {
    if matches!(func.kind, FunctionKind::ForeignTraitMethodImpl { .. }) {
        // There's nothing to do here. It's fine if the param names of
        // a traim method impl don't line up with the type params of the impl.
        Ok(func)
    } else if let FunctionKind::TraitMethodDecl { .. } = &func.kind {
        let FunctionStubX {
            name,
            proxy,
            kind,
            visibility,
            body_visibility,
            opaqueness,
            owning_module,
            mode,
            typ_params,
            mut typ_bounds,
            mut params,
            mut outer_ret,
            item_kind,
            attrs,
            decreases_len,
            returns,
        } = func;

        unsupported_err_unless!(typ_params.len() == 1, span, "type params");

        let mut typ_substs = HashMap::<Arc<String>, Typ>::new();
        typ_substs.insert(
            typ_params[0].clone(),
            Arc::new(TypX::TypParam(vir::def::trait_self_type_param())),
        );
        typ_bounds = vir::sst_util::subst_typ_in_bounds(&typ_substs, &typ_bounds);

        let mut typ_params = (*typ_params).clone();
        typ_params[0] = vir::def::trait_self_type_param();
        let typ_params = Arc::new(typ_params);

        //params = params.iter().map(|p| p.new_x(p.x.new_a(subst_typ(&typ_substs, &p.a)))).collect();
        //outer_ret = outer_ret.new_x(outer_ret.x.new_a(&typ_substs, &outer_ret.a));
        params = Arc::new(crate::util::vec_map(&params, |p| {
            p.new_x(ParamX { typ: subst_typ(&typ_substs, &p.x.typ), ..p.x.clone() })
        }));

        outer_ret = outer_ret
            .new_x(ParamX { typ: subst_typ(&typ_substs, &outer_ret.x.typ), ..outer_ret.x.clone() });

        unsupported_err_unless!(!attrs.broadcast_forall, span, "broadcast_forall");

        Ok(FunctionStubX {
            name,
            proxy,
            kind,
            visibility,
            body_visibility,
            opaqueness,
            owning_module,
            mode,
            typ_params,
            typ_bounds,
            params,
            outer_ret,
            item_kind,
            attrs,
            decreases_len,
            returns,
        })
    } else {
        Ok(func)
    }
}

fn check_external_fn_specification_trait_method_decl_typs(
    span: Span,
    func: &FunctionX,
) -> Result<(), VirErr> {
    if let FunctionKind::TraitMethodDecl { .. } = &func.kind {
        let FunctionX {
            name: _,
            proxy: _,
            kind: _,
            visibility: _,
            body_visibility: _,
            opaqueness: _,
            owning_module: _,
            mode: _,
            typ_params: _,
            typ_bounds: _,
            params: _,
            outer_ret: _,
            inner_ret: _,
            require,
            ensure,
            returns,
            decrease,
            decrease_when,
            decrease_by,
            fndef_axioms: _,
            mask_spec,
            atomic_update: _,
            unwind_spec,
            item_kind: _,
            attrs: _,
            body,
            return_opaque_type_eqs: _,
            extra_dependencies: _,
            hidden: _,
        } = func;

        // We would need to implement substitution logic to support these
        unsupported_err_unless!(require.len() == 0, span, "requires clauses");
        unsupported_err_unless!(ensure.0.len() + ensure.1.len() == 0, span, "ensures clauses");
        unsupported_err_unless!(returns.is_some(), span, "returns clauses");
        unsupported_err_unless!(decrease.len() == 0, span, "decreases clauses");
        unsupported_err_unless!(decrease_when.is_none(), span, "decreases_when clauses");
        unsupported_err_unless!(decrease_by.is_none(), span, "decreases_by clauses");
        unsupported_err_unless!(matches!(mask_spec, None), span, "opens_invariants");
        unsupported_err_unless!(matches!(unwind_spec, None), span, "unwind");
        unsupported_err_unless!(body.is_none(), span, "opens_invariants");
    }
    Ok(())
}

fn param_names_for_async_func<'tcx>(
    ctxt: &Context<'tcx>,
    body_hir: &Body<'tcx>,
    params: &[vir::ast::Param],
) -> Result<Vec<vir::ast::Param>, VirErr> {
    // Each async function body is desugared into a closure.
    // At the beginning of the async function
    // each paramter is re-bound. We need to find thes rebindings and resolve them.
    // For example fn foo(x:usize){} will have one rebinding:
    // fn foo(x:usize){
    //     ||{
    //         let x = x;
    //     }
    // }
    let async_body_bindings = match body_hir.value.kind {
        rustc_hir::ExprKind::Closure(cls) => {
            let closure_body = crate::rust_to_vir_func::find_body(ctxt, &cls.body);
            match closure_body.value.kind {
                rustc_hir::ExprKind::Block(block, ..) => block.stmts,
                _ => {
                    return err_span(
                        body_hir.value.span,
                        format!("internal error: async function doesn't have a function block"),
                    );
                }
            }
        }
        _ => {
            return err_span(
                body_hir.value.span,
                format!("internal error: async function doesn't have a function block"),
            );
        }
    };

    let mut async_body_modes = HashMap::new();

    for stmt in async_body_bindings.iter() {
        match stmt.kind {
            rustc_hir::StmtKind::Let(rustc_hir::LetStmt {
                pat,
                source: rustc_hir::LocalSource::AsyncFn,
                ..
            }) if param_pat_to_destructure(peel_verus_param(pat)).is_some() => {
                return err_span(
                    pat.span,
                    "patterns in async function parameters are not supported",
                );
            }
            rustc_hir::StmtKind::Let(rustc_hir::LetStmt {
                pat: rustc_hir::Pat { kind: rustc_hir::PatKind::Binding(_, id, ident, _), .. },
                init: Some(rustc_hir::Expr { kind: rustc_hir::ExprKind::Path(qpath), .. }),
                ..
            }) => {
                let pat = local_to_var(ident, id.local_id);
                let init = qpath_to_ident(ctxt.tcx, &qpath)
                    .expect("internal error, async closure rebindings has no init value");
                async_body_modes.insert(init.clone(), pat.clone());
            }
            _ => {}
        }
    }

    let mut rewitten_params = vec![];
    for param in params.iter() {
        rewitten_params.push(Spanned::new(
            param.span.clone(),
            ParamX {
                name: async_body_modes[&param.x.name].clone(),
                typ: param.x.typ.clone(),
                mode: param.x.mode,
                unwrapped_info: param.x.unwrapped_info.clone(),
                user_mut: param.x.user_mut,
            },
        ));
    }
    Ok(rewitten_params)
}

fn check_generics_for_invariant_fn<'tcx>(
    tcx: TyCtxt<'tcx>,
    id: DefId,
    self_generics: Option<(&'tcx Generics, DefId)>,
    generics: &'tcx Generics<'tcx>,
    span: Span,
) -> Result<(), VirErr> {
    let fn_sig = tcx.fn_sig(id);
    let fn_sig = fn_sig.skip_binder();
    let inputs = fn_sig.inputs().skip_binder();

    if inputs.len() != 1 {
        return err_span(span, "#[verifier::type_invariant]: expected 1 parameter");
    }
    if tcx.trait_of_assoc(id).is_some() {
        return err_span(span, "#[verifier::type_invariant] function cannot be a trait function");
    }

    let ty = crate::rust_to_vir_base::ty_remove_references(&inputs[0]);

    match ty.kind() {
        TyKind::Adt(AdtDef(adt_def_data), substs) => {
            let adt_def = tcx.adt_def(adt_def_data.did);
            if adt_def.is_union() {
                return err_span(
                    span,
                    "not supported: #[verifier::type_invariant] for union types",
                );
            }
            assert!(adt_def.is_struct() || adt_def.is_enum());
            crate::rust_to_vir_base::check_item_external_generics(
                tcx,
                self_generics,
                generics,
                true,
                substs,
                false,
                span,
            )?;

            let datatype_predicates = adt_def.clauses(tcx);
            let func_predicates = tcx.clauses_of(id);
            let datatype_typing_env = TypingEnv::post_analysis(tcx, adt_def.did());
            let func_typing_env = TypingEnv::post_analysis(tcx, id);
            let preds1 = datatype_predicates.instantiate(tcx, substs).clauses;
            let preds2 = func_predicates.instantiate(tcx, substs).clauses;
            // The 'outlives' predicates don't always line up; I don't know why.
            // But they don't matter for the purpose of this check, so filter them out here.
            let preds1 = preds1
                .into_iter()
                .filter(|p| {
                    !matches!(
                        p.kind().skip_binder(),
                        ClauseKind::RegionOutlives(..) | ClauseKind::TypeOutlives(..)
                    )
                })
                .map(|clause| tcx.normalize_erasing_regions(datatype_typing_env, clause))
                .collect();
            let preds2 = preds2
                .into_iter()
                .filter(|p| {
                    !matches!(
                        p.kind().skip_binder(),
                        ClauseKind::RegionOutlives(..) | ClauseKind::TypeOutlives(..)
                    )
                })
                .map(|clause| tcx.normalize_erasing_regions(func_typing_env, clause))
                .collect();
            let preds_match = crate::rust_to_vir_func::predicates_match(tcx, &preds1, &preds2);
            if !preds_match {
                println!("datatype_predicates: {:#?}", preds1);
                println!("func_predicates: {:#?}", preds2);
                return err_span(span, "#[verifier::type_invariant]: trait bounds should match");
            }

            Ok(())
        }
        _ => {
            return err_span(
                span,
                "type_invariant: expected parameter to be a datatype declared in this crate",
            );
        }
    }
}

fn is_mut_ty<'tcx>(
    ctxt: &Context<'tcx>,
    ty: rustc_middle::ty::Ty<'tcx>,
) -> Option<(&'tcx rustc_middle::ty::Ty<'tcx>, Option<(Mode, TypDecoration)>)> {
    use rustc_middle::ty::*;
    match ty.kind() {
        TyKind::Ref(_, tys, rustc_ast::Mutability::Mut) => Some((tys, None)),
        TyKind::Adt(AdtDef(adt_def_data), args) => {
            let did = adt_def_data.did;
            let verus_item = ctxt.verus_items.id_to_name.get(&did);
            if let Some(VerusItem::BuiltinType(
                bt @ (BuiltinTypeItem::Ghost | BuiltinTypeItem::Tracked),
            )) = verus_item
            {
                assert_eq!(args.len(), 1);
                if let Some(t) = args[0].as_type() {
                    if let Some((inner, None)) = is_mut_ty(ctxt, t) {
                        let mode_and_decoration = match bt {
                            BuiltinTypeItem::Ghost => (Mode::Spec, TypDecoration::Ghost),
                            BuiltinTypeItem::Tracked => (Mode::Proof, TypDecoration::Tracked),
                            _ => unreachable!(),
                        };
                        return Some((inner, Some(mode_and_decoration)));
                    }
                }
            }
            None
        }
        _ => None,
    }
}

pub(crate) fn remove_ignored_trait_bounds_from_predicates<'tcx>(
    ctxt: &Context<'tcx>,
    in_trait: bool,
    mut external_trait_private_bounds: Option<&mut Vec<Vec<String>>>,
    trait_ids: &[DefId],
    ex_trait_assoc: Option<rustc_middle::ty::GenericArg<'tcx>>,
    preds: &mut Vec<Clause<'tcx>>,
) {
    use rustc_middle::ty;
    use rustc_middle::ty::{ConstKind, ScalarInt};
    let tcx = ctxt.tcx;
    preds.retain(|p: &Clause<'tcx>| match p.kind().skip_binder() {
        rustc_middle::ty::ClauseKind::<'tcx>::Trait(tp) => {
            if in_trait && trait_ids.contains(&tp.trait_ref.def_id) && tp.trait_ref.args.len() >= 1
            {
                if let Some(ty) = tp.trait_ref.args[0].as_type() {
                    match ty.kind() {
                        // ignore Self: T bound for trait T
                        ty::TyKind::Param(param)
                            if param.name == rustc_span::symbol::kw::SelfUpper =>
                        {
                            false
                        }
                        ty::TyKind::Alias(_, _) if Some(tp.trait_ref.args[0]) == ex_trait_assoc => {
                            false
                        }
                        _ => true,
                    }
                } else {
                    true
                }
            } else {
                use crate::rust_to_vir_base::def_path_to_vir_path;
                use crate::verus_items::RustItem;
                use vir::def::krate_to_string_ignore_stable_id;
                let id = tp.trait_ref.def_id;
                let rust_item = crate::verus_items::get_rust_item(tcx, id);
                let is_local = id.is_local();
                let mut is_external_trait_private_bound = false;
                let is_match = |ignore: &Vec<String>| -> bool {
                    if let Some(path) = def_path_to_vir_path(tcx, tcx.def_path(id)) {
                        ignore.len() == path.segments.len() + 1
                            && ignore[0] == krate_to_string_ignore_stable_id(&path.krate)
                            && (0..path.segments.len())
                                .into_iter()
                                .all(|i| ignore[i + 1] == path.segments[i].to_string())
                    } else {
                        false
                    }
                };
                if let Some(external_trait_private_bounds) = &mut external_trait_private_bounds {
                    if let Some(i) = external_trait_private_bounds.iter().position(is_match) {
                        // external_trait_private_bound should be for non-public bounds only.
                        // It's hard to check whether id is really "effectively" non-public,
                        // because of re-exports, but we can easily do a minimal sanity check to
                        // see that it's not obviously public:
                        let mut is_public = true;
                        let mut ancestor = Some(id);
                        while let Some(a) = ancestor {
                            is_public = is_public && tcx.visibility(a).is_public();
                            ancestor = tcx.opt_parent(a);
                        }

                        if !is_public && !is_local {
                            external_trait_private_bounds.remove(i);
                            is_external_trait_private_bound = true;
                        }
                    }
                }

                match rust_item {
                    Some(RustItem::Destruct) => false, // https://github.com/verus-lang/verus/pull/726
                    _ if is_external_trait_private_bound => false,
                    _ => true,
                }
            }
        }
        rustc_middle::ty::ClauseKind::<'tcx>::ConstArgHasType(cnst, _ty) => {
            if let ConstKind::Value(Value { ty, valtree }) = cnst.kind() {
                if *valtree == &ValTreeKind::Leaf(ScalarInt::TRUE) {
                    match ty.kind() {
                        TyKind::Bool => false,
                        _ => true,
                    }
                } else {
                    false
                }
            } else {
                false
            }
        }
        _ => true,
    });
}

pub(crate) fn predicates_match<'tcx>(
    tcx: TyCtxt<'tcx>,
    preds1: &Vec<Clause<'tcx>>,
    preds2: &Vec<Clause<'tcx>>,
) -> bool {
    if preds1.len() != preds2.len() {
        return false;
    }

    // Note: it might actually be impossible for the below check to fail?
    // Since we already passed Rust's typechecking, one of the predicate lists
    // has to be a subset of the other. But we just checked they're the same size.
    // So they have to be equal.
    //
    // Regardless, it makes sense to keep this as a sanity check.
    let preds1 = preds1.iter().map(|p| tcx.anonymize_bound_vars(p.kind()));
    let mut preds2: Vec<_> = preds2.iter().map(|p| tcx.anonymize_bound_vars(p.kind())).collect();

    for p1 in preds1 {
        let mut found = false;
        for i in 0..preds2.len() {
            if p1 == preds2[i] {
                preds2.remove(i);
                found = true;
                break;
            }
        }
        if !found {
            return false;
        }
    }
    return true;
}

fn all_predicates<'tcx>(
    tcx: TyCtxt<'tcx>,
    id: rustc_span::def_id::DefId,
    substs: GenericArgsRef<'tcx>,
    preliminarily_try_to_process_and_eliminate_trait_aliases: bool,
) -> Vec<Clause<'tcx>> {
    let mut trait_alias_clauses: Vec<Clause<'tcx>> = Vec::new();
    let preds = tcx.clauses_of(id);
    if preliminarily_try_to_process_and_eliminate_trait_aliases {
        // raw_ptr.rs uses external_fn_specification for functions with core::ptr::Thin bounds,
        // where core::ptr::Thin is a trait alias (an experimental Rust feature)
        // to core::ptr::Pointee<Metadata = ()>
        // We don't support trait aliases yet.
        // However, to get this case to work, we attempt to expand away trait aliases unto
        // their underlying traits here.
        // This is not fully general and probably doesn't yet work for parameterized trait aliases.
        for (p, _) in preds.clauses {
            match p.kind().skip_binder() {
                rustc_middle::ty::ClauseKind::<'tcx>::Trait(tp) => {
                    if tcx.trait_is_alias(tp.trait_ref.def_id) {
                        let preds = tcx.clauses_of(tp.trait_ref.def_id);
                        let alias_typing_env = TypingEnv::post_analysis(tcx, tp.trait_ref.def_id);
                        trait_alias_clauses.extend(
                            preds
                                .instantiate(tcx, substs)
                                .into_iter()
                                .map(|(p, _)| tcx.normalize_erasing_regions(alias_typing_env, p)),
                        );
                    }
                }
                _ => {}
            }
        }
    }
    let typing_env = TypingEnv::post_analysis(tcx, id);
    let preds = preds.instantiate(tcx, substs);
    let mut clauses: Vec<Clause<'tcx>> = preds
        .clauses
        .into_iter()
        .map(|clause| tcx.normalize_erasing_regions(typing_env, clause))
        .collect();
    if preliminarily_try_to_process_and_eliminate_trait_aliases {
        clauses.retain(|clause| match clause.kind().skip_binder() {
            rustc_middle::ty::ClauseKind::<'tcx>::Trait(tp) => {
                !tcx.trait_is_alias(tp.trait_ref.def_id)
            }
            _ => true,
        });
    }
    clauses.extend(trait_alias_clauses);
    clauses
}

fn get_external_def_id<'tcx>(
    ctxt: &Context<'tcx>,
    proxy_fun_id: DefId,
    body_id: &BodyId,
    body: &Body<'tcx>,
    sig: &FnOrConstSig<'tcx>,
) -> Result<(rustc_span::def_id::DefId, FunctionKind, bool), VirErr> {
    let tcx = ctxt.tcx;

    let err = || {
        err_span(
            sig.span,
            format!("assume_specification encoding error: body should end in call expression"),
        )
    };

    let async_function_err = || {
        err_span(
            sig.span,
            format!(
                "assume_specification encoding error: async function body should end in await to a call expression"
            ),
        )
    };

    let body_expr = if sig.asyncness().is_async() {
        extract_desugared_async_body(ctxt, body)?
    } else {
        &body.value
    };

    // Get the 'body' of this function (skipping over header and unsafe-block if necessary)
    let expr = match &body_expr.kind {
        ExprKind::Block(block_body, _) => match &block_body.expr {
            Some(body_value) => body_value,
            None => {
                return err();
            }
        },
        _ => body_expr,
    };
    let expr = match &expr.kind {
        ExprKind::Block(block_body, _) => match &block_body.expr {
            Some(body_value) => body_value,
            None => {
                return err();
            }
        },
        _ => &expr,
    };

    let expr = if sig.asyncness().is_async() {
        match &expr.kind {
            ExprKind::Match(
                Expr { hir_id: _, kind: ExprKind::Call(_expr, call_args), span: _ },
                _arms,
                rustc_hir::MatchSource::AwaitDesugar,
            ) => &call_args[0],
            _ => {
                return async_function_err();
            }
        }
    } else {
        expr
    };

    let types = body_id_to_types(tcx, body_id);

    let (external_id, hir_id, is_const) = match &expr.kind {
        ExprKind::Call(fun, _args) => match &fun.kind {
            ExprKind::Path(qpath) => {
                let def = types.qpath_res(&qpath, fun.hir_id);
                match def {
                    rustc_hir::def::Res::Def(_, def_id) => {
                        // We don't need to check the args match or anything,
                        // the type signature check done by the handle_external_fn
                        // is sufficient.
                        (def_id, fun.hir_id, false)
                    }
                    _ => {
                        return err();
                    }
                }
            }
            _ => {
                return err();
            }
        },
        ExprKind::MethodCall(_name_and_generics, _receiver, _other_args, _fn_span) => {
            // TODO maybe deprecate this; it isn't used with the new
            // 'assume_specification' style
            let def_id =
                types.type_dependent_def_id(expr.hir_id).expect("def id of the method definition");
            (def_id, expr.hir_id, false)
        }
        ExprKind::Path(qpath) => {
            use rustc_hir::def::{DefKind, Res};
            let res = types.qpath_res(&qpath, expr.hir_id);
            if let Res::Def(DefKind::Const { .. }, def_id) = res {
                (def_id, expr.hir_id, true)
            } else if let Res::Def(DefKind::AssocConst { .. }, def_id) = res {
                (def_id, expr.hir_id, true)
            } else {
                return err();
            }
        }
        _ => {
            return err();
        }
    };

    if let Some(trait_def_id) = tcx.trait_of_assoc(external_id) {
        // If this is a trait function, then the DefId we have right now points to
        // function definition in the trait definition.
        // We want to resolve to a specific definition in a trait implementation.
        let node_substs = types.node_args(hir_id);
        let typing_env = TypingEnv::post_analysis(tcx, proxy_fun_id);

        let resolution = crate::resolve_traits::resolve_trait_item(
            sig.span,
            tcx,
            typing_env,
            external_id,
            node_substs,
        )?;

        match resolution {
            ResolutionResult::Unresolved => err_span(
                sig.span,
                "assume_specification cannot be used to specify generic specifications of trait methods; consider using external_trait_specification instead",
            ),
            ResolutionResult::Builtin(b) => err_span(
                sig.span,
                format!(
                    "Verus assume_specification does not support this verus_builtin impl '{:?}'",
                    b
                ),
            ),
            ResolutionResult::Resolved { resolved_item: ResolvedItem::FromTrait(..), .. } => {
                unsupported_err!(sig.span, "assume_specification for a provided trait method");
            }
            ResolutionResult::Resolved {
                impl_def_id,
                impl_args,
                impl_item_args: _,
                resolved_item: ResolvedItem::FromImpl(impl_item_id, _args),
            } => {
                let trait_path = ctxt.def_id_to_vir_path(trait_def_id);

                let mut types: Vec<Typ> = vec![];

                let trait_ref = tcx.impl_trait_ref(impl_def_id);
                let trait_ref = tcx.normalize_erasing_regions(
                    TypingEnv::post_analysis(tcx, impl_item_id),
                    trait_ref.instantiate(tcx, impl_args),
                );

                for ty in trait_ref.args.types() {
                    types.push(ctxt.mid_ty_to_vir(impl_item_id, sig.span, &ty, None)?);
                }

                let kind = FunctionKind::ForeignTraitMethodImpl {
                    method: Arc::new(FunX { path: ctxt.def_id_to_vir_path(external_id) }),
                    impl_path: ctxt.def_id_to_vir_path(impl_def_id),
                    trait_path: trait_path,
                    trait_typ_args: Arc::new(types),
                };
                Ok((impl_item_id, kind, is_const))
            }
        }
    } else {
        Ok((external_id, FunctionKind::Static, is_const))
    }
}

pub(crate) fn check_item_const_or_static<'tcx>(
    ctxt: &Context<'tcx>,
    state: &mut State,
    infos: &mut Vec<FunctionOrConstInfo>,
    span: Span,
    id: DefId,
    visibility: vir::ast::Visibility,
    module_path: &vir::ast::Path,
    attrs: &[Attribute],
    typ: &Typ,
    body_id: &BodyId,
    is_static: bool,
    self_generics: Option<(&'tcx Generics, DefId)>,
) -> Result<Fun, VirErr> {
    let mut path = ctxt.def_id_to_vir_path(id);

    let vattrs = ctxt.get_verifier_attrs(attrs)?;
    if vattrs.unerased_proxy {
        path = fixup_unerased_proxy_path(&path, span)?;
    }

    let name = Arc::new(FunX { path: path.clone() });

    let is_async = ctxt.tcx.asyncness(id).is_async();
    assert!(!is_async);

    let mode_opt = crate::attributes::get_mode_opt(attrs);
    let (func_mode, body_mode, ret_mode) = if is_static {
        // All statics are exec
        // For consistency with const, require the user to mark it 'exec' explicitly
        match mode_opt {
            None => {
                return err_span(
                    span,
                    "explicitly mark the static as `exec` and use an `ensures` clause",
                );
            }
            Some(m) => {
                if m != Mode::Exec {
                    return err_span(span, "a static item can only have mode `exec`");
                }
            }
        }
        (Mode::Exec, Mode::Exec, Mode::Exec)
    } else {
        match mode_opt {
            // Anonymous constants are evaluated in executable Rust contexts.
            None if matches!(ctxt.tcx.def_kind(id), rustc_hir::def::DefKind::AnonConst) => {
                (Mode::Exec, Mode::Exec, Mode::Exec)
            }
            // By default, a named const is dual-use as spec and exec,
            // where the function is considered spec but the return value and body are exec:
            None => (Mode::Spec, Mode::Exec, Mode::Exec),
            // Otherwise, a const is a single-mode function:
            Some(m) => (m, m, m),
        }
    };

    if vattrs.external_fn_specification {
        return err_span(span, "use `external_fn_specification` on fn whose body is a const");
    }

    let ret_name = air_unique_var(RETURN_VALUE);
    let outer_ret = ctxt.spanned_new(
        span,
        ParamX {
            name: ret_name,
            typ: typ.clone(),
            mode: ret_mode,
            user_mut: false,
            unwrapped_info: None,
        },
    );
    let fattrs = make_attributes(
        ctxt,
        id,
        &vattrs,
        false,
        false,
        false,
        Safety::Safe,
        is_async,
        span,
        false,
        false,
    )?;

    let pre_header = get_pre_header(ctxt, &[], &CheckItemFnEither::BodyId(body_id), is_async)?;

    let (body_visibility, opaqueness) = get_body_visibility_and_fuel(
        span,
        &visibility,
        vattrs.publish,
        &pre_header.open_visibility_qualifier,
        vattrs.opaque,
        vattrs.opaque_outside_module,
        func_mode,
        module_path,
        !vattrs.external_body,
    )?;

    ctxt.push_body_erasure(
        id.expect_local(),
        BodyErasure { erase_body: body_mode == Mode::Spec, ret_spec: ret_mode == Mode::Spec },
    );

    // An associated const declared in an `impl<T> ...` block may refer to the impl's
    // type parameters in its type or body, so include them here.
    let (typ_params, typ_bounds) = if let Some((cg, impl_def_id)) = self_generics {
        check_generics_bounds_no_polarity(
            ctxt.tcx,
            &ctxt.verus_items,
            cg.span,
            Some(cg),
            impl_def_id,
            Some(&mut *ctxt.diagnostics.borrow_mut()),
        )?
    } else {
        (Arc::new(vec![]), Arc::new(vec![]))
    };

    let mut functionx = FunctionStubX {
        name: name.clone(),
        proxy: None,
        kind: FunctionKind::Static,
        visibility,
        body_visibility,
        opaqueness,
        owning_module: Some(module_path.clone()),
        mode: func_mode,
        typ_params,
        typ_bounds,
        params: Arc::new(vec![]),
        outer_ret,
        item_kind: if is_static { ItemKind::Static } else { ItemKind::Const },
        attrs: fattrs,
        decreases_len: pre_header.decreases_len,
        returns: pre_header.returns,
    };

    let autospec = handle_autospec(ctxt, span, id, &vattrs, &functionx)?;
    if autospec.redirect_to.is_some() {
        Arc::make_mut(&mut functionx.attrs).autospec = autospec.redirect_to.clone();
    }

    let function = ctxt.spanned_new(span, functionx);
    state.insert_fun_warn_config(ctxt, &function.x.name, id);

    if let Some(f) = &autospec.new_func {
        state.insert_fun_warn_config(ctxt, &f.x.name, id);
    }

    infos.push(FunctionOrConstInfo::Const(ConstInfo {
        function: function,
        function_for_autospec: autospec.new_func,
        pre_header,
        def_id: id,
        body_id: *body_id,
        vattrs,
        span,
        body_mode,
        ret_mode,
        func_mode,
        is_static,
    }));

    Ok(name)
}

pub(crate) fn finish_const_or_static<'tcx>(
    ctxt: &Context<'tcx>,
    const_info: &ConstInfo,
    functions: &mut Vec<vir::ast::Function>,
) -> Result<(), VirErr> {
    let ConstInfo {
        ref function,
        ref function_for_autospec,
        ref pre_header,
        body_id,
        def_id: id,
        ref vattrs,
        span,
        body_mode,
        ret_mode,
        func_mode,
        is_static,
    } = *const_info;
    let vir::ast::FunctionStubX {
        name,
        proxy,
        kind,
        visibility,
        body_visibility,
        opaqueness,
        owning_module,
        mode,
        typ_params,
        typ_bounds,
        params,
        outer_ret,
        item_kind,
        attrs,
        decreases_len,
        returns: has_returns,
    } = function.x.clone();

    let body = find_body(ctxt, &body_id);
    let (mut vir_body, _) = body_to_vir(
        ctxt,
        id,
        &body_id,
        body,
        body_mode,
        vattrs.external_body,
        &None,
        None,
        &[],
        None,
        false,
    )?;
    let header = vir::headers::read_header(
        &mut vir_body,
        &vir::headers::HeaderAllows::Some(vec![vir::headers::HeaderAllow::Ensure]),
    )?;
    crate::pre_header::sanity_check_preheader(span, &header, &pre_header)?;
    if header.require.len() + header.recommend.len() > 0 {
        return err_span(span, "consts cannot have requires/recommends");
    }

    let spec_or_dual = ret_mode == Mode::Spec || func_mode == Mode::Spec;
    if spec_or_dual && (header.ensure.0.len() > 0 || header.ensure.1.len() > 0) {
        return err_span(span, "const cannot have `ensures` unless it is `exec const`");
    }
    if spec_or_dual && header.returns.is_some() {
        return err_span(span, "const cannot have `returns` unless it is `exec const`");
    }

    if !is_static
        && body_mode == Mode::Exec
        && !vattrs.external_body
        && header.ensure.0.is_empty()
        && header.ensure.1.is_empty()
        && header.returns.is_none()
    {
        if let Some(value) = crate::native_const::scalar(ctxt, id) {
            vir_body =
                ctxt.spanned_typed_new(span, &outer_ret.x.typ, vir::ast::ExprX::Const(value));
        }
    }

    let inner_ret = outer_ret.clone();
    let ensure = clean_ensures_for_unit_return(
        ctxt,
        &inner_ret,
        &header.const_static_ensures(&name, is_static),
    );

    let functionx = FunctionX {
        name,
        proxy,
        kind,
        visibility,
        body_visibility,
        opaqueness,
        owning_module,
        mode,
        typ_params,
        typ_bounds,
        params,
        inner_ret,
        outer_ret,
        require: Arc::new(vec![]),
        ensure: (ensure, Arc::new(vec![])),
        returns: None,
        decrease: Arc::new(vec![]),
        decrease_when: None,
        decrease_by: None,
        fndef_axioms: None,
        mask_spec: None,
        atomic_update: None,
        unwind_spec: None,
        item_kind,
        attrs,
        body: if vattrs.external_body { None } else { Some(vir_body) },
        return_opaque_type_eqs: Arc::new(vec![]),
        extra_dependencies: vec![],
        hidden: Arc::new(header.hidden.clone()),
    };

    assert!(functionx.returns.is_some() == has_returns);
    assert!(functionx.decrease.len() == decreases_len);

    let function = ctxt.spanned_new(span, functionx);

    functions.push(function.clone());
    if let Some(f) = &function_for_autospec {
        functions.push(finish_autospec(span, &function, f)?);
    }

    Ok(())
}

pub(crate) fn check_foreign_item_fn<'tcx>(
    ctxt: &Context<'tcx>,
    state: &mut State,
    infos: &mut Vec<FunctionOrConstInfo<'tcx>>,
    id: DefId,
    span: Span,
    visibility: vir::ast::Visibility,
    attrs: &[Attribute],
    decl: &'tcx FnDecl<'tcx>,
    idents: &[&Ident],
    generics: &'tcx Generics,
) -> Result<(), VirErr> {
    let vattrs = ctxt.get_verifier_attrs(attrs)?;

    let path = ctxt.def_id_to_vir_path(id);
    let name = Arc::new(FunX { path });

    if vattrs.external_fn_specification {
        return err_span(span, "assume_specification not supported here");
    }

    let mode = get_mode(Mode::Exec, attrs);

    let fn_sig = ctxt.tcx.fn_sig(id);
    // REVIEW: rustc docs refer to skip_binder as "dangerous"
    let fn_sig = fn_sig.skip_binder();
    let inputs = fn_sig.inputs().skip_binder();

    let ret_typ_mode =
        check_fn_decl(span, ctxt, id, decl, attrs, mode, fn_sig.output().skip_binder(), None)?;
    let (typ_params, typ_bounds) = check_generics_bounds_no_polarity(
        ctxt.tcx,
        &ctxt.verus_items,
        generics.span,
        Some(generics),
        id,
        Some(&mut *ctxt.diagnostics.borrow_mut()),
    )?;
    let mut vir_params: Vec<vir::ast::Param> = Vec::new();

    assert!(idents.len() == inputs.len());
    for (i, (param, input)) in idents.iter().zip(inputs.iter()).enumerate() {
        let name = no_body_param_to_var(param, i);
        let typ = ctxt.mid_ty_to_vir(id, param.span, input, None)?;
        // REVIEW: the parameters don't have attributes, so we use the overall mode
        let vir_param = ctxt.spanned_new(
            param.span,
            ParamX { name, typ, mode, unwrapped_info: None, user_mut: false },
        );
        vir_params.push(vir_param);
    }
    let params = Arc::new(vir_params);
    let (ret_typ, ret_mode) = match ret_typ_mode {
        None => (unit_typ(), mode),
        Some((typ, mode)) => (typ, mode),
    };
    let ret_param = ParamX {
        name: air_unique_var(RETURN_VALUE),
        typ: ret_typ,
        mode: ret_mode,
        user_mut: false,
        unwrapped_info: None,
    };
    let ret = ctxt.spanned_new(span, ret_param);

    // No body, so these don't matter
    let body_visibility = vir::ast::BodyVisibility::Visibility(visibility.clone());
    let opaqueness = Opaqueness::Opaque;

    if !vattrs.external_body {
        return Err(err_span_bare(span, "extern function cannot be checked")
            .help("to tell Verus to trust this function, either mark this function `#[verifier::external_body]` and use an empty specification; or mark it `#[verifier::external]` and use `assume_specification` to provide a spec"));
    }

    let func = FunctionX {
        name,
        proxy: None,
        kind: FunctionKind::Static,
        visibility,
        body_visibility,
        opaqueness,
        owning_module: None,
        mode,
        typ_params,
        typ_bounds,
        params,
        outer_ret: ret.clone(),
        inner_ret: ret,
        require: Arc::new(vec![]),
        ensure: (Arc::new(vec![]), Arc::new(vec![])),
        returns: None,
        decrease: Arc::new(vec![]),
        decrease_when: None,
        decrease_by: None,
        fndef_axioms: None,
        mask_spec: None,
        atomic_update: None,
        unwind_spec: None,
        item_kind: ItemKind::Function,
        attrs: Default::default(),
        body: None,
        return_opaque_type_eqs: Arc::new(vec![]),
        extra_dependencies: vec![],
        hidden: Arc::new(vec![]),
    };
    let function = ctxt.spanned_new(span, func);
    state.insert_fun_warn_config(ctxt, &function.x.name, id);

    infos.push(FunctionOrConstInfo::ForeignFunction(ForeignFunctionInfo {
        function_full: function.clone(),
        function_stub: vir::ast_util::function_to_stub(&function),
    }));

    Ok(())
}

fn get_body_visibility_and_fuel(
    span: Span,
    func_visibility: &Visibility,
    publish: Option<AttrPublish>,
    open_visibility_qualifier: &Option<Visibility>,
    opaque: bool,
    opaque_outside_module: bool,
    mode: Mode,
    my_module: &vir::ast::Path,
    has_body: bool,
) -> Result<(BodyVisibility, Opaqueness), VirErr> {
    let private_vis = Visibility { restricted_to: Some(my_module.clone()) };

    if open_visibility_qualifier.is_some() && publish != Some(AttrPublish::Open) {
        crate::internal_err!(
            span,
            "found 'open_visibility_qualifier' declaration but no 'publish' attribute"
        )
    }

    if mode != Mode::Spec {
        if publish == Some(AttrPublish::Open) {
            return err_span(span, "function is marked `open` but it is not a `spec` function");
        }
        if publish == Some(AttrPublish::Closed) {
            return err_span(span, "function is marked `closed` but it is not a `spec` function");
        }
        if opaque || opaque_outside_module {
            return err_span(span, "function is marked `opaque` but it is not a `spec` function");
        }

        // These don't matter for non-spec functions
        Ok((BodyVisibility::Visibility(private_vis), Opaqueness::Opaque))
    } else if !has_body {
        if opaque || opaque_outside_module {
            return err_span(span, "opaque has no effect on a function without a body");
        }

        if publish == Some(AttrPublish::Uninterp) {
            Ok((BodyVisibility::Uninterpreted, Opaqueness::Opaque))
        } else {
            // These don't matter without a body
            Ok((BodyVisibility::Visibility(private_vis), Opaqueness::Opaque))
        }
    } else {
        // mode == Mode::Spec && has_body
        if publish == Some(AttrPublish::Uninterp) {
            return err_span(span, "function is marked `uninterp` but it has a body");
        }

        if opaque && opaque_outside_module {
            return err_span(span, "function is marked both 'opaque' and 'opaque_outside_module'");
        }

        if publish == Some(AttrPublish::Open) && func_visibility == &private_vis {
            return err_span(
                span,
                "function is marked `open` but not marked `pub`; for the body of a function to be visible, the function symbol must also be visible",
            );
        }

        if let Some(vis) = open_visibility_qualifier {
            if !vis.at_least_as_restrictive_as(&func_visibility) {
                return err_span(
                    span,
                    "the function body is declared 'open' to a wider scope than the function itself",
                );
            }
        }

        let body_visibility = if publish == Some(AttrPublish::Open) {
            match open_visibility_qualifier {
                None => func_visibility.clone(),
                Some(vis) => vis.clone(),
            }
        } else {
            private_vis.clone()
        };

        let opaqueness = if opaque {
            Opaqueness::Opaque
        } else if opaque_outside_module {
            Opaqueness::Revealed { visibility: private_vis }
        } else {
            Opaqueness::Revealed {
                // Revealed everywhere the module is visible
                visibility: body_visibility.clone(),
            }
        };

        Ok((BodyVisibility::Visibility(body_visibility), opaqueness))
    }
}

/// If the function has a unit return type, then we will elide the return value
/// in the AIR encoding later (e.g., in the %ens functions). However, it is still
/// possible that the user refers to the unit return value by name, e.g.,
/// ```
/// fn example() -> (ret: ())
///     ensures ret == (),
/// ```
/// Therefore, we substitute out the name here so it be safely elided.
pub fn clean_ensures_for_unit_return<'tcx>(
    ctxt: &Context<'tcx>,
    inner_ret: &vir::ast::Param,
    ensure: &vir::ast::Exprs,
) -> vir::ast::Exprs {
    match &*vir::ast_util::undecorate_typ(&inner_ret.x.typ) {
        TypX::Datatype(vir::ast::Dt::Tuple(0), ..) => {
            if inner_ret.x.name == air_unique_var(vir::def::RETURN_VALUE) {
                ensure.clone()
            } else {
                let mut es = vec![];
                for e in ensure.iter() {
                    let e1 = vir::ast_visitor::map_expr_place_visitor(
                        e,
                        &|expr| match &expr.x {
                            vir::ast::ExprX::Var(ident) if ident == &inner_ret.x.name => {
                                assert!(vir::ast_util::is_unit(&vir::ast_util::undecorate_typ(
                                    &expr.typ
                                )));
                                ctxt.erasure_info
                                    .borrow_mut()
                                    .extra_erase_ast_ids
                                    .push(expr.span.clone());
                                Ok(vir::ast_util::mk_tuple(&expr.span, &Arc::new(vec![])))
                            }
                            _ => Ok(expr.clone()),
                        },
                        &|place| match &place.x {
                            vir::ast::PlaceX::Local(ident) if ident == &inner_ret.x.name => {
                                assert!(vir::ast_util::is_unit(&vir::ast_util::undecorate_typ(
                                    &place.typ
                                )));
                                ctxt.erasure_info
                                    .borrow_mut()
                                    .extra_erase_ast_ids
                                    .push(place.span.clone());
                                let e = vir::ast_util::mk_tuple(&place.span, &Arc::new(vec![]));
                                Ok(ctxt.spanned_typed_new_vir(
                                    &place.span,
                                    &place.typ,
                                    vir::ast::PlaceX::Temporary(e),
                                ))
                            }
                            _ => Ok(place.clone()),
                        },
                    )
                    .unwrap();
                    es.push(e1);
                }
                Arc::new(es)
            }
        }
        _ => ensure.clone(),
    }
}

fn get_async_inner_return_typ<'tcx>(
    ctxt: &Context<'tcx>,
    span: Span,
    def_id: DefId,
    body_id: &CheckItemFnEither<BodyId, ()>,
) -> Result<vir::ast::Typ, VirErr> {
    let ty = get_async_inner_return_ty(ctxt, span, def_id, body_id)?;
    ctxt.mid_ty_to_vir(def_id, span, &ty, None)
}

/// Given an async function `async fn(...) -> X` which de-sugars to
/// `fn(...) -> impl Future<Output=X>`
/// this functionrecovers the type `X`.
fn get_async_inner_return_ty<'tcx>(
    ctxt: &Context<'tcx>,
    span: Span,
    def_id: DefId,
    _body_id: &CheckItemFnEither<BodyId, ()>,
) -> Result<rustc_middle::ty::Ty<'tcx>, VirErr> {
    let fn_sig = ctxt.tcx.fn_sig(def_id).skip_binder();
    let output = fn_sig.output().skip_binder();

    let rustc_middle::ty::TyKind::Alias(_, al_ty) = output.kind() else {
        crate::internal_err!(span, "get_async_inner_return_ty");
    };
    let alias_def_id = al_ty.kind.try_to_opaque().expect("alias kind");
    let typing_env = TypingEnv::non_body_analysis(ctxt.tcx, alias_def_id);
    let instantiated_bounds = ctxt.tcx.normalize_erasing_regions(
        typing_env,
        ctxt.tcx.item_bounds(alias_def_id).instantiate(ctxt.tcx, al_ty.args),
    );
    // We are looking for a ProjectionPredicate that <F as Future>::Output = X
    // where F is the opaque type.
    let ty_list = instantiated_bounds
        .iter()
        .filter_map(|clause| match clause.kind().skip_binder() {
            ClauseKind::Projection(pc) => match pc.projection_term.kind {
                AliasTermKind::ProjectionTy { def_id } => {
                    if Some(def_id) == ctxt.tcx.lang_items().future_output()
                        && pc.projection_term.args.len() == 1
                        && let rustc_middle::ty::TyKind::Alias(_, al_ty) = output.kind()
                        && al_ty.kind.try_to_opaque() == Some(alias_def_id)
                    {
                        Some(pc.term.expect_type())
                    } else {
                        None
                    }
                }
                _ => None,
            },
            _ => None,
        })
        .collect::<Vec<_>>();
    if ty_list.len() != 1 {
        crate::internal_err!(span, "get_async_inner_return_ty failed to find bound");
    }
    Ok(ty_list[0])
}
