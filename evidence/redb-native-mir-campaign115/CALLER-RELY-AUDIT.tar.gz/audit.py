from pathlib import Path
import datetime
import hashlib
import json
import sys

ROOT = Path('/private/tmp/redb-header-caller-audit115-20261108T160609Z')
PARENT = Path('/Users/tommyvolk/.t3/worktrees/verus/t3-60978068')
RECOVERY = Path('/private/tmp/verus-crash-consistency94-20261105/native-leaf-lookup-007')
NATIVE = RECOVERY / 'recovered-native/redb'
EVIDENCE = [
    'evidence/redb-native-mir-campaign115/AUTHORIZATION.md',
    'evidence/redb-native-mir-campaign115/PLAN.md',
    'evidence/redb-native-mir-campaign115/GOAL-CONTINUATION.md',
    'evidence/redb-native-mir-campaign115/ENTRY-PARENT-INPUTS.json',
    'evidence/redb-writablepage-lifecycle113/B-SOURCE-REVIEW.md',
    'evidence/redb-writablepage-lifecycle113/CORRESPONDENCE-CUTS.md',
    'evidence/redb-writablepage-lifecycle113/ENTRY-INPUTS.json',
    'evidence/redb-header-recovery111/NATIVE-LINKAGE-SOURCE.json',
    'evidence/redb-native-frontier112/DECISION-AUTHENTICATION.json',
]


def identity(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def patch(name, content):
    print('*** Begin Patch')
    print('*** Add File: ' + str(ROOT / name))
    for line in content.splitlines():
        print('+' + line)
    print('*** End Patch')


def collect():
    files = sorted((NATIVE / 'src').rglob('*.rs'))
    files += [path for path in [NATIVE / 'Cargo.toml', NATIVE / 'Cargo.lock', NATIVE / 'build.rs'] if path.exists()]
    files += [PARENT / name for name in EVIDENCE]
    files += [RECOVERY / 'recovery.json', RECOVERY / 'MANIFEST.json']
    records = [identity(path) for path in files]
    recovery = json.loads((RECOVERY / 'recovery.json').read_text())
    return {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'first_clock_utc': '2026-11-08T16:06:09Z', 'first_read_or_atomic_snapshot': False, 'records': records, 'recovery_redb': recovery['repositories']['redb'], 'recovery_original_path_preservation': recovery['original_path_preservation']}


if __name__ != '__main__':
    pass
elif sys.argv[1] == 'entry':
    patch('entry-identities.json', json.dumps(collect(), indent=2))
elif sys.argv[1] == 'ranges':
    path = NATIVE / 'src' / sys.argv[2]
    lines = path.read_text().splitlines()
    print('SOURCE', path)
    for span in sys.argv[3:]:
        start, end = map(int, span.split(':'))
        for number in range(start, end + 1):
            print(f'{number}: {lines[number - 1]}')
elif sys.argv[1] == 'search':
    import re
    expression = re.compile(sys.argv[2])
    for path in sorted((NATIVE / 'src').rglob('*.rs')):
        for number, line in enumerate(path.read_text().splitlines(), 1):
            if expression.search(line):
                print(f'{path.relative_to(NATIVE / "src")}:{number}:{line}')
elif sys.argv[1] == 'authenticate':
    entry = json.loads((ROOT / 'entry-identities.json').read_text())
    bindings = entry['recovery_redb']['blobs']
    result = []
    for record in entry['records']:
        path = Path(record['path'])
        if not path.is_relative_to(NATIVE):
            continue
        relative = str(path.relative_to(NATIVE))
        expected = bindings.get(relative)
        data = path.read_bytes()
        blob = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
        result.append({'path': str(path), 'expected': expected, 'actual_sha256': record['sha256'], 'actual_git_blob': blob, 'matches': expected is not None and expected['sha256'] == record['sha256'] and expected['git_blob'] == blob})
    prior = json.loads((PARENT / 'evidence/redb-writablepage-lifecycle113/ENTRY-INPUTS.json').read_text())
    lookup = {record['path']: record for record in prior['records']}
    historical = [{'path': record['path'], 'matches': lookup[record['path']]['sha256'] == record['sha256'], 'pin': lookup[record['path']]['sha256']} for record in entry['records'] if record['path'] in lookup and str(NATIVE) in record['path']]
    patch('pin-authentication.json', json.dumps({'recovered_revision_pin': entry['recovery_redb']['pin'], 'recovery_records': result, 'prior_113_records': historical, 'original_path_preservation': 'FAILED_MISSING_FILES_NOT_ATTRIBUTED', 'git_continuity': 'UNAVAILABLE; content SHA-1 binding is not restored Git history', 'new_trust': False}, indent=2))
elif sys.argv[1] == 'excerpts':
    selections = {
        'tree_store/page_store/page_manager.rs': [(40, 60), (195, 260), (290, 301), (532, 690), (841, 925), (952, 979), (1001, 1029), (1105, 1143), (1185, 1261), (1264, 1296), (1327, 1479), (1617, 1645), (1796, 1919), (1922, 1996), (2036, 2044), (2056, 2098), (2255, 2285), (2320, 2332), (2355, 2425), (2486, 2516), (2923, 2965)],
        'tree_store/page_store/cached_file.rs': [(17, 122), (124, 267), (279, 335), (338, 375), (400, 460), (461, 978)],
        'tree_store/page_store/lru_cache.rs': [(1, 115)],
        'tree_store/page_store/fast_hash.rs': [(1, 55)],
        'tree_store/page_store/base.rs': [(17, 108), (142, 161), (242, 290)],
        'tree_store/page_store/header.rs': [(121, 191), (274, 303), (480, 516), (599, 626)],
        'tree_store/page_store/layout.rs': [(1, 71), (202, 225)],
        'db.rs': [(69, 98), (431, 545), (558, 578), (765, 783), (798, 804), (865, 1020), (1098, 1165), (1408, 1453), (1560, 1586), (1595, 1653), (1700, 1725), (1750, 1785), (1787, 1839), (1845, 1969), (2024, 2050), (2052, 2127), (2211, 2224)],
        'transaction_tracker.rs': [(183, 208), (252, 353), (480, 503)],
        'transactions.rs': [(898, 1008), (1752, 1780), (2015, 2065), (2135, 2147), (2717, 2765)],
        'tree_store/page_store/savepoint.rs': [(76, 96)],
        'tree_store/table_tree.rs': [(808, 815)],
        'sync.rs': [(1, 38), (75, 103), (149, 167)],
        'lib.rs': [(115, 132)],
        'tree_store/mod.rs': [(1, 30)],
        'tree_store/page_store/mod.rs': [(1, 58)],
    }
    identities = {record['path']: record for record in json.loads((ROOT / 'entry-identities.json').read_text())['records']}
    excerpts = []
    for relative, ranges in selections.items():
        path = NATIVE / 'src' / relative
        data = path.read_bytes()
        lines = data.decode().splitlines(keepends=True)
        for start, end in ranges:
            end = min(end, len(lines))
            text = ''.join(lines[start - 1:end])
            excerpts.append({'source': str(path), 'file_sha256': identities[str(path)]['sha256'], 'start_line': start, 'end_line_inclusive': end, 'exact_text': text, 'excerpt_sha256': hashlib.sha256(text.encode()).hexdigest()})
    patch('native-excerpts.json', json.dumps({'schema': 'redb-source-excerpts-v1', 'line_numbering': 'one-based inclusive; exact_text keeps original newlines', 'excerpts': excerpts}, indent=2))
elif sys.argv[1] == 'index':
    import re
    expression = re.compile(r'HeaderGuard|HeaderHold|WriterLock|PagedCachedFile|write_header\(|\.flush\(|\.resize\(|invalidate_cache|discard_write_buffer|cancel_pending_write|\.write\(0,|read_direct\(0,|write_direct\(0,|write_slot|defer_close|rollback_growth|fn get_memory|fn register_read_transaction|fn xxh3_checksum|\.get_page\(|\.get_page_mut\(')
    matches = []
    for path in sorted((NATIVE / 'src').rglob('*.rs')):
        for number, line in enumerate(path.read_text().splitlines(), 1):
            if expression.search(line):
                matches.append({'source': str(path), 'line': number, 'text': line})
    patch('native-call-index.json', json.dumps({'regex': expression.pattern, 'scope': 'all recovered src/**/*.rs, including cfg(test); index is lexical, not a proven call graph', 'matches': matches}, indent=2))
