import datetime
import hashlib
import json
import os
import sys
from pathlib import Path
from audit import ROOT, identity, patch

phase = sys.argv[1]
now = datetime.datetime.now(datetime.timezone.utc)
first = datetime.datetime.fromisoformat('2026-11-08T16:06:09+00:00')

if phase == 'exit':
    entry = json.loads((ROOT / 'entry-identities.json').read_text())
    comparisons = []
    for record in entry['records']:
        try:
            actual = identity(Path(record['path']))
            comparisons.append({'entry': record, 'exit': actual, 'matches': actual == record})
        except OSError as failure:
            comparisons.append({'entry': record, 'matches': False, 'error': str(failure)})
    patch('exit-identities.json', json.dumps({'utc': now.isoformat(), 'atomic_snapshot': False, 'comparisons': comparisons, 'matches': sum(record['matches'] for record in comparisons), 'mismatches': [record for record in comparisons if not record['matches']]}, indent=2))
elif phase == 'check':
    checks = []
    parsed = {}
    for path in sorted(ROOT.glob('*.json')):
        try:
            parsed[path.name] = json.loads(path.read_text())
            checks.append({'artifact': path.name, 'json_parses': True})
        except ValueError as failure:
            checks.append({'artifact': path.name, 'json_parses': False, 'error': str(failure)})
    excerpts = parsed['native-excerpts.json']['excerpts']
    mismatches = []
    for excerpt in excerpts:
        data = Path(excerpt['source']).read_bytes()
        lines = data.decode().splitlines(keepends=True)
        actual = ''.join(lines[excerpt['start_line'] - 1:excerpt['end_line_inclusive']])
        if actual != excerpt['exact_text'] or hashlib.sha256(data).hexdigest() != excerpt['file_sha256'] or hashlib.sha256(actual.encode()).hexdigest() != excerpt['excerpt_sha256']:
            mismatches.append({'source': excerpt['source'], 'line': excerpt['start_line']})
    result = {'utc': now.isoformat(), 'kind': 'artifact/source-integrity validation only; not tests or native execution', 'json_checks': checks, 'excerpts': len(excerpts), 'excerpt_mismatches': mismatches, 'interference_families': len(parsed['interference-table.json']['entrypoints']), 'header_calls': len(parsed['header-callers.json']['callers']), 'entry_exit_mismatches': parsed['exit-identities.json']['mismatches'], 'old_manifest_mismatches': [record for record in parsed['historical-manifest-check.json']['records'] if not record['matches']], 'recovery_pin_mismatches': [record for record in parsed['pin-authentication.json']['recovery_records'] if not record['matches']]}
    patch('PACKAGING-CHECK.json', json.dumps(result, indent=2))
elif phase == 'manifest':
    records = [identity(path) for path in sorted(ROOT.rglob('*')) if path.is_file() and path.name not in ['CONTENT-MANIFEST.json', 'SEAL.json']]
    patch('CONTENT-MANIFEST.json', json.dumps({'schema': 'redb-source-audit-content-v1', 'utc': now.isoformat(), 'records': records, 'self_reference_policy': 'Manifest excludes itself and SEAL; SEAL binds this manifest. No recursive self hash is claimed.'}, indent=2))
elif phase == 'seal':
    records = [identity(path) for path in sorted(ROOT.rglob('*')) if path.is_file()]
    stats = os.statvfs('/private/tmp')
    free = stats.f_bavail * stats.f_frsize
    elapsed = (now - first).total_seconds()
    used = sum(record['bytes'] for record in records)
    allocated = sum(path.stat().st_blocks * 512 for path in ROOT.rglob('*') if path.is_file())
    result = {'schema': 'redb-source-audit-seal-v1', 'first_clock_utc': first.isoformat(), 'seal_utc': now.isoformat(), 'elapsed_seconds_to_seal': elapsed, 'absolute_cutoff_utc': '2026-11-08T16:26:09Z', 'under_20_minutes_at_seal': elapsed < 1200, 'scratch_bytes_before_seal': used, 'scratch_allocated_bytes_before_seal': allocated, 'scratch_limit_bytes': 64 * 1024 * 1024, 'entry_free_bytes_df_sample': 59508124 * 1024, 'exit_free_bytes': free, 'free_disk_required_strictly_above_bytes': 16 * 1024 ** 3, 'exit_free_disk_pass': free > 16 * 1024 ** 3, 'disk_samples_not_continuous_enforcement': True, 'content_manifest': identity(ROOT / 'CONTENT-MANIFEST.json'), 'artifact_count_before_seal': len(records), 'writes': 'new scratch root only, through apply_patch', 'compiler_build_verifier_solver_native_application_executions': 0, 'semantic_tests_and_controls_executed': 0, 'network_requests': 0, 'delegations_or_worker_polls': 0, 'native_proof_credit': False, 'producer_or_trust_adoption': False, 'all18': 'OPEN'}
    text = json.dumps(result, indent=2)
    result['scratch_bytes_including_seal_upper_bound'] = used + len(text.encode()) + 256
    result['scratch_under_limit'] = result['scratch_bytes_including_seal_upper_bound'] < 64 * 1024 * 1024
    patch('SEAL.json', json.dumps(result, indent=2))
