#[path = "candidate/source/rust_verify/src/native_resource143/machine147.rs"]
mod machine147;
