#[path = "candidate/source/rust_verify/src/native_resource143/machine147.rs"]
mod machine147;

fn duplicate(handle: machine147::Handle) -> (machine147::Handle, machine147::Handle) {
    (handle, handle)
}

fn duplicate_loan(loan: machine147::SliceLoan) -> machine147::SliceLoan {
    loan.clone()
}

fn main() {}
