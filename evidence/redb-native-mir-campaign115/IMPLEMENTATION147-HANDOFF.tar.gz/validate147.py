import difflib
import json
from pathlib import Path
import re
import runner

ROOT = runner.ROOT
failures = []

def check(condition, message):
    if not condition:
        failures.append(message)

commands = json.loads((ROOT / 'commands.json').read_text())
receipts = {entry['name']: json.loads((ROOT / (entry['name']+'.receipt.json')).read_text())
            for entry in commands if (ROOT / (entry['name']+'.receipt.json')).exists()}
for name, receipt in receipts.items():
    check(receipt['owned_group_absent'], name+': process group still present')
    check(receipt['cause'] is None, name+': timeout/resource/driver failure')
    check(receipt['source_unchanged_during_command'] or receipt['kind'] == 'format', name+': unintended concurrent source change')
    check(receipt['before']['free'] > 16*1024**3 and receipt['after']['free'] > 16*1024**3, name+': disk floor')
    check(max(receipt['after']['logical'],receipt['after']['allocated']) <= 2*1024**3, name+': scratch bound')
    for stream in ('stdout','stderr'):
        check(runner.sha(ROOT/(name+'.'+stream)) == receipt[stream]['sha256'], name+': stream hash mismatch')

expected = {
    'build147-01':101,'build147-02':101,'build147-03':0,'original147-01':1,
    'build147-04':0,'original147-02':1,'build147-05':101,'build147-06':0,'original147-03':1,
    'unit147-build':0,'unit147-positive':0,'unit147-final-build':0,'unit147-final-positive':0,
    'mutant-bytes-build':0,'mutant-bytes-test':101,'mutant-root-build':0,'mutant-root-test':101,
    'mutant-suspension-build':0,'mutant-suspension-build-corrected':0,'mutant-suspension-test':101,
    'mutant-cleanup-build':0,'mutant-cleanup-test':101,'format147':0,
    'unit147-restored-build':0,'unit147-restored-test':0,'affine-compile-refusal':1,
    'build147-final':0,'original147-final':1,'feature-required-refusal':101,
}
for name,status in expected.items():
    check(name in receipts and receipts[name]['returncode'] == status, name+': unexpected/missing status')
check(len(commands) <= 32, 'charged allowance exceeded')

restored = (ROOT/'unit147-restored-test.stdout').read_text()
check('18 passed; 0 failed' in restored, 'final restored18 controls did not pass')
check(json.loads((ROOT/'source-restoration147.json').read_text())['exact_byte_restoration'], 'preformat restoration mismatch')
compile_errors = (ROOT/'affine-compile-refusal.stderr').read_text()
check('E0382' in compile_errors and 'E0599' in compile_errors, 'affine move/clone compile guards not exercised')
check('requires the features' in (ROOT/'feature-required-refusal.stderr').read_text(), 'feature refusal not attributable')

mutants = {}
original = (ROOT/'machine147.control-original.rs').read_text().splitlines(keepends=True)
patches = []
for mutant in ('bytes','root','suspension','cleanup'):
    source = ROOT/('machine147.mutant-'+mutant+'.rs')
    output = (ROOT/('mutant-'+mutant+'-test.stdout')).read_text()
    check('0 passed; 1 failed' in output, mutant+': intended targeted test did not fail')
    mutants[mutant] = dict(source_sha256=runner.sha(source),targeted_test_failed=True,scope='concrete-byte control machine only; not native semantic proof')
    patches += difflib.unified_diff(original,source.read_text().splitlines(keepends=True),
        fromfile='restored/machine147.rs',tofile='mutant-'+mutant+'/machine147.rs')
(ROOT/'control-mutations147.patch').write_text(''.join(patches))

native = json.loads((ROOT/'original147-final.json').read_text())
check(native['native_bodies_proved'] == 0 and native['laws_adopted'] == 0 and native['all18'] == 'OPEN', 'native credit unexpectedly changed')
check('NRE143_OPEN_NATIVE_PROOF_OBLIGATIONS' in (ROOT/'original147-final.stderr').read_text(), 'native export refusal missing')
check(not (ROOT/'original147-final.rmeta').exists(), 'unexpected native metadata export')
mem = next(body for name,body in native['bodies'].items() if name.endswith('WritablePage::mem_mut'))
header = next(body for name,body in native['bodies'].items() if name.endswith('TransactionalMemory::write_header'))
arc = mem['native_lowering']['Ok']['unadopted_byte_authority147']
check('Ok' in arc['arc_get_mut'], 'final exact Arc binding did not succeed')
check('Err(CheckedOriginalCheckoutAndBytes)' in str(arc['arc_get_mut']), 'missing checkout was credited')
check(all('Err' in item['result'] and 'BUG' not in str(item['result']) for item in arc['typed_mutants']), 'typed native mutant accepted')
check('Ok' in arc['restoration'], 'typed native restoration failed')
check('R146LiveHolderIncarnation' in arc['required_open_ports'] and 'R146GlobalOccurrenceAndBundleConsumption' in arc['required_open_ports'], '146 ports waived')
header_ports = header['native_lowering']['Ok']['unadopted_byte_authority147']
consumers = [item['Ok'] for item in header_ports['actual143_consumers'] if 'Ok' in item]
check(sum(item['kind']=='ByteMutation' for item in consumers)==2, 'header normal/unwind byte occurrences not both captured')
check(any('normal successor and exact NLL end' in item.get('edge','') for item in consumers), 'normal NLL consumer missing')
check(any('cleanup endpoint' in item.get('edge','') for item in consumers), 'cleanup NLL consumer missing')
check(all('REFUSED' in item['authority'] for item in consumers), 'native consumer credited missing authority')
check(runner.inventory(ROOT/'candidate') == json.loads((ROOT/'build147-final.source.json').read_text()), 'final candidate differs from final build')
check(runner.inventory(ROOT/'candidate') == json.loads((ROOT/'unit147-restored-build.source.json').read_text()), 'final unit compilation used different candidate source')

scope = dict(smt_proved=[],sst_air_smt_runs=0,native_bodies_proved=0,adopted_laws=0,all18='OPEN',
    executable_unit_tests='18/18 concrete-byte machine; test-only issuance; no native application executed',
    source_mutants=mutants,typed_original_mutants=arc['typed_mutants'],typed_original_restoration=arc['restoration'],
    native_original='compiler-only; local typed constraints captured, missing checkout refused; no native metadata export',
    native_law_functions='compiled only; native proof-port producers uninhabited; no native execution/semantic proof',
    unexecuted=['native capability issuance','native transition positive execution','native byte/loan copy contract instantiation',
                'original native application','148 patch and8 reported tests','independent147 exact-law review/disposition',
                'full original WF/modes/SST/AIR/SMT','native durability and all other18 cells'])
runner.write('proof-scope147.json',scope)
sources = ['source/rust_verify/src/native_resource143/authority147.rs','source/rust_verify/src/native_resource143/machine147.rs',
           'source/rust_verify/src/native_resource143.rs','source/rust_verify/src/bin/native_resource147.rs',
           'source/rust_verify/src/lib.rs','source/rust_verify/Cargo.toml','source/vstd/std_specs/slice.rs']
bindings = dict(original_mem_mut=arc['arc_get_mut'],header_consumers=header_ports['actual143_consumers'])
runner.write('source-law-manifest147.json',dict(disposition='UNADOPTED; separate independent exact-law review required',
    baseline143_seal='1147ecfc3fb5f12b94ba7eac4e824b8fe8a1777dafe69754975749eeab9b9360',
    baseline143_candidate='8a8a2134a7691b290f01989ef4a0777c2aa2ec3bd2a9d4c32919bcac32c6adc4',
    law=dict(path='LAW147.md',sha256=runner.sha(ROOT/'LAW147.md')),
    compiler_sources=[dict(path=path,sha256=runner.sha(ROOT/'candidate'/path)) for path in sources],
    library=dict(root=str(runner.LIBRARY),sync_sha256=runner.sha(runner.LIBRARY/'alloc/src/sync.rs'),
        get_mut_line=2673,get_mut_unchecked_line=2748,is_unique_line=2811,
        runtime_source_binding='pinned-runtime147.json',runtime_source_binding_sha256=runner.sha(ROOT/'pinned-runtime147.json'),
        compiler_runtime_bootstrap_correspondence='OPEN; local source128 is not proof of installed compiler correspondence'),
    exact_bindings=bindings,proof_scope='proof-scope147.json',remaining_ports=arc['required_open_ports']))
runner.write('failures-and-refusals147.json',dict(
    setup='SETUP-FAILURES.md; raw early setup transcript not independently saved',
    unsuccessful_compiler_commands=[dict(name=name,status=receipt['returncode'],stderr=receipt['stderr']) for name,receipt in receipts.items() if receipt['returncode']!=0],
    mistaken_control_build='mutant-suspension-build: compiled preceding root mutant after setup patch failure; not credited',
    inherited143='36/36 exhausted; no reset; zero native bodies proved; no SST/AIR/SMT',
    preserved_gaps=['R146-1 live holders','R146-2 injectivity/bundle coverage','Assert','for','cleanup','backend','map','hasher','callback/reentry']))
runner.write('validation-summary147.json',dict(utc=runner.utc(),failures=failures,completed_receipts=len(receipts),
    commands_including_this_validation=len(commands),unit_tests=18,mutants=4,typed_mutants=5,
    source_semantic_proof=False,native_credit=0,trust_credit=0,all18='OPEN'))
print(json.dumps(dict(failures=failures,receipts=len(receipts),all18='OPEN',native_proved=0)))
if failures:
    raise SystemExit(1)
