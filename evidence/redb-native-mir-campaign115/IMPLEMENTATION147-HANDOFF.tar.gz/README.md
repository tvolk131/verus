# Implementation147: closed byte-authority proposal, UNADOPTED

This is a distinct compiler-source candidate for the missing byte authority of
the ORIGINAL `WritablePage::mem_mut`. It is not a143 retry/exhaustion reset,
diagnostic inventory, native proof, trusted application summary or installed
law. All18 cells remain OPEN. Adopted laws0; original native bodies proved0;
SST/AIR/SMT runs0. Stop at this sealed handoff for separate independent exact-law
review/disposition; no review or automatic followup is started here.

## Deliverable and baseline-relative delta

Only `/private/tmp/implementation147-20261108-FkC98LCT` is written. Shared
checkout, baseline143, pinned sources and original redb remain read-only.
There is no Git/worktree creation, parent/native integration, original native
application execution, network operation, destructive cleanup or subdelegation.
Applicable instruction locations were checked; original redb's AGENTS was read.
No file in original redb is edited and its application tests are not executed.

Authenticated baseline143:

- `SEAL.json` SHA256
  `1147ecfc3fb5f12b94ba7eac4e824b8fe8a1777dafe69754975749eeab9b9360`.
- `candidate-final.json` SHA256
  `8a8a2134a7691b290f01989ef4a0777c2aa2ec3bd2a9d4c32919bcac32c6adc4`.
- All411 sealed payloads and1104 candidate files match at staging entry and
  remain selected through preexecution/exit authentication. Historical143's
  36/36 exhaustion, failures, zero native proofs and no SMT remain unchanged.

`candidate.patch` and `source-delta.json` are the exact143-relative delta, NOT a
patch against the dirty shared checkout. Six files differ: three new files
(`authority147.rs`, `machine147.rs`, `bin/native_resource147.rs`), and narrow
additions in143's driver, Cargo binary declaration, and rustc_abi import.
The old143 ledger is unchanged. No141 artifact, law or bypass is installed.

`authority147.rs` implements closed typed conditional native transitions:
Some/None, receiver suspension, Some/unwrap/native returned-loan transfer,
native source-copy byte term, unchanged or mutated NLL writeback, and matching
allocation/generation/handle/loan checks. Affine native tokens have no
Clone/Copy/Duplicate operation. Inputs are private compiler-owned typed bindings
and specific checked proof ports, never arbitrary Expr relations, booleans,
keys, logical binders or count certificates. Internal immutable identity
witnesses do not duplicate capability issuance.

**Original checkout/native bytes issuance remains an UNSATISFIED port.** Its
producer type is uninhabited. Additional discriminant, source alias/length/frame,
interprocedural lifetime, original holder/bundle, exact-law and runtime proof
ports also have no native producers. This is intentional refusal, not a
vacuously accepted proof. `LAW147.md` is the exact fixed law/port proposal.
`source-law-manifest147.json` binds its hash, compiler files, pinned library and
actual captured occurrences. Native law functions are compiled only; no native
capability is manufactured to execute them.

## Actual original occurrences and authority refusal

The final compiler-only original-source run is `original147-final`. It analyzes
`/private/tmp/redb-original-crate-preflight115/redb/src/lib.rs`, with actual
rustc MIR/borrow facts and retained original HIR/VIR calls, and exits1 with
`NRE143_OPEN_NATIVE_PROOF_OBLIGATIONS`. No successful native metadata export or
application execution occurs.

Local typed constraints bind actual Arc/get_mut DefId/Instance/[u8]/Global,
owner, actual self.data field/full Place, borrow reservation/activation,
actual Option destination/nominal discriminants/Some field, unwrap normal and
cleanup edges, native returned `_0` and original reborrow indices. Header
ByteMutation and LoanEndWriteback consumers bind actual native mem_mut, copy
receiver/source, normal NLL successor and cleanup endpoint. JSON is an
observation of those in-memory checks, never an imported authority certificate.

These local bindings do NOT establish native byte authority, runtime Option
discriminant observation, lifetime transfer, global source-bundle coverage or
live-holder correctness. Every native consumer refuses the missing semantic
inputs. Original false proof-debt assertions remain debts and are never called
byte semantics. No new VIR/SST/AIR relation or assumption is installed.

## Tests and non-proof scope

- Final offline/locked/jobs1 feature build succeeds (`build147-final`).
- Final restored concrete-byte control machine:18/18 executable unit tests pass.
  The finite byte-pattern control covers lengths0..32 and four patterns; it is
  not an exhaustive/native proof. Test-only fixture issuance is absent from
  native builds and is not original checkout authority.
- Four separate changed-source mutants (wrong bytes, missing root check,
  duplicate issuance/use-while-suspended, cleanup-as-normal) each compile and
  fail the intended targeted test. Exact mutant sources, patch and raw streams
  remain. The machine is restored byte-for-byte before formatting; the final
  formatted source is separately recompiled and all18 tests pass again.
- Five typed fault injections on actual original mem_mut constraints (Option,
  root, loan, returned native slice, Instance) all reject. Unmodified typed
  restoration succeeds, with original checkout still refused. These are typed
  in-memory perturbations, not five changed original source programs.
- Handle duplication and loan Clone compile guards refuse with E0382/E0599.
  Default-off binary selection refuses its required experimental feature.
- `validation-summary147.json` has no failures. `proof-scope147.json` separates
  compiled, executed, captured/translated and unexecuted controls. NOTHING is
  SMT-proved in147; no original body or durability cell is proved.

Reuse of `vstd/std_specs/slice.rs:634` is specified but NOT instantiated on redb:
real native byte/loan, alias/frame/source and equal-length inputs are missing.
No panic rollback, successful lock, inert callback, latest-load, weak-CAS
fairness, finite panic hook or unconditional normal termination is assumed.

## Review146, repair148 and inherited OPEN obligations

Sealed source-only146 report is authenticated against user-pinned root
`be03f003c5e3c9fef2826fddb64f3edb7a4980fca90285034f0c82e4b714752d`;
its report hash is checked against that seal. Selection is late, not backdated.
R146-1 (stale live-holder incarnation/root edges) and R146-2 (noninjective
bindings/exactly-once bundle consumption) remain OPEN typed proof ports.
Neither report nor147 claims a reproduced accepted-native exploit or finding
closure. Parent148 is explicitly UNCONSUMED; its artifacts are not inspected,
compiled, composed or used as authority. Its8 reported tests remain unrun here.
See `REPAIR148-DISPOSITION.md`.

AUTHORIZATION139/FIRST-CELL139 still target original arbitrary finite-history
two-phase acknowledged durability through native page/buffer/flush/barrier/
public acknowledgement/history/crash/recovery and required tree/allocator
effects. Assert/for/cleanup/backend/map/hasher/callback/reentry, cache/constructor,
full original WF/dependency and other18-cell obligations are preserved OPEN.

## Custody, failures, allowances and release

`inputs.json`, entry/preexecution/exit authentication, each source inventory,
raw argv/environment/status/clocks/stdout/stderr/resources, executable hashes
and group-reaping receipts are retained. The final build and restored-test
source inventories equal the final candidate. `candidate-final.json` covers all
candidate files; `target-final.json` covers final cached/build artifacts.
The target began as an APFS clone-copy of143's local cache: cache content is not
an independently proved dependency/bootstrap provenance theorem. Local pinned
Rust source != installed compiler/library/runtime correspondence.

`pinned-runtime147.json` authenticates7 expanded library members against128's
pinned archive. Its atomic/pointer/runtime assumptions remain OPEN. Additional
runtime members and146 inputs were selected late; no retroactive custody is
claimed. Early read-only discovery/setup traces and earlier runner revisions
are not independently retained as complete raw shell executions; the explicit
setup-failure record and compiler receipts state their actual scope. Per-command
argument-file/runner hashing begins after the first unit compilation; earlier
compiler-source inventories and executable hashes are still retained. The
final runner hash does not authenticate every earlier runner revision.

All compiler failures are preserved, including initial rustc API/lifetime/type
repairs. A failed temporary mutation patch was followed by a charged build of
the prior mutant; that build is NOT credited as a suspension control. A new
charged corrected build/test supplies that control. No allowance is reset.
See `SETUP-FAILURES.md` and `failures-and-refusals147.json`.

The distinct147 allowance is at most32 charged commands,40 minutes INCLUDING
seal/readback (start20:57:06Z, deadline21:37:06Z),2GiB fresh scratch, free disk
strictly>16GiB, builds<=600s, other commands<=120s, jobs1/offline/locked.
Actual final usage and explicit slot release are in `RELEASE.json`. All owned
command groups are terminated/reaped and absent. No work remains running.
`SEAL.json`, `SEAL.sha256` and `seal-readback.json` are the sealed handoff.
