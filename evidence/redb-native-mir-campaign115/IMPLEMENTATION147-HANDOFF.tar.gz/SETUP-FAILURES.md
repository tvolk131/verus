# Preserved setup failures

Initial read-only discovery used an overbroad `*ledger*` glob; terminal output
was truncated. A guessed `ledger.json` did not exist. Actual source ledger and
`commands.json` were then selected. No compiler/build/test command was run.

First147 runner initialization failed before input authentication/copy because
system Python lacks `hashlib.file_digest` (AttributeError). Replaced with
streaming SHA256 and retried; the failure is not an authentication success.
No compiler/build/test allowance was consumed by that setup-only attempt.

Second initialization failed on manifest ordering (Path sort differs from string
sort for a sibling directory/file). Explicit maps showed1104/1104 entries with
identical bytes/hashes; path-string ordering repaired the comparison. That
failure is retained, not treated as a successful initialization.

A temporary control patch used out-of-order hunks and failed to find the earlier
Some-suspension context. The shell did not stop and charged
`mutant-suspension-build` compiled the preceding root mutant instead. It is NOT
credited as a suspension control. Its exact source hash/receipt and
`machine147.setup-failed-mutation.rs` are retained. The corrected control uses
ordered hunks and a separately charged build; later compound commands stop on
setup failure. No allowance was reset or failure hidden.
