import datetime
import difflib
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
BASE = Path('/private/tmp/implementation143-20261108-LpJjrIbt')
SHARED = Path('/Users/tommyvolk/.t3/worktrees/verus/t3-60978068')
TC = Path('/Users/tommyvolk/.rustup/toolchains/1.99.1-aarch64-apple-darwin')
ORIGINAL = Path('/private/tmp/redb-original-crate-preflight115/redb')
LIBRARY = Path('/private/tmp/verus-pinned-rust-source-20261107-9FT58F/rust-src-1.99.1/rust-src/lib/rustlib/src/rust/library')
START = 1794171426
DEADLINE = START + 40 * 60

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()

def write(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

def inventory(root):
    return sorted([dict(path=str(path.relative_to(root)), bytes=path.stat().st_size, sha256=sha(path))
            for path in root.rglob('*') if path.is_file() and '.git' not in path.parts], key=lambda entry: entry['path'])

def resources():
    logical = allocated = 0
    for directory, _, names in os.walk(ROOT):
        for name in names:
            stat = (Path(directory) / name).lstat()
            logical += stat.st_size
            allocated += stat.st_blocks * 512
    value = dict(utc=utc(), logical=logical, allocated=allocated, free=shutil.disk_usage(ROOT).free,
                 deadline_remaining_seconds=DEADLINE-time.time())
    assert max(logical, allocated) <= 2 * 1024**3, value
    assert value['free'] > 16 * 1024**3, value
    assert time.time() < DEADLINE, value
    return value

def authenticate(phase):
    entries = json.loads((ROOT / 'inputs.json').read_text())
    failed = [entry['path'] for entry in entries if sha(entry['path']) != entry['sha256']]
    write('authentication-' + phase + '.json', dict(phase=phase, utc=utc(), failures=failed,
          selected=len(entries), resources=resources()))
    assert not failed, failed

def initialize():
    assert sha(BASE / 'SEAL.json') == '1147ecfc3fb5f12b94ba7eac4e824b8fe8a1777dafe69754975749eeab9b9360'
    assert sha(BASE / 'candidate-final.json') == '8a8a2134a7691b290f01989ef4a0777c2aa2ec3bd2a9d4c32919bcac32c6adc4'
    sealed = json.loads((BASE / 'SEAL.json').read_text())
    assert all(sha(BASE / entry['path']) == entry['sha256'] for entry in sealed)
    baseline = json.loads((BASE / 'candidate-final.json').read_text())
    assert inventory(BASE / 'candidate') == baseline
    selected = [BASE / entry['path'] for entry in sealed]
    selected += [BASE / 'candidate' / entry['path'] for entry in baseline]
    selected += [BASE / 'SEAL.json', BASE / 'candidate-final.json']
    selected += [ORIGINAL / entry['path'] for entry in inventory(ORIGINAL)]
    campaign = SHARED / 'evidence/redb-native-mir-campaign115'
    selected += [campaign / name for name in ('AUTHORIZATION139.md', 'FIRST-CELL139.md', 'LOCAL-PINNED-LIBRARY128.json')]
    pinned = json.loads((campaign / 'LOCAL-PINNED-LIBRARY128.json').read_text())
    for member in pinned['selected_members']:
        assert sha(LIBRARY / member['path']) == member['sha256']
        selected.append(LIBRARY / member['path'])
    selected += [LIBRARY / path for path in ('core/src/option.rs', 'core/src/slice/mod.rs', 'alloc/src/alloc.rs')]
    selected += [TC / 'bin' / name for name in ('rustc', 'cargo', 'rustdoc', 'rustfmt')]
    selected += list((TC / 'lib').glob('librustc_driver*'))
    selected += [Path('/private/tmp/redb-native-mir115-20261108T160243Z/target/debug/deps/liblibc-709064e59816a9f7.rlib')]
    write('inputs.json', [dict(path=str(path), bytes=path.stat().st_size, sha256=sha(path)) for path in sorted(set(selected))])
    write('baseline143.json', baseline)
    write('commands.json', [])
    write('slot.json', dict(task='implementation147', state='HELD', sole_compiler_slot=True, start_utc='2026-11-08T20:57:06Z',
          deadline_utc=datetime.datetime.fromtimestamp(DEADLINE, datetime.timezone.utc).isoformat(),
          charged_limit=32, fresh_scratch_limit=2*1024**3, inherited143='36/36 exhausted; unchanged; zero native proofs; no SST/AIR/SMT'))
    authenticate('entry')
    shutil.copytree(BASE / 'candidate', ROOT / 'candidate')
    (ROOT / 'tmp').mkdir()
    write('original-source.json', inventory(ORIGINAL))
    print(json.dumps(resources()))

def run(name, kind, seconds, argv):
    commands = json.loads((ROOT / 'commands.json').read_text())
    assert len(commands) < 32
    assert seconds <= (600 if kind == 'build' else 120)
    seconds = min(seconds, DEADLINE - time.time() - 75)
    assert seconds > 0
    authenticate('preexecution-' + name)
    source = inventory(ROOT / 'candidate')
    write(name + '.source.json', source)
    environment = json.loads((BASE / 'build-final-15.launch.json').read_text())['environment']
    for variable in ('CARGO_TARGET_DIR', 'CARGO_BUILD_BUILD_DIR'):
        environment[variable] = str(ROOT / 'target')
    environment['TMPDIR'] = str(ROOT / 'tmp')
    environment['VERUS_SOURCE_SNAPSHOT_SHA256'] = hashlib.sha256(json.dumps(source, sort_keys=True).encode()).hexdigest()
    entry = dict(number=len(commands)+1, name=name, kind=kind, argv=argv, cwd=str(ROOT / 'candidate/source'),
                 environment=environment, executable_sha256=sha(argv[0]), before=resources(), timeout=seconds)
    entry['runner_sha256'] = sha(__file__)
    entry['argv_regular_inputs'] = [dict(path=argument, bytes=Path(argument).stat().st_size, sha256=sha(argument))
                                    for argument in argv[1:] if Path(argument).is_file()]
    commands.append(entry)
    write('commands.json', commands)
    write(name + '.launch.json', entry)
    started = time.monotonic()
    process = None
    cause = None
    try:
        with (ROOT / (name+'.stdout')).open('wb') as output, (ROOT / (name+'.stderr')).open('wb') as error, (ROOT / (name+'.resources.jsonl')).open('w') as samples:
            process = subprocess.Popen(argv, cwd=entry['cwd'], env=environment, stdout=output, stderr=error, start_new_session=True)
            entry.update(pid=process.pid, pgid=process.pid)
            write(name + '.launch.json', entry)
            while process.poll() is None:
                samples.write(json.dumps(resources())+'\n')
                samples.flush()
                if time.monotonic()-started >= seconds:
                    cause = 'TIMEOUT'
                    break
                time.sleep(1)
    except BaseException as exception:
        cause = repr(exception)
    finally:
        if process is not None:
            try:
                os.killpg(process.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
            try:
                process.wait(timeout=3)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait()
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            try:
                os.killpg(process.pid, 0)
                entry['owned_group_absent'] = False
            except ProcessLookupError:
                entry['owned_group_absent'] = True
            entry['returncode'] = process.returncode
        entry.update(cause=cause, elapsed_seconds=time.monotonic()-started, after=resources(), end_utc=utc())
        after_source = inventory(ROOT / 'candidate')
        entry['source_unchanged_during_command'] = after_source == source
        if kind == 'format':
            write(name + '.after-source.json', after_source)
        for stream in ('stdout', 'stderr'):
            path = ROOT / (name+'.'+stream)
            entry[stream] = dict(bytes=path.stat().st_size, sha256=sha(path))
        write(name+'.receipt.json', entry)
        print(json.dumps({key: entry.get(key) for key in ('name','returncode','cause','elapsed_seconds','owned_group_absent')}))
    assert entry.get('owned_group_absent')
    return 0 if cause is None and entry.get('returncode') == 0 else 1

def seal():
    authenticate('exit')
    assert not json.loads((ROOT/'validation-summary147.json').read_text())['failures']
    baseline = {entry['path']:entry for entry in json.loads((ROOT/'baseline143.json').read_text())}
    candidate = inventory(ROOT/'candidate')
    write('candidate-final.json', candidate)
    patch = []
    delta = []
    for entry in candidate:
        relative = entry['path']
        if baseline.get(relative) != entry:
            delta.append(dict(path=relative, baseline=baseline.get(relative), candidate=entry))
            before = (BASE/'candidate'/relative).read_text().splitlines(keepends=True) if relative in baseline else []
            after = (ROOT/'candidate'/relative).read_text().splitlines(keepends=True)
            patch += difflib.unified_diff(before,after,fromfile='baseline143/'+relative,tofile='candidate147/'+relative)
    write('source-delta.json', delta)
    (ROOT/'candidate.patch').write_text(''.join(patch))
    target = inventory(ROOT/'target')
    write('target-final.json', target)
    assert inventory(ORIGINAL) == json.loads((ROOT/'original-source.json').read_text())
    commands = json.loads((ROOT/'commands.json').read_text())
    receipts = [json.loads((ROOT/(entry['name']+'.receipt.json')).read_text()) for entry in commands]
    assert all(entry['owned_group_absent'] and (entry['source_unchanged_during_command'] or entry['kind'] == 'format') for entry in receipts)
    write('RELEASE.json', dict(task='implementation147', state='RELEASED', utc=utc(), charged=len(commands), limit=32,
          owned_groups_absent=True, all18='OPEN', adopted_laws=0, native_bodies_proved=0, sst_air_smt_runs=0, resources=resources()))
    write('slot.json', json.loads((ROOT/'RELEASE.json').read_text()))
    files = [path for path in sorted(ROOT.iterdir()) if path.is_file() and path.name not in ('SEAL.json','SEAL.sha256','seal-readback.json')]
    write('SEAL.json', [dict(path=path.name,bytes=path.stat().st_size,sha256=sha(path)) for path in files])
    digest = sha(ROOT/'SEAL.json')
    (ROOT/'SEAL.sha256').write_text(digest+'  SEAL.json\n')
    assert all(sha(ROOT/entry['path']) == entry['sha256'] for entry in json.loads((ROOT/'SEAL.json').read_text()))
    assert inventory(ROOT/'candidate') == candidate
    assert inventory(ROOT/'target') == target
    write('seal-readback.json',dict(utc=utc(),seal_sha256=digest,candidate_manifest_sha256=sha(ROOT/'candidate-final.json'),
          payloads_checked=len(files),candidate_files_checked=len(candidate),failures=[],release='RELEASED'))
    print((ROOT/'seal-readback.json').read_text())

if __name__ == '__main__':
    if sys.argv[1] == 'init':
        initialize()
    elif sys.argv[1] == 'seal':
        seal()
    else:
        sys.exit(run(sys.argv[2],sys.argv[3],float(sys.argv[4]),sys.argv[5:]))
