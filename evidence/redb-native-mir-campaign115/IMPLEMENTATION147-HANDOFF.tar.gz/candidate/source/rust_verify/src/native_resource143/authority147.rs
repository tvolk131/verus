#![allow(dead_code)]

use super::ledger::{Effect, Lowering, Requirement};
use super::{Occurrence, operand_place, resolve};
use rustc_borrowck::consumers::{self, BodyWithBorrowckFacts, BorrowIndex, TwoPhaseActivation};
use rustc_hir::def_id::{DefId, LocalDefId};
use rustc_middle::mir::{self, Operand, Place, Rvalue, StatementKind, TerminatorKind};
use rustc_middle::ty::{self, Ty, TyCtxt};
use rustc_span::Symbol;
use serde_json::{Value, json};
use std::rc::Rc;

enum CheckedOriginalCheckoutProducer {}
enum CheckedNativeDiscriminantProducer {}
enum CheckedNativeSourceAliasLengthProducer {}
enum CheckedNativeLifetimeTransferProducer {}
enum CheckedLiveHolderIncarnationProducer {}
enum CheckedGlobalOccurrenceConsumptionProducer {}
enum CheckedIndependentExactLawDispositionProducer {}

struct GenerationIdentity;
struct HandleIdentity;

struct AllocationIdentity<'tcx> {
    constructor_owner: LocalDefId,
    constructor: Call<'tcx>,
}

struct NativeByteView<'tcx> {
    allocation: Rc<AllocationIdentity<'tcx>>,
    generation: Rc<GenerationIdentity>,
    value: NativeByteValue<'tcx>,
}

enum NativeByteValue<'tcx> {
    CheckedCheckout(CheckedOriginalCheckoutProducer),
    CopyOf {
        source: Box<NativeByteView<'tcx>>,
        actual_call: Call<'tcx>,
    },
}

struct NativeAuthority<'tcx> {
    producer: CheckedOriginalCheckoutProducer,
    owner: LocalDefId,
    root: Place<'tcx>,
    handle: Rc<HandleIdentity>,
    bytes: NativeByteView<'tcx>,
}

struct CheckedOutcome<'tcx> {
    producer: CheckedNativeDiscriminantProducer,
    live_holders: CheckedLiveHolderIncarnationProducer,
    global_occurrences: CheckedGlobalOccurrenceConsumptionProducer,
    law_disposition: CheckedIndependentExactLawDispositionProducer,
    owner: LocalDefId,
    call: mir::Location,
    option: Place<'tcx>,
    branch: NativeBranch,
}

enum NativeBranch {
    Some {
        variant: rustc_abi::VariantIdx,
        discriminant: u128,
    },
    None {
        variant: rustc_abi::VariantIdx,
        discriminant: u128,
    },
}

struct SuspendedReceiver<'tcx> {
    authority: NativeAuthority<'tcx>,
    binding: BoundGetMut<'tcx>,
    loan_identity: Rc<LoanIdentity>,
}

struct LoanIdentity;

struct NativeSliceLoan<'tcx> {
    allocation: Rc<AllocationIdentity<'tcx>>,
    generation: Rc<GenerationIdentity>,
    handle: Rc<HandleIdentity>,
    loan_identity: Rc<LoanIdentity>,
    owner: LocalDefId,
    option: Place<'tcx>,
    returned: Place<'tcx>,
    parent: BorrowIndex,
}

enum NativeOutcome<'tcx> {
    NonePreserved(NativeAuthority<'tcx>),
    SomeSuspended(SuspendedReceiver<'tcx>, NativeSliceLoan<'tcx>),
}

fn outcome<'tcx>(
    authority: NativeAuthority<'tcx>,
    binding: BoundGetMut<'tcx>,
    result: CheckedOutcome<'tcx>,
) -> Result<NativeOutcome<'tcx>, String> {
    if authority.owner != binding.call.owner
        || authority.root != binding.root
        || result.owner != binding.call.owner
        || result.call != binding.call.at
        || result.option != binding.call.destination
    {
        return Err("A147_AUTHORITY_OUTCOME_EXACT_OWNER_ROOT_CALL_OPTION".into());
    }
    match result.branch {
        NativeBranch::None {
            variant,
            discriminant,
        } if variant == binding.none_variant && discriminant == binding.none_discriminant => {
            Ok(NativeOutcome::NonePreserved(authority))
        }
        NativeBranch::Some {
            variant,
            discriminant,
        } if variant == binding.some_variant && discriminant == binding.some_discriminant => {
            let loan_identity = Rc::new(LoanIdentity);
            let slice = NativeSliceLoan {
                allocation: Rc::clone(&authority.bytes.allocation),
                generation: Rc::clone(&authority.bytes.generation),
                handle: Rc::clone(&authority.handle),
                loan_identity: Rc::clone(&loan_identity),
                owner: binding.call.owner,
                option: binding.call.destination,
                returned: binding.some_field,
                parent: binding.receiver_loan,
            };
            Ok(NativeOutcome::SomeSuspended(
                SuspendedReceiver {
                    authority,
                    binding,
                    loan_identity,
                },
                slice,
            ))
        }
        _ => Err("A147_EXACT_ACTUAL_OPTION_DISCRIMINANT_REQUIRED".into()),
    }
}

struct CheckedCopyPorts<'tcx> {
    source_alias_length: CheckedNativeSourceAliasLengthProducer,
    lifetime_transfer: CheckedNativeLifetimeTransferProducer,
    source: NativeByteView<'tcx>,
    copy: Call<'tcx>,
    source_operand: Operand<'tcx>,
    caller_returned: Place<'tcx>,
    caller_loan: BorrowIndex,
    callee_owner: LocalDefId,
    callee_returned: Place<'tcx>,
    callee_parent: BorrowIndex,
}

struct CheckedReturnedLoanPorts {
    lifetime_transfer: CheckedNativeLifetimeTransferProducer,
}

fn transfer_returned_native<'tcx>(
    suspension: &SuspendedReceiver<'tcx>,
    mut loan: NativeSliceLoan<'tcx>,
    _ports: CheckedReturnedLoanPorts,
) -> Result<NativeSliceLoan<'tcx>, String> {
    let binding = &suspension.binding;
    if !Rc::ptr_eq(&suspension.loan_identity, &loan.loan_identity)
        || loan.owner != binding.call.owner
        || loan.option != binding.call.destination
        || loan.parent != binding.receiver_loan
        || loan.returned != binding.some_field
    {
        return Err("A147_EXACT_SOME_UNWRAP_NORMAL_NATIVE_RETURN_TRANSFER".into());
    }
    loan.returned = binding.returned;
    Ok(loan)
}

struct MutatedNativeSlice<'tcx> {
    loan: NativeSliceLoan<'tcx>,
    bytes: NativeByteView<'tcx>,
    copy_at: mir::Location,
    caller_owner: LocalDefId,
    caller_loan: BorrowIndex,
    caller_returned: Place<'tcx>,
    normal_target: mir::BasicBlock,
}

fn copy_native<'tcx>(
    loan: NativeSliceLoan<'tcx>,
    ports: CheckedCopyPorts<'tcx>,
) -> Result<MutatedNativeSlice<'tcx>, String> {
    if loan.owner != ports.callee_owner
        || loan.returned != ports.callee_returned
        || loan.parent != ports.callee_parent
        || Rc::ptr_eq(&loan.allocation, &ports.source.allocation)
        || ports.copy.arguments.get(1) != Some(&ports.source_operand)
        || operand_place(&ports.copy.arguments[0]) != Some(ports.caller_returned)
    {
        return Err("A147_CHECKED_NATIVE_COPY_SOURCE_ALIAS_AND_RETURNED_LOAN_PORTS".into());
    }
    let copy_at = ports.copy.at;
    let caller_owner = ports.copy.owner;
    let normal_target = ports.copy.normal;
    let bytes = NativeByteView {
        allocation: Rc::clone(&loan.allocation),
        generation: Rc::clone(&loan.generation),
        value: NativeByteValue::CopyOf {
            source: Box::new(ports.source),
            actual_call: ports.copy,
        },
    };
    Ok(MutatedNativeSlice {
        loan,
        bytes,
        copy_at,
        caller_owner,
        normal_target,
        caller_loan: ports.caller_loan,
        caller_returned: ports.caller_returned,
    })
}

struct NativeLoanEndPort<'tcx> {
    lifetime_transfer: CheckedNativeLifetimeTransferProducer,
    callee_owner: LocalDefId,
    callee_returned: Place<'tcx>,
    callee_parent: BorrowIndex,
    owner: LocalDefId,
    at: mir::Location,
    loan: BorrowIndex,
    receiver: Place<'tcx>,
    returned: Place<'tcx>,
}

fn writeback_native<'tcx>(
    tcx: TyCtxt<'tcx>,
    facts: &BodyWithBorrowckFacts<'tcx>,
    suspension: SuspendedReceiver<'tcx>,
    mutated: MutatedNativeSlice<'tcx>,
    endpoint: NativeLoanEndPort<'tcx>,
) -> Result<NativeAuthority<'tcx>, String> {
    let endpoints = consumers::calculate_borrows_out_of_scope_at_location(
        &facts.body,
        &facts.region_inference_context,
        &facts.borrow_set,
    );
    if !Rc::ptr_eq(&suspension.loan_identity, &mutated.loan.loan_identity)
        || !Rc::ptr_eq(
            &suspension.authority.bytes.allocation,
            &mutated.loan.allocation,
        )
        || !Rc::ptr_eq(
            &suspension.authority.bytes.generation,
            &mutated.loan.generation,
        )
        || !Rc::ptr_eq(&suspension.authority.handle, &mutated.loan.handle)
        || !Rc::ptr_eq(&mutated.bytes.allocation, &mutated.loan.allocation)
        || !Rc::ptr_eq(&mutated.bytes.generation, &mutated.loan.generation)
        || endpoint.callee_owner != mutated.loan.owner
        || endpoint.callee_returned != mutated.loan.returned
        || endpoint.callee_parent != mutated.loan.parent
        || facts.body.source.def_id() != endpoint.owner.to_def_id()
        || endpoint.owner != mutated.caller_owner
        || endpoint.loan != mutated.caller_loan
        || endpoint.returned != mutated.caller_returned
        || endpoint.at.block != mutated.normal_target
        || endpoint.at.statement_index != 0
        || facts.body.basic_blocks[endpoint.at.block].is_cleanup
        || !endpoints
            .get(&endpoint.at)
            .is_some_and(|loans| loans.contains(&endpoint.loan))
        || facts.borrow_set[endpoint.loan].borrowed_place() != endpoint.receiver
        || facts.borrow_set[endpoint.loan].assigned_place() != endpoint.returned
        || !byte_slice(
            tcx,
            endpoint.returned.ty(&facts.body.local_decls, tcx).ty,
            rustc_ast::Mutability::Mut,
        )
    {
        return Err("A147_EXACT_AFFINE_SUSPENSION_GENERATION_MUTATION_NLL_NORMAL_WRITEBACK".into());
    }
    let mut authority = suspension.authority;
    authority.bytes = mutated.bytes;
    Ok(authority)
}

fn writeback_unchanged_native<'tcx>(
    facts: &BodyWithBorrowckFacts<'tcx>,
    suspension: SuspendedReceiver<'tcx>,
    loan: NativeSliceLoan<'tcx>,
    endpoint: NativeLoanEndPort<'tcx>,
) -> Result<NativeAuthority<'tcx>, String> {
    let endpoints = consumers::calculate_borrows_out_of_scope_at_location(
        &facts.body,
        &facts.region_inference_context,
        &facts.borrow_set,
    );
    if !Rc::ptr_eq(&suspension.loan_identity, &loan.loan_identity)
        || !Rc::ptr_eq(&suspension.authority.bytes.allocation, &loan.allocation)
        || !Rc::ptr_eq(&suspension.authority.bytes.generation, &loan.generation)
        || !Rc::ptr_eq(&suspension.authority.handle, &loan.handle)
        || endpoint.callee_owner != loan.owner
        || endpoint.callee_returned != loan.returned
        || endpoint.callee_parent != loan.parent
        || facts.body.source.def_id() != endpoint.owner.to_def_id()
        || facts.body.basic_blocks[endpoint.at.block].is_cleanup
        || !endpoints
            .get(&endpoint.at)
            .is_some_and(|loans| loans.contains(&endpoint.loan))
        || facts.borrow_set[endpoint.loan].borrowed_place() != endpoint.receiver
        || facts.borrow_set[endpoint.loan].assigned_place() != endpoint.returned
    {
        return Err("A147_EXACT_UNMUTATED_RETURNED_LOAN_NLL_WRITEBACK".into());
    }
    Ok(suspension.authority)
}

#[derive(Debug)]
enum OpenPort {
    CheckedOriginalCheckoutAndBytes,
    CompleteHandleAndWeakInventory,
    UnsafeAliasExclusionAndFrameOwnership,
    PinnedLibraryToCompilerAndRuntimeCorrespondence,
    IndependentExactLawDisposition,
    NativeReturnedSliceAndNllByteWriteback,
    NativeSourceReadAliasAndEqualLength,
    UnwrapPanicHookUnwindAbortOrDivergence,
    R146LiveHolderIncarnation,
    R146GlobalOccurrenceAndBundleConsumption,
    ActualNativeOptionDiscriminantObservation,
}

#[derive(Debug)]
struct Call<'tcx> {
    owner: LocalDefId,
    at: mir::Location,
    instance: ty::Instance<'tcx>,
    arguments: Vec<Operand<'tcx>>,
    destination: Place<'tcx>,
    normal: mir::BasicBlock,
    unwind: mir::UnwindAction,
}

#[derive(Debug)]
struct BoundGetMut<'tcx> {
    call: Call<'tcx>,
    arc_definition: DefId,
    allocator: Ty<'tcx>,
    data_field: DefId,
    root: Place<'tcx>,
    receiver: Place<'tcx>,
    receiver_loan: BorrowIndex,
    some_variant: rustc_abi::VariantIdx,
    none_variant: rustc_abi::VariantIdx,
    some_discriminant: u128,
    none_discriminant: u128,
    native_slice_type: Ty<'tcx>,
    some_field: Place<'tcx>,
    unwrap: Call<'tcx>,
    returned: Place<'tcx>,
    returned_at: mir::Location,
    returned_reborrows: Vec<BorrowIndex>,
    is_unique: DefId,
    get_mut_unchecked: DefId,
}

fn same_type<'tcx>(tcx: TyCtxt<'tcx>, left: Ty<'tcx>, right: Ty<'tcx>) -> bool {
    tcx.erase_and_anonymize_regions(left) == tcx.erase_and_anonymize_regions(right)
}

fn byte_slice<'tcx>(tcx: TyCtxt<'tcx>, typ: Ty<'tcx>, mutability: rustc_ast::Mutability) -> bool {
    matches!(typ.kind(), ty::Ref(_, inner, actual) if *actual == mutability
        && matches!(inner.kind(), ty::Slice(element) if *element == tcx.types.u8))
}

fn inherent(tcx: TyCtxt<'_>, adt: DefId, name: &str) -> Result<DefId, String> {
    let methods = tcx
        .inherent_impls(adt)
        .iter()
        .flat_map(|implementation| {
            tcx.associated_items(*implementation)
                .filter_by_name_unhygienic(Symbol::intern(name))
                .map(|item| item.def_id)
        })
        .collect::<Vec<_>>();
    if methods.len() != 1 {
        return Err(format!("A147_UNIQUE_NOMINAL_ASSOCIATED_ITEM_OPEN {name}"));
    }
    Ok(methods[0])
}

fn call<'tcx>(
    tcx: TyCtxt<'tcx>,
    owner: LocalDefId,
    facts: &BodyWithBorrowckFacts<'tcx>,
    occurrences: &[Result<Occurrence<'tcx>, String>],
    at: mir::Location,
) -> Result<Call<'tcx>, String> {
    let body = &facts.body;
    if body.source.def_id() != owner.to_def_id() {
        return Err("A147_EXACT_BODY_OWNER_REQUIRED".into());
    }
    let data = &body.basic_blocks[at.block];
    if at.statement_index != data.statements.len() || data.is_cleanup {
        return Err("A147_NORMAL_CALL_OCCURRENCE_REQUIRED".into());
    }
    let TerminatorKind::Call {
        func,
        args,
        destination,
        target: Some(normal),
        unwind,
        ..
    } = &data.terminator().kind
    else {
        return Err("A147_EXACT_CALL_NORMAL_AND_UNWIND_REQUIRED".into());
    };
    let instance = resolve(tcx, owner, func.ty(&body.local_decls, tcx))?;
    let anchors = occurrences
        .iter()
        .filter_map(|result| result.as_ref().ok())
        .filter(|occurrence| occurrence.location == at)
        .collect::<Vec<_>>();
    if anchors.len() != 1
        || anchors[0].instance != instance
        || anchors[0].destination != *destination
        || anchors[0].hir.owner.def_id != owner
    {
        return Err("A147_REAL_HIR_VIR_MIR_OWNER_INSTANCE_DESTINATION".into());
    }
    let signature = tcx.instantiate_bound_regions_with_erased(
        tcx.fn_sig(instance.def_id())
            .instantiate(tcx, instance.args)
            .skip_norm_wip(),
    );
    if signature.inputs().len() != args.len()
        || !same_type(
            tcx,
            signature.output(),
            destination.ty(&body.local_decls, tcx).ty,
        )
        || signature
            .inputs()
            .iter()
            .zip(args)
            .any(|(expected, actual)| {
                !same_type(tcx, *expected, actual.node.ty(&body.local_decls, tcx))
            })
    {
        return Err(format!(
            "A147_COMPLETE_NATIVE_CALL_OPERAND_AND_RESULT_TYPES at {at:?}: signature={signature:?}; result={:?}; actual_inputs={:?}",
            destination.ty(&body.local_decls, tcx).ty,
            args.iter()
                .map(|argument| argument.node.ty(&body.local_decls, tcx))
                .collect::<Vec<_>>()
        ));
    }
    Ok(Call {
        owner,
        at,
        instance,
        arguments: args.iter().map(|argument| argument.node.clone()).collect(),
        destination: *destination,
        normal: *normal,
        unwind: *unwind,
    })
}

#[derive(Clone, Copy, Debug)]
enum Challenge {
    Original,
    WrongOption,
    WrongRoot,
    WrongLoan,
    WrongReturnedSlice,
    WrongInstance,
}

fn bind_get_mut<'tcx>(
    tcx: TyCtxt<'tcx>,
    owner: LocalDefId,
    facts: &BodyWithBorrowckFacts<'tcx>,
    occurrences: &[Result<Occurrence<'tcx>, String>],
    lowering: &Lowering<'tcx>,
    challenge: Challenge,
) -> Result<BoundGetMut<'tcx>, String> {
    let body = &facts.body;
    let gets = lowering
        .requirements
        .iter()
        .filter(|requirement| matches!(requirement, Requirement::ArcGetMutOutcomes { .. }))
        .collect::<Vec<_>>();
    if gets.len() != 1 {
        return Err("A147_EXACT_SINGLE_GET_MUT_REQUIRED".into());
    }
    let mut get = gets[0].clone();
    if let Requirement::ArcGetMutOutcomes {
        returned_option,
        receiver_loan,
        ..
    } = &mut get
    {
        if matches!(challenge, Challenge::WrongOption) {
            *returned_option = Place::from(mir::RETURN_PLACE);
        }
        if matches!(challenge, Challenge::WrongLoan) {
            *receiver_loan = facts
                .borrow_set
                .iter_enumerated()
                .find(|(index, _)| index != receiver_loan)
                .ok_or("A147_NO_ALTERNATE_NATIVE_LOAN_CONTROL")?
                .0;
        }
    }
    get.validate(tcx, owner, facts)?;
    let Requirement::ArcGetMutOutcomes {
        at,
        receiver_loan,
        arc,
        returned_option,
    } = get
    else {
        unreachable!()
    };
    let mut actual_call = call(tcx, owner, facts, occurrences, at)?;
    let arc_id = tcx
        .get_diagnostic_item(Symbol::intern("Arc"))
        .ok_or("A147_ARC_DIAGNOSTIC_ITEM_OPEN")?;
    let ty::Adt(arc_adt, arc_args) = arc.ty(&body.local_decls, tcx).ty.kind() else {
        return Err("A147_NOMINAL_ARC_REQUIRED".into());
    };
    if arc_adt.did() != arc_id
        || tcx.crate_name(arc_id.krate).as_str() != "alloc"
        || arc_args.len() != 2
        || !matches!(arc_args.type_at(0).kind(), ty::Slice(element) if *element == tcx.types.u8)
    {
        return Err("A147_EXACT_ALLOC_ARC_U8_SLICE".into());
    }
    let parameters = &tcx.generics_of(arc_id).own_params;
    let allocator = tcx
        .type_of(parameters[1].def_id)
        .instantiate_identity()
        .skip_norm_wip();
    if !same_type(tcx, arc_args.type_at(1), allocator)
        || !matches!(allocator.kind(), ty::Adt(global, arguments) if arguments.is_empty()
            && tcx.item_name(global.did()).as_str() == "Global"
            && tcx.crate_name(global.did().krate).as_str() == "alloc")
    {
        return Err("A147_EXACT_DEFAULT_GLOBAL_ALLOCATOR_REQUIRED".into());
    }
    let canonical = inherent(tcx, arc_id, "get_mut")?;
    if matches!(challenge, Challenge::WrongInstance) {
        actual_call.instance = ty::Instance::new_raw(
            inherent(tcx, arc_id, "get_mut_unchecked")?,
            actual_call.instance.args,
        );
    }
    if actual_call.instance.def_id() != canonical
        || !same_type(
            tcx,
            actual_call.instance.args.type_at(0),
            arc_args.type_at(0),
        )
        || !same_type(tcx, actual_call.instance.args.type_at(1), allocator)
    {
        return Err("A147_EXACT_GET_MUT_DEFID_INSTANCE_SUBSTITUTIONS".into());
    }
    let loan = &facts.borrow_set[receiver_loan];
    if loan.borrowed_place() != arc
        || loan.activation_location() != TwoPhaseActivation::ActivatedAt(at)
        || operand_place(&actual_call.arguments[0]) != Some(loan.assigned_place())
    {
        return Err("A147_EXACT_NLL_RECEIVER_RESERVATION_ACTIVATION".into());
    }
    let ty::Adt(option_adt, option_args) = returned_option.ty(&body.local_decls, tcx).ty.kind()
    else {
        return Err("A147_OPTION_REQUIRED".into());
    };
    if tcx.lang_items().option_type() != Some(option_adt.did())
        || option_args.len() != 1
        || !byte_slice(tcx, option_args.type_at(0), rustc_ast::Mutability::Mut)
    {
        return Err("A147_NATIVE_OPTION_MUT_U8_SLICE".into());
    }
    let some = option_adt
        .variants()
        .iter_enumerated()
        .find(|(_, variant)| variant.name.as_str() == "Some")
        .ok_or("A147_NOMINAL_SOME_VARIANT")?;
    let none = option_adt
        .variants()
        .iter_enumerated()
        .find(|(_, variant)| variant.name.as_str() == "None")
        .ok_or("A147_NOMINAL_NONE_VARIANT")?;
    if some.1.fields.len() != 1
        || !none.1.fields.is_empty()
        || !same_type(
            tcx,
            some.1
                .fields
                .iter()
                .next()
                .unwrap()
                .ty(tcx, option_args)
                .skip_norm_wip(),
            option_args.type_at(0),
        )
    {
        return Err("A147_COMPLETE_SOME_FIELD_TYPE".into());
    }
    let unwraps = lowering.requirements.iter().filter(|requirement| matches!(requirement, Requirement::UnwrapOutcomes { from, .. } if *from == at)).collect::<Vec<_>>();
    let transfers = lowering.requirements.iter().filter(|requirement| matches!(requirement, Requirement::ReturnedLoanTransfer { from, .. } if *from == at)).collect::<Vec<_>>();
    if unwraps.len() != 1 || transfers.len() != 1 {
        return Err("A147_UNWRAP_RETURN_NATIVE_PATH_REQUIRED".into());
    }
    unwraps[0].validate(tcx, owner, facts)?;
    let Requirement::UnwrapOutcomes {
        at: unwrap_at,
        returned_slice,
        ..
    } = unwraps[0]
    else {
        unreachable!()
    };
    let unwrap = call(tcx, owner, facts, occurrences, *unwrap_at)?;
    if unwrap.instance.def_id() != inherent(tcx, option_adt.did(), "unwrap")?
        || !same_type(tcx, unwrap.instance.args.type_at(0), option_args.type_at(0))
        || actual_call.normal != unwrap_at.block
    {
        return Err("A147_EXACT_UNWRAP_OPTION_INSTANCE_AND_NORMAL_EDGE".into());
    }
    let mut transfer = transfers[0].clone();
    if let Requirement::ReturnedLoanTransfer { root, returned, .. } = &mut transfer {
        if matches!(challenge, Challenge::WrongRoot) {
            *root = Place::from(mir::RETURN_PLACE);
        }
        if matches!(challenge, Challenge::WrongReturnedSlice) {
            *returned = *returned_slice;
        }
    }
    transfer.validate(tcx, owner, facts)?;
    let Requirement::ReturnedLoanTransfer {
        at: returned_at,
        root,
        returned,
        receiver,
        parent,
        ..
    } = transfer
    else {
        unreachable!()
    };
    if parent != receiver_loan
        || receiver != arc
        || !byte_slice(
            tcx,
            returned.ty(&body.local_decls, tcx).ty,
            rustc_ast::Mutability::Mut,
        )
        || unwrap.normal != returned_at.block
    {
        return Err("A147_RETURN_NATIVE_SLICE_ROOT_AND_NORMAL_EDGE".into());
    }
    let signature = tcx.instantiate_bound_regions_with_erased(
        tcx.fn_sig(owner).instantiate_identity().skip_norm_wip(),
    );
    let ty::Ref(_, self_type, rustc_ast::Mutability::Mut) = signature.inputs()[0].kind() else {
        return Err("A147_MUTABLE_SELF_REQUIRED".into());
    };
    let ty::Adt(page, arguments) = self_type.kind() else {
        return Err("A147_NOMINAL_WRITABLE_PAGE_REQUIRED".into());
    };
    let fields = page
        .non_enum_variant()
        .fields
        .iter_enumerated()
        .filter(|(_, field)| field.name.as_str() == "data")
        .collect::<Vec<_>>();
    if !page.did().is_local()
        || tcx.item_name(page.did()).as_str() != "WritablePage"
        || fields.len() != 1
    {
        return Err("A147_EXACT_NATIVE_RECEIVER_DATA_FIELD".into());
    }
    let (field_index, field) = fields[0];
    let field_type = field.ty(tcx, arguments).skip_norm_wip();
    let self_local = body
        .args_iter()
        .next()
        .ok_or("A147_NATIVE_SELF_ARGUMENT_REQUIRED")?;
    if body.arg_count != 1
        || !same_type(tcx, body.local_decls[self_local].ty, signature.inputs()[0])
    {
        return Err("A147_EXACT_NATIVE_SELF_ARGUMENT_TYPE".into());
    }
    let expected_root = Place::from(self_local).project_deeper(
        &[
            mir::ProjectionElem::Deref,
            mir::ProjectionElem::Field(field_index, field_type),
        ],
        tcx,
    );
    if root != expected_root || !same_type(tcx, field_type, arc.ty(&body.local_decls, tcx).ty) {
        return Err("A147_ACTUAL_SELF_DATA_FULL_PLACE_REQUIRED".into());
    }
    let mut provenance = vec![*returned_slice];
    let mut returned_reborrows = Vec::new();
    for (statement_index, statement) in body.basic_blocks[returned_at.block]
        .statements
        .iter()
        .enumerate()
    {
        let StatementKind::Assign(assignment) = &statement.kind else {
            continue;
        };
        let (destination, value) = &**assignment;
        let location = mir::Location {
            block: returned_at.block,
            statement_index,
        };
        let inherited = match value {
            Rvalue::Use(operand, _) => {
                operand_place(operand).is_some_and(|place| provenance.contains(&place))
            }
            Rvalue::Ref(_, mir::BorrowKind::Mut { .. }, borrowed) => {
                let parents = provenance
                    .iter()
                    .filter(|place| {
                        place.project_deeper(&[mir::ProjectionElem::Deref], tcx) == *borrowed
                    })
                    .count();
                if parents == 1 {
                    let loans = facts
                        .borrow_set
                        .iter_enumerated()
                        .filter(|(_, child)| {
                            child.reserve_location() == location
                                && child.borrowed_place() == *borrowed
                                && child.assigned_place() == *destination
                        })
                        .collect::<Vec<_>>();
                    if loans.len() != 1
                        || !facts
                            .region_inference_context
                            .eval_outlives(loan.region(), loans[0].1.region())
                    {
                        return Err("A147_NATIVE_RETURN_REBORROW_NLL_OUTLIVES".into());
                    }
                    returned_reborrows.push(loans[0].0);
                }
                parents == 1
            }
            _ => false,
        };
        provenance.retain(|place| place != destination);
        if inherited {
            provenance.push(*destination);
        }
    }
    if !provenance.contains(&returned) || returned_reborrows.is_empty() {
        return Err("A147_NATIVE_UNWRAP_TO_RETURN_SLICE_REBORROWS".into());
    }
    let (some_field_index, _) = some.1.fields.iter_enumerated().next().unwrap();
    let some_field = returned_option.project_deeper(
        &[
            mir::ProjectionElem::Downcast(Some(some.1.name), some.0),
            mir::ProjectionElem::Field(some_field_index, option_args.type_at(0)),
        ],
        tcx,
    );
    Ok(BoundGetMut {
        call: actual_call,
        arc_definition: arc_id,
        allocator,
        data_field: field.did,
        root,
        receiver: arc,
        receiver_loan,
        some_variant: some.0,
        none_variant: none.0,
        some_discriminant: option_adt.discriminant_for_variant(tcx, some.0).val,
        none_discriminant: option_adt.discriminant_for_variant(tcx, none.0).val,
        native_slice_type: option_args.type_at(0),
        some_field,
        unwrap,
        returned,
        returned_at,
        returned_reborrows,
        is_unique: inherent(tcx, arc_id, "is_unique")?,
        get_mut_unchecked: inherent(tcx, arc_id, "get_mut_unchecked")?,
    })
}

fn require_checkout<'tcx>(
    bound: &BoundGetMut<'tcx>,
    incoming: Option<NativeAuthority<'tcx>>,
) -> Result<(), OpenPort> {
    let Some(authority) = incoming else {
        return Err(OpenPort::CheckedOriginalCheckoutAndBytes);
    };
    if authority.owner != bound.call.owner || authority.root != bound.root {
        return Err(OpenPort::CheckedOriginalCheckoutAndBytes);
    }
    match authority.producer {}
}

fn consumer<'tcx>(
    tcx: TyCtxt<'tcx>,
    owner: LocalDefId,
    facts: &BodyWithBorrowckFacts<'tcx>,
    occurrences: &[Result<Occurrence<'tcx>, String>],
    requirement: &Requirement<'tcx>,
) -> Result<Value, String> {
    requirement.validate(tcx, owner, facts)?;
    match requirement {
        Requirement::ByteMutation {
            at,
            returned_from,
            loan,
            source,
            effect,
        } => {
            let copy = call(tcx, owner, facts, occurrences, *at)?;
            let native = call(tcx, owner, facts, occurrences, *returned_from)?;
            let signature = tcx.instantiate_bound_regions_with_erased(
                tcx.fn_sig(copy.instance.def_id())
                    .instantiate(tcx, copy.instance.args)
                    .skip_norm_wip(),
            );
            let implementation = tcx.parent(copy.instance.def_id());
            if !matches!(
                tcx.def_kind(implementation),
                rustc_hir::def::DefKind::Impl { .. }
            ) {
                return Err("A147_COPY_INHERENT_IMPL_REQUIRED".into());
            }
            let self_type = tcx
                .type_of(implementation)
                .instantiate(tcx, copy.instance.args)
                .skip_norm_wip();
            if tcx.crate_name(copy.instance.def_id().krate).as_str() != "core"
                || tcx.item_name(copy.instance.def_id()).as_str() != "copy_from_slice"
                || !matches!(self_type.kind(), ty::Slice(element) if *element == tcx.types.u8)
                || signature.inputs().len() != 2
                || !byte_slice(tcx, signature.inputs()[0], rustc_ast::Mutability::Mut)
                || !byte_slice(tcx, signature.inputs()[1], rustc_ast::Mutability::Not)
                || copy.arguments.get(1) != Some(source)
                || !native.instance.def_id().is_local()
                || tcx.item_name(native.instance.def_id()).as_str() != "mem_mut"
            {
                return Err("A147_EXACT_NATIVE_RETURNED_LOAN_COPY_SOURCE_AND_TYPES".into());
            }
            Ok(
                json!({"kind":"ByteMutation", "owner":format!("{owner:?}"), "call":format!("{copy:?}"),
                "native_return_producer":format!("{native:?}"), "loan":format!("{loan:?}"),
                "effect":format!("{effect:?}"), "authority":"REFUSED: native mem_mut proof + native source read frame + alias/length ports missing",
                "copy_contract":"source/vstd/std_specs/slice.rs:634; NOT instantiated without native byte/loan preconditions"}),
            )
        }
        Requirement::LoanEndWriteback {
            at,
            loan,
            receiver,
            returned,
            effect,
            cleanup,
        } => {
            let endpoints = consumers::calculate_borrows_out_of_scope_at_location(
                &facts.body,
                &facts.region_inference_context,
                &facts.borrow_set,
            );
            if !endpoints.get(at).is_some_and(|loans| loans.contains(loan)) {
                return Err("A147_EXACT_NLL_ENDPOINT_REQUIRED".into());
            }
            let edge = match effect {
                Effect::NormalCopy(copy) if !cleanup => {
                    let event = call(tcx, owner, facts, occurrences, *copy)?;
                    if at.block != event.normal || at.statement_index != 0 {
                        return Err("A147_NONIMMEDIATE_NORMAL_WRITEBACK_OPEN".into());
                    }
                    "normal successor and exact NLL end bound; no byte writeback credited"
                }
                Effect::UnwindPrefix(_) if *cleanup => {
                    "cleanup endpoint bound; NO normal restoration or rollback"
                }
                Effect::UnchangedByThisLoan => {
                    "no byte mutation credited; original native authority still required"
                }
                _ => return Err("A147_NORMAL_CLEANUP_EFFECT_CONFLATION_REFUSED".into()),
            };
            Ok(
                json!({"kind":"LoanEndWriteback", "at":format!("{at:?}"),"loan":format!("{loan:?}"),
                "receiver":format!("{receiver:?}"),"returned":format!("{returned:?}"),"edge":edge,
                "authority":"REFUSED: checked suspension + same-generation native byte mutation + exact checked endpoint required"}),
            )
        }
        _ => Err("A147_NOT_A_BYTE_WRITEBACK_CONSUMER".into()),
    }
}

pub(super) fn inspect<'tcx>(
    tcx: TyCtxt<'tcx>,
    owner: LocalDefId,
    facts: &BodyWithBorrowckFacts<'tcx>,
    occurrences: &[Result<Occurrence<'tcx>, String>],
    lowering: &Lowering<'tcx>,
) -> Value {
    let has_arc = lowering
        .requirements
        .iter()
        .any(|requirement| matches!(requirement, Requirement::ArcGetMutOutcomes { .. }));
    let get_mut = if has_arc {
        Some(bind_get_mut(tcx, owner, facts, occurrences, lowering, Challenge::Original).map(|bound| {
            let refusal = require_checkout(&bound, None);
            json!({"typed_binding":format!("{bound:#?}"), "native_authority_port":format!("{refusal:?}"),
                "outcomes":"Some uses actual nominal Some discriminant/field only; None preserves byte authority; unwrap normal Some vs panic/unwind/abort/nonreturn remain separate",
                "library_semantics":"UNADOPTED pinned alloc/sync.rs get_mut/is_unique/get_mut_unchecked; no global count/return-time uniqueness equivalence"})
        }))
    } else {
        None
    };
    let controls = if has_arc {
        [Challenge::WrongOption, Challenge::WrongRoot, Challenge::WrongLoan, Challenge::WrongReturnedSlice, Challenge::WrongInstance]
            .iter().map(|challenge| json!({"challenge":format!("{challenge:?}"),
                "result":bind_get_mut(tcx, owner, facts, occurrences, lowering, *challenge).map(|_| "BUG: accepted mutant") })).collect::<Vec<_>>()
    } else {
        Vec::new()
    };
    let restored = if has_arc {
        Some(
            bind_get_mut(
                tcx,
                owner,
                facts,
                occurrences,
                lowering,
                Challenge::Original,
            )
            .map(|_| "typed original restored; authority still refused"),
        )
    } else {
        None
    };
    let consumers = lowering
        .requirements
        .iter()
        .filter(|requirement| {
            matches!(
                requirement,
                Requirement::ByteMutation { .. } | Requirement::LoanEndWriteback { .. }
            )
        })
        .map(|requirement| consumer(tcx, owner, facts, occurrences, requirement))
        .collect::<Vec<_>>();
    json!({"schema":"unadopted-byte-authority147", "arc_get_mut":get_mut,"typed_mutants":controls,"restoration":restored,
        "actual143_consumers":consumers,"native_checkout_constructor":"UNSATISFIED: uninhabited checked-original producer; syntactic origin is not authority",
        "required_open_ports":format!("{:?}", [OpenPort::CheckedOriginalCheckoutAndBytes,OpenPort::CompleteHandleAndWeakInventory,
            OpenPort::UnsafeAliasExclusionAndFrameOwnership,OpenPort::PinnedLibraryToCompilerAndRuntimeCorrespondence,
            OpenPort::IndependentExactLawDisposition,OpenPort::NativeReturnedSliceAndNllByteWriteback,
            OpenPort::NativeSourceReadAliasAndEqualLength,OpenPort::UnwrapPanicHookUnwindAbortOrDivergence,
            OpenPort::R146LiveHolderIncarnation,OpenPort::R146GlobalOccurrenceAndBundleConsumption,
            OpenPort::ActualNativeOptionDiscriminantObservation]),
        "semantic_credit":0,"adopted":false,"native_export":"REFUSED","sst_air_smt":"NOT RUN; no added VIR relations or assumptions"})
}
