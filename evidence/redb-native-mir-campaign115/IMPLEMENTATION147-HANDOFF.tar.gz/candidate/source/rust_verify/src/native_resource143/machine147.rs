#![allow(dead_code)]

use std::rc::Rc;

#[derive(Debug)]
struct Identity;

#[derive(Debug)]
struct Stamp {
    allocation: Rc<Identity>,
    generation: Rc<Identity>,
    handle: Rc<Identity>,
}

impl Stamp {
    fn same(&self, other: &Self) -> bool {
        Rc::ptr_eq(&self.allocation, &other.allocation)
            && Rc::ptr_eq(&self.generation, &other.generation)
            && Rc::ptr_eq(&self.handle, &other.handle)
    }

    fn witness(&self) -> Self {
        Self {
            allocation: Rc::clone(&self.allocation),
            generation: Rc::clone(&self.generation),
            handle: Rc::clone(&self.handle),
        }
    }
}

#[derive(Debug)]
pub(super) struct Handle {
    stamp: Stamp,
}

#[derive(Debug)]
pub(super) struct SliceLoan {
    stamp: Stamp,
    loan: Rc<Identity>,
}

#[derive(Debug)]
pub(super) struct ReadFrame {
    stamp: Stamp,
    bytes: Box<[u8]>,
}

#[derive(Debug)]
pub(super) struct NormalCopy {
    stamp: Stamp,
    loan: Rc<Identity>,
    event: Rc<Identity>,
}

#[derive(Debug)]
pub(super) struct CheckedLoanEnd {
    stamp: Stamp,
    loan: Rc<Identity>,
    event: Rc<Identity>,
    edge: ExitEdge,
}

#[derive(Debug, PartialEq, Eq)]
pub(super) enum ExitEdge {
    Normal,
    Cleanup,
}

#[derive(Debug)]
enum Phase {
    Available,
    Suspended {
        loan: Rc<Identity>,
        mutation: Option<Rc<Identity>>,
    },
    Frozen,
    Poisoned,
    Retired,
}

#[derive(Debug)]
struct Record {
    stamp: Stamp,
    bytes: Box<[u8]>,
    phase: Phase,
}

#[derive(Debug, PartialEq, Eq)]
pub(super) enum Refusal {
    MissingCheckout,
    UnknownAllocationOrGeneration,
    DuplicateHandle,
    ReceiverSuspended,
    NotAvailable,
    DuplicateOrMismatchedLoan,
    Overlap,
    LengthMismatch,
    StaleSource,
    MissingMutation,
    StaleMutation,
    CleanupIsNotNormal,
}

pub(super) struct Machine {
    records: Vec<Record>,
}

impl Machine {
    pub(super) fn new() -> Self {
        Self {
            records: Vec::new(),
        }
    }

    pub(super) fn native_checkout(&mut self) -> Result<Handle, Refusal> {
        Err(Refusal::MissingCheckout)
    }

    fn record(&self, stamp: &Stamp) -> Result<&Record, Refusal> {
        self.records
            .iter()
            .find(|record| record.stamp.same(stamp))
            .ok_or(Refusal::UnknownAllocationOrGeneration)
    }

    fn record_mut(&mut self, stamp: &Stamp) -> Result<&mut Record, Refusal> {
        self.records
            .iter_mut()
            .find(|record| record.stamp.same(stamp))
            .ok_or(Refusal::UnknownAllocationOrGeneration)
    }

    pub(super) fn observe(&self, handle: &Handle) -> Result<&[u8], Refusal> {
        let record = self.record(&handle.stamp)?;
        match record.phase {
            Phase::Available => Ok(&record.bytes),
            Phase::Suspended { .. } => Err(Refusal::ReceiverSuspended),
            _ => Err(Refusal::NotAvailable),
        }
    }

    pub(super) fn get_mut_none(&mut self, handle: &Handle) -> Result<(), Refusal> {
        self.observe(handle).map(|_| ())
    }

    pub(super) fn get_mut_some(&mut self, handle: &Handle) -> Result<SliceLoan, Refusal> {
        let record = self.record_mut(&handle.stamp)?;
        if !matches!(record.phase, Phase::Available) {
            return Err(Refusal::ReceiverSuspended);
        }
        let loan = Rc::new(Identity);
        record.phase = Phase::Suspended {
            loan: Rc::clone(&loan),
            mutation: None,
        };
        Ok(SliceLoan {
            stamp: handle.stamp.witness(),
            loan,
        })
    }

    pub(super) fn freeze(&mut self, handle: &Handle) -> Result<ReadFrame, Refusal> {
        let record = self.record_mut(&handle.stamp)?;
        if !matches!(record.phase, Phase::Available) {
            return Err(Refusal::NotAvailable);
        }
        record.phase = Phase::Frozen;
        Ok(ReadFrame {
            stamp: handle.stamp.witness(),
            bytes: record.bytes.clone(),
        })
    }

    pub(super) fn thaw(&mut self, frame: ReadFrame) -> Result<(), Refusal> {
        let record = self.record_mut(&frame.stamp)?;
        if !matches!(record.phase, Phase::Frozen) || record.bytes != frame.bytes {
            return Err(Refusal::StaleSource);
        }
        record.phase = Phase::Available;
        Ok(())
    }

    fn active(&self, loan: &SliceLoan) -> Result<&Record, Refusal> {
        let record = self.record(&loan.stamp)?;
        if !matches!(&record.phase, Phase::Suspended { loan: actual, .. } if Rc::ptr_eq(actual, &loan.loan))
        {
            return Err(Refusal::DuplicateOrMismatchedLoan);
        }
        Ok(record)
    }

    pub(super) fn copy_from_slice(
        &mut self,
        loan: &SliceLoan,
        source: &ReadFrame,
    ) -> Result<NormalCopy, Refusal> {
        let destination = self.active(loan)?;
        if Rc::ptr_eq(&destination.stamp.allocation, &source.stamp.allocation) {
            return Err(Refusal::Overlap);
        }
        let original = self.record(&source.stamp)?;
        if !matches!(original.phase, Phase::Frozen) || original.bytes != source.bytes {
            return Err(Refusal::StaleSource);
        }
        if destination.bytes.len() != source.bytes.len() {
            return Err(Refusal::LengthMismatch);
        }
        let event = Rc::new(Identity);
        let record = self.record_mut(&loan.stamp)?;
        record.bytes.copy_from_slice(&source.bytes);
        record.phase = Phase::Suspended {
            loan: Rc::clone(&loan.loan),
            mutation: Some(Rc::clone(&event)),
        };
        Ok(NormalCopy {
            stamp: loan.stamp.witness(),
            loan: Rc::clone(&loan.loan),
            event,
        })
    }

    pub(super) fn writeback(
        &mut self,
        loan: SliceLoan,
        copy: NormalCopy,
        end: CheckedLoanEnd,
    ) -> Result<(), Refusal> {
        let record = self.active(&loan)?;
        if end.edge != ExitEdge::Normal {
            return Err(Refusal::CleanupIsNotNormal);
        }
        if !loan.stamp.same(&copy.stamp)
            || !loan.stamp.same(&end.stamp)
            || !Rc::ptr_eq(&loan.loan, &copy.loan)
            || !Rc::ptr_eq(&loan.loan, &end.loan)
        {
            return Err(Refusal::DuplicateOrMismatchedLoan);
        }
        let Phase::Suspended { mutation, .. } = &record.phase else {
            return Err(Refusal::DuplicateOrMismatchedLoan);
        };
        let Some(mutation) = mutation else {
            return Err(Refusal::MissingMutation);
        };
        if !Rc::ptr_eq(mutation, &copy.event) || !Rc::ptr_eq(mutation, &end.event) {
            return Err(Refusal::StaleMutation);
        }
        self.record_mut(&loan.stamp)?.phase = Phase::Available;
        Ok(())
    }

    pub(super) fn cleanup_without_normal_writeback(
        &mut self,
        loan: SliceLoan,
    ) -> Result<(), Refusal> {
        self.active(&loan)?;
        self.record_mut(&loan.stamp)?.phase = Phase::Poisoned;
        Ok(())
    }

    #[cfg(test)]
    fn control_checkout(&mut self, bytes: &[u8]) -> Handle {
        let stamp = Stamp {
            allocation: Rc::new(Identity),
            generation: Rc::new(Identity),
            handle: Rc::new(Identity),
        };
        self.records.push(Record {
            stamp: stamp.witness(),
            bytes: bytes.into(),
            phase: Phase::Available,
        });
        Handle { stamp }
    }

    #[cfg(test)]
    fn control_end(&self, loan: &SliceLoan, copy: &NormalCopy, edge: ExitEdge) -> CheckedLoanEnd {
        CheckedLoanEnd {
            stamp: loan.stamp.witness(),
            loan: Rc::clone(&loan.loan),
            event: Rc::clone(&copy.event),
            edge,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn setup() -> (Machine, Handle, Handle) {
        let mut machine = Machine::new();
        let destination = machine.control_checkout(&[1, 2, 3]);
        let source = machine.control_checkout(&[7, 8, 9]);
        (machine, destination, source)
    }

    #[test]
    fn positive_copy_suspends_and_writes_back_exact_bytes() {
        let (mut machine, destination, source) = setup();
        let frame = machine.freeze(&source).unwrap();
        let loan = machine.get_mut_some(&destination).unwrap();
        assert_eq!(
            machine.observe(&destination),
            Err(Refusal::ReceiverSuspended)
        );
        let copy = machine.copy_from_slice(&loan, &frame).unwrap();
        let end = machine.control_end(&loan, &copy, ExitEdge::Normal);
        machine.writeback(loan, copy, end).unwrap();
        assert_eq!(machine.observe(&destination).unwrap(), &[7, 8, 9]);
        machine.thaw(frame).unwrap();
        assert_eq!(machine.observe(&source).unwrap(), &[7, 8, 9]);
    }

    #[test]
    fn none_preserves_handle_generation_and_bytes() {
        let (mut machine, destination, _) = setup();
        machine.get_mut_none(&destination).unwrap();
        assert_eq!(machine.observe(&destination).unwrap(), &[1, 2, 3]);
        machine.get_mut_some(&destination).unwrap();
    }

    #[test]
    fn original_native_checkout_has_no_constructor() {
        assert_eq!(
            Machine::new().native_checkout().unwrap_err(),
            Refusal::MissingCheckout
        );
    }

    #[test]
    fn duplicate_handle_cannot_issue_second_loan() {
        let (mut machine, destination, _) = setup();
        let forged = Handle {
            stamp: destination.stamp.witness(),
        };
        machine.get_mut_some(&destination).unwrap();
        assert_eq!(
            machine.get_mut_some(&forged).unwrap_err(),
            Refusal::ReceiverSuspended
        );
    }

    #[test]
    fn duplicate_loan_cannot_resume_twice() {
        let (mut machine, destination, source) = setup();
        let frame = machine.freeze(&source).unwrap();
        let loan = machine.get_mut_some(&destination).unwrap();
        let copy = machine.copy_from_slice(&loan, &frame).unwrap();
        let end = machine.control_end(&loan, &copy, ExitEdge::Normal);
        let forged = SliceLoan {
            stamp: loan.stamp.witness(),
            loan: Rc::clone(&loan.loan),
        };
        machine.writeback(loan, copy, end).unwrap();
        assert_eq!(
            machine.active(&forged).unwrap_err(),
            Refusal::DuplicateOrMismatchedLoan
        );
    }

    #[test]
    fn stale_generation_is_not_reissued_authority() {
        let (mut machine, destination, _) = setup();
        let stale = Handle {
            stamp: Stamp {
                allocation: Rc::clone(&destination.stamp.allocation),
                generation: Rc::new(Identity),
                handle: Rc::clone(&destination.stamp.handle),
            },
        };
        assert_eq!(
            machine.get_mut_some(&stale).unwrap_err(),
            Refusal::UnknownAllocationOrGeneration
        );
    }

    #[test]
    fn overlap_refuses_before_byte_change() {
        let (mut machine, destination, _) = setup();
        let forged = ReadFrame {
            stamp: destination.stamp.witness(),
            bytes: Box::new([4, 5, 6]),
        };
        let loan = machine.get_mut_some(&destination).unwrap();
        assert_eq!(
            machine.copy_from_slice(&loan, &forged).unwrap_err(),
            Refusal::Overlap
        );
        assert_eq!(machine.active(&loan).unwrap().bytes.as_ref(), &[1, 2, 3]);
    }

    #[test]
    fn length_mismatch_is_not_normal_copy_or_rollback_claim() {
        let (mut machine, destination, _) = setup();
        let short = machine.control_checkout(&[7, 8]);
        let frame = machine.freeze(&short).unwrap();
        let loan = machine.get_mut_some(&destination).unwrap();
        assert_eq!(
            machine.copy_from_slice(&loan, &frame).unwrap_err(),
            Refusal::LengthMismatch
        );
        assert_eq!(
            machine.observe(&destination),
            Err(Refusal::ReceiverSuspended)
        );
    }

    #[test]
    fn mismatched_source_snapshot_refuses() {
        let (mut machine, destination, source) = setup();
        let mut frame = machine.freeze(&source).unwrap();
        frame.bytes[0] = 55;
        let loan = machine.get_mut_some(&destination).unwrap();
        assert_eq!(
            machine.copy_from_slice(&loan, &frame).unwrap_err(),
            Refusal::StaleSource
        );
    }

    #[test]
    fn wrong_root_and_wrong_loan_refuse() {
        let (mut machine, destination, source) = setup();
        let other = machine.control_checkout(&[0, 0, 0]);
        let frame = machine.freeze(&source).unwrap();
        let loan = machine.get_mut_some(&destination).unwrap();
        let copy = machine.copy_from_slice(&loan, &frame).unwrap();
        let mut end = machine.control_end(&loan, &copy, ExitEdge::Normal);
        end.stamp = other.stamp.witness();
        assert_eq!(
            machine.writeback(loan, copy, end),
            Err(Refusal::DuplicateOrMismatchedLoan)
        );
        assert_eq!(
            machine.observe(&destination),
            Err(Refusal::ReceiverSuspended)
        );
    }

    #[test]
    fn wrong_loan_identity_refuses_even_with_matching_root() {
        let (mut machine, destination, source) = setup();
        let frame = machine.freeze(&source).unwrap();
        let loan = machine.get_mut_some(&destination).unwrap();
        let copy = machine.copy_from_slice(&loan, &frame).unwrap();
        let mut end = machine.control_end(&loan, &copy, ExitEdge::Normal);
        end.loan = Rc::new(Identity);
        assert_eq!(
            machine.writeback(loan, copy, end),
            Err(Refusal::DuplicateOrMismatchedLoan)
        );
        assert_eq!(
            machine.observe(&destination),
            Err(Refusal::ReceiverSuspended)
        );
    }

    #[test]
    fn stale_source_generation_refuses_before_copy() {
        let (mut machine, destination, source) = setup();
        let mut frame = machine.freeze(&source).unwrap();
        frame.stamp.generation = Rc::new(Identity);
        let loan = machine.get_mut_some(&destination).unwrap();
        assert_eq!(
            machine.copy_from_slice(&loan, &frame).unwrap_err(),
            Refusal::UnknownAllocationOrGeneration
        );
    }

    #[test]
    fn early_endpoint_without_mutation_refuses() {
        let (mut machine, destination, _) = setup();
        let loan = machine.get_mut_some(&destination).unwrap();
        let event = Rc::new(Identity);
        let copy = NormalCopy {
            stamp: loan.stamp.witness(),
            loan: Rc::clone(&loan.loan),
            event,
        };
        let end = machine.control_end(&loan, &copy, ExitEdge::Normal);
        assert_eq!(
            machine.writeback(loan, copy, end),
            Err(Refusal::MissingMutation)
        );
    }

    #[test]
    fn stale_writeback_after_later_copy_refuses() {
        let (mut machine, destination, source) = setup();
        let frame = machine.freeze(&source).unwrap();
        let loan = machine.get_mut_some(&destination).unwrap();
        let old_copy = machine.copy_from_slice(&loan, &frame).unwrap();
        let old_end = machine.control_end(&loan, &old_copy, ExitEdge::Normal);
        machine.copy_from_slice(&loan, &frame).unwrap();
        assert_eq!(
            machine.writeback(loan, old_copy, old_end),
            Err(Refusal::StaleMutation)
        );
    }

    #[test]
    fn cleanup_never_credits_normal_byte_writeback() {
        let (mut machine, destination, source) = setup();
        let frame = machine.freeze(&source).unwrap();
        let loan = machine.get_mut_some(&destination).unwrap();
        let copy = machine.copy_from_slice(&loan, &frame).unwrap();
        let end = machine.control_end(&loan, &copy, ExitEdge::Cleanup);
        assert_eq!(
            machine.writeback(loan, copy, end),
            Err(Refusal::CleanupIsNotNormal)
        );
        assert_eq!(
            machine.observe(&destination),
            Err(Refusal::ReceiverSuspended)
        );
    }

    #[test]
    fn unwind_poison_has_no_resumption_or_rollback() {
        let (mut machine, destination, source) = setup();
        let frame = machine.freeze(&source).unwrap();
        let loan = machine.get_mut_some(&destination).unwrap();
        machine.copy_from_slice(&loan, &frame).unwrap();
        machine.cleanup_without_normal_writeback(loan).unwrap();
        assert_eq!(machine.observe(&destination), Err(Refusal::NotAvailable));
    }

    #[test]
    fn restoration_after_length_mutant_preserves_conservation() {
        for short_length in 0..3 {
            let (mut machine, destination, _) = setup();
            let short = machine.control_checkout(&vec![0; short_length]);
            let short_frame = machine.freeze(&short).unwrap();
            let restored = machine.control_checkout(&[9, 8, 7]);
            let restored_frame = machine.freeze(&restored).unwrap();
            let loan = machine.get_mut_some(&destination).unwrap();
            assert_eq!(
                machine.copy_from_slice(&loan, &short_frame).unwrap_err(),
                Refusal::LengthMismatch
            );
            let copy = machine.copy_from_slice(&loan, &restored_frame).unwrap();
            let end = machine.control_end(&loan, &copy, ExitEdge::Normal);
            machine.writeback(loan, copy, end).unwrap();
            assert_eq!(machine.observe(&destination).unwrap(), &[9, 8, 7]);
        }
    }

    #[test]
    fn byte_patterns_and_lengths_survive_normal_writeback() {
        for length in 0..33 {
            for pattern in [0, 1, 127, 255] {
                let mut machine = Machine::new();
                let destination = machine.control_checkout(&vec![11; length]);
                let expected = vec![pattern; length];
                let source = machine.control_checkout(&expected);
                let frame = machine.freeze(&source).unwrap();
                let loan = machine.get_mut_some(&destination).unwrap();
                let copy = machine.copy_from_slice(&loan, &frame).unwrap();
                let end = machine.control_end(&loan, &copy, ExitEdge::Normal);
                machine.writeback(loan, copy, end).unwrap();
                assert_eq!(machine.observe(&destination).unwrap(), expected);
            }
        }
    }
}
