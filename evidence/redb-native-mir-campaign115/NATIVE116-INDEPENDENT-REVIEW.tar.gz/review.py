import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import tarfile
import time

ROOT = Path(__file__).parent
WORKER = Path('/private/tmp/redb-native-mir-observer116-20261108T164457Z')
PARENT = Path('/private/tmp/redb-native116-parent-handoff-20261108T1727Z')
START_NS = 1794158967464587008
DEADLINE_NS = START_NS + 900_000_000_000
LIMIT = 128 * 1024 * 1024
FLOOR = 16 * 1024 * 1024 * 1024
SAMPLES = []

def guard():
    free = shutil.disk_usage(ROOT).free
    logical = sum(path.stat().st_size for path in ROOT.rglob('*') if path.is_file())
    allocated = sum(path.stat().st_blocks * 512 for path in ROOT.rglob('*') if path.is_file())
    sample = dict(epoch_ns=time.time_ns(), free_bytes=free, scratch_bytes=logical, allocated_bytes=allocated)
    SAMPLES.append(sample)
    if free <= FLOOR or max(logical, allocated) > LIMIT or time.time_ns() >= DEADLINE_NS:
        raise RuntimeError('STOP_RESOURCE_OR_TIME_LIMIT: ' + str(sample))

def load(path):
    return json.loads(Path(path).read_text())

def digest(path):
    hasher = hashlib.sha256()
    with Path(path).open('rb') as stream:
        while chunk := stream.read(1024 * 1024):
            hasher.update(chunk)
    return hasher.hexdigest()

def write(name, value):
    guard()
    path = ROOT / name
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.flush()
        os.fsync(stream.fileno())
    return path

def authenticate(stage):
    guard()
    expected = {
        'MANIFEST.json': 'ccf82f5db4b9ba3cbb8adb43119e529b9cea4b09f4884b1e8b279b0b011adcc2',
        'WORKER-PAYLOADS.json': '1f53863ae0e158c98594b8b456aca8b834190b017ab9383060ca4dc0dcc3ae16',
        'SOURCE-AND-RECEIPTS.tar.gz': '2433feedc32703409fe42a8701d24c172ee8ef3e5b8333a415974f94e96f0a87',
    }
    records = []
    def check(path, wanted, size=None, category=None):
        actual = digest(path)
        observed_size = Path(path).stat().st_size
        matched = actual == wanted and (size is None or size == observed_size)
        records.append(dict(path=str(path), sha256=actual, bytes=observed_size,
                            expected_sha256=wanted, match=matched, category=category))
    for name, wanted in expected.items():
        check(PARENT / name, wanted, category='parent_pins')
    for entry in load(PARENT / 'MANIFEST.json')['records']:
        check(PARENT / entry['path'], entry['sha256'], entry['bytes'], 'parent_payload_5')
    payloads = load(PARENT / 'WORKER-PAYLOADS.json')['records']
    for entry in payloads:
        check(WORKER / entry['path'], entry['sha256'], entry['bytes'], 'worker_payload_177')
    for name in ['exit-authentication.json', 'LIBC-ENTRY.json']:
        entries = load(WORKER / name)['records']
        for index, entry in enumerate(entries):
            if index % 100 == 0:
                guard()
            check(entry['path'], entry['sha256'], entry['bytes'], name)
    binding = load(WORKER / 'BUILD-BINDING.json')
    check(binding['source'], binding['source_sha256'], category='binding_source')
    check(binding['executable'], binding['executable_sha256'], category='binding_executable')
    for entry in binding['libc_metadata']:
        check(entry['path'], entry['sha256'], category='binding_metadata')
    archive_checks = []
    with tarfile.open(PARENT / 'SOURCE-AND-RECEIPTS.tar.gz', 'r:gz') as archive:
        expected_members = {entry['path']: entry for entry in payloads}
        for member in archive:
            stream = archive.extractfile(member) if member.isfile() else None
            value = hashlib.sha256(stream.read()).hexdigest() if stream else None
            entry = expected_members.get(member.name)
            archive_checks.append(dict(path=member.name, bytes=member.size, sha256=value,
                                       match=entry is not None and value == entry['sha256']
                                       and member.size == entry['bytes']))
    failures = [entry for entry in records + archive_checks if not entry['match']]
    counts = {category: sum(entry['category'] == category for entry in records)
              for category in sorted({entry['category'] for entry in records})}
    value = dict(epoch_ns=time.time_ns(), stage=stage, records=records, counts=counts,
                 archive_members=archive_checks, failures=failures,
                 original_worker_status='INTERRUPTED_BEFORE_FINAL_SEAL',
                 platform_transitive_closure='NOT_ESTABLISHED', trust=0, native_proof_credit=0)
    write('authentication-' + stage + '.json', value)
    print('AUTHENTICATION', stage, counts, 'archive', len(archive_checks), 'failures', len(failures), flush=True)
    if failures or len(archive_checks) != 177 or len({entry['path'] for entry in archive_checks}) != 177:
        raise RuntimeError('authentication failed')

def historical():
    guard()
    binding = load(WORKER / 'BUILD-BINDING.json')
    rows = []
    for indexed in load(WORKER / 'RECEIPTS-INDEX.json')['records']:
        receipt_path = Path(indexed['files']['receipt.json']['path'])
        registration_path = Path(indexed['files']['registration.json']['path'])
        receipt = load(receipt_path)
        registration = load(registration_path)
        plan_path = Path(registration['plan']) if isinstance(registration['plan'], str) else None
        row = dict(name=receipt_path.parent.name,
                   indexed_file_hashes={key: digest(entry['path']) == entry['sha256']
                                        for key, entry in indexed['files'].items()},
                   exit_code=receipt['exit_code'], started_ns=receipt['started_ns'],
                   ended_ns=receipt['ended_ns'], errors=receipt['errors'],
                   plan_sha256=registration['plan_sha256'],
                   plan_path=str(plan_path),
                   plan_hash_matches=digest(plan_path) == registration['plan_sha256'] if plan_path else None)
        if row['name'] == 'observer-build-3-full-raw-calls':
            row['binding_plan_match'] = digest(plan_path) == binding['build_plan_sha256'] if plan_path else None
            row['binding_receipt_match'] = digest(receipt_path) == binding['build_receipt_sha256']
            row['binding_registration_match'] = digest(registration_path) == binding['build_registration_sha256']
            row['source_before'] = registration['inputs_before'].get(binding['source'])
            row['source_after'] = receipt['inputs_after'].get(binding['source'])
            row['executable_after'] = receipt['outputs_after'].get(binding['executable'])
        rows.append(row)
    captures = []
    for indexed in load(WORKER / 'CAPTURE-INDEX.json')['records']:
        report = load(indexed['path'])
        for capture in report['captures']:
            captures.append(dict(name=indexed['name'], definition=capture['def_path'],
                                 native=capture['native_capture_phase'], phase=capture['mir_phase'],
                                 calls=len(capture['calls']), drops=len(capture['drops']),
                                 raw_mir=bool(capture.get('raw_elaborated_body_debug')),
                                 typed_builder=capture.get('all_typed_builder_temporary_observations') is not None))
    write('historical-review.json', dict(epoch_ns=time.time_ns(), receipts=rows, captures=captures))
    print('HISTORICAL', len(rows), 'commands', len(captures), 'captures',
          sum(entry['calls'] for entry in captures), 'calls', sum(entry['drops'] for entry in captures), 'drops', flush=True)

def run_cases():
    guard()
    prior = load(WORKER / 'plans/original-header-complete.json')
    executable = prior['argv'][0]
    definition = prior['argv'][4]
    native_source = prior['argv'][6]
    libc = prior['argv'][8]
    sysroot = prior['argv'][10]
    environment = dict(prior['environment'])
    environment['TMPDIR'] = str(ROOT / 'tmp')
    (ROOT / 'tmp').mkdir()
    (ROOT / 'empty-sysroot').mkdir()
    cases = [
        ('header', definition, [], 2),
        ('wrong-qualified', definition.replace('TransactionalMemory', 'PageManager'), [], 65),
        ('seeded-report', definition, [], 64),
        ('extra-output', definition, ['--emit=link'], 64),
        ('link-only', definition, ['--link-only'], 64),
        ('compiler-failure', definition, [], 70),
    ]
    results = []
    native_records = [entry for entry in load(WORKER / 'exit-authentication.json')['records']
                      if entry['path'].startswith('/private/tmp/redb-original-crate-preflight115/redb/')]
    for name, selected, extra, expected_exit in cases:
        guard()
        case_root = ROOT / 'cases' / name
        case_root.mkdir(parents=True)
        report_path = case_root / 'report.json'
        if name == 'seeded-report':
            report_path.write_bytes(b'REVIEW116_SENTINEL_DO_NOT_REPLACE\n')
        argv = [executable, '--report', str(report_path), '--definition', selected,
                '--crate-source', native_source, '--libc', libc, '--sysroot',
                str(ROOT / 'empty-sysroot') if name == 'compiler-failure' else sysroot] + extra
        binding = load(WORKER / 'BUILD-BINDING.json')
        selected_paths = [binding['source'], executable, native_source, libc,
                          str(Path(sysroot) / 'bin/rustc')]
        selected_inputs = [dict(path=path, sha256=digest(path), bytes=Path(path).stat().st_size)
                           for path in selected_paths]
        report_before = digest(report_path) if report_path.exists() else None
        registration = dict(epoch_ns=time.time_ns(), argv=argv, environment=environment,
                            cwd=str(case_root), timeout_seconds=90, total_deadline_epoch_ns=DEADLINE_NS,
                            selected_inputs=selected_inputs, original_native_records=native_records,
                            source_unchanged=True, expected_exit=expected_exit,
                            expected_facts={
                                'header': 'one exact target, native Runtime(PostCleanup), e78->_20 WritablePage, normal bb16 and cleanup bb19, 11 calls, exit2 refuses proof',
                                'wrong-qualified': 'no selected definition/capture/explicit selected query; same-name candidates allowed; exit65',
                                'seeded-report': 'exit64, existing sentinel unchanged, no stage/report publication',
                                'extra-output': 'fixed CLI refuses extra --emit=link before compiler, exit64, no report',
                                'link-only': 'fixed CLI refuses extra --link-only before compiler, exit64, no report',
                                'compiler-failure': 'unchanged original redb; intentional empty sysroot; missing std diagnostic, exit70, no proof or capture'
                            }[name], report_before_sha256=report_before,
                            build_binding=binding, no_build=True, no_native_application_execution=True)
        registration_path = write('cases/' + name + '/registration.json', registration)
        registration_hash = digest(registration_path)
        guard()
        started_ns = time.time_ns()
        timed_out = False
        with (case_root / 'stdout.bin').open('xb') as stdout, (case_root / 'stderr.bin').open('xb') as stderr:
            process = subprocess.Popen(argv, cwd=case_root, env=environment,
                                       stdout=stdout, stderr=stderr, start_new_session=True)
            try:
                while process.poll() is None:
                    guard()
                    if time.time_ns() - started_ns > 90_000_000_000:
                        timed_out = True
                        raise RuntimeError('case timeout')
                    time.sleep(0.1)
            except BaseException:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait()
                raise
        ended_ns = time.time_ns()
        guard()
        input_after = [dict(path=entry['path'], sha256=digest(entry['path']),
                            match=digest(entry['path']) == entry['sha256']) for entry in selected_inputs]
        report = load(report_path) if report_path.exists() and name != 'seeded-report' else None
        checks = dict(exit_matches=process.returncode == expected_exit,
                      registration_predates_launch=registration['epoch_ns'] < started_ns,
                      registration_unchanged=digest(registration_path) == registration_hash,
                      selected_inputs_unchanged=all(entry['match'] for entry in input_after),
                      timeout_ok=not timed_out and ended_ns - started_ns <= 90_000_000_000)
        if report:
            checks['proof_refused'] = report['proof_acceptance'] is False and report['native_checked_proof_bodies'] == 0
            if name == 'header':
                capture = report['captures'][0] if len(report['captures']) == 1 else {}
                checks.update(one_exact_definition=report['selected_definitions'] == [definition],
                              one_explicit_query=report['explicit_selected_query_requests'] == 1,
                              native_runtime=capture.get('native_capture_phase') is True and capture.get('mir_phase') == 'Runtime(PostCleanup)',
                              eleven_calls=len(capture.get('calls', [])) == 11,
                              raw_mir=bool(capture.get('raw_elaborated_body_debug')),
                              header_drop_facts=all(any(drop['block'] == block and drop['cleanup'] == cleanup
                                  and drop['local'] == 20 and drop['root_type'].endswith('::WritablePage')
                                  and len(drop['matching_temporary_observations']) == 1
                                  and drop['matching_temporary_observations'][0]['expression'] == 'e78'
                                  for drop in capture.get('drops', [])) for block, cleanup in [(16, False), (19, True)]))
            elif name == 'wrong-qualified':
                checks.update(no_selected=report['selected_definitions'] == [], no_capture=report['captures'] == [],
                              no_explicit_query=report['explicit_selected_query_requests'] == 0)
            elif name == 'compiler-failure':
                checks.update(compiler_did_not_complete=report['compiler_completed_without_panic'] is False,
                              no_after_analysis=report['after_analysis_reached'] is False,
                              no_captures=report['captures'] == [])
        elif name in ['header', 'wrong-qualified', 'compiler-failure']:
            checks['expected_report_present'] = False
        if name == 'seeded-report':
            checks['sentinel_unchanged'] = digest(report_path) == report_before
            checks['no_staging_file'] = not list(case_root.glob('.*observer-stage*'))
        if name in ['extra-output', 'link-only']:
            checks['no_report'] = not report_path.exists()
            checks['no_staging_file'] = not list(case_root.glob('.*observer-stage*'))
        receipt = dict(name=name, pid=process.pid, started_ns=started_ns, ended_ns=ended_ns,
                       exit_code=process.returncode, reaped=True, timed_out=timed_out,
                       registration_sha256=registration_hash, checks=checks,
                       selected_inputs_after=input_after,
                       stdout_sha256=digest(case_root / 'stdout.bin'), stderr_sha256=digest(case_root / 'stderr.bin'),
                       stderr_text=(case_root / 'stderr.bin').read_text(errors='replace'),
                       report_sha256=digest(report_path) if report_path.exists() else None,
                       case_files=[dict(path=str(path), bytes=path.stat().st_size, sha256=digest(path))
                                   for path in case_root.iterdir() if path.is_file()])
        write('cases/' + name + '/receipt.json', receipt)
        results.append(receipt)
        print('CASE', name, process.returncode, checks, flush=True)
    write('fresh-diagnostics.json', dict(epoch_ns=time.time_ns(), fresh_cases=len(results), cases=results,
                                       resource_samples=SAMPLES, historical_allowances_reset=False,
                                       trust=0, native_proof_credit=0, all18='OPEN'))

def supplement():
    guard()
    binding = load(WORKER / 'BUILD-BINDING.json')
    rows = []
    for indexed in load(WORKER / 'RECEIPTS-INDEX.json')['records']:
        receipt_path = Path(indexed['files']['receipt.json']['path'])
        name = receipt_path.parent.name
        receipt = load(receipt_path)
        registration_path = Path(indexed['files']['registration.json']['path'])
        registration = load(registration_path)
        plan_path = WORKER / 'plans' / (name + '.json')
        row = dict(name=name, plan_path=str(plan_path),
                   plan_sha256=digest(plan_path),
                   plan_hash_matches=digest(plan_path) == registration['plan_sha256'],
                   embedded_plan_matches=registration['plan'] == load(plan_path),
                   input_content_changes=[path for path, before in registration['inputs_before'].items()
                       if receipt['inputs_after'].get(path, {}).get('sha256') != before.get('sha256')],
                   selected_inputs_sampled_before_launch=all(
                       before['sampled_ns'] < receipt['started_ns']
                       for before in registration['inputs_before'].values()),
                   elapsed_ns=receipt['ended_ns'] - receipt['started_ns'])
        if name == 'observer-build-3-full-raw-calls':
            row['binding_plan_matches'] = digest(plan_path) == binding['build_plan_sha256']
        target_path = WORKER / 'plans' / (name + '.target-registration.json')
        if target_path.exists():
            target = load(target_path)
            row['target_registration_predates_launch'] = target['epoch_ns'] < receipt['started_ns']
            row['target_executable_matches_final'] = target['executable_sha256'] == binding['executable_sha256']
            row['target_source_matches_final'] = target['observer_source_sha256'] == binding['source_sha256']
        rows.append(row)
    registration = load(WORKER / 'records/original-header-complete/registration.json')
    toolchain = []
    for path, entry in registration['inputs_before'].items():
        if '/.rustup/' in path and entry.get('sha256'):
            guard()
            toolchain.append(dict(path=path, sha256=digest(path),
                                  expected_sha256=entry['sha256'], match=digest(path) == entry['sha256']))
    fresh = []
    for case_root in sorted((ROOT / 'cases').iterdir()):
        if not case_root.is_dir():
            continue
        receipt = load(case_root / 'receipt.json')
        registration = load(case_root / 'registration.json')
        report_path = case_root / 'report.json'
        report = load(report_path) if report_path.exists() and case_root.name != 'seeded-report' else None
        report_summary = None
        if report:
            report_summary = {key: value for key, value in report.items() if key != 'captures'}
            report_summary['capture_coverage'] = [dict(
                definition=capture['def_path'], phase=capture['mir_phase'], native=capture['native_capture_phase'],
                raw_mir_bytes=len(capture['raw_elaborated_body_debug'].encode()),
                raw_builder_binding_bytes=len(capture['raw_builder_bindings_debug'].encode()),
                raw_builder_temporaries_bytes=len(capture['raw_builder_temporary_capture_debug'].encode()),
                typed_observations=len(capture['all_typed_builder_temporary_observations']),
                calls=capture['calls'], drops=capture['drops']) for capture in report['captures']]
        published = report.get('report_staging_path_retained') if report else None
        fresh.append(dict(name=case_root.name, report=report_summary,
                          report_and_stage_same_inode=bool(published) and os.stat(published).st_ino == os.stat(report_path).st_ino,
                          files=[path.name for path in case_root.iterdir()],
                          expected_checks_all_true=all(receipt['checks'].values()),
                          elapsed_ns=receipt['ended_ns'] - receipt['started_ns'],
                          native_records_preregistered=len(registration['original_native_records'])))
    write('correspondence-supplement.json', dict(epoch_ns=time.time_ns(), receipts=rows,
        toolchain_current_readback=toolchain,
        toolchain_timing_limit='Current supplemental readback after fresh runs, not retrofitted as fresh preregistration/entry observation; fresh registrations pin observer executable and rustc binary, not full loader closure.',
        initial_historical_review_limit='Initial historical-review.json did not resolve embedded plan objects to files and records null plan comparisons; this additive readback checks original plan bytes and embedded plan equality without changing original receipts.',
        fresh=fresh, resource_samples=SAMPLES))
    print('SUPPLEMENT', len(rows), 'receipts; plans matched', all(row['plan_hash_matches'] and row['embedded_plan_matches'] for row in rows),
          'toolchain readback', len(toolchain), 'mismatches', sum(not entry['match'] for entry in toolchain), flush=True)

def coverage():
    guard()
    calls = []
    drops = []
    rows = []
    for indexed in load(WORKER / 'CAPTURE-INDEX.json')['records']:
        report = load(indexed['path'])
        for capture in report['captures']:
            raw = capture['raw_elaborated_body_debug']
            raw_path = WORKER / 'raw-mir' / (indexed['name'] + '.body-debug.txt')
            row = dict(case=indexed['name'], definition=capture['def_path'],
                       raw_body_file_matches=raw_path.read_text() == raw,
                       every_call_terminator_in_raw=all(call['terminator'] in raw for call in capture['calls']),
                       calls=len(capture['calls']), drops=len(capture['drops']),
                       typed_observations=len(capture['all_typed_builder_temporary_observations']),
                       raw_temporary_origin_count=capture['raw_builder_temporary_capture_debug'].count('TemporaryOrigin {'),
                       native=capture['native_capture_phase'], phase=capture['mir_phase'],
                       raw_binder_capture_present=bool(capture['raw_builder_bindings_debug']))
            row['typed_and_raw_observation_counts_match'] = row['typed_observations'] == row['raw_temporary_origin_count']
            rows.append(row)
            calls.extend(dict(call, case=indexed['name'], def_path=capture['def_path']) for call in capture['calls'])
            drops.extend(dict(drop, case=indexed['name'], def_path=capture['def_path']) for drop in capture['drops'])
    canonical = lambda values: sorted(json.dumps(value, sort_keys=True) for value in values)
    current_tools = []
    for entry in load(ROOT / 'correspondence-supplement.json')['toolchain_current_readback']:
        guard()
        current_tools.append(dict(path=entry['path'], sha256=digest(entry['path']),
                                  match=digest(entry['path']) == entry['expected_sha256']))
    write('capture-coverage.json', dict(epoch_ns=time.time_ns(), captures=rows,
        captures_count=len(rows), definitions_count=len({row['definition'] for row in rows}),
        calls_count=len(calls), drops_count=len(drops),
        all_calls_index_matches=canonical(calls) == canonical(load(WORKER / 'ALL-CALLS.json')['records']),
        all_drops_index_matches=canonical(drops) == canonical(load(WORKER / 'ALL-DROPS.json')['records']),
        toolchain_supplemental_exit_readback=current_tools,
        no_unique_resource_events_inferred=True))
    print('COVERAGE', len(rows), 'captures', len(calls), 'calls', len(drops), 'drops', flush=True)

def seal():
    guard()
    entry = load(ROOT / 'authentication-entry.json')
    exit_auth = load(ROOT / 'authentication-exit.json')
    fresh = load(ROOT / 'fresh-diagnostics.json')
    correspondence = load(ROOT / 'correspondence-supplement.json')
    capture_coverage = load(ROOT / 'capture-coverage.json')
    checks = dict(
        entry_and_exit_clean=not entry['failures'] and not exit_auth['failures'],
        six_fresh_cases=len(fresh['cases']) == 6,
        all_fresh_expectations_match=all(all(case['checks'].values()) for case in fresh['cases']),
        all_historical_plan_bindings=all(row['plan_hash_matches'] and row['embedded_plan_matches'] for row in correspondence['receipts']),
        historical_selected_inputs_unchanged=all(not row['input_content_changes'] for row in correspondence['receipts']),
        all_raw_capture_coverage=all(row['raw_body_file_matches'] and row['every_call_terminator_in_raw']
            and row['typed_and_raw_observation_counts_match'] for row in capture_coverage['captures']),
        call_and_drop_indices_match=capture_coverage['all_calls_index_matches'] and capture_coverage['all_drops_index_matches'],
        toolchain_supplemental_readbacks_clean=all(row['match'] for row in correspondence['toolchain_current_readback']
            + capture_coverage['toolchain_supplemental_exit_readback']))
    if not all(checks.values()):
        raise RuntimeError(str(checks))
    samples = fresh['resource_samples'] + correspondence['resource_samples'] + SAMPLES
    write('REVIEW-RESULT.json', dict(epoch_ns=time.time_ns(), verdict='PARTIAL_DIAGNOSTIC_ONLY_NO_ADOPTION',
        checks=checks, original_worker_status='INTERRUPTED_BEFORE_FINAL_WORKER_SEAL',
        historical_managed_commands=20, fresh_observer_cases=6,
        review_builds=0, review_cargo_invocations=0, review_verifier_solver_native_app_executions=0,
        source_credit=0, native_proof_credit=0, trust=0, native_checked_proof_bodies=0, all18='OPEN',
        no_mapping_approval=True, no_strict_independent_oracle_pass=True, no_generic_helper_adoption=True,
        repair118_not_adopted=True, platform_and_transitive_closure='UNESTABLISHED',
        findings=[
            dict(severity='P2', kind='handoff_scope', title='Original worker handoff remains interrupted and unsealed',
                 diagnostic_retention_blocking=False, original_completion_claim_blocking=True),
            dict(severity='P3', kind='schema', title='same_name_candidates_not_forced_by_observer includes selected target', blocking=False),
            dict(severity='P3', kind='classification', title='RAW_MIR_CAPTURE_NOT_NATIVE_PROOF label persists in compiler failure with zero captures; consult exit70 and status fields', blocking=False)],
        resource_summary=dict(minimum_sampled_free_bytes=min(sample['free_bytes'] for sample in samples),
                              maximum_sampled_scratch_bytes=max(sample['scratch_bytes'] for sample in samples),
                              strict_free_floor_bytes=FLOOR, scratch_limit_bytes=LIMIT),
        first_review_command_epoch_ns=START_NS, deadline_epoch_ns=DEADLINE_NS,
        next_smallest_edge='Diagnostic identity-only bridge from original write_header _20 drop sites bb16/bb19 to the exact WritablePage destructor/drop-glue instance; source return_value call is not an admitted resource effect. No further execution authorized or performed.'))
    paths = sorted(path for path in ROOT.rglob('*') if path.is_file())
    manifest = dict(version=1, epoch_ns=time.time_ns(), root=str(ROOT),
                    scope='Independent review artifacts only; external parent and worker retained in place, pins and entry/exit authentication included; no reconstructed original worker seal.',
                    records=[dict(path=str(path.relative_to(ROOT)), bytes=path.stat().st_size, sha256=digest(path)) for path in paths])
    manifest_path = write('MANIFEST.json', manifest)
    readback = all(digest(ROOT / entry['path']) == entry['sha256'] and (ROOT / entry['path']).stat().st_size == entry['bytes'] for entry in manifest['records'])
    if not readback:
        raise RuntimeError('manifest readback failed')
    guard()
    sealed_ns = time.time_ns()
    write('SEAL.json', dict(version=1, epoch_ns=sealed_ns, manifest_sha256=digest(manifest_path),
                           readback_members=len(manifest['records']), readback_all_match=True,
                           elapsed_ns=sealed_ns-START_NS, within_15_minutes=sealed_ns < DEADLINE_NS,
                           review_seal_only=True, worker_final_seal_created=False,
                           final_resource_sample=SAMPLES[-1]))
    print('SEALED', digest(manifest_path), 'members', len(manifest['records']), 'elapsed_seconds', (sealed_ns-START_NS)/1e9, flush=True)

guard()
if sys.argv[1] == 'entry':
    authenticate('entry')
    historical()
elif sys.argv[1] == 'cases':
    run_cases()
elif sys.argv[1] == 'exit':
    authenticate('exit')
elif sys.argv[1] == 'supplement':
    supplement()
elif sys.argv[1] == 'coverage':
    coverage()
elif sys.argv[1] == 'seal':
    seal()
else:
    raise RuntimeError('unknown operation')
