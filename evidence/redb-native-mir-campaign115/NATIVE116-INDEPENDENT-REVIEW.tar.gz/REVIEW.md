# Independent review of actual built native-MIR observer116

## Disposition and boundaries

PARTIAL, DIAGNOSTIC-ONLY, NO ADOPTION. The actual final source and executable were independently reviewed, rather than relying on source review119 of unbuilt revision2. Six new sequential, offline observer executions were performed in place, using unchanged original redb source. No builds, Cargo, verifier, solver, native application execution, network, Git, source integration, laws, or admission changes were performed. No subdelegation or followup chain was started. Repair118 was neither used nor adopted.

Source credit 0; native proof credit 0; trust 0; native checked proof bodies 0; all18 OPEN. Matching the bounded preregistered diagnostic expectations is not a strict independent-oracle pass, mapping approval, generic provenance-helper adoption, Verus admission, or proof of native resource behavior.

## Findings and objections

- **P2, handoff/completion scope:** Original worker116 is terminal interrupted at **2026-11-08T17:02:52.937Z**, following resource-safety cancellation. Its final worker seal/report is absent. The parent archive is post-interruption preservation, not a completed original worker handoff; this review seal is not a substitute. Retaining authenticated raw diagnostics is defensible, but representing worker116 as completed is not. Historical allowances remain historical; the 20 managed commands are not reset by this review's six-case permission.
- **P3, nonblocking schema defect:** `same_name_candidates_not_forced_by_observer` includes the exact selected target. The fresh header report lists `TransactionalMemory::write_header` there while also recording one explicit selected query. This is a same-name candidate inventory, not proof that each listed candidate was unforced. Earlier ordinary compiler queries also run; fresh header elaboration-provider count is 126, versus one explicit observer request.
- **P3, nonblocking classification ambiguity:** The intentionally induced compiler failure still has top-level classification `RAW_MIR_CAPTURE_NOT_NATIVE_PROOF`, despite zero captures. The actual exit is 70, `compiler_completed_without_panic=false`, `after_analysis_reached=false`, and captures are empty. Consumers must inspect exit/status/captures rather than interpreting that classification string as capture success. Exit70 also covers publication failure by source inspection; this is not a fine-grained failure taxonomy and is not an admission path.

No additional blocking defect was demonstrated within the permitted diagnostic-only review. The unresolved handoff and compiler/platform correspondence limits remain objections to any stronger completion/trust claim, not grounds for inventing native proof credit.

## Authentication and build/receipt correspondence

`authentication-entry.json` and `authentication-exit.json` independently rehash all **177** non-target worker payloads and all **2,654** selected input records: **2,201** `exit-authentication.json` records plus **453** `LIBC-ENTRY.json` records. They check the parent manifest pin and its **five** payloads, the supplied archive/inventory hashes, and stream-read all **177** archive members without extraction. The executable, compiler source, and audited libc metadata are checked explicitly at both boundaries. External targets, toolchains, caches, and native source trees remain in place and were not copied.

Pinned final source SHA256: `a3108ccdd8f57a5e62d920670d7b1972225d0f16cca34845c03e8e3d70f39922`.

Pinned executable SHA256: `2e51324f3c5f92df35bc23921bc62af67921668a39678cdd8cd41f785197d214`.

Pinned audited libc metadata SHA256: `964becb973a8749cc06fa4c95e0916fd6755b5ee282547950f4fa3d2c936327c`.

The source is worker `src/main.rs`; the executable is worker `target-observer/debug/redb-native-mir-observer`. Final build receipt `observer-build-3-full-raw-calls` records the final source hash before and after compilation and the current executable hash after compilation. Its plan, receipt, and registration hashes match `BUILD-BINDING.json`. All 20 historical indexed receipt/registration/stdout/stderr hashes match; original plan bytes match registration plan hashes and embedded plans. Target registrations match the final source/executable and precede recorded launch times. Selected historical input content is unchanged between each receipt's recorded boundaries.

`historical-review.json` initially leaves plan comparisons null because registrations embed plan objects instead of plan paths. The additive `correspondence-supplement.json` resolves and checks original plan files without editing original evidence or claiming the initial null checks passed. The local review collector is scratch instrumentation, not an adopted provenance attestation system.

Historical setup failure remains recorded: build1 failed while creating an incremental compilation directory. The retained environment correction changes the incremental/debug profile. The first libc inventory was taken only after the first successful libc build; the independent audited fresh libc rebuild has separate preregistration and before/after selection. `DISCOVERY-CORRECTION.md` correctly discloses that the first intended discovery actually selected the exact header and exited2 with a capture. Missing/truncated initial exploration timestamps and raw terminal streams remain documentary limitations; no retrospective timestamps were supplied.

## Final source review

References are to the authenticated final `src/main.rs` (285 lines).

- Lines32-36 require the whole compiler definition path, not a suffix-only match. Lines157-176 enumerate qualified body owners, establish exactly one target, and only then issue an explicit selected elaboration query. The provider hook can also observe compiler-initiated elaboration queries, so this does not mean only one whole-crate compiler query occurs.
- Lines182-212 fix the ten-argument CLI, require a qualified target and canonical absolute report parent, and refuse an existing destination. Lines229-239 construct their own metadata-only lib/default/std rustc arguments; arbitrary compiler flags cannot be forwarded. Lines178 and272 stop after analysis and report no observer-requested code generation. Metadata-only ordinary rustc typechecking is not Verus admission.
- Lines214-220 reserve a staging file using `create_new`; lines273-276 flush/sync it and publish using `hard_link` without overwriting a destination. Seeded destination preservation was rechecked. Successful fresh reports and retained stages share an inode. No race-injection or crash/power-loss test was performed; directory fsync and complete crash-durable publication were not established. A hard link alone is not an authenticity boundary against later filesystem writes, hence the sealed hashes.
- Lines240-246 catch compiler unwinding, require after-analysis plus one selected definition and one capture before the diagnostic observation predicate can hold. Lines277-284 return70 on compiler/publication failure,65 on missing/nonunique observation, and **2**, never positive0, on a successful capture with explicit proof refusal.
- Lines39-137 retain the complete body Debug representation, raw builder bindings/temporary capture, local types/spans, call terminators/callee definition/type/span, and drop details including normal/cleanup status, projection, unwind, and matching temporary observations. Destructor identity, drop-glue identity, unique occurrence, and resource effects are explicitly not established.
- The selected builder source records `as_temp_inner` observations and scope wrappers, and marks a capture complete when retaining the builder. It preserves repeated records and fixed-temporary reuse; `complete` is not a global provenance theorem. Typed observations use the captured MIR local declaration's type, not independently authenticated expression semantics. The `native` marker is set by `begin(true)`; the separately observed MIR phase and original source binding provide diagnostic context, not compiler correctness or native proof.

## Historical and fresh capture coverage

Historical evidence contains **six capture instances / five definitions**, **145 calls /31 drops**, including the repeated header. All six raw body files match the corresponding report strings; every structured call terminator appears in the corresponding raw body. Aggregated call/drop indexes match the per-report records. Raw builder temporary-origin counts match the corresponding typed observation counts. These checks preserve capture coverage; they do not count unique runtime events, ownership identities, or resource effects.

The original header is `tree_store::page_store::page_manager::TransactionalMemory::write_header` in unchanged original redb. Both old and fresh captures report **native=true, Runtime(PostCleanup)**, expression **e78 -> _20**, root type **WritablePage**, normal drop **bb16** (normal target17, unwind cleanup20), and cleanup drop **bb19** (normal target20, unwind terminate-cleanup). Each drop has one matching temporary observation, but the same local match appears at both CFG sites. This is not uniqueness of a dynamic event or glue identity. There are **11 calls**, including `PagedCachedFile::write`, `WritablePage::mem_mut`, and `copy_from_slice`; the multi-process direct-write branch is also present.

Fresh registrations were fsynced before launch and retain exact executable/source/rustc hashes, all132 original native input records, exact argv, complete replacement environment, cwd, and expected diagnostic facts. Each case retains raw stdout/stderr, actual integer epoch-nanosecond start/end, and a receipt; no registration was replaced after execution.

| Fresh case | Actual exit | Raw observation |
|---|---:|---|
| Original complete header | 2 | One exact definition/capture/query; header facts and11 calls; proof refused |
| Wrong qualified PageManager owner | 65 | No selected definition, capture, or explicit selected query |
| Seeded report preservation | 64 | Sentinel unchanged; no staging file |
| Extra `--emit=link` argument | 64 | Usage refusal before compiler; no report/stage |
| Extra `--link-only` argument | 64 | Usage refusal before compiler; no report/stage |
| Native-source compiler failure | 70 | Unchanged original redb and pinned libc; intentionally empty sysroot produces raw E0463 missing-std diagnostic, no analysis/capture/proof |

The failure case changes only the registered sysroot argument to an existing empty review directory. It does not edit redb, introduce a source fixture, imply a defect in redb, or download missing components. This checks observer failure classification, not a successful native compile under that sysroot. No optional seventh capture was attempted.

## Limits and next smallest edge

The selected toolchain's **326** files also match historical registration hashes on supplemental current and exit readback. Those readbacks follow the fresh runs and are not retrofitted as fresh preregistration/entry observations. Fresh registrations pin the observer executable and rustc binary; the dynamic compiler/loader, OS, system libraries, SDK, all transitive dependencies, proc-macro execution closure, build reproducibility, and compiler bootstrap correspondence are not exhaustively authenticated. Current readback cannot attest every byte loaded during a past execution. The broader 2,654-record entry/exit checks are selected content checks, not an immutable whole-platform sandbox.

The next smallest defensible **diagnostic identity-only** lifecycle edge is the original header's `_20` drop sites **bb16/bb19 -> exact WritablePage destructor/drop-glue instance**. The original `cached_file.rs` source has `WritablePage::drop` calling the cache's `return_value`, but the current observer explicitly does not resolve that glue/destructor or establish its resource effect. Resolving that one native dispatch edge, with exact instance arguments and cleanup context, would be smaller than inventing a generic ownership law or admitting the whole transaction chain. This is a bounded next-edge description, not mapping approval or authorization for another execution/followup chain.

## Review seal

`REVIEW-RESULT.json` gives machine-readable checks and findings. `MANIFEST.json` inventories this review's local artifacts; `SEAL.json` pins that manifest after full local readback. These are independent-review artifacts only. Parent preservation and original worker files are authenticated references retained in place, not repackaged as a completed original worker handoff. The seal records actual elapsed time, resource samples, and the15-minute deadline; each observer case has a90-second bound and the scratch allocation has a128MiB ceiling with free disk strictly above16GiB.
