import json
from pathlib import Path
import runner

root = Path(__file__).resolve().parent
data = json.loads((root / 'outputs/original-checkout-final.json').read_text())
assert data['selected_original_bodies'] == 8
assert data['native_bodies_proved'] == data['primitive_laws_adopted'] == 0
assert data['native_certificate'] is False
assert len(data['body_results']) == 8
assert all('body' in result and 'producer_error' not in result for result in data['body_results'])
bodies = {result['body']['method']: result for result in data['body_results']}
for method in ('mem', 'mem_mut'):
    result = bodies[method]
    derivation = result['derivation']['Ok']
    assert derivation['returned_data_view'] is True
    assert derivation['native_bodies_proved'] == 0
    assert 'NRE140_OPEN_NATIVE_OBLIGATIONS' in result['lowering_refusal']
    assert all(obligation['disposition'] == 'OPEN; not adopted or assumed' for obligation in derivation['obligations'])
    assert result['semantic_negatives']['Ok'][-1].endswith('affine lowering refuses')
assert bodies['write']['derivation'] == {'Err': 'NRE140_SUCCESSOR_LOSS bb0'}
assert bodies['write']['body']['blocks'][0]['compiler_successors']
assert 'Unsupported' in bodies['write']['body']['blocks'][0]['end']
header = data['header_resource_consumer']['Ok']
assert header['native_bodies_proved'] == 0
assert header['original_checkout_body'] == bodies['write']['body']['definition_hash']
assert [name for name, value in header['checkout_fields']] == ['buffer', 'offset', 'data']
assert len(header['checkout_take_sites']) == 2
assert len(header['cleanup_drop_sites']) > 0
assert all(obligation['disposition'] == 'OPEN; not adopted or assumed' for obligation in header['obligations'])
assert {'original-checkout', 'checkout-result-to-page', 'original-copy-bytes', 'source-to-vir', 'primitive-disposition'} <= {obligation['kind'] for obligation in header['obligations']}
assert len(data['header_semantic_negatives']['Ok']) == 4
source = runner.digest(runner.inventory(root / 'candidate'))
commands = json.loads((root / 'commands.json').read_text())
assert len(commands) <= 24
completed = []
for command in commands:
    receipt_path = root / (command['name'] + '.receipt.json')
    if not receipt_path.exists():
        assert command['name'] == 'evidence-audit'
        continue
    receipt = json.loads(receipt_path.read_text())
    assert receipt['owned_group_absent'] is True
    assert receipt['status'] == 'COMPLETED'
    for stream in ('stdout', 'stderr'):
        assert runner.sha(root / (command['name'] + '.' + stream)) == receipt[stream]['sha256']
    completed.append(receipt)
by_name = {receipt['name']: receipt for receipt in completed}
for name, code in (('build10', 0), ('original-checkout-final', 1), ('producer-export-refusal-sealed', 2)):
    assert by_name[name]['returncode'] == code
    assert by_name[name]['source_sha256'] == source
binary = runner.sha(root / 'target/debug/native-resource140')
for name in ('original-checkout-final', 'producer-export-refusal-sealed'):
    assert by_name[name]['argv_file_inputs'][0]['sha256'] == binary
assert 'NRE140_OPEN_NATIVE_OBLIGATIONS' in (root / 'original-checkout-final.stderr').read_text()
assert 'NRE140_EXPORT_REFUSED' in (root / 'producer-export-refusal-sealed.stderr').read_text()
assert not list((root / 'outputs').glob('*.rmeta'))
assert not list(root.rglob('*.vir'))
assert not list(root.rglob('*.verusdata'))
authentication = runner.authenticate('evidence-audit')
result = dict(status='PASS: evidence consistency only, not native proof',
              original_executable_bodies_proved=0, compiler_captured_original_bodies=8,
              conditional_returned_data_views=['mem', 'mem_mut'],
              checkout_authority='OPEN: exact constructor and take_value bindings are not a reservation proof; unsupported assert/effect blocks derivation',
              source_to_vir='OPEN: no original nominal VIR/SST/AIR occurrence resource lowerer',
              primitive_laws_adopted=0, candidate141='NOT ADOPTED; no task141 output consumed',
              all18='OPEN', commands_charged=len(commands), source_sha256=source,
              producer_sha256=binary, authentication=authentication,
              semantic_negatives={method: bodies[method]['semantic_negatives']['Ok'] for method in ('mem', 'mem_mut')},
              header_semantic_negatives=data['header_semantic_negatives']['Ok'])
runner.write('evidence-audit.json', result)
print(json.dumps(result, sort_keys=True))
