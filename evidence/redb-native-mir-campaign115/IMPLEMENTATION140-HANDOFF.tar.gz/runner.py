import datetime
import difflib
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
BASE = Path('/private/tmp/redb-compiler-validation114-worker-20261108T151020Z/snapshot')
PARENT = Path('/Users/tommyvolk/.t3/worktrees/verus/t3-60978068')
ORIGINAL = Path('/private/tmp/redb-original-crate-preflight115/redb')
TC = Path('/Users/tommyvolk/.rustup/toolchains/1.99.1-aarch64-apple-darwin')
STAGE = ROOT / 'candidate'
DEADLINE = datetime.datetime.fromisoformat('2026-11-08T19:57:37+00:00').timestamp()

def sha(path):
    result = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(4 * 1024 * 1024), b''):
            result.update(chunk)
    return result.hexdigest()

def write(name, value):
    path = ROOT / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')
    return value

def inventory(root):
    records = []
    for directory, children, files in os.walk(root):
        children.sort()
        for filename in sorted(files):
            path = Path(directory) / filename
            record = dict(path=str(path.relative_to(root)), bytes=path.stat().st_size, sha256=sha(path))
            if path.is_symlink():
                record.update(symlink=os.readlink(path), resolved=str(path.resolve()))
            records.append(record)
    return sorted(records, key=lambda record: record['path'])

def digest(records):
    return hashlib.sha256(json.dumps(records, sort_keys=True, separators=(',', ':')).encode()).hexdigest()

def resources():
    allocated = logical = 0
    for directory, children, files in os.walk(ROOT):
        for filename in files:
            status = (Path(directory) / filename).lstat()
            allocated += status.st_blocks * 512
            logical += status.st_size
    free = shutil.disk_usage(ROOT).free
    return dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), allocated_bytes=allocated,
                logical_bytes=logical, free_bytes=free,
                safe=max(allocated, logical) <= 4 * 1024**3 and free > 16 * 1024**3)

def authenticate(phase):
    selected = json.loads((ROOT / 'inputs.json').read_text())
    provider_file = ROOT / 'provider-inputs.json'
    if provider_file.exists():
        selected['selected'] += json.loads(provider_file.read_text())['records']
    failures = []
    for entry in selected['selected']:
        path = Path(entry['path'])
        if not path.is_file() or sha(path) != entry['sha256'] or path.stat().st_size != entry['bytes']:
            failures.append(str(path))
    baseline = inventory(BASE)
    original = inventory(ORIGINAL)
    result = dict(phase=phase, baseline_files=len(baseline), baseline_sha256=digest(baseline),
                  original_files=len(original), original_sha256=digest(original), failures=failures,
                  resource=resources())
    write('authentication-' + phase + '.json', result)
    assert not failures, failures
    assert digest(baseline) == selected['baseline_sha256'] == 'c9cb297436ab24053c254ed95bd4e520ef6fca5b86832d217b37302cb5ad7b23'
    assert digest(original) == selected['original_sha256']
    assert result['resource']['safe'], result
    return result

def select_providers():
    assert not (ROOT / 'provider-inputs.json').exists()
    paths = [Path('/private/tmp/redb-native-mir115-20261108T160243Z/target/debug/deps/liblibc-709064e59816a9f7.rlib')]
    for library in ('alloc', 'core', 'std', 'panic_unwind', 'unwind'):
        paths += sorted((TC / 'lib/rustlib/aarch64-apple-darwin/lib').glob('lib' + library + '-*.rlib'))
    records = [dict(path=str(path), bytes=path.stat().st_size, sha256=sha(path)) for path in paths]
    write('provider-inputs.json', dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
          phase='supplemental selection before first original-body compiler execution', records=records,
          standard_library_source='not shipped in pinned rustc-src (only proc_macro exists); no source-level primitive law is inferred'))
    authenticate('supplemental-provider-entry')

def initialize():
    assert not STAGE.exists()
    selected = [TC / 'bin' / name for name in ('cargo', 'rustc', 'rustdoc')]
    selected += sorted((TC / 'lib').glob('librustc_driver*'))
    selected += sorted((TC / 'lib/rustlib/aarch64-apple-darwin/lib').glob('librustc_borrowck*'))
    compiler_sources = TC / 'lib/rustlib/rustc-src/rust/compiler'
    selected += [compiler_sources / path for path in (
        'rustc_borrowck/src/consumers.rs', 'rustc_borrowck/src/borrow_set.rs',
        'rustc_borrowck/src/dataflow.rs', 'rustc_middle/src/mir/terminator.rs',
        'rustc_middle/src/ty/context.rs')]
    selected += [PARENT / path for path in (
        'source/vir/src/native_resource.rs', 'source/vir/src/native_resource/tests.rs',
        'source/vir/src/ast.rs', 'source/vir/src/def.rs', 'source/vir/src/lib.rs',
        'source/vir/src/ast_to_sst_func.rs', 'source/vir/Cargo.toml',
        'source/rust_verify/src/import_export.rs', 'source/rust_verify/src/verifier.rs',
        'evidence/redb-native-mir-campaign115/AUTHORIZATION139.md',
        'evidence/redb-native-mir-campaign115/FIRST-CELL139.md')]
    selected += [Path('/private/tmp/redb-native-mir115-20261108T160243Z') / name for name in
                 ('README.md', 'build-engine-02.launch.json')]
    selected += [Path('/private/tmp/redb-writablepage113-A-20261108T143038Z-ti8KsKPj/attempt-05-exact-namespace-annotated') / name
                 for name in ('stderr.txt', 'stdout.txt', 'invocation.json', 'result.json')]
    records = [dict(path=str(path), bytes=path.stat().st_size, sha256=sha(path)) for path in selected]
    baseline, original = inventory(BASE), inventory(ORIGINAL)
    write('baseline-input.json', baseline)
    write('original-input.json', original)
    write('inputs.json', dict(baseline_sha256=digest(baseline), original_sha256=digest(original), selected=records))
    authenticate('entry')
    shutil.copytree(BASE, STAGE, symlinks=True)
    assert inventory(STAGE) == baseline
    (ROOT / 'tmp').mkdir()
    (ROOT / 'outputs').mkdir()
    (ROOT / 'prior113').mkdir()
    for path in selected:
        if 'attempt-05-' in str(path):
            shutil.copy2(path, ROOT / 'prior113' / path.name)
    write('copy-ledger.json', dict(source=str(BASE), destination=str(STAGE), exact_baseline_copy=True,
                                 copied_files=baseline, native_source_copy=False, checkout_created=False))
    write('commands.json', [])
    print(str(ROOT))

def environment():
    result = dict(HOME='/Users/tommyvolk', USER='tommyvolk', LOGNAME='tommyvolk',
                  PATH=str(TC / 'bin') + ':/usr/bin:/bin:/usr/sbin:/sbin',
                  TMPDIR=str(ROOT / 'tmp'), LANG='C', LC_ALL='C', TZ='UTC',
                  CARGO_HOME='/Users/tommyvolk/.cargo', CARGO_NET_OFFLINE='true',
                  CARGO_BUILD_JOBS='1', CARGO_INCREMENTAL='0',
                  CARGO_TARGET_DIR=str(ROOT / 'target'), CARGO_BUILD_BUILD_DIR=str(ROOT / 'target'),
                  CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0',
                  RUSTC=str(TC / 'bin/rustc'), RUSTDOC=str(TC / 'bin/rustdoc'), RUSTC_BOOTSTRAP='1',
                  RUST_MIN_STACK='20971520', VERUS_IN_VARGO='1', VARGO_TOOLCHAIN=TC.name,
                  DYLD_LIBRARY_PATH=str(TC / 'lib') + ':' + str(TC / 'lib/rustlib/aarch64-apple-darwin/lib'),
                  VERUS_Z3_PATH='/Users/tommyvolk/Documents/GitHub/verus/source/z3')
    result['VERUS_SOURCE_SNAPSHOT_SHA256'] = digest(inventory(STAGE))
    return result

def run(name, kind, timeout, argv):
    assert kind in ('build', 'check', 'proof')
    commands = json.loads((ROOT / 'commands.json').read_text())
    assert len(commands) < 24
    assert not (ROOT / (name + '.launch.json')).exists()
    commands.append(dict(name=name, kind=kind, argv=argv))
    write('commands.json', commands)
    authenticate('preexecution-' + name)
    source = inventory(STAGE)
    write(name + '.source.json', source)
    timeout = min(float(timeout), 600 if kind == 'build' else 120, DEADLINE - time.time() - 120)
    assert timeout > 0
    env = environment()
    entry = dict(name=name, kind=kind, command_number=len(commands), argv=argv,
                 cwd=str(STAGE / 'source'), environment=env, timeout_seconds=timeout,
                 start_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                 source_sha256=digest(source), status='PREPARED', resource_before=resources())
    entry['argv_file_inputs'] = [dict(path=argument, sha256=sha(argument)) for argument in argv
                                if Path(argument).is_absolute() and Path(argument).is_file()]
    write(name + '.launch.json', entry)
    caught = []
    previous = {number: signal.signal(number, lambda number, frame: caught.append(number))
                for number in (signal.SIGTERM, signal.SIGINT, signal.SIGHUP)}
    process = None
    cause = None
    started = time.monotonic()
    try:
        with (ROOT / (name + '.stdout')).open('wb') as stdout, (ROOT / (name + '.stderr')).open('wb') as stderr, (ROOT / (name + '.resources.jsonl')).open('w') as samples:
            process = subprocess.Popen(argv, cwd=STAGE / 'source', env=env, stdout=stdout, stderr=stderr, start_new_session=True)
            entry.update(pid=process.pid, process_group=process.pid, status='RUNNING')
            write(name + '.launch.json', entry)
            while process.poll() is None:
                sample = resources()
                samples.write(json.dumps(sample, sort_keys=True) + '\n')
                samples.flush()
                if caught:
                    cause = 'INTERRUPTED'
                elif time.monotonic() - started >= timeout:
                    cause = 'TIMEOUT'
                elif not sample['safe']:
                    cause = 'RESOURCE_LIMIT'
                if cause:
                    break
                time.sleep(0.5)
    except BaseException as error:
        cause = 'LAUNCH_OR_RUN_EXCEPTION: ' + repr(error)
    finally:
        if process is not None:
            if process.poll() is None:
                try:
                    os.killpg(process.pid, signal.SIGTERM)
                except ProcessLookupError:
                    pass
                try:
                    process.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    os.killpg(process.pid, signal.SIGKILL)
                    process.wait(timeout=5)
            entry['returncode'] = process.wait()
            try:
                os.killpg(process.pid, 0)
                os.killpg(process.pid, signal.SIGKILL)
                entry['residual_group_killed'] = True
            except ProcessLookupError:
                entry['owned_group_absent'] = True
            if not entry.get('owned_group_absent'):
                for attempt in range(20):
                    try:
                        os.killpg(process.pid, 0)
                        time.sleep(0.1)
                    except ProcessLookupError:
                        entry['owned_group_absent'] = True
                        break
        for number, handler in previous.items():
            signal.signal(number, handler)
        entry.update(status=cause or 'COMPLETED', elapsed_seconds=time.monotonic() - started,
                     end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), resource_after=resources())
        for stream in ('stdout', 'stderr'):
            path = ROOT / (name + '.' + stream)
            if path.exists():
                entry[stream] = dict(bytes=path.stat().st_size, sha256=sha(path))
        write(name + '.receipt.json', entry)
        print(json.dumps(entry, sort_keys=True))
    assert entry.get('owned_group_absent'), entry
    assert entry['resource_after']['safe'], entry
    return 0 if cause is None and entry.get('returncode') == 0 else 1

def seal():
    authenticate('exit')
    baseline = {entry['path']: entry for entry in inventory(BASE)}
    candidate = inventory(STAGE)
    write('candidate-final.json', candidate)
    delta = []
    patches = []
    for entry in candidate:
        relative = entry['path']
        old = baseline.get(relative)
        if old != entry:
            delta.append(dict(path=relative, baseline=old, candidate=entry))
            before = (BASE / relative).read_text().splitlines(keepends=True) if old else []
            after = (STAGE / relative).read_text().splitlines(keepends=True)
            patches.extend(difflib.unified_diff(before, after, fromfile='baseline/' + relative, tofile='candidate/' + relative))
    (ROOT / 'candidate.patch').write_text(''.join(patches))
    write('source-delta.json', delta)
    commands = json.loads((ROOT / 'commands.json').read_text())
    receipts = [json.loads((ROOT / (command['name'] + '.receipt.json')).read_text()) for command in commands]
    assert all(receipt.get('owned_group_absent') for receipt in receipts)
    assert len(commands) <= 24
    samples = [receipt[key] for receipt in receipts for key in ('resource_before', 'resource_after')]
    for path in ROOT.glob('*.resources.jsonl'):
        samples += [json.loads(line) for line in path.read_text().splitlines() if line]
    assert all(sample['safe'] for sample in samples)
    artifacts = inventory(ROOT / 'target')
    write('artifacts-final.json', dict(sha256=digest(artifacts), records=artifacts))
    exports = [str(path.relative_to(ROOT)) for suffix in ('*.vir', '*.verusdata') for path in ROOT.rglob(suffix)]
    assert not exports, exports
    write('export-absence.json', dict(exports=exports, native_certificate=False, native_bodies_proved=0))
    write('seal-summary.json', dict(commands_charged=len(commands), limit=24, deadline_utc='2026-11-08T19:57:37Z',
                                  within_deadline=time.time() < DEADLINE, resource=resources(),
                                  sampled_max_allocated_bytes=max(sample['allocated_bytes'] for sample in samples),
                                  sampled_max_logical_bytes=max(sample['logical_bytes'] for sample in samples),
                                  sampled_min_free_bytes=min(sample['free_bytes'] for sample in samples),
                                  resource_samples=len(samples), final_artifacts_sha256=digest(artifacts),
                                  compiler_slot='RELEASED', live_owned_process_groups=0,
                                  original_native_application_execution=False, all18='OPEN',
                                  native_bodies_proved=0, primitive_laws_adopted=0))
    released = datetime.datetime.now(datetime.timezone.utc).isoformat()
    (ROOT / 'RELEASE.md').write_text('# Compiler-slot RELEASE\n\n'
        + 'implementation140 explicitly RELEASES the exclusive jobs1 compiler/build/verifier slot at ' + released + '.\n\n'
        + str(len(commands)) + '/24 charged commands are complete; every owned process group is terminated/reaped and absent. '
        + 'No compiler, solver, verifier, watcher or original application remains running. Scratch and failures are retained; no destructive cleanup occurred. '
        + 'All18 remain OPEN, original bodies proved0, primitive laws adopted0, candidate141 NOT ADOPTED. No automatic followup.\n')
    manifest = [entry for entry in inventory(ROOT) if not entry['path'].startswith(('target/', 'candidate/', 'tmp/'))
                and entry['path'] not in ('SEAL.json', 'SEAL.sha256')]
    write('SEAL.json', manifest)
    (ROOT / 'SEAL.sha256').write_text(sha(ROOT / 'SEAL.json') + '  SEAL.json\n')
    assert time.time() < DEADLINE, 'seal deadline exceeded'
    print(json.dumps(json.loads((ROOT / 'seal-summary.json').read_text()), sort_keys=True))

if __name__ == '__main__':
    if sys.argv[1] == 'init':
        initialize()
    elif sys.argv[1] == 'run':
        sys.exit(run(sys.argv[2], sys.argv[3], float(sys.argv[4]), sys.argv[5:]))
    elif sys.argv[1] == 'seal':
        seal()
    elif sys.argv[1] == 'providers':
        select_providers()
