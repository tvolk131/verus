# Investigation128 — bounded offline pinned-source acquisition

## Decision

**EXACT_LOCAL_SOURCE_LOCATED, WITH QUALIFIED COMPONENT/COMMIT BINDING.**

A preexisting cached Rust source component matches the installed pinned channel
manifest's exact rust-src 1.99.1 archive digest. Its archived release and full
commit metadata match the previously recorded compiler identity in completed115.
All four requested source files exist both in the archive and its preexisting
expanded staging tree, and their byte counts and SHA256 values agree.

This establishes local exact-version component/content correspondence relative
to the consulted manifest and receipts. It does **not** authenticate the channel
manifest upstream, establish current compiler-binary/source correspondence,
reproduce compilation, or establish bootstrap correspondence. No installed
receipt, filename, archive label, or local digest is promoted into full trust.

All **18 obligations remain OPEN**. Native/resource/trust/proof credit: **0/0/0/0**.

## Exact locations

- Cached archive:
  `/private/tmp/verus-pinned-rust-source-20261107-9FT58F/rust-src-1.99.1.tar.xz`
- Existing expanded library root:
  `/private/tmp/verus-pinned-rust-source-20261107-9FT58F/rust-src-1.99.1/rust-src/lib/rustlib/src/rust/library`
- Archive library-member prefix:
  `rust-src-1.99.1/rust-src/lib/rustlib/src/rust/library/`
- Archive size: **5,863,216 bytes**.
- Archive SHA256:
  `e485a88c45db546b73571df7bebfcb4454ba4fb552c492e25fc5b00eeb5bf22d`.

No archive or package was copied or extracted into a new tree. Selective tar
member reads went only through stdout pipes to metadata filters or hashing.
The expanded tree predates this investigation; it was not created or integrated.

## Binding evidence

1. The user-specified audit124 cut was hashed before its narrow acquisition/
   version-reference reads. REPORT.md matched
   `2b84e2106c98d331c06ff5ec2227c8a7385850f1d44ebf22bcb4caadd3f3c107`;
   DECISION.json matched
   `a2079f545547233bf0b760f78900bb3d9293094b2a4c6425baa1ab76f391bbbb`.
   This is cut identification, not an independent trust root. No hasher/vstd
   contract analysis was repeated.
2. The installed pinned metadata file is
   `/Users/tommyvolk/.rustup/toolchains/1.99.1-aarch64-apple-darwin/lib/rustlib/multirust-channel-manifest.toml`,
   SHA256 `48419307eb32e389a25ac360b6bccd4d196f3c4f35ce9d67a223319eff017c6c`.
   Its line 2 records distribution date **2026-10-15**; lines 2534–2535,
   33825–33826, and 34907–34908 identify rust, rust-src, and rustc as
   **1.99.1 (58cf8f9c3 2026-10-13)**.
3. Manifest lines 33828–33835 describe the target-independent rust-src
   component. The recorded xz basename is `rust-src-1.99.1.tar.xz`, dated
   2026-10-15, and line 33833 gives exactly the observed archive SHA256 above.
   The gzip hash is a different encoding, not a mismatch:
   `b0d6d3a7e46a97adfe6488f8b60c04c019566b8363eeb6ffb32c6cf63609071d`.
   No recorded download address was contacted.
4. Manifest lines 34910–34917 describe rustc for **aarch64-apple-darwin**;
   recorded rustc xz SHA256 is
   `23948a0a9c162fd2952defb3fb0462c44e8fcfd1a4ab8a274a1e1bdb2cf810a3`.
   No compiler archive was acquired or matched. This links declarations in
   one local manifest, not verified installed binary bytes to source.
5. After the archive digest match, its member inventory was read, then only
   selected members. Archived `version` states
   `1.99.1 (58cf8f9c3 2026-10-13)`; `git-commit-hash` and `git-commit-info`
   give full commit **58cf8f9c35b355199727627d07ae34a4e2846d67**.
   `components` is `rust-src`. The archived `rust-src/manifest.in` lists the
   four requested source files at lines 78, 701, 1277, and 1523.
6. Completed115's preexisting `preflight-rustc-identity.receipt.json`, under
   `/private/tmp/redb-native-mir115-20261108T160243Z/`, records the pinned
   absolute rustc path, `-vV`, completion, and output digest
   `e003fd3d385fcd0de16bc6b049124efb20207831dd810fd4ab39ff079bbb12a5`.
   Its existing 192-byte stdout matches that digest and reports release
   **1.99.1**, the same full commit, date **2026-10-13**, and host
   **aarch64-apple-darwin**. Investigation128 did not execute that command.
7. Completed122's existing `records/build1/receipt.json`, under
   `/private/tmp/redb-scope-validation122-20261108T174715Z/`, records pinned
   cargo/rustc/rustdoc paths. It records rustc as 413,480 bytes with SHA256
   `1ba7bb8e273bd64125f4048d2ecce530e0a6470e565ab1b3aecf0b82b532f7b1`.
   This is receipt evidence only: no current executable was opened, hashed,
   or run, and no compiler-package-to-executable relation was verified.

`PINNED-METADATA.txt`, `ARCHIVE-METADATA.txt`, `COMPONENT-BINDING.txt`, and
`IDENTITY-CORROBORATION.txt` retain the narrow observations. `METADATA.before.sha256`
and `METADATA.after.sha256` cover all 18 consulted preexisting metadata/archive/
receipt files; `SOURCE.before.sha256` and `SOURCE.after.sha256` cover the four
expanded source files. Completed exit comparisons are in `EXIT-CHECKS.retry.txt`;
the original partial `EXIT-CHECKS.txt` is retained as failure evidence.

## Exact requested content

Each member appears exactly once in the 4,649-entry archive filename inventory.
Selected tar metadata identifies each as an ordinary regular file. The existing
expanded copy matches the archive member digest for each row:

| Library-relative file | Bytes | SHA256 |
| --- | ---: | --- |
| `core/src/hash/mod.rs` | 31,675 | `3670a47bcf646bbcc69e1f70131df6c0093f12b0602be614ac828266f19e2a1f` |
| `alloc/src/sync.rs` | 179,132 | `b2f806b0f696a181018072625dceed25304aa97dfef6a79bac9800d529afdd0e` |
| `std/src/collections/hash/map.rs` | 95,130 | `1c4722af99116914c3b164e253668e951515cbf4ef38e3c6fb77d1edc8f0ec63` |
| `std/src/sync/poison/mutex.rs` | 34,960 | `5e45f2804aaee6b2dd24af91b471757cd15010058b03b39b4cbba90809e3fb8c` |

The three expanded source-version metadata files also match their archived
counterparts. File correspondence is not an analysis of those files' contracts
or semantics, nor a claim that every expanded file was compared.

## Precisely searched and skipped

- `/Users/tommyvolk/.rustup/downloads` and `.rustup/tmp`: filename inventory
  to depth two found no regular files; no archive contents existed to inspect.
- Pinned `lib/rustlib`: filename inventory to depth two; substantive reads
  confined to the prehashed channel manifest, component/config/version metadata,
  and rustc/cargo filename receipts. No compiled library or executable inspected.
- `.rustup/update-hashes`: immediate file names inventoried; only the pinned
  20-byte update-hash file read. Its `fb152be80975c194aa5f` value is treated as
  opaque installed bookkeeping, not archive or provenance authentication.
- `.cargo/registry/cache`: regular-file filename search to depth two, names
  matching `*rust-src*`, `*rust-source*`, or `*rust-library*`; no candidate
  matched. Non-source-labelled crate archives were not opened. This is not
  exhaustive search for arbitrary renamed archives or source hidden in crates.
- `/private/tmp`: immediate-name discovery only across the root; retained
  campaign/source-stage and completed115/122 metadata filenames. Deeper metadata
  filename inventories were limited to the explicitly listed completed115/122
  directories, with source/snapshot/target/.git pruning where configured.
  One Rust-labelled source staging directory was inventoried to depth two and
  yielded the exact archive. Only its archive, selected source-version metadata,
  and four requested expanded source files were consulted substantively.
- Other campaign/build/download staging trees were not recursively searched
  after the exact component was found. `/private/tmp/redb-build127-20261108TZZvZKo`
  was name-only discovery; no live build target was inspected.
- `/private/tmp/verus-rust1991-source-review-20261107-3f7c9d` was recorded by
  location only; its review contents were not read. Other delegate/review
  artifacts, staging `SOURCE-BINDING.json`, `SOURCE-INVENTORY.json`, downloaded
  headers, saved staging tool output, and staging scripts were not read or run.
- The expected pinned `lib/rustlib/src/rust/library` path is missing. A separate
  path-only check found `lib/rustlib/rustc-src/rust/library` present; its contents
  were deliberately not inspected, and presence is not exact-source evidence.
  Stable 1.99.0 sources were not reread or substituted.
- No traversal outside the allowed roots, network, Git, credentials/auth/SSH/
  cloud configuration, unrelated personal content, compiler/Cargo/rustup/
  rustfmt/verifier/solver/diagnostic/test/native-target execution, source edits,
  integration, cleanup, trust changes, or subdelegation occurred.

Full retained filename inventories are in `INVENTORY.txt`, `RECEIPT122.paths.txt`,
`ARCHIVE.members.txt`, and the selected-size/source-path inventories. Discovery
does not prove that a candidate was never inspected in an earlier task. The
archive was newly examined by investigation128; its prior inspection history
was not established, and no other delegate's conclusion was adopted.

## Preauthentication and limits

Initial directory names, filenames, sizes, timestamps and archive labels were
unauthenticated discovery hints. The archive hash was recorded before any tar
inventory. The filename and selected-size inventories were discovery observations,
not preauthenticated content: no automated expected-digest comparison preceded
them. The matching recorded archive/local-manifest digests were observed before
the substantive version/source member reads. Explicit automated digest/content
comparisons are retained at exit. This sequencing does not upgrade discovery
to preauthentication.
Hashing a local manifest before use preserves observed identity and sequencing;
it does not authenticate its issuer. Archive commit metadata is content evidence
inside that matching component, not independent proof of build provenance.

The first zsh command accidentally used special variable `path` as a loop name,
which altered PATH; `ls`/`find` failed. An absolute-utility-path retry succeeded.
An immediate tmp discovery reported `codex-daemon-501: Operation not permitted`;
no attempt was made to bypass it. That path was not a relevant archive candidate.
The broad first inventory and two receipt displays were truncated by the tool's
display limit. Subsequent inventories and receipt metadata observations were
retained in full in this report directory; no omitted display is treated as
negative evidence. `DISCOVERY.stderr` retains the discovery denial;
`ARCHIVE.stderr` is empty. No archive operation timed out or failed.

The first automated exit comparison selected field four instead of field three
for the manifest's recorded xz digest, producing an empty expected value and
stopping the check. The partial output is retained. A corrected field-three
retry passes archive/manifest, saved-stdout/receipt, and all four source-member
comparisons; this was a report parser failure, not evidence of differing bytes.

The deadline was **2026-11-08T18:27:37Z**, nine minutes after the first filesystem
command. The initial report write was guarded by **33,297,464 KiB** available,
strictly above **16,777,216 KiB (16 GiB)**. Every later write-command group also
checked that strict reserve. The final time/disk/size accounting is sealed in
`ACCOUNTING.txt` and `SEAL.txt`. The whole fresh report is below **2 MiB**.

Archive bounds: one candidate, at most 256 MiB per compressed archive, at most
512 MiB of conservative archive-file input across passes, 25-second deadline per
tar invocation, and 8 MiB selective member payload. Actual archive use was
16 bounded tar operations plus initial/exit archive hashes: at most
**105,537,888 compressed archive-file input bytes**. Selective member payload
was **881,027 bytes**, including two reads of the component filename manifest.
There were no filesystem extractions, bulk copies, or archive installation.
Decompressed traversal bytes were not instrumented; compressed-input bounds
and per-command time limits are distinct from an uncompressed-byte measurement.

## One next action

The parent should select the existing archive at the exact location and SHA256
above as its pinned-1.99.1 library-source input. This handoff authorizes no
installation, integration, trust promotion, or automatic followup.
