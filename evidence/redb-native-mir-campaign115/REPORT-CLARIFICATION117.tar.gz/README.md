# Scratch report clarification117

Independent review115 found that the inherited native_collection_completed
field can be mistaken for native-phase completion. Its actual predicate is
only native_function_scope.is_some(), set before checked-drop preparation can
refuse. This is not a new115 semantic regression, a native-resource theorem,
or evidence that a native MIR phase ran for the anonymous fixture.

This minimal source-only correction keeps the legacy schema1 predicate for
existing consumers, adds the precisely named compiled_function_inventory_available
alias and an explicit legacy-field definition, and states that the inventory
cannot establish resource correspondence. It changes no verifier state,
normalizer, inference, admission, import/export policy, native query scheduling,
contract, or proof interface. Existing body counts retain their old predicates.

The exact before-source came from the authenticated115 snapshot; its original
worker/source and review remain immutable. The patch lives only in new scratch.
It is not built, runtime tested, independently closed or integrated. A pinned
rustfmt parse is syntax evidence only. The existing115 binaries/reports are not
retroactively relabelled with these new fields. Future use would require a
new source-bound engine build and actual emitted-report controls.

The authoritative campaign explicitly forbids using native_collection_completed
alone as native-phase or native-resource proof evidence. Real native-phase
captures and operation-check records must still be distinguished from the
selected-body coverage report, and neither supplies Arc/Mutex/cache authority.
All18 remain OPEN; no native, trust or final-cell credit follows.
