import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

ROOT = Path('/private/tmp/redb-primitive158-20261108-234646')

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def write(path, value):
    Path(path).write_text(json.dumps(value, sort_keys=True, indent=2) + '\n')

def sample():
    logical = allocated = 0
    for directory, _, names in os.walk(ROOT):
        for name in names:
            status = (Path(directory) / name).lstat()
            logical += status.st_size
            allocated += status.st_blocks * 512
    return dict(utc=utc(), logical=logical, allocated=allocated, free=shutil.disk_usage(ROOT).free,
                within_2gib=max(logical, allocated) <= 2147483648)

entry = dict(number=17, kind='SEAL_ONLY_AFTER_RECORDED_RESOURCE_FAILURE', argv=[sys.executable, str(ROOT / 'seal158.py')],
             env=dict(os.environ), cwd=str(ROOT), start_utc=utc(), start_ns=time.time_ns(), before=sample(),
             wrapper_sha256=sha(__file__), executable_sha256=sha(sys.executable), script_sha256=sha(ROOT / 'seal158.py'))
write(ROOT / 'seal.launch.json', entry)
with (ROOT / 'seal.stdout').open('xb') as stdout, (ROOT / 'seal.stderr').open('xb') as stderr:
    child = subprocess.Popen(entry['argv'], cwd=ROOT, env=dict(os.environ), stdout=stdout, stderr=stderr, start_new_session=True)
    entry['pid'] = child.pid
    write(ROOT / 'seal.launch.json', entry)
    try:
        entry['returncode'] = child.wait(timeout=180)
    except subprocess.TimeoutExpired:
        os.killpg(child.pid, 9)
        entry['returncode'] = child.wait(timeout=10)
        entry['timeout'] = True
    entry['reaped'] = True
try:
    os.killpg(child.pid, 0)
    entry['owned_group_absent'] = False
except ProcessLookupError:
    entry['owned_group_absent'] = True
entry.update(end_utc=utc(), end_ns=time.time_ns(), after=sample(),
             streams={name: dict(bytes=(ROOT / ('seal.' + name)).stat().st_size, sha256=sha(ROOT / ('seal.' + name))) for name in ['stdout', 'stderr']})
write(ROOT / 'seal.receipt.json', entry)
assert entry['returncode'] == 0 and entry['owned_group_absent']
compiler = json.loads((ROOT / 'compiler-build.launch.json').read_text())
try:
    os.killpg(compiler['pid'], 0)
    raise RuntimeError('compiler group still present; no release')
except ProcessLookupError:
    pass
release = dict(utc=utc(), status='RELEASE_COMPILER_CHILDREN_REAPED_OWNED_GROUPS_ABSENT',
               compiler_group_absent=True, seal_child_reaped=True, seal_group_absent=True,
               compiler_reap_evidence='runner traceback reached final resources after kill/wait; raw exit unretained',
               original_application_executed=False, followup_scheduled=False, resource_compliance='FAILED_2GIB_SCRATCH')
write(ROOT / 'RELEASE158.json', release)
seal = json.loads((ROOT / 'SEAL158.json').read_text())
handoff = dict(task='campaign94-task158', root=str(ROOT), result='UNCOMPILED_PARTIAL_NEW_PRIMITIVE_TCB_PROPOSAL_G1_G2_OPEN',
    archive='HANDOFF158.tar.gz', archive_sha256=sha(ROOT / 'HANDOFF158.tar.gz'),
    manifest_sha256=sha(ROOT / 'MANIFEST158.json'), seal_sha256=sha(ROOT / 'SEAL158.json'),
    release_sha256=sha(ROOT / 'RELEASE158.json'), seal_receipt_sha256=sha(ROOT / 'seal.receipt.json'),
    regular_unique_byte_identical_members=seal['regular_unique_byte_identical_members'],
    source_delta_sha256=sha(ROOT / 'source-relative158.patch'), charged_commands=17, command_limit=32,
    start_utc='2026-11-08T23:46:46Z', deadline_utc='2026-11-09T00:26:46Z', end_utc=utc(),
    compilation='FAILED_RESOURCE_WATCHDOG_NO158BINARY', tests='NOT_RUN', solver_runs=0,
    scratch_requirement='FAILED_AT2174758912_ALLOCATED_BYTES_BEFORE_MINIMAL_SEAL_METADATA', final_sample=sample(),
    native_export='REFUSED', accepted_original_allocations=0, accepted_original_stores=0,
    accepted_original_bodies=0, laws_adopted=0, all18='OPEN', law_status='PENDING_REVIEW',
    compiler_slot=release['status'], original_application_executed=False,
    independent_review_and_explicit_parent_disposition='REQUIRED_NOT_DONE')
write(ROOT / 'HANDOFF158.json', handoff)
print(json.dumps(dict(handoff=str(ROOT / 'HANDOFF158.json'), handoff_sha256=sha(ROOT / 'HANDOFF158.json'),
                     archive_sha256=handoff['archive_sha256'], manifest_sha256=handoff['manifest_sha256'],
                     patch_sha256=handoff['source_delta_sha256'], release=release['status'], final_sample=handoff['final_sample']), indent=2))
