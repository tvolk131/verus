from pathlib import Path
import subprocess

root = Path('/private/tmp/redb-primitive158-20261108-234646')
source = root / 'candidate/source'
original = (source / 'rust_verify/src/bin/permission154.rs').read_text()
prefix = original[:original.index('impl rustc_driver::Callbacks for Callbacks {')]
prefix = prefix.replace('    test: String,\n    outcome: String,', '    pending: bool,')
prefix = prefix.replace('include!("../allocation156.rs");', 'include!("../allocation156.rs");\ninclude!("../primitive158.rs");')
callback = original[original.index('impl rustc_driver::Callbacks for Callbacks {'):original.index('        let mut resolved_path =')]
callback += '''        let pending = pending_occurrence158(tcx, &store, &allocation, self.pending);
        std::fs::write(self.output.with_extension("pending.json"), serde_json::to_vec_pretty(&pending).unwrap()).unwrap();
        compiler.sess.dcx().err("PRIMITIVE158_EXPORT_REFUSED: fixed new primitive TCB proposal PENDING_REVIEW; no resource issuance, original-event acceptance, native export or theorem credit");
        rustc_driver::Compilation::Stop
    }
}

fn main() -> std::process::ExitCode {
    let mut arguments = std::env::args().collect::<Vec<_>>();
    assert_eq!(arguments[1], "--primitive158-output");
    let output = PathBuf::from(arguments.remove(2));
    arguments.remove(1);
    let pending = if arguments.get(1).is_some_and(|argument| argument == "--pending-occurrence158") {
        arguments.remove(1);
        true
    } else { false };
    let source_root = PathBuf::from(arguments.last().unwrap()).parent().unwrap().canonicalize().unwrap();
    let result = rustc_driver::catch_fatal_errors(|| rustc_driver::run_compiler(&arguments, &mut Callbacks { output, pending, source_root }));
    if result.is_ok() { std::process::ExitCode::SUCCESS } else { std::process::ExitCode::FAILURE }
}
'''
patch = '*** Begin Patch\n*** Add File: ' + str(source / 'rust_verify/src/bin/primitive158.rs') + '\n'
patch += ''.join('+' + line + '\n' for line in (prefix + callback).splitlines())
patch += '*** End Patch\n'
subprocess.run(['/Users/tommyvolk/.t3/userdata/providers/codex/codex_095eca24-b4b7-4a15-8759-9d8964dbd03a/shadow/tmp/arg0-macos/codex-arg0pyHCn8/apply_patch', patch], check=True)
