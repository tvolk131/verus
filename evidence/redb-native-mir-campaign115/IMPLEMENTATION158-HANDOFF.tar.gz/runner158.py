import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import tarfile
import time

ROOT = Path('/private/tmp/redb-primitive158-20261108-234646')
BASE = Path('/private/tmp/redb-allocation156-20261108-230238')
REPO = Path('/Users/tommyvolk/.t3/worktrees/verus/t3-60978068')
START = datetime.datetime.fromisoformat('2026-11-08T23:46:46+00:00').timestamp()
DEADLINE = START + 2400

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            digest.update(block)
    return digest.hexdigest()

def write(path, value):
    Path(path).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

def inventory(root):
    return sorted([dict(path=str(path.relative_to(root)), bytes=path.stat().st_size, sha256=sha(path))
                   for path in root.rglob('*') if path.is_file() and '.git' not in path.parts], key=lambda record: record['path'])

def resources():
    logical = allocated = 0
    for directory, _, names in os.walk(ROOT):
        for name in names:
            status = (Path(directory) / name).lstat()
            logical += status.st_size
            allocated += status.st_blocks * 512
    result = dict(utc=utc(), logical=logical, allocated=allocated, free=shutil.disk_usage(ROOT).free)
    if max(logical, allocated) > 2 * 1024**3 or result['free'] <= 16 * 1024**3:
        raise RuntimeError(result)
    return result

def authenticate(name):
    mismatches = [record['path'] for record in json.loads((ROOT / 'inputs.json').read_text())
                  if sha(record['path']) != record['sha256']]
    write(ROOT / ('authentication-' + name + '.json'), dict(utc=utc(), mismatches=mismatches))
    assert not mismatches, mismatches

def init():
    began = time.time_ns()
    before = resources()
    pins = {'HANDOFF156.json': '3b7a3fb633dc793c16a441f30fbafa8b1e875c9f2ef53ac6ac53ea2cf84df582',
            'HANDOFF156.tar.gz': '1d49f719b9d15749aa741ce9b2aa7c629867abc191639526fdb1b5278cd64095'}
    for name, expected in pins.items():
        assert sha(BASE / name) == expected
    members = []
    with tarfile.open(BASE / 'HANDOFF156.tar.gz') as package:
        for member in package:
            assert member.isfile() and member.name not in members
            assert not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
            members.append(member.name)
            assert package.extractfile(member).read() == (BASE / member.name).read_bytes()
    shutil.copytree(BASE / 'candidate', ROOT / 'candidate')
    shutil.copytree(BASE / 'target', ROOT / 'target')
    for name in ['checks', 'tmp', 'history', 'authority']:
        (ROOT / name).mkdir()
    selected = [Path(record['path']) for record in json.loads((BASE / 'inputs.json').read_text())]
    for name in ['AUTHORIZATION139.md', 'FIRST-CELL139.md', 'RESOURCE-BOUNDARY135.md', 'ALLOCATION-CONTRACT-DISPOSITION155.md']:
        endpoint = REPO / 'evidence/redb-native-mir-campaign115' / name
        shutil.copy2(endpoint, ROOT / 'authority' / name)
        selected.append(endpoint)
    selected += [BASE / name for name in pins]
    selected += [BASE / name for name in ['REPORT156.md', 'BRIDGE156.md', 'MANIFEST156.json']]
    selected += [BASE / 'candidate' / record['path'] for record in inventory(BASE / 'candidate')]
    write(ROOT / 'inputs.json', [dict(path=str(path), bytes=path.stat().st_size, sha256=sha(path)) for path in sorted(set(selected))])
    write(ROOT / 'initial-source.json', inventory(ROOT / 'candidate'))
    write(ROOT / 'archive156-authentication.json', dict(members=members, count=len(members), pins=pins))
    inherited = json.loads((BASE / 'compiler-u8-align-build.launch.json').read_text())['env']
    allowed = ['PATH', 'HOME', 'RUSTUP_HOME', 'CARGO_HOME', 'RUSTC_BOOTSTRAP', 'RUSTC', 'RUSTFLAGS', 'DYLD_LIBRARY_PATH', 'VERUS_Z3_PATH', 'VERUS_ROOT', 'VSTD_KIND', 'CARGO_ENCODED_RUSTFLAGS', 'VERUS_SOURCE_SNAPSHOT_SHA256']
    environment = {key: inherited[key] for key in allowed if key in inherited}
    environment.update(CARGO_TARGET_DIR=str(ROOT / 'target'), CARGO_BUILD_BUILD_DIR=str(ROOT / 'target'),
                       CARGO_BUILD_JOBS='1', CARGO_NET_OFFLINE='true', TMPDIR=str(ROOT / 'tmp'), LANG='C', LC_ALL='C')
    write(ROOT / 'environment.json', environment)
    write(ROOT / 'bounds.json', dict(start=START, deadline=DEADLINE, commands=32, preflight_charged=6, build=600,
                                    diagnostic=180, jobs=1, bytes=2 * 1024**3, slot='HELD_IMPLEMENTATION158'))
    write(ROOT / 'setup.receipt.json', dict(number=6, argv=sys.argv, env=dict(os.environ), start_ns=began,
          end_ns=time.time_ns(), returncode=0, before=before, after=resources(),
          preflight='Five bounded shell inspections retained in parent tool transcript; conservatively charged. No inherited environment dumped or forwarded. Bootstrap edit is setup.'))
    authenticate('entry')
    print(ROOT)

def run(name, kind, argv):
    number = 11 + len(list(ROOT.glob('*.launch.json')))
    assert number <= 32
    seconds = min(600 if kind == 'build' else 180, DEADLINE - time.time() - 150)
    assert seconds > 0
    authenticate(name + '-entry')
    environment = json.loads((ROOT / 'environment.json').read_text())
    environment['VERUS_SOURCE_SNAPSHOT_SHA256'] = sha(ROOT / 'initial-source.json')
    write(ROOT / (name + '.source.json'), inventory(ROOT / 'candidate'))
    endpoints = sorted(set(Path(argument.split('=', 1)[-1]) for argument in argv if Path(argument.split('=', 1)[-1]).is_file()))
    entry = dict(number=number, name=name, kind=kind, argv=argv, env=environment, cwd=str(ROOT / 'candidate/source'),
                 timeout=seconds, start_utc=utc(), start_ns=time.time_ns(), before=resources(), runner_sha256=sha(__file__),
                 executable_sha256=sha(shutil.which(argv[0], path=environment['PATH']) or argv[0]),
                 argument_inputs=[dict(path=str(path), bytes=path.stat().st_size, sha256=sha(path)) for path in endpoints])
    write(ROOT / (name + '.launch.json'), entry)
    child = None
    started = time.monotonic()
    try:
        with (ROOT / (name + '.stdout')).open('xb') as stdout, (ROOT / (name + '.stderr')).open('xb') as stderr:
            child = subprocess.Popen(argv, cwd=entry['cwd'], env=environment, stdout=stdout, stderr=stderr, start_new_session=True)
            entry['pid'] = child.pid
            write(ROOT / (name + '.launch.json'), entry)
            with (ROOT / (name + '.resources.jsonl')).open('x') as samples:
                while child.poll() is None:
                    try:
                        child.wait(timeout=2)
                    except subprocess.TimeoutExpired:
                        samples.write(json.dumps(resources()) + '\n')
                        samples.flush()
                        if time.monotonic() - started >= seconds:
                            raise TimeoutError(name)
    except BaseException as error:
        entry['failure'] = repr(error)
    finally:
        if child is not None:
            if child.returncode is None:
                os.killpg(child.pid, signal.SIGKILL)
            child.wait(timeout=10)
            entry['returncode'] = child.returncode
            entry['reaped'] = True
            try:
                os.killpg(child.pid, 0)
                entry['owned_group_absent'] = False
            except ProcessLookupError:
                entry['owned_group_absent'] = True
        entry.update(end_utc=utc(), end_ns=time.time_ns(), elapsed=time.monotonic() - started, after=resources())
        entry['streams'] = {stream: dict(bytes=(ROOT / (name + '.' + stream)).stat().st_size, sha256=sha(ROOT / (name + '.' + stream))) for stream in ['stdout', 'stderr']}
        write(ROOT / (name + '.receipt.json'), entry)
        print(json.dumps({key: entry.get(key) for key in ['number', 'name', 'returncode', 'failure', 'elapsed', 'reaped', 'owned_group_absent']}))
    return entry.get('returncode', 1)

if __name__ == '__main__':
    if sys.argv[1] == 'init':
        init()
    elif sys.argv[1] == 'run':
        raise SystemExit(run(sys.argv[2], sys.argv[3], sys.argv[4:]))
