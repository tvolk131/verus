use vstd::prelude::*;
use vstd::raw_ptr::{Dealloc, PointsToRaw};

verus! {
proof fn consume(tracked raw: PointsToRaw, tracked dealloc: Dealloc) {}

pub proof fn missing() {
    let tracked raw: PointsToRaw;
    let tracked dealloc: Dealloc;
    consume(raw, dealloc);
}
}
