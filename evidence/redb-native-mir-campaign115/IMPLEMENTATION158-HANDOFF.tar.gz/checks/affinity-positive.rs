use vstd::prelude::*;
use vstd::raw_ptr::{Dealloc, PointsToRaw};

#[path = "../candidate/source/vstd/proposals/native_allocator158.rs"]
mod proposal;

verus! {
proof fn consume(tracked raw: PointsToRaw, tracked dealloc: Dealloc) {}

pub proof fn conditional_transport(tracked raw: PointsToRaw, tracked dealloc: Dealloc) {
    consume(raw, dealloc);
}
}
