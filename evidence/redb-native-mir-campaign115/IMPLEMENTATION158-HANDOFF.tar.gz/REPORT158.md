# Task158: fixed native allocator primitive proposal / partial occurrence bridge

**PENDING_REVIEW / UNCOMPILED / NOT ADOPTED / NATIVE EXPORT REFUSED.**
All18 required cells remain OPEN; first target remains two-phase acknowledged
durability. Accepted original native allocations0, stores0, bodies0; laws
adopted0. No original application or solver proof was executed. No live157
review was inspected. No subdelegation, network, Git writes, destructive
cleanup, parent integration or original/frozen input edits occurred.

## Delivered

- LAW158.md fixes NATIVE_RAW_ALLOC_NORMAL158_V1 as a NEW PRIMITIVE TCB proposal,
  not inherited allocate reuse or a checked allocator implementation. It lists
  every proposed trusted equation, exact real resource types, normal-success
  premises, excluded outcomes/gifts, runtime/cfg/ABI/allocator qualifications
  and mandatory independent review / explicit disposition checklist.
- API158.json fixes one compiler-owned operation, no public resource issuer,
  arbitrary relations/binders or generic law-injection API. The real-vstd
  specification predicate is only a Boolean predicate, not a trusted issuer;
  it is not linked into vstd. There is no assume_new implementation.
- candidate/source/rust_verify/src/bin/primitive158.rs and primitive158.rs
  propose a default-off, compiler-owned diagnostic producer selecting the
  actual typed original raw allocator call's operands, result place, normal
  continuation and unwind edge. It does not generate another allocation.
  Even explicitly opted in, it only serializes a pending metadata node and
  unconditionally diagnoses native export refusal. It cannot adopt the law.
- source-relative158.patch is relative to authenticated156 candidate/source;
  unchanged source is inherited via the pinned156 archive, not re-packaged.

## Precise result and remaining technical gap

This is partial source, NOT a compiled candidate or demonstrated158 compiler
producer run. The exact new bin never finished building and produced no
pending.json. Original-route facts are inherited156 observations; no new
compiler observation or semantic correspondence is claimed.

G1/G2 remain OPEN: dynamic actual activation/occurrence identity, same full
specification-pointer interpretation, consumptive event witness, native live
resource environment and same-continuation genuine PointsToRaw/Dealloc
issuance are not implemented. A non-Clone private Rust pending node is not
native affine authority. Static typed call identity, numeric pointer equality,
shared alloc leaf or serialized descriptors do not discharge those obligations.
Global/stale-holder/replay gates remain OPEN. No original authority is minted.

Native combined Layout/size/alignment/positive branch, actual normal nonnull
return, header initialization/resource conservation, metadata/projection,
iterator/enumeration/index/prior-value flow, caller/Arc/cache/callback/frame
and durability composition remain checked obligations, not trusted summaries.

The candidate binary reuses156's existing selector/store helper source and
retains dead legacy string-generating helpers through that include. The158
callback invokes neither legacy lower nor allocation_lower156. Thus this is
not another generated wrapper allocation milestone. Compilation and safety
of this new callback have NOT been established.

## Failed build and exact budget breach

The first build was offline --locked -j1 with minimal allowlisted environment.
It rebuilt cached dependencies after scratch relocation/feature selection.
At 2026-11-08T23:53:51.526616Z the runner's resource check observed:

- logical scratch2159791964 bytes (12308316 over2147483648);
- allocated scratch2174758912 bytes (27275264 over2147483648);
- free disk27498385408 bytes, strictly above16GiB.

The watchdog then killed the owned process group and waited/reaped it. The
runner's finally block made a second enforcing resource call, which raised
before writing the normal build receipt. That receipt-completion defect is
preserved, not hidden or claimed repaired. compiler-build.launch.json, source
snapshot, raw stdout/stderr and the last successful resource samples remain.
The offending values are from the retained tool traceback, not invented
entries in the sample stream. The final code path reached the post-reap
resource call; a separate signal0 group probe at23:55:37.294427Z observed the
group absent and candidate binary nonexistent. Raw build exit status was
not retained; do not relabel this as a compiler diagnostic rejection or pass.

**The strict2GiB scratch requirement was NOT met.** Sampling after growth is
not a hard filesystem quota. No cleanup or resumed build/test is attempted to
conceal the breach. Only small custody/seal metadata is written thereafter;
those extra bytes remain counted and explicitly noncompliant. See final
HANDOFF158.json for actual final samples and release. No allowance is reset.

## Checks and custody

Supplied156 HANDOFF and archive pins match. All1789 regular unique archive
members were byte-compared to the retained156 endpoints without extraction.
Candidate sources were copied only into fresh task158 scratch. Full selected
source/tool/library/original endpoints were hashed at entry and rechecked
before each charged run; final authentication records endpoint exit status.
The declared limit is selected local endpoints, not OS loader transitive
closure, upstream authenticity or source/binary/bootstrap correspondence.
No accepted conclusion depends on an unverified compiled158 artifact.

The generator initially failed because minimal PATH did not expose apply_patch;
the corrected explicit-tool-path generator succeeded. The transcript-only
inspection/setup/failure qualifications and numbering reconciliation are in
CUSTODY158.md. Seventeen total conservatively charged commands include the
single failed build and sealing. Planned affinity/WF/occurrence checks were
NOT RUN after the resource violation; their authored fixtures are unvalidated.
No solver was invoked, in particular none relying on the proposed law.

The seal archive includes source delta, law/API, scripts, selected-input and
source inventories, failures and raw streams; it excludes inherited/rebuilt
target binaries. Current target state is retained on disk without destructive
cleanup. Archive members are regular, unique and read back byte-for-byte.
Postarchive receipt/handoff/release are separately pinned to avoid circular
hash claims. Parent must independently review before ANY law disposition.

Compiler slot: RELEASE is recorded only after the final seal child is reaped
and the owned compiler process group is again observed absent. No followup
review/build/watch is scheduled. Historical156 exhausted36/36,14336/36,
14024/24 and interrupted116 are unchanged.
