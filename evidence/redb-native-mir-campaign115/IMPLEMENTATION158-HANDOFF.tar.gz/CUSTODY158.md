# Task158 custody qualifications

Start is November8 2026 23:46:46 UTC, deadline 00:26:46 UTC November9.
Six preliminary shell inspections plus isolated setup are charged7. Three
numbered inspections7/8/9 were written with a stale numbering base; those labels
are identifiers, not total charges. Three additional tool-transcript-only
commands (bounded helper read, candidate-generator failure, generator-path/env
inspection) are charged3. Thus after those inspections and failure total13;
the next runner attempt is14. All are conservatively charged, including reads.

The initial candidate generator failed FileNotFoundError for apply_patch under
the deliberately minimal PATH. Its proposed files preceding generation were
successfully patched; the compiler bin was not created by that failed attempt.
The failure's raw tool output/argv are in the parent transcript; there are no
invented local clocks/streams for transcript-only commands. The corrected
generator uses the explicit tool path and runs under the captured runner.

No inherited environment was printed or forwarded. The setup receipt records
only env-i PATH. Compiler children receive an explicit allowlist selected from
the sealed156 launch plus task-owned Cargo/tmp variables, jobs1/offline. The
inherited snapshot label in environment.json is historical156; runner commands
replace it with this task's actual initial-source inventory hash.

No live157 review is inspected. Original redb AGENTS.md applies only to the
read-only original tree, which is never edited or executed. Its application
test requirement is not invoked in this separate compiler proposal.
