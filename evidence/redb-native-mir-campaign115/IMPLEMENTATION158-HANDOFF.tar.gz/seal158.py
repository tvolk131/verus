import difflib
import hashlib
import json
import os
from pathlib import Path
import tarfile
import time

ROOT = Path('/private/tmp/redb-primitive158-20261108-234646')
BASE = Path('/private/tmp/redb-allocation156-20261108-230238')

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def write(path, value):
    Path(path).write_text(json.dumps(value, sort_keys=True, indent=2) + '\n')

def group_absent():
    launch = json.loads((ROOT / 'compiler-build.launch.json').read_text())
    try:
        os.killpg(launch['pid'], 0)
        return False
    except ProcessLookupError:
        return True

began = time.time_ns()
assert group_absent()
mismatches = [entry['path'] for entry in json.loads((ROOT / 'inputs.json').read_text()) if sha(entry['path']) != entry['sha256']]
write(ROOT / 'authentication-exit.json', dict(time_ns=time.time_ns(), mismatches=mismatches))
assert not mismatches
delta = []
patch = []
for path in sorted((ROOT / 'candidate/source').rglob('*')):
    if not path.is_file():
        continue
    relative = path.relative_to(ROOT / 'candidate/source')
    previous = BASE / 'candidate/source' / relative
    if previous.exists() and previous.read_bytes() == path.read_bytes():
        continue
    delta.append(str(path.relative_to(ROOT)))
    before = previous.read_text().splitlines(keepends=True) if previous.exists() else []
    patch.extend(difflib.unified_diff(before, path.read_text().splitlines(keepends=True),
                 fromfile='a/' + str(relative) if previous.exists() else '/dev/null', tofile='b/' + str(relative)))
(ROOT / 'source-relative158.patch').write_text(''.join(patch))
write(ROOT / 'source-delta158.json', [dict(path=relative, bytes=(ROOT / relative).stat().st_size, sha256=sha(ROOT / relative)) for relative in delta])
excluded = {'target', 'tmp', 'candidate'}
postarchive = {'HANDOFF158.tar.gz', 'MANIFEST158.json', 'HANDOFF158.json', 'RELEASE158.json', 'SEAL158.json',
               'seal.stdout', 'seal.stderr', 'seal.launch.json', 'seal.receipt.json'}
payloads = [path for path in ROOT.rglob('*') if path.is_file() and not any(part in excluded for part in path.relative_to(ROOT).parts)
            and path.name not in postarchive]
payloads += [ROOT / name for name in delta]
payloads = sorted(set(payloads))
manifest = dict(task='campaign94-task158', classification='PENDING_REVIEW_UNCOMPILED_PARTIAL_NEW_PRIMITIVE_TCB',
                inputs156=dict(handoff_sha256=sha(BASE / 'HANDOFF156.json'), archive_sha256=sha(BASE / 'HANDOFF156.tar.gz')),
                target_binaries='RETAINED_ON_DISK_NOT_PACKAGED; NO158BINARY',
                payloads=[dict(path=str(path.relative_to(ROOT)), bytes=path.stat().st_size, sha256=sha(path)) for path in payloads])
write(ROOT / 'MANIFEST158.json', manifest)
payloads.append(ROOT / 'MANIFEST158.json')
archive = ROOT / 'HANDOFF158.tar.gz'
with tarfile.open(archive, 'w:gz') as package:
    for path in payloads:
        assert path.is_file() and not path.is_symlink()
        package.add(path, arcname=str(path.relative_to(ROOT)), recursive=False)
seen = set()
with tarfile.open(archive) as package:
    for member in package:
        assert member.isfile() and member.name not in seen
        assert not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
        seen.add(member.name)
        assert package.extractfile(member).read() == (ROOT / member.name).read_bytes()
assert seen == {str(path.relative_to(ROOT)) for path in payloads}
write(ROOT / 'SEAL158.json', dict(start_ns=began, end_ns=time.time_ns(), archive_sha256=sha(archive),
    manifest_sha256=sha(ROOT / 'MANIFEST158.json'), regular_unique_byte_identical_members=len(seen),
    payloads=len(manifest['payloads']), source_delta_files=len(delta), compiler_group_absent=group_absent(),
    scratch_bound='FAILED_BEFORE_SEAL_NO_RETRY_OR_CLEANUP', laws_adopted=0, accepted_original_allocations=0,
    accepted_original_stores=0, accepted_original_bodies=0, all18='OPEN', native_export='REFUSED'))
print(json.dumps(dict(archive=str(archive), sha256=sha(archive), members=len(seen))))
