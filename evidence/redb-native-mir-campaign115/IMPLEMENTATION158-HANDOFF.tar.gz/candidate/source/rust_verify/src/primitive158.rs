struct PendingIssue158<'tcx> {
    owner: ty::Instance<'tcx>,
    callee: ty::Instance<'tcx>,
    block: rustc_middle::mir::BasicBlock,
    size: Operand<'tcx>,
    align: Operand<'tcx>,
    result: Place<'tcx>,
    continuation: rustc_middle::mir::BasicBlock,
    unwind: String,
}

impl PendingIssue158<'_> {
    fn into_pending_continuation(self) -> Value {
        json!({
            "kind": "PendingNativeAllocatorNormalReturn158",
            "authority": "NONE_METADATA_ONLY_NOT_POINTS_TO_RAW_OR_DEALLOC",
            "owner_instance": format!("{:?}", self.owner),
            "callee_instance": format!("{:?}", self.callee),
            "call_block": self.block.as_usize(),
            "actual_size_operand": format!("{:?}", self.size),
            "actual_align_operand": format!("{:?}", self.align),
            "actual_result_place": format!("{:?}", self.result),
            "normal_continuation": self.continuation.as_usize(),
            "unwind": self.unwind,
            "pointer_transport": "ACTUAL_PLACE_HELD_NO_ADDRESS_SUBSTITUTION_NO_SPEC_POINTER_CREATED",
            "dynamic_activation_and_affinity": "OPEN_NO_ACTIVATION_ID_OR_GLOBAL_OCCURRENCE_LEDGER",
            "stale_holders": "OPEN_NO_NATIVE_RESOURCE_ENVIRONMENT_THREADING",
            "semantic_application": "FORBIDDEN_PENDING_REVIEW_AND_EXPLICIT_PARENT_DISPOSITION",
        })
    }
}

fn pending_occurrence158<'tcx>(tcx: TyCtxt<'tcx>, store: &TypedStore<'tcx>, allocation: &AllocationCut156, enabled: bool) -> Value {
    let mut queue = VecDeque::from([(store.instance, Vec::<Value>::new(), Vec::<ty::Instance<'tcx>>::new())]);
    let mut runtime = Vec::new();
    let mut explored = 0usize;
    while let Some((instance, path, ancestors)) = queue.pop_front() {
        explored += 1;
        assert!(explored <= 350 && ancestors.len() <= 14, "bounded exact call-path selection exhausted");
        assert!(!ancestors.contains(&instance), "recursive activation path unsupported");
        let mut next_ancestors = ancestors;
        next_ancestors.push(instance);
        for (callee, block, record) in resolved_calls156(tcx, instance) {
            let name = tcx.opt_item_name(callee.def_id()).map(|name| name.as_str().to_owned()).unwrap_or_default();
            if tcx.crate_name(callee.def_id().krate).as_str() != "alloc" { continue; }
            let mut next_path = path.clone();
            next_path.push(record);
            if name == "alloc_impl_runtime" {
                let body = tcx.instance_mir(instance.def);
                let data = body.basic_blocks.iter().nth(block).unwrap();
                let TerminatorKind::Call { args, .. } = &data.terminator().kind else { unreachable!() };
                assert_eq!(args.len(), 2);
                let Operand::Constant(zeroed) = &args[1].node else { panic!("selected invocation requires actual false operand") };
                assert_eq!(zeroed.const_.try_eval_scalar_int(tcx, ty::TypingEnv::fully_monomorphized()).expect("zeroed constant").to_u8(), 0);
                runtime.push((callee, next_path));
                continue;
            }
            if matches!(name.as_str(), "allocate_for_slice" | "allocate_for_layout" | "allocate" | "alloc_impl" | "call_once" | "")
                && tcx.is_mir_available(callee.def_id()) {
                queue.push_back((callee, next_path, next_ancestors.clone()));
            }
        }
    }
    assert_eq!(runtime.len(), 1, "one exact incoming runtime invocation path required; no instance-only deduplication");
    let (owner, path) = runtime.pop().unwrap();
    let body = tcx.instance_mir(owner.def);
    let mut leaves = Vec::new();
    for (block, data) in body.basic_blocks.iter_enumerated() {
        let TerminatorKind::Call { func, args, destination, target, unwind, .. } = &data.terminator().kind else { continue };
        let function_type = instantiate(tcx, owner, func.ty(&body.local_decls, tcx));
        let ty::FnDef(definition, arguments) = *function_type.kind() else { continue };
        if tcx.crate_name(definition.krate).as_str() != "alloc"
            || tcx.opt_item_name(definition).is_none_or(|name| name.as_str() != "__rust_alloc") { continue; }
        let callee = ty::Instance::try_resolve(tcx, ty::TypingEnv::fully_monomorphized(), definition, arguments.skip_binder()).unwrap().unwrap();
        assert_eq!(args.len(), 2);
        for argument in args {
            assert_eq!(instantiate(tcx, owner, argument.node.ty(&body.local_decls, tcx)), tcx.types.usize);
        }
        assert_eq!(instantiate(tcx, owner, destination.ty(&body.local_decls, tcx).ty), Ty::new_mut_ptr(tcx, tcx.types.u8));
        assert!(!data.is_cleanup);
        let continuation = target.expect("normal return edge required");
        assert!(!body.basic_blocks[continuation].is_cleanup);
        let scope = &body.source_scopes[data.terminator().source_info.scope];
        let (inline, _) = scope.inlined.expect("inlined alloc owner required");
        assert_eq!(tcx.crate_name(inline.def_id().krate).as_str(), "alloc");
        assert_eq!(tcx.item_name(inline.def_id()).as_str(), "alloc");
        leaves.push(PendingIssue158 { owner, callee, block, size: args[0].node.clone(), align: args[1].node.clone(), result: *destination, continuation, unwind: format!("{unwind:?}") });
    }
    assert_eq!(leaves.len(), 1, "one selected nonzeroed raw allocator leaf required");
    let issue = leaves.pop().unwrap();
    let location = json!({"owner": format!("{owner:?}"), "block": issue.block.as_usize(), "body_sha256": digest(format!("{body:#?}").as_bytes())});
    let selected = if enabled { Some(issue.into_pending_continuation()) } else { None };
    json!({
        "schema": "native-allocator158-fixed-pending-occurrence-v1",
        "law": "NATIVE_RAW_ALLOC_NORMAL158_V1",
        "classification": "NEW_PRIMITIVE_TCB_PROPOSAL_NOT_INHERITED_ALLOCATE_REUSE",
        "status": "PENDING_REVIEW", "feature_default": false, "occurrence_opt_in": enabled,
        "source_root": store.record, "source_allocation156": allocation.record,
        "exact_incoming_path": path, "selected_static_location": location,
        "actual_runtime_mir": format!("{body:#?}"), "pending_node": selected,
        "gates": {
            "independent_exact_law_review": "OPEN", "explicit_parent_disposition": "OPEN",
            "actual_valid_positive_size_align": "OPEN", "actual_nonzero_branch": "OPEN",
            "actual_normal_nonnull_return": "OPEN", "full_spec_pointer_binding": "OPEN",
            "dynamic_activation_unique_issuance": "OPEN", "stale_holder_global_occurrence": "OPEN",
            "resource_continuation_and_effects": "OPEN", "runtime_cfg_abi_allocator_binding": "OPEN",
            "native_layout_header_iterator_caller": "OPEN"
        },
        "real_resource_issues": 0, "accepted_original_allocations": 0,
        "accepted_original_stores": 0, "accepted_original_bodies": 0, "laws_adopted": 0,
        "native_export": "REFUSED", "all18": "OPEN",
    })
}
