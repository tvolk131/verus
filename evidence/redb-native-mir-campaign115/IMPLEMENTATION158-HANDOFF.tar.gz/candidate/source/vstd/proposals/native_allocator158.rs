use vstd::prelude::*;
use vstd::raw_ptr::{Dealloc, DeallocData, PointsToRaw};

verus! {
pub open spec fn normal_resources158(
    pointer: *mut u8,
    size: usize,
    align: usize,
    raw: PointsToRaw,
    dealloc: Dealloc,
) -> bool {
    &&& vstd::layout::valid_layout(size, align)
    &&& size > 0
    &&& pointer.addr() != 0
    &&& raw.is_range(pointer.addr() as int, size as int)
    &&& pointer.addr() + size <= usize::MAX + 1
    &&& pointer.addr() as int % align as int == 0
    &&& pointer@.provenance == raw.provenance()
    &&& dealloc@ == (DeallocData {
        addr: pointer.addr(),
        size: size as nat,
        align: align as nat,
        provenance: pointer@.provenance,
    })
}
}
