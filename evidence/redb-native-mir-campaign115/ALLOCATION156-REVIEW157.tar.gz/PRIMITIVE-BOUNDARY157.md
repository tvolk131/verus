# Minimum allocation-event boundary157 (PROPOSED ONLY; UNADOPTED)

This is an independent boundary recommendation under139/155, not a new law,
an installed spec, a native acceptance, or a review of the prior reviewer.

## A. First try the already-authorized contract without duplicating an event

An exact checked refinement may identify THIS original normally successful
positive/nonzeroed allocation activation with one application of inherited
vstd::raw_ptr::allocate(size,align)'s normal-return transition. The proof must
identify the actual native Layout's size/alignment, executed runtime branch,
single event and returned full specification pointer/provenance; only then can
the single raw+Dealloc issuance feed the original continuation. The wrapper call
is a semantic counterpart, not a second executed allocation. Resource flow must
be checked, not recovered from syntactic placement or declared metadata.

The selected inherited contract is external_body/std raw_ptr.rs:908. It requires
valid_layout and nonzero size and provides exact raw range, alignment/end bounds,
same pointer/provenance and matching Dealloc on normal return. It gives no zero
contents, Arc state, no_unwind or arbitrary ambient frame. Existing split,
into_typed, ptr_mut_write and deallocate remain under their real premises.

A theorem that two wrappers eventually call alloc is not this refinement.
Neither is executing the inherited wrapper separately, equating numeric
addresses, taking assumed PointsToRaw inputs, calling assume_new, annotating a
native MIR call with a resource label, or declaring every raw pointer owned.

## B. If A is unavailable: the smallest additional trusted normal boundary

The minimum is RESOURCE ISSUANCE AT THE ACTUAL ALLOCATION EVENT, not Arc creation,
not the native collection loop, not a whole-function Global/Arc equivalence.
Pin the selected native nonzero/nonzeroed global allocation leaf (the recorded
alloc::__rust_alloc call) or an exactly justified equivalent allocator ABI event.
The proposal must bind actual allocator implementation/shim/interface, target,
cfg/features/profile and calling/outcome semantics. A mere DefId/name or compiler
MIR Assert/Assume is not an allocator contract or historical loaded-code pin.

### Exact input/success clauses needed

1. This one dynamic activation has concrete size s and alignment a, with checked
   positive s, valid_layout(s,a), exact ABI argument correspondence, and checked
   nonzeroed runtime selection. Do not trust native layout calculations here.
2. Conditional on THAT event normally returning nonnull pointer p, issue ONCE
   genuine affine PointsToRaw R for [addr(p),addr(p)+s) and matching affine
   Dealloc D. R and D carry p's full live specification provenance, exact s/a,
   aligned address and nonwrapping representable endpoint, just as the inherited
   successful allocation resource contract requires. Pointer metadata/casts in
   native wrappers still need checked interpretation.
3. Ownership is for the allocation denoted by that event, not an unrelated fresh
   allocation chosen as a witness. Live-resource nonduplication is enforced by
   the resource semantics. Do not add a global numeric freshness tag, global
   address uniqueness across time, or an unreviewed stronger provenance axiom.
4. R is raw/uninitialized permission. No initialized byte value, zero fill,
   AtomicUsize state, Arc uniqueness/strong/weak count, iterator/caller invariant,
   eventual success, successful cleanup or reusable resource after deallocation
   is issued. Existing split/typed conversion/store rules do that later work.
5. State exactly which live allocation/owned-memory frame the allocator interface
   preserves, if that preservation is needed. Its source/semantic basis must be
   separately justified at the exact boundary. opens_invariants none is not
   arbitrary ambient state noninterference. Do not infer inert allocator reentry,
   callback/panic-hook behavior, cache preservation or an atomic global frame.
   Anything outside the justified primitive footprint stays an explicit checked
   frame/outcome obligation; if absent, composition remains blocked.

### Outcomes not covered by the success clause

Null return / allocation error, zero-size dangling success, zeroed allocation,
handler calls, panic/unwind, abort and divergence are separate cases. The success
clause does not create a successful range/token on these paths or erase any
permitted partial effects. Non-normal traces do not gain a rollback or frame
claim. If the exact ABI excludes an unwind case, justify that exact exclusion;
do not infer a universal no_unwind or termination theorem from this wrapper.

In particular native Global null -> Err -> Arc handle_alloc_error differs from
inherited allocate null -> process::abort. A normal-success relational cut may
ignore neither this difference when proving whole behavior nor callback effects
when proving a frame. No poisoned lock behavior, latest-value load, weak-CAS
progress or finite panic-hook completion is supplied by allocation trust.

### Adoption gate

Such a leaf resource law would be NEW TRUST if not derived from the inherited
contract by a checked event-preserving semantics. It needs an exact separate
proposal, independent review and explicit parent disposition before internal
adoption. Authorization139 permits that narrow development/review; disposition155
does not silently authorize it. No law is installed or adopted in review157.

## C. What remains application/compiler proof, never part of B

- Bind original zero_filled_arc/RepeatN<u8>/collect/Arc instances, actual closure
  and call activation, event/result projections and control/outcome path. Prove
  the selected typed producer corresponds to the executable occurrence; hashes
  and source resemblance are only identity observations.
- Derive actual successful Layout::array, extend and pad arithmetic, lengths,
  target-dependent ArcInner field offsets/alignment, overflow/isize bounds and
  exact allocator s/a. Generated header16/align8 are recorded target results,
  not portable laws. len0 still requires a positive combined header allocation;
  it gives no payload cell.
- Track genuine permissions through native strong/weak initialization, metadata
  construction, guards, raw casts, all relevant calls/reentry and normal/cleanup
  edges. Account for initialized header values rather than returning a fictional
  untouched raw header. Prove original Arc/control state and needed atomic
  semantics separately; an allocation law does not justify Arc validity.
- Prove actual RepeatN/Enumerate length, index progression, byte operand, object
  bounds and Offset full pointer identity. Some(payload) is not index<len. For
  every store split the exact one-byte subrange from CURRENT live raw ownership,
  preserve prior typed initialized values and header/complement resources, and
  carry the same matching Dealloc. Empty-domain/descriptive tokens cannot supply
  a nonempty cell; joining raw domains cannot preserve forgotten value facts.
- Prove return/cleanup/deallocation and native caller preconditions and frame.
  Do not assume valid callers, callback/reentry frames, successful locks,
  constructor totality, rollback, cache reservations across unlock, native
  maps/hashers, buffer/backend correspondences or logical recovery invariants.
- Compose native WritablePage memory/copy/drop, checkout/reservation/return,
  buffering/flush/barriers/public acknowledgement, failure/close/reopen/crashes,
  physical roots/tree/allocator effects and logical later-history recovery.
  The original full two-phase acknowledged-durability cell and all other17
  cells remain OPEN until their actual campaign94 closure gates are met.

Bottom line: either CHECKED SAME-EVENT REFINEMENT to an existing permitted
normal allocation resource transition, or a separately reviewed/disposed exact
native normal allocation-event issuance primitive. Neither route permits moving
Arc/layout/iterator/application/caller obligations into a trusted summary.
