import datetime
import hashlib
import json
import pathlib
import stat
import tarfile

ROOT = pathlib.Path('/private/tmp/redb-allocation156-20261108-230238')
OUT = pathlib.Path('/private/tmp/redb-review157-20261108-234518')
AUTHORITY = pathlib.Path('/Users/tommyvolk/.t3/worktrees/verus/t3-60978068/evidence/redb-native-mir-campaign115')
PINS = {'HANDOFF156.json': '3b7a3fb633dc793c16a441f30fbafa8b1e875c9f2ef53ac6ac53ea2cf84df582', 'HANDOFF156.tar.gz': '1d49f719b9d15749aa741ce9b2aa7c629867abc191639526fdb1b5278cd64095'}

def digest(path):
    assert stat.S_ISREG(path.lstat().st_mode), str(path)
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1048576), b''):
            value.update(chunk)
    return value.hexdigest()

def sample():
    import os
    values = os.statvfs(OUT)
    free = values.f_bavail * values.f_frsize
    files = [path for path in OUT.rglob('*') if path.is_file()]
    result = {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'free_bytes': free, 'logical_bytes': sum(path.stat().st_size for path in files), 'allocated_bytes': sum(path.stat().st_blocks * 512 for path in files)}
    assert free > 16 * 1024**3
    assert max(result['logical_bytes'], result['allocated_bytes']) <= 4 * 1024**2
    return result

started = sample()
manifest = json.loads((ROOT / 'MANIFEST156.json').read_text())
handoff = json.loads((ROOT / 'HANDOFF156.json').read_text())
entries = {entry['path']: entry for entry in manifest['payloads']}
assert len(entries) == len(manifest['payloads'])
assert digest(ROOT / 'MANIFEST156.json') == handoff['manifest_sha256']
for name, expected in PINS.items():
    assert digest(ROOT / name) == expected, name
selected = {'REPORT156.md', 'BRIDGE156.md', 'BRIDGE156-OBLIGATIONS.json', 'CUSTODY156.md', 'FAILURES156.md', 'CHANGES156.patch', 'AUTHORITY-ENDPOINTS156.json', 'candidate/source/rust_verify/src/allocation156.rs', 'candidate/source/rust_verify/src/bin/permission154.rs', 'candidate/source/vstd/raw_ptr.rs'}
for path in entries:
    if path.startswith(('proof/final-cut-', 'proof/isolated-cut-', 'proof/restored-cut')):
        selected.add(path)
    if path.startswith(('final-checked-normal.', 'final-wrong-', 'final-missing-issuance.', 'restored-normal.', 'restored-cut.', 'compiler-conservation-final.', 'compiler-disposition155-final.')):
        selected.add(path)
    if path.startswith(('solver-final-checked-normal/', 'solver-final-wrong-', 'solver-final-missing-issuance/', 'solver-restored-normal/')):
        selected.add(path)
    if path.startswith('authority/') and pathlib.PurePosixPath(path).name in ['AUTHORIZATION139.md', 'ALLOCATION-CONTRACT-DISPOSITION155.md', 'FIRST-CELL139.md', 'STORE-CONTRACT-DISPOSITION153.md']:
        selected.add(path)
assert selected <= entries.keys(), selected - entries.keys()
observed = {}
for name in sorted(selected):
    path = ROOT / name
    actual = digest(path)
    assert actual == entries[name]['sha256'], name
    assert path.stat().st_size == entries[name]['bytes'], name
    observed[name] = {'sha256': actual, 'bytes': path.stat().st_size, 'manifest_match': True}
archive_names = set()
matched = set()
total = 0
with tarfile.open(ROOT / 'HANDOFF156.tar.gz', 'r|gz') as archive:
    for member in archive:
        total += 1
        assert member.isfile() and not member.issym() and not member.islnk(), member.name
        assert member.name not in archive_names, member.name
        archive_names.add(member.name)
        assert not pathlib.PurePosixPath(member.name).is_absolute() and '..' not in pathlib.PurePosixPath(member.name).parts
        if member.name in selected or member.name == 'MANIFEST156.json':
            stream = archive.extractfile(member)
            value = hashlib.sha256()
            for chunk in iter(lambda: stream.read(1048576), b''):
                value.update(chunk)
            expected = handoff['manifest_sha256'] if member.name == 'MANIFEST156.json' else observed[member.name]['sha256']
            assert value.hexdigest() == expected, member.name
            matched.add(member.name)
assert selected | {'MANIFEST156.json'} == matched
assert archive_names == set(entries) | {'MANIFEST156.json'}
authority = {name: {'sha256': digest(AUTHORITY / name), 'bytes': (AUTHORITY / name).stat().st_size} for name in ['AUTHORIZATION139.md', 'ALLOCATION-CONTRACT-DISPOSITION155.md', 'FIRST-CELL139.md']}
result = {'task': 'review157', 'coverage': 'Selected current extracted payload hashes compared with supplied-pinned sealed archive and manifest. Archive member metadata/uniqueness checked globally; unselected payload bytes NOT individually authenticated. No historical bootstrap or continuous custody claim.', 'input_root': str(ROOT), 'supplied_pins_verified': PINS, 'manifest_sha256': digest(ROOT / 'MANIFEST156.json'), 'selected_payload_count': len(selected), 'archive_member_count': total, 'archive_all_regular_unique_safe_names': True, 'selected_archive_payloads_matched': len(matched), 'authority_endpoints': authority, 'selected_endpoints': observed, 'start_sample': started, 'end_sample': sample()}
(OUT / 'INPUT-ENDPOINTS157.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
print(json.dumps({'selected_payload_count': len(selected), 'archive_member_count': total, 'selected_archive_matches': len(matched), 'resource_sample': sample()}, indent=2))
