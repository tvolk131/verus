import hashlib
import json
import pathlib
import re

ROOT = pathlib.Path('/private/tmp/redb-allocation156-20261108-230238')
OUT = pathlib.Path('/private/tmp/redb-review157-20261108-234518')

def digest(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1048576), b''):
            value.update(chunk)
    return value.hexdigest()

receipt_names = ['final-checked-normal', 'final-wrong-offset', 'final-wrong-extent', 'final-wrong-provenance', 'final-missing-issuance', 'final-wrong-byte', 'restored-normal', 'restored-cut']
checks = {}
external = {}
for name in receipt_names:
    receipt = json.loads((ROOT / (name + '.receipt.json')).read_text())
    for stream in ['stdout', 'stderr']:
        path = ROOT / (name + '.' + stream)
        assert digest(path) == receipt['streams'][stream]['sha256']
        assert path.stat().st_size == receipt['streams'][stream]['bytes']
    argument_checks = []
    for entry in receipt['argument_inputs']:
        path = pathlib.Path(entry['path'])
        if path.is_file() and 'sha256' in entry:
            actual = digest(path)
            argument_checks.append({'path': str(path), 'sha256': actual, 'recorded_sha256': entry['sha256'], 'matches': actual == entry['sha256']})
            external[str(path)] = {'sha256': actual, 'bytes': path.stat().st_size, 'current_endpoint_only': True}
    checks[name] = {'receipt_number': receipt['number'], 'recorded_returncode': receipt['returncode'], 'recorded_reaped': receipt['reaped'], 'recorded_owned_group_absent': receipt['owned_group_absent'], 'recorded_start_utc': receipt['start_utc'], 'recorded_end_utc': receipt['end_utc'], 'recorded_executable_sha256': receipt['executable_sha256'], 'stream_hashes_verified': True, 'argument_current_endpoints': argument_checks, 'environment_keys_only': sorted(receipt['env']), 'recorded_before': receipt['before'], 'recorded_after': receipt['after']}
    assert all(entry['matches'] for entry in argument_checks)
normal = ROOT / 'proof/isolated-cut-normal.rs'
restored = ROOT / 'proof/restored-cut.rs'
assert normal.read_bytes() == restored.read_bytes()
source = normal.read_text()
air = (ROOT / 'solver-final-checked-normal/root.air').read_text()
unit_names = re.findall(r'^;; Function-Def isolated_cut_normal::([^\n]+)', air, re.M)
assert len(unit_names) == 7
executable_names = re.findall(r'^pub fn (generated_[a-z0-9_]+)', source, re.M)
assert len(executable_names) == 5
solver_outcomes = {}
for directory in ['solver-final-checked-normal', 'solver-restored-normal', 'solver-final-wrong-offset', 'solver-final-wrong-extent', 'solver-final-wrong-provenance', 'solver-final-wrong-byte']:
    text = (ROOT / directory / 'root.smt_transcript').read_text()
    outcomes = re.findall(r'^(sat|unsat|unknown)$', text, re.M)
    solver_outcomes[directory] = {'sat': outcomes.count('sat'), 'unsat': outcomes.count('unsat'), 'unknown': outcomes.count('unknown'), 'incomplete_quantifiers_markers': text.count('(incomplete quantifiers)')}
binding = json.loads((ROOT / 'proof/restored-cut.binding.json').read_text())
original = pathlib.Path(binding['root_source_path'])
external[str(original)] = {'sha256': digest(original), 'bytes': original.stat().st_size, 'recorded_binding_sha256': binding['root_source_sha256'], 'matches': digest(original) == binding['root_source_sha256'], 'current_endpoint_only': True}
assert external[str(original)]['matches']
mir_checks = []
for record in binding['allocation156']['typed_instances_and_paths']:
    actual = hashlib.sha256(record['mir'].encode()).hexdigest()
    assert actual == record['mir_sha256']
    mir_checks.append({'name': record['name'], 'mir_sha256': actual, 'matches': True})
result = {'method': 'Static source, emitted AIR/SMT transcript and retained receipt inspection only. No compiler/build/verifier/native execution; no replay attestation.', 'positive_generated_sha256': digest(normal), 'restored_byte_identical': True, 'seven_units_exact': unit_names, 'distinct_generated_executable_bodies': executable_names, 'new_generated_executable_bodies': 4, 'solver_transcript_outcomes': solver_outcomes, 'receipt_checks': checks, 'current_external_input_endpoints': external, 'embedded_mir_hash_checks': mir_checks, 'native_export_diagnostic_observed': 'ALLOCATION156_EXPORT_REFUSED' in (ROOT / 'restored-cut.stderr').read_text(), 'qualifications': ['Tool output containing a target inventory was truncated; no inference depends on unseen inventory entries.', 'Current binaries and source endpoint matches do not authenticate historical loaded bytes or source-to-binary bootstrap.', 'This reviewer does not reconstruct credential values or inspect private credential storage.']}
(OUT / 'EVIDENCE-CHECKS157.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
print(json.dumps({'seven_units': unit_names, 'positive_sha256': digest(normal), 'restored_byte_identical': True, 'solver_outcomes': solver_outcomes, 'receipt_count': len(checks), 'current_external_endpoints': len(external), 'embedded_mir_hashes_verified': len(mir_checks)}, indent=2))
