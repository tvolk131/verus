import datetime
import hashlib
import json
import os
import pathlib
import stat
import tarfile

ROOT = pathlib.Path('/private/tmp/redb-review157-20261108-234518')
INPUT = pathlib.Path('/private/tmp/redb-allocation156-20261108-230238')
AUTHORITY = pathlib.Path('/Users/tommyvolk/.t3/worktrees/verus/t3-60978068/evidence/redb-native-mir-campaign115')
START = datetime.datetime(2026, 11, 8, 23, 45, 18, tzinfo=datetime.timezone.utc)
DEADLINE = START + datetime.timedelta(minutes=15)
SAMPLES = []

def now():
    return datetime.datetime.now(datetime.timezone.utc)

def digest(path):
    assert stat.S_ISREG(path.lstat().st_mode)
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1048576), b''):
            value.update(chunk)
    return value.hexdigest()

def write(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

def sample(label):
    clock = now()
    assert clock < DEADLINE
    filesystem = os.statvfs(ROOT)
    files = [path for path in ROOT.rglob('*') if path.is_file()]
    result = {'label': label, 'utc': clock.isoformat(), 'logical_bytes': sum(path.stat().st_size for path in files), 'allocated_bytes': sum(path.stat().st_blocks * 512 for path in files), 'free_bytes': filesystem.f_bavail * filesystem.f_frsize}
    assert result['free_bytes'] > 16 * 1024**3
    assert max(result['logical_bytes'], result['allocated_bytes']) <= 4 * 1024**2
    SAMPLES.append(result)
    return result

sample('seal_entry')
inputs = json.loads((ROOT / 'INPUT-ENDPOINTS157.json').read_text())
for name, expected in inputs['supplied_pins_verified'].items():
    assert digest(INPUT / name) == expected
assert digest(INPUT / 'MANIFEST156.json') == inputs['manifest_sha256']
for name, expected in inputs['selected_endpoints'].items():
    assert digest(INPUT / name) == expected['sha256'], name
    assert (INPUT / name).stat().st_size == expected['bytes']
for name, expected in inputs['authority_endpoints'].items():
    assert digest(AUTHORITY / name) == expected['sha256']
    assert digest(INPUT / 'authority' / name) == expected['sha256']
checks = json.loads((ROOT / 'EVIDENCE-CHECKS157.json').read_text())
for name, expected in checks['current_external_input_endpoints'].items():
    assert digest(pathlib.Path(name)) == expected['sha256'], name
sample('all_selected_endpoints_rechecked')
write('ACCOUNTING157.json', {
    'task': 'review157', 'first_action_observed_utc': START.isoformat(),
    'deadline_utc': DEADLINE.isoformat(), 'accounting_cutoff_utc': now().isoformat(),
    'ceiling_fresh_logical_and_allocated_bytes': 4 * 1024**2,
    'free_disk_strict_lower_bound_bytes': 16 * 1024**3,
    'scope': 'Distinct static review and sealing only; original156 exhausted36/36 and116 interrupted preserved',
    'compiler_invocations': 0, 'build_invocations': 0, 'verifier_invocations': 0,
    'native_application_or_test_invocations': 0, 'network_requests': 0,
    'git_writes': 0, 'candidate_or_parent_edits': 0, 'subdelegations': 0,
    'law_adoptions': 0, 'compiler_slot': 'NOT_ACQUIRED_NOT_USED',
    'read_hash_shell_commands': 'Tool-transcript recorded; not an independently metered private runner command census',
    'review_script_invocations_through_this_seal': {'authenticate157.py': 2, 'inspect157.py': 1, 'seal157.py': 1},
    'input_archive_members_metadata_checked': inputs['archive_member_count'],
    'input_selected_payloads_individually_authenticated': inputs['selected_payload_count'],
    'input_endpoints_rechecked_at_seal': True,
    'samples': SAMPLES,
    'limits': 'Sampled current endpoints only; no continuous global disk/process/custody/bootstrap claim',
    'seal_projection': 'Archive and external seal/handoff add far less than1MiB; final exact bytes/time and all-member readback are reported postarchive in SEAL157/HANDOFF157, not circularly inside this accounting payload'
})
excluded = {'MANIFEST157.json', 'HANDOFF157.tar.gz', 'SEAL157.json', 'HANDOFF157.json', 'SHA256SUMS157.txt'}
payloads = []
for path in sorted(ROOT.iterdir()):
    if path.name in excluded:
        continue
    assert stat.S_ISREG(path.lstat().st_mode)
    payloads.append({'path': path.name, 'bytes': path.stat().st_size, 'sha256': digest(path)})
write('MANIFEST157.json', {'task': 'review157', 'payloads': payloads, 'postarchive_exclusions': sorted(excluded - {'MANIFEST157.json'})})
archive_path = ROOT / 'HANDOFF157.tar.gz'
members = [entry['path'] for entry in payloads] + ['MANIFEST157.json']
with tarfile.open(archive_path, 'w:gz', format=tarfile.USTAR_FORMAT) as archive:
    for name in members:
        archive.add(ROOT / name, arcname=name, recursive=False)
observed = set()
with tarfile.open(archive_path, 'r:gz') as archive:
    for member in archive:
        assert member.isfile() and not member.issym() and not member.islnk()
        assert member.name not in observed
        assert member.name in members
        assert archive.extractfile(member).read() == (ROOT / member.name).read_bytes()
        observed.add(member.name)
assert observed == set(members)
archive_path.chmod(0o444)
sample('archive_all_member_readback_complete')
seal = {'task': 'review157', 'archive': archive_path.name, 'archive_sha256': digest(archive_path), 'archive_bytes': archive_path.stat().st_size, 'manifest_sha256': digest(ROOT / 'MANIFEST157.json'), 'regular_unique_byte_identical_members': len(members), 'manifested_payloads': len(payloads), 'postarchive_utc': now().isoformat(), 'samples': SAMPLES, 'qualification': 'Postarchive endpoint evidence; archive does not contain this seal or future handoff. Selected input authentication only; no continuous/bootstrap custody.'}
write('SEAL157.json', seal)
handoff = {'task': 'campaign94-review157', 'root': str(ROOT), 'result': 'CONDITIONAL_GENERATED_SUBSET_RETAINED_G1_G2_OPEN_NO_NATIVE_ACCEPTANCE', 'report': 'REPORT157.md', 'primitive_boundary': 'PRIMITIVE-BOUNDARY157.md', 'findings': 'FINDINGS157.json', 'archive': archive_path.name, 'archive_sha256': seal['archive_sha256'], 'manifest_sha256': seal['manifest_sha256'], 'seal_sha256': digest(ROOT / 'SEAL157.json'), 'input_handoff156_sha256': inputs['supplied_pins_verified']['HANDOFF156.json'], 'input_archive156_sha256': inputs['supplied_pins_verified']['HANDOFF156.tar.gz'], 'selected_input_payloads_authenticated': inputs['selected_payload_count'], 'review_archive_regular_unique_byte_identical_members': len(members), 'seven_units': '2 constants +5 generated executable bodies,4 new', 'positive_restoration_byte_identical': True, 'semantic_controls': 'unknown/incomplete quantifiers, NOT SAT', 'new_laws_adopted': 0, 'original_allocation_store_whole_body_credits': [0, 0, 0], 'all18': 'OPEN', 'original156': 'EXHAUSTED36/36_PRESERVED', 'interrupted116': 'PRESERVED', 'compiler_slot': 'NOT_USED_NO_OWNED_COMPILER_CHILDREN_CREATED', 'followup_subdelegation_integration': False, 'parent_continues_independently': True, 'completion_utc': now().isoformat(), 'elapsed_seconds_from_first_observation': (now() - START).total_seconds(), 'fresh_resources_before_handoff': sample('pre_handoff'), 'resource_qualification': 'Endpoint samples only; final small handoff and checksum files are checked immediately after writing; no continuous global resource assertion'}
write('HANDOFF157.json', handoff)
names = ['HANDOFF157.tar.gz', 'MANIFEST157.json', 'SEAL157.json', 'HANDOFF157.json']
(ROOT / 'SHA256SUMS157.txt').write_text(''.join(digest(ROOT / name) + '  ' + name + '\n' for name in names))
final_sample = sample('handoff_and_checksums_written')
print(json.dumps({'handoff': str(ROOT / 'HANDOFF157.json'), 'handoff_sha256': digest(ROOT / 'HANDOFF157.json'), 'archive_sha256': seal['archive_sha256'], 'manifest_sha256': seal['manifest_sha256'], 'regular_unique_byte_identical_members': len(members), 'selected_input_payloads_authenticated': inputs['selected_payload_count'], 'final_resource_sample': final_sample, 'elapsed_seconds': (now() - START).total_seconds()}, indent=2))
