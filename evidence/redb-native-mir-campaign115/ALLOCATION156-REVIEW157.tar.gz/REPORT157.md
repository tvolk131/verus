# Independent review157 of sealed implementation156

Date: November 8, 2026. Authority: standing campaign94, AUTHORIZATION139,
FIRST-CELL139, and the exact parent ALLOCATION-CONTRACT-DISPOSITION155.
Review start observation: 2026-11-08T23:45:18Z. This is a distinct bounded
static review, not implementation156 continuation and not review-of-review.

## Disposition and explicit scope

RETAIN THE CONDITIONAL GENERATED SUBSET; DO NOT ACCEPT ORIGINAL NATIVE ISSUANCE.
No blocking concrete defect was identified in the inspected generated normal
helper/resource conservation. This is source/retained-evidence review, not a new
verification run or independent authentication of the loaded verifier semantics.
The requested same-original-event issuance milestone remains unachieved.

Original allocation occurrences accepted: 0. Original store occurrences accepted:
0. Original executable whole bodies verified: 0. New laws adopted: 0. All eighteen
campaign94 cells remain OPEN. P151-v1(A) and 147 H1/H2 remain UNADOPTED; 141 stays
rejected. Original156's exhausted 36/36 allowance and interrupted116 are preserved.
The first-cell target is still full original two-phase acknowledged durability,
not an allocation helper, a header-byte model, or an assumed-valid native caller.

## Authentication actually performed

The supplied HANDOFF156.json SHA256
3b7a3fb633dc793c16a441f30fbafa8b1e875c9f2ef53ac6ac53ea2cf84df582 and
HANDOFF156.tar.gz SHA256
1d49f719b9d15749aa741ce9b2aa7c629867abc191639526fdb1b5278cd64095 match current
regular-file endpoints. The handoff-pinned MANIFEST156.json hash matches.
199 selected extracted payloads match their manifest size/hash AND the bytes of
the corresponding sealed archive members. The embedded manifest also matches.
All 1,789 archive members were inspected for regular type, unique safe names, and
exact inventory equality to 1,788 manifested payloads plus the manifest.
UNSELECTED PAYLOAD BYTES WERE NOT INDIVIDUALLY HASHED AGAINST THE MANIFEST.

Selected coverage includes REPORT156, BRIDGE156 and its obligations, CUSTODY156,
FAILURES156, CHANGES156, compiler event-selection/emission sources, inherited
raw_ptr source, actual isolated positive/control and restored generated sources,
eight inspected receipts and associated raw streams, their selected launch/
resource/source records, and final positive/control/restoration solver artifacts.
INPUT-ENDPOINTS157.json enumerates the exact coverage. EVIDENCE-CHECKS157.json
records checked receipt stream hashes, current available argument endpoints,
embedded MIR hashes, and actual transcript outcomes. Current external native
root bytes match the binding hash. No historical source-to-binary, sysroot,
loaded-library, environment continuity or bootstrap attestation follows.

## (1) Actual seven-unit scope and resource conservation

Both final-checked-normal (receipt26) and restored-normal (receipt33) record
exit0, '7 verified, 0 errors', reaped children and group-absence observations.
Their retained SMT transcripts each contain seven unsat responses, no unknown
and no sat. Their stdout/stderr hashes match the receipts. These are reported
historical outcomes; this reviewer did not invoke a verifier.

The emitted AIR identifies the seven units EXACTLY:
1. PAYLOAD_OFFSET constant (16 on the recorded target).
2. ALLOCATION_ALIGN constant (8 on that target).
3. generated_native_store154, the reused generic conditional store body.
4. generated_allocate156.
5. generated_allocation_to_store156.
6. generated_reclaim156.
7. generated_zero_length156.

Thus five distinct generated executable bodies, only four new in156, plus two
constant checks: NOT seven native bodies or seven new executable bodies. The
open spec allocation_size156 is a definition, not an extra executable body.
The actual final input is proof/isolated-cut-normal.rs, not the earlier similarly
named proof/final-cut-normal.rs. Actual positive and restored-cut.rs are exactly
byte-identical, SHA256
013748d956cbc3654815b82caf64d70e4848dc5241584d511f8d0fd391af4e63. The earlier
final-cut-normal differs by whitespace and an explicit numeric-address assertion;
it must not be substituted as the byte-identical final positive endpoint.

generated_allocate156 has no caller PointsTo/PointsToRaw/Dealloc input. It checks
the explicit scalar length bound, computes the proposed padded size, establishes
valid positive layout, calls the inherited external_body allocate, and consumes
the issued raw token in a header/payload split. Matching Dealloc remains affine.
The padded payload includes any tail padding; it is not an assertion that all
padding bytes were initialized. For len0 the size is the nonzero header size and
the payload domain is empty, not the native Global zero-size/dangling case.

The store composition additionally requires scalar index<len. It uses the same
generated base's provenance via with_addr, proves full pointer equality (not
merely equal numeric addresses), and consumes exactly one u8-sized raw range.
The generic154 store receives that genuine cell permission and the actual
generated byte operand. It initializes that cell to byte. A separate header-byte
permission is explicitly borrowed as a disjoint frame, remains unchanged and
uninitialized, and is rejoined with the header tail. The result states exact
header/complement domains, pairwise disjointness, union equal to the full original
allocation domain, common provenance and matching address/size/alignment Dealloc.
There is no duplicative resource issuance in this inspected generated chain.

generated_reclaim156 deliberately forgets the u8 value with the existing
leak_contents proof operation, converts to raw, rejoins complement/header and
consumes the matching full-range/deallocation permissions. This is checked
generated normal reclamation, not a theorem about native Arc Drop or unwind.
generated_zero_length156 separately verifies the empty-payload/header-only case.

The demonstrated frame is the explicitly supplied header-byte token and returned
tracked resources, NOT arbitrary allocator callbacks, shared mutable state,
initialized Arc atomics, or previous native loop values. Raw uninitialized header
and raw complement cannot stand in for strong/weak initialization or prior-value
facts. allocate has opens_invariants none but no no_unwind; the store's no_unwind
does not propagate to the allocating helpers or native Arc caller.

## (2) G1/G2 gap, source selection, and false-acceptance assessment

The candidate sources and binding provide useful STRUCTURAL evidence: actual
Instances/substitutions, allocation-result-to-ArcInner.data projection and thin
cast, normal-graph domination, actual concrete closure/runtime calls with false
zeroed operand, and the selected inlined alloc owner/__rust_alloc call. Layout
offsets come from compiler layout_of of the actual instantiated type, rather
than an asserted portable header law. Five embedded allocation-route MIR hashes
match their recorded MIR bytes.

This is not a checked transition refinement. Selecting one static callsite does
not establish one dynamic allocation activation, exact successful native Layout,
the same normal returned full pointer/provenance, or one permission issuance for
that ORIGINAL event. The generated code executes an authored inherited allocate
call in a separate program. Its genuine tokens belong to that call. A shared
allocation leaf, matching target, numeric address equality, or output hash cannot
transport those tokens into the original continuation. G1 and G2 are genuinely
OPEN, not merely evidence-packaging tasks.

No false claim of native acceptance was found in the inspected report, bridge,
handoff, obligations, binding or final compiler path. The candidate emits an
unconditional ALLOCATION156_EXPORT_REFUSED diagnostic after generating proof
inputs; restored-cut receipt32 records exit1 and the raw diagnostic states G1/G2,
native header effects, iterator bounds and caller issuance remain OPEN. Zero
native credits in the package agree with that refusal. The '7 verified' result
belongs exclusively to the generated proof input. Promoting it to native
acceptance would be false, but implementation156 does not do so here.

The source selector is not a general soundness certificate: unique_definition
counts certain direct Assign definitions, not every projected write, call/alias
effect or lifetime invalidation. Normal-graph dominance is structural and not a
semantic effect/frame proof. Instance-based deduplication is better than Debug
deduplication; debug/source/inline identity and traversal completeness still are
not a verified native producer. These are future admission gates; this review
asserts no accepted native exploit or present positive-helper failure.

## Controls: unknown is not SAT

Final offset/extent/provenance/byte controls reject at the expected sites.
Offset fails payload subset and store/frame separation; extent fails the exact
u8 range and complement promise; provenance fails full-pointer equality AFTER
numeric-address equality; byte fails Init(byte). Retained transcripts show:
offset 2 unknown, extent 2 unknown, provenance 1 unknown, byte 1 unknown, each
with '(incomplete quantifiers)', and no sat responses. Additional unsat responses
are present for other queries. These are fail-closed VC failures, NOT concrete
SAT counterexamples, not an exhaustive mutation theorem, and not native mutants.

Missing issuance is E0381 on uninitialized genuine raw/deallocation tokens before
SMT. It tests front-end resource initialization, not original-event creation.
The earlier confounded provenance/layout and extent/subset failures remain in
FAILURES156; they are not silently substituted for the final isolated controls.
Positive restoration remains useful despite this limited negative evidence.

## (3) Minimum primitive and remaining application work

PRIMITIVE-BOUNDARY157.md gives the exact conditional minimum. Preferred route:
prove an event-preserving refinement to the already permitted inherited contract
without issuing resources a second time. If that cannot be established in the
chosen semantics, wrapper reuse is INSUFFICIENT; a source/API/ABI/cfg-pinned,
reviewed normal-success allocation-event primitive is the missing trust boundary.
It is not a blanket Global/Arc summary, and is NOT adopted by this review.

Even with that primitive, G3 actual array/extend/pad layout and nonzero/nonzeroed
success premises, G4 header/metadata/guard/iterator/cleanup/live effects, G5 actual
RepeatN/Enumerate/index/operand and Offset identity, and G6/G7 CURRENT resource
splitting, prior initialized elements, matching Dealloc and native continuation
remain checked obligations. Cache reservation/return, buffer/flush, actual public
acknowledgement and crash/recovery/logical data history remain beyond this subset.

## Severity objections and recommendation

- HIGH / BLOCKS NATIVE CREDIT: G1/G2 same-activation event/refinement and original
  affine issuance are absent. Do not install a producer or award original credit.
- HIGH / BLOCKS NATIVE COMPOSITION: actual layout, Arc header and CURRENT resource
  flow, iterator bounds/prior values and caller/cleanup effects are not proved.
  A leaf allocation law cannot discharge these application obligations.
- MEDIUM / ADMISSION LIMIT: structural selection/definition/dominance evidence
  must not become automatic general source-to-resource correctness.
- MEDIUM / EVIDENCE LIMIT: semantic negatives are unknown, not SAT; initialization
  rejection and restoration do not prove exhaustive semantic robustness.
- MEDIUM / CUSTODY LIMIT: selected endpoint consistency is not continuous custody,
  historical bootstrap, replay or credential/environment value completeness.

These are retained limitations, not requests to weaken scope or add arbitrary
axioms. No additional blocking concrete generated-normal-helper bug is alleged.
Parent should independently choose the next source-specific event/refinement or
exact proposed leaf-law review task; no followup/delegate/integration is started.

## Custody, credentials, restrictions

The input explicitly discloses setup's credential-value redaction and two
conservatively charged tool-transcript-only redaction attempts, including the
initial patch failure. This reviewer did not display, recover, reconstruct or
request a secret. Setup original environment value completeness is qualified;
no fabricated exact clocks/raw process streams repair that gap. Recorded minimal
final proof environments have no credential key identified in that disclosure.
No claim is made that this review audited every possible credential occurrence.

All activity is local static reading/hashing/evidence generation. No compiler,
build, verifier, native application/test, network, Git write, candidate/parent
edit, integration, law adoption or subdelegation. No compiler slot used. Tool
transcripts provide read-command custody; this review has no continuous private
per-command launch/environment/process monitor. Some combined text/inventory
displays were truncated; decisive sources/outcomes were recovered via bounded
reads or structured extraction. Unseen inventory text is not evidence.
ACCOUNTING157.json records actual wall/resource observations and their limits.
