import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import tempfile
import time


BASE = Path('/private/tmp/implementation143-20261108-LpJjrIbt')
REPAIR = Path('/private/tmp/redb-provenance-repair148-20261108-j01r2pgl')
HELPER = Path('/private/tmp/redb-receipt-cancellation118-revision2/candidate/source/tools/capture_provenance_receipt.py')
ORIGINAL = Path('/private/tmp/redb-original-crate-preflight115/redb')
TOOLCHAIN = Path('/Users/tommyvolk/.rustup/toolchains/1.99.1-aarch64-apple-darwin')
STATE = Path('/private/tmp/redb-parent-validation150-location.json')


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha(location):
    digest = hashlib.sha256()
    with Path(location).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def write(location, value):
    with Path(location).open('x') as output:
        json.dump(value, output, indent=2, sort_keys=True)
        output.write('\n')


def inventory(root):
    return sorted([dict(path=str(location.relative_to(root)), bytes=location.stat().st_size,
                        sha256=sha(location)) for location in root.rglob('*')
                   if location.is_file() and '.git' not in location.parts], key=lambda entry: entry['path'])


def authenticate(root, phase):
    records = json.loads((root / 'inputs.json').read_text())
    mismatches = [record['path'] for record in records
                  if sha(record['path']) != record['sha256']
                  or Path(record['path']).stat().st_size != record['bytes']]
    write(root / ('authentication-' + phase + '.json'), dict(utc=utc(), selected=len(records), mismatches=mismatches))
    if mismatches:
        raise ValueError(mismatches)


def resources(root):
    logical = allocated = 0
    for directory, _, names in os.walk(root):
        for name in names:
            status = (Path(directory) / name).lstat()
            logical += status.st_size
            allocated += status.st_blocks * 512
    value = dict(utc=utc(), logical=logical, allocated=allocated, free=shutil.disk_usage(root).free)
    if max(logical, allocated) > 2 * 1024**3 or value['free'] <= 16 * 1024**3:
        raise RuntimeError('resource limit: ' + repr(value))
    return value


def initialize():
    if STATE.exists():
        raise FileExistsError(STATE)
    if sha(BASE / 'candidate-final.json') != '8a8a2134a7691b290f01989ef4a0777c2aa2ec3bd2a9d4c32919bcac32c6adc4':
        raise ValueError('baseline manifest')
    if sha(REPAIR / 'MANIFEST.json') != '7659d7f7811bda10dd984dc547c8ddd114fd2ef1a115ce449724ba7e5a76766d':
        raise ValueError('repair manifest')
    baseline = json.loads((BASE / 'candidate-final.json').read_text())
    if inventory(BASE / 'candidate') != baseline:
        raise ValueError('baseline source drift')
    repair_records = json.loads((REPAIR / 'MANIFEST.json').read_text())
    for record in repair_records:
        if sha(REPAIR / record['path']) != record['sha256'] or (REPAIR / record['path']).stat().st_size != record['bytes']:
            raise ValueError('repair drift')
    root = Path(tempfile.mkdtemp(prefix='redb-parent-validation150-20261108-', dir='/private/tmp'))
    write(STATE, {'root': str(root)})
    write(root / 'bounds.json', dict(start_utc=utc(), deadline_epoch=time.time()+20*60,
          charged_limit=8, compiler_slot='HELD_BY_PARENT150', scratch_bytes=2*1024**3,
          minimum_free_disk_strictly_above=16*1024**3, jobs=1,
          distinct_objective='Validate parent-authored R146 bookkeeping source repair148; no law147 adoption or143 allowance reset'))
    shutil.copytree(BASE / 'candidate', root / 'candidate')
    for record in repair_records:
        if record['path'].startswith('candidate/'):
            shutil.copyfile(REPAIR / record['path'], root / record['path'])
    (root / 'tmp').mkdir()
    selected = [BASE / 'candidate' / entry['path'] for entry in baseline]
    selected += [REPAIR / entry['path'] for entry in repair_records]
    selected += [BASE / 'candidate-final.json', REPAIR / 'MANIFEST.json', HELPER, Path(__file__)]
    selected += [BASE / name for name in ['original-final.launch.json', 'original-final.receipt.json']]
    selected += [TOOLCHAIN / 'bin' / name for name in ['rustc', 'cargo', 'rustdoc']]
    selected += list((TOOLCHAIN / 'lib').glob('librustc_driver*'))
    selected += [ORIGINAL / record['path'] for record in inventory(ORIGINAL)]
    selected += [Path('/private/tmp/redb-native-mir115-20261108T160243Z/target/debug/deps/liblibc-709064e59816a9f7.rlib')]
    write(root / 'inputs.json', [dict(path=str(location), bytes=location.stat().st_size, sha256=sha(location))
                              for location in sorted(set(selected))])
    write(root / 'baseline143.json', baseline)
    write(root / 'initial-source.json', inventory(root / 'candidate'))
    write(root / 'helper-selection.json', dict(path=str(HELPER), sha256=sha(HELPER),
          qualification='Current endpoint before import; helper source was inspected earlier. No retroactive custody or transitive stdlib/OS authentication. Only its reviewed interrupt deferral is reused, not a full receipt attestation.'))
    authenticate(root, 'entry')
    print(json.dumps(dict(root=str(root), resources=resources(root))))


def run(root, name, kind, seconds, argv):
    bounds = json.loads((root / 'bounds.json').read_text())
    starts = sorted(root.glob('*.launch.json'))
    if len(starts) >= bounds['charged_limit']:
        raise ValueError('charged limit')
    seconds = min(seconds, bounds['deadline_epoch']-time.time()-90)
    if seconds <= 0 or seconds > (600 if kind == 'build' else 120):
        raise ValueError('command time budget')
    authenticate(root, 'preexecution-' + name)
    helper_expected = json.loads((root / 'helper-selection.json').read_text())['sha256']
    if sha(HELPER) != helper_expected:
        raise ValueError('helper drift')
    specification = importlib.util.spec_from_file_location('capture150_selected', HELPER)
    helper = importlib.util.module_from_spec(specification)
    specification.loader.exec_module(helper)
    environment = dict(json.loads((BASE / 'original-final.launch.json').read_text())['environment'])
    for key in ['CARGO_BUILD_BUILD_DIR', 'CARGO_TARGET_DIR']:
        environment[key] = str(root / 'target')
    environment['TMPDIR'] = str(root / 'tmp')
    source = inventory(root / 'candidate')
    write(root / (name + '.source.json'), source)
    environment['VERUS_SOURCE_SNAPSHOT_SHA256'] = hashlib.sha256(json.dumps(source, sort_keys=True).encode()).hexdigest()
    entry = dict(number=len(starts)+1, name=name, kind=kind, argv=argv,
                 environment=environment, cwd=str(root / 'candidate/source'), timeout=seconds,
                 start_utc=utc(), start_epoch_ns=time.time_ns(), executable_sha256=sha(argv[0]),
                 runner_sha256=sha(__file__), helper_sha256=helper_expected, before=resources(root))
    write(root / (name + '.launch.json'), entry)
    process = None
    interruption = None
    started = time.monotonic()
    try:
        with (root / (name + '.stdout')).open('xb') as stdout, (root / (name + '.stderr')).open('xb') as stderr:
            with helper.defer_process_interrupt():
                process = subprocess.Popen(argv, cwd=entry['cwd'], env=environment,
                                           stdout=stdout, stderr=stderr, start_new_session=True)
                entry['pid'] = process.pid
            with (root / (name + '.resources.jsonl')).open('x') as samples:
                while True:
                    try:
                        with helper.defer_process_interrupt():
                            process.wait(timeout=min(1, max(0.001, seconds-(time.monotonic()-started))))
                        break
                    except subprocess.TimeoutExpired:
                        samples.write(json.dumps(resources(root))+'\n')
                        samples.flush()
                        if time.monotonic()-started >= seconds:
                            raise TimeoutError('command time limit')
        entry['returncode'] = process.returncode
    except BaseException as error:
        interruption = error
        entry['failure'] = repr(error)
    finally:
        try:
            if process is not None:
                with helper.defer_process_interrupt():
                    if process.returncode is None:
                        try:
                            os.killpg(process.pid, signal.SIGKILL)
                        except ProcessLookupError:
                            pass
                    process.wait(timeout=5)
                entry['returncode'] = process.returncode
                try:
                    os.killpg(process.pid, 0)
                    entry['owned_group_absent'] = False
                except ProcessLookupError:
                    entry['owned_group_absent'] = True
            entry.update(end_utc=utc(), end_epoch_ns=time.time_ns(), elapsed_seconds=time.monotonic()-started,
                         after=resources(root), source_unchanged_during_command=inventory(root / 'candidate') == source)
            for stream in ['stdout', 'stderr']:
                location = root / (name + '.' + stream)
                entry[stream] = dict(bytes=location.stat().st_size, sha256=sha(location))
            write(root / (name + '.receipt.json'), entry)
        except BaseException as persistence_error:
            if interruption is not None:
                raise interruption from persistence_error
            raise
    print(json.dumps({key: entry.get(key) for key in ['name', 'returncode', 'failure', 'elapsed_seconds', 'owned_group_absent']}))
    if interruption is not None:
        raise interruption
    if not entry.get('owned_group_absent') or not entry['source_unchanged_during_command']:
        raise RuntimeError('cleanup/source check failed')
    return entry['returncode']


if sys.argv[1] == 'init':
    initialize()
else:
    root = Path(json.loads(STATE.read_text())['root'])
    if sys.argv[1] == 'run':
        raise SystemExit(run(root, sys.argv[2], sys.argv[3], int(sys.argv[4]), sys.argv[5:]))
