import datetime
import difflib
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import shutil
import tarfile
import time


ROOT = Path('/private/tmp/redb-parent-validation150-20261108-vumyv529')
BASE = Path('/private/tmp/implementation143-20261108-LpJjrIbt')
REPAIR = Path('/private/tmp/redb-provenance-repair148-20261108-j01r2pgl')
DESTINATION = Path('/Users/tommyvolk/.t3/worktrees/verus/t3-60978068/evidence/redb-native-mir-campaign115')


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha(location):
    digest = hashlib.sha256()
    with Path(location).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def write(name, value):
    with (ROOT / name).open('x') as output:
        json.dump(value, output, indent=2, sort_keys=True)
        output.write('\n')


def inventory(root):
    return sorted([dict(path=str(location.relative_to(root)), bytes=location.stat().st_size, sha256=sha(location))
                   for location in root.rglob('*') if location.is_file() and '.git' not in location.parts],
                  key=lambda record: record['path'])


def authenticate():
    records = json.loads((ROOT / 'inputs.json').read_text())
    mismatches = [record['path'] for record in records
                  if sha(record['path']) != record['sha256'] or Path(record['path']).stat().st_size != record['bytes']]
    if mismatches:
        raise ValueError('selected input drift: ' + repr(mismatches))
    return dict(utc=utc(), selected=len(records), mismatches=mismatches,
                qualification='Selected endpoint authentication, not transitive dependencies, runtime closure, historical continuous custody or compiler/source/bootstrap attestation.')


expected = [
    ('repair148-tests-build', 0), ('repair148-tests', 0), ('repair148-native-build', 0),
    ('original-repair148', 1), ('stale-holder-negative', 101), ('holder-restored', 0),
    ('duplicate-origin-negative', 101), ('origin-restored', 0)]
receipts = []
for number, (name, returncode) in enumerate(expected, 1):
    receipt = json.loads((ROOT / (name + '.receipt.json')).read_text())
    if (receipt['number'] != number or receipt['returncode'] != returncode
            or receipt.get('failure') is not None or not receipt['owned_group_absent']
            or not receipt['source_unchanged_during_command']):
        raise ValueError('receipt status: ' + name)
    for stream in ['stdout', 'stderr']:
        location = ROOT / (name + '.' + stream)
        if sha(location) != receipt[stream]['sha256'] or location.stat().st_size != receipt[stream]['bytes']:
            raise ValueError('stream drift: ' + name)
    receipts.append(receipt)
for name in ['repair148-tests', 'holder-restored', 'origin-restored']:
    if '8 passed; 0 failed' not in (ROOT / (name + '.stdout')).read_text():
        raise ValueError('positive tests absent: ' + name)
if '5 passed; 3 failed' not in (ROOT / 'stale-holder-negative.stdout').read_text():
    raise ValueError('holder mutant not detected as intended')
if '7 passed; 1 failed' not in (ROOT / 'duplicate-origin-negative.stdout').read_text():
    raise ValueError('origin mutant not detected as intended')
final_source = inventory(ROOT / 'candidate')
if final_source != json.loads((ROOT / 'initial-source.json').read_text()):
    raise ValueError('final source restoration mismatch')
original = json.loads((ROOT / 'original-repair148.json').read_text())
if original['native_bodies_proved'] != 0 or original['native_certificate'] or original['laws_adopted'] != 0:
    raise ValueError('unexpected native authority')
if (ROOT / 'original-repair148.rmeta').exists():
    raise ValueError('unexpected native metadata output')
proof_refusals = {}
for owner, body in original['bodies'].items():
    lowered = body.get('native_lowering', {}).get('Ok', {})
    error = lowered.get('original_body_proof_lowering', {}).get('Err')
    if error:
        proof_refusals[owner] = error
if len(proof_refusals) != 3 or not all('NRE148_UNBOUND_REQUIRED_PROOF_BUNDLE' in error for error in proof_refusals.values()):
    raise ValueError('expected required-bundle refusals absent')
authentication = authenticate()
write('authentication-exit.json', authentication)
write('source-final.json', final_source)
baseline = {record['path']:record for record in json.loads((ROOT / 'baseline143.json').read_text())}
changes = [record for record in final_source if baseline.get(record['path']) != record]
if len(changes) != 2:
    raise ValueError('unexpected source scope')
patch = []
for record in changes:
    name = record['path']
    patch.extend(difflib.unified_diff((BASE / 'candidate' / name).read_text().splitlines(keepends=True),
          (ROOT / 'candidate' / name).read_text().splitlines(keepends=True), fromfile='a/' + name, tofile='b/' + name))
with (ROOT / 'candidate.patch').open('x') as output:
    output.writelines(patch)
write('source-delta.json', changes)
for mutant, relative in [
    ('stale-holder-mutant.rs', 'source/rust_verify/src/native_resource143/ledger.rs'),
    ('duplicate-origin-mutant.rs', 'source/rust_verify/src/native_resource143.rs')]:
    lines = difflib.unified_diff((ROOT / 'candidate' / relative).read_text().splitlines(keepends=True),
              (ROOT / mutant).read_text().splitlines(keepends=True), fromfile='positive/' + relative, tofile='mutant/' + relative)
    with (ROOT / (mutant + '.patch')).open('x') as output:
        output.writelines(lines)
shutil.copyfile('/private/tmp/redb-parent-validation150.py', ROOT / 'runner.py')
shutil.copyfile(__file__, ROOT / 'seal150.py')
write('target-final.json', inventory(ROOT / 'target'))
bounds = json.loads((ROOT / 'bounds.json').read_text())
samples = []
for receipt in receipts:
    samples.extend([receipt['before'], receipt['after']])
for location in ROOT.glob('*.resources.jsonl'):
    samples.extend(json.loads(line) for line in location.read_text().splitlines())
if time.time() >= bounds['deadline_epoch']:
    raise ValueError('deadline before seal')
usage = dict(peak_sampled_logical=max(sample['logical'] for sample in samples),
             peak_sampled_allocated=max(sample['allocated'] for sample in samples),
             minimum_sampled_free=min(sample['free'] for sample in samples),
             current_free=shutil.disk_usage(ROOT).free)
if max(usage['peak_sampled_logical'], usage['peak_sampled_allocated']) > 2*1024**3 or usage['minimum_sampled_free'] <= 16*1024**3:
    raise ValueError('sampled limits')
summary = dict(utc=utc(), command_count=len(receipts), command_limit=8,
    statuses=[dict(number=receipt['number'], name=receipt['name'], returncode=receipt['returncode']) for receipt in receipts],
    tests=dict(initial=8, holder_restored=8, origin_restored=8, holder_mutant_failed_tests=3, origin_mutant_failed_tests=1),
    source_restoration='BYTE_IDENTICAL_TO_INITIAL_COMPOSED143_PLUS148_SOURCE',
    native_original=dict(exit=1, export='REFUSED_AND_METADATA_ABSENT', native_bodies_proved=0,
        translated_bodies=6, selected_bodies=7, new_required_bundle_refusals=proof_refusals,
        original_write_assert_and_macro_for='OPEN', full_wf_modes_sst_air_smt_runs=0),
    law147='NOT_CONSUMED_NOT_ADOPTED_PENDING_REVIEW149',
    r146='Parent source repair compiles and targeted controls pass; full independent native/alias/branch/cleanup coverage not established.',
    selected_authentication=authentication, resources=usage, all18='OPEN', adopted_laws=0)
write('validation-summary.json', summary)
report = '''# Parent validation150 — targeted repair checks, not native proof

The parent validated its own small148 source repair in a fresh143-based compiler
candidate. This is distinct from exhausted broad143 and sealed147; no allowance
was reset. Exactly8/8 commands ran, all direct children reaped and owned groups
observed absent in receipts. The compiler slot is RELEASED. All18 remain OPEN.

## Actual outcomes

- Offline/locked/jobs1 library-test build succeeds;8 targeted tests pass.
- Offline feature-enabled native-resource143 binary build succeeds.
- Original redb is analyzed by the compiler only: exit1, native export refused,
  metadata absent, zero original native bodies proved and zero adopted laws.
- Deliberately retaining stale reference-holder entries causes exactly3 intended
  unit failures (move, overwrite and storage kill); restored8/8 pass.
- Deliberately disabling HIR-origin injectivity causes exactly1 intended failure;
  restored8/8 pass. Both exact changed sources, patches and raw failures remain.
- Final1104-file candidate inventory is byte-identical to the initial composed
  candidate. Source148 originals and baseline143 remain unchanged.

The controls exercise live-holder bookkeeping and the pure key-uniqueness gate,
not a complete original-program alias/lifetime/frame proof. Bundle consumption
has no positive path-duplication theorem. Global native resource correctness and
independent R146 closure are not claimed. Parent148 itself is immutable; this
fresh validation carries the actual compile/test evidence.

## Native proof frontier remains explicit

Six of seven selected original bodies translate, none is verified. Original
write still fails the ordinary frontend's macro-for support and native Assert
semantics. Requiring bundle coverage now explicitly refuses unanchored required
calls in Drop, return_value and write_header instead of silently leaving a proof
bundle unplaced. Exact observed locations are in validation-summary.json.
The other generated proof-debt ASTs are false assertions, not byte semantics or
SST/AIR/SMT proofs. Incoming checkout, reservations, byte authority, cleanups,
application callees, native laws and complete history/recovery remain OPEN.

Law147 was not consumed or adopted. Its exact independent source review149 runs
separately. Original redb application/test execution did not occur; no original
source integration or completed original-code-change claim is made. Thus no
original just-test integration result is asserted.

## Custody, limits and qualifications

Selected inputs authenticate at entry, before every command and exit. This is
endpoint custody only, not historical continuity, dependency/runtime closure,
current compiler/source correspondence or bootstrap attestation. The complete
candidate, changed sources, runner, command argv/env/time/status/streams, output
hashes, resource samples and exact negative sources are retained. Target files
have a final hash inventory but are not all independently replayed or archived.

The selected118revision2 helper supplies interrupt deferral through a standard
importlib load; its text digest is not a loaded-bytecode or interpreter/stdlib
attestation. No matching adjacent helper cache file was observed after commands;
no cache entry inventory or historical loaded-code correspondence is claimed.
The parent runner signals only an acquired, unreaped child group; post-reap
group checks use signal0 and do not authorize signaling a recycled identifier.
Descendant containment and hostile runtime behavior are not proved.

Terminal display truncations during parent discovery/report inspection remain
in the tool record; structured field-selected outputs and raw sealed evidence
provide the actual observations. No unexpected compiler/test failure occurred;
the native refusal and two deliberate regression failures are retained, not
counted as successful native proofs. Historical14024/24,14336/36,14730/32 and
interrupted116 are unchanged. No laws, trust or source-integration approval.
'''
with (ROOT / 'REPORT.md').open('x') as output:
    output.write(report)
release = dict(utc=utc(), compiler_slot='RELEASED', charged=8, limit=8,
               live_owned_groups=0, all_receipts_owned_group_absent=True,
               resources=usage, native_bodies_proved=0, laws_adopted=0, all18='OPEN')
write('RELEASE.json', release)
files = [location for location in sorted(ROOT.iterdir()) if location.is_file()]
records = [dict(path=location.name, bytes=location.stat().st_size, sha256=sha(location)) for location in files]
write('SEAL.json', records)
with (ROOT / 'SEAL.sha256').open('x') as output:
    output.write(sha(ROOT / 'SEAL.json') + '  SEAL.json\n')
payloads = {record['path']:(ROOT / record['path']).read_bytes() for record in records}
payloads['SEAL.json'] = (ROOT / 'SEAL.json').read_bytes()
payloads['SEAL.sha256'] = (ROOT / 'SEAL.sha256').read_bytes()
for record in changes:
    payloads['candidate/' + record['path']] = (ROOT / 'candidate' / record['path']).read_bytes()
archive = DESTINATION / 'PROVENANCE-REPAIR148-VALIDATION150.tar.gz'
with archive.open('xb') as raw:
    with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w', format=tarfile.USTAR_FORMAT) as output:
            for name, payload in sorted(payloads.items()):
                member = tarfile.TarInfo(name)
                member.mode = 0o644
                member.mtime = 0
                member.size = len(payload)
                output.addfile(member, io.BytesIO(payload))
with tarfile.open(archive, 'r:gz') as restored:
    members = restored.getmembers()
    if len(members) != len(payloads) or len({member.name for member in members}) != len(members):
        raise ValueError('archive uniqueness')
    for member in members:
        if not member.isfile() or member.name not in payloads or restored.extractfile(member).read() != payloads[member.name]:
            raise ValueError('archive byte readback')
for record in records:
    if sha(ROOT / record['path']) != record['sha256']:
        raise ValueError('sealed file drift')
if inventory(ROOT / 'candidate') != final_source:
    raise ValueError('candidate exit drift')
authenticate()
index = dict(record='parent-repair148-validation150-retention', root=str(ROOT),
    seal_json_sha256=sha(ROOT / 'SEAL.json'), sealed_payloads=len(records),
    retained_archive=archive.name, retained_archive_sha256=sha(archive),
    retained_archive_bytes=archive.stat().st_size, retained_regular_unique_byte_identical_members=len(payloads),
    validation=summary, release=release,
    qualification='Targeted parent validation, not independent R146 closure or law/native adoption. Baseline143/parent148 remain unchanged;147 unconsumed. Selected endpoints only; no full target/runtime/source attestation.')
with (DESTINATION / 'PROVENANCE-REPAIR148-VALIDATION150.json').open('x') as output:
    json.dump(index, output, indent=2)
    output.write('\n')
print(json.dumps(dict(seal_json_sha256=index['seal_json_sha256'], sealed_payloads=len(records),
      archive_sha256=index['retained_archive_sha256'], archive_members=len(payloads),
      selected_inputs=authentication['selected'], compiler_slot='RELEASED', charged='8/8', resources=usage), indent=2))
