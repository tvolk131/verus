# Parent validation150 — targeted repair checks, not native proof

The parent validated its own small148 source repair in a fresh143-based compiler
candidate. This is distinct from exhausted broad143 and sealed147; no allowance
was reset. Exactly8/8 commands ran, all direct children reaped and owned groups
observed absent in receipts. The compiler slot is RELEASED. All18 remain OPEN.

## Actual outcomes

- Offline/locked/jobs1 library-test build succeeds;8 targeted tests pass.
- Offline feature-enabled native-resource143 binary build succeeds.
- Original redb is analyzed by the compiler only: exit1, native export refused,
  metadata absent, zero original native bodies proved and zero adopted laws.
- Deliberately retaining stale reference-holder entries causes exactly3 intended
  unit failures (move, overwrite and storage kill); restored8/8 pass.
- Deliberately disabling HIR-origin injectivity causes exactly1 intended failure;
  restored8/8 pass. Both exact changed sources, patches and raw failures remain.
- Final1104-file candidate inventory is byte-identical to the initial composed
  candidate. Source148 originals and baseline143 remain unchanged.

The controls exercise live-holder bookkeeping and the pure key-uniqueness gate,
not a complete original-program alias/lifetime/frame proof. Bundle consumption
has no positive path-duplication theorem. Global native resource correctness and
independent R146 closure are not claimed. Parent148 itself is immutable; this
fresh validation carries the actual compile/test evidence.

## Native proof frontier remains explicit

Six of seven selected original bodies translate, none is verified. Original
write still fails the ordinary frontend's macro-for support and native Assert
semantics. Requiring bundle coverage now explicitly refuses unanchored required
calls in Drop, return_value and write_header instead of silently leaving a proof
bundle unplaced. Exact observed locations are in validation-summary.json.
The other generated proof-debt ASTs are false assertions, not byte semantics or
SST/AIR/SMT proofs. Incoming checkout, reservations, byte authority, cleanups,
application callees, native laws and complete history/recovery remain OPEN.

Law147 was not consumed or adopted. Its exact independent source review149 runs
separately. Original redb application/test execution did not occur; no original
source integration or completed original-code-change claim is made. Thus no
original just-test integration result is asserted.

## Custody, limits and qualifications

Selected inputs authenticate at entry, before every command and exit. This is
endpoint custody only, not historical continuity, dependency/runtime closure,
current compiler/source correspondence or bootstrap attestation. The complete
candidate, changed sources, runner, command argv/env/time/status/streams, output
hashes, resource samples and exact negative sources are retained. Target files
have a final hash inventory but are not all independently replayed or archived.

The selected118revision2 helper supplies interrupt deferral through a standard
importlib load; its text digest is not a loaded-bytecode or interpreter/stdlib
attestation. No matching adjacent helper cache file was observed after commands;
no cache entry inventory or historical loaded-code correspondence is claimed.
The parent runner signals only an acquired, unreaped child group; post-reap
group checks use signal0 and do not authorize signaling a recycled identifier.
Descendant containment and hostile runtime behavior are not proved.

Terminal display truncations during parent discovery/report inspection remain
in the tool record; structured field-selected outputs and raw sealed evidence
provide the actual observations. No unexpected compiler/test failure occurred;
the native refusal and two deliberate regression failures are retained, not
counted as successful native proofs. Historical14024/24,14336/36,14730/32 and
interrupted116 are unchanged. No laws, trust or source-integration approval.
