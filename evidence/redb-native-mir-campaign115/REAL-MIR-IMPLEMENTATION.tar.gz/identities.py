import difflib
import json
from pathlib import Path
import worker

ROOT = worker.ROOT
metadata = json.loads((ROOT / 'preflight-cargo-metadata.stdout').read_text())
packages = {package['id']: package for package in metadata['packages']}
nodes = {node['id']: node for node in metadata['resolve']['nodes']}
selected = {key for key, package in packages.items() if package['name'] in ('rust_verify', 'verus_builtin', 'verus_builtin_macros')}
pending = list(selected)
while pending:
    current = pending.pop()
    for dependency in nodes[current]['dependencies']:
        if dependency not in selected:
            selected.add(dependency)
            pending.append(dependency)
records = []
for package_id in sorted(selected):
    package = packages[package_id]
    directory = Path(package['manifest_path']).parent
    source = worker.inventory(directory)
    records.append({'package_id': package_id, 'name': package['name'], 'version': package['version'],
                    'manifest': package['manifest_path'], 'source': package['source'],
                    'source_fingerprint': worker.digest(source), 'files': source})
worker.write('dependency-source-identities.json', {'packages': records,
    'scope': 'resolved package dependency graph; may include target/dev packages not actually executed; actual rustc commands remain in verbose build logs'})
worker.write('build-output-identities.json', {'records': worker.inventory(ROOT / 'target'),
                                           'archived_targets': False})
tools = []
for filename in (ROOT / 'target/debug/rust_verify', ROOT / 'artifacts/rust_verify-build01',
                 ROOT / 'target/debug/libverus_builtin.rlib', ROOT / 'target/debug/libverus_builtin_macros.dylib',
                 Path('/Users/tommyvolk/Documents/GitHub/verus/source/z3')):
    tools.append({'path': str(filename), 'bytes': filename.stat().st_size, 'sha256': worker.sha(filename)})
worker.write('executable-and-companion-identities.json', tools)
before = {record['path']: record for record in worker.inventory(worker.PREVIOUS / 'snapshot')}
after = worker.inventory(worker.STAGE)
delta = []
patch = []
for record in after:
    if record != before.get(record['path']):
        delta.append({'before': before.get(record['path']), 'after': record})
        original = worker.PREVIOUS / 'snapshot' / record['path']
        candidate = worker.STAGE / record['path']
        patch.extend(difflib.unified_diff(original.read_text().splitlines(True), candidate.read_text().splitlines(True),
            fromfile='baseline/' + record['path'], tofile='task115/' + record['path']))
worker.write('source-final-inventory.json', {'records': after, 'fingerprint': worker.digest(after), 'delta': delta})
(ROOT / 'source-diagnostic-only.patch').write_text(''.join(patch))
temporary = (ROOT / 'fixtures/anonymous_temporary.rs').read_text().splitlines(True)
matched = (ROOT / 'fixtures/matched_binder.rs').read_text().splitlines(True)
(ROOT / 'fixture-matched-binder.patch').write_text(''.join(difflib.unified_diff(temporary, matched,
    fromfile='fixtures/anonymous_temporary.rs', tofile='fixtures/matched_binder.rs')))
print('Dependency packages', len(records), 'source delta files', len(delta), 'source digest', worker.digest(after), flush=True)
