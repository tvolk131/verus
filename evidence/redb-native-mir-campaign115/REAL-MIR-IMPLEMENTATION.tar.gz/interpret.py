import copy
import hashlib
import json
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parent
MAX_STREAM = 4 * 1024 * 1024

def sha(file):
    return hashlib.sha256(file.read_bytes()).hexdigest()

def parse_capture_lines(stderr):
    captures = []
    for line in stderr.splitlines():
        if line.startswith('TASK115_CAPTURE '):
            capture = json.loads(line[len('TASK115_CAPTURE '):])
            assert isinstance(capture.get('native_phase'), bool)
            assert isinstance(capture.get('drop_sites'), list)
            assert isinstance(capture.get('unestablished_count'), int)
            assert capture['mir_phase'] == 'Runtime(PostCleanup)'
            captures.append(capture)
    return captures

def classify(receipt, stdout, stderr, captures):
    if receipt['status'] != 'COMPLETED' or receipt.get('child_exit_code') is None:
        return 'tool_or_harness_failure'
    if any(marker in stderr.lower() for marker in ('internal compiler error', 'panicked at', 'query stack during panic')):
        return 'compiler_panic_or_ice'
    code = receipt['child_exit_code']
    if code < 0:
        return 'tool_signal_failure'
    result = stdout.get('verification-results', {})
    if 'checked normal destruction metadata export is declined' in stderr and code != 0:
        return 'intentional_export_refusal'
    if 'destruction site captured but declined' in stderr and code != 0:
        assert any(capture['unestablished_count'] > 0 and capture['normalization'].startswith('Err(') for capture in captures)
        return 'intentional_provenance_refusal'
    if code != 0 and result.get('errors', 0) > 0 and 'postcondition not satisfied' in stderr:
        return 'backend_semantic_failure'
    if code != 0 and ('cannot find `vstd`' in stderr or 'could not find `vstd`' in stderr):
        return 'frontend_companion_cfg_failure'
    if code != 0 and 'implementation for Drop must be marked no_unwind' in stderr:
        return 'frontend_drop_specification_refusal'
    if code != 0 and '`std::fs::File` is not supported' in stderr:
        return 'frontend_unsupported_native_resource'
    if code == 0 and result.get('success') is True and result.get('errors') == 0:
        return 'backend_semantic_success'
    return 'unclassified_failure' if code != 0 else 'unclassified_zero'

def interpret(name):
    receipt = json.loads((ROOT / (name + '.receipt.json')).read_text())
    streams = {}
    for stream in ('stdout', 'stderr'):
        file = ROOT / (name + '.' + stream)
        assert file.stat().st_size <= MAX_STREAM
        assert sha(file) == receipt[stream + '_sha256'], (name, stream, 'stream hash mismatch')
        streams[stream] = file.read_text()
    before = json.loads((ROOT / (name + '.source-before.json')).read_text())
    digest = hashlib.sha256(json.dumps(before['records'], sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    assert digest == before['fingerprint'] == receipt['source_digest'] == receipt['source_after_digest']
    assert receipt.get('owned_group_absent') is True
    assert receipt['resource_before']['safe'] and receipt['resource_after']['safe']
    stdout = json.loads(streams['stdout'])
    assert stdout['verus']['commit'] == 'unversioned:snapshot-sha256:' + digest
    captures = parse_capture_lines(streams['stderr'])
    outcome = classify(receipt, stdout, streams['stderr'], captures)
    argv = receipt['argv']
    original_root = Path(receipt['environment']['CARGO_TARGET_DIR']).parent
    original_fixture = Path(argv[-1])
    assert original_fixture.parent == original_root / 'fixtures'
    fixture = ROOT / 'fixtures' / original_fixture.name
    assert fixture.is_file()
    if 'argv_file_identities_before_launch' in receipt:
        for record in receipt['argv_file_identities_before_launch']:
            if '--bundle-only' not in sys.argv:
                assert sha(Path(record['path'])) == record['sha256'], (name, record['path'])
            elif Path(record['path']).parent == original_root / 'fixtures':
                assert sha(ROOT / 'fixtures' / Path(record['path']).name) == record['sha256']
    exports = []
    for index, argument in enumerate(argv[:-1]):
        if argument == '--export':
            destination = Path(argv[index + 1])
            exports.append({'path': str(destination), 'exists': destination.exists()})
            assert not destination.exists(), 'an effect export unexpectedly exists'
    joins = []
    for capture in captures:
        for site in capture['drop_sites']:
            if site['temporary_status'].startswith('CompleteWithLocalMatches'):
                assert 'Some(TemporaryCapture { complete: true' in capture['temporary_capture']
                for expression, local in re.findall(r'expression: (e\d+), local: _(\d+)', site['builder_origins']):
                    assert int(local) == site['local']
                    matching_lines = [line for line in streams['stderr'].splitlines()
                        if line.startswith('TASK115_BUILDER_TEMP ')
                        and f'::{capture["definition"]}) ' in line
                        and f' expression={expression} local=_{local} ' in line
                        and f' span={original_fixture}:' in line
                        and line.endswith(' native=' + str(capture['native_phase']).lower())]
                    if name.endswith('final') or 'export' in name:
                        assert matching_lines, (name, 'no source-connected Builder observation')
                    joins.append({'definition': capture['definition'], 'native_phase': capture['native_phase'],
                                  'block': site['block'], 'cleanup': site['cleanup'], 'local': site['local'],
                                  'expression': expression, 'source_connected_builder_lines': matching_lines,
                                  'occurrence_uniqueness_established': False, 'resource_ownership_established': False})
    checks = [json.loads(line.removeprefix('TASK115_NATIVE_CHECK ')) for line in streams['stderr'].splitlines()
              if line.startswith('TASK115_NATIVE_CHECK ')]
    return {'name': name, 'classification': outcome, 'exit': receipt['child_exit_code'],
            'verification_results': stdout['verification-results'],
            'native_collection_completed': stdout['verus-infer']['verification_scope']['native_collection_completed'],
            'source_digest': digest, 'fixture': str(fixture), 'fixture_sha256': sha(fixture),
            'capture_count': len(captures), 'native_capture_count': sum(capture['native_phase'] for capture in captures),
            'drop_capture_count': sum(bool(capture['drop_sites']) for capture in captures),
            'native_operation_checks': checks, 'origin_joins': joins, 'export_requests': exports,
            'source_bound_origin_scope_records': sum('scope: Some(' in capture['temporary_capture'] for capture in captures),
            'capture_enabled': '--experimental-checked-normal-drop' in argv,
            'diagnostics_environment': receipt['environment'].get('VERUS_TASK115_DIAGNOSTICS'),
            'executable_bytes_checked_now': '--bundle-only' not in sys.argv and 'argv_file_identities_before_launch' in receipt,
            'per_launch_file_identities_available': 'argv_file_identities_before_launch' in receipt}

def selftests():
    receipt = {'status': 'COMPLETED', 'child_exit_code': 1}
    assert classify(receipt, {}, '', []) == 'unclassified_failure'
    assert classify(dict(receipt, status='TIMEOUT'), {}, 'destruction site captured but declined', []) == 'tool_or_harness_failure'
    assert classify(receipt, {}, 'internal compiler error: destruction site captured but declined', []) == 'compiler_panic_or_ice'
    assert classify(dict(receipt, child_exit_code=-9), {}, '', []) == 'tool_signal_failure'
    assert classify(dict(receipt, child_exit_code=0), {}, '', []) == 'unclassified_zero'
    assert classify(receipt, {'verification-results': {'errors': 1}}, 'postcondition not satisfied', []) == 'backend_semantic_failure'
    malformed_rejected = False
    try:
        parse_capture_lines('TASK115_CAPTURE {not-json}')
    except json.JSONDecodeError:
        malformed_rejected = True
    assert malformed_rejected
    no_capture_rejected = False
    try:
        classify(receipt, {}, 'destruction site captured but declined', [])
    except AssertionError:
        no_capture_rejected = True
    assert no_capture_rejected
    print('Interpreter self-tests: 8 passed; synthetic parser controls only, not MIR evidence.', flush=True)

def main():
    selftests()
    names = [file.name.removesuffix('.receipt.json') for file in sorted(ROOT.glob('*.receipt.json'))
             if Path(json.loads(file.read_text())['argv'][0]).name == 'rust_verify']
    records = [interpret(name) for name in names]
    results = {record['name']: record for record in records}
    expected = {
        'named-owner-final': 'backend_semantic_success',
        'matched-binder-final': 'backend_semantic_success',
        'anonymous-temporary-final': 'intentional_provenance_refusal',
        'scoped-temporary-final': 'intentional_provenance_refusal',
        'backend-negative-final': 'backend_semantic_failure',
        'named-feature-off': 'backend_semantic_failure',
        'frontend-refusal-final': 'frontend_drop_specification_refusal',
        'named-native-resource-final': 'frontend_unsupported_native_resource',
        'named-owner-01': 'frontend_companion_cfg_failure',
        'named-export-refusal': 'intentional_export_refusal',
        'anonymous-export-refusal': 'intentional_provenance_refusal',
        'named-diagnostics-unset': 'backend_semantic_success',
        'empty-control-final': 'backend_semantic_success',
    }
    for name, outcome in expected.items():
        assert results[name]['classification'] == outcome, (name, outcome)
    for name in ('named-owner-final', 'matched-binder-final'):
        result = results[name]
        assert result['verification_results']['verified'] == 2 and result['native_capture_count'] == 2
        assert result['per_launch_file_identities_available']
        assert len(result['native_operation_checks']) == 1
        check = result['native_operation_checks'][0]
        assert check['expected_functions'] == check['seen_functions'] == 2
        assert check['operation_comparison_completed'] is True
    anonymous = results['anonymous-temporary-final']
    assert anonymous['native_capture_count'] == 0 and len(anonymous['origin_joins']) == 1
    assert anonymous['origin_joins'][0]['expression'] == 'e19' and anonymous['origin_joins'][0]['local'] == 7
    assert anonymous['origin_joins'][0]['source_connected_builder_lines']
    scoped = results['scoped-temporary-final']
    assert {join['cleanup'] for join in scoped['origin_joins']} == {False, True}
    assert {join['local'] for join in scoped['origin_joins']} == {8}
    assert not results['named-diagnostics-unset']['diagnostics_environment']
    assert not results['named-diagnostics-unset']['capture_count']
    assert 'TASK115_' not in (ROOT / 'named-diagnostics-unset.stderr').read_text()
    assert results['empty-control-final']['verification_results']['verified'] == 1
    for name in ('named-export-refusal', 'anonymous-export-refusal'):
        assert len(results[name]['export_requests']) == 1
        assert results[name]['export_requests'][0]['exists'] is False
    summary = {'records': records, 'all18': 'OPEN', 'native_proof': 0, 'trust_adoption': 0,
               'scope': 'local source-bound compiler engineering observations; not native lifecycle correspondence'}
    if '--write-summary' in sys.argv:
        (ROOT / 'RESULTS.json').write_text(json.dumps(summary, sort_keys=True, indent=2) + '\n')
    for record in records:
        print(record['name'], record['classification'], 'exit=' + str(record['exit']),
              'captures=' + str(record['capture_count']), 'native=' + str(record['native_capture_count']), flush=True)

if __name__ == '__main__':
    main()
