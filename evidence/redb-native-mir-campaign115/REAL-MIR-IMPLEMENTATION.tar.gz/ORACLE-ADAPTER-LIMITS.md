# Independent oracle handoff reconciliation

Read-only inputs are the independent oracle root
/private/tmp/redb-native-mir-campaign115-oracle-20261108T160308Z. The parent's
update reports 30 SYNTHETIC passing tests and NO actual-MIR verdict. This worker
does not turn those tests, its own parser, or a proposed mapping into one.

The existing launcher recorded real UTC ISO timestamps, monotonic duration,
unique attempt names, argv, cwd, exact allowlisted environment, PID/process
group, completed child wait status, stream hashes, source inventories and disk
samples. It did NOT record actual epoch-ns launch/end boundaries, nor epoch-ns
before/after output lstat samples. Those missing observations are NOT filled
from parsed timestamps, durations, file times or post-hoc guesses. Therefore
none of these old receipts can honestly be normalized to the oracle's full
completed-receipt/output-state contract. No oracle evaluate/CLI verdict is run.

SCOPE-AND-STREAM-BINDINGS.json binds each existing real process/attempt to exact
raw stdout/stderr bytes and the actual JSON body-definition/hash/span/native
phase records at their real byte offsets. These are post-run byte indexes of
genuine compiler observations, not invented compiler timestamps or an atomic
Builder-query/session epoch. Builder lines alone, including feature-off lines
where retention early-returns, are not upgraded to completed capture.

The source's bare native driver error still has no fixture/body span. No such
native refusal is observed here; the anonymous refusal occurs in the verifier
phase with its genuine function span. The mapping does not invent a missing
native span and must not accept a future unscoped native error.

oracle-diagnostic-mapping.PROPOSED.json is a SOURCE-REVIEW PROPOSAL ONLY: the
unchanged Debug field/envelope names bound to the final modified source digest.
It is neither independently approved nor an expectation. Instrumented stderr
contains extra capture JSON, including repeated refusal text; the strict
oracle is not given filtered streams or a relaxed count/noise rule.
Before any actual verdict the parent must independently review a compatible
protocol/mapping, register expectations independently, and collect NEW real
epoch-ns/output-state evidence. Existing successes/failures stay historical.

No additional compiler build or diagnostic launch is made in response to the
oracle update. The compiler-heavy slot is released; only Python evidence and
sealing operations remain. The parent's separately prepared native observer
may proceed under standing authority without another routine approval.
