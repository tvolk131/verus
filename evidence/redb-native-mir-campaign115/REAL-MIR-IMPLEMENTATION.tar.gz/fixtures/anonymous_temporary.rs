use verus_builtin::*;
use verus_builtin_macros::verus;

verus! {
pub struct Flush<'a> { pub destination: &'a mut u64, pub pending: u64 }

impl<'a> Drop for Flush<'a> {
    fn drop(&mut self)
        ensures *final(self).destination == old(self).pending,
        opens_invariants none
        no_unwind
    {
        *self.destination = self.pending;
    }
}

pub fn anonymous_temporary(original_loan: &mut u64)
    ensures *final(original_loan) == 19,
{
    { Flush { destination: original_loan, pending: 19 }; }
}
}
