use verus_builtin::*;
use verus_builtin_macros::verus;

verus! {
pub fn named_native_resource(native_owner: std::fs::File) {
}
}
