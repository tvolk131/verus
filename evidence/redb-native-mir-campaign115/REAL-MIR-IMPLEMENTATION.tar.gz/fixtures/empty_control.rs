use verus_builtin::*;
use verus_builtin_macros::verus;

verus! {
pub fn empty_control() {
}
}
