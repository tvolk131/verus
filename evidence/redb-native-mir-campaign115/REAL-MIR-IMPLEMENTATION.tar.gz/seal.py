import datetime
import difflib
import hashlib
import json
import os
from pathlib import Path
import sys
import tarfile
import time
import traceback
import worker

ROOT = worker.ROOT

def prepare():
    worker.authenticate('exit')
    previous = json.loads((worker.PREVIOUS / 'SEALED-MANIFEST.json').read_text())
    checked = worker.verify(previous['records'], worker.PREVIOUS)
    worker.write('previous-sealed-payload-exit-authentication.json', checked)
    assert checked['ok'], checked
    final = worker.inventory(worker.STAGE)
    identity = json.loads((ROOT / 'source-final-inventory.json').read_text())
    assert final == identity['records']
    assert worker.digest(final) == 'a5ea05ccd4ecd04f5fc0fde6963cdfaaf7e29543a1c7def511a23e6d22f8ee81'
    assert json.loads((ROOT / 'build-output-identities.json').read_text())['records'] == worker.inventory(ROOT / 'target')
    originals = worker.inventory(ROOT / 'source-build01-reconstructed')
    assert originals == json.loads((ROOT / 'build-engine-01.source-before.json').read_text())['records']
    patch = []
    for record in final:
        before = ROOT / 'source-build01-reconstructed' / record['path']
        after = worker.STAGE / record['path']
        if worker.sha(before) != record['sha256']:
            patch.extend(difflib.unified_diff(before.read_text().splitlines(True), after.read_text().splitlines(True),
                fromfile='build01/' + record['path'], tofile='build02/' + record['path']))
    (ROOT / 'build01-to-build02-diagnostic-change.patch').write_text(''.join(patch))
    installed = list((worker.TC / 'lib').glob('*.dylib'))
    sdk = Path((ROOT / 'preflight-sdk-path.stdout').read_text().strip())
    installed.extend([Path((ROOT / 'preflight-linker-path.stdout').read_text().strip()),
                      sdk / 'SDKSettings.json', sdk / 'SDKSettings.plist', sdk / 'usr/lib/libSystem.tbd'])
    tools = [{'path': str(file), 'resolved': str(file.resolve()), 'exists': file.is_file(),
              'bytes': file.stat().st_size if file.is_file() else None,
              'sha256': worker.sha(file) if file.is_file() else None} for file in installed]
    worker.write('platform-support-identities.json', {'records': tools,
        'limits': 'Not exhaustive system dyld cache, SDK/header, kernel, firmware or toolchain bootstrap attestation.'})
    oracle = Path('/private/tmp/redb-native-mir-campaign115-oracle-20261108T160308Z')
    worker.write('oracle-read-only-input-identities.json', [
        {'path': str(oracle / name), 'bytes': (oracle / name).stat().st_size, 'sha256': worker.sha(oracle / name)}
        for name in ('oracle.py', 'HANDOFF.md', 'fixture-expectation.schema.json', 'CONTENT-MANIFEST.json', 'SEAL.json')])
    results = json.loads((ROOT / 'RESULTS.json').read_text())
    result_map = {record['name']: record for record in results['records']}
    ledger = []
    scopes = []
    minimum_free = None
    maximum_allocated = 0
    for file in sorted(ROOT.glob('*.receipt.json')):
        receipt = json.loads(file.read_text())
        name = receipt['name']
        assert receipt['status'] == 'COMPLETED' and receipt['owned_group_absent']
        assert receipt['source_digest'] == receipt['source_after_digest']
        for stream in ('stdout', 'stderr'):
            assert worker.sha(ROOT / (name + '.' + stream)) == receipt[stream + '_sha256']
        assert receipt['elapsed_seconds'] < (900 if receipt['compiler_command'] else 90)
        if receipt['compiler_command']:
            assert receipt['child_exit_code'] == 0
        samples = [json.loads(line) for line in (ROOT / (name + '.resources.jsonl')).read_text().splitlines()]
        samples.extend([receipt['resource_before'], receipt['resource_after']])
        for sample in samples:
            assert sample['safe'] and sample['free_bytes'] > 16 * 1024**3
            minimum_free = min(minimum_free or sample['free_bytes'], sample['free_bytes'])
            maximum_allocated = max(maximum_allocated, sample['allocated_bytes'])
        outcome = result_map.get(name, {}).get('classification', 'non_engine_command')
        ledger.append({'name': name, 'receipt_sha256': worker.sha(file), 'status': receipt['status'],
                       'exit': receipt['child_exit_code'], 'elapsed_seconds': receipt['elapsed_seconds'],
                       'compiler_command': receipt['compiler_command'], 'classification': outcome})
        if name not in result_map:
            continue
        stdout = (ROOT / (name + '.stdout')).read_bytes()
        stderr = (ROOT / (name + '.stderr')).read_bytes()
        captured = []
        offset = 0
        for line_number, line in enumerate(stderr.splitlines(keepends=True), 1):
            if line.startswith(b'TASK115_CAPTURE '):
                observation = json.loads(line[len(b'TASK115_CAPTURE '):])
                captured.append({'stderr_line': line_number, 'byte_offset': offset, 'byte_length': len(line),
                    'line_sha256': hashlib.sha256(line).hexdigest(), 'definition': observation['definition'],
                    'definition_hash': observation['definition_hash'], 'definition_span': observation['definition_span'],
                    'native_phase': observation['native_phase'], 'mir_phase': observation['mir_phase']})
            offset += len(line)
        scopes.append({'attempt_name': name, 'launcher_receipt_sha256': worker.sha(file), 'pid': receipt['pid'],
            'process_group': receipt['process_group'], 'source_fingerprint': receipt['source_digest'],
            'fixture': result_map[name]['fixture'], 'fixture_sha256': result_map[name]['fixture_sha256'],
            'stdout_sha256': hashlib.sha256(stdout).hexdigest(), 'stderr_sha256': hashlib.sha256(stderr).hexdigest(),
            'stdout_bytes': len(stdout), 'stderr_bytes': len(stderr), 'actual_body_observations': captured,
            'started_epoch_ns_available': False, 'ended_epoch_ns_available': False,
            'output_before_after_epoch_ns_available': False, 'atomic_compiler_epoch_claimed': False,
            'oracle_normalizable': False})
    worker.write('COMMAND-LEDGER.json', ledger)
    worker.write('SCOPE-AND-STREAM-BINDINGS.json', {'records': scopes, 'actual_oracle_verdict': None,
        'scope': 'Post-run byte indexes of genuine body observations bound to actual attempts; not missing timestamp/scope repair.'})
    worker.write('FAILURE-ACCOUNTING.json', {'nonzero_bounded_commands': [record for record in ledger if record['exit'] != 0],
        'accidental_application_setup_failure': 'named-owner-01; nine missing-vstd E0433 errors; corrected explicit source-derived cfg',
        'compiler_build_failures': 0, 'observed_panics_ices': 0, 'observed_timeouts_cancellations_signals': 0,
        'early_inspection_and_patch_failures': 'See ENTRY-SETUP-NOTES.md; transcribed tool errors, not separately captured raw streams',
        'warning_attempts': ['build-engine-01', 'build-engine-02'], 'all_bounded_attempts_retained': True})
    worker.write('FINAL-RESOURCE-AND-SLOT.json', {'utc': worker.now(), 'resource': worker.resources(),
        'maximum_command_sampled_allocated_bytes': maximum_allocated, 'minimum_command_sampled_free_bytes': minimum_free,
        'first_clock_utc': '2026-11-08T16:02:43Z', 'deadline_utc': '2026-11-08T16:47:43Z',
        'compiler_heavy_slot_released': True, 'further_compiler_work_planned': False})
    worker.write('SEALING-EXECUTION.json', {'utc': worker.now(), 'argv': sys.argv, 'cwd': os.getcwd(),
        'environment': dict(os.environ), 'invocation': 'Explicitly allowlisted env -i; filesystem/hash/archive work only',
        'actual_oracle_verdict': None, 'source_fingerprint': worker.digest(final),
        'all18': 'OPEN', 'native_proof': 0, 'trust_adoption': 0})

def seal():
    assert not (ROOT / 'SEALED-MANIFEST.json').exists()
    assert time.time() < worker.DEADLINE - 60 and worker.resources()['safe']
    prepare()
    excluded = {'SEALED-MANIFEST.json', 'SOURCE-AND-RECEIPTS.tar.gz', 'SEAL.json'}
    records = [record for record in worker.inventory(ROOT) if record['path'] not in excluded]
    manifest = {'version': 1, 'root': str(ROOT), 'utc': worker.now(), 'records': records,
                'fingerprint': worker.digest(records), 'source_fingerprint': worker.digest(worker.inventory(worker.STAGE)),
                'all18': 'OPEN', 'native_proof': 0, 'trust_adoption': 0,
                'original_native_path': 'FAILED', 'git': 'UNAVAILABLE', 'compiler_bootstrap_correspondence': 'UNESTABLISHED',
                'goal_service_last_observed': 'BLOCKED', 'actual_oracle_verdict': None,
                'exclusions': sorted(excluded), 'archive_excluded_subtrees': ['target', 'artifacts', 'tmp']}
    worker.write('SEALED-MANIFEST.json', manifest)
    archive = ROOT / 'SOURCE-AND-RECEIPTS.tar.gz'
    bundled = [record for record in records if Path(record['path']).parts[0] not in ('target', 'artifacts', 'tmp')]
    with tarfile.open(archive, 'w:gz', compresslevel=6) as stream:
        for record in bundled:
            stream.add(ROOT / record['path'], arcname=record['path'], recursive=False)
        stream.add(ROOT / 'SEALED-MANIFEST.json', arcname='SEALED-MANIFEST.json', recursive=False)
    expected = {record['path']: record for record in bundled}
    expected['SEALED-MANIFEST.json'] = {'bytes': (ROOT / 'SEALED-MANIFEST.json').stat().st_size,
                                      'sha256': worker.sha(ROOT / 'SEALED-MANIFEST.json')}
    with tarfile.open(archive, 'r:gz') as stream:
        members = stream.getmembers()
        assert len(members) == len(expected)
        for member in members:
            assert member.isfile() and member.name in expected
            data = stream.extractfile(member).read()
            assert len(data) == expected[member.name]['bytes']
            assert hashlib.sha256(data).hexdigest() == expected[member.name]['sha256']
    assert worker.resources()['safe'] and time.time() < worker.DEADLINE
    worker.write('SEAL.json', {'utc': worker.now(), 'manifest_sha256': worker.sha(ROOT / 'SEALED-MANIFEST.json'),
        'archive_sha256': worker.sha(archive), 'archive_bytes': archive.stat().st_size,
        'manifest_payload_files': len(records), 'archive_files_verified': len(expected),
        'compiled_output_files_not_bundled': len(records) - len(bundled), 'resource_after': worker.resources(),
        'all18': 'OPEN', 'native_proof': 0, 'trust_adoption': 0, 'actual_oracle_verdict': None})
    print(json.dumps({'root': str(ROOT), 'seal': json.loads((ROOT / 'SEAL.json').read_text()),
                      'seal_sha256': worker.sha(ROOT / 'SEAL.json')}, sort_keys=True), flush=True)

if __name__ == '__main__':
    try:
        seal()
    except BaseException as error:
        worker.write('SEALING-FAILURE-' + datetime.datetime.now(datetime.timezone.utc).strftime('%H%M%S') + '.json',
                     {'utc': worker.now(), 'error': repr(error), 'traceback': traceback.format_exc()})
        raise
