# Task115 — distinct source-bound real-MIR checkpoint

## Scope and unchanged qualifications

This is a distinct task under campaign115 standing authority, not a reset or
rerun of114 and not the unchanged Mutex/Hasher113 probe. No subdelegation,
network, native redb application execution, parent integration, Git write,
trusted producer, assumption, law, admission, or trust adoption is performed.
The excluded growth049/zero-growth050/mutation030/refused-padding95 and
diagnostic107-D1 work stays excluded. Goal service is untouched; its inherited
last-observed state remains BLOCKED. The parent continues at this checkpoint
under standing authority without a routine approval gate.

All18 remain OPEN; native proof0; trust0 (no new trust adoption). Original native
path FAILED; Git UNAVAILABLE; compiler bootstrap correspondence UNESTABLISHED.
The new build/source binding is local engineering evidence, not a repair of
these qualifications and not a native lifecycle theorem.

## Frozen input and executable binding

The immutable114 snapshot was authenticated as 1,095 files with fingerprint
`c9cb297436ab24053c254ed95bd4e520ef6fca5b86832d217b37302cb5ad7b23`.
Its SEALED-MANIFEST SHA256 is
`c73d2fba54d4144d3705d78a6d5d6cf9d29bf5eaeeb80dce6d9736fd001d6dd9`;
the reviewed revision2 MANIFEST SHA256 is
`a586fe4665ee832499ea233969eb2914b941093186596f849d8cfeea9321c342`.
Entry authentication checks all previous sealed payloads and reviewed inputs.
Every executed bounded command authenticates the frozen source, both seals,
reviewed inputs and all 1,478 selected parent records again. Exit authentication
and full previous-payload reauthentication are retained by sealing.

Only source and necessary workspace dependency source were staged. Installed
locked dependency sources and the direct pinned 1.99.1 cargo/rustc/rustdoc
were used in place. No existing target, compiler, toolchain or cache was imported.
The solver is the installed, read-only Z3 4.16.0 binary identified in receipts.
Matching verus_builtin and verus_builtin_macros were built here; no old vstd,
old compiler, duplicate vstd or incompatible companion library was imported.

Two actual offline/locked Cargo builds completed at jobs1, not cargo check or
a test harness: 90.941 seconds and 13.004 seconds. Build01's newly built engine
was moved, not copied from a prior run, to artifacts/rust_verify-build01 before
build02. Its SHA256 is
`154ab68a6598f23ee5b4fc2d40e60385cccba07442124b30a0d6bbb502d69e07`.
Build01 source fingerprint is
`d0632f7e3044a8d70e50a07d0bc7abf1e39216aed4a93c62ef011dec5c699ff8`.
The build01 source is reconstructed transparently under
source-build01-reconstructed; every file exactly matches the original prebuild
inventory. It is not represented as an original-time copy.

The final engine is target/debug/rust_verify, SHA256
`876136841ad6938783d06a4d6751b9bffd268cb04d4626c20cff90b79167a951`.
Its actual source fingerprint is
`a5ea05ccd4ecd04f5fc0fde6963cdfaaf7e29543a1c7def511a23e6d22f8ee81`.
The existing honest unversioned-snapshot metadata branch emits that digest;
no fake Git or shim is used. Final diagnostic receipts hash executable and
fixture bytes immediately before launch. Earlier build01 probes predate this
extra per-launch hashing; their executable was identified before build02 and
their own output metadata and source inventories remain available.

## Checked deltas

Exactly two source paths differ from the frozen baseline:

- source/rust_verify/src/checked_normal_drop.rs: default-off JSON observations
  of actual capture inputs, every actual drop site including binder matches,
  actual origin/completion statuses, normalization/refusal, and completion of
  the existing supported-subset native operation comparison.
- source/rustc_mir_build/src/builder/expr/as_temp.rs: default-off diagnostics at
  actual temporary and temporary-scope retention call sites, exposing DefId,
  ExprId, MIR local, real source span, lifetime, scope and native phase.

VERUS_TASK115_DIAGNOSTICS must equal 1 to print. No existing branch, normalizer,
owner accounting, admission, import/export barrier or trusted behavior changes.
Builder call-site diagnostics can also print when the feature is disabled;
they are NOT, alone, evidence that the early-returning retention function
stored anything. Interpretation requires an actual elaborated capture and
joins its completed origin/local back to a matching source-bearing Builder
line. The feature-off control has no capture records or accepted origin joins.
The temporary-scope logging branch is instrumented but was not reached by
these fixtures: no scope: Some record is claimed.

source-diagnostic-only.patch is the exact frozen-to-final delta.
fixture-matched-binder.patch changes only the anonymous constructor statement
to a named let binding at the same lexical scope. No fixture imports parent
application code or adds external specifications, axioms or admitted bodies.

## Actual execution results

- named-owner-final: exit0; two checked bodies verified; actual elaborated MIR
  Runtime(PostCleanup) observed in verifier and native phases. Native check
  reports two expected/two seen functions and completed existing operation
  comparison. This is only the established narrow scalar writeback subset.
- anonymous-temporary-final: exit1 intentional provenance refusal, not panic.
  The source constructor at fixtures/anonymous_temporary.rs:20:7 creates e19,
  local _7. Actual elaborated verifier MIR drops _7 at bb3; binder capture is
  complete with two observations and no local match; temporary capture is
  complete with eight observations and one local match. The same e19/_7 is
  joined to the Builder source span. Native phase is false. Normal successor,
  unwind Cleanup(bb5), root type and honest unqueried glue labels are retained.
  This refusal prevents this fixture reaching the native comparison.
- matched-binder-final: exit0, two bodies verified and both phases observed;
  the matched lexical/binder correction reaches the existing two-function
  native operation comparison. Local matches imply neither unique occurrence
  nor resource ownership.
- scoped-temporary-final: exit1 intentional provenance refusal. The borrowed
  anonymous owner has e19/_8 with a real Remainder lifetime. Normal and cleanup
  MIR drops both match the same completed origin record. This is not two
  owners, unique occurrence, or native cleanup correspondence.
- backend-negative-final: exit1, actual postcondition failure (19 versus20),
  not provenance refusal. named-feature-off also fails its postcondition.
- frontend-refusal-final: exit1, missing required no_unwind; no MIR capture.
- named-native-resource-final: exit1, std::fs::File unsupported by the frontend;
  no capture and no resource effect accepted. The suggested external type
  specification is NOT added. This is not evidence of a native File drop query.
- empty-control-final: exit0, one verified body. Both actual capture maps are
  completed-empty in a no-drop function. No actual missing or incomplete
  capture, nor an empty capture at an actual drop site, is claimed.
- named-export-refusal: exit1 at the existing explicit export barrier.
  anonymous-export-refusal: exit1 earlier at provenance refusal. Both requested
  effect.vir paths are absent and their output directories are empty.
- named-diagnostics-off (value0) and named-diagnostics-unset (variable absent):
  exit0, two bodies verified, no diagnostic capture/Builder/native-check lines.
  Absence of diagnostic lines here is not absence of actual compiler work.

RESULTS.json and individual observations retain exact counters and raw joins.
The final names above all use build02; initial build01 probes are kept too.

## Failures, warnings and interpretation

named-owner-01 is the one accidental application setup failure: exit1 with nine
E0433 diagnostics because the no-vstd macro cfg was missing. Source inspection
showed cfg_no_vstd evaluates verus_no_vstd; subsequent runs explicitly add
--cfg verus_no_vstd together with --no-vstd. No vstd substitute was used.
All deliberate refusal/backend controls and this failed attempt retain raw
stdout/stderr, true child exits, source inventories, exact argv/cwd/allowlisted
environment, resource samples and process-group completion checks.

Both successful Cargo builds retain the honest read-only cache last-use-data
warning and two inherited Rust dead-code warnings. This is not warning-free.
No compiler build failed; no actual panic/ICE, timeout, signal termination or
tool failure occurred in bounded commands. Eight synthetic interpreter tests
exercise those classification boundaries, malformed JSON, missing capture and
nonzero-only rejection; they are parser tests, not actual MIR evidence.
ENTRY-SETUP-NOTES.md discloses earlier inspection failures and the limitation
that their error text is transcribed rather than separately captured raw.

Run without compiling or executing any fixture:

    /usr/bin/python3 -B /private/tmp/redb-native-mir115-20261108T160243Z/interpret.py

For an extracted source/receipt bundle, use --bundle-only. That mode checks
receipt streams, source fingerprints, fixture bytes and source-origin joins,
but does NOT revalidate unavailable executable/tool bytes or rerun a compiler.
The original root retains the newly built artifacts; the handoff archive
deliberately omits target and artifacts. The seal checks archive member bytes.

The independent oracle update is reconciled in ORACLE-ADAPTER-LIMITS.md.
Original launchers lack real epoch-ns boundaries and output sampling; none is
retrofitted. SCOPE-AND-STREAM-BINDINGS.json is a truthful post-run byte index,
not an atomic compiler epoch. The proposed mapping is unapproved. No actual
independent-oracle verdict or native unscoped-error acceptance is claimed.

## Resource and next boundary

First clock: 16:02:43Z November8,2026; deadline:16:47:43Z. Compiler commands
are bounded at900 seconds, diagnostics at90 seconds; Cargo jobs1. Owned process
groups are terminated on timeout/cancellation and direct children are reaped.
Every completed bounded run reports its owned group absent. No timeout path
was required. Disk reservations, samples and final sealing resources retain
the actual use against6GiB and sampled free disk strictly above16GiB.

The next smallest native correspondence gap is the anonymous owner's
verifier/native origin and drop-site relationship beyond a local ExprId/local
match. This checkpoint has no native-phase anonymous capture because honest
verifier refusal stops first. Multiple sites/observations do not establish a
unique event, drop-glue identity, exclusive resource ownership, successor
effects or a lifecycle theorem. Any next diagnostic must retain that refusal
and unsupported named native resource effects, not bypass admission.
