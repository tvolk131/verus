import json
from pathlib import Path
import sys
import worker

ROOT = worker.ROOT

def probe(name, fixture, checked=True, extra=(), diagnostics=True):
    output = ROOT / 'outputs' / name
    output.mkdir(parents=True, exist_ok=False)
    arguments = [str(ROOT / 'target/debug/rust_verify'), '--internal-test-mode',
                 '--sysroot', str(worker.TC), '--crate-type=lib', '--edition=2021',
                 '--no-vstd', '--cfg', 'verus_no_vstd', '--output-json', '--no-cheating',
                 '--extern', 'verus_builtin=' + str(ROOT / 'target/debug/libverus_builtin.rlib'),
                 '--extern', 'verus_builtin_macros=' + str(ROOT / 'target/debug/libverus_builtin_macros.dylib'),
                 '-L', 'dependency=' + str(ROOT / 'target/debug/deps'),
                 '--out-dir', str(output)]
    if checked:
        arguments.append('--experimental-checked-normal-drop')
    arguments.extend(extra)
    arguments.append(str(ROOT / 'fixtures' / fixture))
    receipt = worker.run(name, 90, False, arguments,
                         {'VERUS_TASK115_DIAGNOSTICS': '1' if diagnostics else None})
    stdout = (ROOT / (name + '.stdout')).read_text()
    stderr = (ROOT / (name + '.stderr')).read_text()
    captures = [json.loads(line.removeprefix('TASK115_CAPTURE ')) for line in stderr.splitlines() if line.startswith('TASK115_CAPTURE ')]
    worker.write(name + '.observations.json', {'captures': captures, 'fixture': str(ROOT / 'fixtures' / fixture),
                 'fixture_sha256': worker.sha(ROOT / 'fixtures' / fixture),
                 'output_records': worker.inventory(output), 'exit': receipt.get('child_exit_code'),
                 'builder_lines': [line for line in stderr.splitlines() if line.startswith('TASK115_BUILDER_')],
                 'native_check_lines': [line for line in stderr.splitlines() if line.startswith('TASK115_NATIVE_CHECK ')]})
    print('captures', len(captures), 'exit', receipt.get('child_exit_code'), flush=True)
    for capture in captures:
        if capture['drop_sites']:
            print(capture['definition'], capture['native_phase'], capture['mir_phase'],
                  [(site['local'], site['binder_status'], site['temporary_status']) for site in capture['drop_sites']], flush=True)
    print(stderr[-1800:], flush=True)

if __name__ == '__main__':
    probe(sys.argv[1], sys.argv[2], sys.argv[3] != 'off' if len(sys.argv) > 3 else True,
          sys.argv[4:] if len(sys.argv) > 4 else ())
