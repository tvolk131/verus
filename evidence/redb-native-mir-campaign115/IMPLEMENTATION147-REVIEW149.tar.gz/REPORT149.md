# Independent exact-law review149 of sealed implementation147

## Disposition and scope

**147 remains UNADOPTED. No native theorem, resource certificate, primitive-law
installation, trust acceptance, final-cell approval, or campaign credit is
granted. 141 remains rejected; 148 is unconsumed; R146 H/G remain unsatisfied.**
All eighteen original cells remain OPEN. The first target remains original
two-phase acknowledged durability, not a header-byte or conditional-model cell.

This is a standalone source/receipt-only review in fresh scratch
`/private/tmp/review149-20261108-st0I07Ni`. No compiler, build, verifier, solver,
native application, test binary, network, Git operation, integration, parent
edit, or subdelegation ran. No compiler slot was acquired. The input was not
modified. Python performed only hash/archive-member/resource/receipt reading and
wrote this review's own evidence. The 18-minute limit includes sealing and is
measured from November 8, 2026, 15:34:53 America/Chicago, deadline 15:52:53.
Actual final elapsed time, scratch allocation, disk availability, and seal
readback are recorded in `SEAL149-READBACK.json`.

### Answer to the adoption question

The narrow **conditional, normal-return Arc byte-preservation/suspension and
Some-unwrap movement relations are source-supported**, rather than arbitrary
axioms. Subject to a separately enumerated runtime trust boundary below, they
are sufficiently defined for the parent to consider an explicit, bounded future
primitive disposition. Source support is not permission to mint a native token,
claim an original checkout invariant, or install the complete147 API as laws.

**The sealed147 implementation as a native byte-copy/writeback bridge is still
an unadoptable skeleton.** In particular, mere inhabitation of its current empty
marker types is insufficient: the producers must establish indexed semantic
premises, and findings H1/H2 must be resolved in the producer/consumer contract.
No transition has been solver-installed or applied to original native authority.
This review does not adopt even the source-supported subrelations. Parent
disposition and checked native application remain separate consequential steps.

## Authentication and custody

The supplied root was authenticated before substantive candidate inspection:

- Input: `/private/tmp/implementation147-20261108-FkC98LCT`.
- `SEAL.json` SHA256
  `87c3ca9a5a331d7ce7d654c89e256f9f5ac39b2487dc7be687cc16ea08204c10`.
- All **260/260** sealed payloads matched byte lengths and hashes, totaling
  24,567,764 bytes; these were read in place, not copied into review scratch.
- `candidate-final.json`: **1107/1107** actual candidate files matched before
  Rust inspection. Its hash is
  `25a7e31d181427d70313c9460b93016af9f3e6e530e58ab56cf9d1a7517b1b62`.
- `source-law-manifest147.json` hash
  `41635b537891ade2bb01443e499849d403bf3fba6340a4670d4fccfeefbf3dd2`;
  all seven referenced compiler/spec files match. The six-file source delta
  matches the actual candidate. `candidate.patch` hash
  `fd37c9820e890a89e8433a914bea6b224665757b2087c80189cf4e9122dacecb`.
- `LAW147.md` hash
  `41b070267a7d54baca7dd7c6723a8336ced51e30cfa9420ce1ca5130f13f994f`;
  `README.md` hash
  `9a378745daa64df0746955a0eb28e89b87e87284bbf1f4c49504bc1b8a6514f6`.
- Actual `authority147.rs` hash
  `2ba4042cce9f1fe58f0acb0351638981a3f4cbf1c542ac568f90041cbb26ff66`;
  actual `machine147.rs` hash
  `681a51f576a03cfd24e0376120419c3821ab7ebf6aca2aeaa77008b9f4510fa1`;
  actual `native_resource143.rs` hash
  `97a2702ff81b5af575548012a9a725cf6a9583f2a187401f5ac8e0ab009899d1`.

The actual authority139/first-cell139/selection128 files also match the
external selections in sealed `inputs.json`. RESOURCE-BOUNDARY135 was separately
hashed. Hashes and full selected-file lists appear in
`authentication-recorded-entry149.json` and `authentication-exit149.json`.
These files record this review's current readbacks, not invented earlier custody.

Rust source selection128 is release1.99.1, commit
`58cf8f9c35b355199727627d07ae34a4e2846d67`. The archive's actual length and SHA256
match selection128:
`e485a88c45db546b73571df7bebfcb4454ba4fb552c492e25fc5b00eeb5bf22d`.
All four originally selected expanded members match. All seven147-selected
runtime members match both their expanded files and their archive members
without extraction to disk. `alloc/src/sync.rs` is
`b2f806b0f696a181018072625dceed25304aa97dfef6a79bac9800d529afdd0e`.
This authenticates local source selection, **not upstream authenticity or
installed compiler/runtime/bootstrap correspondence**. The latter remain OPEN,
as selection128 and147 explicitly say.147's late member selection is not
backdated to its entry.

### Anchor conventions

All Rust anchors below refer to authenticated final files under
`/private/tmp/implementation147-20261108-FkC98LCT/candidate/`:

- `A` = `source/rust_verify/src/native_resource143/authority147.rs`.
- `M` = `source/rust_verify/src/native_resource143/machine147.rs`.
- `N` = `source/rust_verify/src/native_resource143.rs`.
- `L` = `source/rust_verify/src/native_resource143/ledger.rs`.
- `V` = `source/vstd/std_specs/slice.rs`.

`LAW` means input `LAW147.md`. Runtime source anchors are under selection128's
authenticated library root, not the installed toolchain source by presumption.
Line anchors name starts; subsequent prose identifies the exact function/body.

## Severity-ranked findings

### H1 — Native copy constructs a term, not the promised normal byte equation

**Anchors:** `LAW:130`, `A:29`, `A:145`, `A:190`, `A:203`, `A:825`,
`A:855`; contrasting control implementation `M:192`.

`copy_native` verifies callee owner/returned Place/parent loan, rejects the same
allocation identity, and compares source/receiver operands. It then constructs
`NativeByteValue::CopyOf { source, actual_call }`. `NativeByteView` contains no
length, byte sequence, slice extent, or interpretation relation. There is no
normal-completion observation input: storing `copy.normal` records a possible
CFG successor, not evidence that this invocation took it. The function itself
also does not check that the supplied Call is the canonical copy instance or
is the already-validated ByteMutation occurrence. The separate `consumer`
checks actual core slice-copy shape but returns refusal JSON, not checked ports
or a native semantic relation.

Thus the code does **not by itself enforce** `B_after = source_snapshot` and
`n_after = n_before = source_len`, nor source-frame preservation. In contrast,
`M:201` checks a live frozen source snapshot and `M:205` checks lengths before
`M:210` performs concrete byte copying. These control checks are absent from
the native representation; four killed control mutants do not transfer them.

**Exact missing premises:** a checked source view bound to actual source Place,
allocation/generation, extent, initialized bytes and read lifetime; exact
destination loan/extent; equal native lengths; disjoint live storage/provenance;
source/unrelated-state frames; the exact canonical copy occurrence and an
executed normal-return proof fact; and a closed interpretation/lowering of
CopyOf into the existing slice equation. A static normal edge is insufficient.

**Counterargument and limitation:** S/R are intentionally empty checked ports,
and a future private factory could prove all these premises before constructing
`CheckedCopyPorts`. That would be a valid design route. Today there is no such
producer or contract implementation, so this is a **high-priority future-law
installation blocker, not a currently accepted false theorem or executable
native exploit**. A producer must not be inhabited by a generic permit or by
reusing the observer's successful shape check.

### H2 — Unchanged writeback lacks the effect and caller-link premises needed to restore old bytes

**Anchors:** `LAW:138`, `LAW:151`, `A:158`, `A:162`, `A:225`, `A:289`,
`A:300`; original mutation-capable result `cached_file.rs:35`.

`writeback_unchanged_native` consumes the matching loan identity and suspension,
checks allocation/generation/handle, matching callee labels, a non-cleanup
actual NLL endpoint, and that endpoint's local borrowed/assigned Places. It
returns the original authority with its original byte view. Unlike the mutated
path, it has **no saved caller owner/loan/returned-Place/normal-successor link to
compare against**. The endpoint's caller body can be internally consistent
without being shown here to be the caller of this suspension. More importantly,
possession of an unconsumed loan token is not a proof that the actual returned
`&mut [u8]` has not been written through, reborrowed to a writing callee, or
affected by an unmodeled operation. NLL end proves an endpoint, not unchanged
contents. This function has no explicit effect-completeness/no-write witness.

**Exact missing premises:** E/R must certify the same dynamic returned loan and
caller/callee invocation, precise reborrow lineage, holder incarnation, full
receiver/root relation, correct normal event/endpoint, and that every native
effect on the loan's bytes up to that endpoint is represented. For this branch,
that final effect must be an actual unchanged frame, not merely absence of a
`copy_native` token. If there were writes, the rule must instead consume their
checked final byte view. The checked normal endpoint must follow all descendant
loans and not be an unrelated local NLL end.

**Counterargument and limitation:** a strong `CheckedNativeLifetimeTransferProducer`
could carry an opaque theorem including those facts. But the empty marker has
no implemented indexed producer, and its name alone specifies no no-write
theorem. Private fields and uninhabited ports prevent actual use now. Therefore
this is again an adoption blocker, not a demonstrated admitted proof. Do not
fix it by assuming the original caller starts or stays valid.

### M1 — Affine object transport is not full effect/debt accounting

**Anchors:** `A:97`, `A:162`, `A:190`, `A:237`, `A:289`, `LAW:138`,
`LAW:144`; contrasting `M:69`, `M:222`, `M:252`.

By-value native tokens plus private constructors prevent ordinary duplication
and successful double resumption within the one-copy API. They do not establish
all claims made by the prose: native code has no current-mutation/event ledger,
no explicit stored length, no cleanup-prefix byte semantics, and no outstanding
debt object returned on errors. An `Err(String)` can drop moved authority/loan
arguments; the control machine instead keeps its record suspended/poisoned.
Conservative resource loss is not a second usable authority and is not itself
unsound, but it must not later be mistaken for discharging a required obligation.

The native API consumes a loan on copy, so its single-copy shape does prevent
the particular repeated-copy scenario used by `M:488`; absence of a native
event ledger is **not** proof that that control counterexample is directly
reachable. It does mean that any extension to multiple writes/events requires
a real current-effect chain and exact endpoint coupling, rather than importing
the control machine's stale-event coverage as native evidence.

**Missing premise/repair contract:** globally retained outstanding obligations,
exactly-once full required-bundle consumption, effect-complete write chains,
and explicit error/cleanup/nonreturn residuals. R146 H/G and the unconditional
export refusal currently keep this gap fail-closed. They are not discharged by
Rust move checking, and148 was not consumed.

### I1 — The tests and original observations are honestly scoped but not native-law evidence

**Anchors:** `M:115`, `M:142`, `M:146`, `M:261`, `M:276`, `A:904`,
`A:925`, `A:958`, `N:789`, `N:873`; `README.md:75`,
`proof-scope147.json`, `validation-summary147.json`.

The18 control tests operate on a separate Box-backed machine. Some/None there
are chosen API operations, not observations of the native Option result. Test
fixture checkout/end issuance is cfg(test), and native checkout always refuses.
The five typed faults mutate actual in-memory binding records, not five original
native source programs and not native byte-law executions.147 explicitly makes
these distinctions; I found no evidence of a hidden native producer or adopted
law. Treating these results as native law validation would be a new overclaim,
not what the retained receipts establish.

## Per-transition disposition

Classification used below:

- **S:** source-supported conditional relation under the explicit runtime trust
  boundary, not a proved native theorem.
- **C:** exact structured transport/check actually present in code, assuming
  inputs exist; not a semantic solver law.
- **U:** unsupported/uninstantiated as an original-native semantic law in147.

Every transition below remains **U for native application and UNADOPTED**.

### T0 — Original checkout / authority issuance

**S:** No original checkout theorem is supplied. Constructor identity alone
does not prove initialized/reused bytes, a persistent cache None reservation,
eligibility, alias closure, or complete handle/weak inventories.

**C:** `A:13` makes the original producer uninhabited; `A:43` embeds it in every
NativeAuthority. `A:796` refuses `require_checkout(binding, None)` and has no
reachable success producer. `NativeByteValue`'s only finite base is the empty
checkout producer (`A:35`); recursively wrapping CopyOf does not create a base.

**Missing:** I in full: checked actual constructor/checkout/cache path, byte
initialization or reuse, live allocation and fresh generation, handle and weak
inventory including implicit weak, frame/unsafe alias closure. Fresh Rc identity
alone does not establish a native allocation incarnation. No token is issued.

### T1 — Arc get_mut normal None

**S:** In `alloc/src/sync.rs:2673`, the false branch returns None and does not
write allocation data. `is_unique:2811` accesses count fields, not `[u8]` bytes.
For a valid live allocation, valid Arc metadata, stable byte frame and the
runtime trust boundary, the receiver's allocation/generation/handle/root and
actual byte sequence/length are preserved. This does not preserve every count
intermediate or assert None iff aliases exist at return.

**C:** `A:102` checks owner/root/call/destination; `A:110` checks the exact
nominal None tag; `A:115` returns the very same NativeAuthority without changing
its fields. No returned slice token is created. This is genuine field/object
preservation, conditional on authentic authority and outcome inputs.

**Missing:** I, A, actual D=None bound to this invocation/destination, and a
stable no-external-byte-write frame. The nominal variant's metadata is not D.
H/G are also embedded in CheckedOutcome for both tags, making this API stricter
than LAW's None precondition; that conservatism is not a soundness defect.

### T2 — Arc get_mut normal Some / receiver suspension

**S:** `sync.rs:2673`, `sync.rs:2748`, and `sync.rs:2811` support the conditional
grant of the allocation's data projection, with unchanged bytes and slice
length. Some does not independently prove a count-based global invariant. The
reference excludes count fields. Safe/unsafe alias and runtime assumptions are
essential to exclusive access, not facts proved by hashing these bodies.

**C:** `A:117` retains the whole original authority in a private suspension and
creates one fresh loan identity; allocation, generation and handle witnesses
are Rc-cloned without cloning authority. Loan owner/Some field/parent BorrowIndex
come from the binding. There is no public usable-authority accessor on the
suspension and no Clone/Copy on native authority/loan tokens. The loan itself
does not carry an explicit B/n payload or solver predicate.

**Missing:** I, actual D=Some, H/G, A, exact slice extent and exclusive data
permission relation, live generation/handle-to-native-storage correspondence,
and a semantic interpretation connecting the suspended byte view to the loan.

### T3 — Some payload through Option unwrap and native return

**S:** `core/src/option.rs:1011` moves Some's payload to the result; None calls
`unwrap_failed` (`option.rs:2247`) and supplies no normal result. A normal
Some payload is not duplicated. Actual compiler lowering, native lifetime and
interprocedural reborrow interpretation still need the stated boundary/proofs.

**C:** `A:162` requires the matching loan identity, owner, original Option Place,
parent and Some-field Place, then changes that loan's returned Place to the
bound native return. It consumes the token. `A:613`, `A:627`, `A:655`, and
`A:708` check original unwrap/return block, nominal types, assignments and
reborrow/outlives facts. These are local structural constraints; region erasure
is used only for signature type comparison (`A:369`, `A:433`).

**Missing:** R's exact actual normal-unwrap result, returned `_0` and caller
loan connection; effect/holder correctness throughout moves/overwrites/storage
reuse; H/G; actual returned slice value/permission correspondence. No local
SwitchInt was fabricated. A future checked producer may derive Some from a
proved normal unwrap path under the exact Option rule; it need not execute a
new runtime observation or rewrite the original caller. No finite panic-hook,
eventual unwrap return, or cleanup-to-normal conversion is justified.

### T4 — Native copy, normal outcome

**S:** `core/src/slice/mod.rs:4339` dispatches T:Copy to the implementation;
`slice/mod.rs:5582` checks length, then uses nonoverlapping copy at `5605`.
For u8, valid equal-length disjoint initialized storage and a stable read frame,
the conditional normal result is exactly source bytes. Existing `V:634`
requires equal old destination/source lengths and ensures final destination
sequence equals source. This is itself an assume_specification, not a new
verified source proof, and it has no no_unwind clause here.

**C:** `A:190` checks callee labels, different allocation witnesses and exact
operands, consumes the native loan and builds a destination-identified CopyOf
term with the static normal target. The separate observer `A:825` validates
actual native mem_mut/copy shape and refuses authority. Same-allocation copies
are conservatively rejected even if subranges might be disjoint; this restricts
coverage and is not a claim that every disjoint native copy is rejected/accepted
correctly without S.

**Missing:** all H1 premises; R/S/A; source frame preservation and endpoint-
indexed normal event. V's contract has never been instantiated on the original
redb receiver in147. Copy length mismatch, panic, unwind, abort and nonreturn do
not receive the normal equation or an old-byte rollback equation.

### T5 — Normal mutated NLL end / writeback

**S:** NLL endpoints alone give no byte equation. Conditional on a real E/R,
the same suspended receiver can regain exactly the latest checked loan's final
byte view after the actual normal successor and end of all relevant loans.
This is source/borrow-semantics-supported resource transfer, not a consequence
of Arc source text alone.

**C:** `A:237` compares loan/allocation/generation/handle identities, mutated
byte-view identities, callee labels, caller owner/loan/returned Place, immediate
normal successor at statement0, non-cleanup, exact NLL-end membership and
borrowed/assigned Places; it consumes both and updates the sole returned
authority's byte view. Ordinary token reuse cannot resume it twice. It cannot
validate that CopyOf denotes correct native bytes, that the caller mapping is
semantically valid, or that all effects were accounted for.

**Missing:** E/R indexed by actual invocation/loan/effect; the H1 byte equation;
all descendant-loan ends and frame/lifetime correctness; H/G; effect-complete
latest-write relation; preservation of outstanding obligations on failures.
An immediate normal successor may be deliberately restrictive; no arbitrary
later endpoint, loop iteration, or cleanup is covered.

### T6 — Unchanged normal NLL end / writeback

**S:** Unchanged writeback is valid only if the actual native byte frame is
unchanged and the same loan's lifetime has ended. Merely not creating a copy
token does not prove this, because the result is a native mutable slice.

**C:** `A:289` consumes identities and checks a non-cleanup actual local NLL
end, then returns the unchanged authority object. This proves structural token
retention under those inputs, not the missing unchanged-frame relation.

**Missing:** all H2 premises, especially checked no-write/effect completeness,
cross-function caller/root mapping, normal event/endpoint identity and end of
all derived loans. Do not install this rule in its current marker-only form.

### T7 — Cleanup, unwind, abort and divergence

**S:** No normal continuation follows abort/divergence. None unwrap enters panic
machinery, whose hook/destruction may unwind, abort or fail to return. No finite
hook or total termination premise follows from source. Slice length-mismatch
checks occur before this implementation's copy operation, but that does not
prove a global rollback property for panic hooks, prior native effects or
unrelated state. A normal-copy equation is not a cleanup-prefix equation.

**C:** `A:270`/`A:308` reject cleanup in normal writeback; `A:878` separates
normal-copy, unwind-prefix cleanup and unchanged observer labels, granting no
authority. `M:252` only poisons a control record. It is not native Mutex poisoning,
not a proof of partial native bytes, and not a native error-prefix model.

**Missing:** checked actual prefix effects, residual obligations, unwind/drop
glue and panic-hook frame/outcome facts as needed by the original body. Current
native cleanup laws are absent, not silently total or vacuously successful.

### T8 — Native application Result / question-mark transfer (not a147 primitive rule)

**S:** No Result/Try source law was reviewed or adopted in147. Its selected seven
runtime members do not include `core/src/result.rs`; Option payload movement
must not be extended to Result or residual conversion by analogy.

**C:** The actual original write_header capture retains bb7 storage.write,
bb8 `Result::Try::branch`, bb13 `Result::FromResidual::from_residual`, and bb15
native mem_mut. In authenticated `original147-final.json`, the first and last
are `CHECKED_ORIGINAL_BODY_REQUIRED`, and both Result operations are
`UNADOPTED_NATIVE_OPERATION_REQUIRED`. The observer does not grant any of them
byte authority. Actual source `page_manager.rs:1623` uses `write(...)?` before
mem_mut/copy and `page_manager.rs:1628` returns Ok only after that source path.

**Missing:** exact nominal Result/ControlFlow types, Instances/substitutions,
runtime discriminants, Ok payload ownership/moves, Err/residual conversion,
normal/cleanup edges and branch-specific prefix effects; a checked storage.write
body establishing the returned WritablePage's reservation/byte authority. The
original native result and its success are not established merely because the
following mem_mut/copy shape binds. These remain U, separate from T3.

## Exact runtime/source/compiler boundary

The following must be recorded as either explicit bounded trusted assumptions
or actual checked caller facts, **not hidden inside a generic checked port**:

1. **Source/compiler/config binding:** selection128's local release/commit and
   exact member hashes; actual linked alloc/core/std definitions and the
   compiler's builtin/diagnostic/lang-item interpretation; compiler lowering,
   Instance/substitutions and target code generation; actual
   `aarch64-apple-darwin`, edition2024, std feature and panic=unwind analysis
   configuration in `original147-final.receipt.json`. The receipt's flags are
   historical observations, not a build/runtime correspondence proof.
2. **Arc atomic semantics:** the actual usize strong compare_exchange
   weak(1,MAX,Acquire,Relaxed), strong.load(Acquire), weak.store(1,Release),
   allowed read-from/coherence and the needed synchronization; valid implicit-
   weak protocol and no count corruption/unsupported unsafe access. This CAS is
   strong; no weak-CAS retry/fairness premise is used. No freshest-load axiom or
   None-at-return iff concurrent-count invariant is allowed. Full caller handle
   inventory and eligibility still require checked native facts.
3. **Memory and allocation semantics:** valid live allocation, pointer/data-field
   layout and DST length metadata; Global allocation alignment/initialization/
   lifetime and generation; valid raw-to-reference provenance, Rust reference
   alias/reborrow/NLL rules; actual u8 storage ownership and stable source frames.
   Actual checkout, reservation and initial bytes are not replaced by trusting
   allocation identity labels. Allocation failure/abort/nonreturn is not normal
   constructor success.
4. **Copy/runtime semantics:** correct instantiated u8 Copy implementation and
   compiler memory-copy intrinsic, disjoint valid ranges, initialized source
   bytes, equal lengths, and the conditional normal memory effect. The pinned
   intrinsic declaration is source input; its target implementation is not
   proved by that declaration. No callbacks or rollback are postulated.
5. **Panic/cleanup/platform:** Option None and slice mismatch panic entry are
   distinct from hook completion, unwind, destructor effects, abort and
   divergence. Rust drop glue, compiler unwind lowering and runtime behavior
   need their exact bounded disposition where consumed. Mutex/Darwin pthread,
   guard/poison, map/hasher, atomics elsewhere, backends, buffers, synchronization
   and persistence are separate unresolved dependencies, not consequences of
   this Arc rule. No platform-wide primitive adoption is granted here.

The nominal binding work is useful: `N:149` resolves actual FnDef Instances;
`A:394` couples exact HIR/VIR/MIR location/instance/result/signature types;
`A:528` requires rustc's Arc diagnostic item; `A:541` uses the allocator's actual
default type and alloc Global ADT; `A:553` matches get_mut's associated DefId;
`A:577` requires the Option lang item and actual mutable-u8 Some field;
`A:627` binds nominal unwrap; `A:698` compares the full self.data Place and field
type. `A:791` retains is_unique/get_mut_unchecked associated DefIds. None of this
establishes that installed library machine code implements the selected source
or that arbitrary native aliases obey the trust boundary. The read-only
observer's printed JSON is not an input authority certificate.
No arbitrary input Expr, boolean, external key, count certificate, logical
binder, or serialized receipt is accepted as native law authority by these
private transition signatures. Internal sharing of immutable Rc identity
witnesses is not duplication of an affine capability. This positive confinement
does not supply any of the absent semantic producers.

## Retained execution evidence, failures and endpoint

`receipt-audit149.json` independently checks all30 historical receipts and
their raw stdout/stderr hashes. `raw-receipts149.json` additionally retains exact
bytes of all30 receipts/streams, commands and selected historical failure/scope/
release records as base64, with original lengths/hashes. Nothing was re-executed.
The audit records each return code rather than counting every nonzero as an
unexpected failure or concealing setup errors.

-147 remains **30/32** charged;143 remains **36/36 exhausted**. No allowance is
  reset by this review. Compiler slot acquisition by review149:0.
- Builds147-01,147-02,147-05 exited101; subsequent build receipts and the final
  feature build exit0. The original analysis runs exit1. The final raw stderr
  says `NRE143_OPEN_NATIVE_PROOF_OBLIGATIONS` and `export refused`.
-18 control tests pass in the restored/final formatted machine's retained
  streams. Four intended changed-source machine mutants compile and exit101
  in their targeted tests. The failed suspension patch setup accidentally built
  the preceding root mutant in command18; it is **not** credited as a suspension
  control. Corrected command19 and test20 are separate charged work.
- Five typed actual-original binding faults refuse; typed restoration returns
  the original structural binding while checkout still refuses. This is not
  five changed native original source mutants or native semantic proof.
- `source-restoration147.json` records the pre-format control source hash
  `e367616030f09775de334fff71aa56701504e03877c935460930921f70aee0ad`.
  It matches actual `machine147.control-original.rs`. Do not confuse it with
  the final formatted machine hash `681a51f5...`; format147 intentionally reports
  source changed, and commands24/25 separately recompile/run the restored final
  source. This review runs neither.
- Affine compile guards exit1; default-feature selection refusal exits101;
  validate147 exits0. The summary produced during validation lists29 completed
  receipts plus the in-flight thirtieth command; all30 final receipts now exist.
- Implementation147 historical exit authentication reports1671 selections,
  no failures, approximately1.035GB allocated scratch, >32GB free and293 seconds
  remaining. RELEASE reports30 charged, no owned command groups remaining,
  all18 OPEN and all adoption/proof counts0. These are historical147 observations,
  **not** review149's resource usage or claims of live process revalidation.
- Setup failures,143 exhaustion, interrupted116, historical source/compiler
  failures, unavailable Git continuity and unestablished bootstrap are retained.
  `SETUP-FAILURES.md` is authenticated, not overwritten. Parent148 and its reported
  authored-but-unrun tests remain unconsumed and supply no147/149 successes.
- Review149's own two read-only setup failures are retained: a zsh special
  `path` variable made cat unavailable (exit127), and a dict/list shape assumption
  raised AttributeError (exit1). Corrected reads succeeded; neither failure is
  counted as authentication success. Some broad terminal output was truncated;
  exact numbered slices and bounded summaries supplied the substantive review.

The original endpoint is still fail-closed in source: `N:873` emits an OPEN-only
capture with native_certificate=false/native_bodies_proved=0/laws_adopted=0;
`N:876` emits the hard error and stops compilation. `A:916` passes None to the
checkout requirement; `A:958` reports adopted=false, semantic_credit=0 and
native_export=REFUSED. No checked producer is instantiated, and no byte theorem
is exported. Therefore this is **no native proof**, not a vacuously accepted
native theorem. Rust compiling a function whose input is uninhabited is not
installation of its proposed equation in VIR/SST/AIR/SMT. All such runs in147
and in this review remain0.

## Smallest proof-directed next application

Do not start another diagnostic inventory, broaden Weak/progress work, or count
another control machine. After explicit parent disposition of only the narrow
conditional Arc/Option rules and its separate validation of any source repairs,
the next useful **actual proof-producing obligation** is:

**Establish one original fresh-overwrite checkout-to-mem_mut source path** in
`cached_file.rs:964`: prove the normal `zero_filled_arc(len)` bytes/allocation
ownership and carry them through actual `lock.insert`/`take_value` at `971` and
the returned WritablePage at `974`, preserving the exact native reservation,
generation/handle identity and unsafe-alias frame. Use that checked result, not
an assumed caller invariant, to construct the first occurrence-indexed native
checkout producer I for original `WritablePage::mem_mut` (`cached_file.rs:35`).
Then consume it through the actual normal Arc/Option path and verify that
original helper's full conditional native result with ordinary admission and
solver machinery. Missing dependency contracts must fail rather than become
trusted summaries. This is a bounded branch lemma, not a restriction of the
ultimate arbitrary-history campaign or permission to skip other checkout paths.

The first consumer after that helper is the actual write_header copy at
`page_manager.rs:1626`, with exact `header.to_bytes(true)` source/length frame and
checked normal NLL writeback; H1/H2 must be resolved before this produces bytes.
Cache reuse/reservations, errors/cleanup/drop, buffer return/flush/barriers/public
acknowledgement, crash/recovery and all other original obligations remain.
No header-only milestone closes acknowledged durability. This paragraph names
future work only: **no automatic followup is started by review149**.

## Final acceptance accounting

| Original native property | One-phase | Two-phase | Mixed histories |
| --- | --- | --- | --- |
| Crash atomicity | OPEN | OPEN | OPEN |
| Acknowledged durability | OPEN | OPEN | OPEN |
| Recoverable-state preservation | OPEN | OPEN | OPEN |
| Recovery, including interrupted recovery | OPEN | OPEN | OPEN |
| Error correctness | OPEN | OPEN | OPEN |
| Logical key/value refinement | OPEN | OPEN | OPEN |

Native/resource/trust/proof acceptance added: **0/0/0/0**. Native source proof
path remains failed/open; upstream/compiler/bootstrap correspondence remains
unestablished. Source-supported conditional relations are not native acceptance.
147 stays UNADOPTED,141 rejected,148 unconsumed, H/G unsatisfied. No final cell
is approved, no historical allowance is reset, and no auto followup is scheduled.
