import base64
import datetime
import hashlib
import json
import os
import pathlib
import sys
import tarfile
import time


ROOT = pathlib.Path('/private/tmp/review149-20261108-st0I07Ni')
INPUT = pathlib.Path('/private/tmp/implementation147-20261108-FkC98LCT')
WORKSPACE = pathlib.Path('/Users/tommyvolk/.t3/worktrees/verus/t3-60978068')
PIN = '87c3ca9a5a331d7ce7d654c89e256f9f5ac39b2487dc7be687cc16ea08204c10'
START = datetime.datetime.fromisoformat('2026-11-08T15:34:53-06:00').timestamp()
DEADLINE = START + 18 * 60


def digest(target):
    checksum = hashlib.sha256()
    with target.open('rb') as stream:
        while True:
            block = stream.read(1024 * 1024)
            if not block:
                break
            checksum.update(block)
    return checksum.hexdigest()


def observation(target):
    return {'path': str(target), 'bytes': target.stat().st_size, 'sha256': digest(target)}


def dump(name, data):
    (ROOT / name).write_text(json.dumps(data, indent=2, sort_keys=True) + '\n')


def resources():
    files = [entry for entry in ROOT.rglob('*') if entry.is_file()]
    disk = os.statvfs(ROOT)
    result = {
        'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'elapsed_seconds': time.time() - START,
        'deadline_remaining_seconds': DEADLINE - time.time(),
        'free_bytes': disk.f_bavail * disk.f_frsize,
        'logical_scratch_bytes': sum(entry.stat().st_size for entry in files),
        'allocated_scratch_bytes': sum(entry.stat().st_blocks * 512 for entry in files),
        'compiler_slot_acquired': False,
        'compiler_build_verifier_test_native_executions': 0,
    }
    assert result['free_bytes'] > 16 * 1024**3, result
    assert result['logical_scratch_bytes'] <= 4 * 1024**2, result
    assert result['allocated_scratch_bytes'] <= 4 * 1024**2, result
    assert result['deadline_remaining_seconds'] > 0, result
    return result


def authenticate(phase):
    assert digest(INPUT / 'SEAL.json') == PIN
    seal = json.loads((INPUT / 'SEAL.json').read_text())
    assert len(seal) == 260
    checked_payloads = []
    for item in seal:
        target = INPUT / item['path']
        assert not target.is_symlink()
        assert target.resolve().is_relative_to(INPUT)
        actual = observation(target)
        assert actual['sha256'] == item['sha256'], actual
        assert actual['bytes'] == item['bytes'], actual
        checked_payloads.append(actual)
    candidate = json.loads((INPUT / 'candidate-final.json').read_text())
    assert len(candidate) == 1107
    for item in candidate:
        target = INPUT / 'candidate' / item['path']
        assert not target.is_symlink()
        assert target.resolve().is_relative_to(INPUT / 'candidate')
        assert target.stat().st_size == item['bytes']
        assert digest(target) == item['sha256'], str(target)
    manifest = json.loads((INPUT / 'source-law-manifest147.json').read_text())
    for item in manifest['compiler_sources']:
        assert digest(INPUT / 'candidate' / item['path']) == item['sha256']
    assert digest(INPUT / manifest['law']['path']) == manifest['law']['sha256']
    runtime = json.loads((INPUT / 'pinned-runtime147.json').read_text())
    selection_path = WORKSPACE / 'evidence/redb-native-mir-campaign115/LOCAL-PINNED-LIBRARY128.json'
    selection = json.loads(selection_path.read_text())
    assert selection['release'] == '1.99.1'
    assert selection['commit'] == '58cf8f9c35b355199727627d07ae34a4e2846d67'
    archive = pathlib.Path(selection['archive']['path'])
    assert archive.stat().st_size == selection['archive']['bytes']
    assert digest(archive) == selection['archive']['sha256'] == runtime['archive_sha256']
    runtime_checked = []
    with tarfile.open(archive, 'r:xz') as bundle:
        for item in runtime['expanded_member_correspondence']:
            target = pathlib.Path(item['path'])
            assert target.stat().st_size == item['bytes']
            assert digest(target) == item['sha256']
            member = bundle.extractfile(item['archive_member'])
            assert member is not None
            data = member.read()
            assert len(data) == item['bytes']
            assert hashlib.sha256(data).hexdigest() == item['sha256']
            runtime_checked.append(item)
    library = pathlib.Path(selection['existing_library_root'])
    for item in selection['selected_members']:
        assert digest(library / item['path']) == item['sha256']
    selected_external = []
    selected_terms = (
        'AUTHORIZATION139.md', 'FIRST-CELL139.md', 'LOCAL-PINNED-LIBRARY128.json',
        '/redb-original-crate-preflight115/redb/src/tree_store/page_store/cached_file.rs',
        '/redb-original-crate-preflight115/redb/src/tree_store/page_store/page_manager.rs',
    )
    for item in json.loads((INPUT / 'inputs.json').read_text()):
        if any(term in item['path'] for term in selected_terms):
            target = pathlib.Path(item['path'])
            actual = observation(target)
            assert actual['sha256'] == item['sha256'] and actual['bytes'] == item['bytes']
            selected_external.append(actual)
    selected_external.append(observation(WORKSPACE / 'evidence/redb-native-mir-campaign115/RESOURCE-BOUNDARY135.md'))
    delta = json.loads((INPUT / 'source-delta.json').read_text())
    assert len(delta) == 6
    for item in delta:
        assert digest(INPUT / 'candidate' / item['path']) == item['candidate']['sha256']
    result = {
        'phase': phase,
        'initial_authentication': 'Seal and 260 payloads verified before substantive candidate inspection; 1107 actual candidate files verified before reading Rust source; runtime members verified before reading their source.',
        'seal_sha256': PIN,
        'seal_payload_count': len(seal),
        'seal_payload_bytes': sum(item['bytes'] for item in seal),
        'candidate_file_count': len(candidate),
        'source_delta_count': len(delta),
        'failures': [],
        'selected_external': selected_external,
        'runtime_archive': observation(archive),
        'runtime_members': runtime_checked,
        'compiler_sources': manifest['compiler_sources'],
        'sealed_payloads': checked_payloads,
        'resources': resources(),
        'custody_limit': 'Current entry/exit readback and supplied implementation147 seal only; no backdated acquisition, installed compiler correspondence, or upstream authenticity claim.',
    }
    dump('authentication-' + phase + '149.json', result)
    return result


def receipts():
    commands = json.loads((INPUT / 'commands.json').read_text())
    records = []
    for entry in sorted(INPUT.glob('*.receipt.json')):
        receipt = json.loads(entry.read_text())
        for channel in ('stdout', 'stderr'):
            raw = INPUT / (receipt['name'] + '.' + channel)
            assert raw.stat().st_size == receipt[channel]['bytes']
            assert digest(raw) == receipt[channel]['sha256']
        records.append({
            'number': receipt['number'], 'name': receipt['name'],
            'returncode': receipt['returncode'], 'cause': receipt.get('cause'),
            'source_unchanged_during_command': receipt.get('source_unchanged_during_command'),
            'receipt': observation(entry), 'stdout': receipt['stdout'], 'stderr': receipt['stderr'],
        })
    records.sort(key=lambda item: item['number'])
    assert len(records) == len(commands) == 30
    assert [item['number'] for item in records] == list(range(1, 31))
    final = json.loads((INPUT / 'original147-final.json').read_text())
    assert final['all18'] == 'OPEN' and final['native_bodies_proved'] == 0
    assert final['laws_adopted'] == 0 and final['native_certificate'] is False
    control = INPUT / 'machine147.control-original.rs'
    restoration = json.loads((INPUT / 'source-restoration147.json').read_text())
    assert digest(control) == restoration['original_control_sha256'] == restoration['source_sha256']
    raw_files = [INPUT / 'commands.json', INPUT / 'SETUP-FAILURES.md', INPUT / 'REPAIR148-DISPOSITION.md',
                 INPUT / 'source-restoration147.json', INPUT / 'proof-scope147.json',
                 INPUT / 'validation-summary147.json', INPUT / 'authentication-entry.json',
                 INPUT / 'authentication-exit.json', INPUT / 'RELEASE.json']
    for record in records:
        raw_files.extend(INPUT / (record['name'] + suffix) for suffix in ('.receipt.json', '.stdout', '.stderr'))
    dump('raw-receipts149.json', {
        'encoding': 'base64 of exact bytes, not re-executed output',
        'files': [{**observation(entry), 'base64': base64.b64encode(entry.read_bytes()).decode('ascii')} for entry in raw_files],
    })
    dump('receipt-audit149.json', {
        'scope': 'Read-only receipt/source audit, no execution or rerun of any retained command.',
        'commands': observation(INPUT / 'commands.json'), 'receipts': records,
        'implementation_allowance': {'charged': 30, 'limit': 32, 'reset': False},
        'baseline143_allowance': {'charged': 36, 'limit': 36, 'reset': False},
        'historical_implementation_exit': json.loads((INPUT / 'authentication-exit.json').read_text()),
        'historical_release': json.loads((INPUT / 'RELEASE.json').read_text()),
        'restoration_pre_format': observation(control),
        'final_formatted_machine': observation(INPUT / 'candidate/source/rust_verify/src/native_resource143/machine147.rs'),
        'raw_review_failures': [
            {'returncode': 127, 'failure': 'zsh loop variable named path replaced the special PATH array; cat: command not found twice. Read-only; retried with entry. No substantive selected source read, no allowance reset.'},
            {'returncode': 1, 'failure': 'Initial JSON shape helper assumed candidate-final.json was a dict; AttributeError: list object has no attribute items. Corrected to treat the 1107-entry manifest as a list. Not an authentication success.'},
            {'failure': 'Some terminal displays were truncated. Targeted numbered source slices and bounded summaries were subsequently used; no truncated display was treated as a complete semantic proof.'},
        ],
        'historical_failure_files': [observation(INPUT / name) for name in ['SETUP-FAILURES.md', 'REPAIR148-DISPOSITION.md', 'source-restoration147.json']],
        'review_executions': {'compiler': 0, 'build': 0, 'verifier': 0, 'solver': 0, 'test_binary': 0, 'native_application': 0, 'network': 0, 'git': 0, 'integration': 0, 'subdelegation': 0},
    })


def seal():
    authenticate('exit')
    before = resources()
    dump('RELEASE149.json', {
        'task': 'review149', 'state': 'SEALED_SOURCE_RECEIPT_ONLY_REVIEW_COMPLETE',
        'implementation147': 'UNADOPTED', 'implementation141': 'REJECTED',
        'repair148': 'UNCONSUMED', 'R146_H_G': 'UNSATISFIED', 'all18': 'OPEN',
        'native_acceptance': 0, 'resource_acceptance': 0, 'trust_acceptance': 0, 'proof_acceptance': 0,
        'automatic_followup': False, 'compiler_slot_acquired': False, 'resources': before,
    })
    payloads = []
    for entry in sorted(ROOT.rglob('*')):
        if entry.is_file() and entry.name not in {'SEAL.json', 'SEAL149-READBACK.json'}:
            item = observation(entry)
            item['path'] = str(entry.relative_to(ROOT))
            payloads.append(item)
    dump('SEAL.json', payloads)
    seal_digest = digest(ROOT / 'SEAL.json')
    readback = json.loads((ROOT / 'SEAL.json').read_text())
    for item in readback:
        actual = observation(ROOT / item['path'])
        assert actual['sha256'] == item['sha256'] and actual['bytes'] == item['bytes']
    dump('SEAL149-READBACK.json', {
        'seal_sha256': seal_digest, 'sealed_payloads': len(payloads), 'all_payloads_readback_match': True,
        'input_seal_sha256_exit': digest(INPUT / 'SEAL.json'), 'resources': resources(),
        'self_exclusion': 'SEAL.json and this readback are excluded from their own payload list; seal digest is handed back in the final response.',
    })
    print(json.dumps({'scratch': str(ROOT), 'seal_sha256': seal_digest, 'payloads': len(payloads), 'resources': resources()}, indent=2))


if __name__ == '__main__':
    phase = sys.argv[1]
    if phase == 'entry':
        authenticate('recorded-entry')
        receipts()
        print(json.dumps(resources(), indent=2))
    elif phase == 'seal':
        seal()
    else:
        raise SystemExit('entry or seal required')
