import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import sys
import time

ROOT = Path('/private/tmp/redb-receipt-cancellation118-revision2')
HERE = Path(__file__).resolve().parent
PYTHON = Path('/Library/Developer/CommandLineTools/Library/Frameworks/Python3.framework/Versions/3.9/bin/python3.9')
EXPECTED_MANIFEST = '6ead302a866a8beac0118f65482cf643fa4588d71a75eb7d13b3fc68525f64b7'
EXPECTED_PYTHON = 'bdea59019a38eb6600cc9e71e984a97fedadc406448431281e7657030f54987e'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def guard():
    free = shutil.disk_usage(HERE).free
    assert free > 16 * 1024 ** 3, free
    used = sum(path.stat().st_size for path in HERE.rglob('*') if path.is_file())
    assert used <= 4 * 1024 ** 2, used
    return {'free_bytes': free, 'scratch_file_bytes': used}


def save(name, data):
    (HERE / name).write_text(json.dumps(data, indent=2, sort_keys=True) + '\n')


def authenticate(label):
    start = time.time_ns()
    space = guard()
    assert digest(ROOT / 'MANIFEST.json') == EXPECTED_MANIFEST
    assert PYTHON.resolve() == PYTHON
    assert digest(PYTHON) == EXPECTED_PYTHON
    manifest = json.loads((ROOT / 'MANIFEST.json').read_text())
    assert len(manifest['records']) == 82
    records = []
    for record in manifest['records']:
        relative = Path(record['path'])
        assert not relative.is_absolute() and '..' not in relative.parts
        path = ROOT / relative
        assert stat.S_ISREG(path.lstat().st_mode)
        assert path.resolve() == path
        actual = {'path': str(relative), 'bytes': path.stat().st_size, 'sha256': digest(path)}
        assert actual == record, actual
        records.append(actual)
    actual_paths = sorted(str(path.relative_to(ROOT)) for path in ROOT.rglob('*') if path.is_file())
    expected_paths = sorted([record['path'] for record in records] + ['MANIFEST.json', 'SEAL.json'])
    assert actual_paths == expected_paths
    save('authentication-' + label + '.json', {
        'start_epoch_ns': start, 'end_epoch_ns': time.time_ns(), 'space': space,
        'root': str(ROOT), 'manifest_sha256': EXPECTED_MANIFEST,
        'python': str(PYTHON), 'python_sha256': EXPECTED_PYTHON,
        'records': records, 'payload_count': len(records),
        'total_payload_bytes': sum(record['bytes'] for record in records),
        'exact_file_set': True, 'supplemental_seal_sha256': digest(ROOT / 'SEAL.json'),
    })
    print('AUTHENTICATED', label, len(records), sum(record['bytes'] for record in records), space, flush=True)


def copy_sources():
    records = []
    for relative in ['candidate/source/tools/capture_provenance_receipt.py',
                     'candidate/source/tools/test_capture_provenance_receipt.py',
                     'reviewer_tests.py']:
        source = ROOT / relative
        destination = HERE / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, destination)
        assert digest(source) == digest(destination)
        records.append({'source': str(source), 'copy': str(destination), 'sha256': digest(destination)})
    (HERE / 'tmp').mkdir(exist_ok=True)
    save('copied-sources.json', records)
    print('COPIED', len(records), 'authored Python files', flush=True)


def command(label, argv):
    before = guard()
    environment = {'LANG': 'C', 'LC_ALL': 'C', 'TZ': 'UTC',
                   'PYTHONDONTWRITEBYTECODE': '1', 'TMPDIR': str(HERE / 'tmp')}
    start = time.time_ns()
    monotonic_start = time.monotonic()
    error = None
    with (HERE / (label + '.stdout')).open('wb') as stdout, (HERE / (label + '.stderr')).open('wb') as stderr:
        try:
            result = subprocess.run(argv, cwd=str(HERE), env=environment,
                                    stdout=stdout, stderr=stderr, timeout=40)
            returncode = result.returncode
        except BaseException as caught:
            error = repr(caught)
            returncode = None
    end = time.time_ns()
    record = {'label': label, 'argv': argv, 'cwd': str(HERE), 'environment': environment,
              'start_epoch_ns': start, 'end_epoch_ns': end,
              'seconds': time.monotonic() - monotonic_start, 'timeout_seconds': 40,
              'returncode': returncode, 'error': error, 'space_before': before,
              'space_after': guard(), 'stdout_sha256': digest(HERE / (label + '.stdout')),
              'stderr_sha256': digest(HERE / (label + '.stderr'))}
    save('command-' + label + '.json', record)
    print(json.dumps(record, sort_keys=True), flush=True)
    print((HERE / (label + '.stdout')).read_text(), end='', flush=True)
    print((HERE / (label + '.stderr')).read_text(), end='', flush=True)
    return returncode


def seal():
    authenticate('exit')
    entry = json.loads((HERE / 'authentication-entry.json').read_text())
    exit_record = json.loads((HERE / 'authentication-exit.json').read_text())
    assert entry['records'] == exit_record['records']
    assert entry['supplemental_seal_sha256'] == exit_record['supplemental_seal_sha256']
    copied = json.loads((HERE / 'copied-sources.json').read_text())
    for record in copied:
        assert digest(Path(record['source'])) == record['sha256']
        assert digest(Path(record['copy'])) == record['sha256']
    before = json.loads((ROOT / 'INPUTS-BEFORE-001.json').read_text())
    reconstructed = ROOT / 'attempt-001-tested-source-reconstructed'
    for record in before['files']:
        path = reconstructed / record['path']
        assert path.stat().st_size == record['bytes']
        assert digest(path) == record['sha256']
    bindings = {}
    for label, script in [('author', 'candidate/source/tools/test_capture_provenance_receipt.py'),
                          ('historical-reviewer', 'reviewer_tests.py'),
                          ('targeted', 'targeted-tests-attempt001.py'),
                          ('targeted-002', 'targeted_tests.py')]:
        record = json.loads((HERE / ('command-' + label + '.json')).read_text())
        assert digest(HERE / (label + '.stdout')) == record['stdout_sha256']
        assert digest(HERE / (label + '.stderr')) == record['stderr_sha256']
        bindings[label] = {'retained_script': script, 'script_sha256': digest(HERE / script),
                           'returncode': record['returncode'], 'seconds': record['seconds']}
    save('final-bindings.json', {'input_unchanged': True, 'copied_sources_unchanged': True,
                                'reconstructed_attempt001_matches_five_recorded_hashes': True,
                                'attempt001_is_not_a_prerun_snapshot': True,
                                'test_bindings': bindings, 'space': guard()})
    records = [{'path': str(path.relative_to(HERE)), 'bytes': path.stat().st_size, 'sha256': digest(path)}
               for path in sorted(HERE.rglob('*')) if path.is_file()
               and path.name not in ('EVIDENCE-MANIFEST.json', 'EVIDENCE-SEAL.json')]
    save('EVIDENCE-MANIFEST.json', {'records': records, 'utc': datetime.datetime.now(datetime.timezone.utc).isoformat()})
    save('EVIDENCE-SEAL.json', {'manifest_sha256': digest(HERE / 'EVIDENCE-MANIFEST.json'),
                              'payload_count': len(records), 'space': guard(),
                              'input_manifest_sha256': EXPECTED_MANIFEST})
    print((HERE / 'EVIDENCE-SEAL.json').read_text(), end='', flush=True)


if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'entry':
        authenticate('entry')
        copy_sources()
    elif action == 'test':
        label = sys.argv[2]
        script = {'author': 'candidate/source/tools/test_capture_provenance_receipt.py',
                  'historical-reviewer': 'reviewer_tests.py',
                  'targeted': 'targeted_tests.py',
                  'targeted-002': 'targeted_tests.py'}[label]
        sys.exit(command(label, [str(PYTHON), '-B', str(HERE / script)]))
    elif action == 'seal':
        seal()
