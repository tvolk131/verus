# Independent review: cancellation118 revision2

## Disposition and scope

No blocking or high/medium-severity source finding was identified in the
requested F1/F2/F3 correction on this pinned macOS/POSIX Python3.9 execution.
The earlier three source findings are addressed within the explicitly narrow
standard-main-thread-SIGINT, sole-owned-direct-child boundary. This is a source
review and authored-Python recheck, not production-readiness, integration,
native/resource/trust approval, or a discharge of the original blocking reviews.
All18 redb cells remain OPEN; native/resource/trust/final-cell credit is 0.

Input: `/private/tmp/redb-receipt-cancellation118-revision2`.
Pinned MANIFEST.json SHA256:
`6ead302a866a8beac0118f65482cf643fa4588d71a75eb7d13b3fc68525f64b7`.
All 82 payloads (395397 bytes) were size/SHA256 checked before copying/testing
and again at exit. The exact regular-file set is those 82 payloads plus the
manifest and supplemental SEAL.json; that seal is independently bound and
compared entry/exit. The three copied authored Python source/test files also
remain byte-identical to their authenticated inputs. No retained observation,
input, original107/118 artifact, or repository file was written by this review.
Original107/118 were not separately reauthenticated here: the parent preservation
record is evidence read, not an independent transitive-custody assertion.

## Required source checks

- F1: `candidate/source/tools/capture_provenance_receipt.py:28` installs a
  recording SIGINT handler before Popen; `:276` keeps handle assignment and
  started publication inside that guard. A real self-SIGINT after actual OS
  launch but before the wrapper returns is deferred, then cancellation reaps
  the owned direct child and refuses success. No guarantee is claimed for an
  arbitrary injected exception inside Popen before handle ownership.
- Wait publication: `:47` requests positive wait slices no greater than 0.1s
  under the same guard. Actual self-SIGINT injected immediately after the
  private POSIX `_try_wait` OS reap, while returncode is still None, is deferred
  until returncode publication. This test specifically relies on pinned
  Python3.9 internals; it is not a broad portability or scheduler-latency claim.
- F2: `:295` signals the numeric group only if the direct child is unreaped
  (`returncode is None`). Already-published zero returncode, including the
  actual reap-publication test and synthetic SystemExit path, produces no
  killpg call. A still-unreaped direct child retains ownership of its PID/group
  identifier under this sole-reaper boundary. No detached-descendant containment
  or concurrently stolen wait status is attested.
- F3: `:348` preserves the caught original KeyboardInterrupt/SystemExit object
  and code when receipt opening/writing raises ENOSPC, chaining that write
  failure as the cause. Independent partial-write tests also preserve both
  interruption kinds after owned-handle publication and cleanup. A partial
  receipt file can remain; it is not a complete successful receipt.
- Handler/thread refusal is honest: nonstandard actual handler is left intact
  and launch refused; author tests cover signal installation failure and a
  real non-main Python thread. Standard handler restoration is checked.
- Unknown cleanup status cannot qualify as success: `:344` requires started,
  completed, reaped, exit_code==0, no timeout/cancellation/errors. Independent
  synthetic None-status cleanup refuses success. Cleanup signaling permission
  failure and cancellation with eventual zero exit remain fail-closed in the
  author tests. No new owned-child/group safety regression was found in scope.

## Executed commands and raw evidence

Resolved interpreter, authenticated entry/exit:
`/Library/Developer/CommandLineTools/Library/Frameworks/Python3.framework/Versions/3.9/bin/python3.9`
SHA256 `bdea59019a38eb6600cc9e71e984a97fedadc406448431281e7657030f54987e`.

Every test command is `[pinned_python, '-B', absolute_script]`, cwd this new
reviewer directory, timeout 40s, with the complete child environment exactly:
`LANG=C`, `LC_ALL=C`, `TZ=UTC`, `PYTHONDONTWRITEBYTECODE=1`,
`TMPDIR=/private/tmp/redb-c118-r2-review.i2hgTJ/tmp`.
The suite-under-test deliberately supplies its own three-variable command
environment, as tested; authored children are Python-only safe fixtures.
No compiler, build, solver, native redb, network, Git, integration, or trust
operation was executed. Synthetic numeric PIDs are always behind mocked group
signaling; real signals target only this test's process or actually owned group.

| Command record | Result | Wall seconds |
| --- | --- | ---: |
| command-author.json | 48/48 pass, exit 0 | 3.279655 |
| command-historical-reviewer.json | 13/13 pass, exit 0 | 1.366974 |
| command-targeted.json | 6/7 pass, exit 1 (reviewer fixture error) | 0.316253 |
| command-targeted-002.json | 7/7 pass, exit 0 (corrected reviewer fixture) | 0.323754 |

The four command JSONs contain exact argv/cwd/environment, epoch-nanosecond
start/end, monotonic duration, status, before/after free space, raw stdout/stderr
digests. Matching `.stdout`/`.stderr` files are complete, including the failed
check. The failed targeted source was preserved after execution, before edits,
as targeted-tests-attempt001.py; it is not claimed as a pre-run hash snapshot.
The candidate and two requested suites were copied and hash-bound before runs.
Final-bindings.json binds the retained sources and verifies raw-output digests.

The independent seven checks cover actual launch and private OS-reap SIGINT
windows, bounded requested wait slices, actual custom-handler refusal,
already-reaped SystemExit/no group signal, unknown cleanup status, and partial
ENOSPC persistence for both interruption types. The observed actual historical
interruption has success=false, exit_code=-9, timed_out=false, and
child_alive_after_capture=false. No synthetic ENOSPC is actual disk exhaustion.

## Findings, objections, and failed attempts

- Source findings: none blocking in the scoped correction; no production or
  integration acceptance follows from that result.
- LOW, evidence limitation E1: initial read-only bootstrap commands preceded
  independent raw-file logging. Their exact tool calls and available outputs
  remain in the review transcript, but two large combined outputs were
  tool-truncated; complete raw bootstrap stdout, inherited shell environment,
  and individual setup start/end times were not independently captured.
  Consequently this evidence does NOT claim a complete all-setup raw transcript.
  Test-command raw capture is complete. This is a qualification to evidence
  completeness, not an observed candidate safety defect.
- Reviewer failures are retained in setup-failures.txt: unavailable absolute
  /usr/bin/rg (exit127); exact-file-set assertion initially omitted supplemental
  SEAL.json (exit1); one targeted fixture incorrectly seeded its output and
  correctly failed preflight, causing a reviewer mock-call assertion failure;
  and a correction patch partially applied before a bookkeeping-context mismatch.
  The fixture was corrected, not the candidate. No test attempt is hidden.
- The parent's distinct substring-classification reconstruction failure remains
  recorded in immutable parent REPORT.md. The earlier 47/13 source is explicitly
  a post-run reconstruction, not a pre-run snapshot. All five reconstructed
  files are independently compared to the parent's recorded pre-run size/hash
  entries at seal time; this still does not authenticate historical custody or
  re-execute the earlier version. The final copied version rechecks 48/13.

## Retention boundaries

Each shell command checks free disk strictly above 16GiB before proceeding;
the authored runner repeats the check before each test and authentication.
Measured test free space stayed above 37.4 billion bytes, not disk exhaustion.
Fresh reviewer scratch stays below 4MiB (final bytes in the seal; observed
allocated scratch was 304KiB before reporting). Each test command completed
well below 45s; first bootstrap UTC was 2026-11-08T17:25:23Z, with the final seal
UTC in EVIDENCE-MANIFEST.json, within the requested 12-minute review/handoff.
No subdelegation, followup review, integration, commit, or old-input edit occurs.

Selected-input endpoint receipts do not establish transitive interpreter/stdlib
or platform custody, compiler-source correspondence, trusted producers,
native/resource semantics, proof acceptance, or descendant containment.
Repeated interruption/process termination can prevent a complete receipt.
The sealed directory is small retention evidence, not independent authority to
close any redb cell. Existing blocking reviews and OPEN status are unchanged.
