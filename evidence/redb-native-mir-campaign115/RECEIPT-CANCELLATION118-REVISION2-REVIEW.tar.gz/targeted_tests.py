import errno
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import unittest
from unittest import mock

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'candidate/source/tools'))
import capture_provenance_receipt as provenance
from test_capture_provenance_receipt import ProvenanceReceiptTests


class IndependentBoundaryTests(ProvenanceReceiptTests):
    def test_guarded_wait_slices_are_bounded_and_restore_handler(self):
        process = mock.Mock(args=['synthetic-only'], returncode=None)
        timeouts = []

        def wait(timeout):
            timeouts.append(timeout)
            self.assertGreater(timeout, 0)
            self.assertLessEqual(timeout, 0.1)
            self.assertNotEqual(signal.getsignal(signal.SIGINT), signal.default_int_handler)
            if len(timeouts) < 4:
                raise subprocess.TimeoutExpired(process.args, timeout)
            process.returncode = 0
            return 0

        process.wait.side_effect = wait
        self.assertEqual(provenance.wait_for_owned_process(process, 1), 0)
        self.assertEqual(len(timeouts), 4)
        self.assertEqual(signal.getsignal(signal.SIGINT), signal.default_int_handler)

    @unittest.skipUnless(os.name == 'posix', 'pinned Python POSIX fixture')
    def test_actual_launch_interrupt_preserves_owned_handle(self):
        original = provenance.subprocess.Popen
        children = []

        def spawn(*arguments, **keywords):
            child = original(*arguments, **keywords)
            children.append(child)
            self.assertTrue(keywords['start_new_session'])
            self.assertNotEqual(signal.getsignal(signal.SIGINT), signal.default_int_handler)
            signal.raise_signal(signal.SIGINT)
            self.assertIsNone(child.returncode)
            return child

        self.plan['argv'][-1] += '; import time; time.sleep(1)'
        with mock.patch.object(provenance.subprocess, 'Popen', side_effect=spawn):
            with self.assertRaises(KeyboardInterrupt):
                provenance.capture(self.plan, self.output)
        self.assertEqual(len(children), 1)
        self.assertIsNotNone(children[0].returncode)
        receipt = json.loads((self.output / 'receipt.json').read_text())
        self.assertTrue(receipt['command']['started'])
        self.assertTrue(receipt['command']['reaped'])
        self.assertTrue(receipt['command']['cancelled'])
        self.assertFalse(receipt['success'])

    @unittest.skipUnless(os.name == 'posix', 'private _try_wait in pinned Python3.9 only')
    def test_actual_reap_interrupt_occurs_before_status_publication(self):
        original = provenance.subprocess.Popen
        events = []

        def spawn(*arguments, **keywords):
            child = original(*arguments, **keywords)
            original_wait = child._try_wait

            def try_wait(flags):
                result = original_wait(flags)
                if result[0] == child.pid:
                    events.append({'returncode_before_publication': child.returncode})
                    self.assertIsNone(child.returncode)
                    self.assertNotEqual(signal.getsignal(signal.SIGINT), signal.default_int_handler)
                    signal.raise_signal(signal.SIGINT)
                return result

            child._try_wait = try_wait
            return child

        with mock.patch.object(provenance.subprocess, 'Popen', side_effect=spawn):
            with mock.patch.object(provenance.os, 'killpg') as kill_group:
                with self.assertRaises(KeyboardInterrupt):
                    provenance.capture(self.plan, self.output)
        kill_group.assert_not_called()
        self.assertEqual(events, [{'returncode_before_publication': None}])
        receipt = json.loads((self.output / 'receipt.json').read_text())
        self.assertEqual(receipt['command']['exit_code'], 0)
        self.assertTrue(receipt['command']['cancelled'])
        self.assertTrue(receipt['command']['reaped'])
        self.assertFalse(receipt['command']['completed'])
        self.assertFalse(receipt['success'])

    def test_unknown_cleanup_status_never_successes(self):
        process = mock.Mock(pid=2147483000, returncode=None, args=['synthetic-only'])
        process.wait.return_value = None

        def spawn(*arguments, **keywords):
            self.artifact.write_bytes(b'synthetic artifact')
            return process

        with mock.patch.object(provenance.subprocess, 'Popen', side_effect=spawn):
            with mock.patch.object(provenance.os, 'killpg') as kill_group:
                receipt = provenance.capture(self.plan, self.output)
        kill_group.assert_called_once_with(process.pid, signal.SIGKILL)
        self.assertTrue(receipt['command']['started'])
        self.assertIsNone(receipt['command']['exit_code'])
        self.assertFalse(receipt['success'])

    def test_already_reaped_system_exit_never_signals_historical_group(self):
        interruption = SystemExit(29)
        process = mock.Mock(pid=2147483000, returncode=0, args=['synthetic-only'])
        process.wait.side_effect = [interruption, 0]
        with mock.patch.object(provenance.subprocess, 'Popen', return_value=process):
            with mock.patch.object(provenance.os, 'killpg') as kill_group:
                with self.assertRaises(SystemExit) as raised:
                    provenance.capture(self.plan, self.output)
        kill_group.assert_not_called()
        self.assertIs(raised.exception, interruption)
        self.assertEqual(raised.exception.code, 29)
        receipt = json.loads((self.output / 'receipt.json').read_text())
        self.assertFalse(receipt['success'])
        self.assertTrue(receipt['command']['reaped'])
        self.assertTrue(receipt['command']['cancelled'])

    def test_partial_persistence_enospc_preserves_original_both_kinds(self):
        for interruption in [KeyboardInterrupt('independent original'), SystemExit(31)]:
            with self.subTest(kind=type(interruption).__name__):
                self.output = self.root / ('partial-' + type(interruption).__name__)
                process = mock.Mock(pid=2147483000, returncode=0, args=['synthetic-only'])
                process.wait.side_effect = [interruption, 0]

                def fail_dump(value, stream, **keywords):
                    stream.write('{"partial":')
                    raise OSError(errno.ENOSPC, 'synthetic partial-write failure, not actual disk exhaustion')

                with mock.patch.object(provenance.subprocess, 'Popen', return_value=process):
                    with mock.patch.object(provenance.os, 'killpg') as kill_group:
                        with mock.patch.object(provenance.json, 'dump', side_effect=fail_dump):
                            with self.assertRaises(type(interruption)) as raised:
                                provenance.capture(self.plan, self.output)
                kill_group.assert_not_called()
                self.assertIs(raised.exception, interruption)
                self.assertEqual(raised.exception.__cause__.errno, errno.ENOSPC)
                self.assertEqual((self.output / 'receipt.json').read_text(), '{"partial":')
                if isinstance(interruption, SystemExit):
                    self.assertEqual(raised.exception.code, 31)

    def test_actual_custom_handler_is_preserved_and_refuses_launch(self):
        def custom_handler(number, frame):
            raise AssertionError('never signaled')

        previous = signal.signal(signal.SIGINT, custom_handler)
        try:
            with mock.patch.object(provenance.subprocess, 'Popen') as spawn:
                receipt = provenance.capture(self.plan, self.output)
            spawn.assert_not_called()
            self.assertIs(signal.getsignal(signal.SIGINT), custom_handler)
            self.assertFalse(receipt['success'])
            self.assertFalse(receipt['command']['started'])
        finally:
            signal.signal(signal.SIGINT, previous)


if __name__ == '__main__':
    names = sorted(name for name in IndependentBoundaryTests.__dict__ if name.startswith('test_'))
    suite = unittest.TestSuite(IndependentBoundaryTests(name) for name in names)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    raise SystemExit(not result.wasSuccessful())
