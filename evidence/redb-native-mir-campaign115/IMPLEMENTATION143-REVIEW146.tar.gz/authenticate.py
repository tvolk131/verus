import datetime
import hashlib
import json
import os
import pathlib
import shutil
import sys

SCRATCH = pathlib.Path(__file__).parent
IMPL = pathlib.Path('/private/tmp/implementation143-20261108-LpJjrIbt')
BASE = pathlib.Path('/private/tmp/implementation140-20261108-RdrUQDUb')
REVIEW = pathlib.Path('/private/tmp/review144-20261108-zvUvswJB')
AUTH = pathlib.Path('/Users/tommyvolk/.t3/worktrees/verus/t3-60978068/evidence/redb-native-mir-campaign115/AUTHORIZATION139.md')
PINNED = {'SEAL.json': '1147ecfc3fb5f12b94ba7eac4e824b8fe8a1777dafe69754975749eeab9b9360', 'candidate-final.json': '8a8a2134a7691b290f01989ef4a0777c2aa2ec3bd2a9d4c32919bcac32c6adc4'}

def digest(path):
    hasher = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            hasher.update(chunk)
    return hasher.hexdigest()

def check(root, records):
    output = []
    for record in records:
        path = root / record['path']
        if not path.resolve().is_relative_to(root.resolve()):
            raise RuntimeError('path escape: ' + str(path))
        actual = digest(path)
        size = path.stat().st_size
        output.append({'path': str(path), 'bytes': size, 'sha256': actual, 'matches': actual == record['sha256'] and size == record['bytes']})
    return output

phase = sys.argv[1]
free = shutil.disk_usage(SCRATCH).free
if free <= 16 * 1024**3:
    raise RuntimeError('free disk not strictly above 16GiB')
rows = []
for name, expected in PINNED.items():
    actual = digest(IMPL / name)
    rows.append({'path': str(IMPL / name), 'bytes': (IMPL / name).stat().st_size, 'sha256': actual, 'matches': actual == expected})
if not all(row['matches'] for row in rows):
    raise RuntimeError('pinned manifest mismatch')
groups = {'implementation143_payload': check(IMPL, json.loads((IMPL / 'SEAL.json').read_text())), 'implementation143_sources': check(IMPL / 'candidate', json.loads((IMPL / 'candidate-final.json').read_text())), 'baseline140_payload': check(BASE, json.loads((BASE / 'SEAL.json').read_text())), 'review144_payload': check(REVIEW, json.loads((REVIEW / 'SEAL.json').read_text())['files'])}
authority = {'path': str(AUTH), 'bytes': AUTH.stat().st_size, 'sha256': digest(AUTH), 'authentication': 'endpoint hash only; no externally supplied digest'}
for root in [BASE, REVIEW]:
    rows.append({'path': str(root / 'SEAL.json'), 'bytes': (root / 'SEAL.json').stat().st_size, 'sha256': digest(root / 'SEAL.json'), 'matches': True, 'authentication': 'locally self-consistent; not user-pinned'})
result = {'review': 146, 'phase': phase, 'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'free_bytes': free, 'pinned_and_selected': rows, 'authority': authority, 'groups': groups, 'counts': {name: len(records) for name, records in groups.items()}, 'all_match': all(row['matches'] for row in rows) and all(row['matches'] for records in groups.values() for row in records), 'scope': 'current endpoint file custody only; not historical continuous custody, target binaries, or resource proof'}
if phase == 'exit':
    entry = json.loads((SCRATCH / 'authentication-entry.json').read_text())
    result['same_as_entry'] = result['groups'] == entry['groups'] and result['pinned_and_selected'] == entry['pinned_and_selected'] and result['authority'] == entry['authority']
(SCRATCH / ('authentication-' + phase + '.json')).write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: value for key, value in result.items() if key != 'groups'}, indent=2))
if not result['all_match'] or not result.get('same_as_entry', True):
    raise RuntimeError('authentication failed')
