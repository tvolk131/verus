# Independent review146 of sealed implementation143

## Narrow disposition

**RETAIN UNADOPTED / native export REFUSED.** Two P2 source-correctness findings
remain below. Neither is a reproduced accepted native proof or a P1 admission
exploit: the driver unconditionally emits an error and stops. Recognize a
source/typed-constraint increment, not source acceptance, native acceptance,
primitive-law adoption, durability proof, or closure of any campaign cell.
Source/native/trust/proof acceptance credit: **0/0/0/0**. All **18 OPEN**.

The target under AUTHORIZATION139.md remains original two-phase acknowledged
durability: native page -> buffer -> flush -> public acknowledgement -> recovery.
Neither typed provenance nor this review supplies that connection. This is a new
independent review146, not a reset/rerun of143, and starts no review chain.

## Authentication, custody, and bounds

Fresh scratch only: `/private/tmp/review146-20261108-PNPfRNC4`.
Start 2026-11-08T20:56:02Z; hard deadline 21:12:02Z, including seal/readback.
Maximum fresh scratch 3 MiB; free disk must remain strictly above16 GiB.
No compiler/build/test/verifier/native application execution, network, Git,
integration, parent edits, subdelegation, slot acquisition, or target execution.
Only review-authored Python file hashing/receipt inspection and source reads ran.

Before substantive inspection, both user-pinned implementation143 digests matched:

- `SEAL.json`: `1147ecfc3fb5f12b94ba7eac4e824b8fe8a1777dafe69754975749eeab9b9360`.
- `candidate-final.json`: `8a8a2134a7691b290f01989ef4a0777c2aa2ec3bd2a9d4c32919bcac32c6adc4`.

All411 listed sealed payloads and1104 actual candidate source files were hashed
against those manifests. All201 baseline140 payloads and13 review144 payloads
also matched their local seals. The baseline/review seal roots were initially
self-consistency checks, not independently user-pinned roots; the143 sealed
README/input records subsequently cross-reference the same roots. Before reading
baseline sources, all1100 baseline candidate files were additionally hashed.
The authority file was hashed before reading; its endpoint digest is
`a43edb91db46e203fc82bcc70555fc46371b1db09848085cd43324ed77386317`, also recorded
in143's sealed inputs. Entry/exit and selected-hash records are separate artifacts.

These are **current endpoint custody** checks. They do not establish historical
continuous custody, authenticate every historical executable/driver version, or
independently prove that a recorded process obeyed its bounds. No current target
binary, dependent rlib/dylib, toolchain binary, or actual original-source tree
outside the selected sealed copies was authenticated here. **Full target
authentication is not claimed.** No optional145 implementation artifact was read
or consumed by this review.143's own planning handoff references do not mean its
compiler consumed145's patch or helper tests.

`discovery.txt` retains the permission-denied discovery and both read-only Python
schema errors, including exact traceback text. Long terminal display truncations
are disclosed; focused source slices/field-selected receipt extraction supply
the actual review evidence. No error caused a compiler retry or allowance reset.

## Source anchor convention

All candidate anchors below are relative to the authenticated root
`/private/tmp/implementation143-20261108-LpJjrIbt/candidate/`.
`L` means `source/rust_verify/src/native_resource143/ledger.rs`;
`N` means `source/rust_verify/src/native_resource143.rs`;
`O` means `source/rustc_mir_build/src/builder/native_resource_origins.rs`.
Each numbered anchor names an exact source line, not a JSON identity certificate.

## Severity-ranked findings

### R146-1 — P2: destructive value kills do not retire the loan-to-place lookup

Primary: `source/rust_verify/src/native_resource143/ledger.rs:494`.
Related: `L:468`, `L:478`, `L:527`, `L:727`, `L:782`, `L:791`, `L:833`,
`L:841`, `L:854`, `L:909`, `L:356`, `L:605`.

`kill(destination)` correctly removes overlapping entries from `values` and
`slots`, but does not invalidate or version `loans[*].returned`. `transfer` moves
only values/slots. The `root` resolver later identifies an ancestor by the
syntactic equation `loan.returned.deref == place`, without checking that this is
still the value occupying that reference place. Storage reuse and unknown
statements likewise leave these loan-to-place identities in the loan table.
NLL removal at the loan's eventual endpoint does not repair intervening reuse.

Static adversarial transfer trace, **not compiled/executed and not observed in
the seven retained originals**: create `r = &mut page_a` (loan a), move r into
saved_r, then overwrite r with a distinct incoming `&mut page_b`. Keep saved_r
live by using it later. Reborrow `*r` for a fresh activated mem_mut receiver loan.
The caller now refers to page_b, while `root(*r)` can still follow loan a's old
`returned == r` to page_a. The fresh immediate receiver loan can pass the actual
reserve/activation checks; those checks do not validate the historical value
occupying r in the root chain. The actual loan must remain outstanding for
saved_r, but its old reference-holder location must no longer identify page_a.

Objection/counterargument: simply deleting every outstanding loan on a move or
overwrite would itself be wrong; Rust permits reference movement and the loan
may remain live through its new holder. Also the exact current-copy checks and
unconditional export refusal are substantial safeguards. **Accepted**: this
finding is not a demonstrated native acceptance or a proof that the retained
header takes this trace. It is the narrower source defect that the root-chain
relation is not stable under the supported transfer operations. Full Place
keys fix the old local-only map, not value incarnation or cross-local aliasing.

Small correction: distinguish loan identity from its current reference holders;
move/overwrite/storage transfers must update or invalidate holder edges (or
fail closed where unsupported), while retaining outstanding loan obligations.
Make root-chain validation consume those live, epoch-aware edges. Unknown calls
need explicit alias/effect obligations, not reuse of an old holder edge.

### R146-2 — P2: individually unique bindings are not a globally injective occurrence map

Primary: `source/rust_verify/src/native_resource143.rs:642`.
Related: `N:184`, `N:218`, `N:226`, `N:241`, `N:272`, `N:631`, `N:635`,
`N:645`, `O:70`, `O:78`.

`bind` checks one builder origin for each MIR call and one occurrence of that
retained Expr Arc in the VIR body. It never rejects two distinct MIR locations
binding to the same retained `(owner,HirId)` Expr. The builder can record a fresh
SourceScope for each construction without enforcing unique HirId/THIR reuse.
`lower_original_proof` then uses `.find` by Arc identity: only the first matching
MIR occurrence's before/after bundle is placed at that VIR expression. Its
unbound-location check merely asks whether each location has any anchor, so it
does not detect that another anchor aliases the same Expr and loses its bundle.

This is a source-level many-to-one case, not a source program reproduced here.
Duplicated lowering of a source occurrence must either receive an explicit
path/multiplicity mapping or be refused; it is not ruled out by the independent
per-call checks. Retained original-final bindings contain **no duplicate bound
HirId within an owner**, so the recorded19 accepted anchors do not themselves
demonstrate lost obligations. The defect is failure to enforce the promised
uniqueness when the case occurs, not a claim that it occurred in these receipts.

Objection/counterargument: ordinary frontend provenance and exact Arc membership
are much stronger than span/JSON matching, and the current corpus has no observed
duplicate. **Accepted**, but neither fact makes the mapping injective. Structural
erasure can still succeed after a proof bundle is omitted: erasure checks the
executable expression, not coverage of every intended MIR obligation. Export
remains refused, limiting present impact to the partial lowerer's correctness.

Small correction: before rewriting, enforce uniqueness of `(MIR location, owner,
HirId, retained Expr)` in both directions for this supported subset. Refuse
many-to-one mappings until path-aware duplication is represented. Track each
required bundle as consumed exactly once; do not rely on `.find` plus erasure.

## Required review dimensions and objections

### 1. Actual typed owner/call/type/Instance binding and erasure

The builder inserts origin SourceScope at the actual MIR Call construction,
`source/rustc_mir_build/src/builder/expr/into.rs:573`; executable Call operands,
destination, normal target and unwind remain in the original construction.
`O:42` searches actual THIR scopes through supported adjustment wrappers and
requires one HIR candidate; ambiguity is not converted into a guessed identity.
`source/rust_verify/src/rust_to_vir_expr.rs:578` and
`source/rust_verify/src/rust_to_vir_expr.rs:614` retain actual frontend Exprs by
owner/HirId. `source/rust_verify/src/rust_to_vir_func.rs:380` exposes the real
body_to_vir used at `N:122`.

`N:165` checks builder scope, HIR call kind, rustc-resolved HIR/MIR Instance
agreement (regions erased), exact retained Arc membership count, VIR static or
resolved target path, disallowed assume_external flag, and destination VIR type.
This is real in-memory binding, not use of a serialized DefId/local/span/hash as
authority. Caveat: the VIR Call target's type-argument/impl-evidence vectors and
argument-by-argument MIR/VIR place correspondence are not separately compared
at `N:244`; only target path and return type are checked there. Do not upgrade
this into full generic-instance/argument semantic equivalence or runtime law
binding. The ordinary translator remains part of the trusted compiler path.

`N:703` erases the inserted wrappers; `N:731` compares serialized full restored
VIR against the original body. This supports syntactic executable preservation
for the actual retained expressions, not full WF, correct resource semantics,
correct proof placement, or global occurrence coverage (R146-2).

Retained six translated owners have bound/unbound call counts: drop2/4,
return_value3/2, take_value3/0, mem_mut2/0, get_mut2/0, write_header7/4.
The seventh original write body does not translate. **Six translated bodies are
not six checked native bodies.**

### 2. Destructive transfers, projections, calls, branches, and aliases

`L:455` compares full Places with conservative prefix/projection overlap within
one local; differing fields are disjoint, differing locals are always treated
as nonoverlapping. `L:527` reads the source, consumes moves, and kills destination
even if source provenance is absent. Unknown rvalues visit all moved operands
then kill destination (`L:771`); storage live/dead kills the whole local (`L:782`);
unknown statements clear pending value/slot maps (`L:785`). Every call consumes
moved arguments/callee and kills its destination in both normal/cleanup states
(`L:833`). These are genuine equivalents of R144-1's immediate value-map fix.

They are not a complete destructive affine resource semantics. Reference-holder
loan edges survive (R146-1); different-local aliases are not canonicalized by
`overlaps`; unknown callee writes through aliases are not a checked havoc/frame
transfer. Current OriginalCall/Unsupported debts prevent treating those facts as
successful preservation. Reject this boundary rather than assume inert callees.

`L:652` clones a separate state per path, including normal/cleanup call outcomes;
`L:1057` explores every SwitchInt successor, avoiding an unsound map-union join.
No branch condition/path fact is carried into Requirement, and all requirements
are flattened. Option Some checks verify nominal type/projection at `L:417`,
not a proved discriminant or successful checkout. No complete relational join,
loop invariant, multi-resource ownership or alias proof is implemented; loops
and the2048 explored-node bound fail closed (`L:660`). Path/occurrence counters
must not be read as distinct checked source statements or feasible executions.

### 3. NLL ends before statements AND terminators/cleanup

`L:664` iterates inclusively through `statements.len()`, calls `apply_ends`
before each location, and only then breaks for terminator dispatch. `L:582`
uses actual rustc NLL endpoints; it emits LoanEndWriteback with receiver, assigned
place, effect, cleanup bit; propagates a child's mutation effect toward its
native parent; and removes expired pending origins. `L:207` rechecks endpoints.

The authenticated original-final record actually includes return_value bw2 at
**bb4[0]**, and header bw1/bw2/bw3 at **bb24[0]** on cleanup paths, including the
copy's UnwindPrefix effect. Multiple entries reflect distinct explored paths,
not duplicate resources established by proof. Missing-terminator fault injection
returns `NRE143_DROP_WITH_OUTSTANDING_RETURNED_LOAN bb24[0]`.

Thus the concrete R144-2 scheduling omission is corrected **in143's new typed
ledger**. Cleanup VIR writeback placement is still explicitly OPEN (`N:621`);
ordinary normal placement only handles the immediate successor case (`N:615`).
Endpoint printing/removal is not receiver-resumption or byte-writeback proof.
UnchangedByThisLoan is not an empty ownership frame or no mutation by all actors.

### 4. Pending checkout/get_mut/unwrap/reborrow/return/writeback

`L:843` connects original WritablePage::mem_mut to an active receiver loan;
`L:893` identifies actual diagnostic Arc<[u8]>::get_mut and records pending
outcomes; `L:928` recognizes nominal Option::unwrap; `L:700` follows supported
exact reborrows; `L:1027` transfers the ArcSlice return _0 with its root chain.
The sealed original source is `redb-source-control/src/tree_store/page_store/cached_file.rs:35`:
`Arc::get_mut(&mut self.data).unwrap()`. Root-chain/outlives validation is at
`L:337`, with the holder-incarnation objection R146-1 still applicable generally.

The header copy at `redb-source-control/src/tree_store/page_store/page_manager.rs:1623`
is connected through its returned slice to an active exact projected loan
(`L:951`, `L:981`, `L:984`). NormalCopy and UnwindPrefix differ (`L:990`).
`L:882` retains LRU getter/cache/key; nominal Some projection, unwrap and reborrow
carry its pending slot into actual take/replace (`L:1007`). Both retained
CacheReservation records include Some(CacheSlot) with exact getter/cache/key;
replace also retains the exact moved value argument. These records are not
successful None reservation, no-other-owner evidence, Arc uniqueness, or cache
ownership across unlock. Constructor and callbacks/hasher/LRU behavior remain
caller obligations, not primitive laws.

At explicit Return/UnwindResume/UnwindTerminate, ExitFrame remains an error even
when pending maps are empty (`L:275`, `L:1028`). Additional coverage objection:
Call processing enqueues only a normal target and an explicit cleanup target
(`L:1014`); Continue/Terminate/Unreachable unwind actions or targetless/diverging
calls do not receive a corresponding terminal resource frame there. `L:1082`
also produces no frame for Unreachable. Do not infer complete panic/abort/
divergence accounting from visiting every existing MIR location. OriginalCall
debts and unconditional refusal keep this a disclosed OPEN boundary, not proof
of primitive totality or legal runtime executions.

### 5. Closed false debts, local typing, and vacuity

`N:530` constructs closed `assert false` leaves, explicitly **not assumptions**;
the local check only confirms bool predicate/unit assertion shape. The retained
assertion counts are2,3,3,2,2,11 for the six translated owners, total23. They are
missing-authority debts, not23 established facts or executable byte semantics.

`N:573` collects validation Results into output instead of requiring all Ok.
Across these six owners, the actual196 requirement validations include86 Ok and
**110 Err**, chiefly explicit unsupported effects/exit-frame debts. Consequently
an `Ok(original_body_proof_lowering)` is not all-constraint acceptance. The23
closed leaves do not encode a byte vector, linear resource algebra, constructor
authority, map reservation law, or legal-execution certificate. A later pass must
not delete/assume/skip them or discharge an unreachable tail after false while
forgetting the false obligation itself. No such solver execution occurred here.

Full original function/dependency declaration WF, modes, SST, AIR and SMT were
**not run** by143's stated final path or this review. Full ABI/nominal declaration
environment and primitive dispositions remain missing. A successful compiler
build or diagnostic JSON is not resource proof. Driver refusal at `N:870` remains
unconditional; feature-required binary gating is at
`source/rust_verify/Cargo.toml:42`. No new admission/import/export/Infer/S0 gate
weakening is present in the11-file baseline-relative delta.

## Equivalent R144 repairs, not changes to140 or145

All1104 final143 sources match their manifest; comparing authenticated140/143
manifests gives exactly the11 paths in source-delta.json. The legacy
`source/vir/src/native_resource/native.rs` is byte-identical in140 and143:
`85ef1774e8d2790a91d08801479b736217b86d9179f5242ff9fab3f1d74ed7cd`.
Its old local-only overwrite and statement-only endpoint code is still present
(`derive` at line218, statement loop255, pending-local transfer300). Therefore
this review does **not** close R144 findings on old140 or certify any145 patch.
It independently recognizes equivalent immediate map-kill and inclusive-endpoint
rules in143's different typed ledger, with the remaining objections above.
An independent in-memory unified-diff reconstruction also matches candidate.patch
byte-for-byte; `patch-reconstruction.json` retains that source-only result.

## Receipts, exact negatives, and exhausted allowances

`receipt-review.json` independently extracts sealed records without rerunning
their commands.36 command records numbered1..36 retain **36/36 exhausted**;
the first two have narrative failure records, not exact saved raw shell receipts.
The other34 have per-command receipts; none records owned_group_absent false.
253 resource samples record minimum free32678723584 bytes, peak logical996257068
and peak allocated1004085248 bytes.143's seal-summary includes additional
endpoint/accounting observations with minimum free32677113856 and final logical
996557207/allocated1004408832. Sampling/receipt claims are not continuous custody
or independently established historical resource compliance. Historic140 remains
24/24 exhausted; interrupted116 is untouched. No new heavy command is authorized.

Final build31 is recorded successful with the final candidate source inventory;
that source inventory exactly equals candidate-final.json. Original32, mutant33,
restored34 have rc1, same recorded executable SHA256
`60bfe75c2145404724bd3a187da327359746ceb75c12e449c806bc4ed16b0654`, and OPEN native
refusal. That is a receipt identity claim, not authentication of today's target
binary. The original/restored JSON bytes independently compare equal, digest
`943d26b8cf3aad5abb842a1102b298ae29132aa259c8132d9050fa3deece6b94`.
The sealed validation-summary has63 passed receipt checks and no failed checks;
these are not63 compiler/native resource proofs.

`semantic-negative.patch` retains the original storage.write but redirects the
copy to unrelated header bytes. Its header ordinary frontend succeeds; the new
typed lowerer specifically reports **NRE143_COPY_HAS_NO_EXACT_RETURNED_LOAN_ORIGIN**.
This is a real changed-source negative in the retained receipts, not an unrelated
frontend refusal. It was not rerun here and does not exercise the new findings.

The four **typed CFG fault injections**, not four changed source programs, give:
lost origin -> NRE143_COPY_HAS_NO_EXACT_RETURNED_LOAN_ORIGIN;
missing terminator ends -> NRE143_DROP_WITH_OUTSTANDING_RETURNED_LOAN bb24[0];
wrong projection -> NRE143_COPY_EXACT_FULL_PROJECTED_RETURNED_PLACE;
stale event -> NRE143_WRITEBACK_HAS_NO_NATIVE_COPY_EVENT.
Older shape controls are explicitly not authority. Neither controls nor their
diagnostic errors establish complete mutant adequacy or byte/resource semantics.

Original PagedCachedFile::write remains refused in two independent ways: ordinary
frontend macro-expanded `for` unsupported, and actual MIR Assert **bb0[12]**
unsupported by native lowering (condition/failure/panic/unwind/abort semantics
missing, `L:1021`). No source rewrite, helper extraction, assumed caller invariant,
or primitive law is credited to bypass it.

## Smallest proof-directed next cut

No automatic follow-up, slot acquisition, compiler retry or chain is requested.
Under a separately explicit bounded disposition: first repair/refuse stale
reference-holder edges (R146-1) and noninjective occurrence coverage (R146-2).
Then take the actual original header mem_mut/copy normal AND cleanup loan ends
through one declared, fully WF/mode-checked semantic resource relation, keeping
incoming checkout/Arc eligibility visibly unproved until the actual original
write/take/constructor reservation supplies them. Replace only the corresponding
false debt with a real checked byte mutation/frame/writeback relation; do not
promote an unverified opaque native callee to trusted authority. Source-level
negatives for move/reuse, duplicate origin, alias, branch and cleanup paths belong
to that future bounded implementation, not this source-only review.

Until original write's Assert/macro-for and the cache/constructor/primitive outcome
boundary are handled without assumptions, even that cut cannot establish the
buffer/flush/acknowledgement/recovery chain. All18 remain OPEN. Final authentication,
scratch accounting, seal and readback are separate records alongside this report.
**Release: no compiler slot acquired or held; none remains to release.**
