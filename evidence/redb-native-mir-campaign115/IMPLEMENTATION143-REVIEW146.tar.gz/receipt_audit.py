import collections
import hashlib
import json
import pathlib

ROOT = pathlib.Path('/private/tmp/implementation143-20261108-LpJjrIbt')
OUT = pathlib.Path(__file__).parent

def load(name):
    return json.loads((ROOT / name).read_text())

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

commands = load('commands.json')
receipts = []
samples = []
for command in commands:
    name = command['name']
    path = ROOT / (name + '.receipt.json')
    item = {'number': command['number'], 'name': name, 'command_keys': list(command)}
    if path.exists():
        receipt = json.loads(path.read_text())
        item.update({key: receipt.get(key) for key in ['returncode', 'elapsed', 'timeout', 'cause', 'owned_group_absent', 'candidate_source_unchanged_during_command', 'executable_sha256']})
        item['resource_samples'] = 0
        resources = ROOT / (name + '.resources.jsonl')
        if resources.exists():
            rows = [json.loads(line) for line in resources.read_text().splitlines()]
            samples.extend(rows)
            item['resource_samples'] = len(rows)
    else:
        item['receipt_missing'] = True
        item['narrative_command_record'] = command
    receipts.append(item)

original = load('original-final.json')
negative = load('negative-final.json')
restored = load('control-restored.json')
bodies = {}
for owner, body in original['bodies'].items():
    occurrences = body.get('occurrences', {}).get('Ok', [])
    accepted = [entry['Ok'] for entry in occurrences if 'Ok' in entry]
    grouped = collections.defaultdict(list)
    for occurrence in accepted:
        grouped[occurrence['hir']].append(occurrence['location'])
    item = {'ordinary_frontend': body['ordinary_frontend'], 'bound_occurrences': accepted, 'unbound_occurrences': [entry for entry in occurrences if 'Err' in entry], 'duplicate_bound_hir': {key: value for key, value in grouped.items() if len(value) > 1}, 'cfg_fault_injections': body['cfg_semantic_negatives']}
    lowering = body['native_lowering']
    if 'Err' in lowering:
        item['lowering_error'] = lowering['Err']
    else:
        result = lowering['Ok']
        item['counts'] = {key: result[key] for key in ['exact_copy_paths', 'returned_loans', 'visited_occurrences']}
        item['requirements'] = result['requirements']
        proof = result['original_body_proof_lowering']
        item['proof'] = {key: value for key, value in proof.get('Ok', {}).items() if key != 'body'} if 'Ok' in proof else proof
    bodies[owner] = item

selected = ['README.md', 'candidate.patch', 'validation-summary.json', 'commands.json', 'SEAL.json', 'SEAL.sha256', 'candidate-final.json', 'source-delta.json', 'seal-summary.json', 'RELEASE.md', 'original-final.json', 'negative-final.json', 'control-restored.json', 'semantic-negative.patch', 'build-final-expiry-17.source.json', 'build-final-expiry-17.receipt.json', 'original-final.receipt.json', 'negative-final.receipt.json', 'control-restored.receipt.json', 'candidate/source/rust_verify/src/native_resource143.rs', 'candidate/source/rust_verify/src/native_resource143/ledger.rs', 'candidate/source/rust_verify/src/rust_to_vir_expr.rs', 'candidate/source/rust_verify/src/rust_to_vir_func.rs', 'candidate/source/rustc_mir_build/src/builder/native_resource_origins.rs', 'candidate/source/rustc_mir_build/src/builder/expr/into.rs', 'candidate/source/vir/src/ast_visitor.rs', 'candidate/source/vir/src/native_resource/native.rs']
selected_hashes = [{'path': str(ROOT / name), 'bytes': (ROOT / name).stat().st_size, 'sha256': sha(ROOT / name)} for name in selected]
(OUT / 'selected-hashes.json').write_text(json.dumps(selected_hashes, indent=2) + '\n')
validation = load('validation-summary.json')
delta = load('source-delta.json')
base = pathlib.Path('/private/tmp/implementation140-20261108-RdrUQDUb/candidate')
old = ROOT / 'candidate/source/vir/src/native_resource/native.rs'
summary = {'scope': 'Independent receipt/data inspection only, not execution/reproduction/resource proof', 'command_count': len(commands), 'command_numbers': [item['number'] for item in commands], 'command_receipts': receipts, 'resource_sample_count': len(samples), 'recorded_minimum_free_bytes': min(row['free'] for row in samples), 'recorded_peak_logical_bytes': max(row['logical'] for row in samples), 'recorded_peak_allocated_bytes': max(row['allocated'] for row in samples), 'validation_checks': len(validation['checks']), 'validation_failures': [row for row in validation['checks'] if not row['passed']], 'original_restored_bytes_identical': (ROOT / 'original-final.json').read_bytes() == (ROOT / 'control-restored.json').read_bytes(), 'original_restored_sha256': sha(ROOT / 'original-final.json'), 'final_build_source_manifest_equals_final': load('build-final-expiry-17.source.json') == load('candidate-final.json'), 'body_reviews': bodies, 'negative_header': next(body['native_lowering'] for owner, body in negative['bodies'].items() if owner.endswith('::write_header')), 'same_recorded_executable': len({load(name + '.receipt.json')['executable_sha256'] for name in ['original-final', 'negative-final', 'control-restored']}) == 1, 'source_delta_paths': [row['path'] for row in delta], 'old140_native_rs_equals143': old.read_bytes() == (base / 'source/vir/src/native_resource/native.rs').read_bytes(), 'old140_native_rs_sha256': sha(old), 'unverified': 'No current target artifacts/dependencies/toolchain executables authenticated here; historical launch/process/resource statements remain receipt claims, not continuous custody.'}
(OUT / 'receipt-review.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({key: value for key, value in summary.items() if key not in ['command_receipts', 'body_reviews']}, indent=2))
