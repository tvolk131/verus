import datetime
import hashlib
import json
import pathlib
import shutil

ROOT = pathlib.Path(__file__).parent
BASE = pathlib.Path('/private/tmp/implementation140-20261108-RdrUQDUb')
START = datetime.datetime.fromisoformat('2026-11-08T20:56:02+00:00')
DEADLINE = START + datetime.timedelta(minutes=16)
LIMIT = 3 * 1024**2
EXCLUDED = {'SEAL.json', 'SEAL.sha256', 'READBACK.json', 'READBACK.sha256'}

def now():
    return datetime.datetime.now(datetime.timezone.utc)

def sha(path):
    hasher = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            hasher.update(chunk)
    return hasher.hexdigest()

def write(name, data):
    (ROOT / name).write_text(json.dumps(data, indent=2) + '\n')

def usage():
    files = [path for path in ROOT.rglob('*') if path.is_file()]
    return {'files': len(files), 'logical_bytes': sum(path.stat().st_size for path in files), 'allocated_bytes': sum(path.stat().st_blocks * 512 for path in files), 'free_bytes': shutil.disk_usage(ROOT).free}

def enforce():
    current = usage()
    if now() >= DEADLINE:
        raise RuntimeError('16 minute limit reached')
    if current['free_bytes'] <= 16 * 1024**3:
        raise RuntimeError('free disk at or below 16GiB')
    if max(current['logical_bytes'], current['allocated_bytes']) > LIMIT:
        raise RuntimeError('fresh scratch exceeds 3MiB')
    return current

enforce()
entry = json.loads((ROOT / 'authentication-entry.json').read_text())
exit_record = json.loads((ROOT / 'authentication-exit.json').read_text())
if not entry['all_match'] or not exit_record['all_match'] or not exit_record['same_as_entry']:
    raise RuntimeError('input authentication failure')

records = json.loads((BASE / 'candidate-final.json').read_text())
failures = []
for record in records:
    path = BASE / 'candidate' / record['path']
    if sha(path) != record['sha256'] or path.stat().st_size != record['bytes']:
        failures.append(record['path'])
baseline = {'phase': 'supplemental-exit', 'root': str(BASE / 'candidate'), 'manifest_sha256': sha(BASE / 'candidate-final.json'), 'count': len(records), 'failures': failures}
baseline_entry = json.loads((ROOT / 'baseline-source-entry.json').read_text())
baseline['same_as_entry'] = all(baseline[key] == baseline_entry[key] for key in ['root', 'manifest_sha256', 'count', 'failures'])
write('baseline-source-exit.json', baseline)
if failures or not baseline['same_as_entry']:
    raise RuntimeError('baseline source changed')

selected = json.loads((ROOT / 'selected-hashes.json').read_text())
for record in selected:
    path = pathlib.Path(record['path'])
    if path.stat().st_size != record['bytes'] or sha(path) != record['sha256']:
        raise RuntimeError('selected record changed: ' + str(path))

accounting = {'review': 146, 'utc': now().isoformat(), 'start_utc': START.isoformat(), 'deadline_utc': DEADLINE.isoformat(), 'elapsed_seconds_before_seal': (now() - START).total_seconds(), 'source_receipt_only': True, 'review_heavy_commands': 0, 'compiler_slot_acquired': False, 'compiler_slot_held': False, 'compiler_slot_release': 'No slot acquired or held; nothing remains to release', 'review_allowances': {'minutes_including_seal': 16, 'scratch_limit_bytes': LIMIT, 'free_disk_requirement': 'strictly > 16GiB'}, 'before_seal': enforce(), 'implementation143': '36/36 EXHAUSTED; not reset or rerun', 'baseline140': '24/24 EXHAUSTED; unchanged', 'source_native_trust_proof_acceptance_credit': [0, 0, 0, 0], 'all18': 'OPEN', 'automatic_followup': False, 'raw_discovery_failures': 'discovery.txt', 'custody_scope': 'Endpoint payload and listed candidate sources; no full target authentication or historical continuous custody'}
write('ACCOUNTING.json', accounting)

payloads = []
for path in sorted(ROOT.rglob('*')):
    if path.is_file() and path.name not in EXCLUDED:
        payloads.append({'path': str(path.relative_to(ROOT)), 'bytes': path.stat().st_size, 'sha256': sha(path)})
seal = {'review': 146, 'implementation': 143, 'utc': now().isoformat(), 'deadline_utc': DEADLINE.isoformat(), 'elapsed_seconds': (now() - START).total_seconds(), 'within_16minutes': now() < DEADLINE, 'source_receipt_only': True, 'compiler_slot_held': False, 'scratch_limit_bytes': LIMIT, 'usage_before_seal': enforce(), 'payload_count': len(payloads), 'files': payloads, 'detached_readback': 'READBACK.json plus READBACK.sha256; intentionally excluded to avoid self-reference'}
write('SEAL.json', seal)
seal_hash = sha(ROOT / 'SEAL.json')
(ROOT / 'SEAL.sha256').write_text(seal_hash + '  SEAL.json\n')

readback_seal = json.loads((ROOT / 'SEAL.json').read_text())
mismatches = []
for record in readback_seal['files']:
    path = ROOT / record['path']
    if path.stat().st_size != record['bytes'] or sha(path) != record['sha256']:
        mismatches.append(record['path'])
readback = {'review': 146, 'utc': now().isoformat(), 'seal_sha256': seal_hash, 'seal_sidecar_matches': (ROOT / 'SEAL.sha256').read_text() == seal_hash + '  SEAL.json\n', 'payloads_read_back': len(readback_seal['files']), 'payload_mismatches': mismatches, 'report_sha256': sha(ROOT / 'REPORT.md'), 'input_reauthentication_same_as_entry': exit_record['same_as_entry'], 'baseline_reauthentication_same_as_entry': baseline['same_as_entry'], 'selected_records_reauthenticated': len(selected), 'elapsed_seconds': (now() - START).total_seconds(), 'usage_before_detached_readback': enforce(), 'slot': 'NONE ACQUIRED OR HELD; explicit release', 'acceptance_credit_source_native_trust_proof': [0, 0, 0, 0], 'all18': 'OPEN'}
write('READBACK.json', readback)
(ROOT / 'READBACK.sha256').write_text(sha(ROOT / 'READBACK.json') + '  READBACK.json\n')
if mismatches or not readback['seal_sidecar_matches']:
    raise RuntimeError('seal readback mismatch')
final_usage = enforce()
print(json.dumps({'seal_sha256': seal_hash, 'readback_sha256': sha(ROOT / 'READBACK.json'), 'report_sha256': sha(ROOT / 'REPORT.md'), 'payload_count': len(payloads), 'selected_records': len(selected), 'input_counts': exit_record['counts'], 'same_as_entry': exit_record['same_as_entry'], 'final_usage': final_usage, 'elapsed_seconds': (now() - START).total_seconds(), 'deadline': DEADLINE.isoformat(), 'slot': 'NONE ACQUIRED OR HELD; explicit release', 'source_native_trust_proof_acceptance_credit': [0, 0, 0, 0], 'all18': 'OPEN'}, indent=2))
