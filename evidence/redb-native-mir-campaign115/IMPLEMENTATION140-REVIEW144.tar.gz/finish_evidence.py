import datetime
import hashlib
import json
import pathlib

ROOT = pathlib.Path('/private/tmp/implementation140-20261108-RdrUQDUb')
SCRATCH = pathlib.Path('/private/tmp/review144-20261108-zvUvswJB')
selected = {
    'candidate/source/vir/src/native_resource/native.rs': [(246, 261), (284, 306), (309, 345), (356, 381), (407, 422), (448, 460), (465, 515), (519, 554)],
    'candidate/source/rust_verify/src/native_resource140.rs': [(80, 90), (129, 136), (164, 175), (293, 314), (318, 332)],
    'candidate/source/vir/src/native_resource.rs': [(1, 36), (307, 345)],
    'candidate/source/rust_verify/src/import_export.rs': [(111, 120), (272, 280)],
    'candidate/source/rust_verify/src/verifier.rs': [(2911, 2920)],
    'candidate/source/vir/src/ast_to_sst_func.rs': [(743, 750)],
}
records = []
for name, ranges in selected.items():
    source = ROOT / name
    payload = source.read_bytes()
    lines = payload.decode().splitlines()
    records.append(dict(path=str(source), sha256=hashlib.sha256(payload).hexdigest(), excerpts=[dict(start_line=start, lines=[dict(line=number, text=lines[number - 1]) for number in range(start, end + 1)]) for start, end in ranges]))
(SCRATCH / 'source-anchors.json').write_text(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), source_records=records), indent=2) + '\n')
before = json.loads((SCRATCH / 'original-before.json').read_text())
original_records = []
for entry in before['records']:
    source = pathlib.Path(entry['path'])
    payload = source.read_bytes()
    observed = hashlib.sha256(payload).hexdigest()
    original_records.append(dict(path=str(source), bytes=len(payload), sha256=observed, unchanged=observed == entry['sha256'] and len(payload) == entry['bytes']))
binary = ROOT / 'target/debug/native-resource140'
binary_hash = hashlib.sha256(binary.read_bytes()).hexdigest()
result = dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), records=original_records, failures=[entry for entry in original_records if not entry['unchanged']], selected_producer_sha256=binary_hash, selected_producer_unchanged=binary_hash == json.loads((SCRATCH / 'receipt-review.json').read_text())['selected_producer_sha256'], all1511_target_artifacts_authenticated=False)
(SCRATCH / 'original-after.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(dict(original_records=len(original_records), failures=result['failures'], selected_producer_unchanged=result['selected_producer_unchanged'], source_anchor_files=len(records)), indent=2))
