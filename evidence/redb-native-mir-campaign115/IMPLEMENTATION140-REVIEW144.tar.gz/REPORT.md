# Review144: sealed implementation140 source/receipt review

## Disposition and authority

**RETAIN UNADOPTED. Two P2 source-implementation findings; no P1 trust-boundary
bypass found in the reviewed patch. Zero original bodies verified, zero new
primitive laws adopted, zero native certificates, and all18 remain OPEN.**
Candidate141 remains NOT ADOPTED after review142. This is a fresh bounded
source/receipt review, not completion or reset of140 or interrupted116, not law
adoption, integration, first-cell acceptance, or permission for a successor run.
The parent alone may reconcile these findings into143.

Started 2026-11-08T19:56:53Z, with a hard review deadline of20:11:53Z including
seal. Only this fresh scratch is authored. No compiler/Cargo/build/test,
observer/solver/native-application execution, network, Git write, parent or
candidate edit, goal operation, subdelegation, or inspection/polling of143
occurred. The review never acquires the compiler slot. Authored Python helpers
only hash/read existing source/receipts and write this report's scratch evidence;
they do not execute candidate code or recreate negative controls.

## Authentication and custody

- Candidate root: `/private/tmp/implementation140-20261108-RdrUQDUb`.
- Supplied `SEAL.json` SHA256 matched
  `d80fcfca63c352e6ed1ebb3bd254291234dc03dc8bbf05972430934c6ee4eefc`.
- Before candidate source inspection, independently matched all201 sealed
  payloads, all1100 candidate source records, and all203 unique regular archive
  members byte-for-byte with the root. Archive payload:7,780,104bytes.
- Candidate inventory SHA256 matched
  `470b1fb019f203d6b65fdced729bc1602d41dea4a4f7459801fa7f2422acbab8`;
  handoff archive SHA256 matched
  `deafe0d685e390df7b0c4dbff88284bc20948d8bd607c178cfa281a40ad38417`.
- Read all five requested workspace scope/handoff/review records. Their hashes
  are retained in the before/after endpoint manifests. The scope descriptions
  were read before the full candidate endpoint authentication; no earlier
  custody is invented.
- Original root's132 records matched its sealed inventory before original body
  source reading. That endpoint follows instruction reading and an `rg` anchor
  discovery; it is not retroactively described as earlier custody. All eight
  captured body file hashes and source snippets agree with current original
  source. Applicable original AGENTS.md was read; no nested source AGENTS found.
- Reconstructed the complete additive unified patch from the changed frozen114
  files and candidate sources: exact byte equality with `candidate.patch`, and
  the same14 paths as `source-delta.json`. The separately disclosed affine
  channel port is not silently treated as part of frozen114.
- Only the selected producer binary was hashed, not run: SHA256
  `ace2e9420a41ab66e622e8d30c947eb292b0966dfccc88988c9f311e243dbb11`,
  matching the final capture/export receipts and its retained artifact record.
  **The1511 target artifact records are NOT wholly authenticated.** Hashing one
  producer now does not retrofit parent artifact custody or prove historical
  build execution, compiler correctness, or source-to-binary correspondence.
- `authentication-before.json`, `authentication-after.json`,
  `original-before.json`, `original-after.json`, `receipt-review.json`, and
  `source-anchors.json` provide the selected evidence and exact source anchors.
  `SEAL.json` is the final report inventory; its timestamp and resource check
  bound this review's endpoint.

## Findings

### R144-1 — P2: overwrite and call transfer can retain stale local provenance

Primary anchor:
`candidate/source/vir/src/native_resource/native.rs:295`.
Related anchors: the same file:284, :312, :334, :361, :485, :498.
File SHA256:
`85ef1774e8d2790a91d08801479b736217b86d9179f5242ff9fab3f1d74ed7cd`.

`derive` keys its pending state by local number. A supported Copy/Move assignment
updates the destination only if the source already has a pending entry. An
overwrite from an untracked local therefore leaves the destination's old
DataView entry intact; moving that untracked source does not change this. Other
assignments merely add an OPEN obligation and also retain a previous destination
entry. At a call, the input lookup discards the argument projection, and only a
recognized candidate-producing call consumes moved arguments or overwrites its
destination. An unrelated call overwriting a tracked local leaves stale state.
`Return` subsequently recognizes the stale local0 entry as `returned_data_view`.
The header path's separate pending-local set similarly ignores ordinary
overwrites and call destinations.

Static counterexample, NOT executed: after `_0` has pending DataView provenance,
assign `_0 = Copy(untracked_same_type_local)` before Return. The supported
assignment arm sees no source entry and performs no destination kill, so the
previous view is still reported as returned. A projected call operand can also
reuse its base local's provenance without proving that projection denotes the
tracked referent. These are concrete transfer-rule defects, not a newly
reproduced native-proof failure; no retained control tests these cases.

Impact: the conditional source path itself can name the wrong current value.
It cannot be reused as an occurrence/resource lowerer merely by discharging its
listed primitive obligations. Current unconditional lowering refusal prevents
native proof credit, so this is P2, not an admitted soundness exploit.

Small correction: use one destructive-write/move transfer in the actual
occurrence state, invalidating overwritten destinations and moved sources even
when their provenance is unknown. Match/reject full projected operands instead
of reducing them to locals. Use the same state transfer for the real header
occurrences rather than a second permissive local set. Unknown transfers remain
unsatisfied obligations, never successful byte/resource transfers.

### R144-2 — P2: loan-end transfer omits terminator locations

Primary anchor:
`candidate/source/vir/src/native_resource/native.rs:255`.
Related anchors: the same file:257, :309, :343, :356, :525.
Producer capture anchor:
`candidate/source/rust_verify/src/native_resource140.rs:164`.

The producer records actual `calculate_borrows_out_of_scope_at_location` entries,
but `derive` applies them only inside the statement loop. It never applies ends
at `statement == block.statements.len()` before dispatching that block's
terminator. In an empty block the loan-end transfer is skipped entirely.
Cleanup successors are checked structurally but not executed through a distinct
cleanup resource state; the header cleanup walk checks reachability only.

This omission is present in retained original graphs, not just a hypothetical
serde object. For original `LRUWriteCache::return_value`, loan2 has an end at
bb4:0; bb4 has zero statements and a Switch terminator. The retained derivation's
NLL-end steps report loans0/1 at bb3:0 but omit loan2 at bb4:0. For original
`write_header`, receiver/reborrow/source loans1/2/3 all end at bb24:0; bb24 is an
empty cleanup block whose terminator drops page20. The header cleanup search
accepts reaching that drop without representing those end events. Additional
actual terminator endpoints for original drop/take_value/get_mut are retained
in `receipt-review.json`.

Impact: a future resource consumer using these transfers would miss receiver
unsuspension/loan-end writeback exactly before native control-flow/drop events.
The existing lifetime/frame/native-proof gap is already disclosed; the new
finding is the precise event-scheduling omission in the source implementation,
not a claim to have reproduced an unsound accepted proof.

Small correction: factor a single `apply_loan_ends(Location, state)` transfer and
invoke it before every statement AND before every terminator, including empty
normal and cleanup blocks. Retain parent/returned-loan provenance through call
outcomes instead of treating `loan: None` on candidate call results as a fresh
authority. In actual lowering, the end transfer must generate a checked
writeback/receiver-resumption obligation, not merely append a diagnostic step.
Unimplemented cleanup/outcome states must remain refused.

## Typed identity, executable coverage and unsupported effects

The compiler adapter genuinely uses `FnDef`, `Instance::try_resolve`, nominal ADT
and diagnostic/lang identities, and `BodyWithBorrowckFacts` from the original
root; it is not exclusively a span/name search. Relevant anchors:
`candidate/source/rust_verify/src/native_resource140.rs:80`, :139, :164, :263.
However, the transported Api/Place/Body fields are public serde/debug/display
strings, primitive tags and local indices. DefPathHash identifies a definition,
not by itself a monomorphized executable occurrence or an affine resource.
Instance substitutions, place/type/region identity and body-to-VIR ownership
cannot become authoritative by accepting this serialized record. There is no
graph import CLI here and `lower_to_affine` always refuses; this is an explicit
boundary objection, not a new bypass finding.

The final raw result captures exactly eight bodies: WritablePage mem/mem_mut/
drop, LRUWriteCache return_value/take_value, LRUCache get_mut, PagedCachedFile
write, and TransactionalMemory write_header. The full original lib.rs was passed
to compiler analysis with the retained target/cfg, but selection is only those
eight bodies. **No original executable body reaches a successful verifier
check.** No general original-code coverage is inferred from full-crate analysis.

`End` successor comparison checks all retained blocks, target bounds and cleanup
entry flags before pending traversal. FalseEdge imaginary successors are retained
structurally; normal traversal uses only the real edge. Switch discriminant
values, branch refinement and joins are not proved. Unsupported MIR rvalues,
statements, retagging and projections become explicit unsupported/OPEN facts or
refusals; they do not receive semantics. Assert is not lowered. Original
PagedCachedFile::write bb0 retains the compiler successors but has Unsupported
Assert and `derive(write)` returns `NRE140_SUCCESSOR_LOSS bb0`. This is the already
disclosed correct refusal, NOT a new finding or successful Assert lowering.

The header consumer calls `derive(header)` but discards that derivation's
obligation vector at :413, uses the producer's obligations at :448, and searches
one post-mem_mut normal path plus existential cleanup-drop reachability. It does
not compose all normal/cleanup resource states or all caller obligations. Keep
that limitation explicit; simply extending an obligation inventory is not the
requested native-lowering milestone.

## Constructor, header-copy and cache-return challenge

Native anchors:
`/private/tmp/redb-original-crate-preflight115/redb/src/tree_store/page_store/cached_file.rs:35`,
the same file:40, :91, :95, :881, :974;
`/private/tmp/redb-original-crate-preflight115/redb/src/tree_store/page_store/page_manager.rs:1617`.

The retained header links are mem_mut bb15:2, copy bb17:5, normal page20 drop
bb18:4 and cleanup page20 drop bb24:0. The actual copy source uses to_bytes(true)
and an unsupported unsize at bb17:3. The conditional view is not a proof of source
bytes, equal length, destination byte update or post-copy writeback.

The constructor has the nominal page hash and field order buffer/offset/data,
with actual operands260/262/263; two take_value calls and the header's write
result22 are recorded. The source has a successful `Ok(WritablePage { ... })`
expression, but branch-specific authority, Result/Try extraction into page20,
reservation ownership across unlock and all constructor paths remain unproved.
No success or byte authority follows from finding the aggregate or counting two
take sites.

Destructor identity follows the actual nominal destructor hash. Its clone-output
local links to return_value's third argument, but the local-output match alone
does not prove clone input equals this page's allocation, matching buffer/key,
cache slot None continuity, Arc eligibility, Mutex/poison outcomes, map/hasher
correspondence, callback frame or atomic history. The consumer's own OPEN
obligations correctly withhold those claims. Application helpers are not
externalized as primitive contracts. No Arc/Mutex/cache/frame law from141 is
installed in the exact patch; the scalar affine fixture is not checkout authority.

## Changed admission/default-off/import/export boundary

All14 changed files are enumerated in `receipt-review.json` and authenticated by
the exact patch. Boundary anchors:

- `candidate/source/rust_verify/Cargo.toml:40` and :45, and
  `candidate/source/vir/Cargo.toml:23`: default-off feature, feature-required
  producer binary, feature-gated producer/native modules.
- `candidate/source/rust_verify/src/lib.rs:10` and :57:
  rustc_borrowck linkage and producer module gate.
- `candidate/source/vir/src/ast.rs:88`, `candidate/source/vir/src/def.rs:1305`,
  `candidate/source/vir/src/lib.rs:57`: explicit later-channel identifier,
  spelling and module addition, not a primitive-law import.
- `candidate/source/vir/src/native_resource.rs:13`, :25, :307:
  marked-crate rejection, default-off/exec/pure/safe-API lowering restriction and
  empty-static-exec-fixture-only instrument gate; Infer/external-body fixtures
  remain rejected. The fixture starts with a symbolic input slot, but the native
  producer neither calls it nor issues an affine token from counts.
- `candidate/source/rust_verify/src/import_export.rs:116` and :275:
  reject marked native-resource crates on import and before export-path handling.
- `candidate/source/rust_verify/src/verifier.rs:2914`:
  reject marked crates at native admission.
- `candidate/source/vir/src/ast_to_sst_func.rs:747`:
  check lowering before body translation.
- `candidate/source/rust_verify/src/native_resource140.rs:296`, :307, :313,
  :326: only OPEN output, hardcoded zero credit/certificate false, deliberate
  compiler error and early explicit --export refusal. There is no certificate
  success path.

No Infer/S0/full-scope checks are removed by the14-file patch. This does not claim
an adversarial audit of every possible unrelated VIR deserialization path.

## Retained controls and accounting, without reruns

Read all24 commands and all launch/receipt/source/stream/resource records.
Sequential numbers, argv, source-inventory digests and stream sizes/hashes agree.
Ten builds: first3 rc101 (pinned API/hash formatting, missing is_u8, then std/core
linkage errors); builds04 through10 rc0. All failures remain charged. Six actual
source captures return rc1 with OPEN producer refusal. Feature-on boundary tests
retain2 passes; feature-off retains3; default-off producer check rc101. The
feature-on tests explicitly skip checked solver fixtures. No source/proof credit
is inferred. Historical test snapshots differ globally from build10 but their
reviewed boundary files are byte-identical to the sealed candidate.

The final build10/capture22/export23/audit24 all bind source digest
`782cf8d5814f50f5e4ca897f8470329e659a1f66a33b32ef628d6c91beb894f2`.
Capture22 and export23 bind the same selected producer hash. Their raw stderr
contains respectively the OPEN native-obligations diagnostic and explicit
`NRE140_EXPORT_REFUSED`; export23 rc2 is not an unrelated frontend refusal.

Raw `outputs/original-checkout-final.json` contains mem's4, mem_mut's6 and header's4
negative/restoration result strings, matching `evidence-audit.json`. The source
checks exact expected failure codes for edge loss, wrong loan origin, absent
two-phase activation, wrong typed callee, copy receiver substitution and nominal
destructor substitution. Primitive-slot removal loses the pending view, not a
resource proof. Restoration returns the same OPEN derivation/refusal. These are
internal mutations of captured graphs, not source-mutated native verifier runs,
not new compiler authority, and not controls for the two findings above.

The current source/receipt scan found no `.vir`, `.verusdata`, or output `.rmeta`;
all requested fresh export paths remain absent. This is absence in the inspected
root at an endpoint, not proof that no arbitrary path was ever written.

All24 receipts record completed/reaped owned groups and group absence. Retained
632 resource samples agree with summary: maximum allocated1,166,659,584bytes,
maximum logical1,156,448,919bytes, minimum free34,244,825,088bytes; each satisfies
the original4GiB scratch and strict>16GiB free limits. Sampling is not continuous
telemetry. RELEASE.md explicitly releases the slot at19:50:30.986945Z within the
original45minute deadline19:57:37Z. No current process-group query or143 polling
was performed, so these are historical receipt claims, not a new liveness audit.
The original24/24 allowance remains exhausted and unchanged.

## Smallest useful next source implementation

Do not add a new diagnostic graph or law schema. In the compiler-owned path for
the original mem_mut occurrence, preserve the actual receiver/returned-loan parent
relation across the normal Arc-get_mut/Option-unwrap outcomes; use destructive
place transfers and loan-end events at every actual Location, including bb24:0
before cleanup drop. Connect that state to the real translated original VIR
function/occurrence and emit a checked unsatisfied loan-end/writeback obligation
there. Unknown incoming checkout authority and unsupported Assert/cleanup effects
must remain blocking, not assumptions. This is a narrowly useful first lowering
increment; it does not itself close acknowledged durability or any of the18 cells.

## Review failures and limitations

Initial grouped terminal displays were truncated; narrower reads and structured
file summaries supplied the missing content. No failed compiler/test command was
run by this review. Implementation140's setup failures (PATH127 and unsuccessful
discovery commands) remain in its sealed SETUP-FAILURES.md; those notes expressly
say initial raw streams were not captured as files. They are transcriptions, not
newly fabricated raw receipts. No implementation140/116 allowance is reset.

No full target-artifact authentication, historical execution attestation,
compiler/solver trust proof, native occurrence/resource proof, cache-reservation
proof, frame/hasher assumption, legal atomic-history law, persistent root/data
refinement, public-acknowledgment/recovery theorem, primitive141 adoption, native
integration or final-cell acceptance follows from this review. Stop at this
sealed handoff; no automatic successor chain.
