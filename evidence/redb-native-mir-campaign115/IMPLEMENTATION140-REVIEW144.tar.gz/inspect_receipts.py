import datetime
import difflib
import hashlib
import json
import pathlib
import shutil

ROOT = pathlib.Path('/private/tmp/implementation140-20261108-RdrUQDUb')
SCRATCH = pathlib.Path('/private/tmp/review144-20261108-zvUvswJB')

def sha(payload):
    return hashlib.sha256(payload).hexdigest()

def load(name):
    return json.loads((ROOT / name).read_text())

def inventory_digest(records):
    return sha(json.dumps(records, sort_keys=True, separators=(',', ':')).encode())

problems = []
commands = load('commands.json')
rows = []
samples = []
for number, command in enumerate(commands, 1):
    name = command['name']
    receipt = load(name + '.receipt.json')
    launch = load(name + '.launch.json')
    source = load(name + '.source.json')
    source_digest = inventory_digest(source)
    checks = {
        'sequential_number': receipt['command_number'] == number,
        'argv_matches_command_and_launch': command['argv'] == receipt['argv'] == launch['argv'],
        'source_inventory_digest_matches': receipt['source_sha256'] == launch['source_sha256'] == source_digest,
        'owned_group_absent_recorded': receipt.get('owned_group_absent') is True,
        'status_completed': receipt['status'] == 'COMPLETED',
        'timeout_within_bound': receipt['timeout_seconds'] <= (600 if command['kind'] == 'build' else 120),
        'elapsed_within_timeout': receipt['elapsed_seconds'] <= receipt['timeout_seconds'],
        'jobs1_offline_env': receipt['environment'].get('CARGO_BUILD_JOBS') == '1' and receipt['environment'].get('CARGO_NET_OFFLINE') == 'true',
    }
    for stream in ['stdout', 'stderr']:
        payload = (ROOT / (name + '.' + stream)).read_bytes()
        checks[stream + '_bound_to_receipt'] = sha(payload) == receipt[stream]['sha256'] and len(payload) == receipt[stream]['bytes']
    for key, matched in checks.items():
        if not matched:
            problems.append({'command': name, 'check': key})
    samples.extend([receipt['resource_before'], receipt['resource_after']])
    samples.extend(json.loads(line) for line in (ROOT / (name + '.resources.jsonl')).read_text().splitlines() if line)
    rows.append(dict(number=number, name=name, kind=command['kind'], returncode=receipt.get('returncode'), source_sha256=source_digest, checks=checks, start_utc=receipt['start_utc'], end_utc=receipt['end_utc'], argv_file_inputs=receipt['argv_file_inputs']))

baseline_root = pathlib.Path(load('copy-ledger.json')['source'])
baseline = {entry['path']: entry for entry in load('baseline-input.json')}
candidate = {entry['path']: entry for entry in load('candidate-final.json')}
delta = [name for name in sorted(set(baseline) | set(candidate)) if baseline.get(name) != candidate.get(name)]
patches = []
for name in delta:
    before_path = baseline_root / name
    after_path = ROOT / 'candidate' / name
    before = before_path.read_bytes() if name in baseline else b''
    after = after_path.read_bytes() if name in candidate else b''
    if name in baseline and (sha(before) != baseline[name]['sha256'] or len(before) != baseline[name]['bytes']):
        problems.append({'changed_baseline_hash_mismatch': name})
    patches.extend(difflib.unified_diff(before.decode().splitlines(keepends=True), after.decode().splitlines(keepends=True), fromfile='baseline/' + name, tofile='candidate/' + name))
expected_patch = ''.join(patches).encode()
patch_matches = expected_patch == (ROOT / 'candidate.patch').read_bytes()
if not patch_matches:
    problems.append('exact_patch_does_not_match')

capture = load('outputs/original-checkout-final.json')
audit = load('evidence-audit.json')
body_rows = []
terminal_end_rows = []
for entry in capture['body_results']:
    body = entry['body']
    source = pathlib.Path(body['source_file']).read_bytes()
    row = dict(definition=body['definition'], method=body['method'], source_hash_matches=sha(source) == body['source_sha256'], snippet_present=body['source_body'] in source.decode(), block_count=len(body['blocks']), derivation_error=entry['derivation'].get('Err'), semantic_negatives=entry.get('semantic_negatives'))
    if body['method'] in ['mem', 'mem_mut']:
        row['negative_strings_match_audit'] = entry['semantic_negatives']['Ok'] == audit['semantic_negatives'][body['method']]
    body_rows.append(row)
    for loan in body['loans']:
        for end in loan['ends']:
            if end['statement'] == len(body['blocks'][end['block']]['statements']):
                terminal_end_rows.append(dict(method=body['method'], loan=loan['index'], end=end, block_end=body['blocks'][end['block']]['end']))

binary_path = ROOT / 'target/debug/native-resource140'
binary_digest = sha(binary_path.read_bytes())
final_source = inventory_digest(load('candidate-final.json'))
selected_binary_bindings = []
for name in ['original-checkout-final', 'producer-export-refusal-sealed']:
    receipt = load(name + '.receipt.json')
    selected_binary_bindings.append(dict(command=name, current_selected_producer_matches_recorded_input=receipt['argv_file_inputs'][0]['sha256'] == binary_digest, final_source_digest_matches=receipt['source_sha256'] == final_source))
boundary_paths = ['source/vir/src/native_resource.rs', 'source/vir/src/native_resource/tests.rs', 'source/rust_verify/src/import_export.rs', 'source/rust_verify/src/verifier.rs', 'source/vir/src/ast_to_sst_func.rs']
boundary_snapshot_matches = {}
for name in ['channel-feature-on', 'channel-feature-off', 'channel-feature-on-final']:
    source = {entry['path']: entry for entry in load(name + '.source.json')}
    boundary_snapshot_matches[name] = {path: source[path] == candidate[path] for path in boundary_paths}

exports = []
for directory, children, filenames in __import__('os').walk(ROOT):
    for filename in filenames:
        path = pathlib.Path(directory) / filename
        if path.suffix in ['.vir', '.verusdata'] or (path.parent == ROOT / 'outputs' and path.suffix == '.rmeta'):
            exports.append(str(path))
result = dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), source_receipt_only=True, problems=problems, command_count=len(rows), commands=rows, builds=sum(row['kind'] == 'build' for row in rows), initial_build_failure_codes=[row['returncode'] for row in rows[:3]], exact_patch_matches=patch_matches, delta_paths=delta, delta_list_matches=delta == [entry['path'] for entry in load('source-delta.json')], body_results=body_rows, terminator_location_loan_ends=terminal_end_rows, final_source_digest=final_source, selected_producer_sha256=binary_digest, selected_binary_bindings=selected_binary_bindings, all1511_target_artifacts_authenticated=False, boundary_snapshot_matches=boundary_snapshot_matches, header_negative_strings_match_audit=capture['header_semantic_negatives']['Ok'] == audit['header_semantic_negatives'], exported_artifacts_found=exports, retained_sample_count=len(samples), retained_min_free_bytes=min(sample['free_bytes'] for sample in samples), retained_max_allocated_bytes=max(sample['allocated_bytes'] for sample in samples), retained_max_logical_bytes=max(sample['logical_bytes'] for sample in samples), all_retained_resource_samples_safe=all(sample['free_bytes'] > 16 * 1024**3 and max(sample['allocated_bytes'], sample['logical_bytes']) <= 4 * 1024**3 for sample in samples), current_review_free_bytes=shutil.disk_usage(SCRATCH).free, historical_slot_release=load('seal-summary.json'))
(SCRATCH / 'receipt-review.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: value for key, value in result.items() if key not in ['commands', 'body_results', 'terminator_location_loan_ends', 'historical_slot_release', 'boundary_snapshot_matches']}, indent=2))
