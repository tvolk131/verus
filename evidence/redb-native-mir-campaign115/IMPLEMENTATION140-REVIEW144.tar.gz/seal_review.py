import datetime
import hashlib
import json
import pathlib
import shutil

ROOT = pathlib.Path('/private/tmp/review144-20261108-zvUvswJB')
DEADLINE = datetime.datetime.fromisoformat('2026-11-08T20:11:53+00:00')
now = datetime.datetime.now(datetime.timezone.utc)
files = []
for source in sorted(ROOT.rglob('*')):
    if source.is_file() and source.name not in ['SEAL.json', 'SEAL.sha256']:
        payload = source.read_bytes()
        files.append(dict(path=str(source.relative_to(ROOT)), bytes=len(payload), sha256=hashlib.sha256(payload).hexdigest()))
logical = sum(record['bytes'] for record in files)
allocated = sum(source.stat().st_blocks * 512 for source in ROOT.rglob('*') if source.is_file())
free = shutil.disk_usage(ROOT).free
if now >= DEADLINE or max(logical, allocated) + 32768 > 2 * 1024**2 or free <= 16 * 1024**3:
    raise RuntimeError(dict(utc=now.isoformat(), logical=logical, allocated=allocated, free=free))
seal = dict(review='Review144', utc=now.isoformat(), deadline_utc=DEADLINE.isoformat(), elapsed_seconds=(now - datetime.datetime.fromisoformat('2026-11-08T19:56:53+00:00')).total_seconds(), source_receipt_only=True, compiler_slot_used=False, within_15minutes=True, logical_bytes_before_seal=logical, allocated_bytes_before_seal=allocated, free_bytes=free, scratch_limit_bytes=2 * 1024**2, files=files)
payload = (json.dumps(seal, indent=2) + '\n').encode()
(ROOT / 'SEAL.json').write_bytes(payload)
digest = hashlib.sha256(payload).hexdigest()
(ROOT / 'SEAL.sha256').write_text(digest + '  SEAL.json\n')
print(json.dumps(dict(seal_sha256=digest, report_sha256=next(record['sha256'] for record in files if record['path']=='REPORT.md'), utc=seal['utc'], elapsed_seconds=seal['elapsed_seconds'], logical_bytes_including_seal=sum(source.stat().st_size for source in ROOT.rglob('*') if source.is_file()), free_bytes=free, files=len(files)), indent=2))
