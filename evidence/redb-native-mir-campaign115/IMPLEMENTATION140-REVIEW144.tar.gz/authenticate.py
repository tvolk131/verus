import datetime
import hashlib
import json
import pathlib
import sys
import tarfile

ROOT = pathlib.Path('/private/tmp/implementation140-20261108-RdrUQDUb')
WORKSPACE = pathlib.Path('/Users/tommyvolk/.t3/worktrees/verus/t3-60978068')
SCRATCH = pathlib.Path('/private/tmp/review144-20261108-zvUvswJB')

def digest(data):
    return hashlib.sha256(data).hexdigest()

phase = sys.argv[1]
records = []
failures = []
for label, base, inventory in [('sealed', ROOT, 'SEAL.json'), ('candidate', ROOT / 'candidate', 'candidate-final.json')]:
    entries = json.loads((ROOT / inventory).read_text())
    for entry in entries:
        source = base / entry['path']
        try:
            data = source.read_bytes()
            observed = digest(data)
            matched = len(data) == entry['bytes'] and observed == entry['sha256']
            records.append({'group': label, 'path': str(source), 'bytes': len(data), 'sha256': observed, 'matched': matched})
            if not matched:
                failures.append(str(source))
        except Exception as error:
            failures.append({'path': str(source), 'error': repr(error)})
for name in ['AUTHORIZATION139.md', 'FIRST-CELL139.md', 'NEXT-NATIVE-LOWERING143.md', 'IMPLEMENTATION140-HANDOFF.json', 'PRIMITIVE141-REVIEW142.json', 'IMPLEMENTATION140-HANDOFF.tar.gz']:
    source = WORKSPACE / 'evidence/redb-native-mir-campaign115' / name
    data = source.read_bytes()
    records.append({'group': 'workspace', 'path': str(source), 'bytes': len(data), 'sha256': digest(data)})
for name in ['SEAL.json', 'candidate-final.json']:
    source = ROOT / name
    data = source.read_bytes()
    records.append({'group': 'inventory', 'path': str(source), 'bytes': len(data), 'sha256': digest(data)})
archive_count = 0
archive_bytes = 0
with tarfile.open(WORKSPACE / 'evidence/redb-native-mir-campaign115/IMPLEMENTATION140-HANDOFF.tar.gz') as archive:
    names = set()
    for member in archive.getmembers():
        if not member.isfile():
            failures.append({'archive_nonregular': member.name})
            continue
        if member.name in names:
            failures.append({'archive_duplicate': member.name})
        names.add(member.name)
        payload = archive.extractfile(member).read()
        source = ROOT / member.name
        if not source.exists() or payload != source.read_bytes():
            failures.append({'archive_mismatch': member.name})
        archive_count += 1
        archive_bytes += len(payload)
result = {'phase': phase, 'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'records': records, 'archive_members': archive_count, 'archive_payload_bytes': archive_bytes, 'failures': failures, 'artifact_target_inventory_authenticated': False}
(SCRATCH / ('authentication-' + phase + '.json')).write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: value for key, value in result.items() if key != 'records'}, indent=2))
print('record_counts', {label: sum(record['group'] == label for record in records) for label in ['sealed', 'candidate', 'workspace', 'inventory']})
