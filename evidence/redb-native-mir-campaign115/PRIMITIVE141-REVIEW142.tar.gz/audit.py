import datetime
import hashlib
import json
import pathlib
import shutil
import sys

WORKSPACE = pathlib.Path('/Users/tommyvolk/.t3/worktrees/verus/t3-60978068')
CANDIDATE = pathlib.Path('/private/tmp/redb-native-contract141-20261108-t1kLSjW6')
SCRATCH = pathlib.Path(__file__).parent

def digest(path):
    state = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(65536), b''):
            state.update(chunk)
    return state.hexdigest()

def manifest(name, root):
    rows = []
    for line in (CANDIDATE / name).read_text().splitlines():
        expected, relative = line.split(None, 1)
        path = pathlib.Path(relative)
        if not path.is_absolute():
            path = root / path
        observed = digest(path)
        rows.append({'path': str(path), 'expected': expected, 'observed': observed, 'match': expected == observed})
    return rows

phase = sys.argv[1]
inputs = manifest('INPUTS.sha256', WORKSPACE)
seal = manifest('SEAL.sha256', CANDIDATE)
selected = sorted(set([str(path) for path in CANDIDATE.iterdir() if path.is_file()] + [row['path'] for row in inputs] + [str(WORKSPACE / name) for name in ['source/vir/src/ast.rs', 'source/vir/src/ast_util.rs', 'source/vir/src/native_resource.rs', 'evidence/redb-native-mir-campaign115/AUTHORIZATION139.md', 'evidence/redb-native-mir-campaign115/FIRST-CELL139.md', 'evidence/redb-native-mir-campaign115/RESOURCE-BOUNDARY135.md', 'evidence/redb-native-mir-campaign115/LOCAL-PINNED-LIBRARY128.json']]))
selected.append(str(WORKSPACE / 'evidence/redb-crash-consistency94/SCOPE.md'))
observation = {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'phase': phase, 'free_bytes': shutil.disk_usage(SCRATCH).free, 'inputs': inputs, 'seal': seal, 'selected': {path: digest(pathlib.Path(path)) for path in selected}}
if observation['free_bytes'] <= 16 * 1024 ** 3:
    raise SystemExit('STOP: free disk at or below 16 GiB')
if phase == 'after':
    before = json.loads((SCRATCH / 'before.json').read_text())
    observation['unchanged'] = observation['selected'] == before['selected']
(SCRATCH / (phase + '.json')).write_text(json.dumps(observation, indent=2) + '\n')
print(json.dumps({'utc': observation['utc'], 'input_records': len(inputs), 'seal_records': len(seal), 'all_match': all(row['match'] for row in inputs + seal), 'selected': len(selected), 'free_bytes': observation['free_bytes'], 'unchanged': observation.get('unchanged')}, indent=2))
