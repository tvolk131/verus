import datetime
import hashlib
import json
import pathlib
import shutil

SCRATCH = pathlib.Path(__file__).parent
now = datetime.datetime.now(datetime.timezone.utc)
deadline = datetime.datetime(2026, 11, 8, 19, 46, 3, tzinfo=datetime.timezone.utc)
free_bytes = shutil.disk_usage(SCRATCH).free
before = json.loads((SCRATCH / 'before.json').read_text())
after = json.loads((SCRATCH / 'after.json').read_text())
static = json.loads((SCRATCH / 'STATIC-CUSTODY.json').read_text())
assert after['unchanged'] and before['selected'] == after['selected']
assert all(row['match'] for row in after['inputs'] + after['seal'])
assert all(static['supplied_observations_match'].values())
assert static['source_members'] == 12 and static['ancillary_members'] == 12
assert static['all_source_equal'] and static['all_ancillary_expected'] and static['patch_source_equal']
assert now < deadline and free_bytes > 16 * 1024 ** 3
payload_bytes = sum(path.stat().st_size for path in SCRATCH.iterdir() if path.is_file())
assert payload_bytes + 65536 < 1024 ** 2
accounting = {'utc': now.isoformat(), 'entry_utc': '2026-11-08T19:31:03Z', 'deadline_utc': deadline.isoformat(), 'elapsed_seconds': (now - datetime.datetime(2026, 11, 8, 19, 31, 3, tzinfo=datetime.timezone.utc)).total_seconds(), 'free_bytes': free_bytes, 'free_strictly_above_16GiB': True, 'payload_bytes_before_accounting_and_seal': payload_bytes, 'reserved_accounting_and_seal_bytes': 65536, 'fresh_scratch_limit_bytes': 1048576, 'selected_input_count': len(after['selected']), 'selected_inputs_unchanged': True, 'compiler_build_verifier_native_application_commands': 0, 'adopted_laws': 0, 'all18': 'OPEN', 'historical_failures_allowances_and_interrupted116': 'PRESERVED'}
(SCRATCH / 'ACCOUNTING.json').write_text(json.dumps(accounting, indent=2) + '\n')
entries = []
for path in sorted(SCRATCH.iterdir()):
    if path.is_file() and path.name != 'SEAL.sha256':
        entries.append(hashlib.sha256(path.read_bytes()).hexdigest() + '  ' + path.name + '\n')
seal = SCRATCH / 'SEAL.sha256'
seal.write_text(''.join(entries))
for line in seal.read_text().splitlines():
    expected, name = line.split(None, 1)
    assert hashlib.sha256((SCRATCH / name).read_bytes()).hexdigest() == expected
total = sum(path.stat().st_size for path in SCRATCH.iterdir() if path.is_file())
assert total <= 1048576
print(json.dumps({'seal_sha256': hashlib.sha256(seal.read_bytes()).hexdigest(), 'seal_records': len(entries), 'fresh_scratch_bytes': total, 'elapsed_seconds': accounting['elapsed_seconds'], 'free_bytes': free_bytes, 'all_seal_records_match': True, 'all49_selected_inputs_unchanged': True}, indent=2))
