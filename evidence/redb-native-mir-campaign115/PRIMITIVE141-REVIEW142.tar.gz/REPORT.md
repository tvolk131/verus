# Review142 — candidate141, SOURCE ONLY

## Disposition

**NOT ADOPTED. Needs correction as a consumable contract API; several equations
are acceptable NECESSARY-RELATION proposals, not sufficient native laws.** No
compiler, Cargo, tests, observer, proof, solver or native application was run.
No task140 inspection/polling, network, Git writes, integration, candidate/parent
edits, goal operations, delegation or automatic successor chain occurred.

The original two-phase acknowledged-durability target is unchanged. All eighteen
campaign94 cells remain OPEN; native/resource/trust/proof credit added: 0/0/0/0.
The seven unresolved gates in the candidate are real blockers, not established
bindings. This review does not authorize adoption by itself.

## Anchor key and exact inputs

- `C` = `/private/tmp/redb-native-contract141-20261108-t1kLSjW6/primitive_contract141.rs`.
- `L` = the same candidate root's `LAW-API.md`.
- `V` = `/Users/tommyvolk/.t3/worktrees/verus/t3-60978068/source/vir/src`.
- `N` = `/private/tmp/redb-original-crate-preflight115/redb`.
- `P` = `/private/tmp/verus-pinned-rust-source-20261107-9FT58F/rust-src-1.99.1/rust-src/lib/rustlib/src/rust/library`.

Anchors below give original line numbers; `RAW-SOURCE.txt` retains numbered
excerpts under full paths, including the complete candidate source and law/API.
Applicable workspace/native/library instruction discovery was read-only. The
native AGENTS.md explicitly exempts report-only analysis from its test command.
AUTHORIZATION139, FIRST-CELL139, RESOURCE-BOUNDARY135, LOCAL-PINNED-LIBRARY128 and
campaign94 SCOPE.md were read. The local pinned source selection is not upstream
authentication, compiler/source correspondence or bootstrap correspondence.

Authenticated 35 INPUTS records with workspace-relative evidence/source paths
and 11 candidate-relative SEAL records. Selected-file observations are current,
not historical custody pins. Selected exact observations:

| Object | SHA256 |
| --- | --- |
| C | 274ed75b881582250cbacd04f93b1e531413b87b0762143260e47b735520e0a5 |
| LAW-API.md | 6d6703c3bef951d4ee2f29d52fa2361f0477d2b1323d0ef05a2689854d45c9ea |
| candidate REPORT.md | 78aa00a013e11950e3c5a6bbb04ad9bc709b4772ab4b05124db0cb33a0d3d4ae |
| candidate SEAL.sha256 | ebd0bdd81b9146c5aabfb13ff7e68371969c4cbd16870bba3a892aa223ba58e2 |
| candidate141.tar.gz | 553b0f71c14dd56c4d0e5297944ca31ef7381ee2de5b6ba03f8d7dcf775ec464 |

Archive was streamed, not extracted: 12 source members byte-equal to candidate
files, plus 12 regular 163-byte AppleDouble companions, all ancillary hash
764baba3ef7595c2cf3f4d77d2bed7777f3054ff173ee03e153c5bb6db0e6094.
The patch's additive source hunk equals C byte-for-byte. This establishes no
successful patch application or build.

## Findings and explicit source challenges

Severity is relative to future contract consumption/adoption. **There is no
installed unsound law or present native acceptance exploit:** the patch is not
applied, no relation is installed, and L:214 explicitly rejects adoption as-is.

### R142-1 — HIGH: caller formulas can vacate coverage or propose falsehood

**C:119, C:133, C:153, C:483.** Candidate::obligations validates labels and
top-level types, not the meaning of caller-supplied edge, completeness or
primitive formulas. It does not inspect TypedInstance's API/signature/owner or
optional producer keys. Missing keys become strings in `unresolved`, not Err.

Source challenge, not runtime reproduction: choose AtomicBoolNew, one Normal
successor with selector=false, completeness=true, empty input/caller/relation
vectors, empty frame views and frame predicates=true. Required-label checking
passes, checked implications are tautologies, yet no edge is selected. With
selector=true and primitive_relation=[false], the same interface instead emits
the proposed assumption true=>false with no corresponding false checked goal.
Duplicate/overlapping successors and API-inappropriate extra outcome tags also
are not rejected. Thus proving the returned checked vector cannot authenticate
the proposed vector or actual outcome completeness.

**Objection tested:** these are explicitly uninstalled schemas (L:14, L:139).
Agreed: this is a blocker to later consumption, not evidence of current verifier
unsoundness. Fix by deriving an exact per-API relation/outcome family internally,
generating its partition obligations, and binding those to actual CFG edges;
do not adopt arbitrary Expr vectors as if they were the reviewed family.

### R142-2 — HIGH: real VIR nodes need not be well-typed VIR expressions

**C:195, C:201, C:225, C:292; V/ast_util.rs:616.** Actual AST variants/signatures
used for SpecFn, Quant, FnSpec, arithmetic and affine Transfer are recognizable
in the baseline (V/ast.rs:279, :1032, :1057, :1125; native_resource.rs:45).
No definite Rust compilation error is asserted; Rust compatibility is UNBUILT.
But require_type reads only the node's attached type, not its operands/scope.

Source challenge: give arc_get_mut_relations a bool-typed observed_strong. It
builds Eq(bool,int(1)), labels the result bool, embeds it in another bool node,
and obligations accepts the outer type. Likewise an int-typed trigger supplied
to conditional_release_acquire becomes an ill-typed implication labelled bool.
apply checks a SpecFn type synthesized FROM argument types, not canonical types
for native event IDs. Identity fields are unconstrained Exprs; loan projection
constructs int locals without checking their actual declarations.

**Objection tested:** using the existing AST constructors provides representation
compatibility, not recursive well-formedness. The baseline mk_eq simply stamps
bool; it performs no operand check. Fix with typed, scope-aware constructors or
the normal VIR well-formedness pass over generated formulas, including canonical
view/event/identity sorts, before exposing a successful contract result.

### R142-3 — HIGH: resource/loan conservation is described, not generated

**C:66, C:72, C:157, C:447, C:497.** obligations never lowers consumed/retained/
produced ports into a global ledger, never calls loan_projection_relations,
and never checks exact_loan_edges, origin/port consistency, receiver suspension,
activation order, lifetime ends, or writeback. None can produce ByteAuthority
or MutableLoan ports through affine.produced while returning no ReturnedLoan;
the None check rejects only returned_loans. Some accepts one MutableLoan with
arbitrary int bounds (including inverted/negative times), arbitrary place and
unrelated suspended receiver. Normal ArcDeref/GuardDerefMut need no loan at all.
PoisonedAcquired requires merely an arbitrary port tagged PoisonErrorGuard;
Acquired does not even require an output guard tag.

**Objection tested:** Port::Clone is legitimately syntax duplication, and L:108
admits a missing global ledger. Correct, but no non-forgeable authority follows
from the syntax. Existing V/native_resource.rs:179 checks one live slot and ten
immutable typed parameters; :253 transfers it, and :306 admits only empty static
monomorphic unit fixtures. transport_projection cannot certify issuance,
multiple live resources, loan splitting or native mutation.

Arc count=1 does not discharge an actual shared borrow, construct a byte view,
prove receiver exclusivity, or return suspended authority. Native [u8] writeback
must be tied to the exact returned place and lifetime. These remain checked
producer/ledger obligations, never new caller-invariant axioms.

### R142-4 — MEDIUM: caller-selected quantified binders can capture evidence

**C:233, C:282, C:401, C:416.** Quantifiers bind a supplied VarIdent with no
freshness check or alpha-renaming against input free variables. In
inventory_delta let handle be Var(k), and also pass binder=k. The selected test
becomes k=k under forall k. Insert then says *all* integers are members; remove
says *no* integer is a member, instead of deleting exactly the selected handle.
This changes even correctly typed intended relations, not just error reporting.
The atomic quantifiers similarly can capture length/event/history operands.

**Objection tested:** a later hygienic producer could avoid the issue. That is
not a precondition enforced or documented by the current public helpers. Allocate
a fresh compiler-local binder disjoint from every input free variable, or reject
collisions explicitly. Do not add binder freshness as a trusted native law.

### R142-5 — HIGH: scalar atomic relations admit non-executions by design

**C:381, C:416, C:429, C:478, C:514.** The load lower bound and read-read
monotonicity are useful necessary constraints. Strong-CAS success uses the last
predecessor MO index and expected equality; failure requires inequality and does
not invent spurious failure or force freshness. Those are good choices, NOT a
complete memory model. No checked definition enforces event uniqueness, object-
linked total MO, real program-order/HB closure, read-write/write-write coherence,
legal RF, release-sequence membership or source/intrinsic execution refinement.

Source challenge: a total history [init=false, later_store=true], a load L
sequenced before later_store W, RF=1, returned=true, and HB(L,W) satisfies the
emitted load lower bounds if no write HB-precedes L. It is not a legal RF choice
for that same-thread future store. A caller-supplied well-formedness=true does
not fix this. B-HB can also be fed trigger=true and unrelated object events; the
helper has no object parameters and will emit the supplied HB edge. Similarly,
read_read_coherence requires a same-object binding absent from its parameters.

**Objection tested:** L:135 explicitly calls these necessary relations and leaves
the full execution relation open. Agreed: this is insufficiency, not a refutation
of the necessary inequalities on legal histories. Adoption must be conditional
on an ACTUALLY CHECKED event/object/execution relation, not an arbitrary boolean
assertion of legality. Native std_specs/atomic.rs:5 presently supports ordering
legality, not stored-value/history reasoning. The selected target must also bind
AtomicBool's intrinsic versus emulated code path (P/core/src/sync/atomic.rs:402,
:955); no native target linkage is established by the host or source digest.

### R142-6 — HIGH: frame ownership and temporal endpoints are unbound

**C:85, C:145, C:368, C:466.** Any same-typed pair in owned_disjoint_views becomes
a proposed equality; no generated goal proves ownership, disjointness, scope or
coverage. guard_completed_drop_relations has no actual caller-thread check or
release/synchronization event; its poison/context inputs are raw Expr/scalars.
Returned accessors preserve payload only at access, not across use of the
returned &mut reference. The schema does not enforce that distinction or a
loan-end native post-mutation view.

**Objection tested:** L:116 correctly places equations at linearization/prefix
endpoints and asks for a checked interference trace. Therefore released.held=false
is acceptable at the unlock event, NOT as an unconditional state at destructor
return: another permitted actor can acquire after unlock. Similarly bytes are
unchanged by get_mut/deref themselves, not by the later slice mutation. Keep
this endpoint-scoped interpretation; derive the environment/ownership/loan-end
obligations from actual places/events instead of assuming frame predicates.

## Outcomes, poison and partial effects: what survived challenge

- P/alloc/src/sync.rs:2819 does strong weak-counter CAS 1->MAX, observes strong
  with Acquire only on success, and restores weak=1 with Release. Some iff those
  actual observations establish uniqueness is a reasonable proposed partition;
  fabricated observations are not sufficient. None reaches native mem_mut's
  unwrap panic (N/cached_file.rs under src/tree_store/page_store:35).
- Arc clone's comparison is strictly old_size>MAX_REFCOUNT AFTER fetch_add
  (P/alloc/src/sync.rs:2417). Normal old=MAX is not rejected; modulo overflow is
  an abort-dispatch PREFIX, not a proved finite terminal outcome. No weak-CAS
  progress or panic-hook termination is inferred.
- Final Arc drop is an intermediate handoff, not completed destruction:
  P/alloc/src/sync.rs:2868 uses Release then an acquire step; :2138 arranges the
  implicit weak cleanup around actual payload drop. Final handoff must compose
  checked payload/drop-glue/cleanup/deallocation including unwind/abort/nonreturn.
  Thus absence of ArcDrop Unwind as a separate *handoff* label is not itself a
  false totality law. Treating that handoff as completed native drop WOULD be.
- P/std/src/sync/poison/mutex.rs:490 locks BEFORE constructing the guard;
  :719 maps a poisoned result into a guard-owning PoisonError. Err is not
  non-acquisition. Native discarded poisoned try_lock Err at cached_file.rs:868
  and :938 still owns cleanup; unwrap, hooks and cleanup may not complete.
- Guard drop performs poison.done then unlock (mutex.rs:743). poison.rs:125
  justifies prior_poison OR (!acquire_panicking AND drop_panicking) for that
  selected unwind std cfg and the relevant interference-free step; abort-only
  std get() returns false (:143). This is not payload rollback, no-poison
  ownership, guaranteed unlock on every prefix, or finite destructor completion.
  pthread lazy initialization allocates/initializes (sys/sync/mutex/pthread.rs:19),
  PAL has panic paths, and reentrant locking can fail to return. Exact cfg and
  runtime binding remain OPEN. A leaked guard is not an unlocked mutex.
- Native return_value's replace precedes its assert (cached_file.rs:91): existing
  Some(old) means the new value has already been installed when the assertion
  fails; missing entry instead panics before replacement. Retain both prefixes.
  A poisoned mutex does not restore the former cache state.

## Per-law disposition — NONE ADOPTED

“Acceptable proposal” below means the scoped necessary relation/prose survived
source objections, NOT an installed law, proven native binding or typechecked API.

| Law / API | Disposition and limiting obligation |
| --- | --- |
| A-read / ArcDeref | Acceptable proposal; insufficient implementation: actual shared loan, ownership, interior-mutability/frame scope and end must be generated (R3/R6). |
| A-get_mut / ArcGetMut | Acceptable observation/Option partition; API needs correction (R1/R2/R3). Exact inventory, byte authority, actual CAS/load history and returned-reference lifetime are still required. |
| A-clone / ArcCloneGlobal | Acceptable normal/overflow-prefix proposal at Global; binder/type/ledger corrections needed (R2/R3/R4). MAX and modulus must bind target constants, not caller numbers. |
| A-retire / ArcDrop | Acceptable nonfinal and final-handoff proposal; insufficient for destructor completion, synchronization, deallocation or loan accounting (R3/R6). |
| M-new / MutexNew | Acceptable unheld/unpoisoned payload proposal; fresh object identity and consumed owned payload are not implemented (R3). Native cache constructor remains checked. |
| M-acquire / MutexLock | Acceptable normal/poison/prefix proposal; insufficient exact guard ownership, legal environment state, actual outcomes and lock visibility (R1/R3/R6). |
| M-acquire / MutexTryLock | Same; WouldBlock must issue no authority, poisoned Err cleanup must remain owned. Labels alone are insufficient. |
| M-access / GuardDeref | Acceptable access-instant projection; missing actual shared loan and suspension/end correspondence (R3/R6). |
| M-access / GuardDerefMut | Acceptable access-instant projection; missing exclusive loan and actual mutable writeback, not a whole-borrow unchanged-payload law (R3/R6). |
| M-release / GuardDrop | Acceptable selected-cfg poison/completed-unlock step; insufficient same-thread guard consumption, synchronization, interference and prefix composition (R3/R6). |
| B-init / AtomicBoolNew | Acceptable initialization equations; insufficient fresh identity, actual init event, history ownership and canonical operand typing (R2/R5). |
| B-store / AtomicBoolStoreRelease | Acceptable MO append necessary relation at the real store event; requires hygiene, object history and release-event binding (R4/R5). |
| B-load / AtomicBoolLoadAcquire | Acceptable necessary RF/value/lower-bound/read-read constraints; explicitly INSUFFICIENT legal-execution model (R5). |
| B-CAS / AtomicBoolCompareExchangeAcqRelAcquire | Acceptable strong success/failure necessary constraints for the bound semantics; insufficient native execution/order/RF binding (R2/R5). No weak progress or latest-failure requirement. |
| B-HB / conditional_release_acquire | Acceptable mathematical conditional only when the antecedent is derived from actual same-object Release/RF/Acquire or applicable sequence; raw-boolean API needs correction (R1/R2/R5). |
| transport_projection / frame and loan schema | Insufficient native/resource law; not an issuance, mutation, complete ledger or native correspondence certificate (R3/R6). |

## Smallest implementation delta that actually removes a first-cell dependency

No scalar-equation-only repair to141 removes a native dependency. Do NOT spend
the next slot on more diagnostic variants or treat a successful build as proof.

The smallest useful source-connected vertical slice is **the real
WritablePage::mem_mut/get_mut/unwrap -> returned mutable slice -> the actual
write_header copy byte events**, not a new wrapper or application summary:

1. Replace freely assembled ArcGetMut candidates with a compiler-owned builder
   for the exact [u8],Global instance, actual receiver place/activation, Some/None
   and unwrap/panic/cleanup edges. Validate generated VIR types and bind true
   source loans, not span guesses, e78/local20 constants or arbitrary ProducerKey
   placeholders. Derive partition and owned frame obligations internally.
2. Extend the existing resource lowering only enough to consume the real byte
   authority, suspend the receiver, issue the returned native &mut [u8] loan and
   restore the SAME capability with post-copy native bytes at the actual loan
   end. Count/inventory and a separate int bounds tuple cannot substitute for
   this checked memory/event link.
3. Discharge the incoming authority at actual native construction/checkout:
   zero-filled OR reused allocation, complete handle/loan accounting, native
   take_value/get_mut writeback and the reserved Option=None entry. If this
   producer obligation is still assumed, report a conditional local result,
   NOT removal of the first-cell native dependency. No new trusted cache or
   caller-invariant law is permissible.

Once that checked slice exists, the next application dependency remains the
reservation through unlock/reentry and WritablePage::drop's cache return, then
actual buffer/flush/barrier/public-acknowledgement/recovery/history composition.
Native LRU/maps/FastHasher64, constructors, RwLock/integer accounting, callbacks
and backend bodies remain checked throughout. Header overwrite does not erase
write's reused-page, pressure/eviction or backend paths (cached_file.rs:881).
Cached return_value/clone/drop is not persistence. Header IDs/payload labels do
not prove physical-root reachability or logical key/value refinement.

Backend close stores C then F before its callback (cached_file.rs:207); ordinary
I/O errors latch F only after callbacks return (:224, :242, :251), best-effort
write does not (:263). Thus F=true need not mean closed, false observations are
not authorization reservations, callback unwind/nonreturn can skip latching,
and Err is not rollback. All of these remain native checked dependencies.

## Bounds, continuity and preserved history

Review began with 2026-11-08T19:31:03Z clock observation; absolute deadline is
19:46:03Z. Free disk was >16 GiB on entry and every recorded accounting check.
Only fresh scratch artifacts were authored using apply_patch; raw digests and
numbered source excerpts were generated by bounded read-only Python helpers.
Fresh scratch must remain <=1 MiB including seal. No archive extraction.

Two local audit setup failures are preserved in OPERATIONS.md; neither is a
candidate build/proof result. Initial successful 48-file hash observation was
19:32:33.910422Z. The selected baseline was extended to49 to include campaign94
SCOPE before reading that scope at19:35:00.982668Z; before.json records that
extended current observation. Candidate source's first excerpt preceded the
first successfully persisted audit JSON; this is not retroactive pre-read
custody. All35+11 manifest digests had been computed in the earlier failed
attempt before its supplemental missing-path error. Final after.json explicitly
compares all49 selected hashes to the extended baseline.

Historical failures/exhausted allowances, unavailable Git continuity,
unestablished bootstrap correspondence and interrupted116 (without its final
handoff) are preserved, not reset or repaired. No status claim about140 is made
beyond the supplied sole-slot ownership instruction. Stop at the sealed handoff.
