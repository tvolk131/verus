import hashlib
import json
import pathlib
import tarfile

SCRATCH = pathlib.Path(__file__).parent
CANDIDATE = pathlib.Path('/private/tmp/redb-native-contract141-20261108-t1kLSjW6')
WORKSPACE = pathlib.Path('/Users/tommyvolk/.t3/worktrees/verus/t3-60978068')
LIBRARY = pathlib.Path('/private/tmp/verus-pinned-rust-source-20261107-9FT58F/rust-src-1.99.1/rust-src/lib/rustlib/src/rust/library')
NATIVE = pathlib.Path('/private/tmp/redb-original-crate-preflight115/redb')
selections = [
    (CANDIDATE / 'primitive_contract141.rs', [(1, 517)]),
    (CANDIDATE / 'LAW-API.md', [(1, 228)]),
    (CANDIDATE / 'REPORT.md', [(1, 100)]),
    (CANDIDATE / 'VALIDATION-PLAN.md', [(1, 100)]),
    (WORKSPACE / 'source/vir/src/ast.rs', [(95, 103), (270, 285), (584, 642), (735, 766), (1024, 1040), (1056, 1059), (1110, 1136)]),
    (WORKSPACE / 'source/vir/src/ast_util.rs', [(154, 174), (571, 575), (604, 629)]),
    (WORKSPACE / 'source/vir/src/native_resource.rs', [(1, 74), (156, 228), (244, 274), (306, 342)]),
    (WORKSPACE / 'source/vstd/std_specs/atomic.rs', [(1, 80)]),
    (NATIVE / 'src/tree_store/page_store/cached_file.rs', [(17, 115), (130, 147), (195, 266), (320, 354), (640, 647), (858, 978)]),
    (NATIVE / 'src/tree_store/page_store/page_manager.rs', [(1615, 1629)]),
    (NATIVE / 'src/tree_store/page_store/lru_cache.rs', [(1, 107)]),
    (NATIVE / 'src/tree_store/page_store/fast_hash.rs', [(1, 49)]),
    (NATIVE / 'src/sync.rs', [(1, 12)]),
    (LIBRARY / 'alloc/src/sync.rs', [(2136, 2150), (2403, 2455), (2671, 2684), (2811, 2833), (2863, 2913)]),
    (LIBRARY / 'std/src/sync/poison/mutex.rs', [(490, 495), (539, 547), (718, 748)]),
    (LIBRARY / 'std/src/sync/poison.rs', [(98, 145)]),
    (LIBRARY / 'std/src/sys/sync/mutex/pthread.rs', [(18, 70)]),
    (LIBRARY / 'std/src/sys/pal/unix/sync/mutex.rs', [(45, 98)]),
    (LIBRARY / 'core/src/sync/atomic.rs', [(25, 58), (394, 407), (908, 942), (954, 999)]),
    (WORKSPACE / 'evidence/redb-crash-consistency94/SCOPE.md', [(1, 180)]),
    (WORKSPACE / 'evidence/redb-native-mir-campaign115/AUTHORIZATION139.md', [(1, 150)]),
    (WORKSPACE / 'evidence/redb-native-mir-campaign115/FIRST-CELL139.md', [(1, 150)]),
    (WORKSPACE / 'evidence/redb-native-mir-campaign115/RESOURCE-BOUNDARY135.md', [(1, 150)]),
]
with (SCRATCH / 'RAW-SOURCE.txt').open('w') as output:
    for path, ranges in selections:
        output.write('\n=== ' + str(path) + ' ===\n')
        lines = path.read_text().splitlines()
        for start, end in ranges:
            for number in range(start, min(end, len(lines)) + 1):
                output.write(str(number) + ': ' + lines[number - 1] + '\n')
with tarfile.open(CANDIDATE / 'candidate141.tar.gz', 'r:gz') as archive:
    rows = []
    for member in archive.getmembers():
        if member.isfile():
            data = archive.extractfile(member).read()
            basename = pathlib.Path(member.name).name
            ancillary = basename.startswith('._')
            corresponding = CANDIDATE / basename
            rows.append({'member': member.name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'ancillary_appledouble': ancillary, 'source_equal': None if ancillary else corresponding.is_file() and data == corresponding.read_bytes()})
(SCRATCH / 'ARCHIVE.json').write_text(json.dumps(rows, indent=2) + '\n')
patch_lines = (CANDIDATE / 'candidate.patch').read_text().splitlines(keepends=True)
start = patch_lines.index('@@ -0,0 +1,517 @@\n') + 1
added = ''.join(line[1:] for line in patch_lines[start:] if line.startswith('+'))
pins = {'primitive_contract141.rs': '274ed75b881582250cbacd04f93b1e531413b87b0762143260e47b735520e0a5', 'LAW-API.md': '6d6703c3bef951d4ee2f29d52fa2361f0477d2b1323d0ef05a2689854d45c9ea', 'REPORT.md': '78aa00a013e11950e3c5a6bbb04ad9bc709b4772ab4b05124db0cb33a0d3d4ae', 'SEAL.sha256': 'ebd0bdd81b9146c5aabfb13ff7e68371969c4cbd16870bba3a892aa223ba58e2', 'candidate141.tar.gz': '553b0f71c14dd56c4d0e5297944ca31ef7381ee2de5b6ba03f8d7dcf775ec464'}
summary = {'source_members': sum(not row['ancillary_appledouble'] for row in rows), 'ancillary_members': sum(row['ancillary_appledouble'] for row in rows), 'all_source_equal': all(row['source_equal'] for row in rows if not row['ancillary_appledouble']), 'all_ancillary_expected': all(row['bytes'] == 163 and row['sha256'] == '764baba3ef7595c2cf3f4d77d2bed7777f3054ff173ee03e153c5bb6db0e6094' for row in rows if row['ancillary_appledouble']), 'supplied_observations_match': {name: hashlib.sha256((CANDIDATE / name).read_bytes()).hexdigest() == expected for name, expected in pins.items()}, 'patch_source_equal': added == (CANDIDATE / 'primitive_contract141.rs').read_text(), 'raw_source_bytes': (SCRATCH / 'RAW-SOURCE.txt').stat().st_size}
(SCRATCH / 'STATIC-CUSTODY.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2))
