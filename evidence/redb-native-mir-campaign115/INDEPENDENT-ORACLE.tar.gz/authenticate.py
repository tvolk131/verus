"""Read-only independent authentication; prints a record, never writes files."""

import datetime
import hashlib
import json
import os
from pathlib import Path
import sys

ROOT = Path("/private/tmp/redb-compiler-validation114-worker-20261108T151020Z")
REVIEW = Path("/private/tmp/redb-compiler-validation114-review-20261108T152149Z-independent")
PARENT = Path("/Users/tommyvolk/.t3/worktrees/verus/t3-60978068")
EXPECTED_MANIFEST = "c73d2fba54d4144d3705d78a6d5d6cf9d29bf5eaeeb80dce6d9736fd001d6dd9"
EXPECTED_SOURCE = "c9cb297436ab24053c254ed95bd4e520ef6fca5b86832d217b37302cb5ad7b23"
EXPECTED_REVIEW = "4d44e481b849531f15b77a9eeadd568da5bc022400182d859d2da47881ae9e97"
USED = ["snapshot/source/rust_verify/src/checked_normal_drop.rs",
        "snapshot/source/rustc_mir_build/src/builder/checked_drop_origins.rs",
        "snapshot/source/rustc_mir_build/src/builder/expr/as_temp.rs",
        "snapshot/source/rust_verify/src/driver.rs", "snapshot/source/rust_verify/src/verifier.rs",
        "command-1.source-before.json", "REPORT.md"]
PARENT_INPUTS = {
    "evidence/redb-native-mir-campaign115/AUTHORIZATION.md": "b6d5d80d330c1124ead5af0b9cb1f0188532513ec630676871b4ce0099e1bf0c",
    "evidence/redb-native-mir-campaign115/PLAN.md": "422c3e734f0f7b26d47e53603b39be2d815d4a790533371fb726614ec0f779a3",
    "evidence/redb-writablepage-lifecycle113/CORRESPONDENCE-CUTS.md": "2043a20ed9cee2e8951a27b24ed4aef4ab759b31eb7464b9007098f02320a8b5",
}


def metadata(path):
    before = path.stat()
    hasher = hashlib.sha256()
    total = 0
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(65536), b""):
            total += len(chunk)
            hasher.update(chunk)
    after = path.stat()
    if (before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns) != (
            after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns):
        raise ValueError("changed while hashing: " + str(path))
    return {"bytes": total, "sha256": hasher.hexdigest()}


def main():
    failures = []
    records = []

    def check(path, expected, label):
        observed = metadata(path)
        match = observed["sha256"] == expected["sha256"] and (
            "bytes" not in expected or observed["bytes"] == expected["bytes"])
        records.append({"path": str(path), **observed, "matches": match, "authority": label})
        if not match:
            failures.append(str(path))

    check(ROOT / "SEALED-MANIFEST.json", {"sha256": EXPECTED_MANIFEST}, "user-pinned manifest")
    manifest = json.loads((ROOT / "SEALED-MANIFEST.json").read_bytes())
    indexed = {record["path"]: record for record in manifest["records"]}
    for relative in USED:
        check(ROOT / relative, indexed[relative], "sealed worker manifest")
    check(REVIEW / "CONTENT-MANIFEST.json", {"sha256": EXPECTED_REVIEW}, "entry observed review manifest")
    review = json.loads((REVIEW / "CONTENT-MANIFEST.json").read_bytes())
    review_index = {record["path"]: record for record in review["records"]}
    for relative in ("REPORT.md", "entry-authentication.json"):
        check(REVIEW / relative, review_index[relative], "independent review manifest")
    for relative, expected in PARENT_INPUTS.items():
        check(PARENT / relative, {"sha256": expected}, "entry observed parent document (not source baseline)")
    inventory = json.loads((ROOT / "command-1.source-before.json").read_bytes())
    source_records = []
    source_bytes = 0
    for expected in inventory["records"]:
        observed = metadata(ROOT / "snapshot" / expected["path"])
        source_bytes += observed["bytes"]
        source_records.append({"path": expected["path"], **observed})
        if observed != {key: expected[key] for key in ("bytes", "sha256")}:
            failures.append("snapshot/" + expected["path"])
    fingerprint = hashlib.sha256(json.dumps(source_records, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
    if fingerprint != EXPECTED_SOURCE or inventory["fingerprint"] != EXPECTED_SOURCE:
        failures.append("snapshot aggregate fingerprint")
    filesystem = os.statvfs("/private/tmp")
    free = filesystem.f_bavail * filesystem.f_frsize
    if free <= 16 * 1024 ** 3:
        failures.append("free disk floor")
    print(json.dumps({"phase": sys.argv[1] if len(sys.argv) > 1 else "unspecified",
                      "utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
                      "records": records, "snapshot_records": len(source_records),
                      "snapshot_bytes": source_bytes, "snapshot_fingerprint": fingerprint,
                      "free_bytes": free, "failures": failures, "successful": not failures}, sort_keys=True))
    return 0 if not failures else 1


if __name__ == "__main__":
    raise SystemExit(main())
