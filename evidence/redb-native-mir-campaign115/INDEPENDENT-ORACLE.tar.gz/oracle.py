"""Independent, bounded, fail-closed campaign115 diagnostic/receipt oracle."""

import argparse
import hashlib
import json
import os
import re
import stat
import time

VERSION = "campaign115.oracle.v1"
FROZEN = "c9cb297436ab24053c254ed95bd4e520ef6fca5b86832d217b37302cb5ad7b23"
MAX_BYTES = 2 * 1024 * 1024
MAX_LINE = 65536
MAX_DEPTH = 24
MAX_SITES = 32
MAX_ORIGINS = 128
SITE_FIELDS = (
    "block cleanup native_phase mir_phase local place projections root_type binder_status "
    "temporary_status builder_origins destructor_identity_status drop_glue_identity_status "
    "normal_target replace_assignment_origin async_cancellation_cleanup_target unwind_action "
    "unwind_cleanup_target"
).split()
ORIGIN_FIELDS = "expression local temp_lifetime scope".split()
SCOPE_FIELDS = "hir_id nested_expression region_scope".split()
PREFIX = (
    "destruction site captured but declined: binding/temporary provenance, native resource, "
    "field glue and successor effects are not established: "
)
ENVELOPES = (
    "checked normal destruction declined: ",
    "EXEC correspondence declined: ",
)
PANIC = re.compile(
    r"panick(?:ed|ing)|internal compiler error|\bICE\b|stack backtrace:|"
    r"fatal runtime error|segmentation fault|query stack during panic",
    re.IGNORECASE,
)
HEX = re.compile(r"[0-9a-f]{64}\Z")


class Invalid(ValueError):
    pass


def require(condition, message):
    if not condition:
        raise Invalid(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode()


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, "duplicate JSON key: " + key)
        result[key] = value
    return result


def json_input(data):
    require(type(data) is bytes and len(data) <= MAX_BYTES, "oversized/non-byte JSON")
    require(data.count(b"{") + data.count(b"[") <= 20000, "JSON complexity bound")
    value = json.loads(data.decode("utf-8"), object_pairs_hook=unique_object,
                       parse_constant=lambda value: (_ for _ in ()).throw(Invalid("JSON constant")))
    pending = [(value, 0)]
    while pending:
        current, depth = pending.pop()
        require(depth <= MAX_DEPTH, "JSON depth bound")
        if isinstance(current, dict):
            pending.extend((child, depth + 1) for child in current.values())
        elif isinstance(current, list):
            pending.extend((child, depth + 1) for child in current)
    return value


def keys(value, expected, label):
    require(type(value) is dict and set(value) == set(expected), "invalid fields: " + label)


def integer(value, label, minimum=0):
    require(type(value) is int and value >= minimum, "invalid integer: " + label)
    return value


def digest(value, label):
    require(type(value) is str and HEX.fullmatch(value), "invalid digest: " + label)


def text_input(data):
    require(type(data) is bytes and len(data) <= MAX_BYTES, "oversized/non-byte log")
    text = data.decode("utf-8")
    require(not any(ord(char) < 32 and char not in "\n\r\t" for char in text), "control/ANSI log")
    require(all(len(line) <= MAX_LINE for line in text.splitlines()), "log line bound")
    return text


def parts(text):
    require(len(text) <= MAX_LINE, "Debug size bound")
    stack = []
    quoted = False
    escaped = False
    start = 0
    result = []
    pairs = {"}": "{", "]": "[", ")": "("}
    for offset, char in enumerate(text):
        if quoted:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == '"':
                quoted = False
            continue
        if char == '"':
            quoted = True
        elif char in "{[(":
            stack.append(char)
            require(len(stack) <= MAX_DEPTH, "Debug depth bound")
        elif char in "}])":
            require(stack and stack.pop() == pairs[char], "unbalanced Debug delimiters")
        elif char == "," and not stack:
            require(text[start:offset].strip(), "empty Debug element")
            result.append(text[start:offset].strip())
            start = offset + 1
    require(not quoted and not escaped and not stack, "unfinished Debug value")
    tail = text[start:].strip()
    if tail:
        result.append(tail)
    return result


def record(text, name, fields, mapping):
    require(text.startswith(name + " { ") and text.endswith(" }"), "invalid Debug struct: " + name)
    result = {}
    reverse = {external: internal for internal, external in mapping.items()}
    for item in parts(text[len(name) + 3:-2]):
        field, separator, value = item.partition(": ")
        require(separator and field in reverse and field not in result and value, "invalid Debug field")
        result[field] = value
    require(set(result) == set(mapping.values()) and set(mapping) == set(fields), "missing Debug fields")
    return {reverse[field]: value for field, value in result.items()}


def debug_string(value):
    require(len(value) >= 2 and value[0] == value[-1] == '"', "expected Debug string")
    result = []
    offset = 1
    escapes = {'"': '"', "\\": "\\", "n": "\n", "r": "\r", "t": "\t", "0": "\0"}
    while offset < len(value) - 1:
        char = value[offset]
        require(char != '"' and ord(char) >= 32, "malformed Debug string")
        if char != "\\":
            result.append(char)
            offset += 1
            continue
        offset += 1
        require(offset < len(value) - 1, "unfinished Debug escape")
        escape = value[offset]
        if escape in escapes:
            result.append(escapes[escape])
            offset += 1
        elif escape == "u":
            match = re.match(r"u\{([0-9a-fA-F]{1,6})\}", value[offset:])
            require(match is not None, "unsupported Debug unicode escape")
            number = int(match[1], 16)
            require(number <= 0x10FFFF and not 0xD800 <= number <= 0xDFFF, "invalid unicode")
            result.append(chr(number))
            offset += len(match[0])
        else:
            raise Invalid("unsupported Debug escape")
    return "".join(result)


def debug_int(value):
    require(re.fullmatch(r"0|[1-9][0-9]{0,9}", value), "invalid Debug integer")
    return int(value)


def optional_int(value):
    if value == "None":
        return None
    require(value.startswith("Some(") and value.endswith(")"), "invalid Debug Option")
    return debug_int(value[5:-1])


def status(value):
    if value in ("MissingCapture", "CompleteEmpty"):
        return {"kind": value}
    match = re.fullmatch(r"(IncompleteCapture|CompleteWithoutLocalMatch) \{ observations: ([0-9]+) \}", value)
    if match:
        count = debug_int(match[2])
        require(match[1] == "IncompleteCapture" or count > 0, "empty nonmatching status")
        return {"kind": match[1], "observations": count}
    match = re.fullmatch(r"CompleteWithLocalMatches \{ observations: ([0-9]+), matches: ([0-9]+) \}", value)
    require(match is not None, "unknown capture status")
    count, matches = debug_int(match[1]), debug_int(match[2])
    require(0 < matches <= count, "inconsistent matching status")
    return {"kind": "CompleteWithLocalMatches", "observations": count, "matches": matches}


def default_profile(source):
    return {"version": 1, "source_fingerprint": source, "prefix": PREFIX,
            "envelopes": list(ENVELOPES),
            "site_fields": {field: field for field in SITE_FIELDS},
            "origin_fields": {field: field for field in ORIGIN_FIELDS},
            "scope_fields": {field: field for field in SCOPE_FIELDS}}


def profile_input(raw, source, approved):
    if raw is None:
        require(source == FROZEN, "modified source requires explicit approved mapping")
        return default_profile(source)
    require(approved is not None and sha(raw) == approved, "unapproved explicit field mapping")
    profile = json_input(raw)
    keys(profile, default_profile(source), "profile")
    require(profile["version"] == 1 and profile["source_fingerprint"] == source, "profile source/version")
    for name, fields in (("site_fields", SITE_FIELDS), ("origin_fields", ORIGIN_FIELDS),
                         ("scope_fields", SCOPE_FIELDS)):
        keys(profile[name], fields, name)
        names = list(profile[name].values())
        require(all(type(name) is str and re.fullmatch(r"[a-z_]+", name) for name in names)
                and len(set(names)) == len(names), "ambiguous field mapping")
    require(type(profile["prefix"]) is str and 16 <= len(profile["prefix"]) <= 1024,
            "invalid mapped prefix")
    require(type(profile["envelopes"]) is list and 1 <= len(profile["envelopes"]) <= 4
            and all(type(value) is str and 4 <= len(value) <= 256 for value in profile["envelopes"]),
            "invalid envelopes")
    return profile


def parse_sites(text, profile):
    require(text.startswith("[") and text.endswith("]"), "expected Debug site list")
    values = parts(text[1:-1])
    require(1 <= len(values) <= MAX_SITES, "empty/oversized site list")
    sites = []
    for value in values:
        site = record(value, "UnestablishedDropSite", SITE_FIELDS, profile["site_fields"])
        for field in ("block", "local", "normal_target"):
            site[field] = debug_int(site[field])
        for field in ("cleanup", "native_phase", "replace_assignment_origin"):
            require(site[field] in ("true", "false"), "invalid Debug boolean")
            site[field] = site[field] == "true"
        for field in ("async_cancellation_cleanup_target", "unwind_cleanup_target"):
            site[field] = optional_int(site[field])
        for field in ("mir_phase", "place", "root_type", "destructor_identity_status",
                      "drop_glue_identity_status", "unwind_action"):
            site[field] = debug_string(site[field])
        projections = site["projections"]
        require(projections.startswith("[") and projections.endswith("]"), "projection list")
        site["projections"] = [debug_string(item) for item in parts(projections[1:-1])]
        for field in ("binder_status", "temporary_status"):
            site[field] = status(site[field])
        require(site["binder_status"]["kind"] != "CompleteWithLocalMatches", "bound local cannot be captured")
        origins = site["builder_origins"]
        require(origins.startswith("[") and origins.endswith("]"), "origin list")
        origin_values = parts(origins[1:-1])
        require(len(origin_values) <= MAX_ORIGINS, "origin bound")
        site["builder_origins"] = []
        for origin_value in origin_values:
            origin = record(origin_value, "TemporaryOrigin", ORIGIN_FIELDS, profile["origin_fields"])
            require(re.fullmatch(r"_[0-9]+", origin["local"]), "origin local syntax")
            origin["local"] = int(origin["local"][1:])
            require(origin["local"] == site["local"], "origin local mismatch")
            scope = origin["scope"]
            if scope == "None":
                origin["scope"] = None
            else:
                require(scope.startswith("Some(") and scope.endswith(")"), "scope Option")
                origin["scope"] = record(scope[5:-1], "TemporaryScope", SCOPE_FIELDS, profile["scope_fields"])
            site["builder_origins"].append(origin)
        captured = site["temporary_status"]
        count = len(site["builder_origins"])
        if captured["kind"] == "CompleteWithLocalMatches":
            require(count == captured["matches"], "matching observation count mismatch")
        elif captured["kind"] == "IncompleteCapture":
            require(count <= captured["observations"], "incomplete observation mismatch")
        else:
            require(count == 0, "missing/empty/nonmatching capture has origins")
        require(site["destructor_identity_status"] == "NOT_QUERIED_UNESTABLISHED_RESOURCE_EFFECTS"
                and site["drop_glue_identity_status"] == "NOT_QUERIED_NO_RESOLVED_INSTANCE_OR_SHIM_IDENTITY",
                "identity not established/unsupported status")
        sites.append(site)
    return sites


def validate_expectation(expectation):
    keys(expectation, "version fixture_id fixture_path fixture_sha256 source_fingerprint executable_sha256 "
         "launch_id argv cwd output_path output_arg outcome output_policy expected_sites diagnostic_span "
         "frontend_message ordinary_stdout ordinary_stderr stderr_before_error stderr_after_error "
         "profile_sha256".split(), "expectation")
    require(type(expectation["version"]) is int and expectation["version"] == 1, "expectation version")
    for field in ("fixture_sha256", "source_fingerprint", "executable_sha256", "profile_sha256"):
        digest(expectation[field], field)
    for field in ("fixture_path", "output_path", "cwd"):
        require(type(expectation[field]) is str and os.path.isabs(expectation[field])
                and os.path.normpath(expectation[field]) == expectation[field], "noncanonical path")
    require(type(expectation["fixture_id"]) is str and expectation["fixture_id"]
            and type(expectation["launch_id"]) is str and expectation["launch_id"], "fixture/launch identity")
    argv = expectation["argv"]
    require(type(argv) is list and 1 <= len(argv) <= 256 and all(type(item) is str for item in argv), "argv")
    require(expectation["fixture_path"] in argv, "fixture not in argv")
    output_arg = expectation["output_arg"]
    require(type(output_arg) is str and re.fullmatch(r"--?[a-z][a-z0-9-]*", output_arg), "output argument")
    bindings = sum(argv[index:index + 2] == [output_arg, expectation["output_path"]]
                   for index in range(len(argv) - 1))
    bindings += argv.count(output_arg + "=" + expectation["output_path"])
    occurrences = sum(item == output_arg or item.startswith(output_arg + "=") for item in argv)
    require(bindings == occurrences == 1 and expectation["output_path"] not in (expectation["fixture_path"], argv[0]),
            "requested output not uniquely bound to argv")
    require(expectation["outcome"] in ("captured_refusal", "frontend_refusal", "ordinary_control"), "outcome")
    require(expectation["output_policy"] in ("absent", "fresh_file"), "output policy")
    require(expectation["outcome"] == "ordinary_control" or expectation["output_policy"] == "absent",
            "refusal must not produce requested output")
    require(type(expectation["ordinary_stdout"]) is str and type(expectation["ordinary_stderr"]) is str
            and type(expectation["frontend_message"]) is str
            and type(expectation["stderr_before_error"]) is str and type(expectation["stderr_after_error"]) is str,
            "expected log types")
    require(type(expectation["expected_sites"]) is list and len(expectation["expected_sites"]) <= MAX_SITES,
            "expected sites")
    span = expectation["diagnostic_span"]
    if expectation["outcome"] != "ordinary_control":
        keys(span, "line column".split(), "diagnostic span")
        integer(span["line"], "line", 1)
        integer(span["column"], "column", 1)
    else:
        require(span is None and not expectation["expected_sites"], "ordinary diagnostic expectation")


def validate_receipt(receipt, expectation, stdout, stderr, state_raw):
    keys(receipt, "version fixture_id fixture_path fixture_sha256 source_fingerprint executable_sha256 "
         "launch_id argv cwd output_path status started_ns ended_ns completed reaped exit_code signal "
         "spawn_error timed_out cancelled stdout_sha256 stderr_sha256 stdout_bytes stderr_bytes "
         "output_state_sha256".split(), "receipt")
    require(type(receipt["version"]) is int and receipt["version"] == 1, "receipt version")
    for field in ("fixture_id", "fixture_path", "fixture_sha256", "source_fingerprint", "executable_sha256",
                  "launch_id", "argv", "cwd", "output_path"):
        require(receipt[field] == expectation[field], "receipt binding mismatch: " + field)
    for field in ("completed", "reaped", "timed_out", "cancelled"):
        require(type(receipt[field]) is bool, "receipt boolean: " + field)
    require(receipt["status"] in ("exited", "spawn_failure", "cancelled", "timeout", "tool_failure", "running"),
            "receipt status")
    integer(receipt["started_ns"], "start", 1)
    if receipt["ended_ns"] is not None:
        integer(receipt["ended_ns"], "end", receipt["started_ns"])
        require(receipt["ended_ns"] - receipt["started_ns"] <= 90_000_000_000, "launch duration >90s")
    require(receipt["exit_code"] is None or type(receipt["exit_code"]) is int
            and 0 <= receipt["exit_code"] <= 255, "exit code")
    require(receipt["signal"] is None or type(receipt["signal"]) is int and 1 <= receipt["signal"] <= 127,
            "signal")
    require(receipt["spawn_error"] is None or type(receipt["spawn_error"]) is str and receipt["spawn_error"],
            "spawn error")
    require(type(receipt["stdout_bytes"]) is int and type(receipt["stderr_bytes"]) is int
            and receipt["stdout_bytes"] == len(stdout) and receipt["stderr_bytes"] == len(stderr)
            and receipt["stdout_sha256"] == sha(stdout) and receipt["stderr_sha256"] == sha(stderr)
            and receipt["output_state_sha256"] == sha(state_raw), "raw stream/output binding mismatch")
    if not receipt["completed"] or not receipt["reaped"] or receipt["ended_ns"] is None:
        return "unfinished_launch"
    indicators = [receipt["timed_out"], receipt["cancelled"], receipt["spawn_error"] is not None,
                  receipt["signal"] is not None]
    if sum(indicators) > 1:
        return "ambiguous_launch_failure"
    if receipt["timed_out"] or receipt["status"] == "timeout":
        return "timeout"
    if receipt["cancelled"] or receipt["status"] == "cancelled":
        return "cancelled"
    if receipt["spawn_error"] is not None or receipt["status"] == "spawn_failure":
        return "spawn_failure"
    if receipt["signal"] is not None or receipt["status"] == "tool_failure":
        return "tool_failure"
    require(receipt["status"] == "exited" and receipt["exit_code"] is not None, "inconsistent completed receipt")
    return None


def validate_output(state, receipt, expectation):
    keys(state, "version path before after".split(), "output state")
    require(type(state["version"]) is int and state["version"] == 1
            and state["path"] == expectation["output_path"], "output path/version")
    before, after = state["before"], state["after"]
    for observation in (before, after):
        keys(observation, "kind sampled_ns size sha256 mtime_ns ctime_ns".split(), "output observation")
        integer(observation["sampled_ns"], "sample time", 1)
        require(observation["kind"] in ("absent", "regular_file"), "symlink/special output")
        if observation["kind"] == "absent":
            require(all(observation[field] is None for field in ("size", "sha256", "mtime_ns", "ctime_ns")),
                    "absent output with metadata")
        else:
            integer(observation["size"], "output size", 1)
            digest(observation["sha256"], "output hash")
            integer(observation["mtime_ns"], "mtime", 1)
            integer(observation["ctime_ns"], "ctime", 1)
    require(before["kind"] == "absent", "seeded/preexisting requested output")
    require(before["sampled_ns"] <= receipt["started_ns"] <= receipt["ended_ns"] <= after["sampled_ns"],
            "output sampling order")
    require(after["sampled_ns"] - before["sampled_ns"] <= 120_000_000_000, "output sampling interval")
    if expectation["output_policy"] == "absent":
        require(after["kind"] == "absent", "unexpected requested output after refusal/control")
    else:
        require(after["kind"] == "regular_file", "missing requested ordinary output")
        require(all(receipt["started_ns"] <= after[field] <= receipt["ended_ns"]
                    for field in ("mtime_ns", "ctime_ns")), "stale requested output")


def evaluate(stdout, stderr, receipt_raw, expectation_raw, state_raw, mapping_raw=None, approved_mapping=None):
    started = time.monotonic()
    result = {"oracle": VERSION, "matched": False, "classification": "invalid_evidence",
              "real_mir_integration": "NOT_ESTABLISHED_BY_ORACLE", "native_credit": 0,
              "trust_credit": 0, "source_final_cell_credit": 0, "all18": "OPEN"}
    try:
        require(sum(len(data) for data in (stdout, stderr, receipt_raw, expectation_raw, state_raw))
                <= 4 * MAX_BYTES, "aggregate input bound")
        stdout_text, stderr_text = text_input(stdout), text_input(stderr)
        receipt, expectation, state = map(json_input, (receipt_raw, expectation_raw, state_raw))
        validate_expectation(expectation)
        profile = profile_input(mapping_raw, expectation["source_fingerprint"], approved_mapping)
        profile_hash = sha(canonical(profile)) if mapping_raw is None else sha(mapping_raw)
        require(expectation["profile_sha256"] == profile_hash, "expectation profile binding")
        failure = validate_receipt(receipt, expectation, stdout, stderr, state_raw)
        combined = stdout_text + "\n" + stderr_text
        if failure:
            result.update(classification=failure, reason="launch did not complete normally")
            return result
        if PANIC.search(combined):
            result.update(classification="panic_or_ice", reason="panic/ICE marker takes precedence over refusal")
            return result
        validate_output(state, receipt, expectation)
        require(not re.search(r"(?m)^error(?:\[|:)", stdout_text)
                and profile["prefix"] not in stdout_text, "diagnostics on unexpected stream")
        errors = []
        summaries = []
        for match in re.finditer(r"(?m)^error(?:\[[^\]\n]+\])?: (.*)$", stderr_text):
            if re.fullmatch(r"aborting due to [1-9][0-9]* previous errors?(?:; [0-9]+ warnings? emitted)?", match[1]):
                summaries.append(match[1])
                continue
            errors.append(match)
        require(len(summaries) <= 1 and (not summaries or len(errors) == 1
                and re.match(r"aborting due to 1 previous error(?:;|$)", summaries[0])), "ambiguous error summary")
        outcome = expectation["outcome"]
        if outcome == "ordinary_control":
            require(receipt["exit_code"] == 0 and not errors and "error:" not in combined.lower()
                    and profile["prefix"] not in combined and "UnestablishedDropSite" not in combined,
                    "ordinary control has failure/diagnostic evidence")
            require(stdout_text == expectation["ordinary_stdout"]
                    and stderr_text == expectation["ordinary_stderr"], "ordinary log mismatch")
            result.update(classification="ordinary_control", matched=True)
        else:
            require(stdout_text == expectation["ordinary_stdout"], "refusal stdout mismatch")
            require(receipt["exit_code"] != 0, "refusal requires a normal nonzero exit")
            require(len(errors) == 1, "absent/ambiguous primary error")
            primary = errors[0]
            tail = stderr_text[primary.end():]
            spans = re.findall(r"(?m)^\s*--> (.+):([0-9]+):([0-9]+)\s*$", tail)
            expected_span = (expectation["fixture_path"], str(expectation["diagnostic_span"]["line"]),
                             str(expectation["diagnostic_span"]["column"]))
            require(spans == [expected_span], "absent/wrong/ambiguous fixture diagnostic span")
            message = primary[1]
            payloads = [message[len(envelope + profile["prefix"]):]
                        for envelope in profile["envelopes"] if message.startswith(envelope + profile["prefix"])]
            if payloads:
                require(len(payloads) == 1 and combined.count(profile["prefix"]) == 1,
                        "ambiguous captured diagnostic")
                sites = parse_sites(payloads[0], profile)
                require(combined.count("UnestablishedDropSite") == len(sites), "additional unscoped capture")
                result["observed_sites"] = sites
                result["classification"] = "captured_provenance_refusal"
                require(outcome == "captured_refusal", "capture was not expected")
                require(canonical(sites) == canonical(expectation["expected_sites"]), "site field/observation mismatch")
            else:
                require(profile["prefix"] not in combined and "UnestablishedDropSite" not in combined,
                        "malformed/unscoped capture")
                result["classification"] = "unexpected_error"
                require(outcome == "frontend_refusal" and expectation["frontend_message"]
                        and message == expectation["frontend_message"] and not expectation["expected_sites"],
                        "unexpected nonzero error; not expected rejection")
                result["classification"] = "earlier_frontend_refusal"
            require(stderr_text[:primary.start()] == expectation["stderr_before_error"]
                    and stderr_text[primary.end():] == expectation["stderr_after_error"],
                    "unregistered/malformed stderr context")
            result["matched"] = True
        require(time.monotonic() - started <= 2.0, "oracle time bound")
        result["reason"] = "exact fixture-scoped diagnostic/receipt/output contract matched"
    except (Invalid, ValueError, TypeError, KeyError, UnicodeError, RecursionError, OverflowError) as error:
        result["matched"] = False
        result["reason"] = str(error)
    return result


def bounded_read(path):
    descriptor = os.open(path, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_NONBLOCK", 0))
    with os.fdopen(descriptor, "rb") as stream:
        before = os.fstat(stream.fileno())
        require(stat.S_ISREG(before.st_mode) and before.st_size <= MAX_BYTES, "nonregular/oversized input")
        data = stream.read(MAX_BYTES + 1)
        after = os.fstat(stream.fileno())
        require(len(data) <= MAX_BYTES and (before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns)
                == (after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns), "input changed during read")
        return data


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("stdout", "stderr", "receipt", "expectation", "output-state"):
        parser.add_argument("--" + name, required=True)
    parser.add_argument("--mapping")
    parser.add_argument("--approved-mapping-sha256")
    args = parser.parse_args()
    try:
        values = [bounded_read(getattr(args, name)) for name in
                  ("stdout", "stderr", "receipt", "expectation", "output_state")]
        mapping = bounded_read(args.mapping) if args.mapping else None
        result = evaluate(*values, mapping, args.approved_mapping_sha256)
    except (OSError, Invalid) as error:
        result = {"oracle": VERSION, "matched": False, "classification": "input_tool_failure", "reason": str(error)}
    print(json.dumps(result, sort_keys=True))
    return 0 if result["matched"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
