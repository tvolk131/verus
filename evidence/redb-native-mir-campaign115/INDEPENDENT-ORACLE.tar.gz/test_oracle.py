"""Synthetic parser/contract tests ONLY; these never execute MIR or candidate code."""

import copy
import json
import sys
import time
import unittest

import oracle


ORIGIN = ("TemporaryOrigin { expression: e7, local: _2, temp_lifetime: "
          "TempLifetime { temp_lifetime: None, backwards_incompatible: None }, scope: None }")
SITE = (
    'UnestablishedDropSite { block: 3, cleanup: false, native_phase: false, '
    'mir_phase: "Runtime(PostCleanup)", local: 2, place: "_2", projections: [], root_type: "Owner", '
    'binder_status: CompleteEmpty, temporary_status: CompleteWithLocalMatches { observations: 1, matches: 1 }, '
    'builder_origins: [' + ORIGIN + '], '
    'destructor_identity_status: "NOT_QUERIED_UNESTABLISHED_RESOURCE_EFFECTS", '
    'drop_glue_identity_status: "NOT_QUERIED_NO_RESOLVED_INSTANCE_OR_SHIM_IDENTITY", '
    'normal_target: 4, replace_assignment_origin: false, async_cancellation_cleanup_target: None, '
    'unwind_action: "Continue", unwind_cleanup_target: None }'
)
EXPECTED_SITE = {
    "block": 3, "cleanup": False, "native_phase": False, "mir_phase": "Runtime(PostCleanup)",
    "local": 2, "place": "_2", "projections": [], "root_type": "Owner",
    "binder_status": {"kind": "CompleteEmpty"},
    "temporary_status": {"kind": "CompleteWithLocalMatches", "observations": 1, "matches": 1},
    "builder_origins": [{"expression": "e7", "local": 2,
                         "temp_lifetime": "TempLifetime { temp_lifetime: None, backwards_incompatible: None }",
                         "scope": None}],
    "destructor_identity_status": "NOT_QUERIED_UNESTABLISHED_RESOURCE_EFFECTS",
    "drop_glue_identity_status": "NOT_QUERIED_NO_RESOLVED_INSTANCE_OR_SHIM_IDENTITY",
    "normal_target": 4, "replace_assignment_origin": False,
    "async_cancellation_cleanup_target": None, "unwind_action": "Continue", "unwind_cleanup_target": None,
}


def observation(kind="absent", sampled_ns=999):
    return {"kind": kind, "sampled_ns": sampled_ns, "size": None, "sha256": None,
            "mtime_ns": None, "ctime_ns": None}


def fixture(outcome="captured_refusal"):
    expectation = {
        "version": 1, "fixture_id": "SYNTHETIC-pair", "fixture_path": "/synthetic/fixture.rs",
        "fixture_sha256": "a" * 64, "source_fingerprint": oracle.FROZEN,
        "executable_sha256": "b" * 64, "launch_id": "SYNTHETIC-launch-1",
        "argv": ["/synthetic/verus", "/synthetic/fixture.rs", "-o", "/synthetic/requested.out"],
        "cwd": "/synthetic", "output_path": "/synthetic/requested.out", "output_arg": "-o", "outcome": outcome,
        "output_policy": "absent", "expected_sites": [copy.deepcopy(EXPECTED_SITE)],
        "diagnostic_span": {"line": 12, "column": 1}, "frontend_message": "",
        "ordinary_stdout": "", "ordinary_stderr": "",
        "stderr_before_error": "",
        "stderr_after_error": "\n  --> /synthetic/fixture.rs:12:1\nerror: aborting due to 1 previous error\n",
        "profile_sha256": oracle.sha(oracle.canonical(oracle.default_profile(oracle.FROZEN))),
    }
    stdout = b""
    stderr = ("error: " + oracle.ENVELOPES[0] + oracle.PREFIX + "[" + SITE + "]\n"
              "  --> /synthetic/fixture.rs:12:1\n"
              "error: aborting due to 1 previous error\n").encode()
    state = {"version": 1, "path": expectation["output_path"],
             "before": observation(), "after": observation(sampled_ns=2001)}
    receipt = {field: copy.deepcopy(expectation[field]) for field in
               ("version", "fixture_id", "fixture_path", "fixture_sha256", "source_fingerprint",
                "executable_sha256", "launch_id", "argv", "cwd", "output_path")}
    receipt.update(status="exited", started_ns=1000, ended_ns=2000, completed=True, reaped=True,
                   exit_code=1, signal=None, spawn_error=None, timed_out=False, cancelled=False,
                   stdout_sha256="", stderr_sha256="", stdout_bytes=0, stderr_bytes=0, output_state_sha256="")
    if outcome == "ordinary_control":
        stderr = b""
        stdout = b"verification results:: 1 verified, 0 errors\n"
        expectation.update(expected_sites=[], diagnostic_span=None, ordinary_stdout=stdout.decode(),
                           output_policy="fresh_file")
        receipt["exit_code"] = 0
        state["after"].update(kind="regular_file", size=7, sha256="c" * 64, mtime_ns=1500, ctime_ns=1500)
    elif outcome == "frontend_refusal":
        expectation.update(expected_sites=[], frontend_message="unsupported external type: std::sync::Mutex")
        expectation["stderr_after_error"] = "\n  --> /synthetic/fixture.rs:12:1\n"
        stderr = ("error: " + expectation["frontend_message"] + "\n  --> /synthetic/fixture.rs:12:1\n").encode()
    return {"stdout": stdout, "stderr": stderr, "receipt": receipt,
            "expectation": expectation, "state": state}


def inputs(bundle):
    receipt = copy.deepcopy(bundle["receipt"])
    state = oracle.canonical(bundle["state"])
    receipt.update(stdout_sha256=oracle.sha(bundle["stdout"]), stderr_sha256=oracle.sha(bundle["stderr"]),
                   stdout_bytes=len(bundle["stdout"]), stderr_bytes=len(bundle["stderr"]),
                   output_state_sha256=oracle.sha(state))
    return [bundle["stdout"], bundle["stderr"], oracle.canonical(receipt),
            oracle.canonical(bundle["expectation"]), state]


def run(bundle, **kwargs):
    return oracle.evaluate(*inputs(bundle), **kwargs)


class OracleTests(unittest.TestCase):
    def assert_closed(self, bundle, reason=None):
        result = run(bundle)
        self.assertFalse(result["matched"], result)
        if reason:
            self.assertIn(reason, result["reason"])

    def test_matched_refusal_and_ordinary_control_pair(self):
        refusal, control = fixture(), fixture("ordinary_control")
        self.assertEqual(refusal["expectation"]["fixture_sha256"], control["expectation"]["fixture_sha256"])
        self.assertTrue(run(refusal)["matched"])
        self.assertTrue(run(control)["matched"])
        self.assertEqual(run(refusal)["native_credit"], 0)
        self.assertEqual(run(refusal)["all18"], "OPEN")

    def test_explicit_frontend_refusal_distinct_from_capture(self):
        result = run(fixture("frontend_refusal"))
        self.assertTrue(result["matched"], result)
        self.assertEqual(result["classification"], "earlier_frontend_refusal")

    def test_field_phase_local_and_successor_mismatches(self):
        for old, new in ((b"block: 3", b"block: 4"), (b"native_phase: false", b"native_phase: true"),
                         (b"PostCleanup", b"Initial"), (b"local: 2", b"local: 9"),
                         (b"normal_target: 4", b"normal_target: 8"),
                         (b"cleanup: false", b"cleanup: true"),
                         (b"replace_assignment_origin: false", b"replace_assignment_origin: true"),
                         (b"root_type: \"Owner\"", b"root_type: \"Other\"")):
            with self.subTest(old=old):
                bundle = fixture()
                bundle["stderr"] = bundle["stderr"].replace(old, new)
                self.assert_closed(bundle)

    def test_all_missing_empty_and_incomplete_statuses_stay_distinct(self):
        statuses = [("MissingCapture", {"kind": "MissingCapture"}),
                    ("CompleteEmpty", {"kind": "CompleteEmpty"}),
                    ("IncompleteCapture { observations: 0 }", {"kind": "IncompleteCapture", "observations": 0}),
                    ("CompleteWithoutLocalMatch { observations: 1 }",
                     {"kind": "CompleteWithoutLocalMatch", "observations": 1})]
        for raw, expected in statuses:
            with self.subTest(status=raw):
                bundle = fixture()
                bundle["stderr"] = bundle["stderr"].replace(
                    b"CompleteWithLocalMatches { observations: 1, matches: 1 }", raw.encode()).replace(ORIGIN.encode(), b"")
                bundle["expectation"]["expected_sites"][0].update(temporary_status=expected, builder_origins=[])
                self.assertTrue(run(bundle)["matched"], run(bundle))
                bundle["expectation"]["expected_sites"][0]["temporary_status"] = {"kind": "CompleteEmpty" if raw != "CompleteEmpty" else "MissingCapture"}
                self.assert_closed(bundle)

    def test_missing_field_is_not_empty_capture(self):
        bundle = fixture()
        bundle["stderr"] = bundle["stderr"].replace(b"binder_status: CompleteEmpty, ", b"")
        self.assert_closed(bundle, "missing Debug fields")

    def test_duplicate_observation_preserved_not_unique(self):
        bundle = fixture()
        bundle["stderr"] = bundle["stderr"].replace(ORIGIN.encode(), (ORIGIN + ", " + ORIGIN).encode()).replace(
            b"observations: 1, matches: 1", b"observations: 2, matches: 2")
        self.assert_closed(bundle)
        expected = bundle["expectation"]["expected_sites"][0]
        expected["temporary_status"].update(observations=2, matches=2)
        expected["builder_origins"] *= 2
        result = run(bundle)
        self.assertTrue(result["matched"], result)
        self.assertEqual(len(result["observed_sites"][0]["builder_origins"]), 2)
        self.assertNotIn("unique_owner", result)

    def test_count_impostor(self):
        bundle = fixture()
        bundle["stderr"] = bundle["stderr"].replace(b"observations: 1, matches: 1", b"observations: 2, matches: 2")
        self.assert_closed(bundle, "count mismatch")

    def test_nonzero_impostors_never_expected_rejection(self):
        for text in (b"error: linker failed\n", b"error: unsupported external type\n", b"", b"tool failed: exit 1\n"):
            with self.subTest(text=text):
                bundle = fixture()
                bundle["stderr"] = text + b"  --> /synthetic/fixture.rs:12:1\n"
                self.assert_closed(bundle)

    def test_panic_and_ice_override_even_exact_refusal(self):
        for marker in (b"thread 'main' panicked at fake.rs:1\n", b"error: internal compiler error\n",
                       b"stack backtrace:\n", b"fatal runtime error\n"):
            with self.subTest(marker=marker):
                bundle = fixture()
                bundle["stderr"] += marker
                result = run(bundle)
                self.assertFalse(result["matched"])
                self.assertEqual(result["classification"], "panic_or_ice")

    def test_cancel_timeout_spawn_signal_tool_and_unfinished(self):
        mutations = [({"cancelled": True, "status": "cancelled"}, "cancelled"),
                     ({"timed_out": True, "status": "timeout"}, "timeout"),
                     ({"spawn_error": "ENOENT", "status": "spawn_failure", "exit_code": None}, "spawn_failure"),
                     ({"signal": 9, "exit_code": None}, "tool_failure"),
                     ({"status": "tool_failure"}, "tool_failure"),
                     ({"completed": False, "ended_ns": None}, "unfinished_launch"),
                     ({"reaped": False}, "unfinished_launch"),
                     ({"status": "running", "completed": False}, "unfinished_launch")]
        for mutation, expected in mutations:
            with self.subTest(mutation=mutation):
                bundle = fixture()
                bundle["receipt"].update(mutation)
                result = run(bundle)
                self.assertFalse(result["matched"])
                self.assertEqual(result["classification"], expected)

    def test_wrong_fixture_and_unscoped_capture(self):
        for old, new in ((b"/synthetic/fixture.rs:12:1", b"/other/fixture.rs:12:1"),
                         (b"12:1", b"13:1"),
                         (b"  --> /synthetic/fixture.rs:12:1\n", b"")):
            with self.subTest(new=new):
                bundle = fixture()
                bundle["stderr"] = bundle["stderr"].replace(old, new)
                self.assert_closed(bundle, "fixture diagnostic span")
        bundle = fixture()
        bundle["receipt"]["fixture_sha256"] = "d" * 64
        self.assert_closed(bundle, "receipt binding mismatch")

    def test_ordinary_missing_stale_seeded_output(self):
        bundle = fixture("ordinary_control")
        bundle["state"]["after"] = observation(sampled_ns=2001)
        self.assert_closed(bundle, "missing requested")
        for field in ("mtime_ns", "ctime_ns"):
            with self.subTest(field=field):
                bundle = fixture("ordinary_control")
                bundle["state"]["after"][field] = 999
                self.assert_closed(bundle, "stale requested")
        bundle = fixture("ordinary_control")
        bundle["state"]["before"] = copy.deepcopy(bundle["state"]["after"])
        bundle["state"]["before"]["sampled_ns"] = 999
        self.assert_closed(bundle, "seeded/preexisting")

    def test_refusal_cannot_leave_an_output(self):
        bundle = fixture()
        bundle["state"]["after"] = fixture("ordinary_control")["state"]["after"]
        self.assert_closed(bundle, "unexpected requested output")

    def test_symlink_wrong_path_and_sampling_order(self):
        for mutation in (lambda state: state["after"].update(kind="symlink"),
                         lambda state: state.update(path="/wrong.out"),
                         lambda state: state["before"].update(sampled_ns=1001),
                         lambda state: state["after"].update(sampled_ns=1999)):
            bundle = fixture()
            mutation(bundle["state"])
            self.assert_closed(bundle)

    def test_raw_hash_mismatch(self):
        values = inputs(fixture())
        values[1] += b"unexpected bytes\n"
        result = oracle.evaluate(*values)
        self.assertFalse(result["matched"])
        self.assertIn("raw stream/output binding", result["reason"])

    def test_duplicate_json_unknown_fields_and_malformed(self):
        for replacement in (b'{"version":1,"version":1}', b"{", b"null", b"[", b"{\"value\":NaN}"):
            with self.subTest(replacement=replacement):
                values = inputs(fixture())
                values[2] = replacement
                self.assertFalse(oracle.evaluate(*values)["matched"])
        bundle = fixture()
        bundle["receipt"]["unexpected"] = True
        self.assert_closed(bundle)

    def test_oversized_line_bytes_nesting_and_invalid_utf8(self):
        for raw in (b"x" * (oracle.MAX_BYTES + 1), b"x" * (oracle.MAX_LINE + 1), b"\xff", b"\x1b[31m"):
            values = inputs(fixture())
            values[1] = raw
            self.assertFalse(oracle.evaluate(*values)["matched"])
        values = inputs(fixture())
        values[2] = b"[" * 1000 + b"]" * 1000
        self.assertFalse(oracle.evaluate(*values)["matched"])

    def test_zero_exit_does_not_establish_refusal(self):
        bundle = fixture()
        bundle["receipt"]["exit_code"] = 0
        self.assert_closed(bundle, "nonzero")

    def test_duplicate_diagnostic_or_field_and_extra_error(self):
        bundle = fixture()
        bundle["stderr"] *= 2
        self.assert_closed(bundle)
        bundle = fixture()
        bundle["stderr"] = bundle["stderr"].replace(b"block: 3,", b"block: 3, block: 3,")
        self.assert_closed(bundle)
        bundle = fixture()
        bundle["stderr"] += b"error: linker failed\n"
        self.assert_closed(bundle)
        bundle = fixture()
        bundle["stderr"] = bundle["stderr"].replace(b"1 previous error", b"9 previous errors")
        self.assert_closed(bundle)

    def test_unbalanced_and_quoted_debug_strings(self):
        bundle = fixture()
        bundle["stderr"] = bundle["stderr"].replace(b'root_type: "Owner"', b'root_type: "Owner {, \\\" nested"')
        bundle["expectation"]["expected_sites"][0]["root_type"] = 'Owner {, " nested'
        self.assertTrue(run(bundle)["matched"], run(bundle))
        bundle["stderr"] = bundle["stderr"].replace(b"builder_origins: [", b"builder_origins: (")
        self.assert_closed(bundle)

    def test_scope_kept_as_structural_exact_debug_evidence(self):
        bundle = fixture()
        scope = "TemporaryScope { hir_id: HirId(DefId(0:7 ~ synthetic[abc]::f).4), nested_expression: e6, region_scope: Scope { local_id: 3, data: Node } }"
        bundle["stderr"] = bundle["stderr"].replace(b"scope: None", ("scope: Some(" + scope + ")").encode())
        bundle["expectation"]["expected_sites"][0]["builder_origins"][0]["scope"] = {
            "hir_id": "HirId(DefId(0:7 ~ synthetic[abc]::f).4)", "nested_expression": "e6",
            "region_scope": "Scope { local_id: 3, data: Node }"}
        self.assertTrue(run(bundle)["matched"], run(bundle))

    def test_explicit_mapping_requires_approval_and_pinned_expectation(self):
        bundle = fixture()
        source = "d" * 64
        bundle["expectation"]["source_fingerprint"] = source
        bundle["receipt"]["source_fingerprint"] = source
        profile = oracle.default_profile(source)
        profile["site_fields"]["local"] = "mir_local"
        raw = oracle.canonical(profile)
        bundle["expectation"]["profile_sha256"] = oracle.sha(raw)
        bundle["stderr"] = bundle["stderr"].replace(b" local: 2,", b" mir_local: 2,")
        self.assertFalse(run(bundle, mapping_raw=raw)["matched"])
        result = run(bundle, mapping_raw=raw, approved_mapping=oracle.sha(raw))
        self.assertTrue(result["matched"], result)
        self.assertFalse(run(bundle)["matched"])

    def test_frontend_capture_wrong_expectations_and_ordinary_errors(self):
        bundle = fixture("frontend_refusal")
        bundle["expectation"]["outcome"] = "captured_refusal"
        self.assert_closed(bundle)
        bundle = fixture()
        bundle["expectation"].update(outcome="frontend_refusal", frontend_message="impostor", expected_sites=[])
        self.assert_closed(bundle)
        bundle = fixture("ordinary_control")
        bundle["stderr"] = b"error: ordinary control failed\n"
        self.assert_closed(bundle)

    def test_duration_and_malformed_receipt_flags(self):
        bundle = fixture()
        bundle["receipt"]["ended_ns"] = 91_000_001_000
        self.assert_closed(bundle)
        bundle = fixture()
        bundle["receipt"]["completed"] = 1
        self.assert_closed(bundle)

    def test_ordinary_explicit_warning_bytes_are_not_silently_discarded(self):
        bundle = fixture("ordinary_control")
        bundle["stderr"] = b"warning: unused variable: example\n"
        self.assert_closed(bundle)
        bundle["expectation"]["ordinary_stderr"] = bundle["stderr"].decode()
        self.assertTrue(run(bundle)["matched"], run(bundle))

    def test_post_exit_artifact_seeding_and_stray_capture(self):
        bundle = fixture("ordinary_control")
        bundle["state"]["after"]["ctime_ns"] = 2001
        self.assert_closed(bundle, "stale requested")
        bundle = fixture()
        bundle["stderr"] += b"UnestablishedDropSite { unrelated: true }\n"
        self.assert_closed(bundle, "unscoped capture")

    def test_origin_local_expression_lifetime_and_missing_binder_mismatches(self):
        for old, new in ((b"local: _2", b"local: _9"), (b"expression: e7", b"expression: e8"),
                         (b"backwards_incompatible: None", b"backwards_incompatible: Some(1)"),
                         (b"binder_status: CompleteEmpty", b"binder_status: MissingCapture")):
            with self.subTest(old=old):
                bundle = fixture()
                bundle["stderr"] = bundle["stderr"].replace(old, new)
                self.assert_closed(bundle)

    def test_receipt_missing_fields_and_ambiguous_failure_indicators(self):
        bundle = fixture()
        del bundle["receipt"]["completed"]
        self.assert_closed(bundle, "invalid fields")
        bundle = fixture()
        bundle["receipt"].update(cancelled=True, timed_out=True)
        result = run(bundle)
        self.assertFalse(result["matched"])
        self.assertEqual(result["classification"], "ambiguous_launch_failure")

    def test_requested_output_must_be_bound_to_exact_launch_arguments(self):
        bundle = fixture()
        bundle["expectation"]["output_arg"] = "--invented-output"
        self.assert_closed(bundle, "not uniquely bound")
        bundle = fixture()
        bundle["expectation"]["argv"] += ["-o", "/wrong.out"]
        bundle["receipt"]["argv"] = bundle["expectation"]["argv"][:]
        self.assert_closed(bundle, "not uniquely bound")

    def test_unregistered_log_context_and_malformed_error_lines(self):
        for extra in (b"tool failed without a standard header\n", b" error : malformed\n", b"ERROR: tool\n"):
            with self.subTest(extra=extra):
                bundle = fixture()
                bundle["stderr"] += extra
                self.assert_closed(bundle, "stderr context")


class AccountingResult(unittest.TestResult):
    def __init__(self):
        super().__init__()
        self.passed_ids = []
        self.failed_ids = []

    def addSuccess(self, test):
        super().addSuccess(test)
        self.passed_ids.append(test.id())

    def addFailure(self, test, error):
        super().addFailure(test, error)
        self.failed_ids.append(test.id())

    def addError(self, test, error):
        super().addError(test, error)
        self.failed_ids.append(test.id())


if __name__ == "__main__":
    started = time.monotonic()
    result = AccountingResult()
    unittest.defaultTestLoader.loadTestsFromTestCase(OracleTests).run(result)
    print(json.dumps({"kind": "SYNTHETIC_PARSER_UNIT_TESTS_ONLY", "tests_run": result.testsRun,
                      "passed": result.passed_ids, "failed": result.failed_ids,
                      "failures": [{"test": test.id(), "traceback": text} for test, text in result.failures],
                      "errors": [{"test": test.id(), "traceback": text} for test, text in result.errors],
                      "elapsed_seconds": time.monotonic() - started, "successful": result.wasSuccessful(),
                      "compiler_executions": 0, "real_mir_executions": 0}, sort_keys=True))
    sys.exit(0 if result.wasSuccessful() else 1)
