# Independent campaign115 diagnostic/receipt oracle

## Status and complete content

This is reusable Python source and synthetic parser/receipt tests, NOT a verdict
on the implementation worker's unbuilt/unseen output and NOT executed real-MIR
evidence. Parent must supply actual authenticated implementation receipts after
both handoffs. No real-MIR passing example is included or invented.

Payloads: `oracle.py`, `test_oracle.py`, `fixture-expectation.schema.json`,
`authenticate.py`, `INPUT-AUTHENTICATION.json`, `TEST-ATTEMPTS.json`,
`RESULTS.json`, and this file. `CONTENT-MANIFEST.json` hashes all payloads;
`SEAL.json` separately binds that manifest. All files are complete, not excerpts.
No import/execute of candidate helpers; only authored Python and stdlib execute.

## Parent wiring contract

Use Python 3 with `-B`. Run `python3 -B test_oracle.py` for SYNTHETIC tests.
Operational CLI (paths denote existing collector records, not invented compiler
outputs):

```
python3 -B oracle.py --stdout RAW.stdout --stderr RAW.stderr \
  --receipt COMPLETED-NORMALIZED-RECEIPT.json \
  --expectation REGISTERED-EXPECTATION.json --output-state OUTPUT-STATE.json
```

CLI stdout is one JSON result; exit0 means `matched:true`, exit1 means not matched.
The Python API is `evaluate(stdout_bytes, stderr_bytes, receipt_bytes,
expectation_bytes, output_state_bytes, mapping_raw=None, approved_mapping=None)`.
No inputs are generated, no command is launched, and no requested output is
written. The API never returns resource/trust/final-cell credit.

Register expectations independently of the oracle's observed parse. Do not copy
an observed dump into an expectation and call that independent evidence.
`fixture-expectation.schema.json` specifies every expectation field. Runtime
checks also enforce exact types, binding, phase, counts and output freshness.
`ordinary_stdout` is the exact expected stdout for ALL outcomes, despite its
historical name. `ordinary_stderr` is exact ordinary-control stderr, allowing
only explicitly registered warnings, never silent filtering.

Receipt adapter: retain and authenticate the original launcher record and its
raw streams; normalize explicitly to the following complete object. This is a
collector adapter contract, NOT a claim these are existing compiler fields:

```
version: 1
fixture_id, fixture_path, fixture_sha256, source_fingerprint, executable_sha256,
launch_id, argv, cwd, output_path: exactly the registered expectation values
status: exited | spawn_failure | cancelled | timeout | tool_failure | running
started_ns, ended_ns: epoch-nanosecond actual launch/completion times (end may be null)
completed, reaped, timed_out, cancelled: strict booleans
exit_code: normal child exit 0..255, or null; never shell-inferred success
signal: actual signal 1..127, or null; negative subprocess return codes must map honestly
spawn_error: actual nonempty error string, or null
stdout_sha256, stderr_sha256, stdout_bytes, stderr_bytes: exact raw stream bindings
output_state_sha256: SHA256 of the exact supplied output-state JSON bytes
```

Never normalize a cancelled/unfinished/tool-failed launch to `status:exited`.
Timeout/cancellation plus a recorded terminating signal is conservatively
ambiguous here, NOT expected refusal. Log-binding or metadata errors fail closed.
The exact executable, source and fixture hashes are claims by the authenticated
collector; the oracle does not prove an executable was built from that source.
Keep raw fixture before/after and binary/source authentication outside the
oracle as part of real integration evidence. No authenticity/signature service
or dishonest-collector resistance is claimed by this local parser.

Output-state complete shape:

```
{"version":1,"path":"ABSOLUTE_REGISTERED_OUTPUT",
 "before":{"kind":"absent","sampled_ns":EPOCH_NS,"size":null,"sha256":null,"mtime_ns":null,"ctime_ns":null},
 "after":{"kind":"absent OR regular_file","sampled_ns":EPOCH_NS,
          "size":null_or_positive_int,"sha256":null_or_sha256,
          "mtime_ns":null_or_epoch_ns,"ctime_ns":null_or_epoch_ns}}
```

Use independent lstat/open/fstat observations, no symlink-following or seeded
output, same clock domain, before<=start<=end<=after. For refusal, requested
output must be absent before AND after. For ordinary `fresh_file`, the file
must be nonempty with both mtime and ctime within launch interval, not merely
within the later sampling interval. No rounding tolerance: coarse timestamps
fail closed. Collector must exclude parent-component symlinks, path aliases,
unrelated writers and races. File metadata is not proof of compiler ownership.
`output_arg` is the actual registered output option, e.g. `-o`; argv must bind
exactly one option/value pair or `option=path`. No fabricated report/output is
required. Only one requested output is modeled; extend/review the contract
before using it to justify claims about more files. `absent` for an ordinary
control is only appropriate when that actual requested path is intentionally
not produced; never substitute that for a required ordinary artifact.

Pair real negative and ordinary controls from the same authenticated compiler
source/executable and matched source fixture, with explicit launch identities
and complete separate receipts. The synthetic paired test demonstrates this
contract but establishes no real execution/capture fact.

## Actual Debug diagnostic syntax and strict limitations

The authenticated `capture` uses ordinary `:?` (not pretty Debug) and formats:

```
destruction site captured but declined: binding/temporary provenance, native resource, field glue and successor effects are not established: [UnestablishedDropSite { ... }]
```

`prepare` maps the stored error through `error`, which prepends `checked normal
destruction declined: ` and uses the function span. The driver native path can
prepend `EXEC correspondence declined: ` but its bare `dcx().err` does NOT itself
provide a source span. The default oracle accepts only a single `error: ...`
or `error[CODE]: ...` header on stderr, this exact envelope, every named site
field, and exactly one subsequent `--> absolute_fixture_path:line:column` matching
the registered diagnostic span. A bare native error WITHOUT a fixture span is
UNSCOPED and fails closed. Do not invent the missing span. A new independently
validated diagnostic protocol is the appropriate engineering fix if needed.

It parses balanced list/struct delimiters, quoted strings, numeric/bool/Option
values, all five OriginCaptureStatus variants, TemporaryOrigin and optional
TemporaryScope. Expression identifiers, TempLifetime, HirId and region Scope
remain exact balanced Debug lexemes, NOT interpreted semantic identities.
Rust Debug common escapes and `\u{...}` are handled; unsupported escapes fail
closed. Arbitrary pretty/multiline Debug, color/ANSI, JSON rustc diagnostics,
relative span paths, multiple fixture labels/primary errors, truncated logs or
unknown fields fail closed. Captures on stdout fail; no missing map/field becomes
empty. List order and duplicate observation multiplicity are preserved exactly.
Observed-local equality never means unique expression occurrence, owner or AstId.
Root type/place/projections/phase/successors/statuses must all match expectation.

Panic/ICE/backtrace markers override even a matching refusal. Unknown nonzero
errors are `unexpected_error`, never expected capture/frontend rejection. A
frontend refusal requires its separately registered exact primary message and
fixture span; that registration's source/phase interpretation must be validated
by parent, not inferred from exit status. Extra primary errors, mismatching
abort counts and stray/unscoped capture records fail. Human source snippets and
ordinary explanatory note/warning lines are not a general rustc log grammar.
Every byte outside the primary refusal header must exactly match registered
`stderr_before_error` and `stderr_after_error` context, including newlines,
source snippet, span and summary. Unregistered prose/tool errors fail closed;
registered prose itself establishes no additional evidence.

Inputs: max2MiB each, max8MiB aggregate for the five main inputs, max65536
characters per log/Debug line, max24 nested delimiters/JSON levels, max32 sites,
max128 origins/site, 90s recorded launch duration, 120s output observation window.
Acceptance also requires oracle elapsed<=2s. No process watchdog is launched;
these are size/structure bounds plus elapsed rejection, not a hard scheduler
preemption guarantee. Oversized files/nonregular inputs fail before reading;
CLI disallows final-component symlinks and detects input mutation during read.

## Explicit future diagnostic mapping

Default profile is permitted ONLY for the exact frozen fingerprint. Its hash is
SHA256 of `canonical(default_profile(FROZEN))`, where canonical means sorted
compact ASCII JSON; the registered expectation must pin it. For any modified
source/default-off diagnostic, author an explicit complete mapping object:
`version`, `source_fingerprint`, `prefix`, `envelopes`, `site_fields`,
`origin_fields`, `scope_fields`. Each field map covers every current canonical
field exactly once, mapping to unique external Debug field names. The exact
source hash, renamed fields and new envelope must be independently inspected.
Register the exact mapping file SHA256 in the expectation AND explicitly pass
`--mapping FILE --approved-mapping-sha256 SHA256` (API equivalents supported).
Nothing is auto-discovered or approved from logs or a claimed reviewed boolean.
The external approver is responsible for validating mapping/source semantics;
the digest flag is explicit consent, not a proof of that validation. New data
formats/extra semantic fields require an explicit reviewed oracle extension;
they are not silently ignored or treated as established provenance. This is
not a public admission bypass, feature enabling operation or trust change.

## Source boundary and one next engineering edge

Authenticated source anchors, relative to frozen snapshot/source:

- `rustc_mir_build/src/builder/expr/as_temp.rs:41`: scoped recursion returns the
  same temporary and appends a scope observation. At :132, ordinary temporary
  observation is appended after destination construction and before value-drop
  scheduling. Existing fixed-temp reuse/storage/value scheduling remains.
- `rustc_mir_build/src/builder/checked_drop_origins.rs:55`: append-only temporary
  observations may be incomplete; :85 retention inserts binder map and marks
  even empty temporary capture complete. Separate maps/native flag and resets
  are not an atomic epoch/session snapshot.
- `rust_verify/src/checked_normal_drop.rs:137`: collector examines actual Drop
  terminators, skipping any root local matching a binder. It retains explicit
  missing/incomplete/empty/no-match/matches status and does not resolve concrete
  destructor/glue identity. :530 capture refuses BEFORE normalize; :896 prepare
  forces elaborated query and forwards failure; :1000 hook wraps the default
  elaborated provider. All blocks, including cleanup/unreachable ones, may cause
  conservative refusal. This is not evidence that every captured site executes.
- `rust_verify/src/driver.rs:126`: native Builder/elaborated hooks; :154 forwards
  native correspondence refusal; :361 begin_native clears captures. The verifier
  begins ghost capture at :3323, installs elaborated hook at :3409, and prepare
  precedes replacement installation at :2933. There are earlier frontend gates.

Native lifecycle implication: captured local/typed scope provenance can expose
the anonymous temporary boundary, but cannot bridge resource/byte authority,
Arc strong/Weak uniqueness, Mutex ownership/poisoning, cache reservation, clone
admission, destructor/field glue or writeback/history effects. The prior review
was source/receipt scoped and its five tests were pure metadata, not Builder or
real-MIR execution. Lifecycle113 cut2 is only source candidate history, not new
native correspondence; cuts3-5 remain independent missing dependencies.

ONE concrete next engineering edge: add an explicit default-off, fixture-scoped
session/body identity diagnostic at the actual capture hook and preserve the
same identity through prepare/native refusal. Validate its real-MIR receipts
with separately registered expectations. This addresses the inspected bare
native-error scope gap and per-session capture attribution without resolving
glue or asserting ownership. It is a proposed engineering step, not work run
here, permission escalation, a follow-on chain, or proof that independent locks
are atomic. No Arc/Mutex/cache/Drop correspondence is claimed.

## Authentication and accounting limitations

First UTC resource observation: 2026-11-08T16:03:08Z; use a conservative hard
deadline16:22:00Z (initial command preceded that clock). No applicable AGENTS.md
was found in repository ancestors, targeted evidence scopes, scratch/source
ancestors or source snapshot. Source input hashes match manifest records; full
1095-file frozen snapshot aggregate is recomputed independently before final
testing and after. Initial focused source inspection preceded full aggregate
recomputation; each relied-on source was subsequently individually authenticated
and key slices reread before final testing. Do NOT misdescribe this as a full
aggregate pass performed before the first ever source read. Parent documents
are pinned entry-observed documents, NOT the live-parent source baseline.

All scratch writes use apply_patch only, Python uses -B, no caches are created.
Raw test runner JSON and every attempt/failure count are retained in
TEST-ATTEMPTS.json. Terminal-display truncations are recorded separately from
execution failures; focused rereads/hashes replaced truncated context. The
implementation receipt is not available/awaited in this lane. Free-disk samples
are not continuous monitoring and cannot establish another worker's resource
use. Final retained scratch/free/time accounting appears in SEAL.json.

Compiler/build/verifier/solver/native executions0; network0; subdelegation0;
parent/candidate/frozen/evidence/Git edits0; adoption0; trust/admission changes0.
Source final-cell credit0/native0/trust0. All18 remain OPEN. No verdict on unseen
real-MIR evidence, no resource semantics proof, no acceptance/adoption decision.
