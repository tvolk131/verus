import difflib
import hashlib
import json
from pathlib import Path
import re
import shutil
import tarfile


ROOT = Path('/private/tmp/redb-parent-repair163')
SOURCE = ROOT / 'candidate' / 'source'
BASE = Path('/private/tmp/redb-continuation160-20261109-001100/candidate/source')
OUTPUT = ROOT / 'payload'
CHANGED = ['vir/src/native_resource/continuation160.rs',
    'vir/src/native_resource/continuation160/tests.rs',
    'rust_verify/src/bin/continuation160.rs', 'rust_verify/src/allocation_selection160.rs']


def digest(payload):
    return hashlib.sha256(payload).hexdigest()


OUTPUT.mkdir(exist_ok=False)
patch = ''
for name in CHANGED:
    destination = OUTPUT / 'source' / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(SOURCE / name, destination)
    patch += ''.join(difflib.unified_diff((BASE / name).read_text().splitlines(True),
        (SOURCE / name).read_text().splitlines(True), fromfile='a/' + name, tofile='b/' + name))
(OUTPUT / 'repair163.patch').write_text(patch)
test_name = CHANGED[1]
current_tests = (SOURCE / test_name).read_text()
initial_tests = current_tests
for suffix, first_holder, second_holder in [('child', 'field(3, 0)', 'place(3)'),
                                           ('parent', 'place(3)', 'field(3, 0)')]:
    replacement = ('#[test]\nfn loan_destination_cannot_overwrite_live_' + suffix + '() {\n'
        '    assert_eq!(run(vec![invoke(), normal(),\n'
        '        Effect160::Loan { root: place(1), holder: ' + first_holder + ' },\n'
        '        Effect160::Loan { root: place(2), holder: ' + second_holder + ' }]).err(),\n'
        '        Some(Refusal160::LiveDestination));\n}\n')
    initial_tests, count = re.subn(r'#\[test\]\nfn loan_destination_cannot_overwrite_live_' + suffix
        + r'\(\) \{.*?\n\}\n', lambda match: replacement, initial_tests, count=1, flags=re.S)
    assert count == 1
initial_tests = initial_tests.replace('node(vec![Effect160::Exit], vec![]), node(vec![Effect160::Exit], vec![])',
    'node(vec![], vec![]), node(vec![], vec![])')
first_receipt = json.loads((ROOT / 'baseline-loan-regressions.receipt.json').read_text())
assert digest(initial_tests.encode()) == first_receipt['source_entry'][test_name]
(OUTPUT / 'initial-tests-reconstructed.rs').write_text(initial_tests)
second_receipt = json.loads((ROOT / 'complete-loan-counterexamples.receipt.json').read_text())
assert digest(current_tests.encode()) == second_receipt['source_entry'][test_name]
proof_receipt = json.loads((ROOT / 'corrected-structural-tests.receipt.json').read_text())
build_receipt = json.loads((ROOT / 'corrected-compiler-build-snapshot.receipt.json').read_text())
for receipt in [proof_receipt, build_receipt]:
    assert receipt['returncode'] == 0 and receipt['reaped'] and not receipt['errors']
    assert receipt['source_entry'] == receipt['source_exit']
    for name in CHANGED:
        assert digest((SOURCE / name).read_bytes()) == receipt['source_exit'][name]
for path in sorted(ROOT.iterdir()):
    if path.name.endswith(('.receipt.json', '.stdout', '.stderr')) or path.name in {'run.py', 'seal.py', 'REPORT163.md'}:
        shutil.copy2(path, OUTPUT / path.name)
summary = dict(test_result='27 structural tests passed,204 filtered; not solver/native proof',
    initial_result='24 passed3 failed:2 initial regression fixtures +existing coverage fixture',
    complete_counterexample_result='25 passed2 intended loan-overlap failures; old checker returned success',
    build_result='success after monitor-race and explicit unversioned source-snapshot setup repairs',
    initial_tests_qualification='RECONSTRUCTED_FROM_RETAINED_PATCH_DELTAS_MATCHES_RECORDED_ENTRY_SHA_NOT_NEW_HISTORICAL_OBSERVATION',
    changed={name:digest((SOURCE / name).read_bytes()) for name in CHANGED},
    patch_sha256=digest((OUTPUT / 'repair163.patch').read_bytes()),
    compiled_binary_sha256=digest((ROOT / 'target/debug/continuation160').read_bytes()),
    old160='SEALED19/32_UNCHANGED', old158='SEALED17/32_FAILED2GiB_UNCHANGED',
    original_native_acceptance=0, operative_laws=0, schema=1, all18='OPEN')
(OUTPUT / 'SUMMARY163.json').write_text(json.dumps(summary, indent=2) + '\n')
records = []
for path in sorted(OUTPUT.rglob('*')):
    if path.is_file():
        payload = path.read_bytes()
        records.append(dict(path=str(path.relative_to(OUTPUT)), bytes=len(payload), sha256=digest(payload)))
manifest = OUTPUT / 'MANIFEST163.json'
manifest.write_text(json.dumps(records, indent=2) + '\n')
archive = ROOT / 'HANDOFF163.tar.gz'
with archive.open('xb') as output:
    with tarfile.open(fileobj=output, mode='w:gz') as package:
        for record in records:
            package.add(OUTPUT / record['path'], arcname=record['path'], recursive=False)
        package.add(manifest, arcname=manifest.name, recursive=False)
with tarfile.open(archive, 'r:gz') as package:
    members = package.getmembers()
    assert len(members) == len(records) + 1 and len({member.name for member in members}) == len(members)
    for member in members:
        assert member.isfile() and package.extractfile(member).read() == (OUTPUT / member.name).read_bytes()
handoff = dict(root=str(ROOT), payload=str(OUTPUT), summary=summary,
    manifest_sha256=digest(manifest.read_bytes()), archive_sha256=digest(archive.read_bytes()),
    archive_members=len(records) + 1, heavy_slot='RELEASED_SIX_CHARGED_COMMANDS_REAPED_NO_OTHER_RUN',
    qualification='Selected source/command endpoints and reconstructed initial fixture; no historical bootstrap/runtime/native semantics claim')
(ROOT / 'HANDOFF163.json').write_text(json.dumps(handoff, indent=2) + '\n')
print(json.dumps(dict(patch_sha256=summary['patch_sha256'], archive_sha256=handoff['archive_sha256'],
    handoff_sha256=digest((ROOT / 'HANDOFF163.json').read_bytes()), archive_members=handoff['archive_members'])))
