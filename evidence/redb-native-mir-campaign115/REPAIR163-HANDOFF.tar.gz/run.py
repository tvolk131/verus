import datetime
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time


ROOT = Path('/private/tmp/redb-parent-repair163')
SOURCE = ROOT / 'candidate' / 'source'
TARGET = ROOT / 'target'
MINIMUM_FREE = 16 * 1024 ** 3
MAXIMUM_SCRATCH = 1536 * 1024 ** 2


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def resources():
    allocated = 0
    logical = 0
    vanished_files = 0
    for directory, names, files in os.walk(ROOT):
        for name in files:
            try:
                information = (Path(directory) / name).stat()
            except FileNotFoundError:
                vanished_files += 1
                continue
            allocated += information.st_blocks * 512
            logical += information.st_size
    space = os.statvfs(ROOT)
    return dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        allocated=allocated, logical=logical, vanished_files=vanished_files,
        free=space.f_bavail * space.f_frsize)


def source_hashes():
    return {str(path.relative_to(SOURCE)): digest(path) for path in sorted(SOURCE.rglob('*'))
            if path.is_file()}


label = sys.argv[1]
if not label.replace('-', '').isalnum():
    raise ValueError('invalid receipt label')
argv = sys.argv[2:]
if not argv:
    raise ValueError('missing command')
prior = json.loads(Path('/private/tmp/redb-continuation160-20261109-001100/core-tests.receipt.json').read_text())
environment = {key: value.replace('/private/tmp/redb-continuation160-20261109-001100', str(ROOT))
               for key, value in prior['env'].items()}
allowed = {'CARGO_BUILD_BUILD_DIR', 'CARGO_BUILD_JOBS', 'CARGO_HOME', 'CARGO_INCREMENTAL',
    'CARGO_NET_OFFLINE', 'CARGO_PROFILE_DEV_DEBUG', 'CARGO_PROFILE_TEST_DEBUG',
    'CARGO_TARGET_DIR', 'DYLD_LIBRARY_PATH', 'HOME', 'LANG', 'LC_ALL', 'PATH',
    'RUSTC', 'RUSTC_BOOTSTRAP', 'TMPDIR', 'VSTD_KIND'}
if set(environment) != allowed:
    raise ValueError('unexpected environment keys')
if 'build' in argv:
    environment['VARGO_TOOLCHAIN'] = '1.99.1-aarch64-apple-darwin'
    environment['VERUS_SOURCE_SNAPSHOT_SHA256'] = hashlib.sha256(
        json.dumps(source_hashes(), sort_keys=True, separators=(',', ':')).encode()).hexdigest()
receipt_path = ROOT / (label + '.receipt.json')
if receipt_path.exists():
    raise ValueError('receipt exists')
receipt = dict(argv=argv, env=environment, cwd=str(SOURCE), source_entry=source_hashes(),
    start_epoch_ns=time.time_ns(), samples=[], errors=[], spawned=False, reaped=False)
process = None
interrupted = None
limit = 600 if 'build' in argv else 180
stdout_path = ROOT / (label + '.stdout')
stderr_path = ROOT / (label + '.stderr')
try:
    first = resources()
    receipt['samples'].append(first)
    if first['free'] <= MINIMUM_FREE or max(first['allocated'], first['logical']) > MAXIMUM_SCRATCH:
        raise RuntimeError('resource preflight refused')
    with stdout_path.open('xb') as stdout, stderr_path.open('xb') as stderr:
        process = subprocess.Popen(argv, cwd=SOURCE, env=environment,
            stdout=stdout, stderr=stderr, start_new_session=True)
        receipt['spawned'] = True
        receipt['pid'] = process.pid
        deadline = time.monotonic() + limit
        while process.poll() is None:
            sample = resources()
            receipt['samples'].append(sample)
            if sample['free'] <= MINIMUM_FREE or max(sample['allocated'], sample['logical']) > MAXIMUM_SCRATCH:
                receipt['errors'].append('resource threshold crossed')
                break
            if time.monotonic() >= deadline:
                receipt['errors'].append('timeout')
                break
            time.sleep(0.5)
        if process.returncode is None:
            os.killpg(process.pid, signal.SIGKILL)
        receipt['returncode'] = process.wait(timeout=20)
        receipt['reaped'] = True
except BaseException as failure:
    interrupted = failure
    receipt['errors'].append(type(failure).__name__ + ': ' + str(failure))
    if process is not None and process.returncode is None:
        os.killpg(process.pid, signal.SIGKILL)
        receipt['returncode'] = process.wait(timeout=20)
        receipt['reaped'] = True
finally:
    receipt['end_epoch_ns'] = time.time_ns()
    receipt['source_exit'] = source_hashes()
    receipt['samples'].append(resources())
    for name, path in [('stdout', stdout_path), ('stderr', stderr_path)]:
        if path.exists():
            receipt[name + '_sha256'] = digest(path)
    with receipt_path.open('x') as output:
        json.dump(receipt, output, indent=2, sort_keys=True)
        output.write('\n')
print(json.dumps({key: receipt.get(key) for key in ('spawned', 'returncode', 'reaped', 'errors')}))
if interrupted is not None:
    raise interrupted
sys.exit(receipt.get('returncode', 1))
