use crate::ast::*;
use crate::ast_util::{mk_ineq, types_equal, unit_typ};
use crate::def::Spanned;
use crate::messages::Span;
use std::collections::{BTreeMap, BTreeSet, HashSet, VecDeque};
use std::hash::Hash;
use std::sync::Arc;

pub const LAW160: &str = "NATIVE_RAW_ALLOC_NORMAL158_V1";
pub const ISSUANCE_GATE160: &str = "PENDING_REVIEW";

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum Refusal160 {
    PendingReview,
    MissingNativeEventInterpretation,
    MissingVstdTypes,
    WrongResourceType,
    WrongValueType,
    DuplicateOccurrence,
    MissingCoverage,
    WrongNormalEdge,
    UnsupportedOutcome,
    UnprovedApplicability,
    WitnessReplay,
    ResourceReplay,
    StaleHolder,
    LiveDestination,
    OutstandingLoan,
    IncompatibleJoin,
    ResourceLeak,
}

pub enum NativeSemanticWitness160 {}

pub struct ResourceTypes160 {
    raw: Typ,
    dealloc: Typ,
    resolved: bool,
}

fn resource_type(name: &str, mode: Mode, typ: &Typ) -> bool {
    let TypX::Datatype(Dt::Path(path), arguments, implementations) = &**typ else {
        return false;
    };
    path.krate == CrateId::Vstd
        && path.segments.iter().map(|part| part.as_str()).eq(["raw_ptr", name])
        && arguments.is_empty()
        && implementations.is_empty()
        && mode == Mode::Proof
}

impl ResourceTypes160 {
    pub fn from_datatypes(datatypes: &[Datatype]) -> Result<Self, Refusal160> {
        let find = |name: &str| {
            let matching = datatypes.iter().filter_map(|datatype| {
                let typ = Arc::new(TypX::Datatype(
                    datatype.x.name.clone(), Arc::new(vec![]), Arc::new(vec![]),
                ));
                resource_type(name, datatype.x.mode, &typ).then_some(typ)
            }).collect::<Vec<_>>();
            if matching.len() == 1 { Ok(matching[0].clone()) }
            else { Err(Refusal160::MissingVstdTypes) }
        };
        Ok(Self { raw: find("PointsToRaw")?, dealloc: find("Dealloc")?, resolved: true })
    }

    pub fn unresolved_native_ports() -> Self {
        let typ = |name: &str| Arc::new(TypX::Datatype(Dt::Path(Arc::new(PathX {
            krate: CrateId::Vstd,
            segments: Arc::new(vec![Arc::new("raw_ptr".into()), Arc::new(name.into())]),
        })), Arc::new(vec![]), Arc::new(vec![])));
        Self { raw: typ("PointsToRaw"), dealloc: typ("Dealloc"), resolved: false }
    }
}

pub struct ResourceBindings160 {
    raw: Param,
    dealloc: Param,
    resolved: bool,
}

impl ResourceBindings160 {
    pub fn new(span: &Span, types: &ResourceTypes160, raw: VarIdent, dealloc: VarIdent)
        -> Result<Self, Refusal160>
    {
        if raw == dealloc { return Err(Refusal160::DuplicateOccurrence); }
        let binding = |name, typ| Spanned::new(span.clone(), ParamX {
            name, typ, mode: Mode::Proof, user_mut: false, unwrapped_info: None,
        });
        Ok(Self { raw: binding(raw, types.raw.clone()), dealloc: binding(dealloc, types.dealloc.clone()), resolved: types.resolved })
    }

    pub fn parameters(&self) -> [&Param; 2] { [&self.raw, &self.dealloc] }

    fn validate(&self) -> Result<(), Refusal160> {
        if !resource_type("PointsToRaw", self.raw.x.mode, &self.raw.x.typ)
            || !resource_type("Dealloc", self.dealloc.x.mode, &self.dealloc.x.typ)
            || self.raw.x.name == self.dealloc.x.name
        { return Err(Refusal160::WrongResourceType); }
        Ok(())
    }
}

pub struct ActualValues160 {
    pub size: Expr,
    pub alignment: AlignmentAsUsize160,
    pub full_pointer: Expr,
}

pub struct AlignmentAsUsize160 {
    operand: Expr,
    numeric_result: Param,
}

impl AlignmentAsUsize160 {
    pub fn new(operand: Expr, result: VarIdent) -> Result<Self, Refusal160> {
        let TypX::Datatype(Dt::Path(path), arguments, _) = &*operand.typ else {
            return Err(Refusal160::WrongValueType);
        };
        if path.krate != CrateId::Core || !arguments.is_empty()
            || !path.segments.iter().map(|part| part.as_str()).eq(["mem", "alignment", "Alignment"])
        { return Err(Refusal160::WrongValueType); }
        let numeric_result = Spanned::new(operand.span.clone(), ParamX {
            name: result, typ: Arc::new(TypX::Int(IntRange::USize)), mode: Mode::Exec,
            user_mut: false, unwrapped_info: None,
        });
        Ok(Self { operand, numeric_result })
    }

    pub fn operand(&self) -> &Expr { &self.operand }
    pub fn numeric_result(&self) -> &Param { &self.numeric_result }
    pub fn value(&self) -> Expr {
        SpannedTyped::new(&self.numeric_result.span, &self.numeric_result.x.typ,
            ExprX::Var(self.numeric_result.x.name.clone()))
    }
}

impl ActualValues160 {
    fn validate(&self) -> Result<(), Refusal160> {
        let is_usize = |typ: &Typ| matches!(&**typ, TypX::Int(IntRange::USize));
        let is_pointer = matches!(&*self.full_pointer.typ,
            TypX::Primitive(Primitive::Ptr, arguments)
            if arguments.len() == 1 && matches!(&*arguments[0], TypX::Int(IntRange::U(8))));
        if !is_usize(&self.size.typ) || !is_usize(&self.alignment.value().typ) || !is_pointer {
            return Err(Refusal160::WrongValueType);
        }
        if [&self.size].iter().any(|value|
            matches!(&value.x, ExprX::Const(Constant::Int(integer)) if integer <= &0.into())) {
            return Err(Refusal160::UnsupportedOutcome);
        }
        Ok(())
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord)]
pub enum Obligation160 {
    ActualPositiveSize,
    ActualValidLayout,
    ActualFalseZeroedBranch,
    ActualNonnullNormalReturn,
    NativeFullPointerInterpretation,
    DynamicActivationAndInvocation,
    GlobalLiveAndStaleResources,
    RuntimeAllocatorBinding,
    HeaderMetadataIteratorIndexPriorValues,
    CacheCallerFrameAndCleanup,
}

pub struct Applicability160 {
    assertions: Vec<Stmt>,
    open: BTreeSet<Obligation160>,
}

impl Applicability160 {
    pub fn pending() -> Self {
        use Obligation160::*;
        Self { assertions: vec![], open: BTreeSet::from([
            ActualPositiveSize, ActualValidLayout, ActualFalseZeroedBranch,
            ActualNonnullNormalReturn, NativeFullPointerInterpretation,
            DynamicActivationAndInvocation, GlobalLiveAndStaleResources,
            RuntimeAllocatorBinding, HeaderMetadataIteratorIndexPriorValues,
            CacheCallerFrameAndCleanup,
        ]) }
    }

    pub fn push_assertion(&mut self, assertion: Stmt) -> Result<(), Refusal160> {
        let StmtX::Expr(expression) = &assertion.x else { return Err(Refusal160::UnprovedApplicability); };
        if !matches!(&expression.x, ExprX::AssertAssume { is_assume: false, .. })
            || !types_equal(&expression.typ, &unit_typ())
        { return Err(Refusal160::UnprovedApplicability); }
        self.assertions.push(assertion);
        Ok(())
    }

    pub fn open(&self) -> &BTreeSet<Obligation160> { &self.open }
    pub fn assertions(&self) -> &[Stmt] { &self.assertions }

    fn assert_positive_size(&mut self, actual: &ActualValues160) {
        let zero = SpannedTyped::new(&actual.size.span, &actual.size.typ,
            ExprX::Const(Constant::Int(0.into())));
        let predicate = mk_ineq(&actual.size.span, &actual.size, &zero, InequalityOp::Gt);
        let assertion = SpannedTyped::new(&actual.size.span, &unit_typ(), ExprX::AssertAssume {
            is_assume: false, expr: predicate,
            msg: Some(crate::messages::error(&actual.size.span, "NATIVE160_ACTUAL_POSITIVE_SIZE_OPEN")),
        });
        self.assertions.push(Spanned::new(actual.size.span.clone(), StmtX::Expr(assertion)));
    }
}

pub struct SelectedCall160<Origin, NativeOperand, NativePlace> {
    pub origin: Origin,
    pub size: NativeOperand,
    pub align: NativeOperand,
    pub result: NativePlace,
    pub normal: usize,
    pub call_point: usize,
}

pub struct NativeReturn160<Origin, NativeOperand, NativePlace> {
    call: SelectedCall160<Origin, NativeOperand, NativePlace>,
    values: ActualValues160,
    resources: ResourceBindings160,
    applicability: Applicability160,
    binder: DynamicBinder160,
}

pub enum DynamicBinder160 {
    FreshInvocationWithinEnclosingNativeActivation,
}

impl<Origin, NativeOperand, NativePlace> NativeReturn160<Origin, NativeOperand, NativePlace> {
    pub fn lower(
        call: SelectedCall160<Origin, NativeOperand, NativePlace>, values: ActualValues160,
        resources: ResourceBindings160, mut applicability: Applicability160,
    ) -> Result<Self, Refusal160> {
        values.validate()?;
        resources.validate()?;
        applicability.assert_positive_size(&values);
        Ok(Self { call, values, resources, applicability,
            binder: DynamicBinder160::FreshInvocationWithinEnclosingNativeActivation })
    }

    pub fn normal(&self) -> usize { self.call.normal }
    pub fn call(&self) -> &SelectedCall160<Origin, NativeOperand, NativePlace> { &self.call }
    pub fn values(&self) -> &ActualValues160 { &self.values }
    pub fn resources(&self) -> &ResourceBindings160 { &self.resources }
    pub fn applicability(&self) -> &Applicability160 { &self.applicability }
    pub fn binder(&self) -> &DynamicBinder160 { &self.binder }

    pub fn admit_to_sst(&self) -> Result<Vec<Stmt>, Refusal160> {
        if !self.resources.resolved { return Err(Refusal160::MissingVstdTypes); }
        Err(Refusal160::PendingReview)
    }

    pub fn bind_native_interpretation(&self, witness: NativeSemanticWitness160) -> Vec<Stmt> {
        match witness {}
    }
}

pub struct NativeProgram160<Origin, NativeOperand, NativePlace> {
    edges: Vec<NativeReturn160<Origin, NativeOperand, NativePlace>>,
}

impl<Origin: Eq + Hash + Clone, NativeOperand, NativePlace> NativeProgram160<Origin, NativeOperand, NativePlace> {
    pub fn connect(edges: Vec<NativeReturn160<Origin, NativeOperand, NativePlace>>,
        actual_occurrences: &HashSet<Origin>) -> Result<Self, Refusal160>
    {
        let mut origins = HashSet::new();
        let mut names = BTreeSet::new();
        for edge in &edges {
            if !origins.insert(edge.call.origin.clone()) { return Err(Refusal160::DuplicateOccurrence); }
            for parameter in edge.resources.parameters() {
                if !names.insert(parameter.x.name.clone()) { return Err(Refusal160::DuplicateOccurrence); }
            }
        }
        if &origins != actual_occurrences { return Err(Refusal160::MissingCoverage); }
        Ok(Self { edges })
    }

    pub fn edges(&self) -> &[NativeReturn160<Origin, NativeOperand, NativePlace>] { &self.edges }
    pub fn admit_to_sst(&self) -> Result<(), Refusal160> { Err(Refusal160::PendingReview) }
}

#[derive(Clone, Debug, PartialEq, Eq, PartialOrd, Ord)]
pub struct Place160(pub Vec<usize>);

fn overlaps(left: &Place160, right: &Place160) -> bool {
    left.0.starts_with(&right.0) || right.0.starts_with(&left.0)
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord)]
pub enum Port160 { Raw, Dealloc }

#[derive(Clone, Debug, PartialEq, Eq)]
enum Holder160 {
    Resource { event: usize, port: Port160 },
    Loan { root: Place160 },
    Stale,
}

#[derive(Clone, Debug, Default, PartialEq, Eq)]
struct Flow160 {
    pending: Option<usize>,
    holders: BTreeMap<Place160, Holder160>,
}

impl Flow160 {
    fn invalidate(&mut self, place: &Place160) {
        for (holder, value) in &mut self.holders {
            if overlaps(holder, place)
                || matches!(value, Holder160::Loan { root } if overlaps(root, place))
            { *value = Holder160::Stale; }
        }
    }

    fn move_place(&mut self, source: &Place160, destination: &Place160) -> Result<(), Refusal160> {
        if overlaps(source, destination) { return Err(Refusal160::LiveDestination); }
        if self.holders.iter().any(|(holder, value)| overlaps(holder, destination)
            && !matches!(value, Holder160::Stale)) { return Err(Refusal160::LiveDestination); }
        let transferred = self.holders.iter().filter_map(|(holder, value)| {
            if holder.0.starts_with(&source.0) {
                let mut moved = destination.0.clone();
                moved.extend_from_slice(&holder.0[source.0.len()..]);
                Some((Place160(moved), value.clone()))
            } else { None }
        }).collect::<Vec<_>>();
        self.invalidate(source);
        for (holder, value) in transferred {
            if matches!(value, Holder160::Stale) { return Err(Refusal160::StaleHolder); }
            if matches!(&value, Holder160::Loan { root } if overlaps(root, source)) {
                self.holders.insert(holder, Holder160::Stale);
                continue;
            }
            self.holders.insert(holder, value);
        }
        Ok(())
    }

    fn consume(&mut self, place: &Place160, port: Port160) -> Result<(), Refusal160> {
        if self.holders.values().any(|value| matches!(value,
            Holder160::Loan { root } if overlaps(root, place))) {
            return Err(Refusal160::OutstandingLoan);
        }
        match self.holders.get(place) {
            Some(Holder160::Resource { port: actual, .. }) if *actual == port => {
                self.invalidate(place); Ok(())
            }
            _ => Err(Refusal160::ResourceReplay),
        }
    }
}

#[derive(Clone, Debug)]
pub enum Effect160 {
    Invoke { event: usize },
    Normal { event: usize, raw: Place160, dealloc: Place160 },
    NonNormal,
    Move { source: Place160, destination: Place160 },
    Destroy { place: Place160 },
    Loan { root: Place160, holder: Place160 },
    EndLoan { holder: Place160 },
    Use { holder: Place160 },
    Consume { holder: Place160, port: Port160 },
    CopyResource,
    ImportResource,
    Exit,
    Ordinary,
    Unsupported,
}

pub struct Point160 {
    pub effects: Vec<Effect160>,
    pub successors: Vec<usize>,
    pub cleanup: bool,
}

pub struct CheckedFlow160 {
    pub covered_points: usize,
    pub static_calls: usize,
}

pub fn check_flow(points: &[Point160], entry: usize,
    required_calls: &BTreeSet<(usize, usize)>) -> Result<CheckedFlow160, Refusal160>
{
    let mut covered_calls = BTreeSet::new();
    let mut events = BTreeSet::new();
    for (point, node) in points.iter().enumerate() {
        if node.successors.iter().any(|successor| *successor >= points.len()) {
            return Err(Refusal160::MissingCoverage);
        }
        for (effect, operation) in node.effects.iter().enumerate() {
            if let Effect160::Invoke { event } = operation {
                if node.cleanup || !events.insert(*event) {
                    return Err(Refusal160::DuplicateOccurrence);
                }
                covered_calls.insert((point, effect));
            }
        }
    }
    if &covered_calls != required_calls || entry >= points.len() {
        return Err(Refusal160::MissingCoverage);
    }
    let mut incoming = BTreeMap::from([(entry, Flow160::default())]);
    let mut queue = VecDeque::from([entry]);
    let mut visited = BTreeSet::new();
    while let Some(point) = queue.pop_front() {
        let node = &points[point];
        let mut state = incoming[&point].clone();
        visited.insert(point);
        for operation in &node.effects {
            match operation {
                Effect160::Invoke { event } => {
                    if state.pending.is_some() { return Err(Refusal160::WitnessReplay); }
                    if state.holders.values().any(|holder| matches!(holder,
                        Holder160::Resource { event: previous, .. } if previous == event)) {
                        return Err(Refusal160::ResourceLeak);
                    }
                    state.pending = Some(*event);
                }
                Effect160::Normal { event, raw, dealloc } => {
                    if node.cleanup || state.pending.take() != Some(*event) {
                        return Err(Refusal160::WitnessReplay);
                    }
                    if overlaps(raw, dealloc) { return Err(Refusal160::LiveDestination); }
                    for (place, port) in [(raw, Port160::Raw), (dealloc, Port160::Dealloc)] {
                        if state.holders.iter().any(|(holder, value)| overlaps(holder, place)
                            && !matches!(value, Holder160::Stale)) {
                            return Err(Refusal160::LiveDestination);
                        }
                        state.holders.insert(place.clone(), Holder160::Resource { event: *event, port });
                    }
                }
                Effect160::NonNormal | Effect160::Unsupported => return Err(Refusal160::UnsupportedOutcome),
                Effect160::CopyResource | Effect160::ImportResource => return Err(Refusal160::ResourceReplay),
                Effect160::Move { source, destination } => state.move_place(source, destination)?,
                Effect160::Destroy { place } => state.invalidate(place),
                Effect160::Loan { root, holder } => {
                    if !matches!(state.holders.get(root), Some(Holder160::Resource { .. })) {
                        return Err(Refusal160::StaleHolder);
                    }
                    if state.holders.iter().any(|(destination, value)| overlaps(destination, holder)
                        && !matches!(value, Holder160::Stale)) {
                        return Err(Refusal160::LiveDestination);
                    }
                    state.holders.insert(holder.clone(), Holder160::Loan { root: root.clone() });
                }
                Effect160::EndLoan { holder } => {
                    if !matches!(state.holders.get(holder), Some(Holder160::Loan { .. })) {
                        return Err(Refusal160::StaleHolder);
                    }
                    state.holders.insert(holder.clone(), Holder160::Stale);
                }
                Effect160::Use { holder } => {
                    if !matches!(state.holders.get(holder), Some(Holder160::Resource { .. } | Holder160::Loan { .. })) {
                        return Err(Refusal160::StaleHolder);
                    }
                }
                Effect160::Consume { holder, port } => state.consume(holder, *port)?,
                Effect160::Exit => {
                    if state.pending.is_some() || state.holders.values().any(|holder| !matches!(holder, Holder160::Stale)) {
                        return Err(Refusal160::ResourceLeak);
                    }
                }
                Effect160::Ordinary => {}
            }
        }
        if node.successors.is_empty() && !matches!(node.effects.last(), Some(Effect160::Exit)) {
            return Err(Refusal160::ResourceLeak);
        }
        if node.effects.iter().enumerate().any(|(index, effect)| matches!(effect, Effect160::Exit)
            && (index + 1 != node.effects.len() || !node.successors.is_empty())) {
            return Err(Refusal160::WrongNormalEdge);
        }
        state.holders.retain(|_, holder| !matches!(holder, Holder160::Stale));
        for successor in &node.successors {
            if let Some(previous) = incoming.get(successor) {
                if previous != &state { return Err(Refusal160::IncompatibleJoin); }
            } else {
                incoming.insert(*successor, state.clone());
                queue.push_back(*successor);
            }
        }
    }
    if visited.len() != points.len() { return Err(Refusal160::MissingCoverage); }
    Ok(CheckedFlow160 { covered_points: visited.len(), static_calls: covered_calls.len() })
}

pub fn refuse_export160() -> Result<(), Refusal160> { Err(Refusal160::PendingReview) }

#[cfg(test)]
mod tests;
