use super::*;
use crate::ast_util::{bool_typ, int_typ};

fn place(local: usize) -> Place160 { Place160(vec![local]) }
fn field(local: usize, field: usize) -> Place160 { Place160(vec![local, field]) }

fn node(effects: Vec<Effect160>, successors: Vec<usize>) -> Point160 {
    Point160 { effects, successors, cleanup: false }
}

fn invoke() -> Effect160 { Effect160::Invoke { event: 0 } }
fn normal() -> Effect160 { Effect160::Normal { event: 0, raw: place(1), dealloc: place(2) } }
fn consume() -> Vec<Effect160> { vec![
    Effect160::Consume { holder: place(1), port: Port160::Raw },
    Effect160::Consume { holder: place(2), port: Port160::Dealloc },
] }

fn run(effects: Vec<Effect160>) -> Result<CheckedFlow160, Refusal160> {
    check_flow(&[node(effects, vec![])], 0, &BTreeSet::from([(0, 0)]))
}

#[test]
fn normal_consumptive_flow() {
    let mut effects = vec![invoke(), normal()];
    effects.extend(consume()); effects.push(Effect160::Exit);
    assert_eq!(run(effects).unwrap().static_calls, 1);
}

#[test]
fn replay_normal_witness_refused() {
    assert_eq!(run(vec![invoke(), normal(), normal()]).err(), Some(Refusal160::WitnessReplay));
}

#[test]
fn duplicate_static_occurrence_refused() {
    assert_eq!(run(vec![invoke(), invoke()]).err(), Some(Refusal160::DuplicateOccurrence));
}

#[test]
fn consume_twice_refused() {
    let mut effects = vec![invoke(), normal()]; effects.extend(consume()); effects.extend(consume());
    assert_eq!(run(effects).err(), Some(Refusal160::ResourceReplay));
}

#[test]
fn clone_and_import_refused() {
    for forbidden in [Effect160::CopyResource, Effect160::ImportResource] {
        assert_eq!(run(vec![invoke(), normal(), forbidden]).err(), Some(Refusal160::ResourceReplay));
    }
}

#[test]
fn unsupported_outcome_refused() {
    assert_eq!(run(vec![invoke(), Effect160::NonNormal]).err(), Some(Refusal160::UnsupportedOutcome));
}

#[test]
fn nonnormal_cleanup_participates() {
    let mut cleanup = node(vec![Effect160::NonNormal], vec![]); cleanup.cleanup = true;
    assert_eq!(check_flow(&[node(vec![invoke()], vec![1]), cleanup], 0,
        &BTreeSet::from([(0, 0)])).err(), Some(Refusal160::UnsupportedOutcome));
}

#[test]
fn normal_in_cleanup_refused() {
    let mut cleanup = node(vec![normal()], vec![]); cleanup.cleanup = true;
    assert_eq!(check_flow(&[node(vec![invoke()], vec![1]), cleanup], 0,
        &BTreeSet::from([(0, 0)])).err(), Some(Refusal160::WitnessReplay));
}

#[test]
fn full_place_move_relocates_all_children() {
    let mut state = Flow160::default();
    state.holders.insert(field(1, 0), Holder160::Resource { event: 0, port: Port160::Raw });
    state.holders.insert(field(1, 1), Holder160::Resource { event: 0, port: Port160::Dealloc });
    state.move_place(&place(1), &place(2)).unwrap();
    assert!(matches!(state.holders[&field(1, 0)], Holder160::Stale));
    assert!(matches!(state.holders[&field(2, 0)], Holder160::Resource { port: Port160::Raw, .. }));
    assert!(matches!(state.holders[&field(2, 1)], Holder160::Resource { port: Port160::Dealloc, .. }));
}

#[test]
fn full_place_destroy_invalidates_root_and_loans() {
    let mut state = Flow160::default();
    state.holders.insert(field(1, 0), Holder160::Resource { event: 0, port: Port160::Raw });
    state.holders.insert(place(3), Holder160::Loan { root: field(1, 0) });
    state.invalidate(&place(1));
    assert!(state.holders.values().all(|value| matches!(value, Holder160::Stale)));
}

#[test]
fn move_invalidates_external_loan_not_retargets_it() {
    let mut state = Flow160::default();
    state.holders.insert(place(1), Holder160::Resource { event: 0, port: Port160::Raw });
    state.holders.insert(place(3), Holder160::Loan { root: place(1) });
    state.move_place(&place(1), &place(2)).unwrap();
    assert!(matches!(state.holders[&place(3)], Holder160::Stale));
}

#[test]
fn outstanding_loan_blocks_consumption() {
    assert_eq!(run(vec![invoke(), normal(), Effect160::Loan { root: place(1), holder: place(3) },
        consume().remove(0)]).err(), Some(Refusal160::OutstandingLoan));
}

#[test]
fn loan_destination_cannot_overwrite_live_child() {
    let mut effects = vec![invoke(), normal(),
        Effect160::Loan { root: place(1), holder: field(3, 0) },
        Effect160::Loan { root: place(2), holder: place(3) },
        Effect160::Use { holder: field(3, 0) },
        Effect160::EndLoan { holder: field(3, 0) }, Effect160::EndLoan { holder: place(3) }];
    effects.extend(consume());
    effects.push(Effect160::Exit);
    assert_eq!(run(effects).err(), Some(Refusal160::LiveDestination));
}

#[test]
fn loan_destination_cannot_overwrite_live_parent() {
    let mut effects = vec![invoke(), normal(),
        Effect160::Loan { root: place(1), holder: place(3) },
        Effect160::Loan { root: place(2), holder: field(3, 0) },
        Effect160::Use { holder: place(3) },
        Effect160::EndLoan { holder: field(3, 0) }, Effect160::EndLoan { holder: place(3) }];
    effects.extend(consume());
    effects.push(Effect160::Exit);
    assert_eq!(run(effects).err(), Some(Refusal160::LiveDestination));
}

#[test]
fn disjoint_loan_destinations_remain_supported() {
    let mut effects = vec![invoke(), normal(),
        Effect160::Loan { root: place(1), holder: place(3) },
        Effect160::Loan { root: place(2), holder: place(4) },
        Effect160::Use { holder: place(3) }, Effect160::Use { holder: place(4) },
        Effect160::EndLoan { holder: place(3) }, Effect160::EndLoan { holder: place(4) }];
    effects.extend(consume());
    effects.push(Effect160::Exit);
    assert!(run(effects).is_ok());
}

#[test]
fn loop_rebinds_symbolic_invocation_after_consumption() {
    let mut effects = vec![invoke(), normal()]; effects.extend(consume());
    let checked = check_flow(&[node(effects, vec![0, 1]), node(vec![Effect160::Exit], vec![])],
        0, &BTreeSet::from([(0, 0)])).unwrap();
    assert_eq!(checked.covered_points, 2);
}

#[test]
fn loop_cannot_keep_previous_resources() {
    assert_eq!(check_flow(&[node(vec![invoke(), normal()], vec![0])], 0,
        &BTreeSet::from([(0, 0)])).err(), Some(Refusal160::IncompatibleJoin));
}

#[test]
fn all_bundles_and_points_required() {
    assert_eq!(check_flow(&[node(vec![invoke()], vec![])], 0, &BTreeSet::new()).err(),
        Some(Refusal160::MissingCoverage));
    assert_eq!(check_flow(&[node(vec![Effect160::Exit], vec![]), node(vec![Effect160::Exit], vec![])], 0,
        &BTreeSet::new()).err(), Some(Refusal160::MissingCoverage));
}

fn span() -> Span { Span { raw_span: Arc::new(()), id: 0, data: vec![], as_string: "160 structural WF fixture".into() } }
fn name(text: &str, id: u64) -> VarIdent { VarIdent(Arc::new(text.into()), VarIdentDisambiguate::NativeResource(id)) }
fn typ(name: &str) -> Typ {
    Arc::new(TypX::Datatype(Dt::Path(Arc::new(PathX { krate: CrateId::Vstd,
        segments: Arc::new(vec![Arc::new("raw_ptr".into()), Arc::new(name.into())]) })),
        Arc::new(vec![]), Arc::new(vec![])))
}
fn expression(typ: Typ, text: &str) -> Expr {
    SpannedTyped::new(&span(), &typ, ExprX::Var(name(text, 10)))
}
fn values() -> ActualValues160 {
    ActualValues160 {
        size: expression(Arc::new(TypX::Int(IntRange::USize)), "actual_size"),
        alignment: AlignmentAsUsize160::new(expression(Arc::new(TypX::Datatype(Dt::Path(Arc::new(PathX {
            krate: CrateId::Core, segments: Arc::new(vec![Arc::new("mem".into()), Arc::new("alignment".into()), Arc::new("Alignment".into())]),
        })), Arc::new(vec![]), Arc::new(vec![]))), "actual_typed_alignment"), name("numeric_as_usize_result", 11)).unwrap(),
        full_pointer: expression(Arc::new(TypX::Primitive(Primitive::Ptr,
            Arc::new(vec![Arc::new(TypX::Int(IntRange::U(8)))]))), "actual_result"),
    }
}
fn edge(origin: usize, id: u64) -> NativeReturn160<usize, (), ()> {
    NativeReturn160::lower(SelectedCall160 { origin, size: (), align: (), result: (), normal: 1, call_point: 0 },
        values(), ResourceBindings160::new(&span(), &ResourceTypes160 { raw: typ("PointsToRaw"),
            dealloc: typ("Dealloc"), resolved: true }, name("raw", id), name("dealloc", id+1)).unwrap(), Applicability160::pending()).unwrap()
}

#[test]
fn actual_tracked_nominal_ports_not_descriptors() {
    let edge = edge(0, 0);
    for parameter in edge.resources().parameters() { assert_eq!(parameter.x.mode, Mode::Proof); }
    assert!(resource_type("PointsToRaw", Mode::Proof, &edge.resources.raw.x.typ));
    assert!(resource_type("Dealloc", Mode::Proof, &edge.resources.dealloc.x.typ));
    assert_eq!(edge.applicability.open().len(), 10);
    assert!(matches!(edge.admit_to_sst(), Err(Refusal160::PendingReview)));
    assert_eq!(refuse_export160(), Err(Refusal160::PendingReview));
}

#[test]
fn no_source_argument_is_resource_authority() {
    assert!(!resource_type("PointsToRaw", Mode::Proof, &int_typ()));
    assert!(!resource_type("PointsToRaw", Mode::Exec, &typ("PointsToRaw")));
    assert!(matches!(ResourceTypes160::from_datatypes(&[]), Err(Refusal160::MissingVstdTypes)));
}

#[test]
fn numeric_address_cannot_replace_full_pointer() {
    let mut actual = values(); actual.full_pointer = expression(int_typ(), "address");
    assert_eq!(actual.validate(), Err(Refusal160::WrongValueType));
}

#[test]
fn false_boolean_cannot_be_actual_size() {
    let mut actual = values(); actual.size = expression(bool_typ(), "false");
    assert_eq!(actual.validate(), Err(Refusal160::WrongValueType));
}

#[test]
fn duplicate_origin_or_binding_and_missing_occurrence_refuse() {
    assert!(matches!(NativeProgram160::connect(vec![edge(0, 0), edge(0, 2)], &HashSet::from([0])), Err(Refusal160::DuplicateOccurrence)));
    assert!(matches!(NativeProgram160::connect(vec![edge(0, 0), edge(1, 0)], &HashSet::from([0, 1])), Err(Refusal160::DuplicateOccurrence)));
    assert!(matches!(NativeProgram160::connect(vec![edge(0, 0)], &HashSet::from([0, 1])), Err(Refusal160::MissingCoverage)));
    assert!(NativeProgram160::connect(vec![edge(0, 0), edge(1, 2)], &HashSet::from([0, 1])).is_ok());
}

#[test]
fn zero_size_numeric_alignment_and_numeric_null_refused_by_typed_lowering() {
    let mut actual = values();
    actual.size = SpannedTyped::new(&span(), &Arc::new(TypX::Int(IntRange::USize)), ExprX::Const(Constant::Int(0.into())));
    assert_eq!(actual.validate(), Err(Refusal160::UnsupportedOutcome));
    assert!(matches!(AlignmentAsUsize160::new(expression(Arc::new(TypX::Int(IntRange::USize)), "arbitrary_8_or_zero"), name("numeric", 10)), Err(Refusal160::WrongValueType)));
    let mut actual = values();
    actual.full_pointer = expression(Arc::new(TypX::Int(IntRange::USize)), "null_address");
    assert_eq!(actual.validate(), Err(Refusal160::WrongValueType));
}

#[test]
fn pending_assertions_are_assertions_not_assumptions_or_discharges() {
    let edge = edge(0, 0);
    assert_eq!(edge.applicability().assertions().len(), 1);
    let StmtX::Expr(assertion) = &edge.applicability().assertions()[0].x else { panic!() };
    assert!(matches!(&assertion.x, ExprX::AssertAssume { is_assume: false, .. }));
    assert_eq!(edge.applicability().open().len(), 10);
}

#[test]
fn moving_aggregate_does_not_restore_loan_to_old_root() {
    let mut state = Flow160::default();
    state.holders.insert(field(1, 0), Holder160::Resource { event: 0, port: Port160::Raw });
    state.holders.insert(field(1, 1), Holder160::Loan { root: field(1, 0) });
    state.move_place(&place(1), &place(2)).unwrap();
    assert!(matches!(state.holders[&field(2, 1)], Holder160::Stale));
}

#[test]
fn unresolved_original_vstd_ports_cannot_enter_sst() {
    let call = SelectedCall160 { origin: 0usize, size: (), align: (), result: (), normal: 1, call_point: 0 };
    let resources = ResourceBindings160::new(&span(), &ResourceTypes160::unresolved_native_ports(), name("raw", 0), name("dealloc", 1)).unwrap();
    let edge = NativeReturn160::lower(call, values(), resources, Applicability160::pending()).unwrap();
    assert!(matches!(edge.admit_to_sst(), Err(Refusal160::MissingVstdTypes)));
}
