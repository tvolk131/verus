pub mod controls {
    pub fn broken() {
        let value: u32 = "not a number";
        let _ = value;
    }
}
