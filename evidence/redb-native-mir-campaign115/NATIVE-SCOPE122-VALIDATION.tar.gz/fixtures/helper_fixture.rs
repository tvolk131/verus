pub mod controls {
    pub fn empty() {}

    pub fn arithmetic(value: u32) -> u32 {
        let sum = value + 1;
        sum
    }
}
