import difflib
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
SOURCE120 = Path('/private/tmp/redb-thir-scope-capture-20261108T173322Z')
PARENT = Path('/private/tmp/redb-thir-scope122-parent-source')
OLD = Path('/private/tmp/redb-native-mir-observer116-20261108T164457Z')
FROZEN = Path('/private/tmp/redb-compiler-validation114-worker-20261108T151020Z')
NATIVE = Path('/private/tmp/redb-original-crate-preflight115')
TC = Path('/Users/tommyvolk/.rustup/toolchains/1.99.1-aarch64-apple-darwin')
LIBC = OLD / 'target-libc-audited/debug/deps/liblibc-3b1090a6c1c370ea.rmeta'
START_NS = 1794160035000000000
DEADLINE_NS = START_NS + 28 * 60 * 10**9
FLOOR = 16 * 1024**3
LIMIT = 6 * 1024**3


def digest(path):
    hasher = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            hasher.update(block)
    return hasher.hexdigest()


def record(path):
    path = Path(path)
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': digest(path)}


def save(path, value):
    path = ROOT / path
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write('\n')


def resources():
    usage = shutil.disk_usage(ROOT)
    logical = 0
    allocated = 0
    for folder, directories, files in os.walk(ROOT):
        for name in files:
            info = (Path(folder) / name).lstat()
            logical += info.st_size
            allocated += info.st_blocks * 512
    return {'epoch_ns': time.time_ns(), 'free_bytes': usage.free,
            'scratch_logical_bytes': logical, 'scratch_allocated_bytes': allocated}


def guard():
    observation = resources()
    assert observation['free_bytes'] > FLOOR, observation
    assert max(observation['scratch_logical_bytes'], observation['scratch_allocated_bytes']) <= LIMIT, observation
    assert time.time_ns() < DEADLINE_NS, 'sealing reserve reached'
    return observation


def authenticate():
    guard()
    expected = {
        SOURCE120 / 'SOURCE-IDENTITY.json': '8c57dd21d736bd999bf82461e521457737f51114a00c07d6e06bb57bb1aaf44e',
        PARENT / 'MANIFEST.json': '18e3567fb7660e704500b75f0b6a493a49ea38c63a31c9605947a571967ff3b7',
        FROZEN / 'SEALED-MANIFEST.json': 'c73d2fba54d4144d3705d78a6d5d6cf9d29bf5eaeeb80dce6d9736fd001d6dd9',
        Path('/private/tmp/redb-observer116-review-20261108T1730Z/MANIFEST.json'): '6579eda1d8ba02be33bee1954aca7f19fb313dd78085ff27b1126717a31d9197',
        LIBC: '964becb973a8749cc06fa4c95e0916fd6755b5ee282547950f4fa3d2c936327c',
    }
    checks = []
    def check(path, pin=None, size=None, basis='current observation'):
        path = Path(path)
        observed = record(path)
        observed.update(expected_sha256=pin, expected_bytes=size, basis=basis)
        observed['matches'] = (pin is None or observed['sha256'] == pin) and (size is None or observed['bytes'] == size)
        checks.append(observed)
        assert observed['matches'], observed
    for path, pin in expected.items():
        check(path, pin, basis='task122 explicit pin')
    identity = json.loads((SOURCE120 / 'SOURCE-IDENTITY.json').read_text())
    for entry in identity['candidate_files']:
        check(SOURCE120 / entry['path'], entry['sha256'], entry['bytes'], 'task120 candidate identity')
    for entry in identity['selected_inputs']:
        check(entry['path'], entry['pinned_sha256'], entry['bytes'], 'task120 selected input')
    for entry in json.loads((PARENT / 'MANIFEST.json').read_text())['records']:
        check(PARENT / entry['path'], entry['sha256'], entry['bytes'], 'parent correction manifest')
    frozen_manifest = json.loads((FROZEN / 'SEALED-MANIFEST.json').read_text())
    prefixes = ('snapshot/source/rustc_mir_build/', 'snapshot/source/rustc_mir_build_additional_files/', 'snapshot/source/rustc_hir_typeck/')
    needed = [entry for entry in frozen_manifest['records'] if entry['path'].startswith(prefixes)]
    for entry in needed:
        check(FROZEN / entry['path'], entry['sha256'], entry['bytes'], 'pinned frozen manifest needed sources')
    content = json.loads((NATIVE / 'CONTENT-MANIFEST.json').read_text())
    native = [entry for entry in content['records'] if entry['path'].startswith('redb/')]
    assert len(native) == 132
    for entry in native:
        check(NATIVE / entry['path'], entry['sha256'], entry['bytes'], 'original132 content manifest')
    for entry in json.loads((OLD / 'LIBC-ENTRY.json').read_text())['records']:
        check(entry['path'], entry['sha256'], entry['bytes'], 'existing libc dependency source record')
    old_manifest = json.loads((OLD / 'INPUT-MANIFEST.json').read_text())
    for entry in old_manifest['records']:
        if entry['path'] in ('Cargo.toml', 'Cargo.lock'):
            check(OLD / entry['path'], entry['sha256'], entry['bytes'], 'observer dependency lock baseline')
    lock = (OLD / 'Cargo.lock').read_text()
    dependencies = {(re.search(r'^name = "([^"]+)"', entry, re.M)[1], re.search(r'^version = "([^"]+)"', entry, re.M)[1])
                    for entry in lock.split('[[package]]') if '\nsource = ' in entry}
    old_auth = json.loads((OLD / 'entry-authentication.json').read_text())
    for entry in old_auth['records']:
        path = Path(entry['path'])
        if '/.cargo/registry/src/' in str(path) and any(f'/{name}-{version}/' in str(path) for name, version in dependencies):
            check(path, entry['sha256'], entry['bytes'], 'installed locked dependency source baseline')
    for entry in json.loads((NATIVE / 'tools.json').read_text())['records']:
        check(entry['path'], entry['sha256'], basis='preflight tool identity')
    tool_paths = [TC / 'bin' / name for name in ['cargo', 'rustc', 'rustdoc', 'rustfmt']]
    tool_paths += [path for path in (TC / 'lib').rglob('*') if path.is_file()]
    for path in sorted(set(tool_paths)):
        check(path, basis='task122 current installed tool/sysroot content observation')
    for name in ['CONTENT-MANIFEST.json', 'entry.json', 'DEPENDENCY-IDENTITIES.json', 'tools.json']:
        check(NATIVE / name, basis='actual currently used native provenance manifest')
    for name in ['BUILD-BINDING.json', 'LIBC-ENTRY.json', 'INPUT-MANIFEST.json', 'entry-authentication.json', 'plans/observer-build-3-full-raw-calls.json', 'plans/original-header-complete.json', 'ENVIRONMENT-CORRECTION.md', 'REPAIR.md']:
        check(OLD / name, basis='actual currently read task116 reference, not historical custody retrofit')
    save('ENTRY-AUTHENTICATION.json', {'epoch_ns': time.time_ns(), 'records': checks,
         'native_original_files': len(native), 'needed_frozen_sources': len(needed),
         'resource_observation': guard(), 'original_recovery_commit': 'c82ab865bb362bc4af067d332adc44978ff64813',
         'git_continuity': 'not re-established; content binding only'})
    return needed


def stage():
    needed = authenticate()
    guard()
    for entry in needed:
        source = FROZEN / entry['path']
        relative = Path(entry['path']).relative_to('snapshot')
        destination = ROOT / 'stage' / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, destination)
    observer = ROOT / 'stage/observer'
    (observer / 'src').mkdir(parents=True)
    shutil.copyfile(SOURCE120 / 'candidate/source/rustc_mir_build/src/builder/checked_drop_origins.rs', ROOT / 'stage/source/rustc_mir_build/src/builder/checked_drop_origins.rs')
    shutil.copyfile(PARENT / 'main.rs', observer / 'src/main.rs')
    shutil.copyfile(OLD / 'Cargo.lock', observer / 'Cargo.lock')
    for name in ['candidate.patch', 'REPORT.md', 'SOURCE-IDENTITY.json']:
        destination = ROOT / 'inputs/task120' / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(SOURCE120 / name, destination)
    for name in ['MANIFEST.json', 'main.rs', 'classification-only.patch', 'README.md']:
        destination = ROOT / 'inputs/parent' / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(PARENT / name, destination)
    for name in ['SEALED-MANIFEST.json']:
        destination = ROOT / 'inputs/frozen' / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(FROZEN / name, destination)
    for name in ['reports', 'records', 'plans', 'tmp', 'cases']:
        (ROOT / name).mkdir()
    save('COMPILER-SLOT-ACQUIRED.json', {'epoch_ns': time.time_ns(), 'lane': 'distinct validation122', 'jobs': 1,
         'build_launch_limit': 2, 'application_limit': 10, 'build_timeout_seconds': 600,
         'application_timeout_seconds': 90, 'start_epoch_ns': START_NS, 'command_deadline_epoch_ns': DEADLINE_NS,
         'seal_deadline_epoch_ns': START_NS + 30*60*10**9, 'no_subdelegation': True,
         'task116_terminal_interrupted_utc': '2026-11-08T17:02:52.937Z', 'task116_not_retried_or_completed': True})


def observation(path):
    path = Path(path)
    value = {'path': str(path), 'observed_epoch_ns': time.time_ns(), 'exists': path.exists()}
    if path.is_file():
        value.update(record(path))
        value['mtime_ns'] = path.stat().st_mtime_ns
    return value


def stop_group(process):
    try:
        os.killpg(process.pid, signal.SIGTERM)
    except ProcessLookupError:
        pass
    try:
        process.wait(timeout=3)
    except subprocess.TimeoutExpired:
        os.killpg(process.pid, signal.SIGKILL)
        process.wait(timeout=3)
    try:
        os.killpg(process.pid, signal.SIGKILL)
    except ProcessLookupError:
        pass


def run(plan_path):
    plan = json.loads(Path(plan_path).read_text())
    receipts = list((ROOT / 'records').glob('*/receipt.json'))
    previous = [json.loads(path.read_text()) for path in receipts]
    assert sum(entry['kind'] == plan['kind'] for entry in previous) < (2 if plan['kind'] == 'build' else 10)
    assert plan['timeout_seconds'] <= (600 if plan['kind'] == 'build' else 90)
    directory = ROOT / 'records' / plan['name']
    directory.mkdir()
    before = guard()
    inputs = [record(path) for path in plan['inputs']]
    outputs_before = [observation(path) for path in plan['outputs']]
    assert all(not entry['exists'] for entry in outputs_before), outputs_before
    launch = {'plan': plan, 'plan_identity': record(plan_path), 'inputs': inputs,
              'outputs_before': outputs_before, 'resource_before': before, 'registration_epoch_ns': time.time_ns()}
    save(directory / 'launch.json', launch)
    samples = []
    process = None
    reason = None
    begin_ns = time.time_ns()
    begin_clock = time.monotonic()
    with (directory / 'stdout').open('xb') as stdout, (directory / 'stderr').open('xb') as stderr, (directory / 'resources.jsonl').open('x') as resource_log:
        try:
            process = subprocess.Popen(plan['argv'], cwd=plan['cwd'], env=plan['environment'],
                                       stdout=stdout, stderr=stderr, start_new_session=True)
            while True:
                sample = resources()
                resource_log.write(json.dumps(sample) + '\n')
                resource_log.flush()
                samples.append(sample)
                if sample['free_bytes'] <= FLOOR:
                    reason = 'free_disk_floor'
                elif max(sample['scratch_logical_bytes'], sample['scratch_allocated_bytes']) > LIMIT:
                    reason = 'scratch_limit'
                elif time.time_ns() >= DEADLINE_NS:
                    reason = 'seal_reserve'
                elif time.monotonic() - begin_clock >= plan['timeout_seconds']:
                    reason = 'per_command_timeout'
                if reason:
                    stop_group(process)
                    break
                if process.poll() is not None:
                    break
                time.sleep(0.2)
        except BaseException as error:
            reason = repr(error)
            if process is not None:
                stop_group(process)
        finally:
            if process is not None and process.poll() is None:
                stop_group(process)
    end_ns = time.time_ns()
    after = resources()
    receipt = {'name': plan['name'], 'kind': plan['kind'], 'begin_epoch_ns': begin_ns, 'end_epoch_ns': end_ns,
               'duration_seconds': time.monotonic() - begin_clock, 'pid_pgid': process.pid if process else None,
               'returncode': process.returncode if process else None, 'stop_reason': reason,
               'resource_after': after, 'minimum_sampled_free_bytes': min(entry['free_bytes'] for entry in samples),
               'maximum_sampled_scratch_bytes': max(max(entry['scratch_logical_bytes'], entry['scratch_allocated_bytes']) for entry in samples),
               'outputs_after': [observation(path) for path in plan['outputs']],
               'stdout': record(directory / 'stdout'), 'stderr': record(directory / 'stderr'),
               'input_reauthentication': [dict(record(entry['path']), unchanged=digest(entry['path']) == entry['sha256']) for entry in inputs],
               'proof_acceptance': False}
    save(directory / 'receipt.json', receipt)
    print(json.dumps({key: receipt[key] for key in ['name', 'returncode', 'duration_seconds', 'stop_reason', 'minimum_sampled_free_bytes', 'maximum_sampled_scratch_bytes']}), flush=True)


if __name__ == '__main__':
    if sys.argv[1] == 'stage':
        stage()
    elif sys.argv[1] == 'run':
        run(sys.argv[2])
