import collections
from datetime import datetime, timezone
import difflib
import json
import os
from pathlib import Path
import shutil
import time

import lane

ROOT = lane.ROOT


def copy_input(source, relative):
    lane.guard()
    destination = ROOT / 'inputs' / relative
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.exists():
        assert destination.read_bytes() == Path(source).read_bytes()
    else:
        shutil.copyfile(source, destination)


def main():
    before = lane.guard()
    receipts = [json.loads(path.read_text()) for path in sorted((ROOT / 'records').glob('*/receipt.json'))]
    assert len(receipts) == 7
    assert sum(receipt['kind'] == 'build' for receipt in receipts) == 1
    assert all(receipt['stop_reason'] is None for receipt in receipts)
    assert all(all(entry['unchanged'] for entry in receipt['input_reauthentication']) for receipt in receipts)
    live_groups = []
    for receipt in receipts:
        try:
            os.killpg(receipt['pid_pgid'], 0)
        except ProcessLookupError:
            continue
        live_groups.append(receipt['pid_pgid'])
    assert not live_groups, live_groups
    lane.save('COMPILER-SLOT-RELEASED.json', {
        'epoch_ns': time.time_ns(), 'utc': datetime.now(timezone.utc).isoformat(),
        'slot': 'sole compiler-heavy diagnostic validation122 lane', 'jobs': 1,
        'owned_process_groups_remaining': live_groups, 'further_builds_or_applications_authorized_by_this_lane': False,
        'build_launches': 1, 'application_launches': 6, 'helper_internal_compiler_sessions': 3,
        'conservative_applications_counting_each_internal_compiler_session': 8,
        'release': 'EXPLICITLY_RELEASED',
    })
    entry = json.loads((ROOT / 'ENTRY-AUTHENTICATION.json').read_text())
    for identity in entry['records']:
        if identity['basis'] == 'pinned frozen manifest needed sources':
            source = Path(identity['path'])
            copy_input(source, Path('frozen-baseline') / source.relative_to(lane.FROZEN / 'snapshot'))
    candidate = json.loads((lane.SOURCE120 / 'SOURCE-IDENTITY.json').read_text())
    for identity in candidate['candidate_files']:
        copy_input(lane.SOURCE120 / identity['path'], Path('task120') / identity['path'])
    for name in ['BUILD-BINDING.json', 'LIBC-ENTRY.json', 'INPUT-MANIFEST.json', 'entry-authentication.json',
                 'Cargo.lock', 'Cargo.toml', 'src/main.rs', 'plans/observer-build-3-full-raw-calls.json',
                 'plans/original-header-complete.json', 'ENVIRONMENT-CORRECTION.md', 'REPAIR.md']:
        copy_input(lane.OLD / name, Path('reference116') / name)
    for name in ['CONTENT-MANIFEST.json', 'DEPENDENCY-IDENTITIES.json', 'entry.json', 'tools.json']:
        copy_input(lane.NATIVE / name, Path('native-provenance') / name)
    original_identity = json.loads((ROOT / 'BUILD1-SOURCE-IDENTITY.json').read_text())
    source_after = []
    for identity in original_identity['records']:
        actual = lane.record(identity['path'])
        actual['unchanged_since_build_registration'] = actual['sha256'] == identity['sha256']
        assert actual['unchanged_since_build_registration'], actual
        source_after.append(actual)
    lane.save('USED-SOURCE-EXIT-IDENTITY.json', {'epoch_ns': time.time_ns(), 'records': source_after})
    patches = []
    patch_records = []
    replacements = [
        (lane.FROZEN / 'snapshot/source/rustc_mir_build/src/builder/checked_drop_origins.rs', ROOT / 'stage/source/rustc_mir_build/src/builder/checked_drop_origins.rs'),
        (lane.OLD / 'src/main.rs', ROOT / 'stage/observer/src/main.rs'),
        (lane.OLD / 'Cargo.toml', ROOT / 'stage/observer/Cargo.toml'),
        (None, ROOT / 'stage/observer/src/bin/helper-controls.rs'),
        (None, ROOT / 'fixtures/helper_fixture.rs'),
        (None, ROOT / 'fixtures/compiler_failure.rs'),
    ]
    for baseline, source in replacements:
        relative = source.relative_to(ROOT)
        patches.extend(difflib.unified_diff(
            baseline.read_text().splitlines(True) if baseline else [], source.read_text().splitlines(True),
            fromfile=str(baseline) if baseline else '/dev/null', tofile=str(relative)))
        patch_records.append({'baseline': lane.record(baseline) if baseline else None, 'used_source': lane.record(source)})
    (ROOT / 'source.patch').write_text(''.join(patches))
    lane.save('PATCH-INDEX.json', {'records': patch_records, 'task120_candidate_patch': lane.record(ROOT / 'inputs/task120/candidate.patch'),
              'parent_classification_patch': lane.record(ROOT / 'inputs/parent/classification-only.patch'),
              'lock_unchanged': lane.digest(ROOT / 'stage/observer/Cargo.lock') == lane.digest(lane.OLD / 'Cargo.lock'),
              'no_compile_repairs': True, 'observer_equals_parent': lane.digest(ROOT / 'stage/observer/src/main.rs') == lane.digest(lane.PARENT / 'main.rs'),
              'helper_equals_task120_candidate': lane.digest(ROOT / 'stage/source/rustc_mir_build/src/builder/checked_drop_origins.rs') == '1aa55b6d95997e1950cc548119ae6b9b83ff3c69af98c36f0790cff895c0ca79'})
    report = json.loads((ROOT / 'reports/original-header.json').read_text())
    capture = report['captures'][0]
    scopes = capture['thir_scope_capture']
    edges = scopes['all_raw_scope_edges']
    temporaries = capture['all_typed_builder_temporary_observations']
    matching_counts = dict(collections.Counter(temporary['exact_thir_scope_edges_with_value_equal_to_expression']['matching_status'] for temporary in temporaries))
    e78 = [temporary for temporary in temporaries if temporary['expression'] == 'e78']
    exact_edges = [edge for edge in edges if edge['value_expression'] == 'e78']
    local_by_id = {local['local']: local for local in capture['locals']}
    spans = collections.defaultdict(list)
    for temporary in temporaries:
        spans[local_by_id[temporary['local']]['span']].append(temporary)
    same_mir_spans = [
        {'observed_mir_local_declaration_span': span,
         'observations': [{'expression': temporary['expression'], 'local': temporary['local'],
                           'reported_exact_edges': temporary['exact_thir_scope_edges_with_value_equal_to_expression']['edges']}
                          for temporary in observations], 'thir_span_equality': 'UNVALIDATED',
         'scope_join_used_span': False}
        for span, observations in spans.items() if len({temporary['expression'] for temporary in observations}) > 1
    ]
    helper = json.loads((ROOT / 'reports/helper-controls.json').read_text())
    helper_summary = []
    for run in helper['runs']:
        helper_summary.append({
            'begin_native_argument': run['mode'],
            'compiler_completed_without_panic': run['compiler_completed_without_panic'],
            'old_body_keys_immediately_after_begin_before_new_compiler': run['old_body_keys_immediately_after_begin_before_new_compiler'],
            'bodies': [{
                'def_path': observation['def_path'], 'def_path_hash': observation['def_path_hash'],
                'body': observation['after_explicit_query']['body'],
                'before_status': observation['before_explicit_query']['status'],
                'after_status': observation['after_explicit_query']['status'],
                'session_generation': observation['after_explicit_query']['session_generation'],
                'session_native': observation['after_explicit_query']['session_native'],
                'edge_count': observation['after_explicit_query']['edge_count'],
                'expression_count': observation['after_explicit_query']['expression_count'],
                'separate_api_clone_debug_equal': observation['after_explicit_query']['separate_api_clone_debug_equal'],
            } for observation in run['observations']],
        })
    controls = []
    for name in ['original-header', 'wrong-qualified', 'compiler-failure', 'extra-flag-refusal', 'link-flag-refusal', 'helper-controls']:
        receipt = next(receipt for receipt in receipts if receipt['name'] == name)
        output = ROOT / 'reports' / f'{name}.json'
        value = json.loads(output.read_text()) if output.exists() else None
        controls.append({'name': name, 'exit_status': receipt['returncode'],
                         'classification': value.get('classification', value.get('scope')) if value else 'CLI_REFUSED_BEFORE_REPORT_RESERVATION',
                         'raw_receipt': str(ROOT / 'records' / name / 'receipt.json'),
                         'report_present': output.exists(),
                         'compiler_completed_without_panic': value.get('compiler_completed_without_panic') if value else None,
                         'after_analysis_reached': value.get('after_analysis_reached') if value else None,
                         'explicit_selected_query_requests': value.get('explicit_selected_query_requests') if value else None})
    duplicate_values = {value: count for value, count in collections.Counter(edge['value_expression'] for edge in edges).items() if count > 1}
    summary = {
        'task': 'distinct bounded offline scratch validation122 of completed source-only task120',
        'not_a_reset_retry_or_completion_of_interrupted116': True,
        'all18': 'OPEN', 'native_credit': 0, 'resource_credit': 0, 'trust_credit': 0,
        'native_resource_correspondence': False, 'proof_acceptance': False, 'mapping_approval': False,
        'build_launches': 1, 'application_launches': 6,
        'conservative_application_count_including_three_helper_sessions': 8,
        'compile_repairs': 0, 'preparation_or_inspection_failures_preserved': 2,
        'baseline': {'task120_identity': lane.record(lane.SOURCE120 / 'SOURCE-IDENTITY.json'),
                     'parent_observer': lane.record(lane.PARENT / 'main.rs'),
                     'modified_stage_helper': lane.record(ROOT / 'stage/source/rustc_mir_build/src/builder/checked_drop_origins.rs'),
                     'frozen_manifest': lane.record(lane.FROZEN / 'SEALED-MANIFEST.json')},
        'native_header': {
            'qualified_target': report['target_definition'], 'exit_status': 2,
            'classification': report['classification'], 'definition_key': capture['def_path_hash'],
            'scope_session_body_key': {key: value for key, value in scopes.items() if key != 'all_raw_scope_edges'},
            'locals': len(capture['locals']), 'typed_temporary_observations': len(temporaries),
            'drops': capture['drops'], 'call_terminators': len(capture['calls']),
            'scope_edges': len(edges), 'arena_expressions': scopes['expression_count'],
            'exact_scope_value_e78_edges': exact_edges, 'e78_observations': e78,
            'e78_edge_hir_ids': [edge['hir_id'] for edge in exact_edges],
            'e78_edge_region_ids': [edge['region_scope'] for edge in exact_edges],
            'e78_no_hir_or_region_inferred_from_spans_or_neighbors': True,
            'e78_temp_lifetime_Node72_is_not_a_scope_edge_or_mapping': True,
            'all_actual_scope_hir_region_records': edges,
            'matching_status_counts': matching_counts, 'duplicate_scope_value_counts': duplicate_values,
            'full_body_temporaries_and_all_scope_edges_retained_in': str(ROOT / 'reports/original-header.json'),
            'non_scope_thir_node_debug_dump': 'NOT_CAPTURED_BY_CANDIDATE_API',
            'elaboration_provider_invocations_total': report['elaboration_provider_invocations_total'],
            'whole_crate_hir_body_owners_enumerated': report['whole_crate_hir_body_owners_enumerated'],
        },
        'controls': controls,
        'actual_rust_helper_api_fixture': {'initial_session_none': helper['initial_session_none'],
                                          'process_id': helper['process_id'], 'runs': helper_summary,
                                          'native_mir_correspondence': False,
                                          'not_a_python_shadow_table': True},
        'same_mir_local_declaration_span_groups': same_mir_spans,
        'unvalidated': {
            'genuine_after_temporary_hook_before_retain_incomplete': 'UNVALIDATED; compiler failure occurred before after_analysis and supplies no genuine incomplete capture',
            'full_thir_scope_arena_complete_empty': 'UNVALIDATED; actual empty fixture fn has 2 expressions and 1 Scope edge',
            'multiple_scope_edges_with_one_exact_value': 'UNVALIDATED; original arena has no duplicated value_expression',
            'equal_thir_expression_spans_for_distinct_origins': 'UNVALIDATED; only MIR local-declaration span equality observed',
            'actual_key_mismatch': 'UNVALIDATED; no fabricated capture/session/body mismatch',
            'sysroot_source_compiler_correspondence': 'UNESTABLISHED; current installed contents authenticated, not bootstrap proof',
            'system_linker_sdk_transitive_provenance': 'NOT_ESTABLISHED; not retrofitted after build',
        },
        'construction_caveat': 'Builder uses default sysroot THIR provider here; custom expr.rs and scope_post are not established executed native lowering. Scanned arena may include abandoned/synthetic wrappers. Cardinality one never establishes unique origin/resource, reachability, ownership, or approved HIR/VIR mapping.',
        'older_oracle115': 'NOT_APPLIED_AS_STRICT_PASS; approved-mapping/expectation contract remains unfulfilled; fresh clocks repair no historical clock or mapping approval',
        'remaining_native_semantic_edge': 'e78 -> _20 WritablePage and bb16/bb19 drops remain raw observations; zero direct incoming Scope.value==e78 edges provides no recovered HIR/region and no native lifecycle/resource correspondence',
        'safety': {'network_used': False, 'git_writes': False, 'subdelegation': False,
                   'original_native_application_execution': False, 'frozen_or_parent_input_mutation': False,
                   'toolchain_cache_target_copying': False, 'infer_or_scope_gate_weakening': False,
                   'trusted_law_producer_admission_or_external_body_changes': False,
                   'no_followup_chain': True},
        'before_seal_resources': before,
    }
    lane.save('SUMMARY.json', summary)
    exit_records = []
    for index, identity in enumerate(entry['records']):
        if index % 100 == 0:
            lane.guard()
        actual = lane.record(identity['path'])
        actual.update(entry_sha256=identity['sha256'], unchanged=actual['sha256'] == identity['sha256'], basis=identity['basis'])
        exit_records.append(actual)
    assert all(identity['unchanged'] for identity in exit_records)
    lane.save('EXIT-AUTHENTICATION.json', {'epoch_ns': time.time_ns(), 'records': exit_records,
              'all_selected_immutable_inputs_unchanged': True, 'records_count': len(exit_records),
              'native_original_files': 132, 'no_historical_custody_retrofit': True})
    header_receipt = next(receipt for receipt in receipts if receipt['name'] == 'original-header')
    report_text = f'''# Distinct bounded offline scratch validation122

Completed validation of the completed source-only task120 candidate with the parent's
classification-only observer correction. This is NOT a reset, retry, continuation,
or completion of terminal interrupted116 (2026-11-08T17:02:52.937Z).

## Disposition

All18 remain OPEN. Native/resource/trust credit: 0/0/0. Capture only: no Verus
admission, mapping approval, resource proof, or output adoption. Compiler slot is
explicitly RELEASED; no owned process groups remain and no followup chain starts.

## Build and binding

Authenticated {len(entry['records'])} selected source, candidate, dependency, native,
libc, manifest and installed tool/sysroot records before provisioning sources.
All 5 task120 candidate payloads and all 8 selected task120 inputs matched.
Authenticated original132 content records, 49 needed frozen sources, 965 installed
locked dependency-source records, and 453 existing libc-source records.
Current installed tool/sysroot content is a local observation, not compiler-source
or bootstrap correspondence. Original Git continuity is not re-established.

One fresh-target offline --locked -j1 build succeeded in 12.816 seconds. No compile
repairs were needed. Candidate helper and parent observer are byte-identical to
their pinned inputs; observer Cargo.toml points to ../source/rustc_mir_build.
Cargo.lock is unchanged. The only build warning is AtomicU64::fetch_update's
deprecation; it is retained, not repaired. No targets/toolchains/caches were copied.
New executable SHA256: bed31a848bf6e89dad299e87c2a9f1f6a86821fc75d24c6d61479613ee418746.
See BUILD-BINDING.json, BUILD1-SOURCE-IDENTITY.json, source.patch and sources/build1/.

## Actual unchanged original header

Target: tree_store::page_store::page_manager::TransactionalMemory::write_header.
Exit 2, RAW_MIR_CAPTURE_NOT_NATIVE_PROOF; proof refused. Real begin epoch ns:
{header_receipt['begin_epoch_ns']}; end epoch ns: {header_receipt['end_epoch_ns']}.
Fresh output absence/presence observations, exact argv/env/cwd, stdout/stderr and
input hashes are in records/original-header/. Compiler argv is also in raw JSON.

Process {scopes['observer_process_id']}, generation 1, native flag true;
body {scopes['capture_body']}; observed phase Runtime(PostCleanup).
DefPathHash: {capture['def_path_hash']}.
Complete capture: 109 arena expressions, all 37 Scope edges, 30 typed temporary
observations, 39 MIR locals, 2 drops and 11 call terminators. Full MIR body,
temporary debug table and every Scope edge/HirId/region are retained in
reports/original-header.json; the API does not dump all non-Scope THIR node kinds.

The actual original e78 -> _20 WritablePage temporary remains scope: None, with
TempLifetime Some(Node(72)). Drops are normal bb16 -> bb17 (unwind Cleanup(bb20))
and cleanup bb19 -> bb20 (unwind Terminate(InCleanup)). Exact Scope.value == e78
edge count is ZERO, with COMPLETE_EMPTY matching status under a COMPLETE_NONEMPTY
arena. There are no e78-edge HirIds or region IDs to report. Node(72) is only the
stored temporary lifetime, not a reconstructed Scope edge. No span, first-match,
neighbor, wrapper-peeling, ownership, or reachability inference was used.

Across all 30 temporary queries: 18 complete-nonempty and 12 complete-empty.
All 37 arena value_expression keys are distinct; no ambiguous-multi-edge control
was established. The observer saw 126 elaboration provider invocations, enumerated
2428 body owners, and made 1 explicit selected query. Discovery is not query history.

## Targeted controls

- Wrong qualified target: exit 65, TARGET_NOT_UNIQUELY_OBSERVED; compiler completed,
  after_analysis reached, no explicit selected query and no capture.
- Genuine Rust type error fixture: exit 70,
  COMPILER_DID_NOT_COMPLETE_RAW_EVIDENCE_ONLY; after_analysis not reached.
  This is compiler failure, NOT a demonstrated incomplete helper capture.
- Extra --cfg and --emit=link arguments: two distinct exit-64 CLI refusals,
  report outputs remain absent. No unrestricted compiler-flag forwarding added.
- Actual Rust helper driver: one isolated diagnostic application, three sequential
  compiler sessions, all completed. Fresh disabled process has no session; both
  real fixture bodies remain MISSING before/after forced MIR queries.
- begin(false) establishes generation 1/native false; begin(true) generation 2/native
  true. Prior actual body keys are missing immediately after each begin before the
  next compiler. Body IDs recur numerically, with no prior capture leakage observed.
- Enabled empty fixture body has 2 expressions and 1 Scope edge; arithmetic has
  10 expressions and 5 Scope edges. Both captures are complete in each enabled
  session, and independent API clones have equal debug data. These are helper/table
  observations from isolated fixture compilation, NOT native-MIR correspondence.

UNVALIDATED: genuine hook-before-retain incomplete; full-arena complete-empty;
multiple edges sharing one value; actual KEY_MISMATCH; equal THIR expression spans.
Eight groups of distinct temporary expressions share observed MIR local-declaration
spans, but those are NOT established equal THIR spans. Their exact edge reports are
retained without using span equality as a join (SUMMARY.json).

## Limits, preservation and caveats

1/2 permitted build launches; 6/10 executable diagnostic applications (8/10 when
counting each of the helper's three internal compiler sessions separately).
All builds <600 seconds and applications <90 seconds; jobs1 throughout. Sampled
free space stays strictly >16 GiB; scratch stays far below 6 GiB. ACCOUNTING.json
binds actual extrema and sealing time. No resource limit or cancellation occurred.
The monitor samples before and every 0.2 seconds during execution; this is sampled,
not a claim of a filesystem quota or mathematically continuous disk observation.

Preserved preparation failure: unavailable Python tomllib, original collector v0,
and repaired collector. Preserved read-only inspection failure: KeyError('type').
These are not compiler failures; their unrecorded historical command clocks are
not invented. Every actual build/application has a preregistered plan and raw
receipt. No failed source/report was overwritten; no destructive cleanup occurred.

Builder uses the default sysroot THIR provider here. Custom expr.rs and scope_post
are NOT established executed native lowering. Scanned arenas may include abandoned
and synthetic wrappers; cardinality 1 never means unique origin/resource,
reachability, ownership or approved HIR/VIR mapping. System linker/SDK transitive
provenance is not established and is not retrofitted after the build.

Older synthetic oracle115 is NOT applied as a strict pass: its approved-mapping /
expectation contract remains unfulfilled. Fresh clocks repair no historical clocks
and grant no mapping approval. The remaining native semantic edge is still the
unproved relationship between the e78/_20 observation, lifecycle/drop semantics,
and approved native/HIR/VIR resource correspondence. Direct e78 Scope-edge recovery
was not observed. All selected immutable inputs reauthenticate unchanged at exit.
'''
    (ROOT / 'REPORT.md').write_text(report_text)
    samples = [json.loads(line) for path in (ROOT / 'records').glob('*/resources.jsonl') for line in path.read_text().splitlines()]
    final_resources = lane.guard()
    all_observations = samples + [before, final_resources]
    lane.save('ACCOUNTING.json', {
        'start_epoch_ns': lane.START_NS, 'seal_observation_epoch_ns': time.time_ns(),
        'elapsed_seconds_at_seal_observation': (time.time_ns() - lane.START_NS) / 10**9,
        'total_time_limit_seconds': 1800, 'command_deadline_epoch_ns': lane.DEADLINE_NS,
        'build_launches': 1, 'build_launch_limit': 2, 'application_launches': 6,
        'conservative_application_count': 8, 'application_limit': 10,
        'maximum_build_seconds': max(receipt['duration_seconds'] for receipt in receipts if receipt['kind'] == 'build'),
        'maximum_application_seconds': max(receipt['duration_seconds'] for receipt in receipts if receipt['kind'] != 'build'),
        'minimum_observed_free_bytes': min(observation['free_bytes'] for observation in all_observations),
        'maximum_observed_new_scratch_bytes': max(max(observation['scratch_logical_bytes'], observation['scratch_allocated_bytes']) for observation in all_observations),
        'free_disk_strict_floor_bytes': lane.FLOOR, 'scratch_limit_bytes': lane.LIMIT,
        'monitor_interval_seconds': 0.2, 'final_resources_before_manifest': final_resources,
        'all_process_groups_reaped': True,
    })
    manifest_records = []
    for path in sorted(ROOT.rglob('*')):
        if path.is_file() and path.name not in ('SEALED-MANIFEST.json',):
            manifest_records.append(dict(lane.record(path), relative_path=str(path.relative_to(ROOT))))
    lane.save('SEALED-MANIFEST.json', {'epoch_ns': time.time_ns(), 'records': manifest_records,
              'manifest_excludes_itself_only': True, 'all18': 'OPEN', 'native_credit': 0,
              'resource_credit': 0, 'trust_credit': 0, 'proof_acceptance': False,
              'compiler_slot': 'EXPLICITLY_RELEASED', 'new_validation122_not_interrupted116_completion': True})
    print(json.dumps({'sealed_manifest': lane.record(ROOT / 'SEALED-MANIFEST.json'),
                      'resources_after_manifest': lane.resources(),
                      'total_elapsed_seconds': (time.time_ns() - lane.START_NS) / 10**9,
                      'exit_authentication_records': len(exit_records), 'compiler_slot': 'EXPLICITLY_RELEASED'}, indent=2))


if __name__ == '__main__':
    main()
