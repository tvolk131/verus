# Distinct bounded offline scratch validation122

Completed validation of the completed source-only task120 candidate with the parent's
classification-only observer correction. This is NOT a reset, retry, continuation,
or completion of terminal interrupted116 (2026-11-08T17:02:52.937Z).

## Disposition

All18 remain OPEN. Native/resource/trust credit: 0/0/0. Capture only: no Verus
admission, mapping approval, resource proof, or output adoption. Compiler slot is
explicitly RELEASED; no owned process groups remain and no followup chain starts.

## Build and binding

Authenticated 4903 selected source, candidate, dependency, native,
libc, manifest and installed tool/sysroot records before provisioning sources.
All 5 task120 candidate payloads and all 8 selected task120 inputs matched.
Authenticated original132 content records, 49 needed frozen sources, 965 installed
locked dependency-source records, and 453 existing libc-source records.
Current installed tool/sysroot content is a local observation, not compiler-source
or bootstrap correspondence. Original Git continuity is not re-established.

One fresh-target offline --locked -j1 build succeeded in 12.816 seconds. No compile
repairs were needed. Candidate helper and parent observer are byte-identical to
their pinned inputs; observer Cargo.toml points to ../source/rustc_mir_build.
Cargo.lock is unchanged. The only build warning is AtomicU64::fetch_update's
deprecation; it is retained, not repaired. No targets/toolchains/caches were copied.
New executable SHA256: bed31a848bf6e89dad299e87c2a9f1f6a86821fc75d24c6d61479613ee418746.
See BUILD-BINDING.json, BUILD1-SOURCE-IDENTITY.json, source.patch and sources/build1/.

## Actual unchanged original header

Target: tree_store::page_store::page_manager::TransactionalMemory::write_header.
Exit 2, RAW_MIR_CAPTURE_NOT_NATIVE_PROOF; proof refused. Real begin epoch ns:
1794160358052040000; end epoch ns: 1794160359762765000.
Fresh output absence/presence observations, exact argv/env/cwd, stdout/stderr and
input hashes are in records/original-header/. Compiler argv is also in raw JSON.

Process 13081, generation 1, native flag true;
body DefId(0:4329 ~ redb[9162]::tree_store::page_store::page_manager::{impl#9}::write_header); observed phase Runtime(PostCleanup).
DefPathHash: DefPathHash(Fingerprint(10476043313273028918, 2904618018494555106)).
Complete capture: 109 arena expressions, all 37 Scope edges, 30 typed temporary
observations, 39 MIR locals, 2 drops and 11 call terminators. Full MIR body,
temporary debug table and every Scope edge/HirId/region are retained in
reports/original-header.json; the API does not dump all non-Scope THIR node kinds.

The actual original e78 -> _20 WritablePage temporary remains scope: None, with
TempLifetime Some(Node(72)). Drops are normal bb16 -> bb17 (unwind Cleanup(bb20))
and cleanup bb19 -> bb20 (unwind Terminate(InCleanup)). Exact Scope.value == e78
edge count is ZERO, with COMPLETE_EMPTY matching status under a COMPLETE_NONEMPTY
arena. There are no e78-edge HirIds or region IDs to report. Node(72) is only the
stored temporary lifetime, not a reconstructed Scope edge. No span, first-match,
neighbor, wrapper-peeling, ownership, or reachability inference was used.

Across all 30 temporary queries: 18 complete-nonempty and 12 complete-empty.
All 37 arena value_expression keys are distinct; no ambiguous-multi-edge control
was established. The observer saw 126 elaboration provider invocations, enumerated
2428 body owners, and made 1 explicit selected query. Discovery is not query history.

## Targeted controls

- Wrong qualified target: exit 65, TARGET_NOT_UNIQUELY_OBSERVED; compiler completed,
  after_analysis reached, no explicit selected query and no capture.
- Genuine Rust type error fixture: exit 70,
  COMPILER_DID_NOT_COMPLETE_RAW_EVIDENCE_ONLY; after_analysis not reached.
  This is compiler failure, NOT a demonstrated incomplete helper capture.
- Extra --cfg and --emit=link arguments: two distinct exit-64 CLI refusals,
  report outputs remain absent. No unrestricted compiler-flag forwarding added.
- Actual Rust helper driver: one isolated diagnostic application, three sequential
  compiler sessions, all completed. Fresh disabled process has no session; both
  real fixture bodies remain MISSING before/after forced MIR queries.
- begin(false) establishes generation 1/native false; begin(true) generation 2/native
  true. Prior actual body keys are missing immediately after each begin before the
  next compiler. Body IDs recur numerically, with no prior capture leakage observed.
- Enabled empty fixture body has 2 expressions and 1 Scope edge; arithmetic has
  10 expressions and 5 Scope edges. Both captures are complete in each enabled
  session, and independent API clones have equal debug data. These are helper/table
  observations from isolated fixture compilation, NOT native-MIR correspondence.

UNVALIDATED: genuine hook-before-retain incomplete; full-arena complete-empty;
multiple edges sharing one value; actual KEY_MISMATCH; equal THIR expression spans.
Eight groups of distinct temporary expressions share observed MIR local-declaration
spans, but those are NOT established equal THIR spans. Their exact edge reports are
retained without using span equality as a join (SUMMARY.json).

## Limits, preservation and caveats

1/2 permitted build launches; 6/10 executable diagnostic applications (8/10 when
counting each of the helper's three internal compiler sessions separately).
All builds <600 seconds and applications <90 seconds; jobs1 throughout. Sampled
free space stays strictly >16 GiB; scratch stays far below 6 GiB. ACCOUNTING.json
binds actual extrema and sealing time. No resource limit or cancellation occurred.
The monitor samples before and every 0.2 seconds during execution; this is sampled,
not a claim of a filesystem quota or mathematically continuous disk observation.

Preserved preparation failure: unavailable Python tomllib, original collector v0,
and repaired collector. Preserved read-only inspection failure: KeyError('type').
These are not compiler failures; their unrecorded historical command clocks are
not invented. Every actual build/application has a preregistered plan and raw
receipt. No failed source/report was overwritten; no destructive cleanup occurred.

Builder uses the default sysroot THIR provider here. Custom expr.rs and scope_post
are NOT established executed native lowering. Scanned arenas may include abandoned
and synthetic wrappers; cardinality 1 never means unique origin/resource,
reachability, ownership or approved HIR/VIR mapping. System linker/SDK transitive
provenance is not established and is not retrofitted after the build.

Older synthetic oracle115 is NOT applied as a strict pass: its approved-mapping /
expectation contract remains unfulfilled. Fresh clocks repair no historical clocks
and grant no mapping approval. The remaining native semantic edge is still the
unproved relationship between the e78/_20 observation, lifecycle/drop semantics,
and approved native/HIR/VIR resource correspondence. Direct e78 Scope-edge recovery
was not observed. All selected immutable inputs reauthenticate unchanged at exit.
