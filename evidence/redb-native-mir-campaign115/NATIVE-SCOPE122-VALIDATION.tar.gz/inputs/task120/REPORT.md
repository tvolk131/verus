# Source-only THIR Scope edge candidate

Date: November 8, 2026. This is an unintegrated implementation candidate, not
another execution of native116 and not a supplied origin lookup/model fixture.
Only the two changed Rust files are staged. All inputs remain immutable.

## Disposition

Source inspection supports scanning `builder.thir.exprs` at the existing
`checked_drop_origins::retain(&self)` call in `Builder::finish`. The candidate
records every actual `ExprKind::Scope { value, hir_id, region_scope }` in that
arena, including its enumerated Scope ExprId. It separately reports every edge
whose stored `value` equals a captured temporary's actual ExprId. No span join,
name join, recursive/transitive join, first-match choice, or new HIR origin is
introduced. The original `TemporaryOrigin.scope`, including `None`, is unchanged.

This is viable as a diagnostic capture, NOT established as compiled or as
recovering any particular original header edge. The original e78 edge count and
HIR identifiers remain UNKNOWN until a distinct authorized runtime validation.

`native_resource_correspondence = false`; `proof_acceptance = false`;
All18 OPEN; native/resource/trust credit 0. No primitive laws/producers,
normalization, mapping approval, admission, resource policy, import/export,
eager glue resolution, or semantic native behavior is changed.

## Source evidence and construction caveat

Authenticated frozen114 files are recorded in `SOURCE-IDENTITY.json`.

- `source/rustc_mir_build/src/thir/cx/expr.rs:134`: pushes the adjusted expression
  as `value`; the later Scope stores that exact ExprId and the HIR expression's
  `hir_id`, plus `expr_scope`. Its Scope ExprId is separately pushed at line 153.
- `source/rustc_mir_build/src/builder/mod.rs:174`: Builder borrows `Thir`.
  Lines 86-98 pass the borrowed THIR from `tcx.thir_body(def)` to construction.
  Line 992 calls the existing retain hook before moving CFG/locals into `Body`.
- `source/rustc_mir_build/src/builder/expr/as_temp.rs:41`: the existing Scope arm
  recurses on its stored `value`. The bare-expression path later records its own
  `expr_id` and MIR temporary. The new table does not edit either observation.
- `source/rustc_mir_build_additional_files/verus_expr.rs:240`: `scope_post` can
  return the original Scope, or append `Scope(arg0)` and a replacement reference-
  tie Call while leaving the previously pushed Scope/Call in the arena. Thus an
  arena scan can include abandoned and synthetic wrappers. It does NOT prove
  that a Scope is reachable from the returned THIR root or used to construct MIR.
- The actual final observer116 `Callbacks::config` replaces the MIR builder hook
  and the elaborated-MIR query, NOT `queries.thir_body`. Its original THIR is
  supplied by the pinned sysroot compiler's default THIR provider. Frozen custom
  `expr.rs` and `scope_post` explain a construction relation, not an authenticated
  assertion that those exact lowering functions execute in original-native116.
  `begin(true)` is a stored mode flag, not proof of lowering provenance.

The exact relation captured is ONLY:

    builder.thir.exprs[scope_expression].kind
        == Scope { value: value_expression, hir_id, region_scope }

The temporary join is ONLY `value_expression == TemporaryOrigin.expression`,
within the capture's session/body. For an observation whose expression is itself
a Scope, this is an incoming-edge query, not a query for that Scope's outgoing
edge. All outgoing edges remain in `all_raw_scope_edges` with their Scope IDs.
No wrapper peeling or construction-site reconstruction is attempted.

## Files and API

`candidate.patch` is a two-file unified diff relative to a future staging layout
containing `source/` and `observer/`. It must NOT be applied to frozen114,
observer116, any repository/worktree, or the active runtime-review lane here.

Exact candidate files:

- `candidate/source/rustc_mir_build/src/builder/checked_drop_origins.rs`
- `candidate/observer/src/main.rs`

New public helper API, under the existing public `builder::checked_drop_origins`:

    ThirScopeSession { generation: u64, native: bool }
    ThirScopeEdge {
        scope_expression: ExprId, value_expression: ExprId,
        hir_id: HirId, region_scope: Scope,
    }
    ThirScopeCapture {
        session: ThirScopeSession, body: LocalDefId, complete: bool,
        expression_count: Option<usize>, edges: Vec<ThirScopeEdge>,
    }
    thir_scope_session() -> Option<ThirScopeSession>
    get_thir_scopes(LocalDefId) -> Option<ThirScopeCapture>

The new table uses the existing default-false ENABLED guard. `begin(native)`
clears the table and allocates a checked, monotonically increasing process-local
session generation. Existing temporary hooks only mark an incomplete body entry;
they do not create edges. Normal retain completion enumerates the whole arena and
publishes a complete entry, even when it contains zero Scope edges. Bodies that
complete without temporary observations are also included. Existing binder and
temporary tables retain their previous semantics and signatures.

The observer reports full raw edges and per-temporary exact matches, including
all matching edges in arena order without deduplication. Its key includes process
ID, current/captured session generations, expected/captured LocalDefId, definition
path/hash, captured native flag, and observed MIR phase. Process ID/generation and
ExprIds are NOT persistent identities across compiler runs. These flags and IDs
do not establish native semantics, ownership, or HIR/VIR mapping.

States are explicit and independent for the entire capture and each match query:

- `MISSING`: no retained entry for that body. Raw edges/matches are null.
- `INCOMPLETE`: a temporary hook ran but normal retain did not finish. The edge
  vector currently remains empty; that is NOT negative evidence of a Scope edge.
- `COMPLETE_EMPTY`: retain completed and the relevant edge set is empty. A match
  query can be complete-empty while the full arena capture is complete-nonempty.
- `COMPLETE_NONEMPTY`: retain completed and the relevant edge set is nonempty.
  Cardinality one is still NOT uniqueness of origin, reachability, or ownership.
- `KEY_MISMATCH`: current session or requested body differs; matching is withheld
  as null, while the full raw mismatched capture remains diagnostically visible.

Schema version is 2. P3's misleading old
`same_name_candidates_not_forced_by_observer` report key is replaced only in the
NEW source by `same_name_definitions_discovered`, plus an explicit statement that
discovery does not establish query history. Selection, provider requests, and old
source/reports are unchanged.

## Exact unvalidated API/type and operational risks

1. The scanner assumes the pinned `rustc_middle::thir::ExprKind::Scope` layout and
   `builder.thir.exprs.iter_enumerated()` yielding `(ExprId, &Expr)`. Matching a
   borrowed expression's kind by value requires the selected fields to be Copy,
   consistent with the existing `as_temp` arm. Only a real compiler typecheck can
   validate these assumptions for the sysroot's rustc-private ABI.
2. `HirId`, `Scope`, and ExprId use their existing Clone/Debug capabilities in
   owned session data; the observer uses Debug for their serialized identity.
   JSON is diagnostic, not an approved stable interchange format or HIR/VIR map.
   The public API exposes the actual typed values, without JSON reconstruction.
3. `AtomicU64::fetch_update`, iterator inference, the rustc-private crate linkage,
   and serde_json macro expansions remain UNTYPECHECKED. Rustfmt does not resolve
   these types, expand/check those macros, or validate provider compatibility.
4. Like the existing global tables, this design requires nonoverlapping compiler
   sessions and begin-before-build. A fresh session does not invalidate rustc
   query caches; begin on an already-used TyCtxt can yield missing captures. No
   concurrent-session safety or end/disable API is claimed. `begin(false)` still
   enables diagnostics; it is NOT the disabled control.
5. Every enabled body is scanned once at finish; API reads clone its edge vector.
   Reports duplicate matches at relevant drops and typed temporaries. Allocation,
   mutex poisoning, whole-crate overhead, report size, and abrupt builder failure
   require bounded runtime observation. No performance or side-effect equivalence
   has been tested. Captures themselves add only diagnostic memory/locking work.
6. The existing ORIGINS duplicate-body assertion can fail before the new complete
   publication. Error construction can bypass Builder::finish entirely. Missing,
   incomplete, complete-empty, and compiler completion are distinct observations.
7. The old observer Cargo.toml points at immutable frozen114 and cannot build this
   new API. A separate authorized integration stage and a manifest pointing at
   THAT modified helper are prerequisites; using the old manifest is not valid
   candidate validation. Source-only input119 review and the old116 build do not
   transfer validation to this candidate.

## What actually ran

Read-only source inspection, SHA256/size/manifest identity checks, text diff
generation, and three bounded pinned-rustfmt syntax-only parses (each <15s).
`SYNTAX-ONLY.json` records the individual parses and source identities. No Cargo,
build, Rust typecheck, tests, verifier, solver, native observer, native program,
network, Git, delegation, source integration, or parent workflow was executed.
Python was used only for hashes/metadata/text patch staging and bounding rustfmt;
NO Python shadow AST or origin-model test was used.

## Suggested distinct bounded validation task (NOT EXECUTED)

Wait for the parent's compiler-diagnostic slot and explicit integration/build
authorization. Do not start a follow-on chain from this handoff. Provision a new
authorized stage with both candidate replacements and a stage-local observer
manifest pointing at `../source/rustc_mir_build`. Preserve the pinned dependency
versions/lock, source/dependency layout and toolchain; never edit the frozen
inputs or reuse the active116 target as an output. This lane provisions none of
that stage, no toolchain/cache/target/tree copies, and no buildable Cargo project.

Use the existing offline plan conventions, with new input hashes/output paths:

- Toolchain `/Users/tommyvolk/.rustup/toolchains/1.99.1-aarch64-apple-darwin`.
- `CARGO_HOME=/Users/tommyvolk/.cargo`, `RUSTC_BOOTSTRAP=1`,
  `CARGO_NET_OFFLINE=true`, `CARGO_INCREMENTAL=0`, `CARGO_BUILD_JOBS=1`,
  `CARGO_PROFILE_DEV_DEBUG=0`, `RUSTFLAGS=-Cdebuginfo=0`,
  `RUST_MIN_STACK=20971520`, and the pinned toolchain's RUSTC/RUSTDOC/lib paths.
- Redirect CARGO_TARGET_DIR, CARGO_BUILD_BUILD_DIR, TMPDIR and reports to the new
  authorized output root. Set PATH to the pinned toolchain bin and system bins.
- A single overall <=900s task, one build <=600s, original run <=90s, remaining
  controls within the leftover budget; stop rather than automatically retry.
  Suggested separate-task scratch <=6GiB and continuously enforced free disk
  >16GiB, with explicit process-group timeout/reaping and bounded report output.
  The 6GiB suggestion is NOT this lane's <=20MiB source-only scratch allowance.

The build argv, only inside that newly preregistered bounded collector plan:

```sh
"$TC/bin/cargo" build --offline --locked -j1 \
  --manifest-path "$STAGE/observer/Cargo.toml"
```

Original-body argv after successful authenticated candidate build, again inside
the bounded collector and to a fresh absolute JSON destination:

```sh
"$OUT/target/debug/redb-native-mir-observer" \
  --report "$OUT/reports/original-header-scope-edges.json" \
  --definition tree_store::page_store::page_manager::TransactionalMemory::write_header \
  --crate-source /private/tmp/redb-original-crate-preflight115/redb/src/lib.rs \
  --libc /private/tmp/redb-native-mir-observer116-20261108T164457Z/target-libc-audited/debug/deps/liblibc-3b1090a6c1c370ea.rmeta \
  --sysroot "$TC"
```

Set TC, STAGE, OUT in the newly registered plan; the above are not runnable
registrations. Existing collector invocation shape, after preparing a NEW plan:

```sh
python3 /private/tmp/redb-native-mir-observer116-20261108T164457Z/run_command.py \
  --plan "$NEW_PLAN"
```

The inherited observer deliberately exits 2 after an observed raw-MIR capture,
65 for an unobserved target, 70 for publication/compiler failure, and 64 for CLI
refusal. The existing collector records nonzero exits as unsuccessful processes;
do not relabel exit 2 as proof acceptance. Inspect its actual receipt and report.
Bind source hashes, executable hash, fixed compiler argv, original inputs and
libc metadata afresh; old116 executable/hash is not the candidate executable.

Required controls, all UNEXECUTED:

1. Original header: re-find the actual e78 -> _20 WritablePage observation and
   the normal bb16 / cleanup bb19 drops in the original body and current session.
   Preserve original scopeNone. Inspect every direct Scope.value == e78 edge and
   its actual HirId/region_scope, full arena count, normal-completion state, keys,
   and MIR phase. Changed IDs or absent edges must be reported, not patched by
   spans, invented origin ownership, or hard-coded expected HIR identifiers.
2. Complete-empty versus missing: exercise a real completed capture with an
   actual temporary whose expression has no incoming value edge, and a body for
   which retain was not reached. For full-arena zero-Scope behavior, use the
   actual Rust helper/capture path with a genuine zero-Scope THIR arena only if a
   bounded real case can be established; do not assert that an empty Rust fn has
   no Scope nodes. Otherwise leave that control explicitly unvalidated. No hand-
   populated capture table or Python stand-in establishes helper behavior.
3. Incomplete: a bounded genuine builder-error/unwind case after a temporary hook
   but before retain must stay incomplete, not complete-empty. If the compiler
   abort prevents safe querying/reporting, record that limitation; do not invent
   a successful report or overwrite an input artifact.
4. Disabled/session-reset: a fresh process without begin must leave new APIs None
   and no scan active. Two nonoverlapping fresh compiler sessions with begin must
   have different generations and no leaked body entries, even if numeric local
   DefIds recur. Check native true/false stored flags without interpreting them as
   proof. Initial disabled is distinct from begin(false).
5. Ambiguous edges: if the actual arena has multiple Scope nodes with the same
   value, every edge must survive API cloning, full reporting, and each exact
   join. No first-match, deduplication, or uniqueness conclusion is permitted.
   If no real multi-edge case exists under the budget, leave the control OPEN.
6. Two-origin same-span: use compiler-produced distinct temporary ExprIds/locals
   with genuinely equal observed source spans. Verify both origins survive and
   each matches ONLY its own ExprId edges, irrespective of the shared span. Span
   equality must itself be observed, not assumed from similar syntax or macros.
   MIR source spans are not automatically equal THIR spans; if stronger THIR-span
   equality cannot be established, state that narrower control explicitly.

This source-only handoff closes none of these controls and establishes no
reachability, unique ownership, approved mapping, or resource correspondence.
