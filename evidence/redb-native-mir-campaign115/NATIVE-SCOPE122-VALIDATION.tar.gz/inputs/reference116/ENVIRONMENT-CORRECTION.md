The first build failed with proc-macro2 incremental-directory creation denied.
Task116 supplied `-Cincremental=` incorrectly: empty is not disabled. No elevation
was requested because it could permit writes into installed package directories.
The correction removes this flag, retains CARGO_INCREMENTAL=0, and confines Cargo
outputs to this experiment. The failed plan and stdout/stderr/receipt are retained.
The first plan's embedded environment preserves the exact before state.
