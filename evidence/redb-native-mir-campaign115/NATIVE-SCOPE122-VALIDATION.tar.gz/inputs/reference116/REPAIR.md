# Parent repair of the three source-review115 P2 findings

The old unbuilt candidate and review inputs remain untouched. Only four small
authored/source-lock files were copied here; no target, toolchain or dependency
cache was copied. This revision remains unbuilt until separately validated.

Selection now requires an exact rustc qualified definition path, not a bare
method name. after_analysis rejects zero/multiple matches before explicitly
forcing any selected MIR query. Same-name candidates are reported for discovery
but not forced by the observer. Compiler-driven ordinary queries can still run;
those are not relabelled as observer-forced queries or native proof.

The command interface no longer forwards arbitrary rustc arguments. It accepts
only the report, exact definition, existing source/libc metadata and sysroot.
The constructed profile is fixed redb/default+std/edition2024/metadata. There is
no user route for link-only, response files, explicit output destinations or
dep-info overlap. This selected diagnostic profile is not a production Cargo
replay; it has no code generation or interface/export acceptance claim.

Report output is now written completely to an exclusive, retained staging file,
flushed and synced, then published by a no-clobber hard link. An existing final
report is refused before compiler entry, and a destination created meanwhile
cannot be overwritten. The staging artifact remains for auditing, not silently
deleted. JSON-only absolute destinations require a canonical existing parent.

The three findings are repaired in source, not yet independently closed or
runtime tested. Additional rustc API/typechecking corrections may be needed.
The scratch command collector retains raw status and actual timestamps; its
synthetic cancellation check is not proof of compiler/runtime correspondence.
All18 remain OPEN; no trust, native resource or admission credit is added.
