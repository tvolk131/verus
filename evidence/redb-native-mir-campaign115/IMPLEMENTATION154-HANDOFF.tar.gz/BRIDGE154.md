# Task154 fixed correspondence proposal and inherited trust

## Authority and status

AUTHORIZATION139/FIRST-CELL139 and the task154 instruction govern this scratch
candidate. STORE-CONTRACT-DISPOSITION153 permits conditional reuse of the
EXISTING inherited vstd raw_ptr::ptr_mut_write::<u8> contract. No new store
axiom is introduced, needed for that contract, installed, or adopted here.
P151-v1(A) raw allocation remains UNADOPTED.147 remains UNADOPTED. All18 OPEN.
The standalone correspondence adapter is development evidence, not approval
of automatic native MIR admission. It always refuses original native export.

## Exact compiler-owned lowering, rather than a Seq trace

The new permission154 binary runs rustc analysis of the unchanged original
redb crate. Its internal TypedStore contains real compiler Instance/Local/Ty
data. Neither JSON nor Debug text is read back to select or authorize a store.
Local numbers and block/statement labels are observations, not certificate keys.

Root discovery uses a name only as a search hint, then requires exactly one
local definition in the exact canonical selected original cached_file.rs,
one usize argument, and an alloc Arc with a slice-u8 return. Its unique actual
Arc-returning call supplies the exact iterator type. Resolved callees are
followed by normalized return-type equality, not suffix/substring selection.
The resulting four-instance route is collect -> from_iter -> to_arc_slice ->
from_iter_exact. This route is a source connection, not proofs of those bodies.

For the selected alloc instance, the compiler requires concrete u8 and the
EXACT iterator type from that original call, a core RepeatN<u8>, exactly one
raw-pointer assignment with a single Deref destination projection, mutable
*mut u8, and Rvalue::Use(Copy(unprojected-u8-local), WithRetag::Yes). Retagging
is limited to scalar u8, not generalized to pointer-bearing values. It checks
unique local definitions for pointer/index/item, same-block reaching order,
typed Offset(base,index), exact Some tuple projections of the SAME Option
local, no intervening overwrite, one normal predecessor, and the actual
Option discriminant edge selecting Some. Source scope binds the actual
inlined core write DefId with instantiated argument u8. Full owner MIR,
typed source observations, substitutions, guard and source endpoints are saved.
Wrong/ambiguous shapes abort without producing a qualifying result.

The internal Local-to-parameter map generates the statement from that typed
store: the actual pointer Local becomes the executable pointer parameter,
and the actual operand Local becomes the executable u8 parameter. Its emitted
statement is ptr_mut_write::<u8>(actual_pointer, Tracked(perm), actual_operand).
The postcondition is separately emitted from the original operand, so a
wrong-byte/effect lowering does not change the promised result. This is
compiler-generated ordinary Verus Rust -> VIR, not a direct trusted AIR
assertion, parsed observer certificate, or manually supplied proof file.
Generation is cross-process; byte hashes connect generated input to each
ordinary verifier invocation. Those hashes are evidence, not permission.

The generated conditional harness has additional tracked permission/frame
parameters and a second executable pointer used by negative tests; it is NOT
the signature or a checked executable whole body of the original function.
The normal harness also constrains that test pointer to have a different
address. No original caller is claimed to satisfy the harness signature.

## Genuine permission and exact downstream theorem

The ordinary verifier checks a tracked mutable borrow of real
vstd::raw_ptr::PointsTo<u8>, not a new descriptor/marker type. The precondition
uses SPECIFICATION equality old(perm).ptr()==actual_pointer. Runtime pointer
PartialEq and numerical address equality are insufficient. The returned use
of that same borrow has the same pointer/address/provenance, and
MemContents::Init(actual_operand). u8 extent is one byte. A generic retained
PointsTo<Frame> borrow has an explicitly disjoint byte interval, and its
entire view is unchanged. No global ambient/map/allocator/callback frame is
asserted. No allocation descriptor/Arc length/count/sequence relation is
silently added. The cell extent is stable; original allocation extent is OPEN.

The primitive's already-external_body implementation and its provenance/value
model are inherited vstd trust. opens_invariants none/no_unwind are inherited
only for the valid primitive invocation. Scalar-copy/retag and the choice to
represent this exact inlined native write by that invocation are the explicit
correspondence-development boundary; this candidate is not an independently
proved compiler semantics or bootstrap/source-to-sysroot attestation.

Ordinary Rust/Verus WF, tracked borrow/affinity and mode checks are enabled;
no no-lifetime/no-verify/admit/assume option or application external_body is
added. VIR/SST/AIR/SMT and solver transcripts are retained for normal and
semantic-negative runs. Genuine no-permission/duplication tests fail WF/borrow
checking; a ghost token fails mode checking; wrong pointer/provenance fail
the inherited contract's precondition in SMT. No integer descriptor, generation
label, JSON or mathematical witness mints a permission. Stale provenance is
rejected even when the numeric address is equal. No numeric-generation model
is substituted for actual vstd provenance.

## Concrete missing checked premises, not new grants

The exact original caller does NOT yet provide PointsTo<u8>. No proof here
establishes that the actual Offset(base,index) is in the allocated object,
shares the live allocation provenance, or that the original allocation issued
the required affine resource. The native assignments/Some guard are checked
structurally; iteration count, index bounds and dynamic value/heap resource
correspondence are not inferred from their presence. DefId/typing/source
checks cannot manufacture those premises. Consequently no original native
store occurrence is accepted unconditionally, and fresh export stays refused.

The smallest next checked dependency is ORIGINAL allocation-to-payload-cell
issuance at this Offset: obtain a genuine live allocation resource from the
actual allocation path, prove index/object bounds and pointer/provenance
equality, and split its exact one-byte range into this borrow while retaining
the complement. Existing PointsToRaw::split/into_typed APIs are available
subject to their real domain/provenance/range/alignment premises; an empty
resource or address descriptor cannot meet a one-byte range premise. No new
store axiom is missing. Raw allocation151(A) is still UNADOPTED. After that,
iterator/loop/Arc header/count/wrapping and source-to-sequence/cache/caller
composition remain checked dependencies. No full original cell is closed.
