# Task154: source-connected typed byte permission transfer

## Result and separate counts

One compiler-selected original typed store occurrence is lowered into a real
permission-taking ordinary checked program. One DISTINCT generated conditional
executable body verifies,1 verified/0 errors, with exact operand-byte
initialization, specification pointer/provenance preservation, one-byte extent,
and a retained disjoint generic frame token. This is not151's mathematical Seq
trace. Repeated normal/restoration runs do not add distinct body credit.

Original executable whole bodies verified:0. Original native store occurrences
accepted without missing premises:0. Structurally source-bound lowered native
store occurrences:1. Distinct generated conditional proof bodies:1. New laws
adopted:0. Original allocation/caller issuance and automatic MIR correspondence
acceptance:OPEN. Native export:REFUSED; requested native metadata absent.
All18 original campaign94 cells remain OPEN; full two-phase acknowledged
durability scope is unchanged. No original application/tests execute.

STORE-CONTRACT-DISPOSITION153 is retained and applied precisely: inherited
ptr_mut_write::<u8> reuse is permitted; no new native store axiom is installed.
BRIDGE154.md fixes the exact mapping, checked/inherited boundary and missing
resource premises. It does not claim that this permission-taking generated
function proves original caller authority or an original whole body.

## Actual source and generated semantics

The unchanged original root is zero_filled_arc in cached_file.rs. Compiler
Instance resolution follows the actual Arc-returning call with typed iterator
substitution through collect/from_iter/to_arc_slice/from_iter_exact. Selection
does not parse Debug locals, suffixes or serialized JSON. Typed matching and
reaching-definition/Some-control checks establish the unique source occurrence.
Actual observed store: (*_19)=copy _18, u8, from_iter_exact::<u8,RepeatN<u8>>;
its pointer definition is Offset(copy _7,copy _17), with item/index projected
from the same Some((usize,u8)). Those labels are observed, never fixed keys.
The inlined core::ptr::write source scope instantiates to u8. Generation uses
the actual internal Local identities for pointer and byte parameters, and
the actual selected operand remains the expected postcondition value.

Normal code takes genuinely tracked PointsTo<u8>; it neither constructs nor
duplicates it. The additional generic frame token is preserved by ordinary
tracked borrowing, not by an assumed arbitrary outside-map relation. The
primitive and raw pointer/value/provenance model are inherited vstd trust.
The structural adapter and scalar-retag correspondence are not promoted to
an approved general raw-MIR-to-resource producer. No147 API is consumed.

## Validation retained

- Final checked-normal and restored-normal each verify1 body,0 errors.
- checked-wrong-byte writes actual_operand XOR1; SMT fails EXACTLY at
  final(perm).opt_value()==Init(actual_operand). No claimed byte0 shortcut.
- checked-omit-effect emits no write; SMT fails the same initialization/value
  postcondition. It cannot pass by observing an unchanged token.
- checked-wrong-pointer fails ptr_mut_write's specification-pointer premise.
- checked-wrong-provenance preserves the numeric address but requires different
  provenance; SMT rejects the inherited same-pointer precondition.
- checked-missing-permission fails E0381 (uninitialized real tracked token).
- checked-duplicate-token fails E0507 (move of non-Copy token from borrowed
  permission), and checked-spec-permission fails ghost mutable-borrow mode.
- rejected-outcome refuses unwind before writing generated/binding artifacts;
  only normal assignment fallthrough is proposed, not whole-function normality.
- Independent regeneration restores byte-identical normal generated source;
  ordinary solver succeeds again. Wrong-byte tests are compiler lowering
  fault injections, NOT executable original-program/source mutants.
- final-original-export-refusal freshly analyzes the unchanged original,
  exits1, explicitly refuses native export, and leaves no requested .rmeta.

All failed attempts remain. Setup1 failed an inventory ordering comparison
(Path-component ordering versus relative-string ordering); setup2 fixes only
that recorder issue. First build fails pinned Rvalue::Use's two-field API;
build4 repairs it. Binding5 rejects the printed public alias of RepeatN;
structural crate/DefId-name/type matching replaces that path comparison.
Build6 fails because EarlyBinder returns Unnormalized; build7 explicitly
normalizes it. Binding8 exposes actual WithRetag::Yes; build9 bounds the
proposed scalar-u8 form and binds the inline owner. Build13 adds type-driven
source selection and actual Some predecessor/discriminant/reaching checks.
These are real charged setup/API/correspondence failures, not solver success.

## Custody, budget, and handoff

The supplied151 MANIFEST/SEAL/archive SHA pins authenticate locally. Fresh
scratch copies of candidate and target are used; original/151/parent sources
are unchanged. Input source, library, selected toolchain and inherited binary
endpoints are rehashed before and after charged commands. The new153
disposition/report have separate endpoint records from command14 onward.
No network, Git write, subdelegation, original source edit or integration.

These hashes establish local endpoint consistency, NOT independent historical
authentication, continuous custody, bootstrap or source-to-loaded-sysroot
correspondence. Ordinary verifier/vstd/Z3 artifacts are inherited pinned151
binary endpoints; no fresh vstd support-body credit is claimed. First setup
failed before recorder initialization: its exact subprocess clocks/streams/env
are only in the tool transcript, not a contemporaneous runner receipt. This
limitation is explicit, not reconstructed into false custody. Early driver
source bytes are reconstructed only when they match existing launch hashes.

Recorded commands have argv/env/cwd/status/clocks/streams, source inventories,
argument endpoints, runner/source history and resource samples. Failed commands
are charged. All owned children are reaped; there is no timeout or state-changing
signal. Signal0 group-absence probes record observations, not a general
descendant-containment theorem. HANDOFF154.json records final actual count,
elapsed time, resources, seal pins and explicit slot release after final
compiler/verifier work. Source/proofs/VIR/AIR/SMT/transcripts are archived;
target binaries have endpoint hashes but are not shipped as a bootstrap bundle.

Next checked dependency: the actual allocation-to-cell resource issuance and
Offset(base,index) bounds/live-provenance correspondence described in
BRIDGE154.md, then original iterator/loop/Arc and checkout composition. There
is no missing new store axiom and no permission grant from this handoff.
