#![feature(rustc_private)]
#[macro_use]
mod common;
use common::*;

test_verify_one_file_with_options! {
    #[test] old_in_body [] => verus_code! {
        fn test(x: &mut u64)
            requires *x == 0
        {
            *x = 5;

            assert(*x == 5);
            assert(*old(x) == 0);
        }

        fn test_fail(x: &mut u64)
            requires *x == 0
        {
            *x = 5;

            assert(*x == 5);
            assert(*old(x) == 0);
            assert(false); // FAILS
        }

        fn test_field(x: (&mut u64, &mut u64))
            requires *x.0 == 0
        {
            *x.0 = 5;

            assert(*x.0 == 5);
            assert(*old(x.0) == 0);
        }

        fn test_field_fail(x: (&mut u64, &mut u64))
            requires *x.0 == 0
        {
            *x.0 = 5;

            assert(*x.0 == 5);
            assert(*old(x.0) == 0);
            assert(false); // FAILS
        }
    } => Err(err) => assert_fails(err, 2)
}

test_verify_one_file_with_options! {
    #[test] old_in_closure_body [] => verus_code! {
        fn test() {
            let clos = |x: &mut u64|
                requires *x == 0
            {
                *x = 5;
                assert(*x == 5);
                assert(*old(x) == 0);
            };
        }

        fn test_fail() {
            let clos = |x: &mut u64|
                requires *x == 0
            {
                *x = 5;
                assert(*x == 5);
                assert(*old(x) == 0);
                assert(false); // FAILS
            };
        }

        fn test_field() {
            let clos = |x: (&mut u64, &mut u64)|
                requires *x.0 == 0
            {
                *x.0 = 5;
                assert(*x.0 == 5);
                assert(*old(x.0) == 0);
            };
        }

        fn test_field_fail() {
            let clos = |x: (&mut u64, &mut u64)|
                requires *x.0 == 0
            {
                *x.0 = 5;
                assert(*x.0 == 5);
                assert(*old(x.0) == 0);
                assert(false); // FAILS
            };
        }
    } => Err(err) => assert_fails(err, 2)
}

test_verify_one_file_with_options! {
    #[test] old_in_spec_fn [] => verus_code! {
        spec fn foo(x: &mut u64) -> u64 {
            *old(x)
        }
    } => Err(err) => assert_vir_error_msg(err, "`old` is meaningless in spec functions")
}

test_verify_one_file_with_options! {
    #[test] old_in_spec_fn_sig [] => verus_code! {
        spec fn foo(x: &mut u64) -> u64
            recommends *old(x) == 0
        {
            0
        }
    } => Err(err) => assert_vir_error_msg(err, "`old` is meaningless in spec functions")
}

test_verify_one_file_with_options! {
    #[test] old_of_spec_closure_param [] => verus_code! {
        proof fn test() {
            let x = |a: &mut u64| *old(a) == 0;
        }
    // TODO(new_mut_ref): (low-pri) slightly confusing error msg here
    } => Err(err) => assert_vir_error_msg(err, "`old` for a local variable that isn't a parameter")
}

test_verify_one_file_with_options! {
    #[test] old_of_local [] => verus_code! {
        fn test() {
            let mut x = 24;
            let x_ref = &mut x;
            *x_ref = 30;
            assert(*old(x_ref) == 24);
        }
    } => Err(err) => assert_vir_error_msg(err, "`old` for a local variable that isn't a parameter")
}

test_verify_one_file_with_options! {
    #[test] postcondition_missing_old [] => verus_code! {
        fn test(x: &mut u64)
            ensures *x == 20,
        {
        }
    } => Err(err) => assert_vir_error_msg(err, "to dereference a mutable reference parameter in a postcondition, disambiguate by wrapping it in either `old` or `final`")
}

test_verify_one_file_with_options! {
    #[test] postcondition_missing_old_async_fn [] => verus_code! {
        use vstd::prelude::*;

        pub async fn bar(x: &mut usize) -> (ret: ())
            ensures
                *x == 2333,
        {
            *x = 2333;
        }
    } => Err(err) => assert_vir_error_msg(err, "to dereference a mutable reference parameter in a postcondition, disambiguate by wrapping it in either `old` or `final`")
}

test_verify_one_file_with_options! {
    #[test] postcondition_missing_old_closure [] => verus_code! {
        fn test() {
            let clos = |x: &mut u64|
                ensures *x == 20,
            {
            };
        }
    } => Err(err) => assert_vir_error_msg(err, "to dereference a mutable reference parameter in a postcondition, disambiguate by wrapping it in either `old` or `final`")
}

test_verify_one_file_with_options! {
    #[test] postcondition_missing_old_for_return_is_ok [] => verus_code! {
        fn test(x: &mut u64) -> (y: &mut u64)
            ensures *y == *old(x) && *final(y) == *final(x),
        {
            x
        }
    } => Ok(())
}

test_verify_one_file_with_options! {
    #[test] postcondition_missing_old_for_tuple [] => verus_code! {
        fn test(x: (&mut u64, &mut u64))
            ensures *x.1 == 20,
        {
        }
    } => Err(err) => assert_vir_error_msg(err, "to dereference a mutable reference parameter in a postcondition, disambiguate by wrapping it in either `old` or `final`")
}

test_verify_one_file_with_options! {
    #[test] postcondition_old_fin_tuple_ok [] => verus_code! {
        fn test(x: (&mut u64, &mut u64))
            requires *x.1 < 10,
            ensures *final(x.1) == *old(x.1) + 1
        {
            *x.1 = *x.1 + 1;
        }
    } => Ok(())
}

test_verify_one_file_with_options! {
    #[test] postcondition_old_fin_tuple_ok_2 [] => verus_code! {
        // I intend for this to also be ok but `old` is currently restricted to &mut -> &mut
        fn test2(x: (&mut u64, &mut u64))
            requires *x.1 < 10,
            ensures *final(x.1) == *old(x).1 + 1
        {
            *x.1 = *x.1 + 1;
        }
    } => Err(err) => assert_rust_error_msg(err, "mismatched types")
}

test_verify_one_file_with_options! {
    #[test] old_containing_fin [] => verus_code! {
        fn test2(x: &mut u64)
            ensures *old(final(x)) == 20
        {
        }
    } => Err(err) => assert_vir_error_msg(err, "The result of `final` must be dereferenced")
}

test_verify_one_file_with_options! {
    #[test] fin_containing_old [] => verus_code! {
        // bizarre thing to write, but there's no reason to disallow it
        fn test2(x: &mut u64)
            ensures *final(old(x)) == 20
        {
            *x = 20;
        }
    } => Ok(())
}

test_verify_one_file_with_options! {
    #[test] nested_mut_refs [] => verus_code! {
        #[verifier::exec_allows_no_decreases_clause]
        fn leak_mut_ref() -> (res: &'static mut u64)
            ensures
                *res == 2,
                *final(res) == 19, // It's obviously impossible to predict this
        {
            loop { }
        }

        fn test0(x: &mut &mut u64)
            requires
                *old(*old(x)) == 0,
            ensures
                mut_ref_current(mut_ref_current(x)) == 0,
                mut_ref_future(mut_ref_current(x)) == 1,
                mut_ref_current(mut_ref_future(x)) == 3,
                mut_ref_future(mut_ref_future(x)) == 19,
        {
            **x = 1;
            *x = leak_mut_ref();
            **x = 3;
        }

        fn test1(x: &mut &mut u64)
            requires
                *old(*old(x)) == 0,
            ensures
                *old(*old(x)) == 0,
                *final(*old(x)) == 1,
                *old(*final(x)) == 3,
                *final(*final(x)) == 19,
        {
            **x = 1;
            *x = leak_mut_ref();
            **x = 3;
        }

        // old isn't needed for the outer derefs
        fn test2(x: &mut &mut u64)
            requires
                *old(*old(x)) == 0,
            ensures
                **old(x) == 0,
                *final(*old(x)) == 1,
                **final(x) == 3,
                *final(*final(x)) == 19,
        {
            **x = 1;
            *x = leak_mut_ref();
            **x = 3;
        }

    } => Ok(())
}

test_verify_one_file_with_options! {
    #[test] test_assert_by [] => verus_code! {
        fn test1_assert_by(x: &mut u64)
            requires *x == 0,
        {
            *x = 1;
            assert(*old(x) == 1) by { }; // FAILS
        }

        fn test2_assert_by(x: &mut u64)
            requires *x == 0,
        {
            *x = 1;
            assert(*x == 0) by { }; // FAILS
        }

        fn test3_assert_by(x: &mut u64)
            requires *x == 0,
        {
            *x = 1;
            assert(*old(x) == 0 && *x == 1) by { };
            assert(false); // FAILS
        }
    } => Err(err) => assert_fails(err, 3)
}

test_verify_one_file_with_options! {
    #[test] test_assert_forall [] => verus_code! {
        spec fn foo(z: bool) -> bool { z }

        fn test1_assert_forall(x: &mut u64)
            requires *x == 0,
        {
            *x = 1;
            assert forall |z| #[trigger] foo(z) implies *old(x) == 1 by { }; // FAILS
        }

        fn test2_assert_forall(x: &mut u64)
            requires *x == 0,
        {
            *x = 1;
            assert forall |z| #[trigger] foo(z) implies *x == 0 by { }; // FAILS
        }

        fn test3_assert_forall(x: &mut u64)
            requires *x == 0,
        {
            *x = 1;
            assert forall |z| #[trigger] foo(z) implies *old(x) == 0 && *x == 1 by { };
            assert(!foo(false));
            assert(foo(true));
            assert(false); // FAILS
        }

        fn test4_assert_forall(x: &mut u64)
            requires *x == 0,
        {
            *x = 1;
            assert forall |z| *old(x) != 1 implies #[trigger] foo(z) by { }; // FAILS
        }

        fn test5_assert_forall(x: &mut u64)
            requires *x == 0,
        {
            *x = 1;
            assert forall |z| *x != 0 implies #[trigger] foo(z) by { }; // FAILS
        }

        fn test6_assert_forall(x: &mut u64)
            requires *x == 0,
        {
            *x = 1;
            assert forall |z| !(*old(x) == 0 && *x == 1) implies #[trigger] foo(z) by { };
            assert(!foo(false));
            assert(foo(true));
            assert(false); // FAILS
        }
    } => Err(err) => assert_fails(err, 6)
}

test_verify_one_file_with_options! {
    #[test] test_assert_nonlinear [] => verus_code! {
        fn nonlinear(x: &mut u64)
            requires *x == 0,
        {
            *x = 5;
            assert(*x == 0 && *old(x) == 5) by(nonlinear_arith);
        }

        fn nonlinear2(x: &mut u64) {
            assert(*x == 0 && *old(x) == 5) by(nonlinear_arith)
              requires *x == 0 && *old(x) == 5;
        }
    } => Err(err) => assert_vir_error_msgs(err, &[
        "`old` is not supported in `nonlinear_arith` assert",
        "`old` is not supported in `nonlinear_arith` assert",
    ])
}

test_verify_one_file_with_options! {
    #[test] old_in_closure_referring_to_outer_param [] => verus_code! {
        use vstd::prelude::*;

        fn test(x: &mut u64)
            requires *x == 0,
        {
            *x = 5;

            let mut clos = ||
                requires *old(x) == 0
            {
                assert(*old(x) == 0);
            };

            assert(*old(x) == 0);
            clos();
        }

        fn test2(x: &mut u64)
            requires *x == 0,
        {
            *x = 5;

            let mut clos = ||
                requires *x == 5
            {
                assert(*x == 5);
            };

            clos();
        }

        fn test3(x: &mut u64)
            requires *x == 0,
        {
            let mut clos = ||
                requires *x == 5
            {
                assert(*x == 5);
            };

            *x = 5;

            clos(); // FAILS
        }
    } => Err(err) => assert_fails(err, 1)
}

test_verify_one_file_with_options! {
    #[test] unwrap_params [] => verus_code! {
        fn test(Tracked(x): Tracked<&mut Ghost<int>>)
            requires *x == 0,
            ensures final(x)@ == old(x)@ + 3,
        {
            proof {
                *x = Ghost(3);
            }

            assert(*x == 3);
            assert(*old(x) == 0);
        }

        fn test_fail(Tracked(x): Tracked<&mut Ghost<int>>)
            requires *x == 0,
        {
            proof {
                *x = Ghost(3);
            }

            assert(*x == 3);
            assert(*old(x) == 0);
            assert(false); // FAILS
        }

        fn caller() {
            let mut x: Ghost<int> = Ghost(0);
            test(Tracked(&mut x));
            assert(x == 3);
        }

        fn caller_fail() {
            let mut x: Ghost<int> = Ghost(0);
            test(Tracked(&mut x));
            assert(x == 3);
            assert(false); // FAILS
        }

        fn caller_fail2() {
            let mut x: Ghost<int> = Ghost(1);
            test(Tracked(&mut x)); // FAILS
        }
    } => Err(err) => assert_fails(err, 3)
}

test_verify_one_file_with_options! {
    #[test] mutable_param_used_in_opens_invariants [] => verus_code! {
        use vstd::prelude::*;
        struct X { a: u64 }

        spec fn ns(x: X) -> int { x.a as int }

        fn foo() {
        }

        fn c0()
            opens_invariants [ 0int ]
        {
        }

        fn test1(x: &mut X)
            requires x.a == 0,
            opens_invariants [ ns(*x) ]
        {
            *x = X { a: 1 };
            c0();
        }
    } => Ok(())
}

test_verify_one_file_with_options! {
    #[test] mutable_param_used_in_opens_invariants2 [] => verus_code! {
        use vstd::prelude::*;
        struct X { a: u64 }

        spec fn ns(x: X) -> int { x.a as int }

        fn foo() {
        }

        fn c1()
            opens_invariants [ 1int ]
        {
        }

        fn test2(x: &mut X)
            requires x.a == 0,
            opens_invariants [ ns(*x) ]
        {
            *x = X { a: 1 };
            c1(); // FAILS
        }
    } => Err(err) => assert_fails(err, 1)
}

test_verify_one_file_with_options! {
    #[test] mutable_param_used_in_opens_invariants3 [] => verus_code! {
        use vstd::prelude::*;
        use vstd::invariant::*;

        struct Pred;
        impl<'a> InvariantPredicate<(), Ghost<u64>> for Pred {
            closed spec fn inv(k: (), v: Ghost<u64>) -> bool {
                5 <= v@ <= 13
            }
        }

        struct X { a: u64 }

        spec fn ns(x: X) -> int { x.a as int }

        fn foo() {
        }

        fn test1(x: &mut X, Tracked(p): Tracked<&LocalInvariant<(), Ghost<u64>, Pred>>)
            requires x.a == 0, p.namespace() == 0,
            opens_invariants [ ns(*x) ]
        {
            *x = X { a: 1 };
            open_local_invariant!(p => p2 => { });
        }

        fn test2(x: &mut X, Tracked(p): Tracked<&LocalInvariant<(), Ghost<u64>, Pred>>)
            requires x.a == 0, p.namespace() == 1,
            opens_invariants [ ns(*x) ]
        {
            *x = X { a: 1 };
            open_local_invariant!(p => p2 => { }); // FAILS
        }
    } => Err(err) => assert_fails(err, 1)
}

test_verify_one_file_with_options! {
    #[test] mutable_param_used_in_decreases [] => verus_code! {
        fn test(x: &mut u64)
            decreases *x
        {
            *x = 200;
            let mut a = 0;
            test(&mut a); // FAILS
        }
    } => Err(err) => assert_fails(err, 1)
}

test_verify_one_file_with_options! {
    #[test] mutable_param_used_in_returns [] => verus_code! {
        fn test_returns_fails(x: &mut u64) -> (ret: u64)
            requires *x < 100,
            returns *old(x)
        {
            let j = *x;
            *x += 1;
            return j + 1; // FAILS
        }

        fn test_returns(x: &mut u64) -> (ret: u64)
            requires *x < 100,
            returns *old(x)
        {
            let j = *x;
            *x += 1;
            return j;
        }
    } => Err(err) => assert_fails(err, 1)
}

test_verify_one_file_with_options! {
    #[test] mutable_param_used_in_unwind_spec [] => verus_code! {
        fn callee(b: bool)
            no_unwind when !b
        {
        }

        fn test1(x: &mut u64)
            no_unwind when *x != 0
        {
            callee(true); // FAILS
        }

        fn test2(x: &mut u64)
            no_unwind when *x != 0
        {
            *x = 0;
            callee(true); // FAILS
        }

        fn test3(x: &mut u64)
            requires *x == 0,
            no_unwind when *x != 0
        {
            *x = 1;
            callee(true);
        }
    } => Err(err) => assert_fails(err, 2)
}
