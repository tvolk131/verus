#![feature(rustc_private)]
#[macro_use]
mod common;
use common::*;

test_verify_one_file! {
    #[test] external_trait_supertrait_associated_type verus_code! {
        #[verifier::external]
        trait Build<A>: Sized {
            fn build(a: A) -> Self;
        }

        #[verifier::external_trait_specification]
        trait ExBuild<A>: Sized {
            type ExternalTraitSpecificationFor: Build<A>;
            fn build(a: A) -> Self;
        }

        #[verifier::external]
        trait T<A>: Build<Self::Item> {
            type Item;
            fn identity(a: Self::Item) -> Self::Item;
        }

        #[verifier::external_trait_specification]
        trait ExT<A>: Build<Self::Item> {
            type ExternalTraitSpecificationFor: T<A>;
            type Item;
            fn identity(a: Self::Item) -> (ret: Self::Item)
                ensures ret == a;
        }

        impl Build<u32> for u32 {
            fn build(a: u32) -> Self { a }
        }

        impl T<bool> for u32 {
            type Item = u32;
            fn identity(a: u32) -> u32 { a }
        }

        fn identity<A, I: T<A>>(a: I::Item) -> (ret: I::Item)
            ensures ret == a,
        {
            I::identity(a)
        }
    } => Ok(())
}

test_verify_one_file! {
    #[test] external_trait_supertrait_associated_type_mismatch verus_code! {
        #[verifier::external]
        trait Build<A>: Sized {}

        #[verifier::external_trait_specification]
        trait ExBuild<A>: Sized {
            type ExternalTraitSpecificationFor: Build<A>;
        }

        #[verifier::external]
        trait T: Build<Self::Item> {
            type Item;
            type Other;
        }

        #[verifier::external_trait_specification]
        trait ExT: Build<Self::Other> {
            type ExternalTraitSpecificationFor: T;
            type Item;
            type Other;
        }
    } => Err(err) => assert_vir_error_msg(err, "external_trait_specification trait bound mismatch")
}

test_verify_one_file! {
    #[test] external_trait_marker_name_collision verus_code! {
        #[verifier::external]
        trait T {
            type ExternalTraitSpecificationFor;
        }

        #[verifier::external_trait_specification]
        trait ExT {
            type ExternalTraitSpecificationFor: T;
        }

        #[verifier::external]
        trait SizedT: Sized {
            type ExternalTraitSpecificationFor;
        }

        #[verifier::external_trait_specification]
        trait ExSizedT: Sized {
            type ExternalTraitSpecificationFor: SizedT;
        }
    } => Ok(())
}

test_verify_one_file! {
    #[test] external_trait_custom_marker_name_collision verus_code! {
        #[verifier::external]
        trait Build<A>: Sized {}

        #[verifier::external_trait_specification]
        trait ExBuild<A>: Sized {
            type ExternalTraitSpecificationFor: Build<A>;
        }

        #[verifier::external]
        trait T: Build<Self::ExternalTraitSpecificationFor> {
            type Marker;
            type ExternalTraitSpecificationFor;
        }

        #[verifier::external_trait_specification(Marker)]
        trait ExT: Build<Self::ExternalTraitSpecificationFor> {
            type Marker: T;
            type ExternalTraitSpecificationFor;
        }
    } => Ok(())
}

test_verify_one_file! {
    #[test] test_trait verus_code! {
        trait Tr {
            fn foo();
            fn bar();
        }

        struct X { }

        #[verifier::external]
        impl Tr for X {
            fn foo() { }
            fn bar() { }
        }

        #[verifier::external_fn_specification]
        fn ex_foo() {
            X::foo()
        }
    } => Err(err) => assert_vir_error_msg(err, "using assume_specification for this function requires you to specify all other functions for the same trait impl, but the method `bar` is missing")
}

test_verify_one_file! {
    #[test] test_trait_provided_method_not_required verus_code! {
        #[verifier::external]
        trait Tr {
            fn foo(&self) -> usize;
            fn bar(&self) -> usize { 7 }
        }

        #[verifier::external_trait_specification]
        trait ExTr {
            type ExternalTraitSpecificationFor: Tr;

            fn foo(&self) -> (r: usize)
                ensures r > 3,
            ;

            fn bar(&self) -> (r: usize)
                ensures r > 5,
            ;
        }

        struct X { }

        #[verifier::external]
        impl Tr for X {
            fn foo(&self) -> usize { 4 }
        }

        assume_specification [<X as Tr>::foo](x: &X) -> (r: usize)
            ensures r > 3,
        ;

        fn test(x: &X) {
            let a = x.foo();
            assert(a > 3);
            // `bar` is inherited from the trait's default body, so the caller gets
            // the trait declaration's ensures.
            let b = x.bar();
            assert(b > 5);
        }
    } => Ok(())
}

test_verify_one_file! {
    #[test] test_trait_dupe verus_code! {
        trait Tr {
            fn foo();
            fn bar();
        }

        struct X { }

        #[verifier::external]
        impl Tr for X {
            fn foo() { }
            fn bar() { }
        }

        #[verifier::external_fn_specification]
        fn ex_foo() {
            X::foo()
        }

        #[verifier::external_fn_specification]
        fn ex_foo2() {
            X::foo()
        }

        #[verifier::external_fn_specification]
        fn ex_bar() {
            X::bar()
        }
    } => Err(err) => assert_vir_error_msg(err, "duplicate assume_specification for this method")
}

test_verify_one_file! {
    #[test] test_trait_dupe2 verus_code! {
        trait Tr {
            fn foo();
            fn bar();
        }

        struct X { }

        impl Tr for X {
            fn foo() { }
            fn bar() { }
        }

        #[verifier::external_fn_specification]
        fn ex_foo() {
            X::foo()
        }

        #[verifier::external_fn_specification]
        fn ex_bar() {
            X::bar()
        }
    } => Err(err) => assert_vir_error_msg(err, "duplicate specification for `test_crate::X::foo`")
}

test_verify_one_file! {
    #[test] test_trait_dupe_imported_trait verus_code! {
        use vstd::prelude::*;

        pub struct X;

        pub assume_specification[<X as core::convert::From<i16>>::from](value: i16) -> X;

        impl core::convert::From<i16> for X {
            fn from(_value: i16) -> X {
                X
            }
        }
    } => Err(err) => assert_vir_error_msg(err, "duplicate specification for `test_crate::X::from`")
}

test_verify_one_file! {
    #[test] test_trait_ok verus_code! {
        trait Tr {
            fn foo();
            fn bar();
        }

        struct X { }

        #[verifier::external]
        impl Tr for X {
            fn foo() { }
            fn bar() { }
        }

        #[verifier::external_fn_specification]
        fn ex_foo() {
            X::foo()
        }

        uninterp spec fn llama() -> bool;

        #[verifier::external_fn_specification]
        fn ex_bar()
            ensures llama(),
        {
            X::bar()
        }

        fn test() {
            X::bar();
            assert(llama());
        }
    } => Ok(())
}

test_verify_one_file! {
    #[test] test_trait_not_ext verus_code! {
        trait T {
        }
        #[verifier::external_trait_specification]
        trait Ex {
            type ExternalTraitSpecificationFor: T;
        }
    } => Err(err) => assert_vir_error_msg(err, "duplicate specification")
}

test_verify_one_file! {
    #[test] test_trait_dup verus_code! {
        #[verifier::external]
        trait T {
            fn f();
        }
        #[verifier::external_trait_specification]
        trait Ex1 {
            type ExternalTraitSpecificationFor: T;
            fn f();
        }
        #[verifier::external_trait_specification]
        trait Ex2 {
            type ExternalTraitSpecificationFor: T;
            fn f();
        }
    } => Err(err) => assert_vir_error_msg(err, "duplicate specification for `test_crate::T::f`")
}

test_verify_one_file! {
    #[test] test_trait_body verus_code! {
        #[verifier::external]
        trait T {
            fn f() {}
        }
        #[verifier::external_trait_specification]
        trait Ex {
            type ExternalTraitSpecificationFor: T;
            fn f() {}
        }
    } => Err(err) => assert_vir_error_msg(err, "`external_trait_specification` functions cannot have bodies")
}

test_verify_one_file! {
    #[test] test_trait_no_assoc verus_code! {
        #[verifier::external]
        trait T {
            fn f() {}
        }
        #[verifier::external_trait_specification]
        trait Ex {
            fn f() {}
        }
    } => Err(err) => assert_vir_error_msg(err, "trait must declare a type ExternalTraitSpecificationFor")
}

test_verify_one_file! {
    #[test] test_trait_different_generics1 verus_code! {
        #[verifier::external]
        trait T<A, B> {
        }
        #[verifier::external_trait_specification]
        trait Ex<A, B> {
            type ExternalTraitSpecificationFor: T<B, A>;
        }
    } => Err(err) => assert_vir_error_msg(err, "expected generics to match")
}

test_verify_one_file! {
    #[test] test_trait_different_generics2 verus_code! {
        #[verifier::external]
        trait T<A> {
        }
        #[verifier::external_trait_specification]
        trait Ex<A: Copy> {
            type ExternalTraitSpecificationFor: T<A>;
        }
    } => Err(err) => assert_vir_error_msg(err, "external_trait_specification trait bound mismatch")
}

test_verify_one_file! {
    #[test] test_trait1 verus_code! {
        #[verifier::external]
        trait T {
            fn f(&self, q: &Self, b: bool) -> usize;
            type X;
        }
        #[verifier::external_trait_specification]
        trait Ex {
            type ExternalTraitSpecificationFor: T;
            fn f(&self, q: &Self, b: bool) -> (r: usize)
                requires b
                ensures r > 7
                ;
            type X;
        }
        fn test<A: T>(a: &A) {
            let i = a.f(a, true);
            assert(i > 7);
            let i = a.f(a, false); // FAILS
        }
    } => Err(e) => assert_one_fails(e)
}

test_verify_one_file! {
    #[test] test_trait2 verus_code! {
        #[verifier::external]
        trait T {
            fn f(&self, q: &Self, b: bool) -> usize;
            type X;
        }
        #[verifier::external_trait_specification(ExternalTraitSpecificationForAlt)]
        trait Ex {
            type ExternalTraitSpecificationForAlt: T;
            fn f(&self, q: &Self, b: bool) -> (r: usize)
                requires b
                ensures r > 7
                ;
            type X;
        }
        fn test<A: T>(a: &A) {
            let i = a.f(a, true);
            assert(i > 7);
            let i = a.f(a, false); // FAILS
        }
    } => Err(e) => assert_one_fails(e)
}

test_verify_one_file! {
    #[test] test_trait3 verus_code! {
        #[verifier::external]
        trait T {
            fn f(&self, q: &Self, b: bool) -> usize;
            type X;
        }
        #[verifier::external_trait_specification]
        trait Ex {
            type ExternalTraitSpecificationFor: T;
            fn f(&self, q: &Self, b: bool) -> (r: usize)
                requires b
                ensures r > 7 // TRAIT
                ;
            type X;
        }
        impl T for u8 {
            fn f(&self, q: &Self, b: bool) -> (r: usize) {
                assert(b);
                8
            }
            type X = u16;
        }
        impl T for u32 {
            fn f(&self, q: &Self, b: bool) -> (r: usize) {
                assert(b);
                6 // FAILS
            }
            type X = u16;
        }
    } => Err(e) => assert_one_fails(e)
}

test_verify_one_file_with_options! {
    #[test] test_trait4 ["--disable-internal-test-mode"] => verus_code! {
        #[verifier::external_type_specification]
        #[verifier::external_body]
        #[verifier::reject_recursive_types_in_ground_variants(I)]
        pub struct ExPeekable<I: Iterator>(core::iter::Peekable<I>);

        #[verifier::external_trait_specification]
        pub trait ExIterator1 {
            type ExternalTraitSpecificationFor: core::iter::Iterator;
            type Item;
            // count already has a vstd model; use another method for split specs.
            fn last(self) -> Option<Self::Item> where Self: Sized;
            #[verifier::impls_cannot_extend_spec]
            fn cmp<I>(self, other: I) -> core::cmp::Ordering where Self: core::iter::Iterator, I: core::iter::IntoIterator<Item = <Self as core::iter::Iterator>::Item>, <Self as core::iter::Iterator>::Item: Ord, Self: Sized;
        }

        #[verifier::external_trait_specification]
        pub trait ExIterator2 {
            type ExternalTraitSpecificationFor: core::iter::Iterator;
            type Item;
            fn peekable(self) -> core::iter::Peekable<Self> where Self: Sized, Self: core::iter::Iterator requires false;
        }

        fn test2<A: Iterator>(a: A) {
            let x = a.last();
        }

        fn test3<A: Iterator>(a: A) {
            let y = a.peekable(); // FAILS
        }
    } => Err(e) => assert_one_fails(e)
}

test_verify_one_file! {
    #[test] test_trait5 verus_code! {
        #[verifier::external]
        trait T {
            type X;
            fn f() -> Self::X;
        }

        #[verifier::external_trait_specification]
        trait ExT {
            type ExternalTraitSpecificationFor: T;
            type X;

            fn f() -> Self::X;
        }
    } => Ok(())
}

test_verify_one_file! {
    #[test] test_trait_extension verus_code! {
        #[verifier::external]
        trait T<A> {
            type X;
            fn f(&self, q: &Self, a: A, b: bool, x: Self::X) -> usize;
        }

        #[verifier::external_trait_specification]
        #[verifier::external_trait_extension(TSpec via TSpecImpl)]
        trait Ex<A> {
            type ExternalTraitSpecificationFor: T<A>;
            type X;
            fn f(&self, q: &Self, a: A, b: bool, x: Self::X) -> (r: usize)
                requires b, self.s(q, a, b, x)
                ensures r > 7
                ;
            spec fn s(&self, q: &Self, a: A, b: bool, x: Self::X) -> bool;
        }


        impl T<u8> for u32 {
            type X = u16;
            fn f(&self, q: &Self, a: u8, b: bool, x: u16) -> (r: usize) {
                10
            }
        }

        impl TSpecImpl<u8> for u32 {
            spec fn s(&self, q: &Self, a: u8, b: bool, x: u16) -> bool {
                a == x
            }
        }

        proof fn test(u: u32) {
            assert(TSpec::s(&u, &u, 6, true, 6));
            assert(TSpec::s(&u, &u, 6, true, 7)); // FAILS
        }

        fn test2(u: u32) {
            u.f(&u, 6, true, 6);
            u.f(&u, 6, true, 7); // FAILS
        }
    } => Err(err) => assert_fails(err, 2)
}

test_verify_one_file! {
    #[test] test_trait_extension_vstd verus_code! {
        use vstd::std_specs::cmp::PartialEqSpec;
        broadcast proof fn axiom_spec_eq_u8(x: u8, y: u8)
            ensures
                #[trigger] x.eq_spec(&y) <==> x == y,
        {
            admit();
        }
        fn test(u: u8, v: u8) {
            broadcast use axiom_spec_eq_u8;
            assert(u.eq_spec(&u));
            assert(u.eq_spec(&v)); // FAILS
        }
    } => Err(e) => assert_one_fails(e)
}

test_verify_one_file! {
    #[test] test_trait_extension_default_method_context_order verus_code! {
        use vstd::prelude::*;
        use vstd::std_specs::convert::*;

        pub struct Foo;

        impl From<Foo> for u16 {
            #[verifier::spinoff_prover]
            fn from(value: Foo) -> Self {
                42u16
            }
        }

        impl FromSpecImpl<Foo> for u16 {
            open spec fn obeys_from_spec() -> bool {
                true
            }

            open spec fn from_spec(value: Foo) -> u16 {
                42u16
            }
        }

        pub trait Bar {
            fn push_record() {
                let f = <u16 as From<Foo>>::from(Foo);
                assert(f == 42);
            }
        }

        impl Bar for Foo {}
    } => Ok(())
}

test_verify_one_file! {
    #[test] test_trait_extension_default_method_body_context_order verus_code! {
        #[verifier::external]
        pub trait T {}

        #[verifier::external_trait_specification]
        #[verifier::external_trait_extension(TSpec via TSpecImpl)]
        pub trait ExT {
            type ExternalTraitSpecificationFor: T;

            spec fn s() -> u8;
        }

        pub struct Foo;

        impl T for Foo {}

        impl TSpecImpl for Foo {
            open spec fn s() -> u8 {
                42
            }
        }

        trait Bar {
            fn check() {
                assert(<Foo as TSpec>::s() == 42);
            }
        }

        impl Bar for Foo {}
    } => Ok(())
}

test_verify_one_file! {
    #[test] test_trait_extension_cycle verus_code! {
        #[verifier::external]
        trait T<A> {
            type X;
            fn f(&self, q: &Self, a: A, b: bool, x: Self::X) -> usize;
        }

        #[verifier::external_trait_specification]
        #[verifier::external_trait_extension(TSpec via TSpecImpl)]
        trait Ex<A> {
            type ExternalTraitSpecificationFor: T<A>;
            type X;
            fn f(&self, q: &Self, a: A, b: bool, x: Self::X) -> (r: usize)
                requires b, self.s(q, a, b, x)
                ensures r > 7
                ;
            spec fn s(&self, q: &Self, a: A, b: bool, x: Self::X) -> bool;
        }

        impl T<u8> for u32 {
            type X = u16;
            fn f(&self, q: &Self, a: u8, b: bool, x: u16) -> (r: usize) {
                10
            }
        }

        impl TSpecImpl<u8> for u32 {
            spec fn s(&self, q: &Self, a: u8, b: bool, x: u16) -> bool {
                !TSpec::<u8>::s(self, q, a, b, x)
            }
        }
    } => Err(err) => assert_vir_error_msg(err, "recursive function must have a decreases clause")
}

test_verify_one_file! {
    #[test] test_trait_extension_cycle2 verus_code! {
        #[verifier::external]
        trait T<A> {
            type X;
            fn f(&self, q: &Self, a: A, b: bool, x: Self::X) -> usize;
        }

        #[verifier::external_trait_specification]
        #[verifier::external_trait_extension(TSpec via TSpecImpl)]
        trait Ex<A> {
            type ExternalTraitSpecificationFor: T<A>;
            type X;
            fn f(&self, q: &Self, a: A, b: bool, x: Self::X) -> (r: usize)
                ensures self.s(q, a, b, x)
                ;
            spec fn s(&self, q: &Self, a: A, b: bool, x: Self::X) -> bool;
        }

        impl T<u8> for u32 {
            type X = u16;
            fn f(&self, q: &Self, a: u8, b: bool, x: u16) -> (r: usize) {
                10
            }
        }

        impl TSpecImpl<u8> for u32 {
            spec fn s(&self, q: &Self, a: u8, b: bool, x: u16) -> bool {
                !call_ensures(Self::f, (self, q, a, b, x), 10)
            }
        }
    } => Err(err) => assert_vir_error_msg(err, "found a cyclic self-reference")
}

test_verify_one_file! {
    #[test] test_trait_extension_cycle3 verus_code! {
        #[verifier::external]
        trait T {}

        #[verifier::external_trait_specification]
        #[verifier::external_trait_extension(TSpec via TSpecImpl)]
        trait Ex {
        type ExternalTraitSpecificationFor: T;
            spec fn s1() -> bool;
            spec fn s2() -> bool;
        }

        impl T for u32 {
        }

        impl TSpecImpl for u32 {
            spec fn s1() -> bool { <u32 as TSpec>::s2() }
            spec fn s2() -> bool { !<u32 as TSpec>::s1() }
        }
    } => Err(err) => assert_vir_error_msg(err, "recursive function must have a decreases clause")
}

test_verify_one_file! {
    #[test] test_trait_extension_mismatch verus_code! {
        #[verifier::external]
        trait T<A> {
            type X;
            fn f(&self, q: &Self, a: A, b: bool, x: Self::X) -> usize;
        }

        #[verifier::external_trait_specification]
        #[verifier::external_trait_extension(TSpec via TSpecImpl)]
        trait Ex<A> {
            type ExternalTraitSpecificationFor: T<A>;
            type X;
            fn f(&self, q: &Self, a: A, b: bool, x: Self::X) -> (r: usize)
                requires b, self.s(q, a, b, x)
                ensures r > 7
                ;
            spec fn s(&self, q: &Self, a: A, b: bool, x: Self::X) -> bool;
        }

        impl<A> T<A> for u32 {
            type X = u16;
            fn f(&self, q: &Self, a: A, b: bool, x: u16) -> (r: usize) {
                10
            }
        }

        impl TSpecImpl<u8> for u32 {
            spec fn s(&self, q: &Self, a: u8, b: bool, x: u16) -> bool {
                true
            }
        }
    } => Err(err) => assert_vir_error_msg(err, "TSpec must have a matching impl")
}

test_verify_one_file! {
    #[test] test_trait_extension_trait_impl_axioms verus_code! {
        #[verifier::external]
        trait T {}
        #[verifier::external]
        impl T for u32 {}

        #[verifier::external_trait_specification]
        #[verifier::external_trait_extension(TSpec via TSpecImpl)]
        trait Ex {
            type ExternalTraitSpecificationFor: T;
        }
        impl TSpecImpl for u32 {
        }

        uninterp spec fn f<A>(x: A) -> bool;

        broadcast proof fn p<A: TSpec>(x: A)
            ensures #[trigger] f(x)
        {
            admit();
        }

        proof fn test1() {
            assert(f(5u32)); // FAILS
        }

        proof fn test2() {
            broadcast use p;
            assert(f(5u32));
        }
    } => Err(e) => assert_one_fails(e)
}

test_verify_one_file! {
    #[test] test_trait_extension_blanket_impl verus_code! {
        #[verifier::external]
        trait T {}
        #[verifier::external]
        impl T for u32 {}

        #[verifier::external_trait_specification]
        #[verifier::external_trait_extension(TSpec via TSpecImpl)]
        trait Ex {
            type ExternalTraitSpecificationFor: T;
        }
        impl TSpecImpl for u32 {
        }

        uninterp spec fn f<A: T>(a: A) -> bool;

        broadcast proof fn b1<A: TSpec>(a: A)
            ensures
                #[trigger] f(a),
        {
            admit();
        }

        broadcast proof fn b2<A: T>(a: A)
            ensures
                #[trigger] f(a),
        {
            // Rust accepts this because of the blanket implementation for TSpec:
            b1(a);
        }

        proof fn call1<A: T>(a: A) {
            // Rust accepts this because of the blanket implementation for TSpec:
            b1::<A>(a);
            assert(f(a));
        }

        proof fn call2<A: T>(a: A) {
            b2::<A>(a);
            assert(f(a));
        }

        proof fn use1<A: T>(a: A) {
            broadcast use b1;
            // Verus emits axiom for blanket implementation for TSpec, allowing this to work:
            assert(f(a));
        }

        proof fn use2<A: T>(a: A) {
            broadcast use b2;
            assert(f(a));
        }
    } => Ok(())
}

test_verify_one_file! {
    #[test] test_trait_auto_import verus_code! {
        #[verifier::external]
        trait T {}

        #[verifier::external]
        impl T for bool {}

        #[verifier::external_trait_specification]
        trait ExT {
            type ExternalTraitSpecificationFor: T;
        }

        trait U {
            type X: T;
        }

        impl U for u8 {
            type X = S;
        }

        impl U for u16 {
            type X = [S; 3];
        }

        struct S;

        #[verifier::external]
        impl T for S where bool: T {}

        #[verifier::external]
        impl<A: T, const N: usize> T for [A; N] {
        }
    } => Ok(())
}

test_verify_one_file! {
    #[test] test_trait_auto_import_special_types verus_code! {
        #[verifier::external]
        trait T<A> {}

        #[verifier::external]
        impl<A> T<A> for A {}

        #[verifier::external]
        impl<A> T<A> for Ghost<A> {}

        #[verifier::external_trait_specification]
        #[verifier::external_trait_extension(TSpec via TSpecImpl)]
        trait ExT<A> {
            type ExternalTraitSpecificationFor: T<A>;

            spec fn s(&self) -> bool;
        }

        impl<A> TSpecImpl<A> for A {
            spec fn s(&self) -> bool {
                false
            }
        }

        impl<A> TSpecImpl<A> for Ghost<A> {
            spec fn s(&self) -> bool {
                false
            }
        }
    } => Ok(())
}

test_verify_one_file! {
    #[test] test_trait_defaults verus_code! {
        #[verifier::external]
        trait T {
            fn d(u: u32) -> u32 { u }
            fn f(u: u32) -> u32;
        }

        #[verifier::external]
        impl T for bool {
            fn f(u: u32) -> u32 { u }
        }

        #[verifier::external_trait_specification]
        trait ExT {
            type ExternalTraitSpecificationFor: T;
            fn d(u: u32) -> (r: u32) requires u >= 100;
            fn f(u: u32) -> (r: u32) requires u >= 100;
        }
        impl T for u8 {
            fn f(u: u32) -> u32 { u }
        }
        fn test() {
            <bool as T>::d(100);
            <u8 as T>::d(99); // FAILS
        }
    } => Err(e) => assert_one_fails(e)
}

test_verify_one_file! {
    #[test] test_trait_default_external_body_issue1307 verus_code! {
        #[verifier::external]
        fn some_external_fn() { }

        trait T {
            #[verifier(external_body)]
            fn f1() -> (ret: bool)
                ensures
                    !ret
            {
                some_external_fn();
                false
            }

            fn f2() -> bool {
                Self::f1()
            }
        }

        struct S;

        impl T for S { }
    } => Ok(())
}

test_verify_one_file! {
    #[test] test_external_trait_impl_issue1627 verus_code! {
        use vstd::*;

        pub struct Foo {
            pub vals: Vec<u32>
        }

        fn main() {}

        #[verifier::external]
        impl IntoIterator for Foo {
            type Item = u32;

            type IntoIter = std::vec::IntoIter<u32>;

            fn into_iter(self) -> Self::IntoIter {
                self.vals.into_iter()
            }
        }

    } => Ok(())
}

test_verify_one_file! {
    #[test] test_external_trait_impl_issue2047 verus_code! {
        use vstd::prelude::*;

        #[verifier::external]
        trait T {
        }

        #[verifier::external_trait_specification]
        #[verifier::external_trait_extension(TSpec via TSpecImpl)]
        trait Ex {
            type ExternalTraitSpecificationFor: T;

            spec fn seq(&self) -> Seq<bool>;

            spec fn initial_value_relation(&self) -> bool;
        }

        impl T for bool {
        }

        impl TSpecImpl for bool {
            closed spec fn seq(&self) -> Seq<bool> {
                seq![true]
            }

            spec fn initial_value_relation(&self) -> bool {
                TSpec::seq(self).len() > 1
            }
        }
    } => Ok(())
}

test_verify_one_file! {
    #[test] test_impl_trait_direct_use_error verus_code! {
        #[verifier::external]
        trait T1 {}

        #[verifier::external]
        impl T1 for u8 {}

        #[verifier::external_trait_specification]
        #[verifier::external_trait_extension(T1Spec via T1SpecImpl)]
        trait ExT1 {
            type ExternalTraitSpecificationFor: T1;

            spec fn f() -> bool;
        }

        impl T1SpecImpl for u8 {
            spec fn f() -> bool { true }
        }

        spec fn g() -> bool {
            <u8 as T1SpecImpl>::f() // should error: cannot use T1SpecImpl directly
        }
    } => Err(err) => assert_vir_error_msg(
        err,
        "cannot use trait `test_crate::T1SpecImpl` directly; use `test_crate::T1Spec` instead"
    )
}

test_verify_one_file! {
    #[test] test_assoc_type_with_trait_bound verus_code! {
        // Test that external_trait_specification works for traits with
        // associated types that have trait bounds (ClauseKind::Projection)
        // and lifetime bounds (ClauseKind::TypeOutlives).
        #[verifier::external]
        trait Bits: Sized + 'static {
        }

        #[verifier::external_trait_specification]
        trait ExBits: Sized + 'static {
            type ExternalTraitSpecificationFor: Bits;
        }

        #[verifier::external]
        trait Flags: Sized + 'static {
            type B: Bits;
        }

        #[verifier::external_trait_specification]
        trait ExFlags: Sized + 'static {
            type ExternalTraitSpecificationFor: Flags;
            type B: Bits;
        }
    } => Ok(())
}

test_verify_one_file! {
    #[test] unrecognized_assoc_type_issue1485 verus_code! {
        use std::borrow::Cow;

        #[verifier::external_trait_specification]
        pub trait ExToOwned {
            type ExternalTraitSpecificationFor: ToOwned;
        }

        #[verifier::external_type_specification]
        #[verifier::reject_recursive_types(B)]
        pub struct ExCow<'a, B: 'a + ?Sized + ToOwned>(Cow<'a, B>);

        fn test() { }
    } => Err(err) => assert_vir_error_msg(
        err,
        "Verus does not recognize associated type `Owned` of trait `alloc::borrow::ToOwned`"
    )
}

test_verify_one_file! {
    #[test] external_trait_private_bound_local verus_code! {
        trait U {}

        #[verifier::external]
        trait T: U {}

        #[verifier::external_trait_specification]
        #[verifier::external_trait_private_bound(test_crate::U)]
        trait ExT {
            type ExternalTraitSpecificationFor: T;
        }
    } => Err(err) => assert_vir_error_msg(err, "not a private non-local bound")
}

test_verify_one_file! {
    #[test] external_trait_private_bound_pub verus_code! {
        #[verifier::external_trait_specification]
        #[verifier::external_trait_private_bound(core::marker::Copy)]
        pub trait ExInteger {
            type ExternalTraitSpecificationFor: Integer;
        }
    } => Err(err) => assert_vir_error_msg(err, "not a private non-local bound")
}

test_verify_one_file! {
    // Regression test: an associated type fixed only by a where-clause bound
    // normalizes to a bare inference variable, which used to trip an
    // `assert!(!matches!(t.kind(), TyKind::Infer(..)))` in rust_to_vir_base
    // and panic the verifier. The program is rejected either way -- the point
    // is that it is rejected with a diagnostic rather than an ICE.
    #[test] external_trait_extension_projection_normalizes_to_infer verus_code! {
        use vstd::prelude::*;

        #[verifier::external]
        pub trait Src { type Item; }

        #[verifier::external]
        pub struct Adapt<I>(I);

        #[verifier::external]
        impl<'a, I, X: 'a> Src for Adapt<I>
            where I: Src<Item = &'a X>, X: Copy,
        {
            type Item = X;
        }

        #[verifier::external_trait_specification]
        #[verifier::external_trait_extension(SrcSpec via SrcSpecImpl)]
        pub trait ExSrc {
            type ExternalTraitSpecificationFor: Src;
            type Item;
            spec fn items(&self) -> Seq<Self::Item>;
        }

        #[verifier::external_body]
        #[verifier::external_type_specification]
        #[verifier::reject_recursive_types(I)]
        pub struct ExAdapt<I>(Adapt<I>);

        impl<'a, I, X: 'a> SrcSpecImpl for Adapt<I>
            where I: Src<Item = &'a X> + SrcSpec, X: Copy,
        {
            closed spec fn items(&self) -> Seq<Self::Item> { Seq::empty() }
        }
    } => Err(err) => assert_rust_error_msg(err, "overflow evaluating the requirement")
}
