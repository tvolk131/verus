#![feature(rustc_private)]
#[macro_use]
mod common;
use common::*;

test_verify_one_file! {
    #[test] test_array_set_assign_op verus_code! {
        use vstd::prelude::*;
        use vstd::array::*;

        fn test(ar: &mut [usize; 20])
        requires
            old(ar)[0] == 1,
            old(ar)[2] == 2,
        ensures
            final(ar)[0] == 2,
            final(ar)[2] == 3,
        {
            ar[0] += 1;
            ar[ar[0]] += 1;
        }

    } => Ok(())
}

test_verify_one_file! {
    #[test] test_array_set_assign_op_with_idx_side_effect verus_code! {
        use vstd::prelude::*;
        use vstd::array::*;
        fn potential_side_effect(i: &mut usize) -> (ret: usize)
        requires
            *old(i) < 10,
        ensures
            ret == *old(i),
            *final(i) == *old(i) + 1,
        {
            let oldi = *i;
            *i = *i + 1;
            oldi
        }

        fn test(ar: &mut [usize; 20])
        requires
            old(ar)[0] < 10,
        ensures
            final(ar)[0] == old(ar)[0] + 1,
            final(ar)[1] == 1,
        {
            let mut i = 0usize;
            ar[potential_side_effect(&mut i)] += 1;
            ar[potential_side_effect(&mut i)] = 1;
            assert(i == 2);
        }
    } => Ok(())
}

test_verify_one_file! {
    #[test] test_array_set_assign_customized_op verus_code! {
        use vstd::prelude::*;
        use vstd::array::*;
        use vstd::std_specs::ops::AddAssignSpec;

        #[derive(Clone, Copy)]
        struct A(u8);

        impl core::ops::AddAssign<u8> for A {
            #[verifier::external_body]
            fn add_assign(&mut self, rhs: u8) {
            }
        }

        fn test(ar: &mut [A; 20])
        {
            assume(ar[0].add_assign_req(1));
            ar[0] += 1;
        }

    } => Ok(())
}

test_verify_one_file! {
    #[test] test_array_clone verus_code! {
        use vstd::prelude::*;

        fn test() {
            let a = [0u8; 16];
            let _b = a.clone();
        }
    } => Ok(())
}

test_verify_one_file! {
    #[test] test_array_set verus_code! {
        use vstd::prelude::*;
        use vstd::array::*;

        fn test(ar: &mut [u8; 20])
        ensures
            final(ar)[0] == 1,
        {
            ar[0] = 1;
        }

        fn test2()
        {
            let mut ar2 = [0u8; 20];
            ar2[21] = 1; // FAILS
        }
    } => Err(e) => assert_one_fails(e)
}

test_verify_one_file! {
    #[test] test_array_set_wrong_type verus_code! {
        use vstd::prelude::*;
        use vstd::array::*;

        fn test(ar: &mut [u8; 20])
        ensures
            ar[0] == 1,
        {
            ar[0] = 1u64;
        }
    } => Err(e) => assert_rust_error_msg(e, "mismatched types")
}

test_verify_one_file! {
    #[test] test1 verus_code! {
        use vstd::prelude::*;
        use vstd::array::*;

        fn test(ar: [u8; 20])
            requires ar[1] == 19
        {
            let x = array_index_get(&ar, 1);
            assert(x == 19);
        }

        fn test2(ar: [u8; 20]) {
            let y = array_index_get(&ar, 20); // FAILS
        }

        fn test3(ar: [u8; 20]) {
            assert(ar@.len() == 20);
        }

        fn test4(ar: [u8; 20]) {
            assert(ar@.len() == 21); // FAILS
        }

        fn test5<const N: usize>(ar: [u8; N]) {
            assert(ar@.len() == N);
        }

        fn test6(ar: [u8; 20]) {
            let mut ar = ar;
            ar[7] = 50;
            assert(ar[7] == 50);
        }

        fn test7(ar: [u8; 20])
            requires ar[1] == 19
        {
            let x = ar[1];
            assert(x == 19);
        }

        fn test8(ar: [u8; 20]) {
            let y = ar[20]; // FAILS
        }

        struct S {
            ar: [usize; 4],
        }

        fn test9(s: &mut S) {
            let mut ar = s.ar;
            ar[0] = 42;
            assert(ar[0] == 42);
        }

        fn test10() {
            let mut ar = [0, 0];
            assert(ar[0] == 0);
            ar[0] = 42;
            assert(ar[0] == 42);
            assert(ar[1] == 0);
        }

    } => Err(err) => assert_fails(err, 3)
}

test_verify_one_file! {
    #[test] test_recursion_checks_1 verus_code! {
        use vstd::array::*;
        use vstd::imap::*;

        struct Foo {
            field: [ IMap<Foo, int> ; 20 ],
        }

    } => Err(err) => assert_vir_error_msg(err, "non-positive position")
}

test_verify_one_file! {
    #[test] test_recursion_checks_2 verus_code! {
        use vstd::array::*;

        struct Foo {
            field: Box<[ Foo ; 1 ]>,
        }

    } => Err(err) => assert_vir_error_msg(err, "datatype must have at least one non-recursive variant")
}

test_verify_one_file! {
    #[test] test_recursive_array_no_ground_variant verus_code! {
        use vstd::prelude::*;

        struct S { a: [Box<S>; 1] }

        proof fn descend(s: S)
            ensures false
            decreases s
        {
            descend(*s.a@[0]);
        }

        proof fn bad() ensures false {
            descend(arbitrary());
        }
    } => Err(err) => assert_vir_error_msg(err, "datatype must have at least one non-recursive variant")
}

test_verify_one_file! {
    #[test] test_recursive_array_no_ground_variant_generic verus_code! {
        use vstd::prelude::*;

        struct S<const N: usize> { a: [Box<S<N>>; N] }
    } => Err(err) => assert_vir_error_msg(err, "datatype must have at least one non-recursive variant")
}

test_verify_one_file! {
    #[test] test_recursive_array_ground_variants verus_code! {
        use vstd::prelude::*;

        struct Empty { a: [Box<Empty>; 0] }

        fn make_empty() -> Empty {
            Empty { a: [] }
        }

        enum Tree<const N: usize> {
            Leaf,
            Branch([Box<Tree<N>>; N]),
        }

        proof fn test_decreases(t: Tree<1>) {
            match t {
                Tree::Leaf => {},
                Tree::Branch(children) => {
                    assert(decreases_to!(t => children@[0]));
                },
            }
        }
    } => Ok(())
}

test_verify_one_file! {
    #[test] test_array_literals verus_code! {
        use vstd::prelude::*;

        fn test1() {
            let x: [u8; 6] = [11, 12, 13, 14, 15, 16];
            assert(x.view().len() == 6);
            assert(x.view()[0] == 11);
            assert(x.view()[1] == 12);
            assert(x.view()[2] == 13);
            assert(x.view()[3] == 14);
            assert(x.view()[4] == 15);
            assert(x.view()[5] == 16);
        }

        fn test2<T>(a: T, b: T, c: T) {
            let x: [T; 3] = [a, b, c];
            assert(x.view().len() == 3);
            assert(x.view()[0] == a);
            assert(x.view()[1] == b);
            assert(x.view()[2] == c);
        }

        fn test3() {
            let x: [u8; 6] = [11, 12, 13, 14, 15, 16];
            assert(x.view().len() == 6);
            assert(x.view()[0] == 12); // FAILS
        }

        fn test4() {
            let a1: [u8; 3] = [10, 20, 30];
            let a2: [u8; 3] = [10, 20, 40];
            assert(a1 != a2);
            assert(a1@ != a2@);
            assert(a1@.contains(30));
            assert(a2@.contains(30)); // FAILS
        }

        proof fn test5() {
            let s1: Seq<int> = [10, 20, 30]@;
            let s2: Seq<int> = [10, 20, 40]@;
            assert(s1 != s2);
            assert(s1 == s2); // FAILS
        }

        proof fn test6() {
            let s: Seq<int> = [10, 20, 30]@;
            assert(s.contains(30));
            assert(s.contains(40)); // FAILS
        }
    } => Err(err) => assert_fails(err, 4)
}

test_verify_one_file! {
    #[test] test_array_literals_lifetime verus_code! {
        fn test2<T>(a: T, b: T) {
            let x: [T; 3] = [a, b, b];
        }
    } => Err(err) => assert_rust_error_msg(err, "use of moved value: `b`")
}

test_verify_one_file! {
    #[test] test_array_literals_spec_fn_supported_1 verus_code! {
        spec fn test() -> [u64; 3] {
            [3, 4, 5]
        }
    } => Ok(())
}

test_verify_one_file! {
    #[test] test_array_literals_spec_fn_unsupported_2 verus_code! {
        use vstd::array::*;
        exec fn test() {
            let ghost a = [3u64, 4, 5];
            assert(a[1] == 4);
        }
    } => Ok(())
}

test_verify_one_file! {
    #[test] test_array_index_generic verus_code! {
        use vstd::prelude::*;

        proof fn test<A, const N: usize>(a: [A; N], i: int)
            requires 0 <= i < N
        {
            use vstd::array::array_view;
            assert(a@[i] == array_index(a, i));
        }
    } => Ok(())
}

test_verify_one_file! {
    #[test] test_array_repeat verus_code! {
        use vstd::prelude::*;

        fn test1() {
            let x: [u8; 6] = [11; 6];
            assert(x.view().len() == 6);
            assert(x.view()[0] == 11);
            assert(x.view()[1] == 11);
            assert(x.view()[2] == 11);
            assert(x.view()[3] == 11);
            assert(x.view()[4] == 11);
            assert(x.view()[5] == 11);
        }

        fn test2<T: Copy>(a: T) {
            let x: [T; 3] = [a; 3];
            assert(x.view().len() == 3);
            assert(x.view()[0] == a);
            assert(x.view()[1] == a);
            assert(x.view()[2] == a);
        }

        fn test3<T: Copy, const N: usize>(a: T, i: usize) {
            let x: [T; N] = [a; N];
            assert(x.view().len() == N);

            assume(0 <= i < N);
            assert(x.view()[i as int] == a);
        }

        proof fn test4<T: Copy, const N: usize>(a: T, i: usize) {
            let x: [T; N] = [a; N];
            assert(x.view().len() == N);

            assume(0 <= i < N);
            assert(x.view()[i as int] == a);
        }

        fn test5() {
            let x: [u8; 6] = [11; 6];
            assert(x.view().len() == 7); // FAILS
        }
    } => Err(err) => assert_fails(err, 1)
}

test_verify_one_file! {
    // https://github.com/verus-lang/verus/issues/1236
    #[test] test_array_type_id verus_code! {
        use vstd::prelude::*;
        struct X;
        fn test2<'a>(p: &'a Option<[X; 75]>) -> (res: &'a [X; 75])
            requires
                p.is_some()
            ensures
                Some(*res) == p
        {
            p.as_ref().unwrap()
        }
    } => Ok(())
}

test_verify_one_file! {
    #[test] test_array_repeat_tracked verus_code! {
        tracked struct X { }

        proof fn array_repeat_tracked<const N: usize>(tracked x: X) {
            let tracked ar = [x; N];
        }
    } => Err(err) => assert_rust_error_msg(err, "the trait bound `X: std::marker::Copy` is not satisfied")
}

test_verify_one_file! {
    #[test] test_array_repeat_tracked_copy verus_code! {
        use vstd::*;
        proof fn array_repeat_tracked<T: Copy, const N: usize>(tracked x: T) {
            let tracked ar = [x; N];
        }
    } => Err(err) => assert_vir_error_msg(err, "expression has mode spec, expected mode proof")
}

test_verify_one_file! {
    #[test] test_array_repeat_non_copy_const verus_code! {
        use vstd::prelude::*;

        struct X { u: u8 }

        const fn some_x() -> X { X { u: 0 } }

        exec const C: X = some_x();

        fn stuff() {
            // This is currently unsupported, but if it were supported,
            // this would need to fail because X is not marked Copy.
            // (Imagine if X were a cell type or something like that, whose representation
            // is some ghost 'cell ID'. The cell ID would change every time the constant
            // is used.)
            let ar = [C; 13];
            assert(ar@[0] == ar@[1]); // FAILS
        }
    } => Err(err) => assert_vir_error_msg(err, "The verifier does not yet support the following Rust feature: array-fill expresion with non-copy type")
}

test_verify_one_file! {
    #[test] test_array_to_slice verus_code! {
        use vstd::prelude::*;

        fn test1(ar: &[u8; 3]) {
            let sl: &[u8] = ar;
            assert(sl@.len() == 3);
        }

        fn test2() {
            let ar = [4, 5, 6];
            let sl: &[u8] = &ar;
            assert(sl@.len() == 3);
            assert(sl@[1] == 5);
        }

        fn test3<const N: usize>(ar: &[u8; N]) {
            let sl: &[u8] = ar;
            assert(sl@.len() == N);
        }

        spec fn len_of_slice(ar: &[u8]) -> int {
            ar@.len() as int
        }

        fn test4<const N: usize>(ar: &[u8; N]) {
            assert(len_of_slice(ar) == ar@.len());
        }

        fn test5<const N: usize>(ar: Box<[u8; N]>) {
            let sl: Box<[u8]> = ar;
            assert(sl@.len() == N);
        }

    } => Ok(())
}

test_verify_one_file! {
    #[test] test_array_for_loop verus_code! {
        use vstd::prelude::*;

        fn test() {
            let ar: [u32; 3] = [0u32, 2u32, 4u32];

            let mut i: usize = 0;
            for x in it: ar.iter()
                invariant
                    i == it.index(),
                    it.seq().unref() == seq![0u32, 2u32, 4u32],
            {
                assert(x < 5);
                assert(x % 2 == 0);
                i = i + 1;
            }
        }
    } => Ok(())
}

test_verify_one_file! {
    #[test] test_array_equality_uses_view verus_code! {
        use vstd::prelude::*;

        fn check<const N: usize>(left: [u8; N], right: [u8; N]) -> (result: bool)
            ensures
                result == (left@ =~= right@),
        {
            left == right
        }
    } => Ok(())
}

test_verify_one_file! {
    #[test] test_slice_ref_equals_array verus_code! {
        use vstd::prelude::*;

        fn check<const N: usize>(left: &[u8], right: [u8; N]) -> (result: bool)
            ensures
                result == (left@ =~= right@),
        {
            left == right
        }
    } => Ok(())
}

test_verify_one_file! {
    #[test]
    array_equals_slice_ref verus_code! {
        use vstd::prelude::*;

        fn check<const N: usize>(left: [u8; N], right: &[u8]) -> (result: bool)
            ensures
                result == (left@ =~= right@),
        {
            left == right
        }
    } => Ok(())
}

test_verify_one_file! {
    #[test]
    slice_equals_array_uses_view verus_code! {
        use vstd::prelude::*;

        fn check(left: &[u8], right: &[u8; 11]) -> (result: bool)
            ensures
                result == (left@ =~= right@),
        {
            <[u8] as PartialEq<[u8; 11]>>::eq(left, right)
        }
    } => Ok(())
}

test_verify_one_file! {
    #[test]
    array_equals_slice_uses_view verus_code! {
        use vstd::prelude::*;

        fn check(left: &[u8; 11], right: &[u8]) -> (result: bool)
            ensures
                result == (left@ =~= right@),
        {
            <[u8; 11] as PartialEq<[u8]>>::eq(left, right)
        }
    } => Ok(())
}

test_verify_one_file! {
    #[test]
    slice_ref_equals_array_ref_uses_view verus_code! {
        use vstd::prelude::*;

        fn check(left: &[u8], right: &[u8; 11]) -> (result: bool)
            ensures
                result == (left@ =~= right@),
        {
            left == right
        }
    } => Ok(())
}

test_verify_one_file! {
    #[test]
    array_ref_equals_slice_ref_uses_view verus_code! {
        use vstd::prelude::*;

        fn check(left: &[u8; 11], right: &[u8]) -> (result: bool)
            ensures
                result == (left@ =~= right@),
        {
            left == right
        }
    } => Ok(())
}
