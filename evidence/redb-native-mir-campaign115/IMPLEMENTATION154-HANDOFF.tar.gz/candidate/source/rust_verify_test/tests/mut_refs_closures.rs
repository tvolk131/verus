#![feature(rustc_private)]
#[macro_use]
mod common;
use common::*;

test_verify_one_file_with_options! {
    // Soundness of closure handling currently relies on disallowing mutation of
    // captured variables. Once that is supported, we will have to revisit the
    // assumption added in ast_to_sst::stm_call.
    #[test] fn_mut_call_ensures_disallows_mutating_moved_capture [] => verus_code! {
        use vstd::prelude::*;

        fn test() {
            let mut captured = 0u64;
            let mut f = move || -> u64 {
                captured += 1;
                captured
            };
            f();
        }
    } => Err(err) => assert_vir_error_msg(err, "Verus does not currently support closures capturing a mutable reference")
}

test_verify_one_file_with_options! {
    #[test] fn_mut_call_ensures_does_not_resolve_borrow [] => verus_code! {
        use vstd::prelude::*;

        proof fn test<F: FnMut(u64) -> u64>(f: &mut F, arg: u64, output: u64)
            requires call_ensures(f, (arg,), output),
        {
            // The output contract applies to the callable at the time of the call.
            assert(call_ensures(*f, (arg,), output));
            // The reference can still be used to replace the callable afterwards.
            assert(*final(f) == *f); // FAILS
        }
    } => Err(err) => assert_fails(err, 1)
}

test_verify_one_file_with_options! {
    #[test] fn_mut_call_ensures_preserves_call_reborrow [] => verus_code! {
        use vstd::prelude::*;

        fn call<G: FnMut() -> u64>(mut g: G) -> (res: (G, u64))
            requires g.requires(()),
            ensures res.0 == g, call_ensures(g, (), res.1),
        {
            let r = g();
            (g, r)
        }

        fn mk(v: u64) -> (f: impl FnMut() -> u64)
            ensures f.requires(()), forall|r: u64| f.ensures((), r) ==> r == v,
        {
            move || -> (r: u64) ensures r == v { v }
        }

        fn test() {
            let mut c = mk(1);
            let replacement = mk(2);
            let (x, r) = call(&mut c);
            assert(r == 1);
            *x = replacement;
            let after_replacement = c();
            assert(after_replacement == 2);
        }
    } => Ok(())
}

test_verify_one_file_with_options! {
    #[test] closure_with_mut_ref_arg_basic [] => verus_code! {
        use vstd::prelude::*;

        fn test() {
            let c = |a: &mut u64|
                requires *a < 100,
                ensures *final(a) == *old(a) + 1 // FAILS
            {
                return;
            };
        }

        fn test1() {
            let c = |a: &mut u64|
                requires *a < 100,
                ensures *final(a) == *old(a) + 1
            {
                *a += 1;
            };

            let mut x = 0;
            c(&mut x);
            assert(x == 1);

            let mut y = 0;
            c(&mut y);
            assert(y == 1);
        }

        fn test2() {
            let c = |a: &mut u64|
                requires *a < 100,
                ensures *final(a) == *old(a) + 1
            {
                *a += 1;
            };

            let mut x = 0;
            c(&mut x);
            assert(x == 1);
            assert(false); // FAILS
        }

        fn test3() {
            let c = |a: &mut u64|
                requires *a < 100,
                ensures *final(a) == *old(a) + 1
            {
                *a += 1;
            };

            let mut x = 100;
            c(&mut x); // FAILS
        }
    } => Err(err) => assert_fails(err, 3)
}

test_verify_one_file_with_options! {
    #[test] closure_returning_mut_ref_arg_basic [] => verus_code! {
        use vstd::prelude::*;

        fn constrain<T: Fn(&mut (u64, u64)) -> &mut u64>(t: T) -> T
            returns t
        { t }

        fn test() {
            let c = constrain(|pair: &mut (u64, u64)| -> (fst: &mut u64)
                ensures
                    *final(pair) == (*final(fst), old(pair).1), // FAILS
            {
                &mut pair.1
            });
        }

        fn test1() {
            let c = constrain(|pair: &mut (u64, u64)| -> (fst: &mut u64)
                ensures
                    *fst == old(pair).0,
                    *final(pair) == (*final(fst), old(pair).1),
            {
                &mut pair.0
            });

            let mut x = (0, 1);
            *c(&mut x) = 10;
            assert(x == (10, 1));

            let mut y = (2, 3);
            let r = c(&mut y);
            *r = 20;
            assert(y == (20, 3));
        }

        fn test2() {
            let c = constrain(|pair: &mut (u64, u64)| -> (fst: &mut u64)
                ensures
                    *fst == old(pair).0,
                    *final(pair) == (*final(fst), old(pair).1),
            {
                &mut pair.0
            });

            let mut x = (0, 1);
            *c(&mut x) = 10;
            assert(x == (10, 1));

            let mut y = (2, 3);
            let r = c(&mut y);
            *r = 20;
            assert(y == (20, 3));

            assert(false); // FAILS
        }
    } => Err(err) => assert_fails(err, 2)
}

test_verify_one_file_with_options! {
    #[test] closure_with_mut_ref_arg_pass_as_arg [] => verus_code! {
        use vstd::prelude::*;

        fn test1() {
            let c = |a: &mut u64|
                requires *a < 100,
                ensures *final(a) == *old(a) + 1
            {
                *a += 1;
            };

            assert(forall |x: &mut u64| *x < 100 ==> call_requires(c, (x,)));
            assert(forall |x: &mut u64, y: ()| call_ensures(c, (x,), y) ==> *final(x) == *x + 1);
        }

        fn test_caller() {
            let c = |a: &mut u64|
                requires *a < 100,
                ensures *final(a) == *old(a) + 1,
            {
                *a += 1;
            };
            test_callee(c);
        }

        fn test_callee(c: impl Fn(&mut u64))
            requires
                forall |x: &mut u64| *x < 100 ==> call_requires(c, (x,)),
                forall |x: &mut u64, y: ()| call_ensures(c, (x,), y) ==> *final(x) == *x + 1,
        {
            let mut x = 0;
            c(&mut x);
            assert(x == 1);
        }
    } => Ok(())
}

test_verify_one_file_with_options! {
    #[test] closure_returning_mut_ref_arg_pass_as_arg [] => verus_code! {
        use vstd::prelude::*;

        fn constrain<T: Fn(&mut (u64, u64)) -> &mut u64>(t: T) -> T
            returns t
        { t }

        fn test1() {
            let c = constrain(|pair: &mut (u64, u64)| -> (fst: &mut u64)
                ensures
                    *fst == old(pair).0,
                    *final(pair) == (*final(fst), old(pair).1),
            {
                &mut pair.0
            });

            assert(forall |x: &mut (u64, u64)| call_requires(c, (x,)));
            assert(forall |x: &mut (u64, u64), y: &mut u64| call_ensures(c, (x,), y) ==>
                    *y == x.0 && *final(x) == (*final(y), x.1));
        }

        fn test_caller() {
            let c = constrain(|pair: &mut (u64, u64)| -> (fst: &mut u64)
                ensures
                    *fst == old(pair).0,
                    *final(pair) == (*final(fst), old(pair).1),
            {
                &mut pair.0
            });
            test_callee(c);
        }

        fn test_callee(c: impl Fn(&mut (u64, u64)) -> &mut u64)
            requires
                forall |x: &mut (u64, u64)| call_requires(c, (x,)),
                forall |x: &mut (u64, u64), y: &mut u64| call_ensures(c, (x,), y) ==>
                        *y == x.0 && *final(x) == (*final(y), x.1),
        {
            let mut x = (0, 1);
            *c(&mut x) = 30;
            assert(x == (30, 1));
        }
    } => Ok(())
}

test_verify_one_file_with_options! {
    #[test] closure_resolve_basic_move [] => verus_code! {
        fn consume<T>(t: T) { }

        fn test<T>(t: T) {
            let a = t;
            let x = || {
                let y = a;
            };
            consume(x);

            assert(has_resolved(a)); // FAILS
        }

        fn test2<T>(t: T) {
            let a = t;
            let x = || {
                let y = a;
                assert(has_resolved(y));
            };
            consume(x);
        }

        fn test3<T>(t: T) {
            let a = t;
            assert(has_resolved(a));

            // Here `a` is taken by reference
            let x = || {
                let y = &a;
            };
            consume(x);
        }

        fn test4<T>(t: T) {
            let a = t;
            assert(has_resolved(a));

            // Technically `a` is moved here, but we can resolve it anyway
            // (since it's only used read-only)
            let x = move || {
                let y = &a;
            };
            consume(x);
        }

        fn test5<T>(t: T) {
            let a = t;
            let x = || {
                let y = a;
                consume(y);
                assert(has_resolved(a)); // FAILS
            };
            consume(x);
        }

        fn test6<T>(t: T, u: T) {
            let a = t;
            let b = u;
            let x = || {
                assert(has_resolved(b)); // FAILS
            };
            consume(x);
            consume(b);
        }
    } => Err(err) => assert_fails(err, 3)
}

test_verify_one_file_with_options! {
    #[test] closure_resolve_basic_move2 [] => verus_code! {
        fn consume<T>(t: T) { }

        fn test<T>(a: T) {
            let x = || {
                let y = a;
            };
            consume(x);

            assert(has_resolved(a)); // FAILS
        }

        fn test2<T>(a: T) {
            let x = || {
                let y = a;
                assert(has_resolved(y));
            };
            consume(x);
        }

        fn test3<T>(a: T) {
            assert(has_resolved(a));

            // Here `a` is taken by reference
            let x = || {
                let y = &a;
            };
            consume(x);
        }

        fn test4<T>(a: T) {
            assert(has_resolved(a));

            // Technically `a` is moved here, but we can resolve it anyway
            // (since it's only used read-only)
            let x = move || {
                let y = &a;
            };
            consume(x);
        }

        fn test5<T>(a: T) {
            let x = || {
                let y = a;
                consume(y);
                assert(has_resolved(a)); // FAILS
            };
            consume(x);
        }
    } => Err(err) => assert_fails(err, 2)
}

test_verify_one_file_with_options! {
    #[test] closure_resolve_basic_move_of_closure_param [] => verus_code! {
        fn consume<T>(t: T) { }

        fn test<T>() {
            let foo = |a: T| {
                let x = || {
                    let y = a;
                };
                consume(x);

                assert(has_resolved(a)); // FAILS
            };
        }

        fn test2<T>() {
            let foo = |a: T| {
                let x = || {
                    let y = a;
                    assert(has_resolved(y));
                };
                consume(x);
            };
        }

        fn test3<T>() {
            let foo = |a: T| {
                assert(has_resolved(a));

                // Here `a` is taken by reference
                let x = || {
                    let y = &a;
                };
                consume(x);
            };
        }

        fn test4<T>() {
            let foo = |a: T| {
                assert(has_resolved(a));

                // Technically `a` is moved here, but we can resolve it anyway
                // (since it's only used read-only)
                let x = move || {
                    let y = &a;
                };
                consume(x);
            };
        }

        fn test5<T>() {
            let foo = |a: T| {
                let x = || {
                    let y = a;
                    consume(y);
                    assert(has_resolved(a)); // FAILS
                };
                consume(x);
            };
        }
    } => Err(err) => assert_fails(err, 2)
}

test_verify_one_file_with_options! {
    #[test] proof_closure_resolve_basic_move [] => verus_code! {
        use vstd::prelude::*;

        proof fn consume<T>(tracked t: T) { }

        proof fn test<T>(tracked t: T) {
            let tracked a = t;
            let tracked x = proof_fn[Once] || {
                let tracked y = a;
            };
            consume(x);

            assert(has_resolved(a)); // FAILS
        }

        proof fn test2<T>(tracked t: T) {
            let tracked a = t;
            let tracked x = proof_fn[Once] || {
                let tracked y = a;
                assert(has_resolved(y));
            };
            consume(x);
        }

        proof fn test3<T>(tracked t: T) {
            let tracked a = t;
            assert(has_resolved(a));

            // Here `a` is taken by reference
            let tracked x = proof_fn || {
                let tracked y = &a;
            };
            consume(x);
        }

        proof fn test4<T>(tracked t: T) {
            let tracked a = t;
            assert(has_resolved(a));

            // Technically `a` is moved here, but we can resolve it anyway
            // (since it's only used read-only)
            let tracked x = move proof_fn || {
                let tracked y = &a;
            };
            consume(x);
        }

        proof fn test5<T>(tracked t: T) {
            let tracked a = t;
            let tracked x = proof_fn[Once] || {
                let tracked y = a;
                consume(y);
                assert(has_resolved(a)); // FAILS
            };
            consume(x);
        }
    } => Err(err) => assert_fails(err, 2)
}

test_verify_one_file_with_options! {
    #[test] closure_resolve_nested_move [] => verus_code! {
        use vstd::prelude::*;

        fn consume<T>(t: T) { }

        fn test<T>(t: T) {
            let a = t;
            let x = || {
                let j = || {
                    let y = a;
                };
                j();
            };
            consume(x);

            assert(has_resolved(a)); // FAILS
        }

        fn test2<T>(t: T) {
            let a = t;
            let x = || {
                let j = || {
                    let y = a;
                    assert(has_resolved(y));
                };
                j();
            };
            consume(x);
        }

        fn test3<T>(t: T) {
            let a = t;
            assert(has_resolved(a));
            let x = || {
                let j = || {
                    let y = &a;
                };
                j();
            };
            consume(x);
        }

        fn test4<T>(t: T) {
            let a = t;
            assert(has_resolved(a));
            let x = move || {
                let j = || {
                    let y = &a;
                };
                j();
            };
            consume(x);
        }

        fn test5<T>(t: T) {
            let a = t;
            let x = || {
                let j = || {
                    let y = a;
                };
                consume(j);
                assert(has_resolved(a)); // FAILS
            };
            consume(x);
        }
    } => Err(err) => assert_fails(err, 2)
}

test_verify_one_file_with_options! {
    #[test] closure_resolve_field_move [] => verus_code! {
        fn consume<T>(t: T) { }

        fn test<T, U>(t: (T, U)) {
            let pair = t;
            let x = || {
                let y = pair.0;
                assert(has_resolved(y));
            };
            consume(x);

            assert(has_resolved(pair.1));
        }

        fn test2<T, U>(t: (T, U)) {
            let pair = t;
            let x = || {
                let y = pair.0;
            };
            consume(x);

            assert(has_resolved(pair.0)); // FAILS
        }

        fn test3<T, U>(t: (T, U)) {
            let pair = t;
            assert(has_resolved(pair));

            // Here `a` is taken by reference
            let x = || {
                let y = &pair.0;
            };
            consume(x);
        }

        fn test4<T, U>(t: (T, U)) {
            let pair = t;
            assert(has_resolved(pair));

            let x = move || {
                let y = &pair.0;
            };
            consume(x);
        }

        fn test5<T, U>(t: (T, U)) {
            let pair = t;
            let x = || {
                let y = pair.0;
                assert(has_resolved(pair.1)); // FAILS
            };
            consume(x);
            consume(pair.1);
        }

    } => Err(err) => assert_fails(err, 2)
}

test_verify_one_file_with_options! {
    #[test] closure_resolve_overlapping_moves [] => verus_code! {
        fn some_bool() -> bool {
            true
        }

        fn consume<T>(t: T) { }

        fn test<T, U, V, W>(t: (T, U), v: (V, W)) {
            let pair = t;
            let qair = v;

            let x = || {
                if some_bool() {
                    consume(pair);
                    consume(qair);

                } else {
                    consume(pair.0);

                    assert(has_resolved(pair.1));
                    assert(has_resolved(qair));
                }
            };
            consume(x);
        }

        fn test1<T, U, V, W>(t: (T, U), v: (V, W)) {
            let pair = t;
            let qair = v;

            let x = || {
                if some_bool() {
                    consume(pair);
                    consume(qair);

                } else {
                    consume(pair.0);
                }
            };
            consume(x);

            assert(has_resolved(pair.1)); // FAILS
        }

        fn test2<T, U, V, W>(t: (T, U), v: (V, W)) {
            let pair = t;
            let qair = v;

            let x = || {
                if some_bool() {
                    consume(pair);
                    consume(qair);

                } else {
                    consume(pair.0);
                }
            };
            consume(x);

            assert(has_resolved(pair.0)); // FAILS
        }

        fn test3<T, U, V, W>(t: (T, U), v: (V, W)) {
            let pair = t;
            let qair = v;

            let x = || {
                if some_bool() {
                    consume(pair);
                    consume(qair);

                } else {
                    consume(pair.0);
                }
            };
            consume(x);

            assert(has_resolved(pair.1)); // FAILS
        }

        fn test4<T, U, V, W>(t: (T, U), v: (V, W)) {
            let pair = t;
            let qair = v;

            let x = || {
                if some_bool() {
                    consume(pair);
                    consume(qair);

                    assert(has_resolved(pair)); // FAILS
                } else {
                    consume(pair.0);

                }
            };
            consume(x);
        }

        fn test5<T, U, V, W>(t: (T, U), v: (V, W)) {
            let pair = t;
            let qair = v;

            let x = || {
                if some_bool() {
                    consume(pair);
                    consume(qair);

                    assert(has_resolved(pair.1)); // FAILS
                } else {
                    consume(pair.0);

                }
            };
            consume(x);
        }

        fn test6<T, U, V, W>(t: (T, U), v: (V, W)) {
            let pair = t;
            let qair = v;

            let x = || {
                if some_bool() {
                    consume(pair);
                    consume(qair);

                    assert(has_resolved(pair.0)); // FAILS
                } else {
                    consume(pair.0);

                }
            };
            consume(x);
        }

        fn test7<T, U, V, W>(t: (T, U), v: (V, W)) {
            let pair = t;
            let qair = v;

            let x = || {
                if some_bool() {
                    consume(pair);
                    consume(qair);

                    assert(has_resolved(pair)); // FAILS
                } else {
                    consume(pair.0);

                }
            };
            consume(x);
        }
    } => Err(err) => assert_fails(err, 7)
}

test_verify_one_file_with_options! {
    #[test] closure_resolve_params [] => verus_code! {
        use vstd::prelude::*;

        fn consume<T>(t: T) { }
        proof fn trk_consume<T>(tracked t: T) { }

        fn test1<T>() {
            let x = |y: T| {
                assert(has_resolved(y));
            };
        }

        fn test2<T>() {
            let x = |y: T| {
                consume(y);
                assert(has_resolved(y)); // FAILS
            };
        }

        proof fn test_trk_gho<T, G>() {
            let tracked x = proof_fn |tracked y: T, z: G| {
                assert(has_resolved(y));
            };
        }

        proof fn test_trk_gho2<T, G>() {
            let tracked x = proof_fn |tracked y: T, z: G| {
                assert(has_resolved(z)); // FAILS
            };
        }

        proof fn test_trk_gho3<T, G>() {
            let tracked x = proof_fn |tracked y: T, z: G| {
                trk_consume(y);
                assert(has_resolved(y)); // FAILS
            };
        }
    } => Err(err) => assert_fails(err, 3)
}

test_verify_one_file_with_options! {
    #[test] mut_refs_in_closure [] => verus_code! {
        fn test1() {
            let foo = || {
                let mut x: u64 = 0;
                let mut y: u64 = 10;

                let mut x_ref = &mut x;
                *x_ref = 20;

                assert(x == 20);

                x_ref = &mut y;
                *x_ref = 30;

                assert(y == 30);
            };
        }

        fn test1_fails() {
            let foo = || {
                let mut x: u64 = 0;
                let mut y: u64 = 10;

                let mut x_ref = &mut x;
                *x_ref = 20;

                assert(x == 20);

                x_ref = &mut y;
                *x_ref = 30;

                assert(y == 30);
                assert(false); // FAILS
            };
        }

        fn test1_fails2() {
            let foo = || {
                let mut x: u64 = 0;
                let mut y: u64 = 10;

                let mut x_ref = &mut x;
                *x_ref = 20;

                assert(x == 20);

                x_ref = &mut y;
                *x_ref = 30;

                assert(y == 30);
            };
            assert(false); // FAILS
        }
    } => Err(err) => assert_fails(err, 2)
}

test_verify_one_file_with_options! {
    #[test] spec_capture_of_mut_ref [] => verus_code! {
        use vstd::prelude::*;
        fn test(x: &mut u64)
            requires *x == 0,
        {
            *x = 5;

            let mut clos = ||
                requires mut_ref_current(x) == 5
            {
                assert(mut_ref_current(x) == 5);
            };

            assert(mut_ref_current(x) == 5);
            clos();
        }
    } => Ok(())
}
