#![feature(rustc_private)]
#[macro_use]
mod common;
use common::*;

test_verify_one_file_with_options! {
    #[test] mut_borrow_of_ghost_local_in_proof_fn [] => verus_code! {
        proof fn test() {
            let ghost g: u64 = 3;
            let mut_ret = &mut g;
        }
    } => Err(err) => assert_vir_error_msg(err, "cannot take mutable borrow of ghost-mode place")
}

test_verify_one_file_with_options! {
    #[test] mut_borrow_of_tracked_local_in_proof_fn [] => verus_code! {
        struct X { }
        proof fn test() {
            let tracked mut x = X { };
            let mut_ret = &mut x;
        }
    } => Ok(())
}

test_verify_one_file_with_options! {
    #[test] mut_borrow_of_ghost_local_in_exec_fn [] => verus_code! {
        fn test() {
            let ghost g: u64 = 3;
            let mut_ret = &mut g;
        }
    } => Err(err) => assert_vir_error_msg(err, "cannot access spec-mode place in executable context")
}

test_verify_one_file_with_options! {
    #[test] mut_borrow_of_tracked_local_in_exec_fn [] => verus_code! {
        struct X { }
        fn test() {
            let tracked x = X { };
            let mut_ret = &mut x;
        }
    } => Err(err) => assert_vir_error_msg(err, "cannot access proof-mode place in executable context")
}

test_verify_one_file_with_options! {
    #[test] mut_borrow_of_ghost_local_in_proof_block [] => verus_code! {
        fn test() {
            let ghost g: u64 = 3;
            proof {
                let tracked mut_ret = &mut g;
            }
        }
    } => Err(err) => assert_vir_error_msg(err, "cannot take mutable borrow of ghost-mode place")
}

test_verify_one_file_with_options! {
    #[test] mut_borrow_of_tracked_local_in_proof_block_to_ghost [] => verus_code! {
        struct X { }
        fn test() {
            let tracked x = X { };
            proof {
                let tracked mut_ret = &mut x;
            }
        }
    } => Ok(())
}

test_verify_one_file_with_options! {
    #[test] mut_borrow_of_exec_local_in_proof_block_to_tracked [] => verus_code! {
        struct X { }
        fn test() {
            let mut x = X { };
            proof {
                let tracked mut_ret = &mut x;
            }
        }
    } => Ok(())
}

test_verify_one_file_with_options! {
    #[test] mut_borrow_of_exec_local_in_tracked_local_decl [] => verus_code! {
        struct X { }
        fn test() {
            let mut x = X { };
            let tracked mut_ret = &mut x;
        }
    } => Ok(())
}

test_verify_one_file_with_options! {
    #[test] mut_borrow_lifetime_error [] => verus_code! {
        struct Y { }
        struct X { y: Y }
        fn test() {
            let mut x = Tracked(X { y: Y{} });
            proof {
                let tracked mut_ref1 = &mut x;
                let tracked mut_ref2 = &mut x;
                mut_ref1.borrow_mut().y = Y { };
            }
        }
    } => Err(err) => assert_rust_error_msg_skip_spec_msgs(err, "cannot borrow `x` as mutable more than once at a time")
}

test_verify_one_file_with_options! {
    #[test] mut_borrow_lifetime_error2 [] => verus_code! {
        struct Y { }
        struct X { y: Y }
        fn test() {
            let mut x = Tracked(X { y: Y{} });
            proof {
                let tracked mut_ref1 = &mut x;
                let ghost mut_ref2 = &mut x;
                mut_ref1.borrow_mut().y = Y { };
            }
        }
    } => Err(err) => assert_rust_error_msg_skip_spec_msgs(err, "cannot borrow `x` as mutable more than once at a time")
}

test_verify_one_file_with_options! {
    // TODO(new_mut_ref): fix
    #[ignore] #[test] mut_borrow_in_ghost_decl [] => verus_code! {
        fn test() {
            let mut x = 0;
            let ghost mut_ref2 = &mut x;
            assert(x == 0);
        }
    } => Ok(())
}

test_verify_one_file_with_options! {
    #[test] mut_borrow_in_spec_fn [] => verus_code! {
        spec fn foo<'a>() -> &'a mut bool {
            &mut false
        }
    } => Err(err) => assert_vir_error_msg(err, "mutable borrow is not allowed in spec context")
}

test_verify_one_file_with_options! {
    #[test] mut_borrow_in_assert_by [] => verus_code! {
        fn test() {
            let mut a = 24;
            assert(true) by {
                let x = &mut a;
            }
        }
    } => Err(err) => assert_vir_error_msg(err, "mutable borrow is not allowed in 'assert ... by' statement")
}

test_verify_one_file_with_options! {
    #[test] modify_tracked_place_in_exec_code [] => verus_code! {
        #[verifier::external_body] struct Y { }
        #[verifier::external_body] struct Z { }
        struct X { y: Tracked<(Y, Z)> }
        axiom fn new_y() -> (tracked y: Y);
        axiom fn new_z() -> (tracked z: Z);

        fn test(x0: X) {
            let mut x = x0;
            let mut_ref = &mut x;

            mut_ref.y.borrow_mut().0 = new_y();
        }
    } => Err(err) => assert_vir_error_msg(err, "cannot access proof-mode place in executable context")
}

test_verify_one_file_with_options! {
    #[test] modify_ghost_place_in_exec_code [] => verus_code! {
        struct X { y: Ghost<(bool, bool)> }

        fn test(x0: X) {
            let mut x = x0;
            let mut_ref = &mut x;

            mut_ref.y.borrow_mut().0 = false;
        }
    } => Err(err) => assert_vir_error_msg(err, "cannot access spec-mode place in executable context")
}

test_verify_one_file_with_options! {
    #[test] modify_ghost_place_in_assert_by [] => verus_code! {
        struct X { y: Ghost<(bool, bool)> }

        fn test(x0: X) {
            let mut x = x0;
            let mut_ref = &mut x;

            assert(true) by {
                mut_ref.y.borrow_mut().0 = false;
            }
        }
    } => Err(err) => assert_vir_error_msg(err, "assignment is not allowed in 'assert ... by' statement")
}

test_verify_one_file_with_options! {
    #[test] modify_tracked_place_in_proof_code [] => verus_code! {
        #[verifier::external_body] struct Y { }
        #[verifier::external_body] struct Z { }
        struct X { y: Tracked<(Y, Z)> }
        axiom fn new_y() -> (tracked y: Y);
        axiom fn new_z() -> (tracked z: Z);

        fn test(x0: X) {
            let mut x = x0;
            let mut_ref = &mut x;

            let tracked y = new_y();

            proof {
                mut_ref.y.borrow_mut().0 = y;
            }

            assert(has_resolved(mut_ref));
            assert(x.y@.0 == y);
        }

        fn test2(x0: X) {
            let mut x = x0;
            let mut_ref = &mut x;

            let tracked y = new_y();

            proof {
                let tracked mr = mut_ref;
                mr.y.borrow_mut().0 = y;
                assert(has_resolved(mr));
            }

            assert(x.y@.0 == y);
        }

        fn test3(x0: X) {
            let mut x = x0;

            let tracked y = new_y();

            proof {
                let tracked mr = &mut x;
                mr.y.borrow_mut().0 = y;
                assert(has_resolved(mr));
            }

            assert(x.y@.0 == y);
        }

        fn test4(x0: X) {
            let mut x = x0;

            let tracked y = new_y();

            proof {
                let tracked mr = &mut x;

                let z = mr.y.borrow_mut().0;
                assert(z == x0.y@.0);

                mr.y.borrow_mut().0 = y;
            }

            assert(x.y@.0 == y);
        }
    } => Ok(())
}

test_verify_one_file_with_options! {
    #[test] modify_ghost_place_in_proof_code [] => verus_code! {
        struct X { y: Ghost<(int, int)> }

        fn test(x0: X) {
            let mut x = x0;
            let mut_ref = &mut x;

            proof {
                mut_ref.y.borrow_mut().0 = 20int;
            }

            assert(has_resolved(mut_ref));
            assert(x.y@.0 == 20);
        }

        fn test2(x0: X) {
            let mut x = x0;
            let mut_ref = &mut x;

            proof {
                let tracked mr = mut_ref;
                mr.y.borrow_mut().0 = 20int;
                assert(has_resolved(mr));
            }

            assert(x.y@.0 == 20);
        }

        fn test3(x0: X) {
            let mut x = x0;
            let mut_ref = &mut x;

            proof {
                let tracked mr = &mut x;
                mr.y.borrow_mut().0 = 20int;
                assert(has_resolved(mr));
            }

            assert(x.y@.0 == 20);
        }

        fn test4(x0: X) {
            let mut x = x0;
            let mut_ref = &mut x;

            proof {
                let tracked mr = &mut x;
                let z = mr.y.borrow_mut().0;
                assert(z == x0.y@.0);
                mr.y.borrow_mut().0 = 20int;
                assert(has_resolved(mr));
            }

            assert(x.y@.0 == 20);
        }
    } => Ok(())
}

test_verify_one_file_with_options! {
    #[test] modify_exec_place_in_proof_code [] => verus_code! {
        struct X { y: Ghost<(int, int)> }

        fn test3(x0: X, x1: X) {
            let mut x = x0;
            let mut_ref = &mut x;

            proof {
                *mut_ref = x1;
            }
        }
    } => Err(err) => assert_vir_error_msg(err, "cannot mutate exec-mode place in proof-code")
}

test_verify_one_file_with_options! {
    #[test] modify_exec_place_in_proof_code2 [] => verus_code! {
        struct X { y: Ghost<(int, int)> }
        tracked struct XWrapper<'a> { tracked mut_ref: &'a mut X }

        fn test3(x0: X, x1: X) {
            let mut x = x0;
            let mut_ref = &mut x;
            let tracked wrapper = XWrapper { mut_ref: mut_ref };

            proof {
                *wrapper.mut_ref = x1;
            }
        }
    } => Err(err) => assert_vir_error_msg(err, "cannot mutate exec-mode place in proof-code")
}

test_verify_one_file_with_options! {
    #[test] modify_tracked_type_in_proof_code [] => verus_code! {
        tracked struct X { y: Ghost<(int, int)> }

        fn test3(x0: Tracked<X>, x1: Tracked<X>) {
            proof {
                let tracked mut x = x0.get();
                let tracked mut_ref = &mut x;

                *mut_ref = x1.get();
            }
        }
    } => Ok(())
}

test_verify_one_file_with_options! {
    #[test] modify_tracked_wrapped_type_in_proof_code [] => verus_code! {
        tracked struct X { y: Ghost<(int, int)> }

        fn test3(x0: Tracked<X>, x1: Tracked<X>) {
            let mut x = x0;
            let mut_ref = &mut x;

            proof {
                *mut_ref = x1;
            }
        }
    } => Ok(())
}

test_verify_one_file_with_options! {
    #[test] modify_ghost_wrapped_type_in_proof_code [] => verus_code! {
        struct X { y: Ghost<(int, int)> }

        fn test3(x0: X, x1: X) {
            let mut x = x0;
            let mut_ref = &mut x;

            proof {
                // mut_ref.y is an exec-mode place of type Ghost
                // but since Ghost is a ZST, it's ok
                mut_ref.y = Ghost((3, 2));
            }
        }
    } => Ok(())
}

test_verify_one_file_with_options! {
    #[test] mut_ref_tracked_place_in_proof_code [] => verus_code! {
        #[verifier::external_body] struct Y { }
        #[verifier::external_body] struct Z { }
        struct X { y: Tracked<(Y, Z)> }
        axiom fn new_y() -> (tracked y: Y);
        axiom fn new_z() -> (tracked z: Z);

        fn test(x0: X) {
            let mut x = x0;
            let mut_ref = &mut x;

            proof {
                let tracked z = &mut mut_ref.y.borrow_mut().0;
            }
        }
    } => Ok(())
}

test_verify_one_file_with_options! {
    #[test] mut_ref_tracked_place_in_proof_code2 [] => verus_code! {
        #[verifier::external_body] struct Y { }
        #[verifier::external_body] struct Z { }
        struct X { y: Tracked<(Y, Z)> }
        axiom fn new_y() -> (tracked y: Y);
        axiom fn new_z() -> (tracked z: Z);

        fn test(x0: X) {
            let mut x = x0;

            proof {
                let tracked z = x.y.borrow_mut();
            }
        }
    } => Ok(())
}

test_verify_one_file_with_options! {
    #[test] mut_ref_ghost_place_in_proof_code [] => verus_code! {
        struct X { y: Ghost<(int, int)> }

        fn test(x0: X) {
            let mut x = x0;
            let mut_ref = &mut x;

            proof {
                let tracked z = &mut mut_ref.y.borrow_mut().0;
            }
        }
    } => Err(err) => assert_vir_error_msg(err, "cannot take mutable borrow of ghost-mode place")
}

test_verify_one_file_with_options! {
    #[test] no_mutation_through_ghost_mut_ref [] => verus_code! {
        fn test() {
            let mut x = 30u64;
            let mut_ref = &mut x;
            let ghost mr = mut_ref;

            proof {
                *mr = 20u64;
            }
        }
    } => Err(err) => assert_vir_error_msg(err, "cannot mutate through a spec-mode mutable reference")
}

test_verify_one_file_with_options! {
    #[test] no_mutation_through_ghost_mut_ref2 [] => verus_code! {
        fn test() {
            let mut x = 30u64;
            let mut_ref = &mut x;
            let mr = Ghost(mut_ref);

            proof {
                **mr.borrow_mut() = 20u64;
            }
        }
    } => Err(err) => assert_vir_error_msg(err, "cannot mutate through a spec-mode mutable reference")
}

test_verify_one_file_with_options! {
    #[test] no_mutation_through_ghost_mut_ref3 [] => verus_code! {
        struct X { }

        fn test() {
            let mut x = Tracked(X {});
            let mut_ref = &mut x;
            let mr = Ghost(mut_ref);

            proof {
                *mr.borrow_mut().borrow_mut() = X { };
            }
        }
    } => Err(err) => assert_vir_error_msg(err, "cannot mutate through a spec-mode mutable reference")
}

test_verify_one_file_with_options! {
    #[test] no_mut_ref_through_ghost_mut_ref [] => verus_code! {
        fn test() {
            let mut x = 30u64;
            let mut_ref = &mut x;
            let ghost mr = mut_ref;

            proof {
                let tracked z = &mut *mr;
            }
        }
    } => Err(err) => assert_vir_error_msg(err, "cannot mutate through a spec-mode mutable reference")
}

test_verify_one_file_with_options! {
    #[test] no_mut_ref_through_ghost_mut_ref2 [] => verus_code! {
        fn test() {
            let mut x = 30u64;
            let mut_ref = &mut x;
            let mr = Ghost(mut_ref);

            proof {
                let tracked z = &mut **mr.borrow_mut();
            }
        }
    } => Err(err) => assert_vir_error_msg(err, "cannot mutate through a spec-mode mutable reference")
}

test_verify_one_file_with_options! {
    #[test] no_mut_ref_through_ghost_mut_ref3 [] => verus_code! {
        struct X { }

        fn test() {
            let mut x = Tracked(X {});
            let mut_ref = &mut x;
            let mr = Ghost(mut_ref);

            proof {
                let tracked z = &mut *mr.borrow_mut().borrow_mut();
            }
        }
    } => Err(err) => assert_vir_error_msg(err, "cannot mutate through a spec-mode mutable reference")
}

test_verify_one_file_with_options! {
    #[test] read_through_ghost_mut_ref_ok [] => verus_code! {
        struct X { }

        fn test() {
            let mut x = Tracked(X {});
            let mut_ref = &mut x;
            let mut mr = Ghost(mut_ref);

            proof {
                let z = *mr.borrow_mut().borrow_mut();
                assert(z == X { });
            }
        }
    } => Ok(())
}

test_verify_one_file_with_options! {
    #[test] cant_move_out_of_tracked_location [] => verus_code! {
        struct Pair<A, B>(Tracked<A>, Ghost<B>);

        fn test_trk<X>(t0: Pair<X, X>) {
            let mut t = t0;

            proof {
                // In principle this could be interpreted as a move, but the borrowchecker
                // doesn't know to do that.
                let tracked y = *t.0.borrow_mut();
            }
        }
    } => Err(err) => assert_rust_error_msg(err, "cannot move out of a mutable reference")
}

test_verify_one_file_with_options! {
    #[test] ghost_places_dont_count_as_moves [] => verus_code! {
        struct Pair<A, B>(Tracked<A>, Ghost<B>);

        enum Option<A> {
            Some(A),
            None,
        }
        use crate::Option::Some;
        use crate::Option::None;

        proof fn consume<X>(tracked x: X) { }
        proof fn use_ghost<X>(x: X) { }

        fn test_ghost<X>(t0: Pair<X, X>) {
            let mut t = t0;

            proof {
                match *t.1.borrow_mut() {
                    b => { use_ghost(b); }
                }
            }

            assert(has_resolved(t));
        }

        fn test_option_ghost<X>(t0: Pair<Option<X>, Option<X>>) {
            let mut t = t0;

            proof {
                match *t.1.borrow_mut() {
                    Some(x) => { use_ghost(x); }
                    None => { }
                }
            }

            assert(has_resolved(t));
        }

        fn test_option_trk2<X>(t0: Pair<Option<X>, Option<X>>) {
            let mut t = t0;

            proof {
                match *t.0.borrow_mut() {
                    Some(_) => { }
                    None => { }
                }
            }

            assert(has_resolved(t));
        }

        fn atbinder_test_let_ghost<X>(t0: Pair<X, X>) {
            let mut t = t0;

            proof {
                let x @ _ = *t.1.borrow_mut();
                use_ghost(x);
            }

            assert(has_resolved(t));
        }

        fn atbinder_test_ghost<X>(t0: Pair<X, X>) {
            let mut t = t0;

            proof {
                match *t.1.borrow_mut() {
                    b @ _ => { use_ghost(b); }
                }
            }

            assert(has_resolved(t));
        }

        fn atbinder_test_option_ghost<X>(t0: Pair<Option<X>, Option<X>>) {
            let mut t = t0;

            proof {
                match *t.1.borrow_mut() {
                    Some(x @ _) => { use_ghost(x); }
                    None => { }
                }
            }

            assert(has_resolved(t));
        }

    } => Ok(())
}

test_verify_one_file_with_options! {
    #[test] ghost_places_dont_resolve [] => verus_code! {
        fn test() {
            let mut x: u64 = 0;

            let mut_ref = &mut x;
            let ghost snapshot = mut_ref;

            *mut_ref = 20;

            assert(x == 20);
            assert(has_resolved(mut_ref));
            assert(has_resolved(snapshot)); // FAILS
        }
    } => Err(err) => assert_fails(err, 1)
}

test_verify_one_file_with_options! {
    #[test] ghost_places_dont_resolve2 [] => verus_code! {
        spec fn id<A>(a: A) -> A { a }

        fn test() {
            let mut x: u64 = 0;

            let mut_ref = &mut x;
            let ghost snapshot = id(mut_ref);

            *mut_ref = 20;

            assert(x == 20);
            assert(has_resolved(mut_ref));
            assert(has_resolved(snapshot)); // FAILS
        }
    } => Err(err) => assert_fails(err, 1)
}

test_verify_one_file_with_options! {
    #[test] tracked_places_lifetime_error [] => verus_code! {
        fn test() {
            let mut x: u64 = 0;

            let mut_ref = &mut x;
            let tracked snapshot = mut_ref;

            *mut_ref = 20;
        }
    } => Err(err) => assert_rust_error_msg(err, "use of moved value: `mut_ref`")
}

test_verify_one_file_with_options! {
    #[test] tracked_places_lifetime_error2 ["--no-lifetime"] => verus_code! {
        proof fn id<A>(tracked a: A) -> (tracked ret: A)
            ensures ret == a
        { a }

        fn test() {
            let mut x: u64 = 0;

            let mut_ref = &mut x;
            let tracked snapshot = id(mut_ref);

            *mut_ref = 20;

            // Even with lifetime-checking disabled, our resolution analysis sees tha
            // mut_ref was moved so it doesn't resolve it.
            assert(has_resolved(mut_ref)); // FAILS
        }
    } => Err(err) => assert_fails(err, 1)
}

test_verify_one_file_with_options! {
    #[test] tracked_places_lifetime_error3 ["--no-lifetime"] => verus_code! {
        proof fn id<A>(tracked a: A) -> (tracked ret: A)
            ensures ret == a
        { a }

        fn test() {
            let mut x: Ghost<u64> = Ghost(0u64);

            let mut_ref = &mut x;
            let tracked snapshot = id(mut_ref);
            let tracked snapshot2 = id(mut_ref);

            proof {
                *snapshot.borrow_mut() = 20u64;
                *snapshot2.borrow_mut() = 30u64;
            }

            // Without lifetime checking, we can get a contradiction since both snapshot
            // and snapshot2 use the same prophecy variable.
            assert(has_resolved(snapshot));
            assert(has_resolved(snapshot2));
            assert(false);
        }
    } => Ok(())
}

test_verify_one_file_with_options! {
    #[test] struct_with_ghost_and_tracked_fields [] => verus_code! {
        tracked struct A<B, C> {
            tracked b: B,
            ghost c: C,
        }

        tracked struct X<'a, 'b, Y, Z> {
            tracked y: &'a mut Y,
            ghost z: &'b mut Z,
        }

        proof fn test1<B, C>(a: A<B, C>) {
            assert(has_resolved(a) ==> has_resolved(a.b));
        }

        proof fn test2<B, C>(a: A<B, C>) {
            assert(has_resolved(a) ==> has_resolved(a.c)); // FAILS
        }

        proof fn test3<'a, 'b, Y, Z>(tracked x: X<'a, 'b, Y, Z>) {
            assert(has_resolved(x.y));
            assert(has_resolved(x.z)); // FAILS

        }
    } => Err(err) => assert_fails(err, 2)
}

test_verify_one_file_with_options! {
    #[test] reading_ghost_field_is_not_move ["--no-lifetime"] => verus_code! {
        #[verifier::external_body]
        struct X { }
        axiom fn new_x() -> (tracked x: X);
        axiom fn new_x_gho() -> (x: X);

        fn test<X>() {
            let mut j = (Tracked(new_x()), Ghost(new_x_gho()));

            proof { let y = *j.1.borrow_mut(); }

            assert(has_resolved(j));
        }

        fn test2<X>() {
            let mut j = (Tracked(new_x()), Ghost(new_x_gho()));

            // This is an ownership error ("cannot move out of a mutable reference"),
            // but I used --no-lifetime for this test because
            // I want to check the below assert fails. (Our resolution_analysis treats
            // this as a move.)
            proof { let tracked y = *j.0.borrow_mut(); }

            assert(has_resolved(j)); // FAILS
        }
    } => Err(err) => assert_fails(err, 1)
}

test_verify_one_file_with_options! {
    #[test] modify_ghost_fields_through_mut_refs [] => verus_code! {
        fn test1() {
            let mut t: Ghost<(int, int)> = Ghost((4, 6));
            let mut_ref = &mut t;
            proof { *mut_ref.borrow_mut() = (5, 10); }
            assert(t@ == (5, 10));
        }

        fn test1_fails() {
            let mut t: Ghost<(int, int)> = Ghost((4, 6));
            let mut_ref = &mut t;
            proof { *mut_ref.borrow_mut() = (5, 10); }
            assert(t@ == (5, 10));
            assert(false); // FAILS
        }

        fn test2() {
            let mut t: Ghost<(int, int)> = Ghost((4, 6));
            let mut_ref = &mut t;
            proof { mut_ref.borrow_mut().0 = 5; }
            assert(t@ == (5, 6));
        }

        fn test2_fails() {
            let mut t: Ghost<(int, int)> = Ghost((4, 6));
            let mut_ref = &mut t;
            proof { mut_ref.borrow_mut().0 = 5; }
            assert(t@ == (5, 6));
            assert(false); // FAILS
        }

        tracked struct Tr {
            ghost ints: (int, int),
        }

        fn test3() {
            let mut t: Tracked<Tr> = Tracked(Tr { ints: (4, 6) });
            let mut_ref = &mut t;
            proof { mut_ref.borrow_mut().ints = (5, 10); }
            assert(t@.ints == (5, 10));
        }

        fn test3_fails() {
            let mut t: Tracked<Tr> = Tracked(Tr { ints: (4, 6) });
            let mut_ref = &mut t;
            proof { mut_ref.borrow_mut().ints = (5, 10); }
            assert(t@.ints == (5, 10));
            assert(false); // FAILS
        }

        fn test4() {
            let mut t: Tracked<Tr> = Tracked(Tr { ints: (4, 6) });
            let mut_ref = &mut t;
            proof { mut_ref.borrow_mut().ints.0 = 5; }
            assert(t@.ints == (5, 6));
        }

        fn test4_fails() {
            let mut t: Tracked<Tr> = Tracked(Tr { ints: (4, 6) });
            let mut_ref = &mut t;
            proof { mut_ref.borrow_mut().ints.0 = 5; }
            assert(t@.ints == (5, 6));
            assert(false); // FAILS
        }
    } => Err(err) => assert_fails(err, 4)
}

test_verify_one_file_with_options! {
    #[test] modify_ghost_fields_doesnt_reinitialize1 [] => verus_code! {
        fn consume<A>(a: A) { }

        fn test<X>(x: X) {
            let y = (x, Ghost(0int));
            consume(y.0);
            proof { *y.1.borrow_mut() = 5int; }

            assert(has_resolved(y.0)); // FAILS
        }
    } => Err(err) => assert_rust_error_msg(err, "cannot borrow `y.1` as mutable, as `y` is not declared as mutable")
}

test_verify_one_file_with_options! {
    #[test] modify_ghost_fields_doesnt_reinitialize2 [] => verus_code! {
        fn consume<A>(a: A) { }

        fn test<X>(x: X) {
            let mut y = (x, Ghost(0int));
            consume(y.0);
            proof { *y.1.borrow_mut() = 5int; }

            assert(has_resolved(y.0)); // FAILS
        }
    } => Err(err) => assert_fails(err, 1)
}

test_verify_one_file_with_options! {
    #[test] deref_ghost_mut_ref_is_ghost [] => verus_code! {
        struct X { }

        proof fn g(tracked m: X) { }

        proof fn f(m: &mut X) {
            g(*m);
        }
    } => Err(err) => assert_vir_error_msg(err, "expression has mode spec, expected mode proof")
}

test_verify_one_file_with_options! {
    #[test] dont_resolve_ghost_field [] => verus_code! {
        broadcast proof fn stronger_resolver_axiom<A, B>(pair: TGPair<A, B>)
            ensures #[trigger] has_resolved(pair) ==> has_resolved(pair.t)
        {
        }

        spec fn id<A>(a: A) -> A { a }

        tracked struct TGPair<A, B> {
            tracked t: A,
            ghost g: B,
        }

        fn test1() {
            let mut a: u64 = 0;
            let mut b: u64 = 0;

            let a_ref = &mut a;
            let b_ref = &mut b;

            // We have to be careful here that resolving tmp.t
            // does not also resolve tmp.g (which is a ghost place)

            proof {
                let tracked tg = TGPair { g: id(a_ref), t: b_ref };
                match tg {
                    TGPair { g: _, t } => {
                    }
                }
            }

            broadcast use stronger_resolver_axiom;

            assert(has_resolved(a_ref)); // FAILS

            *a_ref = 20;
        }
    } => Err(err) => assert_fails(err, 1)
}

test_verify_one_file_with_options! {
    #[test] dont_resolve_ghost_field2 [] => verus_code! {
        broadcast proof fn stronger_resolver_axiom<A, B>(pair: TGPair<A, B>)
            ensures #[trigger] has_resolved(pair) ==> has_resolved(pair.t)
        {
        }

        spec fn id<A>(a: A) -> A { a }

        tracked struct TGPair<A, B> {
            ghost g: B,
            tracked t: A,
        }

        fn test1() {
            let mut a: u64 = 0;
            let mut b: u64 = 0;

            let a_ref = &mut a;
            let b_ref = &mut b;

            // We have to be careful here that resolving tmp.t
            // does not also resolve tmp.g (which is a ghost place)

            proof {
                let tracked tg = TGPair { g: id(a_ref), t: b_ref };
                match tg {
                    TGPair { g: _, t } => {
                    }
                }
            }

            broadcast use stronger_resolver_axiom;

            assert(has_resolved(a_ref)); // FAILS

            *a_ref = 20;
        }
    } => Err(err) => assert_fails(err, 1)
}

test_verify_one_file_with_options! {
    #[test] resolve_tracked_param_but_not_ghost_param [] => verus_code! {
        proof fn test_tr<T>(tracked m: &mut T) {
            assert(has_resolved(m));
        }

        proof fn test_gho<T>(m: &mut T) {
            assert(has_resolved(m)); // FAILS
        }
    } => Err(err) => assert_fails(err, 1)
}

test_verify_one_file_with_options! {
    #[test] read_from_borrowed_ghost_location_and_then_assign_to_mut_ref [] => verus_code! {
        fn test() {
            let mut x: Ghost<bool> = Ghost(false);

            let r = &mut x;

            let ghost updated_value = x@;

            proof {
                r@ = !updated_value;
            }

            assert(false);
        }
    } => Err(err) => assert_rust_error_msg(err, "cannot borrow `(Verus spec x)` as immutable because it is also borrowed as mutable")
}

test_verify_one_file_with_options! {
    #[test] tracked_swap_requires_non_exec_place [] => verus_code! {
        use vstd::prelude::*;
        use vstd::modes::*;
        fn test() {
            let mut a: u64 = 0;
            let mut b: u64 = 1;
            let a_ref = &mut a;
            let b_ref = &mut b;
            proof {
                tracked_swap(a_ref, b_ref);
            }
        }
    } => Err(err) => assert_vir_error_msg(err, "cannot mutate exec-mode place in ghost code")
}

test_verify_one_file_with_options! {
    #[test] tracked_swap_requires_non_exec_place2 [] => verus_code! {
        use vstd::prelude::*;
        use vstd::modes::*;
        fn test(x: &mut u32, y: &mut u32) {
            proof {
                tracked_swap(x, y);
            }
        }
    } => Err(err) => assert_vir_error_msg(err, "cannot mutate exec-mode place in ghost code")
}

test_verify_one_file_with_options! {
    #[test] tracked_swap_requires_non_exec_place3 [] => verus_code! {
        use vstd::prelude::*;
        use vstd::modes::*;
        fn test(x: &mut u32, y: &mut u32) {
            let tracked mut a: u32 = 0;
            let tracked mut b: u32 = 0;
            proof {
                tracked_swap(&mut a, &mut b);
            }
        }
    } => Ok(())
}

test_verify_one_file_with_options! {
    #[test] tracked_swap_requires_non_exec_place4 [] => verus_code! {
        use vstd::prelude::*;
        use vstd::modes::*;
        fn test(x: &mut u32, y: &mut u32) {
            let mut a: u32 = 0;
            let tracked mut b: u32 = 0;
            proof {
                tracked_swap(&mut a, &mut b);
            }
        }
    } => Err(err) => assert_vir_error_msg(err, "cannot mutate exec-mode place in ghost code")
}

test_verify_one_file_with_options! {
    #[test] tracked_swap_requires_non_exec_place5 [] => verus_code! {
        use vstd::prelude::*;
        use vstd::modes::*;
        fn test(x: &mut u32, y: &mut u32) {
            let tracked mut a: u32 = 0;
            let mut b: u32 = 0;
            proof {
                tracked_swap(&mut a, &mut b);
            }
        }
    } => Err(err) => assert_vir_error_msg(err, "cannot mutate exec-mode place in ghost code")
}

test_verify_one_file_with_options! {
    #[test] tracked_swap_requires_non_exec_place6 [] => verus_code! {
        use vstd::prelude::*;
        use vstd::modes::*;
        tracked struct X { }
        fn test(Tracked(x): Tracked<&mut X>, Tracked(y): Tracked<&mut X>) {
            proof {
                tracked_swap(x, y);
            }
        }
    } => Ok(())
}

test_verify_one_file_with_options! {
    #[test] tracked_swap_requires_non_exec_place7 [] => verus_code! {
        use vstd::prelude::*;
        use vstd::modes::*;
        struct X { }
        fn test(Tracked(x): Tracked<&mut Tracked<X>>, Tracked(y): Tracked<&mut Tracked<X>>) {
            proof {
                tracked_swap(x, y);
            }
        }
    } => Ok(())
}

test_verify_one_file_with_options! {
    #[test] tracked_swap_requires_non_exec_place8 [] => verus_code! {
        use vstd::prelude::*;
        use vstd::modes::*;
        tracked struct X { a: u64 }
        fn test(Tracked(x): Tracked<&mut X>, Tracked(y): Tracked<&mut X>) {
            proof {
                tracked_swap(&mut x.a, &mut y.a);
            }
        }
    } => Ok(())
}

test_verify_one_file_with_options! {
    #[test] tracked_swap_requires_non_exec_place9 [] => verus_code! {
        use vstd::prelude::*;
        use vstd::modes::*;
        struct X { a: u64 }
        fn test(Tracked(x): Tracked<&mut X>, Tracked(y): Tracked<&mut X>) {
            proof {
                tracked_swap(&mut x.a, &mut y.a);
            }
        }
    } => Err(err) => assert_vir_error_msg(err, "cannot mutate exec-mode place in ghost code")
}

test_verify_one_file_with_options! {
    #[test] tracked_take_requires_non_exec_place [] => verus_code! {
        use vstd::prelude::*;
        use vstd::modes::*;
        struct X { a: u64 }
        fn test(Tracked(x): Tracked<&mut Option<X>>) {
            proof {
                let tracked x = x.tracked_take();
            }
        }
    } => Err(err) => assert_vir_error_msg(err, "cannot mutate exec-mode place in ghost code")
}

test_verify_one_file_with_options! {
    #[test] tracked_take_requires_non_exec_place2 [] => verus_code! {
        use vstd::prelude::*;
        use vstd::modes::*;
        tracked struct X { a: u64 }
        fn test(Tracked(x): Tracked<&mut Option<X>>)
            requires x.is_some(),
        {
            proof {
                let tracked x = x.tracked_take();
            }
        }
    } => Ok(())
}

test_verify_one_file_with_options! {
    #[test] tracked_take_requires_non_exec_place3 [] => verus_code! {
        use vstd::prelude::*;
        use vstd::modes::*;
        struct X { a: u64 }
        // The type argument being a ZST isn't sufficient
        fn test(Tracked(x): Tracked<&mut Option<Tracked<X>>>) {
            proof {
                let tracked x = x.tracked_take();
            }
        }
    } => Err(err) => assert_vir_error_msg(err, "cannot mutate exec-mode place in ghost code")
}

test_verify_one_file_with_options! {
    #[test] tracked_take_requires_non_exec_place4 [] => verus_code! {
        use vstd::prelude::*;
        use vstd::modes::*;
        struct X { a: u64 }

        #[allow(deprecated)]
        fn test<O: OptionAdditionalFns<X>>(Tracked(x): Tracked<&mut O>)
            requires x.is_Some()
        {
            proof {
                let tracked x = x.tracked_take();
            }
        }
    } => Err(err) => assert_vir_error_msg(err, "cannot mutate exec-mode place in ghost code")
}

test_verify_one_file_with_options! {
    #[test] tracked_swap_option_not_ok [] => verus_code! {
        use vstd::prelude::*;
        use vstd::modes::*;
        tracked struct X { a: u64 }
        // The type argument being a ZST isn't sufficient
        fn test(Tracked(x): Tracked<&mut Option<X>>, Tracked(y): Tracked<&mut Option<X>>) {
            proof {
                tracked_swap(x, y);
            }
        }
    } => Err(err) => assert_vir_error_msg(err, "cannot mutate exec-mode place in ghost code")
}

test_verify_one_file_with_options! {
    #[test] wrapped_params [] => verus_code! {
        fn f(Tracked(x): Tracked<&mut Ghost<int>>)
            requires x.view() < 20,
            ensures final(x).view() == old(x).view() + 1,
        {
            proof { *x = Ghost(x.view() + 1); }
        }

        fn f2(Tracked(x): Tracked<&mut Ghost<int>>)
            requires x.view() < 20,
            ensures final(x).view() == old(x).view() + 1,
        {
            f(Tracked(x));
        }

        fn f3(Tracked(x): Tracked<&mut Ghost<int>>)
            requires x.view() < 20,
            ensures final(x).view() == old(x).view() + 1,
        {
            f(Tracked(&mut *x));
        }

        fn f4() {
            let mut g = Ghost(3);
            f(Tracked(&mut g));
            assert(g == 4);
        }

        fn f5() {
            let mut g = Ghost(3);
            let tg = Tracked(&mut g);
            f(tg);
            assert(g == 4);
        }

        fn f_fails(Tracked(x): Tracked<&mut Ghost<int>>)
            requires x.view() < 20,
            ensures final(x).view() == old(x).view() + 1,
        {
            proof { *x = Ghost(x.view() + 1); }
            assert(false); // FAILS
        }

        fn f2_fails(Tracked(x): Tracked<&mut Ghost<int>>)
            requires x.view() < 20,
            ensures final(x).view() == old(x).view() + 1,
        {
            f(Tracked(x));
            assert(false); // FAILS
        }

        fn f3_fails(Tracked(x): Tracked<&mut Ghost<int>>)
            requires x.view() < 20,
            ensures final(x).view() == old(x).view() + 1,
        {
            f(Tracked(&mut *x));
            assert(false); // FAILS
        }

        fn f4_fails() {
            let mut g = Ghost(3);
            f(Tracked(&mut g));
            assert(g == 4);
            assert(false); // FAILS
        }

        fn f5_fails() {
            let mut g = Ghost(3);
            let tg = Tracked(&mut g);
            f(tg);
            assert(g == 4);
            assert(false); // FAILS
        }
    } => Err(err) => assert_fails(err, 5)
}

test_verify_one_file_with_options! {
    #[test] wrapped_params_reborrow [] => verus_code! {
        fn f(Tracked(x): Tracked<&mut Ghost<int>>)
            requires x.view() < 20,
            ensures final(x).view() == old(x).view() + 1,
        {
            proof { *x = Ghost(x.view() + 1); }
        }

        fn f2(Tracked(x): Tracked<&mut Ghost<int>>)
            requires x.view() == 3,
        {
            f(Tracked(x));
            f(Tracked(x));
            assert(*x == 5);
        }

        fn f2_fails(Tracked(x): Tracked<&mut Ghost<int>>)
            requires x.view() == 3,
        {
            f(Tracked(x));
            f(Tracked(x));
            assert(*x == 5);
            assert(false); // FAILS
        }
    } => Err(err) => assert_fails(err, 1)
}

test_verify_one_file_with_options! {
    #[test] wrapped_mut_ref_params_resolved [] => verus_code! {
        fn test(Ghost(x): Ghost<&mut u64>) {
            assert(has_resolved(x)); // FAILS
        }

        fn test2(Tracked(x): Tracked<&mut u64>) {
            assert(has_resolved(x));
        }

        fn test3(x: Ghost<&mut u64>) {
            assert(has_resolved(x@)); // FAILS
        }

        fn test4(x: Tracked<&mut u64>) {
            assert(has_resolved(x@));
        }
    } => Err(err) => assert_fails(err, 2)
}

test_verify_one_file_with_options! {
    #[test] tracked_overloaded_deref_1 [] => verus_code! {
        fn test1(x: Tracked<u64>) {
            let tracked y: u64 = *x;
            assert(x == y);
        }

        fn test2(x: Tracked<u64>) {
            let tracked y: &u64 = &*x;
            assert(*x == y);
        }

        fn test3(x: Tracked<Ghost<u64>>) {
            let mut x = x;
            let tracked y: &mut Ghost<u64> = &mut *x;
            proof { *y = Ghost(3); }
            assert(*x == 3);
        }

        fn test3_fails(x: Tracked<Ghost<u64>>) {
            let mut x = x;
            let tracked y: &mut Ghost<u64> = &mut *x;
            proof { *y = Ghost(3); }
            assert(*x == 3);
            assert(false); // FAILS
        }

        fn test4(x: Tracked<Ghost<u64>>) {
            let mut x = x;
            proof { *x = Ghost(3); }
            assert(*x == 3);
        }
    } => Err(err) => assert_fails(err, 1)
}

test_verify_one_file_with_options! {
    #[test] tracked_overloaded_deref_2 [] => verus_code! {
        fn test4(x: Tracked<Ghost<u64>>) {
            let mut x = x;
            *x = Ghost(3);
            assert(*x == 3);
        }
    } => Err(err) => assert_vir_error_msg(err, "cannot access proof-mode place in executable context")
}

test_verify_one_file_with_options! {
    #[test] tracked_overloaded_deref_3 [] => verus_code! {
        fn test4(x: Tracked<Ghost<u64>>) {
            let mut x = x;
            let y = &mut *x;
        }
    } => Err(err) => assert_vir_error_msg(err, "cannot access proof-mode place in executable context")
}

test_verify_one_file_with_options! {
    #[test] tracked_overloaded_deref_lifetime_1 [] => verus_code! {
        fn test3(x: Tracked<Ghost<u64>>) {
            let mut x = x;
            let tracked y: &mut Ghost<u64> = &mut *x;
            let tracked y2: &mut Ghost<u64> = &mut *x;
            proof { *y = Ghost(3); }
        }
    } => Err(err) => assert_rust_error_msg_skip_spec_msgs(err, "cannot borrow `x` as mutable more than once at a time")
}

test_verify_one_file_with_options! {
    #[test] tracked_overloaded_deref_lifetime_2 [] => verus_code! {
        fn test3(x: Tracked<Ghost<u64>>) {
            let mut x = x;
            let tracked y: &mut Ghost<u64> = &mut *x;
            let tracked y2: &Ghost<u64> = &*x;
            proof { *y = Ghost(3); }
        }
    } => Err(err) => assert_rust_error_msg(err, "cannot borrow `x` as immutable because it is also borrowed as mutable")
}

test_verify_one_file_with_options! {
    #[test] ghost_overloaded_deref_1 [] => verus_code! {
        fn test1(x: Ghost<u64>) {
            let ghost y: u64 = *x;
            assert(x == y);
        }

        fn test2(x: Ghost<u64>) {
            let ghost y: &u64 = &*x;
            assert(*x == y);
        }

        fn test3(x: Ghost<u64>) {
            let mut x = x;
            let x_ref = &mut x;
            proof { **x_ref = 30u64; }
            assert(x == 30);
        }

        fn test3_fails(x: Ghost<u64>) {
            let mut x = x;
            let x_ref = &mut x;
            proof { **x_ref = 30u64; }
            assert(x == 30);
            assert(false); // FAILS
        }

        fn test4(x: Ghost<u64>) {
            let mut x = x;
            proof { *x = 3; }
            assert(x == 3);
        }
    } => Err(err) => assert_fails(err, 1)
}

test_verify_one_file_with_options! {
    #[test] ghost_overloaded_deref_2 [] => verus_code! {
        fn test4(x: Ghost<Ghost<u64>>) {
            let mut x = x;
            *x = Ghost(3);
            assert(*x == 3);
        }
    } => Err(err) => assert_vir_error_msg(err, "cannot access spec-mode place in executable context")
}

test_verify_one_file_with_options! {
    #[test] ghost_overloaded_deref_3 [] => verus_code! {
        fn test4(x: Ghost<Ghost<u64>>) {
            let mut x = x;
            let y = &mut *x;
        }
    } => Err(err) => assert_vir_error_msg(err, "cannot access spec-mode place in executable context")
}

test_verify_one_file_with_options! {
    #[test] ghost_overloaded_deref_4 [] => verus_code! {
        fn test4(x: Ghost<Ghost<u64>>) {
            let mut x = x;
            proof { let y = &mut *x; }
        }
    } => Err(err) => assert_vir_error_msg(err, "cannot take mutable borrow of ghost-mode place")
}

test_verify_one_file_with_options! {
    #[test] ghost_overloaded_deref_lifetime [] => verus_code! {
        fn test4(x: Ghost<u64>) {
            let mut x = x;
            let x_ref = &mut x;

            x = Ghost(3);

            proof {
                **x_ref = 30u64;
            }
        }
    } => Err(err) => assert_rust_error_msg_skip_spec_msgs(err, "cannot assign to `x` because it is borrowed")
}

test_verify_one_file_with_options! {
    #[test] tracked_auto_deref_1 [] => verus_code! {
        fn test1(x: Tracked<(u64, u64)>) {
            let tracked y: u64 = x.0;
            assert(x@.0 == y);
            assert(x.0 == y);
        }

        fn test2(x: Tracked<(u64, u64)>) {
            let tracked y: &u64 = &x.0;
            assert(x@.0 == y);
            assert(x.0 == y);
        }

        fn test3(x: Tracked<(Ghost<u64>, Ghost<u64>)>) {
            let mut x = x;
            let tracked y: &mut Ghost<u64> = &mut x.0;
            proof { *y = Ghost(3); }
            assert(x.0 == 3);
        }

        fn test3_fails(x: Tracked<(Ghost<u64>, Ghost<u64>)>) {
            let mut x = x;
            let tracked y: &mut Ghost<u64> = &mut x.0;
            proof { *y = Ghost(3); }
            assert(x.0 == 3);
            assert(false); // FAILS
        }

        fn test4(x: Tracked<(Ghost<u64>, Ghost<u64>)>) {
            let mut x = x;
            proof { x.0 = Ghost(3); }
            assert(x.0 == 3);
        }
    } => Err(err) => assert_fails(err, 1)
}

test_verify_one_file_with_options! {
    #[test] tracked_auto_deref_2 [] => verus_code! {
        fn test4(x: Tracked<(Ghost<u64>, Ghost<u64>)>) {
            let mut x = x;
            x.0 = Ghost(3);
            assert(x.0 == 3);
        }
    } => Err(err) => assert_vir_error_msg(err, "cannot access proof-mode place in executable context")
}

test_verify_one_file_with_options! {
    #[test] tracked_auto_deref_3 [] => verus_code! {
        fn test4(x: Tracked<(Ghost<u64>, Ghost<u64>)>) {
            let mut x = x;
            let y = &mut x.0;
        }
    } => Err(err) => assert_vir_error_msg(err, "cannot access proof-mode place in executable context")
}

test_verify_one_file_with_options! {
    #[test] tracked_auto_deref_lifetime_1 [] => verus_code! {
        fn test3(x: Tracked<(Ghost<u64>, Ghost<u64>)>) {
            let mut x = x;
            let tracked y: &mut Ghost<u64> = &mut x.0;
            let tracked y2: &mut Ghost<u64> = &mut x.0;
            proof { *y = Ghost(3); }
        }
    } => Err(err) => assert_rust_error_msgs(err, &[
        "cannot borrow `x` as mutable more than once at a time",
        "cannot borrow `(Verus spec x)` as mutable more than once at a time",
    ])
}

test_verify_one_file_with_options! {
    #[test] tracked_auto_deref_lifetime_2 [] => verus_code! {
        fn test3(x: Tracked<(Ghost<u64>, Ghost<u64>)>) {
            let mut x = x;
            let tracked y: &mut Ghost<u64> = &mut x.0;
            let tracked y2: &Ghost<u64> = &x.0;
            proof { *y = Ghost(3); }
        }
    } => Err(err) => assert_rust_error_msg(err, "cannot borrow `x` as immutable because it is also borrowed as mutable")
}

test_verify_one_file_with_options! {
    #[test] ghost_auto_deref_1 [] => verus_code! {
        fn test1(x: Ghost<(u64, u64)>) {
            let ghost y: u64 = x.0;
            assert(x@.0 == y);
            assert(x.0 == y);
        }

        fn test2(x: Ghost<(u64, u64)>) {
            let ghost y: &u64 = &x.0;
            assert(x.0 == y);
        }

        fn test3(x: Ghost<(u64, u64)>) {
            let mut x = x;
            let x_ref = &mut x;
            proof { x_ref.0 = 30u64; }
            assert(x.0 == 30);
        }

        fn test3_fails(x: Ghost<(u64, u64)>) {
            let mut x = x;
            let x_ref = &mut x;
            proof { x_ref.0 = 30u64; }
            assert(x.0 == 30);
            assert(false); // FAILS
        }

        fn test4(x: Ghost<(u64, u64)>) {
            let mut x = x;
            proof { x.0 = 3; }
            assert(x.0 == 3);
        }
    } => Err(err) => assert_fails(err, 1)
}

test_verify_one_file_with_options! {
    #[test] ghost_auto_deref_2 [] => verus_code! {
        fn test4(x: Ghost<(Ghost<u64>, Ghost<u64>)>) {
            let mut x = x;
            x.0 = Ghost(3);
            assert(x.0 == 3);
        }
    } => Err(err) => assert_vir_error_msg(err, "cannot access spec-mode place in executable context")
}

test_verify_one_file_with_options! {
    #[test] ghost_auto_deref_3 [] => verus_code! {
        fn test4(x: Ghost<(Ghost<u64>, Ghost<u64>)>) {
            let mut x = x;
            let y = &mut x.0;
        }
    } => Err(err) => assert_vir_error_msg(err, "cannot access spec-mode place in executable context")
}

test_verify_one_file_with_options! {
    #[test] ghost_auto_deref_4 [] => verus_code! {
        fn test4(x: Ghost<(Ghost<u64>, Ghost<u64>)>) {
            let mut x = x;
            proof { let y = &mut x.0; }
        }
    } => Err(err) => assert_vir_error_msg(err, "cannot take mutable borrow of ghost-mode place")
}

test_verify_one_file_with_options! {
    #[test] ghost_auto_deref_lifetime [] => verus_code! {
        fn test4(x: Ghost<(u64, u64)>) {
            let mut x = x;
            let x_ref = &mut x;

            x = Ghost((3u64, 3u64));

            proof {
                x_ref.0 = 30u64;
            }
        }
    } => Err(err) => assert_rust_error_msg_skip_spec_msgs(err, "cannot assign to `x` because it is borrowed")
}

test_verify_one_file_with_options! {
    #[test] deref_generic_use_err_deref_tracked [] => verus_code! {
        use vstd::prelude::*;
        fn foo<T: std::ops::Deref>() { }
        fn foo2() {
            foo::<Tracked<u64>>();
        }
    } => Err(err) => assert_vir_error_msg(err, "reliance on trait bound `verus_builtin::Tracked<A>: core::ops::Deref`")
}

test_verify_one_file_with_options! {
    #[test] deref_generic_use_err_deref_mut_tracked [] => verus_code! {
        use vstd::prelude::*;
        fn foo<T: std::ops::DerefMut>() { }
        fn foo2() {
            foo::<Tracked<u64>>();
        }
    } => Err(err) => assert_vir_error_msg(err, "reliance on trait bound `verus_builtin::Tracked<A>: core::ops::DerefMut`")
}

test_verify_one_file_with_options! {
    #[test] deref_generic_use_err_deref_ghost [] => verus_code! {
        use vstd::prelude::*;
        fn foo<T: std::ops::Deref>() { }
        fn foo2() {
            foo::<Ghost<u64>>();
        }
    } => Err(err) => assert_vir_error_msg(err, "reliance on trait bound `verus_builtin::Ghost<A>: core::ops::Deref`")
}

test_verify_one_file_with_options! {
    #[test] deref_generic_use_err_deref_mut_ghost [] => verus_code! {
        use vstd::prelude::*;
        fn foo<T: std::ops::DerefMut>() { }
        fn foo2() {
            foo::<Ghost<u64>>();
        }
    } => Err(err) => assert_vir_error_msg(err, "reliance on trait bound `verus_builtin::Ghost<A>: core::ops::DerefMut`")
}

test_verify_one_file_with_options! {
    #[test] tracked_deref_explicit [] => verus_code! {
        use std::ops::Deref;
        fn foo(x: Tracked<u64>) {
            let y: &u64 = x.deref();
        }
    } => Err(err) => assert_vir_error_msg(err, "not supported: using Tracked::deref")
}

test_verify_one_file_with_options! {
    #[test] tracked_deref_mut_explicit [] => verus_code! {
        use std::ops::DerefMut;
        fn foo(x: Tracked<u64>) {
            let mut x = x;
            let y: &mut u64 = x.deref_mut();
        }
    } => Err(err) => assert_vir_error_msg(err, "not supported: using Tracked::deref_mut")
}

test_verify_one_file_with_options! {
    #[test] write_in_proof_mode_with_decoration_1 [] => verus_code! {
        use vstd::prelude::*;
        tracked struct T { }
        proof fn test1(tracked m: &mut Box<T>) {
            *m = Box::new(T{});
        }
    } => Ok(())
}

test_verify_one_file_with_options! {
    #[test] write_in_proof_mode_with_decoration_2 [] => verus_code! {
        use vstd::prelude::*;
        tracked struct T { }
        proof fn test2(tracked m: &mut Box<T>) {
            **m = T {};
        }
    } => Ok(())
}

test_verify_one_file_with_options! {
    #[test] write_in_proof_mode_with_decoration_3 [] => verus_code! {
        tracked struct T { }
        proof fn test3<'a>(tracked m: &mut &'a T, tracked t_ref: &'a T) {
            *m = t_ref;
        }
    } => Ok(())
}

test_verify_one_file_with_options! {
    #[test] write_in_proof_mode_with_decoration_4 [] => verus_code! {
        use vstd::prelude::*;
        tracked struct T { }
        proof fn test4(tracked m: &mut Box<Tracked<T>>) {
            *m = Box::new(Tracked(T{}));
        }
    } => Err(err) => assert_vir_error_msg(err, "cannot mutate exec-mode place in proof-code")
}

test_verify_one_file_with_options! {
    #[test] write_in_proof_mode_with_decoration_5 [] => verus_code! {
        use vstd::prelude::*;
        tracked struct T { }
        proof fn test5(tracked m: &mut Box<Tracked<T>>) {
            **m = Tracked(T {});
        }
    } => Ok(())
}

test_verify_one_file_with_options! {
    #[test] write_in_proof_mode_with_decoration_6 [] => verus_code! {
        tracked struct T { }
        proof fn test6<'a>(tracked m: &mut &'a Tracked<T>, tracked t_ref: &'a Tracked<T>) {
            *m = t_ref;
        }
    } => Err(err) => assert_vir_error_msg(err, "cannot mutate exec-mode place in proof-code")
}

test_verify_one_file_with_options! {
    #[test] mut_ref_tracked1 [] => verus_code! {
        proof fn upd(tracked t: &mut Tracked<u64>)
            ensures **final(t) == 20
        {
            **t = 20;
        }

        fn test1() {
            let tracked mut u: u64 = 0;
            proof {
                upd(mut_ref_tracked(&mut u));
            }
            assert(u == 20);
        }

        fn fail1() {
            let tracked mut u: u64 = 0;
            proof {
                upd(mut_ref_tracked(&mut u));
            }
            assert(u == 20);
            assert(false); // FAILS
        }
    } => Err(err) => assert_fails(err, 1)
}

test_verify_one_file_with_options! {
    #[test] mut_ref_tracked2 [] => verus_code! {
        proof fn upd(tracked t: &mut Tracked<u64>)
            ensures **final(t) == 20
        {
            **t = 20;
        }

        fn test1(tracked u: &mut u64) {
            proof {
                upd(mut_ref_tracked(u));
            }
            assert(*u == 20);
        }
    } => Err(err) => assert_vir_error_msg(err, "cannot mutate exec-mode place in proof-code")
}

test_verify_one_file_with_options! {
    #[test] mut_ref_tracked3 [] => verus_code! {
        proof fn upd(tracked t: &mut Tracked<u64>)
            ensures **final(t) == 20
        {
            **t = 20;
        }

        fn test1(tracked u: &mut u64) {
            let mut u: u64 = 0;
            let z = mut_ref_tracked(&mut u);
        }
    } => Err(err) => assert_vir_error_msg(err, "cannot use `verus_builtin::mut_ref_tracked` in executable context")
}

test_verify_one_file_with_options! {
    #[test] mut_ref_tracked4 [] => verus_code! {
        proof fn upd(tracked t: &mut Tracked<u64>)
            ensures **final(t) == 20
        {
            **t = 20;
        }

        fn test1() {
            let mut u: u64 = 0;
            proof {
                upd(mut_ref_tracked(&mut u));
            }
            assert(u == 20);
        }
    } => Err(err) => assert_vir_error_msg(err, "cannot mutate exec-mode place in proof-code")
}

test_verify_one_file_with_options! {
    #[test] mut_ref_tracked5 [] => verus_code! {
        proof fn upd(tracked t: &mut X)
            ensures final(t).u == 20
        {
            t.u = 20;
        }

        tracked struct X { u: u64 }

        fn test1(tracked u: &mut X) {
            proof {
                upd(mut_ref_tracked(u));
            }
            assert(u.u == 20);
        }
    } => Ok(())
}

test_verify_one_file_with_options! {
    #[test] mut_ref_tracked6 [] => verus_code! {
        proof fn upd(tracked t: &mut X)
            ensures final(t).u == 20
        {
            t.u = 20;
        }

        struct X { u: u64 }

        fn test1(tracked u: &mut X) {
            proof {
                upd(mut_ref_tracked(u));
            }
            assert(u.u == 20);
        }
    } => Err(err) => assert_vir_error_msgs(err, &[
        "cannot mutate exec-mode place in proof-code",
        "cannot mutate exec-mode place in proof-code",
    ])
}

test_verify_one_file_with_options! {
    #[test] mut_ref_tracked7 [] => verus_code! {
        proof fn upd(tracked t: &mut Tracked<X>)
            ensures final(t).u == 20
        {
            t.u = 20;
        }

        struct X { u: u64 }

        fn test1(tracked u: &mut Tracked<X>) {
            proof {
                upd(mut_ref_tracked(u));
            }
            assert(u.u == 20);
        }
    } => Ok(())
}

test_verify_one_file_with_options! {
    #[test] mut_ref_tracked8 [] => verus_code! {
        proof fn upd(tracked t: &mut Tracked<u64>)
            ensures **final(t) == 20
        {
            **t = 20;
        }

        fn test1(tracked u: &mut u64) {
            proof {
                upd(mut_ref_tracked(&mut *u));
            }
            assert(*u == 20);
        }
    } => Err(err) => assert_vir_error_msg(err, "cannot mutate exec-mode place in proof-code")
}

test_verify_one_file_with_options! {
    #[test] mut_ref_tracked9_proph [] => verus_code! {
        proof fn upd(tracked t: &mut Tracked<u64>)
            ensures **final(t) == 20
        {
            **t = 20;
        }

        #[verifier::prophetic]
        uninterp spec fn cond() -> bool;

        fn test1() {
            let tracked mut u: u64 = 0;
            proof {
                if cond() {
                    **mut_ref_tracked(&mut u) = 19u64;
                }
            }
        }
    } => Err(err) => assert_vir_error_msg(err, "mutable borrow cannot occur in prophecy-conditional context")
}

test_verify_one_file_with_options! {
    #[test] mut_ref_tracked10_proph [] => verus_code! {
        proof fn upd(tracked t: &mut Tracked<u64>)
            ensures **final(t) == 20
        {
            **t = 20;
        }

        fn test1() {
            let tracked mut u: u64 = 0;
            proof {
                **mut_ref_tracked(&mut u) = 19u64;
            }
            assert(u == 19);
        }

        fn test1_fails() {
            let tracked mut u: u64 = 0;
            proof {
                **mut_ref_tracked(&mut u) = 19u64;
            }
            assert(u == 19);
            assert(false); // FAILS
        }
    } => Err(err) => assert_fails(err, 1)
}
