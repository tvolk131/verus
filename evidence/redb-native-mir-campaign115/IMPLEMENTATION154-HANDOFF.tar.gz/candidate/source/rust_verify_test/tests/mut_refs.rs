#![feature(rustc_private)]
#[macro_use]
mod common;
use common::*;

test_verify_one_file_with_options! {
    #[test] test_basic [] => verus_code! {
        fn test_no_update() {
            let mut u: u64 = 20;
            let u_ref: &mut u64 = &mut u;

            assert(u == 20);
        }

        fn test_basic_update() {
            let mut u: u64 = 20;
            let u_ref: &mut u64 = &mut u;

            *u_ref = 30;

            assert(u == 30);
        }

        struct Pair<A, B>(A, B);

        fn test_field_update() {
            let mut u: Pair<u64, u64> = Pair(20, 20);
            let u_ref: &mut Pair<u64, u64> = &mut u;

            u_ref.0 = 30;

            assert(u.0 == 30);
            assert(u.1 == 20);
        }

        fn test_field_update2() {
            let mut u: Pair<u64, u64> = Pair(20, 20);
            let u_ref: &mut u64 = &mut u.0;

            *u_ref = 30;

            assert(u.0 == 30);
            assert(u.1 == 20);
        }

        fn test_mut_ref_in_pair() {
            let mut u: u64 = 20;
            let u_ref: Pair<&mut u64, u64> = Pair { 0: &mut u, 1: 70 };

            *u_ref.0 = 30;

            proof {
                assert(has_resolved(u_ref.0));
            }

            assert(u == 30);
        }

        fn test_reborrow() {
            let mut u: u64 = 20;
            let u_ref: &mut u64 = &mut u;

            *u_ref = 11;

            let u_ref2 = &mut *u_ref;

            let x = *u_ref2;
            assert(x == 11);
            *u_ref2 = 13;

            let x = *u_ref;
            assert(x == 13);

            *u_ref = 17;

            assert(u == 17);
        }
    } => Ok(())
}

test_verify_one_file_with_options! {
    #[test] test_paren_ctors_with_mut_refs [] => verus_code! {
        struct Pair<A, B>(A, B);

        fn test_mut_ref_in_pair() {
            let mut u: u64 = 20;
            let u_ref: Pair<&mut u64, u64> = Pair(&mut u, 70);

            *u_ref.0 = 30;

            proof {
                assert(has_resolved(u_ref.0));
            }

            assert(u == 30);
        }
    } => Ok(())
}

test_verify_one_file_with_options! {
    #[test] test_spec_functions_ok [] => verus_code! {
        spec fn test<T>(x: &mut T) -> T {
            mut_ref_current(x)
        }

        #[verifier::prophetic]
        spec fn test1<T>(x: &mut T) -> T {
            mut_ref_future(x)
        }

        #[verifier::prophetic]
        spec fn test2<T>(x: &mut T) -> bool {
            has_resolved(x)
        }

        #[verifier::prophetic]
        spec fn test3<T>(x: &mut T) -> T {
            *final(x)
        }
    } => Ok(())
}

test_verify_one_file_with_options! {
    #[test] test_mut_ref_future_proph [] => verus_code! {
        spec fn test<T>(x: &mut T) -> T {
            mut_ref_future(x)
        }
    } => Err(err) => assert_vir_error_msg(err, "prophetic value not allowed for body of non-prophetic spec function")
}

test_verify_one_file_with_options! {
    #[test] test_fin_proph [] => verus_code! {
        spec fn test<T>(x: &mut T) -> T {
            *final(x)
        }
    } => Err(err) => assert_vir_error_msg(err, "prophetic value not allowed for body of non-prophetic spec function")
}

test_verify_one_file_with_options! {
    #[test] test_resolved_proph [] => verus_code! {
        spec fn test<T>(x: &mut T) -> bool {
            has_resolved(x)
        }
    } => Err(err) => assert_vir_error_msg(err, "prophetic value not allowed for body of non-prophetic spec function")
}

test_verify_one_file_with_options! {
    #[test] test_after_borrow_proph [] => verus_code! {
        fn test() {
            let mut x = 0;
            let x_ref = &mut x;

            let y = Ghost(after_borrow(x));

            *x_ref = 20;
        }
    } => Err(err) => assert_vir_error_msg(err, "prophetic value not allowed for 'Ghost' wrapper")
}

test_verify_one_file_with_options! {
    #[test] test_after_borrow_ok [] => verus_code! {
        fn test() {
            let mut x = 0;
            let x_ref = &mut x;

            assert(*final(x_ref) == after_borrow(x));

            *x_ref = 20;
        }
    } => Ok(())
}

test_verify_one_file_with_options! {
    #[test] test_after_borrow_bad_expr [] => verus_code! {
        fn test() {
            let mut x = 0;
            let x_ref = &mut x;

            assert(after_borrow(true) == true);

            *x_ref = 20;
        }
    } => Err(err) => assert_vir_error_msg(err, "`after_borrow` expects a local variable, possibly with dereferences or field accesses")
}

test_verify_one_file_with_options! {
    #[test] mut_ref_not_extensional [] => verus_code! {
        // &mut T doesn't have extensionality because that would cause (==) to be
        // a prophetic operator

        fn test1(a: &mut u64, b: &mut u64) {
            assume(mut_ref_current(a) == mut_ref_current(b)
                && mut_ref_future(a) == mut_ref_future(b));
            assert(a == b); // FAILS
        }

        fn test2(a: &mut u64, b: &mut u64) {
            assume(mut_ref_current(a) == mut_ref_current(b)
                && mut_ref_future(a) == mut_ref_future(b));
            assert(a =~= b); // FAILS
        }

        fn test3(a: &mut u64, b: &mut u64) {
            assume(mut_ref_current(a) == mut_ref_current(b)
                && mut_ref_future(a) == mut_ref_future(b));
            assert(a =~~= b); // FAILS
        }
    } => Err(err) => assert_fails(err, 3)
}

test_verify_one_file_with_options! {
    #[test] test_resolved_axioms [] => verus_code! {
        use vstd::prelude::*;

        proof fn test_pair<A, B>(pair: (A, B)) {
            assert(has_resolved(pair) ==> has_resolved(pair.0));
            assert(has_resolved(pair) ==> has_resolved(pair.1));
        }

        proof fn test_option<A>(opt: Option<A>) {
            assert(match opt {
                Some(o) => {
                    has_resolved(opt) ==> has_resolved(o)
                }
                None => true,
            });
        }

        struct Pair<A, B> {
            x: A,
            y: B,
        }

        proof fn test_pair_struct<A, B>(pair: Pair<A, B>) {
            assert(has_resolved(pair) ==> has_resolved(pair.x));
            assert(has_resolved(pair) ==> has_resolved(pair.y));
        }

        proof fn test_box<A>(b: Box<A>) {
            assert(has_resolved(b) ==> has_resolved(*b));
        }

        proof fn test_tracked<A>(t: Tracked<A>) {
            assert(has_resolved(t) ==> has_resolved(t@));
        }

        proof fn test_ghost_fail<A>(t: Ghost<A>) {
            assert(has_resolved(t) ==> has_resolved(t@)); // FAILS
        }

        proof fn test_ref_fail<A>(t: &A) {
            assert(has_resolved(t) ==> has_resolved(*t)); // FAILS
        }

        proof fn test_rc_fail<A>(t: std::rc::Rc<A>) {
            assert(has_resolved(t) ==> has_resolved(*t)); // FAILS
        }

        proof fn test_arc_fail<A>(t: std::sync::Arc<A>) {
            assert(has_resolved(t) ==> has_resolved(*t)); // FAILS
        }

        proof fn test_mut_ref<A>(t: &mut A) {
            assert(has_resolved(t) ==> mut_ref_current(t) == mut_ref_future(t));
        }

        proof fn test_mut_ref_fail<A>(t: &mut A) {
            assert(has_resolved(t) ==> has_resolved(mut_ref_current(t))); // FAILS
        }

        proof fn test_mut_ref_fail2<A>(t: &mut A) {
            assert(has_resolved(t) ==> has_resolved(mut_ref_future(t))); // FAILS
        }
    } => Err(err) => assert_fails(err, 6)
}

test_verify_one_file_with_options! {
    #[test] test_resolve_axioms_in_context [] => verus_code! {
        use vstd::prelude::*;

        fn resolve<T>(t: T)
            ensures has_resolved(t)
        { }

        fn box_with_mut_ref() {
            let mut x: u64 = 0;

            let x_ref = &mut x;
            let x_ref_box = Box::new(x_ref);

            **x_ref_box = 13;

            resolve(x_ref_box);

            // TODO(new_mut_ref): (triggers) without this line, Verus doesn't emit the axiom for
            // has_resolved::<Box<_>>
            assert(has_resolved(x_ref_box));

            assert(x == 13);
        }

        fn shr_ref_with_mut_ref() {
            let mut x: u64 = 0;

            let x_ref = &mut x;
            let x_ref_ref = &x_ref;

            resolve(x_ref_ref);

            assert(has_resolved(x_ref)); // FAILS

            *x_ref = 20;
            resolve(x_ref);
        }

        fn mut_ref_with_mut_ref() {
            let mut x: u64 = 0;

            let mut x_ref = &mut x;
            let x_ref_ref = &mut x_ref;

            **x_ref_ref = 20;

            resolve(x_ref_ref);

            assert(has_resolved(x_ref)); // FAILS

            *x_ref = 30;
            resolve(x_ref);
        }
    } => Err(err) => assert_fails(err, 2)
}

test_verify_one_file_with_options! {
    #[test] test_nested_mut_refs [] => verus_code! {
        fn test_nested() {
            let mut x: u64 = 0;
            let mut y: u64 = 10;

            let mut x_ref = &mut x;
            *x_ref = 20;

            assert(x == 20);

            x_ref = &mut y;
            *x_ref = 30;

            assert(y == 30);
        }

        fn test_nested2() {
            let mut x: u64 = 0;
            let mut y: u64 = 1;
            let mut z: u64 = 2;
            let mut w: u64 = 3;
            let mut v: u64 = 4;

            let mut ref1 = &mut x;
            let mut ref11 = &mut ref1;
            **ref11 = 10;

            let mut ref2 = &mut y;
            let mut ref22 = &mut ref2;
            **ref22 = 20;

            let mut ref3 = &mut z;
            *ref11 = ref3;
            **ref11 = 30;

            let mut ref4 = &mut w;
            ref11 = &mut ref4;
            **ref11 = 40;

            **(&mut &mut v) = 50;

            assert(x == 10);
            assert(y == 20);
            assert(z == 30);
            assert(w == 40);
            assert(v == 50);
        }

        fn test_nested_fails() {
            let mut x: u64 = 0;
            let mut y: u64 = 10;

            let mut x_ref = &mut x;
            *x_ref = 20;

            assert(x == 20);

            x_ref = &mut y;
            *x_ref = 30;

            assert(y == 30);
            assert(false); // FAILS
        }

        fn test_nested2_fails() {
            let mut x: u64 = 0;
            let mut y: u64 = 1;
            let mut z: u64 = 2;
            let mut w: u64 = 3;
            let mut v: u64 = 4;

            let mut ref1 = &mut x;
            let mut ref11 = &mut ref1;
            **ref11 = 10;

            let mut ref2 = &mut y;
            let mut ref22 = &mut ref2;
            **ref22 = 20;

            let mut ref3 = &mut z;
            *ref11 = ref3;
            **ref11 = 30;

            let mut ref4 = &mut w;
            ref11 = &mut ref4;
            **ref11 = 40;

            **(&mut &mut v) = 50;

            assert(x == 10);
            assert(y == 20);
            assert(z == 30);
            assert(w == 40);
            assert(v == 50);
            assert(false); // FAILS
        }
    } => Err(err) => assert_fails(err, 2)
}

test_verify_one_file_with_options! {
    #[test] test_structs_and_boxes [] => verus_code! {
        use vstd::prelude::*;

        struct X<'a> {
            a: (u64, Box<(&'a mut u64, u64)>),
        }

        fn test() {
            let mut u: u64 = 0;

            let mut x = X {
                a: (0, Box::new((&mut u, 20))),
            };

            assert(has_resolved(x.a.1.0)); // TODO(new_mut_ref): (triggers) should be automatic

            assert(u == 0);
        }

        fn test2() {
            let mut u: u64 = 0;

            let mut x = X {
                a: (0, Box::new((&mut u, 20))),
            };
            *x.a.1.0 = 30;

            assert(u == 30);
        }

        fn test3() {
            let mut u: u64 = 0;
            let mut v: u64 = 0;

            let mut x = X {
                a: (0, Box::new((&mut u, 20))),
            };
            *x.a.1.0 = 30;

            x.a.1 = Box::new((&mut v, 100));
            *x.a.1.0 = 90;

            assert(u == 30);
            assert(v == 90);
        }

        fn test4() {
            let mut u: u64 = 0;
            let mut v: u64 = 0;

            let mut x = X {
                a: (0, Box::new((&mut u, 20))),
            };
            *x.a.1.0 = 30;

            x.a.1.0 = &mut v;
            *x.a.1.0 = 90;

            assert(u == 30);
            assert(v == 90);
        }

        fn test_fails() {
            let mut u: u64 = 0;

            let mut x = X {
                a: (0, Box::new((&mut u, 20))),
            };

            assert(has_resolved(x.a.1.0)); // TODO(new_mut_ref): (triggers) should be automatic

            assert(u == 0);
            assert(false); // FAILS
        }

        fn test2_fails() {
            let mut u: u64 = 0;

            let mut x = X {
                a: (0, Box::new((&mut u, 20))),
            };
            *x.a.1.0 = 30;

            assert(u == 30);
            assert(false); // FAILS
        }

        fn test3_fails() {
            let mut u: u64 = 0;
            let mut v: u64 = 0;

            let mut x = X {
                a: (0, Box::new((&mut u, 20))),
            };
            *x.a.1.0 = 30;

            x.a.1 = Box::new((&mut v, 100));
            *x.a.1.0 = 90;

            assert(u == 30);
            assert(v == 90);
            assert(false); // FAILS
        }

        fn test4_fails() {
            let mut u: u64 = 0;
            let mut v: u64 = 0;

            let mut x = X {
                a: (0, Box::new((&mut u, 20))),
            };
            *x.a.1.0 = 30;

            x.a.1.0 = &mut v;
            *x.a.1.0 = 90;

            assert(u == 30);
            assert(v == 90);
            assert(false); // FAILS
        }
    } => Err(err) => assert_fails(err, 4)
}

test_verify_one_file_with_options! {
    #[test] test_structs_and_boxes_double_nested [] => verus_code! {
        use vstd::prelude::*;

        struct X<'a, 'b> {
            a: (u64, Box<(&'a mut (u64, &'b mut (u64, u64)), u64)>),
        }

        fn test() {
            let mut pair: (u64, u64) = (0, 1);
            let mut pair_ref_pair = (3, &mut pair);
            let mut x = X {
                a: (0, Box::new((&mut pair_ref_pair, 4))),
            };
            assert(has_resolved(x.a.1.0)); // TODO(new_mut_ref): (triggers) should be automatic
            assert(has_resolved(pair_ref_pair.1));
            assert(pair == (0, 1));
        }

        fn test2() {
            let mut pair: (u64, u64) = (0, 1);
            let mut pair_ref_pair = (3, &mut pair);
            let mut x = X {
                a: (0, Box::new((&mut pair_ref_pair, 4))),
            };
            x.a.1.0.1.1 = 19;
            assert(has_resolved(x.a.1.0));
            assert(has_resolved(pair_ref_pair.1));
            assert(pair == (0, 19));
        }

        fn test3() {
            let mut pair: (u64, u64) = (0, 1);
            let mut pair_ref_pair = (3, &mut pair);

            let mut pair2: (u64, u64) = (2, 3);
            let mut pair2_ref_pair = (3, &mut pair2);

            let mut x = X {
                a: (0, Box::new((&mut pair_ref_pair, 4))),
            };

            x.a = (17, Box::new((&mut pair2_ref_pair, 5)));
            x.a.1.0.1.1 = 19;

            assert(has_resolved(x.a.1.0));
            assert(has_resolved(pair_ref_pair.1));
            assert(has_resolved(pair2_ref_pair.1));

            assert(pair == (0, 1));
            assert(pair2 == (2, 19));
        }

        fn test4() {
            let mut pair: (u64, u64) = (0, 1);
            let mut pair_ref_pair = (3, &mut pair);

            let mut pair2: (u64, u64) = (2, 3);
            let mut pair2_ref_pair = (3, &mut pair2);

            let mut x = X {
                a: (0, Box::new((&mut pair_ref_pair, 4))),
            };

            x.a = (17, Box::new((&mut pair2_ref_pair, 5)));
            x.a.1.0.0 = 19;

            assert(has_resolved(x.a.1.0));
            assert(has_resolved(pair_ref_pair.1));
            assert(has_resolved(pair2_ref_pair.1));

            assert(pair == (0, 1));
            assert(pair2 == (2, 3));
            assert(pair_ref_pair.0 == 3);
            assert(pair2_ref_pair.0 == 19);
        }

        fn test5() {
            let mut pair: (u64, u64) = (0, 1);
            let mut pair_ref_pair = (3, &mut pair);

            let mut pair2: (u64, u64) = (2, 3);
            let mut pair2_ref_pair = (3, &mut pair2);

            pair_ref_pair.1.0 = 23;
            pair2_ref_pair.1.0 = 24;

            let mut x = X {
                a: (0, Box::new((&mut pair_ref_pair, 4))),
            };

            x.a = (17, Box::new((&mut pair2_ref_pair, 5)));
            x.a.1.0.0 = 19;

            assert(has_resolved(x.a.1.0));
            assert(has_resolved(pair_ref_pair.1));
            assert(has_resolved(pair2_ref_pair.1));

            assert(pair == (23, 1));
            assert(pair2 == (24, 3));
            assert(pair_ref_pair.0 == 3);
            assert(pair2_ref_pair.0 == 19);
        }

        fn test_fails() {
            let mut pair: (u64, u64) = (0, 1);
            let mut pair_ref_pair = (3, &mut pair);
            let mut x = X {
                a: (0, Box::new((&mut pair_ref_pair, 4))),
            };
            assert(has_resolved(x.a.1.0)); // TODO(new_mut_ref): (triggers) should be automatic
            assert(has_resolved(pair_ref_pair.1));
            assert(pair == (0, 1));
            assert(false); // FAILS
        }

        fn test2_fails() {
            let mut pair: (u64, u64) = (0, 1);
            let mut pair_ref_pair = (3, &mut pair);
            let mut x = X {
                a: (0, Box::new((&mut pair_ref_pair, 4))),
            };
            x.a.1.0.1.1 = 19;
            assert(has_resolved(x.a.1.0));
            assert(has_resolved(pair_ref_pair.1));
            assert(pair == (0, 19));
            assert(false); // FAILS
        }

        fn test3_fails() {
            let mut pair: (u64, u64) = (0, 1);
            let mut pair_ref_pair = (3, &mut pair);

            let mut pair2: (u64, u64) = (2, 3);
            let mut pair2_ref_pair = (3, &mut pair2);

            let mut x = X {
                a: (0, Box::new((&mut pair_ref_pair, 4))),
            };

            x.a = (17, Box::new((&mut pair2_ref_pair, 5)));
            x.a.1.0.1.1 = 19;

            assert(has_resolved(x.a.1.0));
            assert(has_resolved(pair_ref_pair.1));
            assert(has_resolved(pair2_ref_pair.1));

            assert(pair == (0, 1));
            assert(pair2 == (2, 19));
            assert(false); // FAILS
        }

        fn test4_fails() {
            let mut pair: (u64, u64) = (0, 1);
            let mut pair_ref_pair = (3, &mut pair);

            let mut pair2: (u64, u64) = (2, 3);
            let mut pair2_ref_pair = (3, &mut pair2);

            let mut x = X {
                a: (0, Box::new((&mut pair_ref_pair, 4))),
            };

            x.a = (17, Box::new((&mut pair2_ref_pair, 5)));
            x.a.1.0.0 = 19;

            assert(has_resolved(x.a.1.0));
            assert(has_resolved(pair_ref_pair.1));
            assert(has_resolved(pair2_ref_pair.1));

            assert(pair == (0, 1));
            assert(pair2 == (2, 3));
            assert(pair_ref_pair.0 == 3);
            assert(pair2_ref_pair.0 == 19);
            assert(false); // FAILS
        }

        fn test5_fails() {
            let mut pair: (u64, u64) = (0, 1);
            let mut pair_ref_pair = (3, &mut pair);

            let mut pair2: (u64, u64) = (2, 3);
            let mut pair2_ref_pair = (3, &mut pair2);

            pair_ref_pair.1.0 = 23;
            pair2_ref_pair.1.0 = 24;

            let mut x = X {
                a: (0, Box::new((&mut pair_ref_pair, 4))),
            };

            x.a = (17, Box::new((&mut pair2_ref_pair, 5)));
            x.a.1.0.0 = 19;

            assert(has_resolved(x.a.1.0));
            assert(has_resolved(pair_ref_pair.1));
            assert(has_resolved(pair2_ref_pair.1));

            assert(pair == (23, 1));
            assert(pair2 == (24, 3));
            assert(pair_ref_pair.0 == 3);
            assert(pair2_ref_pair.0 == 19);
            assert(false); // FAILS
        }
    } => Err(err) => assert_fails(err, 5)
}

test_verify_one_file_with_options! {
    #[test] control_flow_match_on_never [] => verus_code! {
        #[allow(unreachable_code)]
        fn test(x: !) {
            let mut y = 0;
            let y_ref = &mut y;

            assert(has_resolved(y_ref));

            match x { }

            *y_ref = 20;
        }
    } => Err(err) => assert_vir_error_msg(err, "not yet implemented: zero-arm match expressions")
}

test_verify_one_file_with_options! {
    #[test] control_flow_conditional [] => verus_code! {
        fn test(b: bool) {
            let mut x: u64 = 0;
            let mut x_ref = &mut x;

            if b {
                *x_ref = 20;
            } else {
                *x_ref = 30;
            }

            assert(x == (if b { 20u64 } else { 30 }));
        }

        fn test_fails(b: bool) {
            let mut x: u64 = 0;
            let mut x_ref = &mut x;

            if b {
                *x_ref = 20;
            } else {
                *x_ref = 30;
            }

            assert(false); // FAILS
        }

        fn test2(b: bool) {
            let mut x: u64 = 0;
            let mut x_ref = &mut x;

            if b {
                *x_ref = 20;
            } else {
                assert(has_resolved(x_ref)); // FAILS
            }

            *x_ref = 30;
        }

        fn test3(b: bool) {
            let mut x: u64 = 0;
            let mut x_ref = &mut x;

            if b {
                *x_ref = 20;
                assert(has_resolved(x_ref)); // FAILS
            } else {
            }

            *x_ref = 30;
        }

        fn test4(b: bool) {
            let mut x: u64 = 0;
            let mut x_ref = &mut x;

            if b {
                *x_ref = 20;
                assert(has_resolved(x_ref));
            } else {
                assert(has_resolved(x_ref));
            }
        }

        fn test5(b: bool) {
            let mut x: u64 = 0;
            let mut x_ref = &mut x;

            if b {
                assert(has_resolved(x_ref)); // FAILS
                *x_ref = 20;
            } else {
            }
        }

        fn test6(b: bool) {
            let mut x: u64 = 0;
            let mut x_ref = &mut x;

            if b {
            } else {
                assert(has_resolved(x_ref)); // FAILS
                *x_ref = 20;
            }
        }

        fn test7(b: bool) {
            let mut x: u64 = 0;
            let mut x_ref = &mut x;

            if b {
                assert(has_resolved(x_ref));
                return;
            } else {
            }

            *x_ref = 20;
        }

        fn test8(b: bool) {
            let mut x: u64 = 0;
            let mut x_ref = &mut x;

            if b {
                return;
            } else {
                assert(has_resolved(x_ref)); // FAILS
            }

            *x_ref = 20;
        }
    } => Err(err) => assert_fails(err, 6)
}

test_verify_one_file_with_options! {
    #[test] control_flow_conditional_2 [] => verus_code! {
        fn test(b: bool) {
            let mut x: u64 = 0;
            let mut x_ref = &mut x;

            assert(has_resolved(x_ref)); // FAILS

            if b {
                *x_ref = 20;
            } else {
            }
        }

        fn test2(b: bool) {
            let mut x: u64 = 0;
            let mut x_ref = &mut x;

            assert(has_resolved(x_ref)); // FAILS

            if b {
            } else {
                *x_ref = 20;
            }
        }

        fn test3(b: bool) {
            let mut x: u64 = 0;
            let mut x_ref = &mut x;

            assert(has_resolved(x_ref)); // FAILS

            if b {
            } else {
            }

            *x_ref = 20;
        }

        fn test4(b: bool) {
            let mut x: u64 = 0;
            let mut x_ref = &mut x;

            assert(has_resolved(x_ref));

            if b {
            } else {
            }
        }
    } => Err(err) => assert_fails(err, 3)
}

test_verify_one_file_with_options! {
    #[test] control_flow_conditional_with_pair [] => verus_code! {
        fn test(b: bool) {
            let mut x: u64 = 0;
            let mut y: u64 = 0;
            let mut x_ref = (&mut x, &mut y);

            if b {
                *x_ref.0 = 20;
            } else {
                *x_ref.1 = 30;
            }

            assert(x == (if b { 20u64 } else { 0 }));
            assert(y == (if b { 0u64 } else { 30 }));
        }

        fn test_fails(b: bool) {
            let mut x: u64 = 0;
            let mut y: u64 = 0;
            let mut x_ref = (&mut x, &mut y);

            if b {
                assert(has_resolved(x_ref.1));
                *x_ref.0 = 20;
                assert(has_resolved(x_ref.0));
            } else {
                assert(has_resolved(x_ref.0));
                *x_ref.1 = 30;
                assert(has_resolved(x_ref.1));
            }

            assert(x == (if b { 20u64 } else { 0 }));
            assert(y == (if b { 0u64 } else { 30 }));
            assert(b); // FAILS
        }

        fn test_fails2(b: bool) {
            let mut x: u64 = 0;
            let mut y: u64 = 0;
            let mut x_ref = (&mut x, &mut y);

            if b {
                assert(has_resolved(x_ref.1));
                *x_ref.0 = 20;
                assert(has_resolved(x_ref.0));
            } else {
                assert(has_resolved(x_ref.0));
                *x_ref.1 = 30;
                assert(has_resolved(x_ref.1));
            }

            assert(x == (if b { 20u64 } else { 0 }));
            assert(y == (if b { 0u64 } else { 30 }));
            assert(!b); // FAILS
        }
    } => Err(err) => assert_fails(err, 2)
}

test_verify_one_file_with_options! {
    #[test] control_flow_bin_ops_short_circuiting [] => verus_code! {
        fn test_and_1(arg1: u64, arg2: u64) {
            let mut x = 0;
            let mut y = 0;
            let mut x_ref = &mut x;

            // this succeeds because `x_ref = &mut y` is reached before `*x_ref = 30`
            assert(has_resolved(x_ref));

            if ({ x_ref = &mut y; arg1 == 0 }) && arg2 == 0 {
            }

            *x_ref = 30;
        }

        fn test_and_2(arg1: u64, arg2: u64) {
            let mut x = 0;
            let mut y = 0;
            let mut x_ref = &mut x;

            // this fails because `x_ref = &mut y` might not be reached
            assert(has_resolved(x_ref)); // FAILS

            if arg1 == 0 && ({ x_ref = &mut y; arg2 == 0 }) {
            }

            *x_ref = 30;
        }

        fn test_and_3(arg1: u64, arg2: u64) {
            let mut x = 0;
            let mut y = 0;
            let mut x_ref = &mut x;

            assert(has_resolved(x_ref)); // FAILS

            if arg1 == 0 && ({ *x_ref = 30; arg2 == 0 }) {
            }
        }

        fn test_or_1(arg1: u64, arg2: u64) {
            let mut x = 0;
            let mut y = 0;
            let mut x_ref = &mut x;

            // this succeeds because `x_ref = &mut y` is reached before `*x_ref = 30`
            assert(has_resolved(x_ref));

            if ({ x_ref = &mut y; arg1 == 0 }) || arg2 == 0 {
            }

            *x_ref = 30;
        }

        fn test_or_2(arg1: u64, arg2: u64) {
            let mut x = 0;
            let mut y = 0;
            let mut x_ref = &mut x;

            // this fails because `x_ref = &mut y` might not be reached
            assert(has_resolved(x_ref)); // FAILS

            if arg1 == 0 || ({ x_ref = &mut y; arg2 == 0 }) {
            }

            *x_ref = 30;
        }

        fn test_or_3(arg1: u64, arg2: u64) {
            let mut x = 0;
            let mut y = 0;
            let mut x_ref = &mut x;

            assert(has_resolved(x_ref)); // FAILS

            if arg1 == 0 || ({ *x_ref = 30; arg2 == 0 }) {
            }
        }

        fn test_ineq_1(arg1: u64, arg2: u64) {
            let mut x = 0;
            let mut y = 0;
            let mut x_ref = &mut x;

            // this succeeds because `x_ref = &mut y` is reached before `*x_ref = 30`
            assert(has_resolved(x_ref));

            if ({ x_ref = &mut y; arg1 }) < arg2 {
            }

            *x_ref = 30;
        }

        fn test_ineq_2(arg1: u64, arg2: u64) {
            let mut x = 0;
            let mut y = 0;
            let mut x_ref = &mut x;

            // succeeds becasue < has no short-circuiting
            assert(has_resolved(x_ref));

            if arg1 < ({ x_ref = &mut y; arg2 }) {
            }

            *x_ref = 30;
        }

        fn test_ineq_3(arg1: u64, arg2: u64) {
            let mut x = 0;
            let mut y = 0;
            let mut x_ref = &mut x;

            assert(has_resolved(x_ref)); // FAILS

            if arg1 < ({ *x_ref = 30; arg2 }) {
            }
        }
    } => Err(err) => assert_fails(err, 5)
}

test_verify_one_file_with_options! {
    #[test] control_flow_bin_ops_short_circuiting2 [] => verus_code! {
        fn test_and_1(arg1: u64, arg2: u64) {
            let mut x = 0;
            let mut y = 0;
            let mut x_ref = &mut x;

            if ({ x_ref = &mut y; arg1 == 0 }) && arg2 == 0 {
            }

            *x_ref = 30;

            assert(x == 0);
            assert(y == 30);
        }

        fn test_and_2(arg1: u64, arg2: u64) {
            let mut x = 0;
            let mut y = 0;
            let mut x_ref = &mut x;

            if arg1 == 0 && ({ x_ref = &mut y; arg2 == 0 }) {
            }

            *x_ref = 30;

            assert(arg1 == 0 ==> x == 0);
            assert(arg1 == 0 ==> y == 30);

            assert(arg1 != 0 ==> x == 30);
            assert(arg1 != 0 ==> y == 0);
        }

        fn test_and_3(arg1: u64, arg2: u64) {
            let mut x = 0;
            let mut y = 0;
            let mut x_ref = &mut x;

            if arg1 == 0 && ({ *x_ref = 30; arg2 == 0 }) {
            }

            assert(arg1 == 0 ==> x == 30);
            assert(arg1 == 0 ==> y == 0);

            assert(arg1 != 0 ==> x == 0);
            assert(arg1 != 0 ==> y == 0);
        }

        fn test_and_1_fails(arg1: u64, arg2: u64) {
            let mut x = 0;
            let mut y = 0;
            let mut x_ref = &mut x;

            if ({ x_ref = &mut y; arg1 == 0 }) && arg2 == 0 {
            }

            *x_ref = 30;

            assert(x == 0);
            assert(y == 30);
            assert(arg1 == 0); // FAILS
        }

        fn test_and_2_fails(arg1: u64, arg2: u64) {
            let mut x = 0;
            let mut y = 0;
            let mut x_ref = &mut x;

            if arg1 == 0 && ({ x_ref = &mut y; arg2 == 0 }) {
            }

            *x_ref = 30;

            assert(arg1 == 0 ==> x == 0);
            assert(arg1 == 0 ==> y == 30);

            assert(arg1 != 0 ==> x == 30);
            assert(arg1 != 0 ==> y == 0);

            assert(arg1 == 0); // FAILS
        }

        fn test_and_3_fails(arg1: u64, arg2: u64) {
            let mut x = 0;
            let mut y = 0;
            let mut x_ref = &mut x;

            if arg1 == 0 && ({ *x_ref = 30; arg2 == 0 }) {
            }

            assert(arg1 == 0 ==> x == 30);
            assert(arg1 == 0 ==> y == 0);

            assert(arg1 != 0 ==> x == 0);
            assert(arg1 != 0 ==> y == 0);

            assert(arg1 == 0); // FAILS
        }

        fn test_and_1_fails2(arg1: u64, arg2: u64) {
            let mut x = 0;
            let mut y = 0;
            let mut x_ref = &mut x;

            if ({ x_ref = &mut y; arg1 == 0 }) && arg2 == 0 {
            }

            *x_ref = 30;

            assert(x == 0);
            assert(y == 30);
            assert(arg1 != 0); // FAILS
        }

        fn test_and_2_fails2(arg1: u64, arg2: u64) {
            let mut x = 0;
            let mut y = 0;
            let mut x_ref = &mut x;

            if arg1 == 0 && ({ x_ref = &mut y; arg2 == 0 }) {
            }

            *x_ref = 30;

            assert(arg1 == 0 ==> x == 0);
            assert(arg1 == 0 ==> y == 30);

            assert(arg1 != 0 ==> x == 30);
            assert(arg1 != 0 ==> y == 0);

            assert(arg1 != 0); // FAILS
        }

        fn test_and_3_fails2(arg1: u64, arg2: u64) {
            let mut x = 0;
            let mut y = 0;
            let mut x_ref = &mut x;

            if arg1 == 0 && ({ *x_ref = 30; arg2 == 0 }) {
            }

            assert(arg1 == 0 ==> x == 30);
            assert(arg1 == 0 ==> y == 0);

            assert(arg1 != 0 ==> x == 0);
            assert(arg1 != 0 ==> y == 0);

            assert(arg1 != 0); // FAILS
        }
    } => Err(err) => assert_fails(err, 6)
}

test_verify_one_file_with_options! {
    #[test] uninitialized [] => verus_code! {
        fn test_uninit(b: bool) {
            let mut x = 0;
            let x_ref: &mut u64;

            if b {
                x_ref = &mut x;
                assert(has_resolved(x_ref));
            }
        }

        fn test_uninit_fails(b: bool) {
            let mut x = 0;
            let x_ref: &mut u64;

            assert(has_resolved(x_ref)); // FAILS

            if b {
                x_ref = &mut x;
            }
        }

        fn test_uninit_fails2(b: bool) {
            let mut x = 0;
            let x_ref: &mut u64;

            if b {
                x_ref = &mut x;
            }

            assert(has_resolved(x_ref)); // FAILS
        }
    } => Err(err) => assert_fails(err, 2)
}

test_verify_one_file_with_options! {
    #[test] control_flow_never [] => verus_code! {
        fn some_bool() -> bool { true }

        #[verifier::exec_allows_no_decreases_clause]
        fn did_he_ever_return_no_he_never_returned() -> ! {
            loop { }
        }

        #[verifier::exec_allows_no_decreases_clause]
        fn test() {
            let mut x = 0;
            let x_ref = &mut x;

            if some_bool() {
                *x_ref = 40;
            } else {
                *x_ref = 30;
                assert(has_resolved(x_ref));
                loop { }
            }

            *x_ref = 20;
        }

        #[verifier::exec_allows_no_decreases_clause]
        fn test2() {
            let mut x = 0;
            let x_ref = &mut x;

            if some_bool() {
                *x_ref = 40;
                assert(has_resolved(x_ref)); // FAILS
            } else {
                *x_ref = 30;
                loop { }
            }

            *x_ref = 20;
        }

        #[verifier::exec_allows_no_decreases_clause]
        fn test3() {
            let mut x = 0;
            let x_ref = &mut x;

            if some_bool() {
                *x_ref = 40;
            } else {
                *x_ref = 30;
                assert(has_resolved(x_ref));
                did_he_ever_return_no_he_never_returned()
            }

            *x_ref = 20;
        }

        #[verifier::exec_allows_no_decreases_clause]
        fn test4() {
            let mut x = 0;
            let x_ref = &mut x;

            if some_bool() {
                *x_ref = 40;
                assert(has_resolved(x_ref)); // FAILS
            } else {
                *x_ref = 30;
                did_he_ever_return_no_he_never_returned()
            }

            *x_ref = 20;
        }
    } => Err(err) => assert_fails(err, 2)
}

test_verify_one_file_with_options! {
    #[test] let_decl_partial_move [] => verus_code! {
        struct X<'a, 'b, 'c, 'd> {
            f1: (&'a mut u64, &'b mut u64),
            f2: (&'c mut u64, &'d mut u64),
        }

        fn test() {
            let mut a = 0;
            let mut b = 0;
            let mut c = 0;
            let mut d = 0;

            let x = X { f1: (&mut a, &mut b), f2: (&mut c, &mut d) };

            let X { f1: (z, _), f2: (_, w) } = x;

            *z = 13;
            *w = 14;

            *x.f1.1 = 15;
            *x.f2.0 = 16;

            assert(a == 13);
            assert(b == 15);
            assert(c == 16);
            assert(d == 14);
        }

        fn test_fails() {
            let mut a = 0;
            let mut b = 0;
            let mut c = 0;
            let mut d = 0;

            let x = X { f1: (&mut a, &mut b), f2: (&mut c, &mut d) };

            let X { f1: (z, _), f2: (_, w) } = x;

            assert(has_resolved(x.f1.0)); // FAILS

            *z = 20;
        }

        fn test2() {
            let mut a = 0;
            let mut b = 0;
            let mut c = 0;
            let mut d = 0;

            let x = X { f1: (&mut a, &mut b), f2: (&mut c, &mut d) };

            let (z, _) = x.f1;

            *z = 13;

            *x.f1.1 = 15;
            *x.f2.0 = 16;
            *x.f2.1 = 17;

            assert(a == 13);
            assert(b == 15);
            assert(c == 16);
            assert(d == 17);
        }

        fn test2_fails() {
            let mut a = 0;
            let mut b = 0;
            let mut c = 0;
            let mut d = 0;

            let x = X { f1: (&mut a, &mut b), f2: (&mut c, &mut d) };

            let (z, _) = x.f1;

            assert(has_resolved(x.f1.0)); // FAILS

            *z = 20;
        }
    } => Err(err) => assert_fails(err, 2)
}

test_verify_one_file_with_options! {
    #[test] place_behind_mut_ref_doesnt_resolve [] => verus_code! {
        fn test1() {
            let mut x: u64 = 0;

            let mut x_ref: &mut u64 = &mut x;
            let mut x_ref_ref: &mut &mut u64 = &mut x_ref;

            **x_ref_ref = 30;

            // x_ref_ref resolves here, but not *x_ref_ref

            let mut x_ref_ref2: &mut &mut u64 = &mut x_ref;
            **x_ref_ref2 = 40;

            assert(x == 40);
        }

        fn test2() {
            let mut x: u64 = 0;

            let mut x_ref: &mut u64 = &mut x;
            let mut x_ref_ref: &mut &mut u64 = &mut x_ref;

            **x_ref_ref = 30;

            let mut x_ref_ref2: &mut &mut u64 = &mut x_ref;
            **x_ref_ref2 = 40;

            assert(x == 40);
            assert(false); // FAILS
        }

        fn test3() {
            let mut x: u64 = 0;

            let mut x_ref: &mut u64 = &mut x;
            let mut x_ref_ref: &mut &mut u64 = &mut x_ref;

            **x_ref_ref = 30;

            let mut x_ref_ref2: &mut &mut u64 = &mut x_ref;
            **x_ref_ref2 = 40;

            assert(x == 40);
            assert(has_resolved(mut_ref_current(x_ref_ref))); // FAILS
        }
    } => Err(err) => assert_fails(err, 2)
}

test_verify_one_file_with_options! {
    #[test] temporaries_with_semantically_trivial_ops [] => verus_code! {
        use std::sync::Arc;
        use std::rc::Rc;
        use vstd::prelude::*;

        // the goal of this test is to make sure these are all properly temporaries
        // and that we aren't modifying the original local variable
        fn test_temp_shared_ref() {
            let mut x: u64 = 0;

            let y: u64 = 1;
            *(&mut &x) = &y;

            assert(x == 1); // FAILS
        }

        fn test_temp_box() {
            let mut x: u64 = 0;

            *(&mut Box::new(x)) = Box::new(1);

            assert(x == 1); // FAILS
        }

        fn test_temp_rc() {
            let mut x: u64 = 0;

            *(&mut Rc::new(x)) = Rc::new(1);

            assert(x == 1); // FAILS
        }

        fn test_temp_arc() {
            let mut x: u64 = 0;

            *(&mut Arc::new(x)) = Arc::new(1);

            assert(x == 1); // FAILS
        }

        #[verifier::external_body]
        fn arbitrary_const_ptr() -> *const u64 {
            unimplemented!()
        }

        #[verifier::external_body]
        fn arbitrary_mut_ptr() -> *mut u64 {
            unimplemented!()
        }

        fn test_ptr_conversion_const_to_mut() {
            let p1 = arbitrary_mut_ptr();
            let p2 = arbitrary_const_ptr();

            let mut x: *mut u64 = p1;

            *(&mut (x as *const u64)) = p2;

            assert(x == p2); // FAILS
        }

        fn test_ptr_conversion_mut_to_const() {
            let p1 = arbitrary_mut_ptr();
            let p2 = arbitrary_const_ptr();

            let mut x: *const u64 = p2;

            *(&mut (x as *mut u64)) = p1;

            assert(x == p1); // FAILS
        }

        fn test_int_casting() {
            let mut x: u32 = 0;

            *(&mut (x as u64)) = 1;

            assert(x == 1); // FAILS
        }

        fn test_int_casting_trunc() {
            let mut x: u64 = 0;

            *(&mut (x as u32)) = 1;

            assert(x == 1); // FAILS
        }
    } => Err(err) => assert_fails(err, 8)
}

test_verify_one_file_with_options! {
    #[test] test_params [] => verus_code! {
        fn test1(x: &mut u64)
            ensures mut_ref_current(x) == mut_ref_future(x)
        {
        }

        fn test2(x: &mut u64)
            ensures mut_ref_future(x) == 20
        {
            *x = 20;
        }

        fn test2_fails(x: &mut u64)
            ensures false
        {
            *x = 20;
            return; // FAILS
        }

        fn test3_fails(x: &mut u64)
            ensures mut_ref_future(x) == 20
        {
            assert(has_resolved(x)); // FAILS
            *x = 20;
        }

        fn test3_fails2(x: &mut u64)
            ensures false,
        {
            *x = 20;
            return; // FAILS
        }
    } => Err(err) => assert_fails(err, 3)
}

test_verify_one_file_with_options! {
    #[test] test_params_with_reborrow [] => verus_code! {
        fn test4_1(x: &mut (u64, u64)) -> (ret: &mut u64)
            ensures {
                mut_ref_future(x).1 == mut_ref_current(x).1 &&
                mut_ref_current(x).0 == mut_ref_current(ret) &&
                mut_ref_future(x).0 == mut_ref_future(ret)
            },
        {
            &mut x.0
        }

        fn test4(x: &mut (u64, u64)) -> (ret: &mut u64)
            ensures {
                mut_ref_future(x).1 == mut_ref_current(x).1 &&
                mut_ref_current(x).0 == mut_ref_current(ret) &&
                mut_ref_future(x).0 == mut_ref_future(ret)
            },
        {
            let r = &mut x.0;
            return r;
        }

        fn test4_fails(x: &mut (u64, u64)) -> (ret: &mut u64)
            ensures false,
        {
            let ret = &mut x.0;
            return ret; // FAILS
        }

        fn test4_fails2(x: &mut (u64, u64)) -> (ret: &mut u64)
        {
            let ret = &mut x.0;
            assert(has_resolved(ret)); // FAILS
            ret
        }

        fn test4_fails3(x: &mut (u64, u64)) -> (ret: &mut u64)
        {
            let ret = &mut x.0;
            assert(has_resolved(ret)); // FAILS
            return ret;
        }
    } => Err(err) => assert_fails(err, 3)
}

test_verify_one_file_with_options! {
    #[test] test_param_nested [] => verus_code! {
        fn test(x: &mut &mut u64) {
            assert(has_resolved(x));
        }

        fn test_fails(x: &mut &mut u64) {
            assert(has_resolved(mut_ref_current(x))); // FAILS
        }

        fn test2<'a, 'b>(x: &'b mut &'a mut u64, y: &'a mut u64) {
            assert(has_resolved(mut_ref_current(x)));
            *x = y;
        }
    } => Err(err) => assert_fails(err, 1)
}

test_verify_one_file_with_options! {
    #[test] test_param_nested_with_return_stmt [] => verus_code! {
        fn some_bool() -> bool { true }

        fn test(x: &mut &mut u64) {
            if some_bool() {
                assert(has_resolved(x));
                return;
            }
        }

        fn test_fails(x: &mut &mut u64) {
            if some_bool() {
                assert(has_resolved(mut_ref_current(x))); // FAILS
                return;
            }
        }

        fn test2<'a, 'b>(x: &'b mut &'a mut u64, y: &'a mut u64) {
            if some_bool() {
                assert(has_resolved(mut_ref_current(x)));
                *x = y;
                return;
            }
        }
    } => Err(err) => assert_fails(err, 1)
}

test_verify_one_file_with_options! {
    #[test] auto_coerce_to_shr_borrow [] => verus_code! {
        fn foo(x: &u64) { }

        fn test_shr() {
            let mut x: u64 = 0;
            let mut x_ref = &mut x;

            *x_ref = 20;

            assert(after_borrow(x) == 20);

            let x_ref_shr: &u64 = x_ref;
            assert(x_ref_shr == 20);

            foo(x_ref_shr);
        }

        fn test_shr2() {
            let mut x: u64 = 0;
            let mut x_ref = &mut x;

            *x_ref = 20;

            assert(after_borrow(x) == 20);

            foo(x_ref);
        }

        fn test_shr_fails() {
            let mut x: u64 = 0;
            let mut x_ref = &mut x;

            *x_ref = 20;

            assert(after_borrow(x) == 20);

            let x_ref_shr: &u64 = x_ref;
            assert(x_ref_shr == 20);

            foo(x_ref_shr);
            assert(false); // FAILS
        }

        fn test_shr2_fails() {
            let mut x: u64 = 0;
            let mut x_ref = &mut x;

            *x_ref = 20;

            assert(after_borrow(x) == 20);

            foo(x_ref);
            assert(false); // FAILS
        }
    } => Err(err) => assert_fails(err, 2)
}

test_verify_one_file_with_options! {
    #[test] test_moves_via_let_decl [] => verus_code! {
        fn test(b: bool) {
            let mut x: u64 = 0;
            let mut y: u64 = 0;
            let mut refs = (&mut x, &mut y);

            assert(has_resolved(refs.0) || has_resolved(refs.1) || has_resolved(refs)); // FAILS

            let mut refs2 = refs;

            *refs2.0 = 30;
        }

        fn test2(b: bool) {
            let mut x: u64 = 0;
            let mut y: u64 = 0;
            let mut refs = (&mut x, &mut y);

            assert(has_resolved(refs.0) || has_resolved(refs.1) || has_resolved(refs)); // FAILS

            let mut refs2 = refs;
        }

        fn test3(b: bool) {
            let mut x: u64 = 0;
            let mut y: u64 = 0;
            let mut refs = (&mut x, &mut y);

            assert(has_resolved(refs.0)); // FAILS

            let mut ref_x = refs.0;
            *ref_x = 30;
        }

        fn test4(b: bool) {
            let mut x: u64 = 0;
            let mut y: u64 = 0;
            let mut refs = (&mut x, &mut y);

            assert(has_resolved(refs.0)); // FAILS

            let mut ref_x = refs.0;
        }
    } => Err(err) => assert_fails(err, 4)
}

test_verify_one_file_with_options! {
    #[test] test_moves_via_fn_arg [] => verus_code! {
        fn id<A>(a: A) -> A { a }

        fn test(b: bool) {
            let mut x: u64 = 0;
            let mut y: u64 = 0;
            let mut refs = (&mut x, &mut y);

            assert(has_resolved(refs.0) || has_resolved(refs.1) || has_resolved(refs)); // FAILS

            let mut refs2 = id(refs);

            *refs2.0 = 30;
        }

        fn test2(b: bool) {
            let mut x: u64 = 0;
            let mut y: u64 = 0;
            let mut refs = (&mut x, &mut y);

            assert(has_resolved(refs.0) || has_resolved(refs.1) || has_resolved(refs)); // FAILS

            let mut refs2 = id(refs);
        }

        fn test3(b: bool) {
            let mut x: u64 = 0;
            let mut y: u64 = 0;
            let mut refs = (&mut x, &mut y);

            assert(has_resolved(refs.0)); // FAILS

            let mut ref_x = id(refs.0);
            *ref_x = 30;
        }

        fn test4(b: bool) {
            let mut x: u64 = 0;
            let mut y: u64 = 0;
            let mut refs = (&mut x, &mut y);

            assert(has_resolved(refs.0)); // FAILS

            let mut ref_x = id(refs.0);
        }
    } => Err(err) => assert_fails(err, 4)
}

test_verify_one_file_with_options! {
    #[test] copy_from_behind_mut_ref_doesnt_leave_anything_uninitialized [] => verus_code! {
        fn id<A>(a: A) -> A { a }

        fn test() {
            let mut x: u64 = 0;
            let mut x_ref: &mut u64 = &mut x;

            *x_ref = 20;

            let z = *x_ref;

            assert(has_resolved(x_ref));
        }

        fn test2() {
            let mut x: u64 = 0;
            let mut x_ref: &mut u64 = &mut x;

            *x_ref = 20;

            let z = id(*x_ref);

            assert(has_resolved(x_ref));
        }
    } => Ok(())
}

test_verify_one_file_with_options! {
    #[test] two_phase_borrow_resolving [] => verus_code! {
        struct X<'a> {
            x: u64,
            y: &'a mut u64,
        }

        impl<'a> X<'a> {
            fn method_call_takes_mut_ref(&mut self, x: u64)
                ensures mut_ref_future(self).x == 20,
                no_unwind
            {
                self.x = 20;
            }
        }

        fn call_takes_mut_ref<T>(a: &mut T, x: u64)
            no_unwind
        {
        }

        fn call_takes_generic<T>(a: T, x: u64)
            no_unwind
        {
        }

        // When a call takes a two-phase borrow, the mutable reference doesn't get mutated
        // until *after* all arguments have been evaluated. Thus, for a two-phase borrow,
        // we won't see resolution immediately, but for a 'normal' borrow, we should resolution
        // immediately.

        fn test1() {
            let mut a = 24;
            let mut a_ref = &mut a;

            // two-phase-borrow (implicit reborrows are two-phase borrows)
            call_takes_mut_ref(a_ref, {
                *a_ref
            });

            assert(has_resolved(a_ref));
        }

        fn test1_fails() {
            let mut a = 24;
            let mut a_ref = &mut a;

            // two-phase-borrow (implicit reborrows are two-phase borrows)
            call_takes_mut_ref(a_ref, {
                assert(has_resolved(a_ref)); // FAILS
                *a_ref
            });
        }



        fn test2() {
            let mut a = 24;
            let mut a_ref = &mut a;

            call_takes_mut_ref(&mut *a_ref, 0);

            assert(has_resolved(a_ref));
        }

        fn test2_fails() {
            let mut a = 24;
            let mut a_ref = &mut a;

            // an explicit borrow is always a normal borrow, but Rust inserts an additional two-phase
            // borrow through adjustments. So what we have here is:
            //   &mut(two phase) * &mut(normal) * a_ref
            // Verus cleans this up to just:
            //   &mut(two phase) * a_ref
            // thus treats it as a two-phase borrow, which is why the has_resolved fails here.
            // However, Rust wouldn't let you read from *a_ref until the call is done (because of
            // the "normal" reborrow)
            call_takes_mut_ref(&mut *a_ref, {
                assert(has_resolved(a_ref)); // FAILS
                0
            });
        }

        fn test3() {
            let mut a = 24;
            let mut a_ref = &mut a;

            // When instantiating a generic with &mut T, there is no reborrow at all,
            // so a_ref should never be resolved
            call_takes_generic(a_ref, 0);

            assert(has_resolved(a_ref)); // FAILS
        }

        fn test4(x: X) {
            let mut thevar = x;

            // two-phase-borrow (implicit borrow for a receiver is two-phase)
            thevar.method_call_takes_mut_ref(thevar.x);

            assert(has_resolved(thevar));
        }

        fn test4_fails(x: X) {
            let mut a = x;

            // two-phase-borrow (implicit borrow for a receiver is two-phase)
            a.method_call_takes_mut_ref({
                assert(has_resolved(a)); // FAILS
                a.x
            });
        }
    } => Err(err) => assert_fails(err, 4)
}

test_verify_one_file_with_options! {
    #[test] two_phase_borrow_basic [] => verus_code! {
        fn call_takes_mut_ref(a: &mut u64, x: u64)
            requires x < 50
            ensures mut_ref_future(a) == x + 1
        {
            *a = x + 1;
        }

        fn test1() {
            let mut a = 24;
            let mut a_ref = &mut a;

            call_takes_mut_ref(a_ref, *a_ref);

            assert(a == 25);
        }

        fn test1_fails() {
            let mut a = 24;
            let mut a_ref = &mut a;

            call_takes_mut_ref(a_ref, *a_ref);

            assert(a == 25);
            assert(false); // FAILS
        }
    } => Err(err) => assert_fails(err, 1)
}

test_verify_one_file_with_options! {
    #[test] two_phase_lifetime_error [] => verus_code! {
        fn call_takes_mut_ref(a: &mut u64, x: u64) {
            *a = x + 1;
        }

        fn test2() {
            let mut a = 24;
            let mut a_ref = &mut a;

            call_takes_mut_ref(&mut *a_ref, *a_ref);

            assert(a == 25);
        }
    } => Err(err) => assert_rust_error_msg(err, "cannot use `*a_ref` because it was mutably borrowed")
}

test_verify_one_file_with_options! {
    #[test] two_phase_lifetime_error_generic [] => verus_code! {
        fn call_generic<T>(a: T, x: u64) {
        }

        fn test2() {
            let mut a = 24;
            let mut a_ref = &mut a;

            call_generic(a_ref, *a_ref);
        }
    } => Err(err) => assert_rust_error_msg(err, "use of moved value: `a_ref`")
}

test_verify_one_file_with_options! {
    #[test] two_phase_receiver_struct [] => verus_code! {
        struct X {
            a: u64,
            b: u64,
        }

        struct Y {
            x1: X,
            x2: X,
        }

        impl X {
            fn method_call(&mut self, x: u64)
                ensures mut_ref_future(self) == (X {
                    a: x,
                    b: mut_ref_current(self).a,
                })
            {
                self.b = self.a;
                self.a = x;
            }
        }

        fn test1() {
            let mut x = X { a: 0, b: 1 };
            x.method_call(x.a + 20);

            assert(x == X { a: 20, b: 0 });
        }

        fn test1_fails() {
            let mut x = X { a: 0, b: 1 };
            x.method_call(x.a + 20);

            assert(x == X { a: 20, b: 0 });
            assert(false); // FAILS
        }

        fn test2() {
            let mut x = X { a: 0, b: 1 };
            let mut x_ref = &mut x;
            x_ref.method_call(x_ref.a + 20);

            assert(x == X { a: 20, b: 0 });
        }

        fn test2_fails() {
            let mut x = X { a: 0, b: 1 };
            let mut x_ref = &mut x;
            x_ref.method_call(x_ref.a + 20);

            assert(x == X { a: 20, b: 0 });
            assert(false); // FAILS
        }

        fn test3() {
            let mut y = Y { x1: X { a: 0, b: 1 }, x2: X { a: 3, b: 4 } };
            y.x1.method_call(y.x1.a + 20);

            assert(y == Y { x1: X { a: 20, b: 0 }, x2: X { a: 3, b: 4 } });
        }

        fn test3_fails() {
            let mut y = Y { x1: X { a: 0, b: 1 }, x2: X { a: 3, b: 4 } };
            y.x1.method_call(y.x1.a + 20);

            assert(y == Y { x1: X { a: 20, b: 0 }, x2: X { a: 3, b: 4 } });
            assert(false); // FAILS
        }

        fn test4() {
            let mut y = Y { x1: X { a: 0, b: 1 }, x2: X { a: 3, b: 4 } };
            let y_ref = &mut y;
            y_ref.x1.method_call(y_ref.x1.a + y_ref.x1.b + 20);

            assert(y == Y { x1: X { a: 21, b: 0 }, x2: X { a: 3, b: 4 } });
        }

        fn test4_fails() {
            let mut y = Y { x1: X { a: 0, b: 1 }, x2: X { a: 3, b: 4 } };
            let y_ref = &mut y;
            y_ref.x1.method_call(y_ref.x1.a + y_ref.x1.b + 20);

            assert(y == Y { x1: X { a: 21, b: 0 }, x2: X { a: 3, b: 4 } });
            assert(false); // FAILS
        }
    } => Err(err) => assert_fails(err, 4)
}

test_verify_one_file_with_options! {
    #[test] two_phase_arrays_slices [] => verus_code! {
        use vstd::prelude::*;

        struct X {
            a: u64,
            b: u64,
        }

        impl X {
            fn method_call(&mut self, x: u64)
                ensures mut_ref_future(self) == (X {
                    a: x,
                    b: mut_ref_current(self).a,
                })
            {
                self.b = self.a;
                self.a = x;
            }
        }

        fn test_slice(j: &mut [X])
            requires
                (*j).len() > 0,
                (*j)[0] == (X { a: 0, b: 1 }),
        {
            j[0].method_call(j[0].a + 20);
            assert((*j)[0] == (X { a: 20, b: 0 }));
        }

        fn test_slice_fail(j: &mut [X])
            requires
                (*j).len() > 0,
                (*j)[0] == (X { a: 0, b: 1 }),
        {
            j[0].method_call(j[0].a + 20);
            assert((*j)[0] == (X { a: 20, b: 0 }));
            assert(false); // FAILS
        }

        fn test_slice_boxed(j: Box<[X]>)
            requires
                j.len() > 0,
                j[0] == (X { a: 0, b: 1 }),
        {
            let mut j = j;
            j[0].method_call(j[0].a + 20);
            assert(j[0] == (X { a: 20, b: 0 }));
        }

        fn test_slice_boxed_fail(j: Box<[X]>)
            requires
                j.len() > 0,
                j[0] == (X { a: 0, b: 1 }),
        {
            let mut j = j;
            j[0].method_call(j[0].a + 20);
            assert(j[0] == (X { a: 20, b: 0 }));
            assert(false); // FAILS
        }

        fn test_slice_boxed2(j: Box<[X]>)
            requires
                j.len() > 0,
                j[0] == (X { a: 0, b: 1 }),
        {
            let mut j = j;
            let mut j_ref = &mut j;
            j_ref[0].method_call(j_ref[0].a + 20);
            assert(j[0] == (X { a: 20, b: 0 }));
        }

        fn test_slice_boxed2_fail(j: Box<[X]>)
            requires
                j.len() > 0,
                j[0] == (X { a: 0, b: 1 }),
        {
            let mut j = j;
            let mut j_ref = &mut j;
            j_ref[0].method_call(j_ref[0].a + 20);
            assert(j[0] == (X { a: 20, b: 0 }));
            assert(false); // FAILS
        }

        fn test_array(j: &mut [X; 2])
            requires
                mut_ref_current(j)[0] == (X { a: 0, b: 1 }),
        {
            j[0].method_call(j[0].a);
            assert(mut_ref_current(j)[0] == (X { a: 0, b: 0 }));
        }

        fn test_array_fail(j: &mut [X; 2])
            requires
                mut_ref_current(j)[0] == (X { a: 0, b: 1 }),
        {
            j[0].method_call(j[0].a);
            assert(mut_ref_current(j)[0] == (X { a: 0, b: 0 }));
            assert(false); // FAILS
        }

        fn test_array2() {
            let mut j: [X; 2] = [
                X { a: 0, b: 1 },
                X { a: 5, b: 10 },
            ];

            j[0].method_call(j[0].a + 20);
            assert(j[0] == (X { a: 20, b: 0 }));
        }

        fn test_array2_fail() {
            let mut j: [X; 2] = [
                X { a: 0, b: 1 },
                X { a: 5, b: 10 },
            ];

            j[0].method_call(j[0].a + 20);
            assert(j[0] == (X { a: 20, b: 0 }));
            assert(false); // FAILS
        }

        fn test_array3() {
            let mut j: [X; 2] = [
                X { a: 0, b: 1 },
                X { a: 5, b: 10 },
            ];
            let j_ref = &mut j;

            j_ref[0].method_call(j_ref[0].a + 20);
            assert(j[0] == (X { a: 20, b: 0 }));
        }

        fn test_array3_fail() {
            let mut j: [X; 2] = [
                X { a: 0, b: 1 },
                X { a: 5, b: 10 },
            ];
            let j_ref = &mut j;

            j_ref[0].method_call(j_ref[0].a + 20);
            assert(j[0] == (X { a: 20, b: 0 }));
            assert(false); // FAILS
        }
    } => Err(err) => assert_fails(err, 6)
}

test_verify_one_file_with_options! {
    #[test] two_phase_vec [] => verus_code! {
        use vstd::prelude::*;

        struct X {
            a: u64,
            b: u64,
        }

        impl X {
            fn method_call(&mut self, x: u64)
                ensures mut_ref_future(self) == (X {
                    a: x,
                    b: mut_ref_current(self).a,
                })
            {
                self.b = self.a;
                self.a = x;
            }
        }

        fn test_vec(j: &mut Vec<X>) {
            // j[0] is actually a call to index_mut, which disrupts the possibility of a
            // two-phase borrow.
            j[0].method_call(j[0].a);
        }
    } => Err(err) => assert_rust_error_msg(err, "cannot borrow `*j` as immutable because it is also borrowed as mutable")
}

test_verify_one_file_with_options! {
    #[test] two_phase_ctor [] => verus_code! {
        struct Pair<A, B>(A, B);

        fn test1() {
            let mut a = 24;
            let mut a_ref = &mut a;

            let x: Pair<&mut u64, u64> = Pair(a_ref, *a_ref);

            assert(*x.0 == 24);
            assert(x.1 == 24);

            *x.0 = 50;

            assert(a == 50);
        }

        fn test1_fails() {
            let mut a = 24;
            let mut a_ref = &mut a;

            let x: Pair<&mut u64, u64> = Pair(a_ref, *a_ref);

            assert(*x.0 == 24);
            assert(x.1 == 24);

            *x.0 = 50;

            assert(a == 50);

            assert(false); // FAILS
        }
    } => Err(err) => assert_fails(err, 1)
}

test_verify_one_file_with_options! {
    #[test] two_phase_tuple [] => verus_code! {
        fn test1() {
            let mut a = 24;
            let mut a_ref = &mut a;

            let x: (&mut u64, u64) = (a_ref, *a_ref);

            assert(*x.0 == 24);
            assert(x.1 == 24);

            *x.0 = 50;

            assert(a == 50);
        }
    } => Err(err) => assert_rust_error_msg(err, "cannot use `*a_ref` because it was mutably borrowed")
}

test_verify_one_file_with_options! {
    #[test] two_phase_struct [] => verus_code! {
        struct Pair<'a> {
            a_ref: &'a mut u64,
            a: u64,
        }

        fn test1() {
            let mut a = 24;
            let mut a_ref = &mut a;

            let x = Pair { a_ref: a_ref, a: *a_ref };
        }
    } => Err(err) => assert_rust_error_msg(err, "cannot use `*a_ref` because it was mutably borrowed")
}

test_verify_one_file_with_options! {
    #[test] two_phase_proof_code [] => verus_code! {
        proof fn set_to(tracked a: &mut Ghost<int>, tracked b: Ghost<int>)
            ensures *final(a) == b
        {
            *a = b;
        }

        proof fn two_phase() {
            let tracked mut x: Ghost<int> = Ghost(0);
            let tracked x_ref = &mut x;
            set_to(x_ref, Ghost(x_ref@ + 1));
            assert(x == 1);
        }

        proof fn two_phase_fail() {
            let tracked mut x: Ghost<int> = Ghost(0);
            let tracked x_ref = &mut x;
            set_to(x_ref, Ghost(x_ref@ + 1));
            assert(x == 1);
            assert(false); // FAILS
        }
    } => Err(e) => assert_fails(e, 1)
}

test_verify_one_file_with_options! {
    #[test] struct_mut_ref_pair_immut_ref [] => verus_code! {
        struct BigStruct<'a, 'b>(&'a mut (u64, &'b (u64, u64)));

        fn test1() {
            let pair = (2, 3);
            let mut big_pair = (4, &pair);
            let mut big = BigStruct(&mut big_pair);

            *big.0 = (5, &pair);

            assert(has_resolved(big.0));
            assert(mut_ref_current(big.0) == mut_ref_future(big.0));
        }
    } => Ok(())
}

test_verify_one_file_with_options! {
    #[test] calls_unwind_extra_cfg_edge [] => verus_code! {
        fn call_might_unwind() { }
        fn call_no_unwind() no_unwind { }

        // If `*x = y` is definitely going to be reached, then we can resolve *x,
        // however, if there's an unwindable call, then `*x = y` might not be reached.

        fn test1<'a>(x: &mut &'a mut u64, y: &'a mut u64) {
            assert(has_resolved(*x));
            *x = y;
        }

        fn test2<'a>(x: &mut &'a mut u64, y: &'a mut u64) {
            assert(has_resolved(*x));
            call_no_unwind();
            *x = y;
        }

        fn test3<'a>(x: &mut &'a mut u64, y: &'a mut u64) {
            assert(has_resolved(*x)); // FAILS
            call_might_unwind();
            *x = y;
        }

        fn test4<'a>(x: &mut &'a mut u64, y: &'a mut u64) {
            call_might_unwind();
            assert(has_resolved(*x));
            *x = y;
        }
    } => Err(err) => assert_fails(err, 1)
}

test_verify_one_file_with_options! {
    #[test] has_resolved_for_struct_with_drop_impl [] => verus_code! {
        struct XNoDrop<'a> {
            b: &'a mut u64,
        }

        struct X<'a> {
            b: &'a mut u64,
        }

        impl<'a> Drop for X<'a> {
            fn drop(&mut self)
                opens_invariants none
                no_unwind
            {
                *self.b = 20;
            }
        }

        struct Y<'a> {
            x: X<'a>,
            u: &'a mut u64,
        }

        struct YNoDrop<'a> {
            x: XNoDrop<'a>,
            u: &'a mut u64,
        }


        fn test1<'a>(x: X<'a>) {
            // There is an implicit drop for x at the end of this function body
            // This could possibly modify *x.b (as demonstrated in the Drop impl above)
            // Thus, we make the `has_resolved` predicate of X not imply `has_resolved` of its fields.

            assert(has_resolved(x));
            assert(has_resolved(x.b)); // FAILS
        }

        fn test2<'a>(x: XNoDrop<'a>) {
            assert(has_resolved(x));
            assert(has_resolved(x.b));
        }

        fn test3<'a>(y: Y<'a>) {
            assert(has_resolved(y));
            assert(has_resolved(y.x));
            assert(has_resolved(y.x.b)); // FAILS
        }

        fn test4<'a>(y: YNoDrop<'a>) {
            assert(has_resolved(y));
            assert(has_resolved(y.x));
            assert(has_resolved(y.x.b));
        }
    } => Err(err) => assert_fails(err, 2)
}

test_verify_one_file_with_options! {
    #[test] has_resolved_field_of_struct_with_drop_impl [] => verus_code! {
        struct X {
            s: &'static mut u64,
        }

        impl Drop for X {
            fn drop(&mut self)
                opens_invariants none
                no_unwind
            {
            }
        }

        fn test(x: X, r: &'static mut u64) {
            let mut x = x;
            x.s = r;
            assert(has_resolved(x.s)); // FAILS
        }
    } => Err(err) => assert_fails(err, 1)
}

test_verify_one_file_with_options! {
    #[test] assign_op_to_mut_ref [] => verus_code! {
        fn test_add_assign(i: u64)
            requires i < 1000
        {
            let mut x = 20;
            let x_ref = &mut x;

            *x_ref += i;

            assert(x == 20 + i);
        }

        fn test_add_assign_fail(i: u64)
            requires i < 1000
        {
            let mut x = 20;
            let x_ref = &mut x;

            *x_ref += i;

            assert(x == 20 + i);
            assert(false); // FAILS
        }

        fn test_add_assign_fields(i: u64)
            requires i < 1000
        {
            let mut x = (20, 30);
            let x_ref = &mut x;

            x_ref.0 += i;

            assert(x.0 == 20 + i);
            assert(x.1 == 30);
        }

        fn test_add_assign_fields_fail(i: u64)
            requires i < 1000
        {
            let mut x = (20, 30);
            let x_ref = &mut x;

            x_ref.0 += i;

            assert(x.0 == 20 + i);
            assert(x.1 == 30);
            assert(false); // FAILS
        }

        fn test_add_assign_overflow(i: u64)
        {
            let mut x = (20, 30);
            let x_ref = &mut x;

            x_ref.0 += i; // FAILS
        }

        fn test_add_assign_twice(i: u64)
            requires i < 1000
        {
            let mut x = 20;
            let x_ref = &mut x;

            *x_ref += i;
            *x_ref += i;

            assert(x == 20 + 2*i);
        }

        fn test_add_assign_twice_fail(i: u64)
            requires i < 1000
        {
            let mut x = 20;
            let x_ref = &mut x;

            *x_ref += i;
            *x_ref += i;

            assert(x == 20 + 2*i);
            assert(false); // FAILS
        }
    } => Err(err) => assert_fails(err, 4)
}

test_verify_one_file_with_options! {
    #[test] ctor_with_update_tail [] => verus_code! {
        tracked struct TTPair<A, B> {
            tracked a: A,
            tracked b: B,
        }

        fn test1() {
            let mut g1: Ghost<int> = Ghost(1);
            let mut g2: Ghost<int> = Ghost(2);
            let mut g3: Ghost<int> = Ghost(3);

            let tracked p = TTPair {
                a: &mut g1,
                b: &mut g2,
            };

            proof {
                *p.a.borrow_mut() = 4;
                *p.b.borrow_mut() = 5;
            }

            let tracked p2 = TTPair {
                a: &mut g3,
                .. p
            };

            assert(has_resolved(p.b)); // FAILS

            proof {
                *p2.b.borrow_mut() = 4;
            }
        }

        fn test2() {
            let mut g1: Ghost<int> = Ghost(1);
            let mut g2: Ghost<int> = Ghost(2);
            let mut g3: Ghost<int> = Ghost(3);

            let tracked p = TTPair {
                a: &mut g1,
                b: &mut g2,
            };

            proof {
                *p.a.borrow_mut() = 4;
                *p.b.borrow_mut() = 5;
            }

            let tracked p2 = TTPair {
                a: &mut g3,
                .. p
            };

            // ok, p.a was not moved
            assert(has_resolved(p.a));

            proof {
                *p2.b.borrow_mut() = 4;
            }
        }

        fn test3() {
            let mut g1: Ghost<int> = Ghost(1);
            let mut g2: Ghost<int> = Ghost(2);
            let mut g3: Ghost<int> = Ghost(3);

            let tracked p = TTPair {
                a: &mut g1,
                b: &mut g2,
            };

            proof {
                *p.a.borrow_mut() = 4;
                *p.b.borrow_mut() = 5;
            }

            let tracked p2 = TTPair {
                a: &mut g3,
                .. p
            };

            proof {
                *p.a.borrow_mut() = 4;
                *p2.a.borrow_mut() = 5;
                *p2.b.borrow_mut() = 6;
            }

            assert(g1@ == 4);
            assert(g3@ == 5);
            assert(g2@ == 6);

            assert(false); // FAILS
        }

        spec fn id<A>(a: A) -> A { a }

        fn test4() {
            let mut g1: Ghost<int> = Ghost(1);
            let mut g2: Ghost<int> = Ghost(2);
            let mut g3: Ghost<int> = Ghost(3);

            let tracked p = TTPair {
                a: &mut g1,
                b: &mut g2,
            };

            proof {
                *p.a.borrow_mut() = 4;
                *p.b.borrow_mut() = 5;
            }

            let tracked ref_g3 = &mut g3;
            // this doesn't do any moves because it's ghost mode:
            let ghost p2 = TTPair {
                a: id(ref_g3),
                .. p
            };

            assert(has_resolved(p.b));
        }
    } => Err(err) => assert_fails(err, 2)
}

test_verify_one_file_with_options! {
    #[test] shr_bor_of_pair_of_mut_bor [] => verus_code! {
        enum BigEnum<'a, 'b> {
            A(&'a (u64, &'b mut u64)),
        }

        fn test_fails() {
            let mut pair = 2;
            let mut big_pair = (4, &mut pair);
            let mut big = BigEnum::A(&big_pair);

            *big_pair.1 = 10;

            assert(false); // FAILS
        }
    } => Err(err) => assert_fails(err, 1)
}

test_verify_one_file_with_options! {
    #[test] fin_keyword [] => verus_code! {
        fn foo(x: &mut u64) {
            assert(mut_ref_future(x) == *final(x));
        }
    } => Ok(())
}

test_verify_one_file_with_options! {
    #[test] fin_keyword2 [] => verus_code! {
        fn foo(x: &mut bool) {
            assert(mut_ref_current(final(x)));
        }
    } => Err(err) => assert_vir_error_msg(err, "The result of `final` must be dereferenced")
}

test_verify_one_file_with_options! {
    #[test] resolve_places_with_projection_types [] => verus_code! {
        trait Tr {
            type AssocType;
        }

        struct P<T: Tr> {
            a: T::AssocType,
            b: u64,
        }

        struct X<'a> { a: &'a u64 }

        impl<'a> Tr for X<'a> {
            type AssocType = (&'a mut u64, &'a mut u64);
        }

        fn test<'a>(p: P<X<'a>>) {
            let mut p = p;
            assert(has_resolved(p.a.1));
            p.b = 20;
            *p.a.0 = 30;
            assert(has_resolved(p.a.0));
        }

        fn test2<'a>(p: P<X<'a>>) {
            let mut p = p;
            p.b = 20;
            assert(has_resolved(p.a.0)); // FAILS
            *p.a.0 = 30;
        }
    } => Err(err) => assert_fails(err, 1)
}

test_verify_one_file_with_options! {
    #[test] place_that_doesnt_return [] => verus_code! {
        use vstd::prelude::*;

        #[allow(unreachable_code)]
        #[verifier::exec_allows_no_decreases_clause]
        fn test1() {
            let mut a = 4;
            *({ loop {}; &mut a }) = 5;
            assert(false);
        }

        #[allow(unreachable_code)]
        #[verifier::exec_allows_no_decreases_clause]
        fn test2() {
            let mut a = 4;
            *({ loop {}; &mut a }) = ({
                assert(false); // FAILS
                5
            });
            assert(false);
        }

        #[allow(unreachable_code)]
        #[verifier::exec_allows_no_decreases_clause]
        fn test2_fails() {
            let mut a = 4;
            *({
                assert(false);
            &mut a }) = ({ loop {} 5 });
        }

        #[allow(unreachable_code)]
        #[verifier::exec_allows_no_decreases_clause]
        fn test3() {
            let mut a = 4;
            let mut a_ref: &mut u64 = loop { };
            assert(false);
        }

        #[allow(unreachable_code)]
        #[verifier::exec_allows_no_decreases_clause]
        fn test4() {
            let y: [[u64; 2]; 2] = [[0,1],[2,3]];
            let x = y[({ loop{}; 0 })][({ assert(false); 1 })];
        }

        #[allow(unreachable_code)]
        #[verifier::exec_allows_no_decreases_clause]
        fn test5() {
            let y: [[u64; 2]; 2] = [[0,1],[2,3]];
            let x = y[({
              assert(false); // FAILS
            1})][({ loop{}; 0 })];
        }

        #[allow(unreachable_code)]
        #[verifier::exec_allows_no_decreases_clause]
        fn test6(y: [&mut (u64, u64); 2]) {
            let mut y = y;
            (*y[({ loop{} 0 })]).0 = 20;
            assert(false);
        }
    } => Err(e) => assert_fails(e, 2)
}

test_verify_one_file_with_options! {
    #[test] compound_op_that_doesnt_return [] => verus_code! {
        #[allow(unreachable_code)]
        #[verifier::exec_allows_no_decreases_clause]
        fn test1(y: [&mut (u64, u64); 2]) {
            let mut y = y;
            (*y[({ loop{} 0 })]).0 += 20;
        }

        #[allow(unreachable_code)]
        #[verifier::exec_allows_no_decreases_clause]
        fn test2(y: [&mut (u64, u64); 2]) {
            let mut y = y;
            (*y[({
                assert(false);
            0 })]).0 += ({ loop{} 20 });
        }

        #[allow(unreachable_code)]
        #[verifier::exec_allows_no_decreases_clause]
        fn test3(y: [&mut (u64, u64); 2]) {
            let mut y = y;
            (*y[0]).0 += ({ loop{} 20 });
        }

        #[allow(unreachable_code)]
        #[verifier::exec_allows_no_decreases_clause]
        fn test4(y: &mut [&mut (u64, u64); 2])
            ensures mut_ref_current(y) == mut_ref_future(y)
        {
            let mut y = y;
            (*y[0]).0 += ({ return; 20 });
        }

        #[allow(unreachable_code)]
        #[verifier::exec_allows_no_decreases_clause]
        fn test4_fails(y: &mut [&mut (u64, u64); 2])
            ensures false
        {
            let mut y = y;
            (*y[0]).0 += ({
                return; // FAILS
                0
            });
        }
    } => Err(e) => assert_fails(e, 1)
}

test_verify_one_file_with_options! {
    #[test] call_with_args_that_dont_return [] => verus_code! {
        fn call(a: &mut u64, b: &mut u64, c: &mut u64) { }

        fn call_requires_false(a: &mut u64, b: &mut u64, c: &mut u64)
            requires false
        { }

        #[verifier::exec_allows_no_decreases_clause]
        #[allow(unreachable_code)]
        fn test1() {
            let mut a = 20;
            let mut b = 30;
            let mut c = 40;
            call_requires_false(&mut a, ({ loop {} &mut b }), &mut c);
        }

        #[verifier::exec_allows_no_decreases_clause]
        #[allow(unreachable_code)]
        fn test2() {
            let mut a = 20;
            let mut b = 30;
            let mut c = 40;
            call_requires_false(&mut a, (loop {}), &mut c);
        }

        #[verifier::exec_allows_no_decreases_clause]
        #[allow(unreachable_code)]
        fn test3(a_ref: &mut u64, c_ref: &mut u64)
            ensures
                mut_ref_future(a_ref) == mut_ref_current(a_ref),
                mut_ref_future(c_ref) == mut_ref_current(c_ref),
        {
            call_requires_false(a_ref, (return), c_ref);
        }

        #[verifier::exec_allows_no_decreases_clause]
        #[allow(unreachable_code)]
        fn test3_fails(a_ref: &mut u64, c_ref: &mut u64)
            ensures
                false
        {
            call_requires_false(a_ref, (
                return // FAILS
            ), c_ref);
        }

        #[verifier::exec_allows_no_decreases_clause]
        #[allow(unreachable_code)]
        fn test4() {
            let mut a = 20;
            let mut b = 30;
            let mut c = 40;
            call_requires_false(&mut a, (loop {}), ({ assert(false); &mut c }));
        }

        #[verifier::exec_allows_no_decreases_clause]
        #[allow(unreachable_code)]
        fn test5() {
            let mut a = 20;
            let mut b = 30;
            let mut c = 40;
            call(({
              assert(false); // FAILS
            &mut a }), (loop {}), &mut c);
        }
    } => Err(e) => assert_fails(e, 2)
}

test_verify_one_file_with_options! {
    #[test] ctor_with_args_that_dont_return [] => verus_code! {
        struct Ctor<'a, 'b, 'c>(&'a mut u64, &'b mut u64, &'c mut u64);

        #[verifier::exec_allows_no_decreases_clause]
        #[allow(unreachable_code)]
        fn test1() {
            let mut a = 20;
            let mut b = 30;
            let mut c = 40;
            let ct = Ctor(&mut a, ({ loop {} &mut b }), &mut c);
        }

        #[verifier::exec_allows_no_decreases_clause]
        #[allow(unreachable_code)]
        fn test2() {
            let mut a = 20;
            let mut b = 30;
            let mut c = 40;
            let ct = Ctor(&mut a, (loop {}), &mut c);
        }

        #[verifier::exec_allows_no_decreases_clause]
        #[allow(unreachable_code)]
        fn test3(a_ref: &mut u64, c_ref: &mut u64)
            ensures
                mut_ref_future(a_ref) == mut_ref_current(a_ref),
                mut_ref_future(c_ref) == mut_ref_current(c_ref),
        {
            let ct = Ctor(a_ref, (return), c_ref);
        }

        #[verifier::exec_allows_no_decreases_clause]
        #[allow(unreachable_code)]
        fn test3_fails(a_ref: &mut u64, c_ref: &mut u64)
            ensures
                false
        {
            let ct = Ctor(a_ref, (
                return // FAILS
            ), c_ref);
        }

        #[verifier::exec_allows_no_decreases_clause]
        #[allow(unreachable_code)]
        fn test4() {
            let mut a = 20;
            let mut b = 30;
            let mut c = 40;
            let ct = Ctor(&mut a, (loop {}), ({ assert(false); &mut c }));
        }

        #[verifier::exec_allows_no_decreases_clause]
        #[allow(unreachable_code)]
        fn test5() {
            let mut a = 20;
            let mut b = 30;
            let mut c = 40;
            let ct = Ctor(({
              assert(false); // FAILS
            &mut a }), (loop {}), &mut c);
        }
    } => Err(e) => assert_fails(e, 2)
}

test_verify_one_file_with_options! {
    #[test] mut_ref_with_implicit_box_deref [] => verus_code! {
        use vstd::prelude::*;

        enum List {
            Cons(u64, Box<List>),
            Nil,
        }

        #[verifier::exec_allows_no_decreases_clause]
        fn build_zero_list(len: u64) -> List {
            let mut list = List::Nil;
            let mut cur = &mut list;

            let mut i = 0;
            while i < len {
                *cur = List::Cons(0, Box::new(List::Nil));

                match cur {
                    List::Cons(_, b) => {
                        // Replace `cur` with a reference to the newly-created List::Nil,
                        // the child of the previous `cur`.
                        cur = &mut *b;
                    }
                    _ => { /* clearly unreachable */ }
                }

                i += 1;
            }

            return list;
        }
    } => Ok(())
}

test_verify_one_file_with_options! {
    #[test] mut_ref_snapshot [] => verus_code! {
        fn test() {
            let mut a = 0;
            let a_ref = &mut a;

            let ghost snapshot = a_ref;

            assert(a == 0);
            assert(mut_ref_future(snapshot) == 0);
            assert(mut_ref_current(snapshot) == 0);
        }

        fn fails() {
            let mut a = 0;
            let a_ref = &mut a;

            let ghost snapshot = a_ref;

            assert(a == 0);
            assert(mut_ref_future(snapshot) == 0);
            assert(mut_ref_current(snapshot) == 0);
            assert(false); // FAILS
        }
    } => Err(e) => assert_fails(e, 1)
}

test_verify_one_file_with_options! {
    #[test] backwards_compat [] => verus_code! {
        #[verifier::deprecated_postcondition_mut_ref_style(true)]
        fn test(a: &mut u8)
            requires *old(a) < 255,
            ensures *a == *old(a) + 1,
        {
            *a = *a + 1;
        }

        #[verifier::deprecated_postcondition_mut_ref_style(true)]
        fn test2(a: &mut u8)
            requires *old(a) < 255,
            ensures *a == *old(a) + 1,
        {
            test(a);
        }
    } => Ok(())
}

test_verify_one_file_with_options! {
    #[test] backwards_compat_unwrapped_param [] => verus_code! {
        #[verifier::deprecated_postcondition_mut_ref_style(true)]
        fn test(Tracked(a): Tracked<&mut Ghost<u8>>)
            requires old(a)@ < 255,
            ensures a@ == old(a)@ + 1,
        {
            proof { *a = Ghost((a@ + 1) as u8); }
        }

        #[verifier::deprecated_postcondition_mut_ref_style(true)]
        fn test2(Tracked(a): Tracked<&mut Ghost<u8>>)
            requires old(a)@ < 255,
            ensures a@ == old(a)@ + 1,
        {
            test(Tracked(a));
        }

        #[verifier::deprecated_postcondition_mut_ref_style(true)]
        fn test2_fails(Tracked(a): Tracked<&mut Ghost<u8>>)
            requires old(a)@ < 255,
            ensures a@ == old(a)@ + 1,
        {
            test(Tracked(a));
            assert(false); // FAILS
        }

        #[verifier::deprecated_postcondition_mut_ref_style(true)]
        fn test2_fails2(Tracked(a): Tracked<&mut Ghost<u8>>)
            ensures a@ == old(a)@ + 1,
        {
            test(Tracked(a)); // FAILS
        }
    } => Err(e) => assert_fails(e, 2)
}

test_verify_one_file_with_options! {
    #[test] backwards_compat_fail [] => verus_code! {
        #[verifier::deprecated_postcondition_mut_ref_style(true)]
        fn test(a: &mut u8)
            requires *old(a) < 255,
            ensures *final(a) == *old(a) + 1,
        {
            *a = *a + 1;
        }

        #[verifier::deprecated_postcondition_mut_ref_style(true)]
        fn test2(a: &mut u8)
            requires *old(a) < 255,
            ensures *a == *old(a) + 1,
        {
            test(a);
        }
    } => Err(err) => assert_vir_error_msg(err, "to use `final`, disable mut-ref backwards-compatability")
}

test_verify_one_file_with_options! {
    #[test] backwards_compat_fail2 [] => verus_code! {
        #[verifier::deprecated_postcondition_mut_ref_style(true)]
        fn test(a: &mut u8)
            requires *old(a) < 255,
            ensures *a == *old(a) + 1,
        {
            *a = *a + 1;
        }

        #[verifier::deprecated_postcondition_mut_ref_style(true)]
        fn test2(a: &mut u8)
            requires *old(a) < 255,
            ensures a == a
        {
            test(a);
        }
    } => Err(err) => assert_vir_error_msg(err, "For more flexible mutable reference support, disable the backwards-compatability")
}

test_verify_one_file_with_options! {
    #[test] false_two_phase [] => verus_code! {
        fn set_to(Tracked(a): Tracked<&mut Ghost<int>>, Tracked(b): Tracked<Ghost<int>>)
            ensures *final(a) == b
        {
            proof { *a = b; }
        }

        fn test() {
            let tracked mut x: Ghost<int> = Ghost(0);
            let tracked x_ref = &mut x;
            // The x_ref here is two-phase with respect to `Tracked` rather than to
            // the `set_to` call.
            set_to(Tracked(x_ref), Tracked(Ghost(x_ref@ + 1)));
            assert(x == 1);
            assert(false);
        }
    } => Err(err) => assert_rust_error_msg(err, "cannot borrow `*(Verus spec x_ref)` as immutable because it is also borrowed as mutable")
}

test_verify_one_file_with_options! {
    #[test] false_two_phase2 [] => verus_code! {
        fn set_to(Tracked(a): Tracked<&mut Tracked<int>>, Tracked(b): Tracked<int>)
            ensures *final(a) == b
        {
            proof { *a = Tracked(b); }
        }

        fn test_fail() {
            let tracked mut x: Tracked<int> = Tracked(0);
            let tracked x_ref = &mut x;
            set_to(Tracked(x_ref), Tracked(x_ref.get() + 1));
            assert(*x == 1);
            assert(false);
        }
    } => Err(err) => assert_rust_error_msg(err, "cannot use `*x_ref` because it was mutably borrowed")
}

test_verify_one_file_with_options! {
    #[test] overwrite_reborrowed_mut_ref [] => verus_code! {
        fn overwrite() {
            let mut a = 0;
            let mut b = 0;

            let mut x = &mut a;
            *x = 20;

            let y = x;
            x = &mut b;

            *x = 30;
            *y = 40;

            assert(a == 40);
            assert(b == 30);
        }

        fn overwrite_fails() {
            let mut a = 0;
            let mut b = 0;

            let mut x = &mut a;
            *x = 20;

            let y = x;
            x = &mut b;

            *x = 30;
            *y = 40;

            assert(a == 40);
            assert(b == 30);
            assert(false); // FAILS
        }
    } => Err(err) => assert_fails(err, 1)
}

test_verify_one_file_with_options! {
    #[test] overwrite_reborrowed_mut_ref_match_guard [] => verus_code! {
        enum Foo {
            Bar,
            Qux
        }

        fn test_pat(cond: bool) {
            let mut a = Foo::Bar;
            let mut b = Foo::Qux;

            let mut a_ref = &mut a;

            match a_ref {
                Foo::Bar if ({
                    a_ref = &mut b;
                    cond
                }) => { }
                Foo::Bar => { }
                Foo::Qux => { }
            }
        }
    } => Err(err) => assert_rust_error_msg(err, "cannot assign `a_ref` in match guard")
}

test_verify_one_file_with_options! {
    #[test] overwrite_in_slice_index_after_index_read [] => verus_code! {
        fn slice_test(slice1: &mut [[u64; 2]], slice2: &mut [[u64; 2]]) {
            let mut x = slice1;
            let j = x[0][({ x = slice2; 0 })];
        }
    } => Err(err) => assert_rust_error_msg(err, "cannot assign `x` in indexing expression")
}

test_verify_one_file_with_options! {
    #[test] overwrite_in_slice_index_after_index_assign [] => verus_code! {
        fn slice_test(slice1: &mut [[u64; 2]], slice2: &mut [[u64; 2]]) {
            let mut x = slice1;
            let j = x[0][({ x = slice2; 0 })];
        }
    } => Err(err) => assert_rust_error_msg(err, "cannot assign `x` in indexing expression")
}

test_verify_one_file_with_options! {
    #[test] overwrite_in_slice_index_after_index_mut_ref [] => verus_code! {
        fn slice_test(slice1: &mut [[u64; 2]], slice2: &mut [[u64; 2]]) {
            let mut x = slice1;
            let j = &mut x[0][({ x = slice2; 0 })];
        }
    } => Err(err) => assert_rust_error_msg(err, "cannot assign `x` in indexing expression")
}

test_verify_one_file_with_options! {
    #[test] overwrite_two_phase_borrow [] => verus_code! {
        fn set_to(a: &mut u64, b: u64)
            ensures *final(a) == b,
        {
            *a = b;
        }

        fn two_phase_test() {
            let mut a = 0;
            let mut b = 1;

            let mut a_ref = &mut a;
            set_to(a_ref, ({ a_ref = &mut b; 20 }));

            assert(a == 20);
            assert(b == 1);
        }
    } => Err(err) => assert_vir_error_msg(err, "Verus doesn't support assigning during mutable borrow like this")
}

test_verify_one_file_with_options! {
    #[test] overwrite_two_phase_borrow2 [] => verus_code! {
        fn set_to(a: (&mut u64, u64), b: u64)
            ensures *final(a.0) == b,
        {
            *a.0 = b;
        }

        fn two_phase_test() {
            let mut a = 0;
            let mut b = 1;

            let mut a_ref = (&mut a, 20);
            set_to(a_ref, ({ a_ref.0 = &mut b; 20 }));

            assert(a == 20);
            assert(b == 1);
        }
    } => Err(err) => assert_rust_error_msg(err, "assign to part of moved value: `a_ref`")
}

test_verify_one_file_with_options! {
    #[test] overwrite_two_phase_borrow3 [] => verus_code! {
        fn set_to(a: &mut u64, b: u64)
            ensures *final(a) == b,
        {
            *a = b;
        }

        fn two_phase_test() {
            let mut a = 0;
            let mut b = 1;

            let mut a_ref = (&mut a, 0);
            set_to(a_ref.0, ({ a_ref = (&mut b, 2); 20 }));

            assert(a == 20);
            assert(b == 1);
        }
    } => Err(err) => assert_vir_error_msg(err, "Verus doesn't support assigning during mutable borrow like this")
}

test_verify_one_file_with_options! {
    #[test] overwrite_two_phase_borrow4 [] => verus_code! {
        fn set_to(a: &mut u64, b: u64)
            ensures *final(a) == b,
        {
            *a = b;
        }

        fn two_phase_test() {
            let mut a = 0;
            let mut b = 1;

            let mut a_ref = (&mut a, 0);
            set_to(a_ref.0, ({ a_ref.0 = &mut b; 20 }));

            assert(a == 20);
            assert(b == 1);
        }
    } => Err(err) => assert_vir_error_msg(err, "Verus doesn't support assigning during mutable borrow like this")
}

test_verify_one_file_with_options! {
    #[test] overwrite_two_phase_borrow5 [] => verus_code! {
        fn set_to(a: &mut u64, b: u64)
            ensures *final(a) == b,
        {
            *a = b;
        }

        fn two_phase_test() {
            let mut a = 0;
            let mut b = 1;

            let mut a_ref = (&mut a, 0);
            set_to(a_ref.0, ({ a_ref.1 = 17; 20 }));

            assert(a == 20);
            assert(b == 1);
            assert(a_ref.1 == 17);
        }

        fn two_phase_test_fails() {
            let mut a = 0;
            let mut b = 1;

            let mut a_ref = (&mut a, 0);
            set_to(a_ref.0, ({ a_ref.1 = 17; 20 }));

            assert(a == 20);
            assert(b == 1);
            assert(a_ref.1 == 17);
            assert(false); // FAILS
        }

    } => Err(err) => assert_fails(err, 1)
}

test_verify_one_file_with_options! {
    #[test] overwrite_two_phase_borrow6 [] => verus_code! {
        fn set_to(a: &mut u64, b: u64)
            ensures *final(a) == b,
        {
            *a = b;
        }

        fn two_phase_test() {
            let mut a = 0;
            let mut b = 1;
            let mut c = 2;
            let mut d = 3;
            let mut e = 4;

            let mut a_ref = [&mut a, &mut b];
            set_to(a_ref[0], ({ a_ref[0] = &mut c; 20 }));
        }
    } => Err(err) => assert_vir_error_msg(err, "Verus doesn't support assigning during mutable borrow like this")
}

test_verify_one_file_with_options! {
    #[test] overwrite_two_phase_borrow7 [] => verus_code! {
        fn set_to(a: &mut u64, b: u64)
            ensures *final(a) == b,
        {
            *a = b;
        }

        fn two_phase_test() {
            let mut a = 0;
            let mut b = 1;
            let mut c = 2;
            let mut d = 3;
            let mut e = 4;

            let mut a_ref = [&mut a, &mut b];
            // this would be ok but we're not going to compare indices
            set_to(a_ref[0], ({ a_ref[1] = &mut c; 20 }));
        }
    } => Err(err) => assert_vir_error_msg(err, "Verus doesn't support assigning during mutable borrow like this")
}

test_verify_one_file_with_options! {
    #[test] overwrite_two_phase_borrow8 [] => verus_code! {
        fn set_to(a: &mut u64, b: u64)
            ensures *final(a) == b,
        {
            *a = b;
        }

        fn two_phase_test() {
            let mut a = 0;
            let mut b = 1;
            let mut c = 2;
            let mut d = 3;
            let mut e = 4;
            let mut f = 5;

            let mut a_ref = [(&mut a, &mut b), (&mut c, &mut d)];
            set_to(a_ref[0].0, ({ a_ref[0] = (&mut e, &mut f); 20 }));
        }
    } => Err(err) => assert_vir_error_msg(err, "Verus doesn't support assigning during mutable borrow like this")
}

test_verify_one_file_with_options! {
    #[test] overwrite_two_phase_borrow9 [] => verus_code! {
        fn set_to(a: &mut u64, b: u64)
            ensures *final(a) == b,
        {
            *a = b;
        }

        fn two_phase_test() {
            let mut a = 0;
            let mut b = 1;
            let mut c = 2;
            let mut d = 3;
            let mut e = 4;
            let mut f = 5;

            let mut a_ref = [(&mut a, &mut b), (&mut c, &mut d)];
            set_to(a_ref[0].0, ({ a_ref[0].0 = &mut e; 20 }));
        }
    } => Err(err) => assert_vir_error_msg(err, "Verus doesn't support assigning during mutable borrow like this")
}

test_verify_one_file_with_options! {
    #[test] overwrite_two_phase_borrow10 [] => verus_code! {
        use vstd::prelude::*;

        fn set_to(a: &mut u64, b: u64)
            ensures *final(a) == b,
        {
            *a = b;
        }

        fn two_phase_test() {
            let mut a = 0;
            let mut b = 1;
            let mut c = 2;
            let mut d = 3;
            let mut e = 4;
            let mut f = 5;

            let mut a_ref = [(&mut a, &mut b), (&mut c, &mut d)];
            set_to(a_ref[0].0, ({ a_ref[0].1 = &mut e; 20 }));

            assert(has_resolved(a_ref));
            assert(has_resolved(a_ref[0]));
            assert(has_resolved(a_ref[1]));
            assert(has_resolved(a_ref[0].0));
            assert(has_resolved(a_ref[0].1));
            assert(has_resolved(a_ref[1].0));
            assert(has_resolved(a_ref[1].1));

            assert(*a_ref[0].1 == 4);
            assert(a == 20);
            assert(b == 1);
            assert(c == 2);
            assert(d == 3);
            assert(e == 4);
        }

        fn two_phase_test_fails() {
            let mut a = 0;
            let mut b = 1;
            let mut c = 2;
            let mut d = 3;
            let mut e = 4;
            let mut f = 5;

            let mut a_ref = [(&mut a, &mut b), (&mut c, &mut d)];
            set_to(a_ref[0].0, ({ a_ref[0].1 = &mut e; 20 }));

            assert(has_resolved(a_ref));
            assert(has_resolved(a_ref[0]));
            assert(has_resolved(a_ref[1]));
            assert(has_resolved(a_ref[0].0));
            assert(has_resolved(a_ref[0].1));
            assert(has_resolved(a_ref[1].0));
            assert(has_resolved(a_ref[1].1));

            assert(*a_ref[0].1 == 4);
            assert(a == 20);
            assert(b == 1);
            assert(c == 2);
            assert(d == 3);
            assert(e == 4);
            assert(false); // FAILS
        }
    } => Err(err) => assert_fails(err, 1)
}

test_verify_one_file_with_options! {
    #[test] overwrite_two_phase_borrow11 [] => verus_code! {
        fn set_to(a: &mut u64, b: u64)
            ensures *final(a) == b,
        {
            *a = b;
        }

        #[verifier::exec_allows_no_decreases_clause]
        #[allow(unreachable_code)]
        fn two_phase_test() {
            let mut a = 0;
            let mut b = 1;

            let mut a_ref = &mut a;
            // ok because the function call is actually unreachable
            set_to(a_ref, ({ loop { a_ref = &mut b; } 20 }));
            assert(false);
        }
    } => Ok(())
}

test_verify_one_file_with_options! {
    #[test] overwrite_two_phase_borrow12 [] => verus_code! {
        fn set_to(a: &mut u64, b: u64)
            ensures *final(a) == b,
        {
            *a = b;
        }

        fn cond() -> bool { true }

        #[verifier::exec_allows_no_decreases_clause]
        fn two_phase_test() {
            let mut a = 0;
            let mut b = 1;

            let mut a_ref = &mut a;
            set_to(a_ref, ({ loop { a_ref = &mut b; break; } 20 }));
            assert(false);
        }
    } => Err(err) => assert_vir_error_msg(err, "Verus doesn't support assigning during mutable borrow like this")
}

test_verify_one_file_with_options! {
    #[test] overwrite_two_phase_borrow13 [] => verus_code! {
        struct Ctor<'a>(&'a mut u64, u64);

        fn two_phase_test() {
            let mut a = 0;
            let mut b = 1;

            let mut a_ref = &mut a;
            let t = Ctor(a_ref, ({ a_ref = &mut b; 20 }));
        }
    } => Err(err) => assert_vir_error_msg(err, "Verus doesn't support assigning during mutable borrow like this")
}

// vec works differently than slice/array since it's a method call instead of a place expression
test_verify_one_file_with_options! {
    #[test] overwrite_vec_while_indexing [] => verus_code! {
        use vstd::prelude::*;
        fn vec_index_read() {
            let mut a: Vec<u64> = vec![0, 1];
            let b: Vec<u64> = vec![2, 3];

            let j = a[({ a = b; 0 })];
            //assert!(j == 2);
        }
    } => Err(err) => assert_rust_error_msg(err, "cannot assign to `a` because it is borrowed")
}

test_verify_one_file_with_options! {
    #[test] overwrite_vec_while_indexing2 [] => verus_code! {
        use vstd::prelude::*;

        // When x: &mut Vec<T>,
        //    x[({ x = &mut b; 0 })]
        // is equivalent to:
        //    index_mut(&mut *x, ({ x = &mut b; 0 }))
        // The first argument is _not_ a two-phase borrow.

        fn mut_ref_vec_index_read() {
            let mut a: Vec<u64> = vec![0, 1];
            let mut b: Vec<u64> = vec![2, 3];

            let mut x = &mut a;
            let j = x[({ x = &mut b; 0 })];
            assert((*x)@ == seq![2, 3]);
            assert(j == 0);
        }

        fn mut_ref_vec_index_assign() {
            let mut a: Vec<u64> = vec![0, 1];
            let mut b: Vec<u64> = vec![2, 3];

            let mut x = &mut a;
            x[({ x = &mut b; 0 })] = 100;
            assert((*x)@ == seq![2, 3]);
            assert(a@ == seq![100, 1]);
            assert(b@ == seq![2, 3]);
        }

        fn mut_ref_vec_index_mut_ref() {
            let mut a: Vec<u64> = vec![0, 1];
            let mut b: Vec<u64> = vec![2, 3];

            let mut x = &mut a;
            let r = &mut x[({ x = &mut b; 0 })];
            *r = 100;
            assert((*x)@ == seq![2, 3]);
            assert(a@ == seq![100, 1]);
            assert(b@ == seq![2, 3]);
        }

        fn mut_ref_vec_index_read_fails() {
            let mut a: Vec<u64> = vec![0, 1];
            let mut b: Vec<u64> = vec![2, 3];

            let mut x = &mut a;
            let j = x[({ x = &mut b; 0 })];
            assert((*x)@ == seq![2, 3]);
            assert(j == 0);
            assert(false); // FAILS
        }

        fn mut_ref_vec_index_assign_fails() {
            let mut a: Vec<u64> = vec![0, 1];
            let mut b: Vec<u64> = vec![2, 3];

            let mut x = &mut a;
            x[({ x = &mut b; 0 })] = 100;
            assert((*x)@ == seq![2, 3]);
            assert(a@ == seq![100, 1]);
            assert(b@ == seq![2, 3]);
            assert(false); // FAILS
        }

        fn mut_ref_vec_index_mut_ref_fails() {
            let mut a: Vec<u64> = vec![0, 1];
            let mut b: Vec<u64> = vec![2, 3];

            let mut x = &mut a;
            let r = &mut x[({ x = &mut b; 0 })];
            *r = 100;
            assert((*x)@ == seq![2, 3]);
            assert(a@ == seq![100, 1]);
            assert(b@ == seq![2, 3]);
            assert(false); // FAILS
        }
    } => Err(err) => assert_fails(err, 3)
}

test_verify_one_file_with_options! {
    #[test] overwrite_vec_during_indexing3 [] => verus_code! {
        use vstd::prelude::*;

        fn mut_ref_vec_index_read() {
            let mut a: Vec<u64> = vec![0, 1];
            let mut b: Vec<u64> = vec![2, 3];

            let mut x = &mut a;
            let j = x[({ x = &mut b; 0 })];
            x[0] = 200;
            assert((*x)@ == seq![200, 3]);
            assert(j == 0);
        }

        fn mut_ref_vec_index_assign() {
            let mut a: Vec<u64> = vec![0, 1];
            let mut b: Vec<u64> = vec![2, 3];

            let mut x = &mut a;
            x[({ x = &mut b; 0 })] = 100;
            x[0] = 200;

            assert((*x)@ == seq![200, 3]);
            assert(a@ == seq![100, 1]);
            assert(b@ == seq![200, 3]);
        }

        fn mut_ref_vec_index_mut_ref() {
            let mut a: Vec<u64> = vec![0, 1];
            let mut b: Vec<u64> = vec![2, 3];

            let mut x = &mut a;
            let r = &mut x[({ x = &mut b; 0 })];
            *r = 100;
            x[0] = 200;
            assert((*x)@ == seq![200, 3]);
            assert(a@ == seq![100, 1]);
            assert(b@ == seq![200, 3]);
        }

        fn mut_ref_vec_index_read_fails() {
            let mut a: Vec<u64> = vec![0, 1];
            let mut b: Vec<u64> = vec![2, 3];

            let mut x = &mut a;
            let j = x[({ x = &mut b; 0 })];
            x[0] = 200;
            assert((*x)@ == seq![200, 3]);
            assert(j == 0);
            assert(false); // FAILS
        }

        fn mut_ref_vec_index_assign_fails() {
            let mut a: Vec<u64> = vec![0, 1];
            let mut b: Vec<u64> = vec![2, 3];

            let mut x = &mut a;
            x[({ x = &mut b; 0 })] = 100;
            x[0] = 200;

            assert((*x)@ == seq![200, 3]);
            assert(a@ == seq![100, 1]);
            assert(b@ == seq![200, 3]);
            assert(false); // FAILS
        }

        fn mut_ref_vec_index_mut_ref_fails() {
            let mut a: Vec<u64> = vec![0, 1];
            let mut b: Vec<u64> = vec![2, 3];

            let mut x = &mut a;
            let r = &mut x[({ x = &mut b; 0 })];
            *r = 100;
            x[0] = 200;
            assert((*x)@ == seq![200, 3]);
            assert(a@ == seq![100, 1]);
            assert(b@ == seq![200, 3]);
            assert(false); // FAILS
        }
    } => Err(err) => assert_fails(err, 3)
}

test_verify_one_file_with_options! {
    #[test] overwrite_during_indexing [] => verus_code! {
        use vstd::prelude::*;

        // I was kinda surprised most of these are accepted by rustc,
        // and I executed all of these to double-check the behavior here.
        // The semantics are that you compute the "place" in its entirety
        // before reading or writing to the place.
        // This means that in this test, the assignment in the index operation always
        // happens first, i.e., `a[({ a = b; 0 })]` is equivalent to `a = b; a[0]`

        fn array_index_read() {
            let mut a: [u64; 2] = [0, 1];
            let b: [u64; 2] = [2, 3];

            let j = a[({ a = b; 0 })];
            assert(j == 2);
        }

        fn array_index_assign() {
            let mut a: [u64; 2] = [0, 1];
            let b: [u64; 2] = [2, 3];

            a[({ a = b; 0 })] = 100;
            assert(a == [100, 3]);
            assert(b == [2, 3]);
        }

        fn array_index_mut_ref() {
            let mut a: [u64; 2] = [0, 1];
            let b: [u64; 2] = [2, 3];

            let r = &mut a[({ a = b; 0 })];
            *r = 100;
            assert(a == [100, 3]);
            assert(b == [2, 3]);
        }

        fn mut_ref_array_index_read() {
            let mut a: [u64; 2] = [0, 1];
            let mut b: [u64; 2] = [2, 3];

            let mut x = &mut a;
            let j = x[({ x = &mut b; 0 })];
            assert(j == 2);
        }

        fn mut_ref_array_index_assign() {
            let mut a: [u64; 2] = [0, 1];
            let mut b: [u64; 2] = [2, 3];

            let mut x = &mut a;
            x[({ x = &mut b; 0 })] = 100;
            assert(a == [0, 1]);
            assert(b == [100, 3]);
        }

        fn mut_ref_array_index_mut_ref() {
            let mut a: [u64; 2] = [0, 1];
            let mut b: [u64; 2] = [2, 3];

            let mut x = &mut a;
            let r = &mut x[({ x = &mut b; 0 })];
            *r = 100;
            assert(a == [0, 1]);
            assert(b == [100, 3]);
        }

        fn double_mut_ref_array_index_read() {
            let mut a: [u64; 2] = [0, 1];
            let mut b: [u64; 2] = [2, 3];
            let mut a_ref = &mut a;
            let mut b_ref = &mut b;

            let mut x: &mut &mut [u64; 2] = &mut a_ref;
            let j = x[({ x = &mut b_ref; 0 })];
            assert(j == 2);
        }

        fn double_mut_ref_array_index_assign() {
            let mut a: [u64; 2] = [0, 1];
            let mut b: [u64; 2] = [2, 3];
            let mut a_ref = &mut a;
            let mut b_ref = &mut b;

            let mut x: &mut &mut [u64; 2] = &mut a_ref;
            x[({ x = &mut b_ref; 0 })] = 100;
            assert(a == [0, 1]);
            assert(b == [100, 3]);
        }

        fn double_mut_ref_array_index_mut_ref() {
            let mut a: [u64; 2] = [0, 1];
            let mut b: [u64; 2] = [2, 3];
            let mut a_ref = &mut a;
            let mut b_ref = &mut b;

            let mut x: &mut &mut [u64; 2] = &mut a_ref;
            let r = &mut x[({ x = &mut b_ref; 0 })];
            *r = 100;
            assert(a == [0, 1]);
            assert(b == [100, 3]);
        }

        fn mut_ref_array2_index_read() {
            let mut a: [[u64; 2]; 2] = [[0, 1], [10, 11]];
            let mut b: [[u64; 2]; 2] = [[2, 3], [12, 13]];

            let mut x = &mut a;
            let j = x[1][({ x = &mut b; 0 })];
            assert(j == 12);
        }

        fn mut_ref_array2_index_assign() {
            let mut a: [[u64; 2]; 2] = [[0, 1], [10, 11]];
            let mut b: [[u64; 2]; 2] = [[2, 3], [12, 13]];

            let mut x = &mut a;
            x[1][({ x = &mut b; 0 })] = 100;
            assert(a@[0] == [0, 1] && a[1] == [10, 11]);
            assert(b@[0] == [2, 3] && b[1] == [100, 13]);
        }

        fn mut_ref_array2_index_mut_ref() {
            let mut a: [[u64; 2]; 2] = [[0, 1], [10, 11]];
            let mut b: [[u64; 2]; 2] = [[2, 3], [12, 13]];

            let mut x = &mut a;
            let r = &mut x[1][({ x = &mut b; 0 })];
            *r = 100;
            assert(a@[0] == [0, 1] && a[1] == [10, 11]);
            assert(b@[0] == [2, 3] && b[1] == [100, 13]);
        }

        fn mut_ref_slice_index_read() {
            let mut a: [u64; 2] = [0, 1];
            let mut b: [u64; 2] = [2, 3];

            let slice1: &mut [u64] = &mut a;
            let slice2: &mut [u64] = &mut b;

            let mut x = slice1;
            let j = x[({ x = slice2; 0 })];
            assert(j == 2);
        }

        fn mut_ref_slice_index_assign() {
            let mut a: [u64; 2] = [0, 1];
            let mut b: [u64; 2] = [2, 3];

            let slice1: &mut [u64] = &mut a;
            let slice2: &mut [u64] = &mut b;

            let mut x = slice1;
            x[({ x = slice2; 0 })] = 100;
            assert(a == [0, 1]);
            assert(b == [100, 3]);
        }

        fn mut_ref_slice_index_mut_ref() {
            let mut a: [u64; 2] = [0, 1];
            let mut b: [u64; 2] = [2, 3];

            let slice1: &mut [u64] = &mut a;
            let slice2: &mut [u64] = &mut b;

            let mut x = slice1;
            x[({ x = slice2; 0 })] = 100;
            assert(a == [0, 1]);
            assert(b == [100, 3]);
        }
    } => Ok(())
}

test_verify_one_file_with_options! {
    #[test] overwrite_during_indexing_fails [] => verus_code! {
        use vstd::prelude::*;

        fn array_index_read() {
            let mut a: [u64; 2] = [0, 1];
            let b: [u64; 2] = [2, 3];

            let j = a[({ a = b; 0 })];
            assert(j == 2);
            assert(false); // FAILS
        }

        fn array_index_assign() {
            let mut a: [u64; 2] = [0, 1];
            let b: [u64; 2] = [2, 3];

            a[({ a = b; 0 })] = 100;
            assert(a == [100, 3]);
            assert(b == [2, 3]);
            assert(false); // FAILS
        }

        fn array_index_mut_ref() {
            let mut a: [u64; 2] = [0, 1];
            let b: [u64; 2] = [2, 3];

            let r = &mut a[({ a = b; 0 })];
            *r = 100;
            assert(a == [100, 3]);
            assert(b == [2, 3]);
            assert(false); // FAILS
        }

        fn mut_ref_array_index_read() {
            let mut a: [u64; 2] = [0, 1];
            let mut b: [u64; 2] = [2, 3];

            let mut x = &mut a;
            let j = x[({ x = &mut b; 0 })];
            assert(j == 2);
            assert(false); // FAILS
        }

        fn mut_ref_array_index_assign() {
            let mut a: [u64; 2] = [0, 1];
            let mut b: [u64; 2] = [2, 3];

            let mut x = &mut a;
            x[({ x = &mut b; 0 })] = 100;
            assert(a == [0, 1]);
            assert(b == [100, 3]);
            assert(false); // FAILS
        }

        fn mut_ref_array_index_mut_ref() {
            let mut a: [u64; 2] = [0, 1];
            let mut b: [u64; 2] = [2, 3];

            let mut x = &mut a;
            let r = &mut x[({ x = &mut b; 0 })];
            *r = 100;
            assert(a == [0, 1]);
            assert(b == [100, 3]);
            assert(false); // FAILS
        }

        fn double_mut_ref_array_index_read() {
            let mut a: [u64; 2] = [0, 1];
            let mut b: [u64; 2] = [2, 3];
            let mut a_ref = &mut a;
            let mut b_ref = &mut b;

            let mut x: &mut &mut [u64; 2] = &mut a_ref;
            let j = x[({ x = &mut b_ref; 0 })];
            assert(j == 2);
            assert(false); // FAILS
        }

        fn double_mut_ref_array_index_assign() {
            let mut a: [u64; 2] = [0, 1];
            let mut b: [u64; 2] = [2, 3];
            let mut a_ref = &mut a;
            let mut b_ref = &mut b;

            let mut x: &mut &mut [u64; 2] = &mut a_ref;
            x[({ x = &mut b_ref; 0 })] = 100;
            assert(a == [0, 1]);
            assert(b == [100, 3]);
            assert(false); // FAILS
        }

        fn double_mut_ref_array_index_mut_ref() {
            let mut a: [u64; 2] = [0, 1];
            let mut b: [u64; 2] = [2, 3];
            let mut a_ref = &mut a;
            let mut b_ref = &mut b;

            let mut x: &mut &mut [u64; 2] = &mut a_ref;
            let r = &mut x[({ x = &mut b_ref; 0 })];
            *r = 100;
            assert(a == [0, 1]);
            assert(b == [100, 3]);
            assert(false); // FAILS
        }

        fn mut_ref_array2_index_read() {
            let mut a: [[u64; 2]; 2] = [[0, 1], [10, 11]];
            let mut b: [[u64; 2]; 2] = [[2, 3], [12, 13]];

            let mut x = &mut a;
            let j = x[1][({ x = &mut b; 0 })];
            assert(j == 12);
            assert(false); // FAILS
        }

        fn mut_ref_array2_index_assign() {
            let mut a: [[u64; 2]; 2] = [[0, 1], [10, 11]];
            let mut b: [[u64; 2]; 2] = [[2, 3], [12, 13]];

            let mut x = &mut a;
            x[1][({ x = &mut b; 0 })] = 100;
            assert(a@[0] == [0, 1] && a[1] == [10, 11]);
            assert(b@[0] == [2, 3] && b[1] == [100, 13]);
            assert(false); // FAILS
        }

        fn mut_ref_array2_index_mut_ref() {
            let mut a: [[u64; 2]; 2] = [[0, 1], [10, 11]];
            let mut b: [[u64; 2]; 2] = [[2, 3], [12, 13]];

            let mut x = &mut a;
            let r = &mut x[1][({ x = &mut b; 0 })];
            *r = 100;
            assert(a@[0] == [0, 1] && a[1] == [10, 11]);
            assert(b@[0] == [2, 3] && b[1] == [100, 13]);
            assert(false); // FAILS
        }

        fn mut_ref_slice_index_read() {
            let mut a: [u64; 2] = [0, 1];
            let mut b: [u64; 2] = [2, 3];

            let slice1: &mut [u64] = &mut a;
            let slice2: &mut [u64] = &mut b;

            let mut x = slice1;
            let j = x[({ x = slice2; 0 })];
            assert(j == 2);
            assert(false); // FAILS
        }

        fn mut_ref_slice_index_assign() {
            let mut a: [u64; 2] = [0, 1];
            let mut b: [u64; 2] = [2, 3];

            let slice1: &mut [u64] = &mut a;
            let slice2: &mut [u64] = &mut b;

            let mut x = slice1;
            x[({ x = slice2; 0 })] = 100;
            assert(a == [0, 1]);
            assert(b == [100, 3]);
            assert(false); // FAILS
        }

        fn mut_ref_slice_index_mut_ref() {
            let mut a: [u64; 2] = [0, 1];
            let mut b: [u64; 2] = [2, 3];

            let slice1: &mut [u64] = &mut a;
            let slice2: &mut [u64] = &mut b;

            let mut x = slice1;
            x[({ x = slice2; 0 })] = 100;
            assert(a == [0, 1]);
            assert(b == [100, 3]);
            assert(false); // FAILS
        }
    } => Err(err) => assert_fails(err, 15)
}

test_verify_one_file_with_options! {
    #[test] overwrite_during_indexing2 [] => verus_code! {
        use vstd::prelude::*;
        fn id<A>(a: A) -> (ret: A) ensures ret == a { a }

        fn array_index_read() {
            let mut a: [u64; 2] = [0, 1];
            let b: [u64; 2] = [2, 3];

            let j = id(a[({ a = b; 0 })]);
            assert(j == 2);
        }

        fn mut_ref_array_index_read() {
            let mut a: [u64; 2] = [0, 1];
            let mut b: [u64; 2] = [2, 3];

            let mut x = &mut a;
            let j = id(x[({ x = &mut b; 0 })]);
            assert(j == 2);
        }

        fn double_mut_ref_array_index_read() {
            let mut a: [u64; 2] = [0, 1];
            let mut b: [u64; 2] = [2, 3];
            let mut a_ref = &mut a;
            let mut b_ref = &mut b;

            let mut x = &mut a_ref;
            let j = id(x[({ x = &mut b_ref; 0 })]);
            assert(j == 2);
        }

        fn mut_ref_array2_index_read() {
            let mut a: [[u64; 2]; 2] = [[0, 1], [10, 11]];
            let mut b: [[u64; 2]; 2] = [[2, 3], [12, 13]];

            let mut x = &mut a;
            let j = id(x[1][({ x = &mut b; 0 })]);
            assert(j == 12);
        }

        fn mut_ref_slice_index_read() {
            let mut a: [u64; 2] = [0, 1];
            let mut b: [u64; 2] = [2, 3];

            let slice1: &mut [u64] = &mut a;
            let slice2: &mut [u64] = &mut b;

            let mut x = slice1;
            let j = id(x[({ x = slice2; 0 })]);
            assert(j == 2);
        }
    } => Ok(())
}

test_verify_one_file_with_options! {
    #[test] overwrite_during_indexing2_fails [] => verus_code! {
        use vstd::prelude::*;
        fn id<A>(a: A) -> (ret: A) ensures ret == a { a }

        fn array_index_read() {
            let mut a: [u64; 2] = [0, 1];
            let b: [u64; 2] = [2, 3];

            let j = id(a[({ a = b; 0 })]);
            assert(j == 2);
            assert(false); // FAILS
        }

        fn mut_ref_array_index_read() {
            let mut a: [u64; 2] = [0, 1];
            let mut b: [u64; 2] = [2, 3];

            let mut x = &mut a;
            let j = id(x[({ x = &mut b; 0 })]);
            assert(j == 2);
            assert(false); // FAILS
        }

        fn double_mut_ref_array_index_read() {
            let mut a: [u64; 2] = [0, 1];
            let mut b: [u64; 2] = [2, 3];
            let mut a_ref = &mut a;
            let mut b_ref = &mut b;

            let mut x = &mut a_ref;
            let j = id(x[({ x = &mut b_ref; 0 })]);
            assert(j == 2);
            assert(false); // FAILS
        }

        fn mut_ref_array2_index_read() {
            let mut a: [[u64; 2]; 2] = [[0, 1], [10, 11]];
            let mut b: [[u64; 2]; 2] = [[2, 3], [12, 13]];

            let mut x = &mut a;
            let j = id(x[1][({ x = &mut b; 0 })]);
            assert(j == 12);
            assert(false); // FAILS
        }

        fn mut_ref_slice_index_read() {
            let mut a: [u64; 2] = [0, 1];
            let mut b: [u64; 2] = [2, 3];

            let slice1: &mut [u64] = &mut a;
            let slice2: &mut [u64] = &mut b;

            let mut x = slice1;
            let j = id(x[({ x = slice2; 0 })]);
            assert(j == 2);
            assert(false); // FAILS
        }
    } => Err(err) => assert_fails(err, 5)
}

test_verify_one_file_with_options! {
    #[test] overwrite_during_ctor_tail [] => verus_code! {
        use vstd::prelude::*;
        struct Foo {
            i: u64,
            j: u64,
            k: u64,
        }

        fn array_index_ctor_tail() {
            let mut a: [Foo; 2] = [Foo{i: 0, j: 1, k: 2}, Foo{i: 3, j: 4, k: 5}];
            let b: [Foo; 2] = [Foo{i: 6, j: 7, k: 8}, Foo{i: 9, j: 10, k: 11}];

            let j = Foo { i: 12, .. a[({ a = b; 0 })] };
            assert(j == Foo { i: 12, j: 7, k: 8 });
        }

        fn mut_ref_array_index_ctor_tail() {
            let mut a: [Foo; 2] = [Foo{i: 0, j: 1, k: 2}, Foo{i: 3, j: 4, k: 5}];
            let mut b: [Foo; 2] = [Foo{i: 6, j: 7, k: 8}, Foo{i: 9, j: 10, k: 11}];

            let mut x = &mut a;
            let j = Foo { i: 12, .. x[({ x = &mut b; 0 })] };
            assert(j == Foo { i: 12, j: 7, k: 8 });
        }

        fn double_mut_ref_array_index_ctor_tail() {
            let mut a: [Foo; 2] = [Foo{i: 0, j: 1, k: 2}, Foo{i: 3, j: 4, k: 5}];
            let mut b: [Foo; 2] = [Foo{i: 6, j: 7, k: 8}, Foo{i: 9, j: 10, k: 11}];
            let mut a_ref = &mut a;
            let mut b_ref = &mut b;

            let mut x = &mut a_ref;
            let j = Foo { i: 12, .. x[({ x = &mut b_ref; 0 })] };
            assert(j == Foo { i: 12, j: 7, k: 8 });
        }

        fn mut_ref_array2_index_ctor_tail() {
            let mut a: [[Foo; 2]; 2] = [
                [Foo{i: 0, j: 1, k: 2}, Foo{i: 3, j: 4, k: 5}],
                [Foo{i: 200, j: 201, k: 202}, Foo{i: 203, j: 204, k: 205}],
            ];
            let mut b: [[Foo; 2]; 2] = [
                [Foo{i: 6, j: 7, k: 8}, Foo{i: 9, j: 10, k: 11}],
                [Foo{i: 206, j: 207, k: 208}, Foo{i: 209, j: 2010, k: 2011}],
            ];

            let mut x = &mut a;
            let j = Foo { i: 12, .. x[1][({ x = &mut b; 0 })] };
            assert(j == Foo { i: 12, j: 207, k: 208 });
        }

        fn mut_ref_slice_index_ctor_tail() {
            let mut a: [Foo; 2] = [Foo{i: 0, j: 1, k: 2}, Foo{i: 3, j: 4, k: 5}];
            let mut b: [Foo; 2] = [Foo{i: 6, j: 7, k: 8}, Foo{i: 9, j: 10, k: 11}];

            let slice1: &mut [Foo] = &mut a;
            let slice2: &mut [Foo] = &mut b;

            let mut x = slice1;
            let j = Foo { i: 12, .. x[({ x = slice2; 0 })] };
            assert(j == Foo { i: 12, j: 7, k: 8 });
        }
    } => Ok(())
}

test_verify_one_file_with_options! {
    #[test] overwrite_during_ctor_tail_fails [] => verus_code! {
        use vstd::prelude::*;
        struct Foo {
            i: u64,
            j: u64,
            k: u64,
        }

        fn array_index_ctor_tail() {
            let mut a: [Foo; 2] = [Foo{i: 0, j: 1, k: 2}, Foo{i: 3, j: 4, k: 5}];
            let b: [Foo; 2] = [Foo{i: 6, j: 7, k: 8}, Foo{i: 9, j: 10, k: 11}];

            let j = Foo { i: 12, .. a[({ a = b; 0 })] };
            assert(j == Foo { i: 12, j: 7, k: 8 });
            assert(false); // FAILS
        }

        fn mut_ref_array_index_ctor_tail() {
            let mut a: [Foo; 2] = [Foo{i: 0, j: 1, k: 2}, Foo{i: 3, j: 4, k: 5}];
            let mut b: [Foo; 2] = [Foo{i: 6, j: 7, k: 8}, Foo{i: 9, j: 10, k: 11}];

            let mut x = &mut a;
            let j = Foo { i: 12, .. x[({ x = &mut b; 0 })] };
            assert(j == Foo { i: 12, j: 7, k: 8 });
            assert(false); // FAILS
        }

        fn double_mut_ref_array_index_ctor_tail() {
            let mut a: [Foo; 2] = [Foo{i: 0, j: 1, k: 2}, Foo{i: 3, j: 4, k: 5}];
            let mut b: [Foo; 2] = [Foo{i: 6, j: 7, k: 8}, Foo{i: 9, j: 10, k: 11}];
            let mut a_ref = &mut a;
            let mut b_ref = &mut b;

            let mut x = &mut a_ref;
            let j = Foo { i: 12, .. x[({ x = &mut b_ref; 0 })] };
            assert(j == Foo { i: 12, j: 7, k: 8 });
            assert(false); // FAILS
        }

        fn mut_ref_array2_index_ctor_tail() {
            let mut a: [[Foo; 2]; 2] = [
                [Foo{i: 0, j: 1, k: 2}, Foo{i: 3, j: 4, k: 5}],
                [Foo{i: 200, j: 201, k: 202}, Foo{i: 203, j: 204, k: 205}],
            ];
            let mut b: [[Foo; 2]; 2] = [
                [Foo{i: 6, j: 7, k: 8}, Foo{i: 9, j: 10, k: 11}],
                [Foo{i: 206, j: 207, k: 208}, Foo{i: 209, j: 2010, k: 2011}],
            ];

            let mut x = &mut a;
            let j = Foo { i: 12, .. x[1][({ x = &mut b; 0 })] };
            assert(j == Foo { i: 12, j: 207, k: 208 });
            assert(false); // FAILS
        }

        fn mut_ref_slice_index_ctor_tail() {
            let mut a: [Foo; 2] = [Foo{i: 0, j: 1, k: 2}, Foo{i: 3, j: 4, k: 5}];
            let mut b: [Foo; 2] = [Foo{i: 6, j: 7, k: 8}, Foo{i: 9, j: 10, k: 11}];

            let slice1: &mut [Foo] = &mut a;
            let slice2: &mut [Foo] = &mut b;

            let mut x = slice1;
            let j = Foo { i: 12, .. x[({ x = slice2; 0 })] };
            assert(j == Foo { i: 12, j: 7, k: 8 });
            assert(false); // FAILS
        }
    } => Err(err) => assert_fails(err, 5)
}

test_verify_one_file_with_options! {
    #[test] overwrite_during_scrutinee [] => verus_code! {
        use vstd::prelude::*;
        struct Foo {
            i: u64,
            j: u64,
            k: u64,
        }

        fn array_index_read() {
            let mut a: [Foo; 2] = [Foo{i: 0, j: 1, k: 2}, Foo{i: 3, j: 4, k: 5}];
            let b: [Foo; 2] = [Foo{i: 6, j: 7, k: 8}, Foo{i: 9, j: 10, k: 11}];

            let j = match a[({ a = b; 0 })] {
                Foo { i, j, k } => (i, j, k),
            };
            assert(j == (6, 7, 8));
        }

        fn mut_ref_array_index_read() {
            let mut a: [Foo; 2] = [Foo{i: 0, j: 1, k: 2}, Foo{i: 3, j: 4, k: 5}];
            let mut b: [Foo; 2] = [Foo{i: 6, j: 7, k: 8}, Foo{i: 9, j: 10, k: 11}];

            let mut x = &mut a;
            let j = match x[({ x = &mut b; 0 })] {
                Foo { i, j, k } => (i, j, k),
            };
            assert(j == (6, 7, 8));
        }

        fn double_mut_ref_array_index_read() {
            let mut a: [Foo; 2] = [Foo{i: 0, j: 1, k: 2}, Foo{i: 3, j: 4, k: 5}];
            let mut b: [Foo; 2] = [Foo{i: 6, j: 7, k: 8}, Foo{i: 9, j: 10, k: 11}];
            let mut a_ref = &mut a;
            let mut b_ref = &mut b;

            let mut x = &mut a_ref;
            let j = match x[({ x = &mut b_ref; 0 })] {
                Foo { i, j, k } => (i, j, k),
            };
            assert(j == (6, 7, 8));
        }

        fn mut_ref_array2_index_read() {
            let mut a: [[Foo; 2]; 2] = [
                [Foo{i: 0, j: 1, k: 2}, Foo{i: 3, j: 4, k: 5}],
                [Foo{i: 200, j: 201, k: 202}, Foo{i: 203, j: 204, k: 205}],
            ];
            let mut b: [[Foo; 2]; 2] = [
                [Foo{i: 6, j: 7, k: 8}, Foo{i: 9, j: 10, k: 11}],
                [Foo{i: 206, j: 207, k: 208}, Foo{i: 209, j: 2010, k: 2011}],
            ];

            let mut x = &mut a;
            let j = match x[1][({ x = &mut b; 0 })] {
                Foo { i, j, k } => (i, j, k),
            };
            assert(j == (206, 207, 208));
        }

        fn mut_ref_slice_index_read() {
            let mut a: [Foo; 2] = [Foo{i: 0, j: 1, k: 2}, Foo{i: 3, j: 4, k: 5}];
            let mut b: [Foo; 2] = [Foo{i: 6, j: 7, k: 8}, Foo{i: 9, j: 10, k: 11}];

            let slice1: &mut [Foo] = &mut a;
            let slice2: &mut [Foo] = &mut b;

            let mut x = slice1;
            let j = match x[({ x = slice2; 0 })] {
                Foo { i, j, k } => (i, j, k),
            };
            assert(j == (6, 7, 8));
        }
    } => Ok(())
}

test_verify_one_file_with_options! {
    #[test] overwrite_during_scrutinee_fails [] => verus_code! {
        use vstd::prelude::*;
        struct Foo {
            i: u64,
            j: u64,
            k: u64,
        }

        fn array_index_read() {
            let mut a: [Foo; 2] = [Foo{i: 0, j: 1, k: 2}, Foo{i: 3, j: 4, k: 5}];
            let b: [Foo; 2] = [Foo{i: 6, j: 7, k: 8}, Foo{i: 9, j: 10, k: 11}];

            let j = match a[({ a = b; 0 })] {
                Foo { i, j, k } => (i, j, k),
            };
            assert(j == (6, 7, 8));
            assert(false); // FAILS
        }

        fn mut_ref_array_index_read() {
            let mut a: [Foo; 2] = [Foo{i: 0, j: 1, k: 2}, Foo{i: 3, j: 4, k: 5}];
            let mut b: [Foo; 2] = [Foo{i: 6, j: 7, k: 8}, Foo{i: 9, j: 10, k: 11}];

            let mut x = &mut a;
            let j = match x[({ x = &mut b; 0 })] {
                Foo { i, j, k } => (i, j, k),
            };
            assert(j == (6, 7, 8));
            assert(false); // FAILS
        }

        fn double_mut_ref_array_index_read() {
            let mut a: [Foo; 2] = [Foo{i: 0, j: 1, k: 2}, Foo{i: 3, j: 4, k: 5}];
            let mut b: [Foo; 2] = [Foo{i: 6, j: 7, k: 8}, Foo{i: 9, j: 10, k: 11}];
            let mut a_ref = &mut a;
            let mut b_ref = &mut b;

            let mut x = &mut a_ref;
            let j = match x[({ x = &mut b_ref; 0 })] {
                Foo { i, j, k } => (i, j, k),
            };
            assert(j == (6, 7, 8));
            assert(false); // FAILS
        }

        fn mut_ref_array2_index_read() {
            let mut a: [[Foo; 2]; 2] = [
                [Foo{i: 0, j: 1, k: 2}, Foo{i: 3, j: 4, k: 5}],
                [Foo{i: 200, j: 201, k: 202}, Foo{i: 203, j: 204, k: 205}],
            ];
            let mut b: [[Foo; 2]; 2] = [
                [Foo{i: 6, j: 7, k: 8}, Foo{i: 9, j: 10, k: 11}],
                [Foo{i: 206, j: 207, k: 208}, Foo{i: 209, j: 2010, k: 2011}],
            ];

            let mut x = &mut a;
            let j = match x[1][({ x = &mut b; 0 })] {
                Foo { i, j, k } => (i, j, k),
            };
            assert(j == (206, 207, 208));
            assert(false); // FAILS
        }

        fn mut_ref_slice_index_read() {
            let mut a: [Foo; 2] = [Foo{i: 0, j: 1, k: 2}, Foo{i: 3, j: 4, k: 5}];
            let mut b: [Foo; 2] = [Foo{i: 6, j: 7, k: 8}, Foo{i: 9, j: 10, k: 11}];

            let slice1: &mut [Foo] = &mut a;
            let slice2: &mut [Foo] = &mut b;

            let mut x = slice1;
            let j = match x[({ x = slice2; 0 })] {
                Foo { i, j, k } => (i, j, k),
            };
            assert(j == (6, 7, 8));
            assert(false); // FAILS
        }
    } => Err(err) => assert_fails(err, 5)
}

test_verify_one_file_with_options! {
    #[test] resolution_move_from_array_error [] => verus_code! {
        struct X { }

        fn id<A>(a: A) -> A { a }

        fn test_basic_move<T>(t: [X; 2]) {
            let r = id(t[0]);
        }
    } => Err(err) => assert_vir_error_msg(err, "cannot move out of type `[test_crate::X; 2]`, which is non-copy")
}

test_verify_one_file_with_options! {
    #[test] resolution_move_from_array_error2 [] => verus_code! {
        struct X { }

        fn test_basic_move<T>(t: [X; 2]) {
            let r = t[0];
        }
    } => Err(err) => assert_rust_error_msg(err, "cannot move out of type `[X; 2]`, a non-copy array")
}

test_verify_one_file_with_options! {
    #[test] resolution_move_from_array_error3 [] => verus_code! {
        struct X { }

        struct Pair<A, B> {
            a: A,
            b: B,
        }

        fn test_ctor_move<T>(t: [Pair<X, X>; 2]) {
            let r = Pair { a: X{}, .. t[0] };
        }
    } => Err(err) => assert_vir_error_msg(err, "cannot move out of type `[test_crate::Pair<test_crate::X, test_crate::X>; 2]`, which is non-copy")
}

test_verify_one_file_with_options! {
    #[test] not_extensional_equ [] => verus_code! {
        proof fn x<T>(a: &mut T, b: &mut T) {
            assume(mut_ref_current(a) == mut_ref_current(b));
            assume(mut_ref_future(a) == mut_ref_future(b));

            // Mut refs can't have extensional equality like this; this would make `a == b`
            // a prophetic operation. In the VerusBelt model, every mut ref has a unique "name".
            assert(a == b); // FAILS
        }
    } => Err(err) => assert_fails(err, 1)
}

test_verify_one_file_with_options! {
    #[test] final_is_not_decreases [] => verus_code! {
        use vstd::prelude::*;

        struct Rec {
            g: Option<Ghost<&'static mut Rec>>,
        }

        fn test() {
            let mut r = Rec { g: None };

            let mut r_ref = &mut r;
            *r_ref = Rec { g: Some(Ghost(r_ref)) };

            // We're allowed to create this value with a "cycle"
            assert(r.g.is_some());
            assert(r == *final(r.g.unwrap()@));

            // This is okay because 'final' doesn't imply 'decreases_to'.
            // In the VerusBelt model, final is only obtained by "looking up" the value
            // in the prophecy assignment table,
            // not by structural recursion on an inductive datatype.
            assert(decreases_to!(r => r.g));
            assert(decreases_to!(r.g => r.g.unwrap()));
            let ghost bad_dec = decreases_to!(r.g.unwrap()@ => *final(r.g.unwrap()@));
            assert(bad_dec); // FAILS
        }
    } => Err(err) => assert_fails(err, 1)
}

test_verify_one_file! {
    // Regression: nested associated-type projection in a mutable-field path.
    #[test] assoc_projection_nested_trait_mut_ref_regression verus_code! {
        trait Node {
            type Cell;
        }

        trait Wrap {
            type Item: Node;
        }

        struct Root;
        struct Tag;
        struct Slot {
            x: u64,
            y: u64,
        }

        impl Node for Tag {
            type Cell = Slot;
        }

        impl Wrap for Root {
            type Item = Tag;
        }

        struct Container<T: Wrap> {
            data: <T::Item as Node>::Cell,
        }

        #[verifier::external_body]
        fn touch(Tracked(v): Tracked<&mut u64>) {
            unimplemented!()
        }

        fn trigger() {
            let tracked mut c = Container::<Root> { data: Slot { x: 3, y: 9 } };
            touch(Tracked(&mut c.data.x));
        }
    } => Ok(())
}

test_verify_one_file! {
    // Regression: two mutable references into distinct fields under an associated-type field.
    #[test] assoc_projection_two_mut_fields_regression verus_code! {
        trait Assoc {
            type Data;
        }

        struct Root;
        struct Data {
            x: u64,
            y: u64,
            z: u64,
        }

        impl Assoc for Root {
            type Data = Data;
        }

        struct Holder<T: Assoc> {
            value: T::Data,
        }

        #[verifier::external_body]
        fn touch2(Tracked(a): Tracked<&mut u64>, Tracked(b): Tracked<&mut u64>) {
            unimplemented!()
        }

        fn trigger() {
            let tracked mut h = Holder::<Root> { value: Data { x: 0, y: 1, z: 2 } };
            touch2(Tracked(&mut h.value.x), Tracked(&mut h.value.y));
        }
    } => Ok(())
}

test_verify_one_file! {
    // Regression: mutable field update through a projection type where the
    // underlying datatype has type parameters. An earlier fix rejected this
    // case because it tried to synthesize the datatype type from scratch.
    #[test] assoc_projection_generic_datatype_regression verus_code! {
        trait Node {
            type Cell;
        }

        trait Wrap {
            type Item: Node;
        }

        struct Root;
        struct Tag;

        struct Slot<T> {
            x: T,
            y: T,
        }

        impl Node for Tag {
            type Cell = Slot<u64>;
        }

        impl Wrap for Root {
            type Item = Tag;
        }

        struct Container<T: Wrap> {
            data: <T::Item as Node>::Cell,
        }

        #[verifier::external_body]
        fn touch(Tracked(v): Tracked<&mut u64>) {
            unimplemented!()
        }

        fn trigger() {
            let tracked mut c = Container::<Root> { data: Slot { x: 3, y: 9 } };
            touch(Tracked(&mut c.data.x));
        }
    } => Ok(())
}

test_verify_one_file_with_options! {
    #[test] proof_fn_returns_mut_ref [] => verus_code! {
        pub tracked struct X { ghost g: int }

        pub tracked struct S {
            pub tracked perm: X,
        }

        proof fn test_tracked_mut_ref(tracked input: &mut S) -> (tracked output: &mut X)
            ensures
                *output == old(input).perm,
                *final(output) == final(input).perm,
        {
            &mut input.perm
        }

        proof fn test1(tracked input: &mut S) {
            let tracked output = test_tracked_mut_ref(input);
            output.g = 20;
            assert(input.perm.g == 20);
        }

        proof fn test1_fails(tracked input: &mut S) {
            let tracked output = test_tracked_mut_ref(input);
            output.g = 20;
            assert(input.perm.g == 20);
            assert(false); // FAILS
        }
    } => Err(err) => assert_fails(err, 1)
}

test_verify_one_file_with_options! {
    #[test] async_could_get_cancelled [] => verus_code! {
        use vstd::prelude::*;

        async fn callee() {
        }

        #[verifier::exec_allows_no_decreases_clause]
        fn blah() -> &'static mut u64 {
            loop { }
        }

        async fn test1(x: &mut &mut u64) {
            let mr = blah();
            let c = callee();

            let j = c.await;
            assert(has_resolved(*x));
            *x = mr;
        }

        async fn test2(x: &mut &mut u64) {
            let mr = blah();
            let c = callee();

            assert(has_resolved(*x)); // FAILS
            let j = c.await;
            *x = mr;
        }
    } => Err(err) => assert_fails(err, 1)
}

test_verify_one_file_with_options! {
    #[test] test_local_invariant [] => verus_code! {
        use vstd::prelude::*;
        use vstd::invariant::*;

        struct Pred;
        impl<'a> InvariantPredicate<(), &'a mut Ghost<u64>> for Pred {
            closed spec fn inv(k: (), v: &'a mut Ghost<u64>) -> bool {
                5 <= (*v)@ <= 13
            }
        }

        fn test1(Tracked(inv): Tracked<&LocalInvariant<(), &mut Ghost<u64>, Pred>>) {
            open_local_invariant!(inv => i => {
                assert(has_resolved(i)); // FAILS
            });
        }

        fn test2(Tracked(inv): Tracked<&LocalInvariant<(), &mut Ghost<u64>, Pred>>) {
            open_local_invariant!(inv => i => {
                proof { *i = Ghost(12); }
            });
        }
    } => Err(err) => assert_fails(err, 1)
}

test_verify_one_file_with_options! {
    #[test] test_local_invariant2 [] => verus_code! {
        use vstd::prelude::*;
        use vstd::invariant::*;

        struct Pred;
        impl<'a> InvariantPredicate<(), &'a mut Ghost<u64>> for Pred {
            closed spec fn inv(k: (), v: &'a mut Ghost<u64>) -> bool {
                5 <= (*v)@ <= 13
            }
        }

        fn test3(Tracked(inv): Tracked<&LocalInvariant<(), &mut Ghost<u64>, Pred>>) {
            open_local_invariant!(inv => i => {
                proof { *i = Ghost(19); }
            });
        }
    } => Err(err) => assert_vir_error_msg(err, "Cannot show invariant holds at end of block")
}

test_verify_one_file_with_options! {
    #[test] test_local_invariant_control_flow [] => verus_code! {
        use vstd::prelude::*;
        use vstd::invariant::*;

        struct Pred;
        impl<'a> InvariantPredicate<(), &'a mut Ghost<u64>> for Pred {
            closed spec fn inv(k: (), v: &'a mut Ghost<u64>) -> bool {
                5 <= (*v)@ <= 13
            }
        }

        fn test1(Tracked(inv): Tracked<&LocalInvariant<(), &mut Ghost<u64>, Pred>>) {
            let mut x: Ghost<u64> = Ghost(0);
            let x_ref = &mut x;
            open_local_invariant!(({ *x_ref = Ghost(20u64); inv }) => i => {
                proof { *i = Ghost(12); }
            });
            assert(x == 20);
            assert(false); // FAILS
        }

        fn test2(Tracked(inv): Tracked<&LocalInvariant<(), &mut Ghost<u64>, Pred>>) {
            let mut x: Ghost<u64> = Ghost(0);
            let x_ref = &mut x;
            open_local_invariant!(inv => i => {
                *x_ref = Ghost(20u64);
                proof { *i = Ghost(12); }
            });
            assert(x == 20);
            assert(false); // FAILS
        }
    } => Err(err) => assert_fails(err, 2)
}

test_verify_one_file_with_options! {
    #[test] mut_ref_assign_in_rhs [] => verus_code! {
        fn test1() {
            let mut a = 0;
            let mut a_ref = &mut a;

            let mut b = 1;
            let mut c = 2;

            a_ref = ({ a_ref = &mut b; *a_ref = 20; &mut c });
            *a_ref = 30;

            assert(a == 0);
            assert(b == 20);
            assert(c == 30);
        }

        fn test2() {
            let mut a = 0;
            let mut a_ref = &mut a;

            let mut b = 1;
            let mut c = 2;

            *a_ref = ({ a_ref = &mut b; *a_ref = 20; 30 });

            assert(a == 0);
            assert(b == 30);
        }


        fn fails1() {
            let mut a = 0;
            let mut a_ref = &mut a;

            let mut b = 1;
            let mut c = 2;

            a_ref = ({ a_ref = &mut b; *a_ref = 20; &mut c });
            *a_ref = 30;

            assert(a == 0);
            assert(b == 20);
            assert(c == 30);
            assert(false); // FAILS
        }

        fn fails2() {
            let mut a = 0;
            let mut a_ref = &mut a;

            let mut b = 1;
            let mut c = 2;

            *a_ref = ({ a_ref = &mut b; *a_ref = 20; 30 });

            assert(a == 0);
            assert(b == 30);
            assert(false); // FAILS
        }
    } => Err(err) => assert_fails(err, 2)
}

test_verify_one_file_with_options! {
    #[test] compound_op_primitive_evaluation_order [] => verus_code! {
        use vstd::prelude::*;

        fn test_primitive() {
            let mut x = [0, 1];
            let mut y = 0;
            // rhs first
            x[({ y = 3*y + 1; 0 })] += ({ y = 3*y + 2; 2 });
            assert(y == 7);
        }

        fn test_primitive_mut_refs() {
            let mut a = 0;
            let a_ref = &mut a;
            let mut x = [0, 1];
            // rhs first
            x[({ *a_ref = 1; 0 })] += ({ *a_ref = 2; 2 });
            assert(a == 1);
        }

        fn fails_primitive() {
            let mut x = [0, 1];
            let mut y = 0;
            // rhs first
            x[({ y = 3*y + 1; 0 })] += ({ y = 3*y + 2; 2 });
            assert(y == 7);
            assert(false); // FAILS
        }

        fn fails_primitive_mut_refs() {
            let mut a = 0;
            let a_ref = &mut a;
            let mut x = [0, 1];
            // rhs first
            x[({ *a_ref = 1; 0 })] += ({ *a_ref = 2; 2 });
            assert(a == 1);
            assert(false); // FAILS
        }
    } => Err(err) => assert_fails(err, 2)
}

test_verify_one_file_with_options! {
    #[test] compound_op_overloaded_evaluation_order [] => verus_code! {
        // Future-proofing test; overloaded compound assignment isn't supported yet
        use vstd::prelude::*;
        use vstd::std_specs::ops::AddAssignSpec;

        pub struct X {
            pub a: u64,
        }

        impl std::ops::AddAssign<u64> for X {
            fn add_assign(&mut self, other: u64)
            {
                *self = X { a: self.a & other };
            }
        }

        impl vstd::std_specs::ops::AddAssignSpecImpl<u64> for X {
            open spec fn obeys_add_assign_spec() -> bool {
                true
            }
            open spec fn add_assign_req(&self, other: u64) -> bool {
                true
            }
            open spec fn add_assign_spec(&self, other: u64) -> &X {
                &(X { a: self.a & other })
            }
        }

        fn test_overload() {
            let mut x = [X { a: 0 }, X { a: 1 }];
            let mut y = 0;
            // lhs first
            x[({ y = 3*y + 1; 0 })] += ({ y = 3*y + 2; 2 });
            assert(y == 5);
        }

        fn test_overload_mut_refs() {
            let mut a = 0;
            let a_ref = &mut a;
            let mut x = [X { a: 0 }, X { a: 1 }];
            // lhs first
            x[({ *a_ref = 1; 0 })] += ({ *a_ref = 2; 2 });
            assert(a == 2);
        }

        fn fails_overload() {
            let mut x = [X { a: 0 }, X { a: 1 }];
            let mut y = 0;
            // lhs first
            x[({ y = 3*y + 1; 0 })] += ({ y = 3*y + 2; 2 });
            assert(y == 5);
            assert(false); // FAILS
        }

        fn fails_overload_mut_refs() {
            let mut a = 0;
            let a_ref = &mut a;
            let mut x = [X { a: 0 }, X { a: 1 }];
            // lhs first
            x[({ *a_ref = 1; 0 })] += ({ *a_ref = 2; 2 });
            assert(a == 2);
            assert(false); // FAILS
        }
    } => Err(err) => assert_fails(err, 2)
}

test_verify_one_file_with_options! {
    #[test] coarse_grained [] => verus_code! {
        // For this test, the analysis operates over subplaces r.0 and r.1
        // to prove the assert, we need the analysis that is based on explicit asserts
        fn test() {
            let mut a = 0;
            let mut b = 0;
            let r = (&mut a, &mut b);

            *r.0 = 20;

            assert(has_resolved(r));
        }

        fn test2() {
            let mut a = 0;
            let mut b = 0;
            let r = (&mut a, &mut b);

            *r.0 = 20;

            // Using {r} stops the heuristic from working
            assert(has_resolved({r})); // FAILS
        }
    } => Err(err) => assert_fails(err, 1)
}

test_verify_one_file_with_options! {
    #[test] trivial_resolve [] => verus_code! {
        // Resolution of non-mut-ref types are skipped by default
        // unless you explicitly trigger them
        fn test() {
            let mut a = 0;
            assert(has_resolved(a));
        }

        fn test2() {
            let mut a = 0;
            assert(has_resolved({a})); // FAILS
        }
    } => Err(err) => assert_fails(err, 1)
}

test_verify_one_file_with_options! {
    #[test] typ_param_resolve [] => verus_code! {
        // Params are always resolvable, even without an assert to trigger it
        fn test<T>(a: T) {
            assert(has_resolved(a));
        }

        fn test2<T>(a: T) {
            assert(has_resolved({a}));
        }
    } => Ok(())
}

test_verify_one_file_with_options! {
    #[test] option_resolve [] => verus_code! {
        enum Option<V> { Some(V), None }

        // Params are always resolvable, even without an assert to trigger it
        fn test<T>(a: Option<T>) {
            assert(has_resolved(a));
        }

        fn test2<T>(a: Option<T>) {
            assert(has_resolved({a}));
        }

        fn test3<T>(a: Option<u8>) {
            assert(has_resolved(a));
        }

        fn test4<T>(a: Option<u8>) {
            assert(has_resolved({a})); // FAILS
        }
    } => Err(err) => assert_fails(err, 1)
}

test_verify_one_file_with_options! {
    #[test] mut_ref_in_return_stmt_unit_return [] => verus_code! {
        pub fn mutates(Tracked(a): Tracked<&mut int>)
        {
        }

        pub fn returns(Tracked(a): Tracked<&mut int>) {
            return mutates(Tracked(a));
        }
    } => Ok(())
}

test_verify_one_file_with_options! {
    #[test] if_with_no_else_issue3187 [] => verus_code! {
        use vstd::prelude::*;

        fn f(c: bool) -> (res: u64)
            ensures c ==> res == 5,
                !c ==> res == 0,
        {
            let mut x = 0u64;
            let r = &mut x;
            let mut z: Option<&mut u64> = None;

            if c {
                let r2 = r;
                z = Some(r2);
            }

            match z {
                Some(r3) => { *r3 = 5; }
                None => {}
            }

            x
        }

        fn f_fails1(c: bool) -> (res: u64)
            ensures !c, // FAILS
        {
            let mut x = 0u64;
            let r = &mut x;
            let mut z: Option<&mut u64> = None;

            if c {
                let r2 = r;
                z = Some(r2);
            }

            match z {
                Some(r3) => { *r3 = 5; }
                None => {}
            }

            x
        }

        fn f_fails2(c: bool) -> (res: u64)
            ensures c, // FAILS
        {
            let mut x = 0u64;
            let r = &mut x;
            let mut z: Option<&mut u64> = None;

            if c {
                let r2 = r;
                z = Some(r2);
            }

            match z {
                Some(r3) => { *r3 = 5; }
                None => {}
            }

            x
        }
    } => Err(err) => assert_fails(err, 2)
}
