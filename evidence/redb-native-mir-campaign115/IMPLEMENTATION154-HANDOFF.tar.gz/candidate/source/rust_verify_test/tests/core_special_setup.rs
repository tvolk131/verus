#![feature(rustc_private)]
#[macro_use]
mod common;
use common::*;

test_verify_one_file_with_options! {
    #[test] test_is_core ["--is-core", "no-auto-import-verus_builtin"] => code! {
        #![allow(unused_parens)]
        #![allow(unused_imports)]
        #![allow(dead_code)]
        #![allow(unused_attributes)]
        #![allow(unused_variables)]

        #![cfg_attr(verus_keep_ghost, feature(atomic_internals))]
        #![cfg_attr(verus_keep_ghost, feature(generic_atomic))]
        #![cfg_attr(verus_keep_ghost, feature(core_intrinsics))]
        #![cfg_attr(verus_keep_ghost, feature(allocator_api))]
        #![cfg_attr(verus_keep_ghost, feature(step_trait))]
        #![cfg_attr(verus_keep_ghost, feature(ptr_metadata))]

        #![cfg_attr(verus_keep_ghost, feature(derive_clone_copy_internals))]
        #![cfg_attr(verus_keep_ghost, feature(slice_index_methods))]
        #![cfg_attr(verus_keep_ghost, feature(freeze))]
        #![cfg_attr(verus_keep_ghost, feature(sized_hierarchy))]
        #![cfg_attr(verus_keep_ghost, feature(const_destruct))]
        #![cfg_attr(verus_keep_ghost, feature(derive_eq_internals))]
        #![feature(hint_must_use)]
        #![cfg_attr(verus_keep_ghost, feature(fmt_internals))]
        #![cfg_attr(verus_keep_ghost, feature(fmt_arguments_from_str))]
        #![cfg_attr(verus_keep_ghost, feature(panic_internals))]
        #![cfg_attr(
            verus_keep_ghost,
            feature(fn_traits),
        )]

        #[verifier::external]
        #[path="../../../../builtin/src/lib.rs"]
        mod verus_builtin;

        #[path="../../../../vstd/vstd.rs"]
        mod vstd;

        mod test {
            use crate::vstd::set::*;
            use crate::vstd::seq::*;
            use crate::vstd::multiset::*;
            use crate::vstd::prelude::*;

            verus!{

            proof fn test_seqs(a: Seq<int>, b: Seq<int>)
                requires a == b,
            {
                crate::vstd::seq_lib::assert_seqs_equal!(a, b);
                crate::vstd::seq_lib::assert_seqs_equal!(a == b);
            }

            proof fn test_sets(a: Set<int>, b: Set<int>)
                requires a == b,
            {
                crate::vstd::set_lib::assert_sets_equal!(a, b);
                crate::vstd::set_lib::assert_sets_equal!(a == b);
            }

            proof fn test_multisets(a: Multiset<int>, b: Multiset<int>)
                requires a == b,
            {
                crate::vstd::multiset::assert_multisets_equal!(a, b);
                crate::vstd::multiset::assert_multisets_equal!(a == b);
            }

            broadcast use crate::vstd::slice::group_slice_axioms;

            fn test_slice_index(x: &[u8]) -> u8
                requires x@.len() > 0
            {
                x[0]
            }

            fn test_tuple_clone<A: Clone, B: Clone>(value: &(A, B)) -> (result: (A, B))
                ensures
                    cloned(value.0, result.0),
                    cloned(value.1, result.1),
            {
                value.clone()
            }

            fn test_native_option_bridges(condition: bool, value: u64) -> (result: u64)
                ensures result == if condition { value } else { 0 },
            {
                let option = crate::vstd::native_option::then_some(condition, value);
                crate::vstd::native_option::map_or(option, 0, |payload: u64| -> (output: u64)
                    ensures output == payload,
                { payload })
            }

            fn test_ptr_stuff(a: *mut u8, b: *mut [u8; 2]) {
                let t = a as *mut u16;
                let s = b as *mut [u8];
            }

            }
        }

        fn main() { }
    } => Ok(())
}
