// A simple type checker for better diagnostics.
// (Z3 and the Z3 crate will also type-check, but their type errors are uninformative panics)

use crate::ast::{
    Axiom, BinaryOp, BindX, Binder, BinderX, Binders, Constant, Decl, DeclX, Expr, ExprX, Ident,
    MultiOp, Query, QueryX, Stmt, StmtX, Typ, TypX, TypeError, Typs, UnaryOp,
};
use crate::context::{Context, SmtEncoding};
use crate::messages::MessageInterface;
use crate::printer::{Printer, node_to_string};
use crate::scope_map::ScopeMap;
use crate::util::vec_map;
use std::collections::HashSet;
use std::sync::Arc;

pub(crate) type Declared = Arc<DeclaredX>;
#[derive(Clone, Debug)]
pub(crate) enum DeclaredX {
    Type,
    Var { typ: Typ, mutable: bool },
    Fun { params: Typs, ret: Typ, field_accessor: bool }, //args, ret, accessor
}

pub struct Typing {
    pub(crate) message_interface: Arc<dyn MessageInterface>,
    // For simplicity, global and local names must be unique (bound variables can have the same name)
    pub(crate) decls: ScopeMap<Ident, Declared>,
    pub(crate) snapshots: HashSet<Ident>,
    pub(crate) break_labels_local: HashSet<Ident>,
    pub(crate) break_labels_in_scope: ScopeMap<Ident, ()>,
    pub(crate) smt_encoding: SmtEncoding,
}

impl Typing {
    pub(crate) fn get(&self, x: &Ident) -> Option<&DeclaredX> {
        match self.decls.get(x) {
            None => None,
            Some(declared) => Some(&**declared),
        }
    }

    pub(crate) fn insert(&mut self, x: &Ident, d: Declared) -> Result<(), TypeError> {
        self.decls.insert(x.clone(), d).map_err(|_| format!("name {} is already in scope", x))
    }
}

pub fn bt() -> Typ {
    Arc::new(TypX::Bool)
}

pub fn it() -> Typ {
    Arc::new(TypX::Int)
}

pub fn rt() -> Typ {
    Arc::new(TypX::Real)
}

fn typ_name(typ: &Typ) -> String {
    match &**typ {
        TypX::Bool => "Bool".to_string(),
        TypX::Int => "Int".to_string(),
        TypX::Real => "Real".to_string(),
        TypX::Fun => "Fun".to_string(),
        TypX::Named(x) => x.to_string(),
        TypX::BitVec(n) => format!("BitVec{}", n),
        TypX::Float { exp_bits, sig_bits } => format!("Float{exp_bits}_{sig_bits}"),
    }
}

pub fn typ_eq(typ1: &Typ, typ2: &Typ) -> bool {
    typ1 == typ2
}

fn expect_typ(typ1: &Typ, typ2: &Typ, msg: &str) -> Result<(), TypeError> {
    if typ_eq(typ1, typ2) { Ok(()) } else { Err(msg.to_string()) }
}

fn check_typ(typing: &Typing, typ: &Typ) -> Result<(), TypeError> {
    match &**typ {
        TypX::Bool => Ok(()),
        TypX::Int => Ok(()),
        TypX::Real => Ok(()),
        TypX::Fun => Ok(()),
        TypX::Named(x) => match typing.get(x) {
            Some(DeclaredX::Type) => Ok(()),
            _ => Err(format!("use of undeclared type {}", x)),
        },
        TypX::BitVec(_) => Ok(()),
        TypX::Float { exp_bits, sig_bits } => {
            if *exp_bits <= 1 || *sig_bits <= 1 {
                Err(format!(
                    "unsupported floating point type (_ FloatingPoint {exp_bits} {sig_bits})"
                ))
            } else {
                Ok(())
            }
        }
    }
}

fn check_typs(typing: &Typing, typs: &[Typ]) -> Result<(), TypeError> {
    for typ in typs {
        let result = check_typ(typing, typ);
        if let Err(_) = result {
            return result;
        }
    }
    Ok(())
}

fn check_has_typs(
    _typing: &mut Typing,
    f_name: &str,
    f_typs: &[Typ],
    f_typ: &Typ,
    arg_typs: &[Typ],
) -> Result<Typ, TypeError> {
    if f_typs.len() != arg_typs.len() {
        return Err(format!(
            "in call to {}, expected {} arguments, found {} arguments",
            f_name,
            f_typs.len(),
            arg_typs.len()
        ));
    }
    for i in 0..f_typs.len() {
        let et = &arg_typs[i];
        if !typ_eq(et, &f_typs[i]) {
            return Err(format!(
                "in call to {}, argument #{} has type {:?} when it should have type {:?}",
                f_name,
                (i + 1),
                typ_name(&et),
                typ_name(&f_typs[i])
            ));
        }
    }
    Ok(f_typ.clone())
}

fn check_exprs(
    typing: &mut Typing,
    f_name: &str,
    f_typs: &[Typ],
    f_typ: &Typ,
    exprs: &[Expr],
) -> Result<Typ, TypeError> {
    let arg_typs: Result<Vec<Typ>, TypeError> =
        exprs.iter().map(|e| check_expr(typing, e)).collect();
    check_has_typs(typing, f_name, f_typs, f_typ, &arg_typs?)
}

// If exprs[0] has type real, check that all exprs are real, otherwise check that all exprs are int
fn check_exprs_int_or_real(
    typing: &mut Typing,
    f_name: &str,
    n_f_typs: usize,
    f_typ: &Option<Typ>,
    exprs: &[Expr],
) -> Result<Typ, TypeError> {
    let arg_typs: Result<Vec<Typ>, TypeError> =
        exprs.iter().map(|e| check_expr(typing, e)).collect();
    let arg_typs = arg_typs?;
    let scalar_typ =
        if arg_typs.len() > 0 && matches!(&*arg_typs[0], TypX::Real) { rt() } else { it() };
    let f_typ = f_typ.as_ref().unwrap_or(&scalar_typ);
    let f_typs: Vec<Typ> = (0..n_f_typs).into_iter().map(|_| scalar_typ.clone()).collect();
    check_has_typs(typing, f_name, &f_typs, f_typ, &arg_typs)
}

fn get_bv_width(et: &Typ) -> Result<u32, TypeError> {
    if let TypX::BitVec(size) = &**et {
        return Ok(*size);
    }
    Err("not a bit vector type".to_string())
}

fn check_bv_unary_exprs(
    typing: &mut Typing,
    op: UnaryOp,
    f_name: &str,
    expr: &Expr,
) -> Result<Typ, TypeError> {
    match op {
        UnaryOp::BitExtract(high, lo) => {
            let t0 = check_expr(typing, expr)?;
            let w_old = get_bv_width(&t0)?;
            if w_old < high + 1 {
                Err(format!(
                    "Interner Error: bit-vec extract to a longer size. {} to {} ",
                    w_old, high
                ))
            } else if lo > high {
                Err(format!("Interner Error: bit-vec extract has lo > high. {} to {} ", lo, high))
            } else {
                Ok(Arc::new(TypX::BitVec(high + 1 - lo)))
            }
        }
        UnaryOp::BitNot | UnaryOp::BitNeg => {
            let t0 = check_expr(typing, expr)?;
            match get_bv_width(&t0) {
                Ok(_) => Ok(t0.clone()),
                Err(..) => Err("Interner Error: not a bv type inside a bvnot".to_string()),
            }
        }
        UnaryOp::BitZeroExtend(n) | UnaryOp::BitSignExtend(n) => {
            let t0 = check_expr(typing, expr)?;
            match get_bv_width(&t0) {
                Ok(m) => Ok(Arc::new(TypX::BitVec(n + m))),
                Err(..) => Err(format!("Interner Error: not a bv type inside a {}", f_name)),
            }
        }
        _ => Err(format!("Interner Error: not a bv unary op, got {}", f_name)),
    }
}

fn check_bv_exprs(
    typing: &mut Typing,
    bop: BinaryOp,
    f_name: &str,
    exprs: &[Expr],
) -> Result<Typ, TypeError> {
    let t0 = check_expr(typing, &exprs[0])?;
    let t1 = check_expr(typing, &exprs[1])?;
    let w0 = get_bv_width(&t0)?;
    let w1 = get_bv_width(&t1)?;

    if BinaryOp::BitConcat == bop {
        return Ok(Arc::new(TypX::BitVec(w0 + w1)));
    }

    if w0 != w1 {
        return Err(format!(
            "in call to {}, arguments should have the same width, but got {} and {}",
            f_name, w0, w1
        ));
    }

    // return bool type if it is comparision op
    match bop {
        BinaryOp::BitUGe | BinaryOp::BitULe | BinaryOp::BitUGt | BinaryOp::BitULt => Ok(bt()),
        BinaryOp::BitSGe | BinaryOp::BitSLe | BinaryOp::BitSGt | BinaryOp::BitSLt => Ok(bt()),
        _ => Ok(t0.clone()),
    }
}

fn check_float_unary_exprs(
    typing: &mut Typing,
    op: UnaryOp,
    f_name: &str,
    expr: &Expr,
) -> Result<Typ, TypeError> {
    let t0 = check_expr(typing, expr)?;
    // See https://smt-lib.org/theories-FloatingPoint.shtml for types of each operation
    match &*t0 {
        TypX::Float { exp_bits, sig_bits } => match op {
            UnaryOp::FloatNeg => Ok(t0.clone()),
            UnaryOp::FloatRoundToInt(_) => Ok(t0.clone()),
            UnaryOp::FloatIsNormal
            | UnaryOp::FloatIsSubnormal
            | UnaryOp::FloatIsZero
            | UnaryOp::FloatIsInfinite
            | UnaryOp::FloatIsNaN
            | UnaryOp::FloatIsNegative
            | UnaryOp::FloatIsPositive => Ok(bt()),
            UnaryOp::FloatToBitVec { bits, .. } => Ok(Arc::new(TypX::BitVec(bits))),
            UnaryOp::FloatToIeeeBits => Ok(Arc::new(TypX::BitVec(exp_bits + sig_bits))),
            UnaryOp::FloatToReal => Ok(rt()),
            _ => unreachable!(),
        },
        _ => Err(format!(
            "in call to {}, expected a floating point argument, but got {}",
            f_name,
            typ_name(&t0),
        )),
    }
}

fn check_float_exprs(
    typing: &mut Typing,
    bop: BinaryOp,
    f_name: &str,
    exprs: &[Expr],
) -> Result<Typ, TypeError> {
    let t0 = check_expr(typing, &exprs[0])?;
    let t1 = check_expr(typing, &exprs[1])?;
    // See https://smt-lib.org/theories-FloatingPoint.shtml for types of each operation
    match (&*t0, &*t1) {
        (
            TypX::Float { exp_bits: exp_bits0, sig_bits: sig_bits0 },
            TypX::Float { exp_bits: exp_bits1, sig_bits: sig_bits1 },
        ) if exp_bits0 == exp_bits1 && sig_bits0 == sig_bits1 => match bop {
            BinaryOp::FloatEq
            | BinaryOp::FloatLt
            | BinaryOp::FloatGt
            | BinaryOp::FloatLe
            | BinaryOp::FloatGe => Ok(bt()),
            BinaryOp::FloatAdd(_)
            | BinaryOp::FloatSub(_)
            | BinaryOp::FloatMul(_)
            | BinaryOp::FloatDiv(_) => Ok(t0.clone()),
            _ => unreachable!(),
        },
        _ => Err(format!(
            "in call to {}, expected both arguments to have the same floating point type, but got {} and {}",
            f_name,
            typ_name(&t0),
            typ_name(&t1)
        )),
    }
}

fn check_expr(typing: &mut Typing, expr: &Expr) -> Result<Typ, TypeError> {
    let result = match &**expr {
        ExprX::Const(Constant::Bool(_)) => Ok(Arc::new(TypX::Bool)),
        ExprX::Const(Constant::Nat(_)) => Ok(Arc::new(TypX::Int)),
        ExprX::Const(Constant::Real(_)) => Ok(Arc::new(TypX::Real)),
        ExprX::Const(Constant::BitVec(_, width)) => Ok(Arc::new(TypX::BitVec(*width))),
        ExprX::Var(x) => match typing.get(x) {
            Some(DeclaredX::Var { typ, .. }) => Ok(typ.clone()),
            _ => Err(format!("use of undeclared variable {}", x)),
        },
        ExprX::Old(snap, x) => match (typing.snapshots.contains(snap), typing.get(x)) {
            (false, _) => Err(format!("use of undeclared snapshot {}", snap)),
            (true, Some(DeclaredX::Var { typ, .. })) => Ok(typ.clone()),
            (true, _) => Err(format!("use of undeclared variable {}", x)),
        },
        ExprX::Apply(x, es) => match typing.get(x).cloned() {
            Some(DeclaredX::Fun { params, ret, field_accessor: _ }) => {
                check_exprs(typing, x, &params, &ret, es)
            }
            _ => Err(format!("use of undeclared function {}", x)),
        },
        ExprX::ApplyFun(t, e0, es) => {
            let t0 = check_expr(typing, e0)?;
            match &*t0 {
                TypX::Fun => {
                    for e in es.iter() {
                        check_expr(typing, e)?;
                    }
                    Ok(t.clone())
                }
                _ => Err("expected function type".to_string()),
            }
        }
        ExprX::Unary(UnaryOp::Not, e1) => {
            check_exprs(typing, "not", &[bt()], &bt(), std::slice::from_ref(e1))
        }
        ExprX::Unary(UnaryOp::BitNot, e1) => {
            check_bv_unary_exprs(typing, UnaryOp::BitNot, "bvnot", &e1.clone())
        }
        ExprX::Unary(UnaryOp::BitNeg, e1) => {
            check_bv_unary_exprs(typing, UnaryOp::BitNeg, "bvneg", &e1.clone())
        }
        ExprX::Unary(UnaryOp::BitExtract(high, low), e1) => {
            check_bv_unary_exprs(typing, UnaryOp::BitExtract(*high, *low), "extract", &e1.clone())
        }
        ExprX::Unary(UnaryOp::BitZeroExtend(n), e1) => {
            check_bv_unary_exprs(typing, UnaryOp::BitZeroExtend(*n), "zero_extend", &e1.clone())
        }
        ExprX::Unary(UnaryOp::BitSignExtend(n), e1) => {
            check_bv_unary_exprs(typing, UnaryOp::BitSignExtend(*n), "sign_extend", &e1.clone())
        }
        ExprX::Unary(op @ UnaryOp::FloatNeg, e1) => {
            check_float_unary_exprs(typing, op.clone(), "float_neg", &e1.clone())
        }
        ExprX::Unary(op @ UnaryOp::FloatRoundToInt(_), e1) => {
            check_float_unary_exprs(typing, op.clone(), "float_round_to_int", &e1.clone())
        }
        ExprX::Unary(op @ UnaryOp::FloatIsNormal, e1) => {
            check_float_unary_exprs(typing, op.clone(), "float_is_normal", &e1.clone())
        }
        ExprX::Unary(op @ UnaryOp::FloatIsSubnormal, e1) => {
            check_float_unary_exprs(typing, op.clone(), "float_is_subnormal", &e1.clone())
        }
        ExprX::Unary(op @ UnaryOp::FloatIsZero, e1) => {
            check_float_unary_exprs(typing, op.clone(), "float_is_zero", &e1.clone())
        }
        ExprX::Unary(op @ UnaryOp::FloatIsInfinite, e1) => {
            check_float_unary_exprs(typing, op.clone(), "float_is_infinite", &e1.clone())
        }
        ExprX::Unary(op @ UnaryOp::FloatIsNaN, e1) => {
            check_float_unary_exprs(typing, op.clone(), "float_is_nan", &e1.clone())
        }
        ExprX::Unary(op @ UnaryOp::FloatIsNegative, e1) => {
            check_float_unary_exprs(typing, op.clone(), "float_is_negative", &e1.clone())
        }
        ExprX::Unary(op @ UnaryOp::FloatIsPositive, e1) => {
            check_float_unary_exprs(typing, op.clone(), "float_is_positive", &e1.clone())
        }
        ExprX::Unary(UnaryOp::FloatFromIeeeBits { exp_bits, sig_bits }, e1) => {
            let t1 = check_expr(typing, e1)?;
            match &*t1 {
                TypX::BitVec(n) if *n == exp_bits + sig_bits => {
                    Ok(Arc::new(TypX::Float { exp_bits: *exp_bits, sig_bits: *sig_bits }))
                }
                _ => Err(format!(
                    "in float_from_ieee_bits, expected argument of type (_ BitVec {}) but found {}",
                    exp_bits + sig_bits,
                    typ_name(&t1)
                )),
            }
        }
        ExprX::Unary(UnaryOp::FloatFrom { exp_bits, sig_bits, signed, round: _ }, e1) => {
            let t1 = check_expr(typing, e1)?;
            let tf = Arc::new(TypX::Float { exp_bits: *exp_bits, sig_bits: *sig_bits });
            match (&*t1, signed) {
                (TypX::Real, true) => Ok(tf),
                (TypX::Float { .. }, true) => Ok(tf),
                (TypX::BitVec(_), _) => Ok(tf),
                _ => Err(format!(
                    "in float_from, expected argument of type Real or BitVec but found {}",
                    typ_name(&t1)
                )),
            }
        }
        ExprX::Unary(op @ UnaryOp::FloatToBitVec { .. }, e1) => {
            check_float_unary_exprs(typing, op.clone(), "float_to_bitvec", &e1.clone())
        }
        ExprX::Unary(UnaryOp::FloatToIeeeBits, e1) => check_float_unary_exprs(
            typing,
            UnaryOp::FloatToIeeeBits,
            "float_to_ieee_bits",
            &e1.clone(),
        ),
        ExprX::Unary(UnaryOp::FloatToReal, e1) => {
            check_float_unary_exprs(typing, UnaryOp::FloatToReal, "float_to_real", &e1.clone())
        }
        ExprX::Unary(UnaryOp::ToReal, e1) => {
            check_exprs(typing, "to_real", &[it()], &rt(), std::slice::from_ref(e1))
        }
        ExprX::Unary(UnaryOp::RealToInt, e1) => {
            check_exprs(typing, "to_int", &[rt()], &it(), std::slice::from_ref(e1))
        }
        ExprX::Binary(BinaryOp::Implies, e1, e2) => {
            check_exprs(typing, "=>", &[bt(), bt()], &bt(), &[e1.clone(), e2.clone()])
        }
        ExprX::Binary(op @ (BinaryOp::Eq | BinaryOp::Relation(..)), e1, e2) => {
            let t1 = check_expr(typing, e1)?;
            let t2 = check_expr(typing, e2)?;
            if typ_eq(&t1, &t2) {
                Ok(bt())
            } else {
                Err(format!(
                    "in {}, left expression has type {} and right expression has different type {}",
                    match op {
                        BinaryOp::Eq => "equality",
                        _ => "relation",
                    },
                    typ_name(&t1),
                    typ_name(&t2)
                ))
            }
        }
        ExprX::Binary(BinaryOp::FieldUpdate(field_ident), e1, e2) => {
            let t1 = check_expr(typing, e1)?;
            let t2 = check_expr(typing, e2)?;

            match &*t1 {
                TypX::Named(s) => match typing.get(s) {
                    Some(DeclaredX::Type) => {}
                    _ => return Err(format!("in field update, the destination is not a datatype")),
                },
                _ => return Err(format!("in field update, the destination is not a datatype")),
            }

            if let Some(DeclaredX::Fun { params, ret, field_accessor: true }) =
                typing.get(field_ident)
            {
                if let [s] = &params[..] {
                    if t1 != *s {
                        Err(format!(
                            "in field-update, argument type {:?} does not match datatype type {:?}",
                            t1, *s
                        ))
                    } else if t2 != *ret {
                        Err(format!(
                            "in field-update, type of new value ({:?}) does not match field type {:?}",
                            t2, *ret
                        ))
                    } else {
                        Ok(t1)
                    }
                } else {
                    Err(format!("field accessor {:?} should only have one parameter", field_ident))
                }
            } else {
                Err(format!("cannot find field accessor {:?}", field_ident))
            }
        }
        ExprX::Binary(BinaryOp::Le, e1, e2) => {
            check_exprs_int_or_real(typing, "<=", 2, &Some(bt()), &[e1.clone(), e2.clone()])
        }
        ExprX::Binary(BinaryOp::Ge, e1, e2) => {
            check_exprs_int_or_real(typing, ">=", 2, &Some(bt()), &[e1.clone(), e2.clone()])
        }
        ExprX::Binary(BinaryOp::Lt, e1, e2) => {
            check_exprs_int_or_real(typing, "<", 2, &Some(bt()), &[e1.clone(), e2.clone()])
        }
        ExprX::Binary(BinaryOp::Gt, e1, e2) => {
            check_exprs_int_or_real(typing, ">", 2, &Some(bt()), &[e1.clone(), e2.clone()])
        }
        ExprX::Binary(BinaryOp::EuclideanDiv, e1, e2) => {
            check_exprs(typing, "div", &[it(), it()], &it(), &[e1.clone(), e2.clone()])
        }
        ExprX::Binary(BinaryOp::EuclideanMod, e1, e2) => {
            check_exprs(typing, "mod", &[it(), it()], &it(), &[e1.clone(), e2.clone()])
        }
        ExprX::Binary(BinaryOp::RealDiv, e1, e2) => {
            check_exprs(typing, "/", &[rt(), rt()], &rt(), &[e1.clone(), e2.clone()])
        }
        ExprX::Binary(BinaryOp::BitULt, e1, e2) => {
            check_bv_exprs(typing, BinaryOp::BitULt, "bvlt", &[e1.clone(), e2.clone()])
        }
        ExprX::Binary(BinaryOp::BitUGt, e1, e2) => {
            check_bv_exprs(typing, BinaryOp::BitUGt, "bvgt", &[e1.clone(), e2.clone()])
        }
        ExprX::Binary(BinaryOp::BitULe, e1, e2) => {
            check_bv_exprs(typing, BinaryOp::BitULe, "bvle", &[e1.clone(), e2.clone()])
        }
        ExprX::Binary(BinaryOp::BitUGe, e1, e2) => {
            check_bv_exprs(typing, BinaryOp::BitUGe, "bvge", &[e1.clone(), e2.clone()])
        }
        ExprX::Binary(BinaryOp::BitSLt, e1, e2) => {
            check_bv_exprs(typing, BinaryOp::BitSLt, "bvslt", &[e1.clone(), e2.clone()])
        }
        ExprX::Binary(BinaryOp::BitSGt, e1, e2) => {
            check_bv_exprs(typing, BinaryOp::BitSGt, "bvsgt", &[e1.clone(), e2.clone()])
        }
        ExprX::Binary(BinaryOp::BitSLe, e1, e2) => {
            check_bv_exprs(typing, BinaryOp::BitSLe, "bvsle", &[e1.clone(), e2.clone()])
        }
        ExprX::Binary(BinaryOp::BitSGe, e1, e2) => {
            check_bv_exprs(typing, BinaryOp::BitSGe, "bvsge", &[e1.clone(), e2.clone()])
        }
        ExprX::Binary(BinaryOp::BitXor, e1, e2) => {
            check_bv_exprs(typing, BinaryOp::BitXor, "^", &[e1.clone(), e2.clone()])
        }
        ExprX::Binary(BinaryOp::BitURem, e1, e2) => {
            check_bv_exprs(typing, BinaryOp::BitURem, "bvurem", &[e1.clone(), e2.clone()])
        }
        ExprX::Binary(BinaryOp::BitAnd, e1, e2) => {
            check_bv_exprs(typing, BinaryOp::BitAnd, "&", &[e1.clone(), e2.clone()])
        }
        ExprX::Binary(BinaryOp::BitOr, e1, e2) => {
            check_bv_exprs(typing, BinaryOp::BitOr, "|", &[e1.clone(), e2.clone()])
        }
        ExprX::Binary(BinaryOp::BitAdd, e1, e2) => {
            check_bv_exprs(typing, BinaryOp::BitAdd, "bvadd", &[e1.clone(), e2.clone()])
        }
        ExprX::Binary(BinaryOp::BitSub, e1, e2) => {
            check_bv_exprs(typing, BinaryOp::BitSub, "bvsub", &[e1.clone(), e2.clone()])
        }
        ExprX::Binary(BinaryOp::BitMul, e1, e2) => {
            check_bv_exprs(typing, BinaryOp::BitMul, "bvmul", &[e1.clone(), e2.clone()])
        }
        ExprX::Binary(BinaryOp::BitUDiv, e1, e2) => {
            check_bv_exprs(typing, BinaryOp::BitUDiv, "bvudiv", &[e1.clone(), e2.clone()])
        }
        ExprX::Binary(BinaryOp::BitSDiv, e1, e2) => {
            check_bv_exprs(typing, BinaryOp::BitSDiv, "bvsdiv", &[e1.clone(), e2.clone()])
        }
        ExprX::Binary(BinaryOp::BitSRem, e1, e2) => {
            check_bv_exprs(typing, BinaryOp::BitSRem, "bvsrem", &[e1.clone(), e2.clone()])
        }
        ExprX::Binary(BinaryOp::LShr, e1, e2) => {
            check_bv_exprs(typing, BinaryOp::LShr, ">> (lshr)", &[e1.clone(), e2.clone()])
        }
        ExprX::Binary(BinaryOp::AShr, e1, e2) => {
            check_bv_exprs(typing, BinaryOp::AShr, ">> (ashr)", &[e1.clone(), e2.clone()])
        }
        ExprX::Binary(BinaryOp::Shl, e1, e2) => {
            check_bv_exprs(typing, BinaryOp::Shl, "<<", &[e1.clone(), e2.clone()])
        }
        ExprX::Binary(BinaryOp::BitConcat, e1, e2) => {
            check_bv_exprs(typing, BinaryOp::BitConcat, "concat", &[e1.clone(), e2.clone()])
        }
        ExprX::Binary(op @ BinaryOp::FloatAdd(_), e1, e2) => {
            check_float_exprs(typing, op.clone(), "float_add", &[e1.clone(), e2.clone()])
        }
        ExprX::Binary(op @ BinaryOp::FloatSub(_), e1, e2) => {
            check_float_exprs(typing, op.clone(), "float_sub", &[e1.clone(), e2.clone()])
        }
        ExprX::Binary(op @ BinaryOp::FloatMul(_), e1, e2) => {
            check_float_exprs(typing, op.clone(), "float_mul", &[e1.clone(), e2.clone()])
        }
        ExprX::Binary(op @ BinaryOp::FloatDiv(_), e1, e2) => {
            check_float_exprs(typing, op.clone(), "float_div", &[e1.clone(), e2.clone()])
        }
        ExprX::Binary(BinaryOp::FloatEq, e1, e2) => {
            check_float_exprs(typing, BinaryOp::FloatEq, "float_eq", &[e1.clone(), e2.clone()])
        }
        ExprX::Binary(BinaryOp::FloatLt, e1, e2) => {
            check_float_exprs(typing, BinaryOp::FloatLt, "float_lt", &[e1.clone(), e2.clone()])
        }
        ExprX::Binary(BinaryOp::FloatLe, e1, e2) => {
            check_float_exprs(typing, BinaryOp::FloatLe, "float_le", &[e1.clone(), e2.clone()])
        }
        ExprX::Binary(BinaryOp::FloatGt, e1, e2) => {
            check_float_exprs(typing, BinaryOp::FloatGt, "float_gt", &[e1.clone(), e2.clone()])
        }
        ExprX::Binary(BinaryOp::FloatGe, e1, e2) => {
            check_float_exprs(typing, BinaryOp::FloatGe, "float_ge", &[e1.clone(), e2.clone()])
        }
        ExprX::Multi(MultiOp::Float, exprs) => {
            if exprs.len() != 3 {
                Err(format!(
                    "floating point constructor expects 3 arguments, found {}",
                    exprs.len(),
                ))
            } else {
                let sign = check_expr(typing, &exprs[0])?;
                let exp = check_expr(typing, &exprs[1])?;
                let sig = check_expr(typing, &exprs[2])?;
                match (&*sign, &*exp, &*sig) {
                    (TypX::BitVec(1), TypX::BitVec(exp_bits), TypX::BitVec(sig1_bits))
                        if *exp_bits > 1 && *sig1_bits > 0 =>
                    {
                        Ok(Arc::new(TypX::Float { exp_bits: *exp_bits, sig_bits: *sig1_bits + 1 }))
                    }
                    _ => Err(format!(
                        "in floating point constructor, expected arguments of type (BitVec 1), (BitVec exp_bits), (BitVec sig1_bits) with exp_bits > 1 and sig1_bits > 0, but found {}, {}, {}",
                        typ_name(&sign),
                        typ_name(&exp),
                        typ_name(&sig)
                    )),
                }
            }
        }
        ExprX::Multi(op, exprs) => {
            let (x, t) = match op {
                MultiOp::And => ("and", bt()),
                MultiOp::Or => ("or", bt()),
                MultiOp::Xor => ("xor", bt()),
                MultiOp::Add => ("+", it()),
                MultiOp::Sub => ("-", it()),
                MultiOp::Mul => ("*", it()),
                MultiOp::Distinct => ("distinct", it()),
                MultiOp::Float => unreachable!(),
            };
            match op {
                MultiOp::Distinct => {
                    if exprs.len() > 0 {
                        let t0 = check_expr(typing, &exprs[0])?;
                        for e in &exprs[1..] {
                            let tk = check_expr(typing, e)?;
                            expect_typ(&tk, &t0, "arguments to distinct must all have same type")?;
                        }
                    }
                    Ok(bt())
                }
                MultiOp::Add | MultiOp::Sub | MultiOp::Mul => {
                    check_exprs_int_or_real(typing, x, exprs.len(), &None, exprs)
                }
                _ => {
                    let f_typs = vec_map(exprs, |_| t.clone());
                    check_exprs(typing, x, &f_typs, &t, exprs)
                }
            }
        }
        ExprX::IfElse(e1, e2, e3) => {
            let t1 = check_expr(typing, e1)?;
            let t2 = check_expr(typing, e2)?;
            let t3 = check_expr(typing, e3)?;
            if !typ_eq(&t1, &bt()) {
                Err(format!(
                    "in if/then/else, condition has type {} instead of Bool",
                    typ_name(&t1)
                ))
            } else if !typ_eq(&t2, &t3) {
                Err(format!(
                    "in if/then/else, left expression has type {} and right expression has different type {}",
                    typ_name(&t2),
                    typ_name(&t3)
                ))
            } else {
                Ok(t2)
            }
        }
        ExprX::Array(exprs) => {
            if exprs.len() > 0 {
                let t0 = check_expr(typing, &exprs[0])?;
                for e in &exprs[1..] {
                    let tk = check_expr(typing, e)?;
                    expect_typ(&tk, &t0, "arguments to array must all have same type")?;
                }
            }
            Ok(Arc::new(TypX::Fun))
        }
        ExprX::Bind(bind, e1) => {
            // For Let, get types of binder expressions
            let binders: Binders<Typ> = match &**bind {
                BindX::Let(bs) => {
                    let mut binders: Vec<Binder<Typ>> = Vec::new();
                    for b in bs.iter() {
                        let typ = check_expr(typing, &b.a)?;
                        binders.push(Arc::new(BinderX { name: b.name.clone(), a: typ }));
                    }
                    Arc::new(binders)
                }
                BindX::Quant(_, binders, _, _) => binders.clone(),
                BindX::Lambda(binders, _, _, _, _) => binders.clone(),
                BindX::Choose(binders, _, _, _) => binders.clone(),
            };
            // Typecheck WrapLambda outside binder scope
            if let BindX::Lambda(_, _, _, Some(wrap), _) = &**bind {
                let t_id = check_expr(typing, &wrap.id)?;
                let result = match typing.get(&wrap.wrap).cloned() {
                    Some(DeclaredX::Fun { params, ret, field_accessor: _ }) => {
                        if !matches!(&*ret, TypX::Fun) {
                            return Err(format!(
                                "in lambda, wrapper {} returns type {} instead of Fun",
                                wrap.wrap,
                                typ_name(&ret)
                            ));
                        }
                        check_has_typs(typing, &wrap.wrap, &params, &ret, &[t_id, ret.clone()])
                    }
                    _ => Err(format!("use of undeclared function {}", wrap.wrap)),
                };
                let _ = result?;
            }
            // Collect all binder names, make sure they are unique
            typing.decls.push_scope(true);
            for binder in binders.iter() {
                let x = &binder.name;
                let var = DeclaredX::Var { typ: binder.a.clone(), mutable: false };
                typing.insert(x, Arc::new(var))?;
            }
            // Type-check triggers
            match &**bind {
                BindX::Let(_) => {}
                BindX::Quant(_, _, triggers, _)
                | BindX::Choose(_, triggers, _, _)
                | BindX::Lambda(_, triggers, _, _, _) => {
                    for trigger in triggers.iter() {
                        for expr in trigger.iter() {
                            check_expr(typing, expr)?;
                        }
                    }
                }
            }
            // Type-check inner expressions
            match &**bind {
                BindX::Lambda(_, _, _, _, Some(e2)) | BindX::Choose(_, _, _, e2) => {
                    let t2 = check_expr(typing, e2)?;
                    if !typ_eq(&t2, &bt()) {
                        let s = match &**bind {
                            BindX::Lambda(_, _, _, _, _) => "lambda, condition",
                            BindX::Choose(_, _, _, _) => "choose, body",
                            _ => unreachable!(),
                        };
                        return Err(format!("in {} has type {} instead of Bool", s, typ_name(&t2)));
                    }
                }
                _ => {}
            }
            // Type-check expr
            let t1 = check_expr(typing, e1)?;
            let tb = match &**bind {
                BindX::Let(_) => t1,
                BindX::Quant(_, _, _, _) => {
                    expect_typ(&t1, &bt(), "forall/exists body must have type bool")?;
                    t1
                }
                BindX::Lambda(_, _, _, _, _) => Arc::new(TypX::Fun),
                BindX::Choose(..) => t1,
            };
            // Done
            typing.decls.pop_scope();
            Ok(tb)
        }
        ExprX::LabeledAssertion(_, _, _, expr) => check_expr(typing, expr),
        ExprX::LabeledAxiom(_, _, expr) => check_expr(typing, expr),
    };
    match result {
        Ok(t) => Ok(t),
        Err(err) => {
            let node_str = node_to_string(
                &Printer::new_with_encoding(
                    typing.message_interface.clone(),
                    false,
                    typing.smt_encoding,
                )
                .expr_to_node(expr),
            );
            Err(format!("error '{}' in expression '{}'", err, node_str))
        }
    }
}

fn check_stmt(typing: &mut Typing, stmt: &Stmt) -> Result<(), TypeError> {
    let result = match &**stmt {
        StmtX::Assume(expr) => expect_typ(
            &check_expr(typing, expr)?,
            &bt(),
            "assume statement expects expression of type bool",
        ),
        StmtX::Assert(_, _, _, expr) => expect_typ(
            &check_expr(typing, expr)?,
            &bt(),
            "assert statement expects expression of type bool",
        ),
        StmtX::Havoc(x) => match typing.get(x).cloned() {
            Some(DeclaredX::Var { mutable, .. }) => {
                if !mutable {
                    Err(format!("cannot assign to const variable {}", x))
                } else {
                    Ok(())
                }
            }
            _ => Err(format!("assignment to undeclared variable {}", x)),
        },
        StmtX::Assign(x, expr) => match typing.get(x).cloned() {
            Some(DeclaredX::Var { typ, mutable }) => {
                if !mutable {
                    Err(format!("cannot assign to const variable {}", x))
                } else {
                    let t_expr = check_expr(typing, expr)?;
                    if !typ_eq(&t_expr, &typ) {
                        Err(format!(
                            "in assignment, {} has type {}, while expression has type {}",
                            x,
                            typ_name(&typ),
                            typ_name(&t_expr)
                        ))
                    } else {
                        Ok(())
                    }
                }
            }
            _ => Err(format!("assignment to undeclared variable {}", x)),
        },
        StmtX::Snapshot(snap) => {
            typing.snapshots.insert(snap.clone());
            Ok(())
        }
        StmtX::DeadEnd(s) => check_stmt(typing, s),
        StmtX::Block(stmts) => {
            for s in stmts.iter() {
                check_stmt(typing, s)?;
            }
            Ok(())
        }
        StmtX::Breakable(label, s) => {
            if typing.break_labels_local.contains(label) {
                Err(format!("break label '{label}' declared more than once in same query"))
            } else {
                typing.break_labels_local.insert(label.clone());
                typing.break_labels_in_scope.push_scope(false);
                typing.break_labels_in_scope.insert(label.clone(), ()).expect("push break");
                check_stmt(typing, s)?;
                typing.break_labels_in_scope.pop_scope();
                Ok(())
            }
        }
        StmtX::Break(label) => {
            if typing.break_labels_in_scope.contains_key(label) {
                Ok(())
            } else {
                Err(format!("break label '{label}' not in scope"))
            }
        }
        StmtX::Switch(stmts) => {
            let snapshots = typing.snapshots.clone(); // snapshots from branches are not retained
            for s in stmts.iter() {
                check_stmt(typing, s)?;
                typing.snapshots = snapshots.clone(); // reset to pre-branch snapshots
            }
            Ok(())
        }
    };
    match result {
        Ok(()) => Ok(()),
        Err(err) => {
            let node_str = node_to_string(
                &Printer::new_with_encoding(
                    typing.message_interface.clone(),
                    false,
                    typing.smt_encoding,
                )
                .stmt_to_node(stmt),
            );
            Err(format!("error '{}' in statement '{}'", err, node_str))
        }
    }
}

pub(crate) fn check_decl(
    context: &mut Context,
    decl: &Decl,
) -> Result<(Vec<Decl>, Decl), TypeError> {
    let typing = &mut context.typing;
    let result = match &**decl {
        DeclX::Sort(_) => Ok(()),
        DeclX::Datatypes(_) => Ok(()), // it's easier to do the checking in add_decl
        DeclX::Const(_, typ) => check_typ(typing, typ),
        DeclX::Fun(_, typs, typ) => {
            let mut typs_vec = typs.to_vec();
            typs_vec.push(typ.clone());
            check_typs(typing, &typs_vec)
        }
        DeclX::Var(_, typ) => check_typ(typing, typ),
        DeclX::Axiom(Axiom { named: _, expr }) => {
            expect_typ(&check_expr(typing, expr)?, &bt(), "axiom expects expression of type bool")
        }
    };
    match result {
        Ok(()) => Ok(crate::closure::simplify_decl(context, decl)),
        Err(err) => {
            let node_str = node_to_string(
                &Printer::new_with_encoding(
                    context.message_interface.clone(),
                    false,
                    context.smt_encoding,
                )
                .decl_to_node(decl),
            );
            Err(format!("error '{}' in declaration '{}'", err, node_str))
        }
    }
}

pub(crate) fn add_decl<'ctx>(
    context: &mut Context,
    decl: &Decl,
    is_global: bool,
) -> Result<(), TypeError> {
    let num_scopes = context.typing.decls.num_scopes();
    match &**decl {
        DeclX::Sort(x) => {
            context.typing.insert(x, Arc::new(DeclaredX::Type))?;
        }
        DeclX::Datatypes(datatypes) => {
            for datatype in datatypes.iter() {
                context.typing.insert(&datatype.name, Arc::new(DeclaredX::Type))?;
            }
            for datatype in datatypes.iter() {
                for variant in datatype.a.iter() {
                    let typ = Arc::new(TypX::Named(datatype.name.clone()));
                    let typs = vec_map(&variant.a, |field| field.a.clone());
                    let fun = DeclaredX::Fun {
                        params: Arc::new(typs),
                        ret: typ.clone(),
                        field_accessor: false,
                    };
                    context.typing.insert(&variant.name, Arc::new(fun))?;
                    let is_variant = Arc::new("is-".to_string() + &variant.name.to_string());
                    let fun = DeclaredX::Fun {
                        params: Arc::new(vec![typ.clone()]),
                        ret: bt(),
                        field_accessor: false,
                    };
                    context.typing.insert(&is_variant, Arc::new(fun))?;
                    for field in variant.a.iter() {
                        check_typ(&context.typing, &field.a)?;
                        let typs: Typs = Arc::new(vec![typ.clone()]);
                        let fun = DeclaredX::Fun {
                            params: typs,
                            ret: field.a.clone(),
                            field_accessor: true,
                        };
                        context.typing.insert(&field.name, Arc::new(fun))?;
                    }
                }
            }
        }
        DeclX::Const(x, typ) => {
            let var = Arc::new(DeclaredX::Var { typ: typ.clone(), mutable: false });
            context.typing.insert(x, var)?;
        }
        DeclX::Fun(x, typs, typ) => {
            let fun =
                DeclaredX::Fun { params: typs.clone(), ret: typ.clone(), field_accessor: false };
            context.typing.insert(x, Arc::new(fun))?;
        }
        DeclX::Var(x, typ) => {
            if is_global {
                return Err(format!("declare-var {} not allowed in global scope", x));
            }
            let var = Arc::new(DeclaredX::Var { typ: typ.clone(), mutable: true });
            context.typing.insert(x, var)?;
        }
        DeclX::Axiom(_) => {}
    }
    assert_eq!(context.typing.decls.num_scopes(), num_scopes);
    Ok(())
}

pub(crate) fn check_query(context: &mut Context, query: &Query) -> Result<Query, TypeError> {
    let num_scopes = context.typing.decls.num_scopes();
    context.push_name_scope();
    let mut locals: Vec<Decl> = Vec::new();
    for decl in query.local.iter() {
        let (mut gen_decls, decl) = check_decl(context, decl)?;
        add_decl(context, &decl, false)?;
        locals.append(&mut gen_decls);
        locals.push(decl);
    }
    context.typing.snapshots = HashSet::new();
    context.typing.break_labels_local = HashSet::new();
    check_stmt(&mut context.typing, &query.assertion)?;

    // Call crate::closure to rewrite query
    assert_eq!(context.apply_map.num_scopes(), context.typing.decls.num_scopes());
    let (mut gen_decls, assertion) = crate::closure::simplify_stmt(context, &query.assertion);
    assert_eq!(context.apply_map.num_scopes(), context.typing.decls.num_scopes());
    locals.append(&mut gen_decls);
    let query = Arc::new(QueryX { local: Arc::new(locals), assertion });

    context.pop_name_scope();
    assert_eq!(context.typing.decls.num_scopes(), num_scopes);
    Ok(query)
}
