use std::process::Command;

use cargo_verus_toolchains::versions::{get_git_head_paths, get_verus_version};

fn main() {
    // Explicit identity for this isolated, non-Git source-snapshot validation.
    // This digest identifies inventoried source bytes, not a Git revision.
    let snapshot = std::env::var("VERUS_SOURCE_SNAPSHOT_SHA256").ok();
    let (default_version, default_sha, head_paths) = if let Some(digest) = &snapshot {
        assert!(digest.len() == 64 && digest.bytes().all(|b| b.is_ascii_hexdigit()),
            "source snapshot SHA256 must be 64 hexadecimal characters");
        ("unversioned-source-snapshot".to_owned(),
            format!("unversioned:snapshot-sha256:{digest}"), Vec::new())
    } else {
        let (version, sha) = get_verus_version(true).expect("version info");
        (version, sha, get_git_head_paths().expect("Git HEAD paths"))
    };
    let profile = std::env::var("VARGO_BUILD_PROFILE")
        .unwrap_or_else(|_| std::env::var("PROFILE").expect("build profile"));
    let (version, sha) = if snapshot.is_some() {
        (default_version, default_sha)
    } else {
        (std::env::var("VARGO_BUILD_VERSION").unwrap_or(default_version),
            std::env::var("VARGO_BUILD_SHA").unwrap_or(default_sha))
    };
    let toolchain = std::env::var("VARGO_TOOLCHAIN").unwrap_or_else(|_| {
        run_command(&["rustup", "show", "active-toolchain"]).expect("active toolchain")
    });

    for path in head_paths {
        println!("cargo::rerun-if-changed={}", path.display());
    }
    println!("cargo::rerun-if-env-changed=VARGO_BUILD_PROFILE");
    println!("cargo::rerun-if-env-changed=VARGO_BUILD_VERSION");
    println!("cargo::rerun-if-env-changed=VARGO_BUILD_SHA");
    println!("cargo::rerun-if-env-changed=VARGO_TOOLCHAIN");
    println!("cargo::rerun-if-env-changed=VERUS_SOURCE_SNAPSHOT_SHA256");

    println!("cargo::rustc-env=VARGO_BUILD_PROFILE={profile}");
    println!("cargo::rustc-env=VARGO_BUILD_VERSION={version}");
    println!("cargo::rustc-env=VARGO_BUILD_SHA={sha}");
    println!("cargo::rustc-env=VARGO_TOOLCHAIN={toolchain}");
}

fn run_command(program_and_args: &[&str]) -> Option<String> {
    let output = Command::new(program_and_args[0]).args(&program_and_args[1..]).output().ok()?;
    output.status.success().then(|| String::from_utf8_lossy(&output.stdout).trim().to_owned())
}
