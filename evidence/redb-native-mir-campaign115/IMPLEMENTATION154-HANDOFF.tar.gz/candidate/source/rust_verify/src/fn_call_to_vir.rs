use crate::attributes::{GhostBlockAttr, get_ghost_block_opt};
use crate::context::{AtomicallyCtxt, BodyCtxt, HeaderSetting};
use crate::erase::{LoopSpecKind, MiscCall, ResolvedCall};
use crate::resolve_traits::{ResolutionResult, ResolvedItem, resolve_trait_item};
use crate::reveal_hide::RevealHideResult;
use crate::rust_to_vir_base::{
    bitwidth_and_signedness_of_integer_type, is_smt_arith, is_type_std_rc_or_arc_or_ref,
    typ_of_expr_adjusted, typ_of_node_unadjusted,
};
use crate::rust_to_vir_expr::{
    check_lit_int, closure_param_typs, closure_to_vir, expr_to_vir, expr_to_vir_consume,
    expr_to_vir_place, extract_array, extract_tuple, get_fn_path, mk_ty_clip, pat_to_var,
};
use crate::util::{err_span, vec_map, vec_map_result, vir_err_span_str};
use crate::verus_items::{
    self, ArithItem, AssertItem, BinaryOpItem, BuiltinDerefItem, BuiltinFunctionItem, ChainedItem,
    CompilableOprItem, DirectiveItem, EqualityItem, ExprItem, QuantItem, RustItem, SpecArithItem,
    SpecGhostTrackedItem, SpecItem, SpecLiteralItem, SpecOrdItem, UnaryOpItem, VerusItem,
};
use crate::{unsupported_err, unsupported_err_unless};
use air::ast_util::str_ident;
use rustc_ast::LitKind;
use rustc_hir::{Block, BlockCheckMode, Expr, ExprKind, QPath, StmtKind};
use rustc_middle::ty::{GenericArg, GenericArgKind, TyKind, TypingEnv};
use rustc_mir_build_verus::verus::BodyErasure;
use rustc_span::Span;
use rustc_span::Spanned;
use rustc_span::def_id::DefId;
use rustc_trait_selection::infer::InferCtxtExt;
use std::sync::Arc;
use vir::ast::{
    ArithOp, ArrayKind, AssertQueryMode, AtomicallyKind, AutospecUsage, BinaryOp, BitshiftBehavior,
    BitwiseOp, BoundsCheck, BuiltinSpecFun, CallTarget, ChainedOp, ComputeMode, Constant, CrateId,
    Div0Behavior, ExprX, FieldOpr, FunX, HeaderExpr, HeaderExprX, InequalityOp, IntRange,
    IntegerTypeBoundKind, LogicalOp, MaskSpec, Mode, ModeCoercion, ModeWrapperMode, MultiOp,
    OverflowBehavior, Place, PlaceX, Quant, Typ, TypDecoration, TypX, UnaryOp, UnaryOpr, VarBinder,
    VarBinderX, VarIdent, VariantCheck, VirErr,
};
use vir::ast_util::{
    const_int_from_string, mk_tuple_typ, mk_tuple_x, typ_to_diagnostic_str, types_equal,
    undecorate_typ, unit_typ, unpack_tuple,
};
use vir::def::field_ident_from_rust;

pub(crate) fn fn_call_to_vir<'tcx>(
    bctx: &BodyCtxt<'tcx>,
    expr: &Expr<'tcx>,
    f: DefId,
    node_substs: &'tcx rustc_middle::ty::List<rustc_middle::ty::GenericArg<'tcx>>,
    _fn_span: Span,
    args: Vec<&'tcx Expr<'tcx>>,
    is_method: bool,
) -> Result<vir::ast::Expr, VirErr> {
    let tcx = bctx.ctxt.tcx;

    let expr_typ = || typ_of_node_unadjusted(bctx, expr.span, &expr.hir_id);

    let rust_item = verus_items::get_rust_item(tcx, f);
    let verus_item = bctx.ctxt.get_verus_item(f);

    if bctx.external_body
        && !matches!(
            verus_item,
            Some(
                VerusItem::Spec(
                    SpecItem::Requires
                        | SpecItem::Recommends
                        | SpecItem::Ensures
                        | SpecItem::Returns
                        | SpecItem::OpensInvariantMask
                        | SpecItem::NoUnwind
                        | SpecItem::NoUnwindWhen
                        | SpecItem::Decreases
                ) | VerusItem::Directive(DirectiveItem::ExtraDependency)
            )
        )
    {
        return Ok(bctx.spanned_typed_new(
            expr.span,
            &expr_typ()?,
            ExprX::Block(Arc::new(vec![]), None),
        ));
    }

    if let Some(result) = native_byte_vec_call(bctx, expr, f, &args)? {
        return Ok(result);
    }
    if let Some(result) = native_option_call(bctx, expr, f, node_substs, &args)? {
        return Ok(result);
    }

    match rust_item {
        Some(RustItem::BoxNew) if bctx.in_ghost => {
            record_misc(bctx, expr, MiscCall::BoxNew);
            return mk_one_vir_arg(bctx, expr.span, &args);
        }
        Some(RustItem::RcNew) if bctx.in_ghost => {
            record_misc(bctx, expr, MiscCall::RcNew);
            return mk_one_vir_arg(bctx, expr.span, &args);
        }
        Some(RustItem::ArcNew) if bctx.in_ghost => {
            record_misc(bctx, expr, MiscCall::ArcNew);
            return mk_one_vir_arg(bctx, expr.span, &args);
        }
        Some(RustItem::CloneClone) => {
            // Special case `clone` for standard Rc and Arc types, shared references, and unit,
            // where cloning is the identity operation in the SMT encoding.
            let arg_typ = node_substs[0].expect_ty();

            if is_type_std_rc_or_arc_or_ref(bctx.ctxt.tcx, arg_typ)
                || matches!(arg_typ.kind(), TyKind::Tuple(ts) if ts.is_empty())
            {
                let arg = mk_one_vir_arg(bctx, expr.span, &args)?;
                record_misc(bctx, expr, MiscCall::IdentityClone { is_method });
                return Ok(arg);
            }
        }
        Some(RustItem::CloneFrom) => {
            return err_span(expr.span, "Verus does not yet support `clone_from`");
        }
        _ => {}
    }

    if let Some(verus_item) = verus_item {
        match verus_item {
            VerusItem::Vstd(_, _)
            | VerusItem::Marker(_)
            | VerusItem::BuiltinType(_)
            | VerusItem::External(_)
            | VerusItem::BuiltinFunction(BuiltinFunctionItem::ConstrainType) => (),
            _ => {
                return verus_item_to_vir(
                    bctx,
                    expr,
                    expr_typ,
                    verus_item,
                    &args,
                    tcx,
                    node_substs,
                    f,
                );
            }
        }
    }

    // Verus attributes are `Unparsed` where get_all_attrs is acceptable per its
    // deprecation message.
    #[allow(deprecated)]
    let f_attrs = bctx.ctxt.tcx.get_all_attrs(f);
    if crate::attributes::is_get_field_many_variants(
        f_attrs,
        Some(&mut *bctx.ctxt.diagnostics.borrow_mut()),
    )? {
        return Err(vir::messages::error(
            &crate::spans::err_air_span(expr.span),
            format!("this field is present in multiple variants, cannot use -> syntax"),
        )
        .help("use `matches` instead"));
    }

    fn_call_or_assoc_const_to_vir(
        bctx,
        expr,
        f,
        node_substs,
        _fn_span,
        Some(args),
        rust_item,
        false,
    )
}

fn fn_call_or_assoc_const_to_vir<'tcx>(
    bctx: &BodyCtxt<'tcx>,
    expr: &Expr<'tcx>,
    f: DefId,
    node_substs: &'tcx rustc_middle::ty::List<rustc_middle::ty::GenericArg<'tcx>>,
    _fn_span: Span,
    args: Option<Vec<&'tcx Expr<'tcx>>>,
    rust_item: Option<RustItem>,
    const_var: bool,
) -> Result<vir::ast::Expr, VirErr> {
    // Normal function call
    let tcx = bctx.ctxt.tcx;
    let expr_typ = || typ_of_node_unadjusted(bctx, expr.span, &expr.hir_id);

    let path = bctx.ctxt.def_id_to_vir_path(f);
    let name = Arc::new(FunX { path: path.clone() });
    let autospec_usage = if bctx.in_ghost { AutospecUsage::IfMarked } else { AutospecUsage::Final };

    // Compute the 'target_kind'.
    //
    // If the target is a "trait function" then we try to resolve it to a statically known
    // implementation of that function. The target_kind stores this information,
    // known or unknown.
    //
    // If the resolution is statically known, we record the resolved function for the
    // to be used by lifetime_generate.

    let node_substs = if let Some(args) = &args {
        fix_node_substs(tcx, bctx.types, node_substs, rust_item, args, expr)
    } else {
        node_substs
    };

    let mut record_name = name.clone();
    let target_kind = if tcx.trait_of_assoc(f).is_none() {
        vir::ast::CallTargetKind::Static
    } else {
        let typing_env = TypingEnv::non_body_analysis(tcx, bctx.fun_id);
        let res = resolve_trait_item(expr.span, tcx, typing_env, f, node_substs)?;
        match res {
            ResolutionResult::Resolved {
                impl_def_id: _,
                impl_args: _,
                impl_item_args: _,
                resolved_item: ResolvedItem::FromImpl(did, res_args),
            } => {
                let verus_item = bctx.ctxt.get_verus_item(did);
                if matches!(verus_item, Some(VerusItem::BuiltinDeref(_))) {
                    return verus_item_to_vir(
                        bctx,
                        expr,
                        expr_typ,
                        verus_item.unwrap(),
                        args.as_ref().unwrap(),
                        tcx,
                        res_args,
                        did,
                    );
                }

                let typs = mk_typ_args(bctx, res_args, did, expr.span)?;
                let impl_paths = get_impl_paths(bctx, did, res_args, None, const_var, expr.span)?;

                let f = Arc::new(FunX { path: bctx.ctxt.def_id_to_vir_path(did) });
                record_name = f.clone();

                vir::ast::CallTargetKind::DynamicResolved {
                    resolved: f,
                    typs,
                    impl_paths,
                    is_trait_default: false,
                }
            }
            ResolutionResult::Resolved {
                impl_def_id: _,
                impl_args: _,
                impl_item_args: _,
                resolved_item: ResolvedItem::FromTrait(did, args),
            } => {
                // We resolved to the trait method itself, which means this must be
                // a default method implementation in the trait.
                // Redirect this to the appropriate per-instance copy of the default method.

                let typs = mk_typ_args(bctx, args, did, expr.span)?;

                let mut self_trait_impl_path = None;
                let trait_id = tcx.trait_of_assoc(did).unwrap();
                let remove_self_trait_bound = Some((trait_id, &mut self_trait_impl_path));
                let impl_paths =
                    get_impl_paths(bctx, did, args, remove_self_trait_bound, const_var, expr.span)?;

                let Some(vir::ast::ImplPath::TraitImplPath(impl_path)) = self_trait_impl_path
                else {
                    panic!("{} {:?}", "could not resolve call to trait provided method", expr.span);
                };

                let f = Arc::new(FunX { path: bctx.ctxt.def_id_to_vir_path(did) });
                record_name = f.clone();

                let f = vir::def::trait_inherit_default_name(&f, &impl_path);

                vir::ast::CallTargetKind::DynamicResolved {
                    resolved: f,
                    typs,
                    impl_paths,
                    is_trait_default: true,
                }
            }
            ResolutionResult::Builtin(
                rustc_trait_selection::traits::BuiltinImplSource::Object(_),
            ) => {
                // dyn T dispatch
                vir::ast::CallTargetKind::Dynamic
            }
            ResolutionResult::Builtin(b) => {
                if let Some((helper, helper_args)) = crate::tuple_clone::helper(tcx, f, node_substs)
                {
                    let fun = Arc::new(FunX { path: bctx.ctxt.def_id_to_vir_path(helper) });
                    let typs = mk_typ_args(bctx, helper_args, helper, expr.span)?;
                    let impl_paths =
                        get_impl_paths(bctx, helper, helper_args, None, const_var, expr.span)?;
                    record_name = fun.clone();
                    vir::ast::CallTargetKind::DynamicResolved {
                        resolved: fun,
                        typs,
                        impl_paths,
                        is_trait_default: false,
                    }
                } else {
                    unsupported_err!(expr.span, format!("built-in instance {:?}", b));
                }
            }
            ResolutionResult::Unresolved => {
                // Method is generic
                vir::ast::CallTargetKind::Dynamic
            }
        }
    };

    let assume_external_allowed =
        crate::attributes::get_externals_available_without_declaration_walk_parents(
            bctx.ctxt.tcx,
            bctx.fun_id,
        );

    let resolved_call = ResolvedCall::Call(name.clone(), record_name, assume_external_allowed);
    record_call(bctx, expr, resolved_call);

    // REVIEW: The atomic function call is encoded using the following construction:
    //
    // #[verifier::atomic_call]
    // function(x1, x2, x3, ::vstd::atomic::atomically(|update| {
    //     ...
    //     ay = update(ax);
    //     ...
    // }))
    //
    // If we translate this construction naively into VIR, we end up evaluating
    // the `atomically` in its entirety before the actual call to `function`,
    // meaning the atomic pre- and postcondition are generated *before* the
    // private pre- and postcondition.
    //
    // To fix this, we use the "body" of the call to place the `atomically` block
    // in-between the private pre- and postcondition:
    //
    // vir_call(
    //     target: function,
    //     args: [x1, x2, x3, atomic_update_init_dummy],
    //     body: atomically({
    //         ...
    //         ay = update(ax);
    //         ...
    //     }),
    // )

    let is_atomic_function_call = || -> Result<bool, VirErr> {
        let hir_attrs = bctx.ctxt.tcx.hir_attrs(expr.hir_id);
        let vir_attrs = crate::attributes::parse_attrs(hir_attrs, None)?;
        Ok(vir_attrs.contains(&crate::attributes::Attr::AtomicCall))
    };

    let (vir_args, call_body) = match args.as_deref() {
        Some(arg_slice) if is_atomic_function_call()? => {
            let [prefix @ .., au] = arg_slice else {
                panic!("atomic call must have at least one argument");
            };

            let mut vir_args = mk_vir_args(bctx, prefix)?;
            let au_expr = expr_to_vir_consume(&bctx, au)?;
            vir_args.push(bctx.spanned_typed_new(
                au.span,
                &au_expr.typ,
                ExprX::AtomicUpdateInitDummy,
            ));

            (vir_args, Some(au_expr))
        }
        Some(arg_slice) => (mk_vir_args(bctx, arg_slice)?, None),
        None => Default::default(),
    };

    let typ_args = mk_typ_args(bctx, node_substs, f, expr.span)?;
    let impl_paths = get_impl_paths(bctx, f, node_substs, None, const_var, expr.span)?;
    let call_target_attrs =
        vir::ast::CallTargetAttrs { autospec: autospec_usage, assume_external_allowed, const_var };
    let target = CallTarget::Fun(target_kind, name, typ_args, impl_paths, call_target_attrs);
    if vir_args.is_empty()
        && call_body.is_none()
        && node_substs.len() == 1
        && crate::native_const::size_function(&bctx.ctxt, f)
    {
        let ty = node_substs[0].expect_ty();
        if let Some(size) = crate::native_const::fixed_size(&bctx.ctxt, bctx.fun_id, ty) {
            return Ok(bctx.spanned_typed_new(
                expr.span,
                &expr_typ()?,
                ExprX::Const(Constant::Int(size.into())),
            ));
        }
    }
    Ok(bctx.spanned_typed_new(
        expr.span,
        &expr_typ()?,
        ExprX::Call { target, args: Arc::new(vir_args), post_args: None, body: call_body },
    ))
}

pub(crate) fn const_var_to_vir<'tcx>(
    bctx: &BodyCtxt<'tcx>,
    expr: Option<&Expr<'tcx>>,
    id: DefId,
    node_substs: &'tcx rustc_middle::ty::List<rustc_middle::ty::GenericArg<'tcx>>,
    hir_id: &rustc_hir::HirId,
    span: Span,
) -> Result<vir::ast::Expr, VirErr> {
    // A trait associated const, or an inherent-impl associated const that has type
    // parameters (e.g. `impl<T> S<T> { const C: ... = ...; }`), is encoded as a
    // function taking those type parameters, so it must be lowered to ExprX::Call
    // (which supplies the type arguments) rather than ExprX::ConstVar.
    let is_generic_assoc_const =
        bctx.ctxt.tcx.trait_of_assoc(id).is_some() || bctx.ctxt.tcx.generics_of(id).count() > 0;
    if is_generic_assoc_const {
        // associated const --> ExprX::Call rather than ExprX::ConstVar
        let Some(expr) = expr else {
            unsupported_err!(span, "associated constant in pattern");
        };
        return fn_call_or_assoc_const_to_vir(bctx, expr, id, node_substs, span, None, None, true);
    }
    let typ = typ_of_node_unadjusted(bctx, span, hir_id)?;
    if let Some(value) = crate::native_const::scalar(&bctx.ctxt, id) {
        return Ok(bctx.spanned_typed_new(span, &typ, ExprX::Const(value)));
    }
    let path = bctx.ctxt.def_id_to_vir_path(id);
    let fun = FunX { path };
    let autospec_usage = if bctx.in_ghost { AutospecUsage::IfMarked } else { AutospecUsage::Final };
    Ok(bctx.spanned_typed_new(span, &typ, ExprX::ConstVar(Arc::new(fun), autospec_usage)))
}

/// Emit a call to deref or deref_mut
pub(crate) fn call_deref<'tcx>(
    bctx: &BodyCtxt<'tcx>,
    span: Span,
    expr_typ: Typ,
    trait_fun_id: DefId,
    arg: vir::ast::Expr,
    arg_ty: rustc_middle::ty::Ty<'tcx>,
) -> Result<vir::ast::Expr, VirErr> {
    // deref has arg &Self
    // deref_mut has arg &mut Self
    // In either case, strip off the reference to get the Self type for the trait
    let TyKind::Ref(_, self_ty, _) = arg_ty.kind() else {
        crate::internal_err!(span, "deref_to_vir: expected ref")
    };
    let trait_args = bctx.ctxt.tcx.mk_args(&[GenericArg::from(*self_ty)]);
    let args = Arc::new(vec![arg]);
    call_overloaded_method(bctx, span, expr_typ, trait_fun_id, args, trait_args)
}

/// Emit a call to index or index_mut
pub(crate) fn call_index<'tcx>(
    bctx: &BodyCtxt<'tcx>,
    span: Span,
    expr_typ: Typ,
    trait_fun_id: DefId,
    arg: vir::ast::Expr,
    arg_ty: rustc_middle::ty::Ty<'tcx>,
    idx: vir::ast::Expr,
    idx_ty: rustc_middle::ty::Ty<'tcx>,
) -> Result<vir::ast::Expr, VirErr> {
    // index has arg &Self
    // index_mut has arg &mut Self
    // In either case, strip off the reference to get the Self type for the trait
    let TyKind::Ref(_, self_ty, _) = arg_ty.kind() else {
        crate::internal_err!(span, "deref_to_vir: expected ref")
    };
    let trait_args = bctx.ctxt.tcx.mk_args(&[GenericArg::from(*self_ty), GenericArg::from(idx_ty)]);
    let args = Arc::new(vec![arg, idx]);
    call_overloaded_method(bctx, span, expr_typ, trait_fun_id, args, trait_args)
}

/// Common logic for all the overloaded methods
pub(crate) fn call_overloaded_method<'tcx>(
    bctx: &BodyCtxt<'tcx>,
    span: Span,
    expr_typ: Typ,
    trait_fun_id: DefId,
    args: vir::ast::Exprs,
    trait_args: &'tcx rustc_middle::ty::GenericArgs<'tcx>,
) -> Result<vir::ast::Expr, VirErr> {
    let tcx = bctx.ctxt.tcx;
    let typing_env = TypingEnv::non_body_analysis(tcx, bctx.fun_id);

    let trait_fun = Arc::new(FunX { path: bctx.ctxt.def_id_to_vir_path(trait_fun_id) });

    let res = resolve_trait_item(span, tcx, typing_env, trait_fun_id, trait_args)?;
    let target_kind = match res {
        ResolutionResult::Resolved { resolved_item: ResolvedItem::FromImpl(did, args), .. } => {
            let typs = mk_typ_args(bctx, args, did, span)?;
            let impl_paths = get_impl_paths(bctx, did, args, None, false, span)?;
            let resolved = Arc::new(FunX { path: bctx.ctxt.def_id_to_vir_path(did) });

            vir::ast::CallTargetKind::DynamicResolved {
                resolved,
                typs,
                impl_paths,
                is_trait_default: false,
            }
        }
        ResolutionResult::Resolved {
            impl_def_id: _,
            impl_args: _,
            impl_item_args: _,
            resolved_item: ResolvedItem::FromTrait(did, args),
        } => {
            let typs = mk_typ_args(bctx, args, did, span)?;

            let mut self_trait_impl_path = None;
            let trait_id = tcx.trait_of_assoc(did).unwrap();
            let remove_self_trait_bound = Some((trait_id, &mut self_trait_impl_path));
            let impl_paths = get_impl_paths(bctx, did, args, remove_self_trait_bound, false, span)?;

            let Some(vir::ast::ImplPath::TraitImplPath(impl_path)) = self_trait_impl_path else {
                panic!("{} {:?}", "could not resolve call to trait provided method", span);
            };

            let f = Arc::new(FunX { path: bctx.ctxt.def_id_to_vir_path(did) });
            let f = vir::def::trait_inherit_default_name(&f, &impl_path);

            vir::ast::CallTargetKind::DynamicResolved {
                resolved: f,
                typs,
                impl_paths,
                is_trait_default: true,
            }
        }
        ResolutionResult::Unresolved => vir::ast::CallTargetKind::Dynamic,
        _ => crate::internal_err!(span, "unexpected ResolutionResult"),
    };

    let autospec_usage = if bctx.in_ghost { AutospecUsage::IfMarked } else { AutospecUsage::Final };

    let typ_args = mk_typ_args(bctx, trait_args, trait_fun_id, span)?;
    let impl_paths = get_impl_paths(bctx, trait_fun_id, trait_args, None, false, span)?;
    let call_target_attrs = vir::ast::CallTargetAttrs {
        autospec: autospec_usage,
        assume_external_allowed: false,
        const_var: false,
    };
    let call_target =
        CallTarget::Fun(target_kind, trait_fun, typ_args, impl_paths, call_target_attrs);
    let x = ExprX::Call { target: call_target, args, post_args: None, body: None };

    Ok(bctx.spanned_typed_new(span, &expr_typ, x))
}

fn verus_item_to_vir<'tcx, 'a>(
    bctx: &'a BodyCtxt<'tcx>,
    expr: &'a Expr<'tcx>,
    expr_typ: impl Fn() -> Result<Arc<TypX>, VirErr>,
    verus_item: &VerusItem,
    args: &'a Vec<&'tcx Expr<'tcx>>,
    tcx: rustc_middle::ty::TyCtxt<'tcx>,
    node_substs: &'tcx rustc_middle::ty::List<rustc_middle::ty::GenericArg<'tcx>>,
    f: DefId,
) -> Result<vir::ast::Expr, VirErr> {
    // DO NOT use f_name to find items (i.e. do not use f_name == "core::cmp::Eq"),
    // use `crate::verus_item::get_rust_item` instead
    let f_name = tcx.def_path_str(f);
    let args_len = args.len();

    if !bctx.in_ghost && uncompilable_verus_fn(verus_item) {
        return err_span(
            expr.span,
            format!(
                "cannot use `{f_name}`{:} in executable context",
                match verus_item {
                    VerusItem::Expr(ExprItem::IsSmallerThanLexicographic) =>
                        " (of the `decreases_to!` macro)",
                    _ => "",
                }
            ),
        );
    }

    let mk_expr = |x: ExprX| Ok(bctx.spanned_typed_new(expr.span, &expr_typ()?, x));
    let mk_expr_span = |span: Span, x: ExprX| Ok(bctx.spanned_typed_new(span, &expr_typ()?, x));
    match verus_item {
        VerusItem::OpenInvariantBlock(_) => err_span(
            expr.span,
            format!(
                "{} should never be used except through open_atomic_invariant or open_local_invariant macro",
                f_name
            ),
        ),
        VerusItem::OpenAtomicUpdate(_) => err_span(
            expr.span,
            format!("{f_name} should never be used except through open_atomic_update macro"),
        ),
        VerusItem::UnaryOp(UnaryOpItem::SpecLiteral(SpecLiteralItem::Decimal)) => {
            record_spec_fn(bctx, expr);
            unsupported_err_unless!(args_len == 1, expr.span, "expected spec_literal_*", &args);
            let arg = &args[0];
            let s = get_string_lit_arg(&args[0], &f_name)?;
            match &*expr_typ()? {
                TypX::Float(32) => {
                    let f: f32 = match s.to_string().parse() {
                        Ok(f) => f,
                        Err(err) => {
                            return err_span(arg.span, format!("float out of range {}", err));
                        }
                    };
                    mk_expr(ExprX::Const(Constant::Float32(f32::to_bits(f))))
                }
                TypX::Float(64) => {
                    let f: f64 = match s.to_string().parse() {
                        Ok(f) => f,
                        Err(err) => {
                            return err_span(arg.span, format!("float out of range {}", err));
                        }
                    };
                    mk_expr(ExprX::Const(Constant::Float64(f64::to_bits(f))))
                }
                TypX::Real => {
                    let is_valid_real = s.chars().all(|c| c.is_ascii_digit() || c == '.')
                        && s.chars().filter(|c| *c == '.').count() == 1
                        && !s.starts_with(".")
                        && !s.ends_with(".");
                    if !is_valid_real {
                        return err_span(
                            arg.span,
                            "real literal must be digits, followed by a decimal point, followed by digits",
                        );
                    }
                    mk_expr(ExprX::Const(Constant::Real(s.to_string())))
                }
                _ => {
                    return err_span(
                        expr.span,
                        format!(
                            "unexpected type for floating point or real literal: {}",
                            typ_to_diagnostic_str(&expr_typ()?),
                        ),
                    );
                }
            }
        }
        VerusItem::UnaryOp(UnaryOpItem::SpecLiteral(spec_literal_item)) => {
            record_spec_fn(bctx, expr);

            unsupported_err_unless!(args_len == 1, expr.span, "expected spec_literal_*", &args);
            let arg = &args[0];
            let s = get_string_lit_arg(&args[0], &f_name)?;
            let is_num = s.chars().count() > 0 && s.chars().all(|c| c.is_digit(10));
            if is_num {
                // TODO: negative literals for is_spec_literal_int and is_spec_literal_integer
                if spec_literal_item == &SpecLiteralItem::Integer {
                    // TODO: big integers for int, nat
                    let i: u128 = match s.to_string().parse() {
                        Ok(i) => i,
                        Err(err) => {
                            return err_span(arg.span, format!("integer out of range {}", err));
                        }
                    };
                    let in_negative_literal = false;
                    check_lit_int(&bctx.ctxt, expr.span, in_negative_literal, i, &expr_typ()?)?
                }
                mk_expr(ExprX::Const(const_int_from_string(s.to_string())))
            } else {
                err_span(arg.span, "spec_literal_* requires a string literal")
            }
        }
        VerusItem::Spec(spec_item) => {
            // Update the in_fn_sig and in_postcondition fields of bctx if necessary
            let bctx = if bctx.header_setting == HeaderSetting::Fn {
                let (sig, postcondition) = match spec_item {
                    SpecItem::Admit
                    | SpecItem::Assume
                    | SpecItem::NoMethodBody
                    | SpecItem::Recommends
                    | SpecItem::DecreasesWhen
                    | SpecItem::DecreasesBy
                    | SpecItem::RecommendsBy
                    | SpecItem::InvariantExceptBreak
                    | SpecItem::Invariant => (false, false),

                    SpecItem::Requires
                    | SpecItem::Decreases
                    | SpecItem::OpensInvariantMask
                    | SpecItem::InvMaskNone
                    | SpecItem::InvMaskAny
                    | SpecItem::InvMaskList
                    | SpecItem::InvMaskListCompl
                    | SpecItem::InvMaskSet
                    | SpecItem::NoUnwind
                    | SpecItem::NoUnwindWhen => (true, false),

                    SpecItem::Ensures | SpecItem::Returns => (true, true),

                    SpecItem::AtomicSpec | SpecItem::AtomicCallLoop | SpecItem::Atomically => {
                        (false, false)
                    }
                };
                if sig {
                    &BodyCtxt { in_fn_sig: sig, in_postcondition: postcondition, ..bctx.clone() }
                } else {
                    bctx
                }
            } else {
                bctx
            };

            match spec_item {
                SpecItem::NoMethodBody => {
                    record_spec_fn_pure_args_only(bctx, expr);
                    mk_expr(ExprX::Header(Arc::new(HeaderExprX::NoMethodBody)))
                }
                SpecItem::Requires | SpecItem::Recommends | SpecItem::Returns => {
                    record_spec_fn_pure_args_only(bctx, expr);
                    unsupported_err_unless!(
                        args_len == 1,
                        expr.span,
                        "expected requires/recommends",
                        &args
                    );
                    let bctx = &BodyCtxt { external_body: false, in_ghost: true, ..bctx.clone() };
                    let subargs = extract_array(args[0]);

                    let vir_args = vec_map_result(&subargs, |arg| expr_to_vir_consume(&bctx, arg))?;

                    if matches!(spec_item, SpecItem::Returns) && subargs.len() != 1 {
                        return err_span(
                            expr.span,
                            "`returns` clause should have exactly 1 expression",
                        );
                    }

                    for (arg, vir_arg) in subargs.iter().zip(vir_args.iter()) {
                        let typ = vir::ast_util::undecorate_typ(&vir_arg.typ);
                        match spec_item {
                            SpecItem::Requires | SpecItem::Recommends => match &*typ {
                                TypX::Bool => {}
                                _ => {
                                    return err_span(
                                        arg.span,
                                        "requires/recommends needs a bool expression",
                                    );
                                }
                            },
                            SpecItem::Returns => {
                                // type is checked in well_formed.rs
                            }
                            _ => unreachable!(),
                        }
                    }

                    let header = match spec_item {
                        SpecItem::Requires => Arc::new(HeaderExprX::Requires(Arc::new(vir_args))),
                        SpecItem::Recommends => {
                            Arc::new(HeaderExprX::Recommends(Arc::new(vir_args)))
                        }
                        SpecItem::Returns => Arc::new(HeaderExprX::Returns(vir_args[0].clone())),
                        _ => unreachable!(),
                    };
                    mk_expr(ExprX::Header(header))
                }
                SpecItem::OpensInvariantMask => {
                    record_spec_fn_pure_args_only(bctx, expr);
                    let bctx = &BodyCtxt { external_body: false, in_ghost: true, ..bctx.clone() };
                    let inner = expr_to_vir_consume(&bctx, args[0])?;
                    let ExprX::InvMask(mask_spec) = &inner.x else {
                        return err_span(
                            expr.span,
                            "malformed opens_invariants item; \
                            expected invariant mask expression",
                        );
                    };

                    let header = HeaderExprX::OpensInvariantMask(mask_spec.clone());
                    mk_expr(ExprX::Header(Arc::new(header)))
                }
                SpecItem::InvMaskNone => {
                    record_spec_fn_pure_args_only(bctx, expr);
                    mk_expr(ExprX::InvMask(MaskSpec::InvariantOpens(
                        bctx.ctxt.spans.to_air_span(expr.span.clone()),
                        Default::default(),
                    )))
                }
                SpecItem::InvMaskAny => {
                    record_spec_fn_pure_args_only(bctx, expr);
                    mk_expr(ExprX::InvMask(MaskSpec::InvariantOpensExcept(
                        bctx.ctxt.spans.to_air_span(expr.span.clone()),
                        Default::default(),
                    )))
                }
                SpecItem::InvMaskList | SpecItem::InvMaskListCompl => {
                    record_spec_fn_pure_args_only(bctx, expr);
                    let bctx = &BodyCtxt { external_body: false, in_ghost: true, ..bctx.clone() };
                    let subargs = extract_array(args[0]);
                    let mut vir_args = Vec::with_capacity(subargs.len());
                    for arg in subargs {
                        let vir_arg = expr_to_vir_consume(&bctx, arg)?;
                        let typ = undecorate_typ(&vir_arg.typ);
                        let TypX::Int(..) = &*typ else {
                            return err_span(arg.span, "invariant mask must be type int");
                        };

                        vir_args.push(vir_arg);
                    }

                    let span = bctx.ctxt.spans.to_air_span(expr.span.clone());
                    let args = Arc::new(vir_args);
                    mk_expr(ExprX::InvMask(match spec_item {
                        SpecItem::InvMaskList => MaskSpec::InvariantOpens(span, args),
                        SpecItem::InvMaskListCompl => MaskSpec::InvariantOpensExcept(span, args),
                        _ => unreachable!(),
                    }))
                }
                SpecItem::InvMaskSet => {
                    fn typ_is_int_iset(typ: &Typ) -> bool {
                        let TypX::Datatype(vir::ast::Dt::Path(path), args, _) = typ.as_ref() else {
                            return false;
                        };

                        let [int_typ] = args.as_slice() else {
                            return false;
                        };

                        let TypX::Int(..) = int_typ.as_ref() else {
                            return false;
                        };

                        path == &vir::def::iset_type_path()
                    }

                    record_spec_fn_pure_args_only(bctx, expr);
                    let bctx = &BodyCtxt { external_body: false, in_ghost: true, ..bctx.clone() };
                    let set_expr = expr_to_vir_consume(&bctx, args[0])?;
                    if !typ_is_int_iset(&set_expr.typ) {
                        return err_span(
                            args[0].span.clone(),
                            "invariant mask must be a set of ints",
                        );
                    }

                    mk_expr(ExprX::InvMask(MaskSpec::InvariantOpensSet(set_expr)))
                }
                SpecItem::Ensures => {
                    if let HeaderSetting::Loop(loop_hir_id) = bctx.header_setting {
                        record_loop_spec(bctx, expr, loop_hir_id, LoopSpecKind::Ensures);
                    } else {
                        record_spec_fn_pure_args_only(bctx, expr);
                    }
                    unsupported_err_unless!(args_len == 1, expr.span, "expected ensures", &args);
                    let bctx = &BodyCtxt { external_body: false, in_ghost: true, ..bctx.clone() };
                    let header = extract_ensures(&bctx, args[0])?;
                    // extract_ensures does most of the necessary work, so we can return at this point
                    mk_expr_span(args[0].span, ExprX::Header(header))
                }
                SpecItem::AtomicSpec => {
                    record_spec_fn_pure_args_only(bctx, expr);
                    unsupported_err_unless!(
                        args_len == 1,
                        expr.span,
                        "expected atomic spec",
                        &args
                    );
                    let bctx = &BodyCtxt { external_body: false, in_ghost: true, ..bctx.clone() };
                    let expr = expr_to_vir_consume(&bctx, args[0])?;
                    mk_expr_span(
                        args[0].span,
                        ExprX::Header(Arc::new(HeaderExprX::AtomicSpec(expr))),
                    )
                }
                SpecItem::AtomicCallLoop => {
                    record_spec_fn_pure_args_only(bctx, expr);
                    let header = Arc::new(HeaderExprX::AtomicCallLoop);
                    mk_expr(ExprX::Header(header))
                }
                SpecItem::Decreases => {
                    if let HeaderSetting::Loop(loop_hir_id) = bctx.header_setting {
                        record_loop_spec(bctx, expr, loop_hir_id, LoopSpecKind::Decreases);
                    } else {
                        record_spec_fn_pure_args_only(bctx, expr);
                    }

                    unsupported_err_unless!(args_len == 1, expr.span, "expected decreases", &args);
                    let subargs = extract_tuple(args[0]);
                    let bctx = &BodyCtxt { external_body: false, in_ghost: true, ..bctx.clone() };
                    let vir_args = vec_map_result(&subargs, |arg| expr_to_vir_consume(&bctx, arg))?;
                    let header = Arc::new(HeaderExprX::Decreases(Arc::new(vir_args)));
                    mk_expr(ExprX::Header(header))
                }
                SpecItem::InvariantExceptBreak | SpecItem::Invariant => {
                    if let HeaderSetting::Loop(loop_hir_id) = bctx.header_setting {
                        let kind = match spec_item {
                            SpecItem::InvariantExceptBreak => LoopSpecKind::InvariantExceptBreak,
                            SpecItem::Invariant => LoopSpecKind::Invariant,
                            _ => unreachable!(),
                        };
                        record_loop_spec(bctx, expr, loop_hir_id, kind);
                    } else {
                        return err_span(expr.span, "invariant is only expected inside a loop");
                    }

                    unsupported_err_unless!(args_len == 1, expr.span, "expected invariant", &args);
                    let subargs = extract_array(args[0]);
                    for arg in &subargs {
                        if !matches!(bctx.types.expr_ty_adjusted(arg).kind(), TyKind::Bool) {
                            return err_span(arg.span, "invariant needs a bool expression");
                        }
                    }
                    let bctx = &BodyCtxt { external_body: false, in_ghost: true, ..bctx.clone() };
                    let vir_args = vec_map_result(&subargs, |arg| {
                        let mut vir_expr = expr_to_vir_consume(&bctx, arg)?;
                        // Wrap expressions with #[verus::internal(auto_decreases)] attribute
                        let arg_attrs = bctx.ctxt.tcx.hir_attrs(arg.hir_id);
                        if crate::attributes::has_auto_decreases_attr(arg_attrs) {
                            vir_expr = vir_expr.new_x(vir::ast::ExprX::UnaryOpr(
                                vir::ast::UnaryOpr::AutoDecreases,
                                vir_expr.clone(),
                            ));
                        }
                        Ok::<vir::ast::Expr, VirErr>(vir_expr)
                    })?;
                    let header = match spec_item {
                        SpecItem::InvariantExceptBreak => {
                            Arc::new(HeaderExprX::InvariantExceptBreak(Arc::new(vir_args)))
                        }
                        SpecItem::Invariant => Arc::new(HeaderExprX::Invariant(Arc::new(vir_args))),
                        _ => unreachable!(),
                    };
                    mk_expr(ExprX::Header(header))
                }
                SpecItem::DecreasesBy | SpecItem::RecommendsBy => {
                    record_spec_fn_pure_args_only(bctx, expr);
                    unsupported_err_unless!(args_len == 1, expr.span, "expected function", &args);
                    let x = get_fn_path(bctx, &args[0])?;
                    let header = Arc::new(HeaderExprX::DecreasesBy(x));
                    mk_expr(ExprX::Header(header))
                }
                SpecItem::DecreasesWhen => {
                    record_spec_fn_pure_args_only(bctx, expr);
                    let arg = mk_one_vir_arg(bctx, expr.span, &args)?;
                    let header = Arc::new(HeaderExprX::DecreasesWhen(arg));
                    mk_expr(ExprX::Header(header))
                }
                SpecItem::NoUnwind => {
                    record_spec_fn_pure_args_only(bctx, expr);
                    let header = Arc::new(HeaderExprX::NoUnwind);
                    mk_expr(ExprX::Header(header))
                }
                SpecItem::NoUnwindWhen => {
                    record_spec_fn_pure_args_only(bctx, expr);
                    let bctx = &BodyCtxt { external_body: false, in_ghost: true, ..bctx.clone() };
                    let arg = mk_one_vir_arg(bctx, expr.span, &args)?;
                    let header = Arc::new(HeaderExprX::NoUnwindWhen(arg));
                    mk_expr(ExprX::Header(header))
                }
                SpecItem::Admit => {
                    record_spec_fn_pure_args_only(bctx, expr);
                    unsupported_err_unless!(args_len == 0, expr.span, "expected admit", args);
                    let f = bctx.spanned_typed_new(
                        expr.span,
                        &Arc::new(TypX::Bool),
                        ExprX::Const(Constant::Bool(false)),
                    );
                    mk_expr(ExprX::AssertAssume { is_assume: true, expr: f, msg: None })
                }
                SpecItem::Assume => {
                    record_spec_fn_pure_args_only(bctx, expr);
                    let arg = mk_one_vir_arg(bctx, expr.span, &args)?;
                    mk_expr(ExprX::AssertAssume { is_assume: true, expr: arg, msg: None })
                }
                SpecItem::Atomically => {
                    // The atomic function call expands as follows:
                    //
                    // function(x1, x2, x3) atomically |update| {
                    //     ...
                    // }
                    //
                    // #[verifier::atomic_call]
                    // function(x1, x2, x3, ::vstd::atomic::atomically({
                    //     let _verus_internal_identifier_for_closures = ::vstd::prelude::dummy_capture_new();
                    //     |update, atomic_update| {
                    //         ::vstd::prelude::dummy_capture_consume(_verus_internal_identifier_for_closures);
                    //
                    //         #[verifier::internal(spec)]
                    //         let _ = atomic_update;
                    //
                    //         loop? {
                    //             { ... }
                    //         }
                    //     }
                    // }))
                    //
                    // Most of the structure is enforced by the type checker, we need to identify the
                    // let binding and use it to construct the correct function predicate type

                    fn malformed_err<'tcx, X>(expr: &Expr<'tcx>) -> Result<X, VirErr> {
                        let msg = "malformed atomic call; please do not use `vstd::atomic::atomically` directly";
                        err_span(expr.span, msg)
                    }

                    assert!(bctx.atomically.is_none());

                    let [
                        Expr {
                            kind: ExprKind::Block(Block { expr: Some(inner), .. }, None), ..
                        },
                    ] = args.as_slice()
                    else {
                        return malformed_err(expr);
                    };

                    let Expr { kind: ExprKind::Closure(closure), .. } = inner else {
                        return malformed_err(expr);
                    };

                    let body = tcx.hir_body(closure.body);
                    let [update_param, ghost_au_param] = body.params else {
                        panic!("the closure should take exactly two argument")
                    };

                    let ExprKind::Block(Block { expr: Some(inner), .. }, _) = body.value.kind
                    else {
                        return malformed_err(expr);
                    };

                    let kind = match &inner.kind {
                        ExprKind::Loop(..) => AtomicallyKind::Loop,
                        _ => AtomicallyKind::Simple,
                    };

                    let ghost_au_var = pat_to_var(ghost_au_param.pat)?;
                    let (tx, rx) = std::sync::mpsc::channel();
                    let actx = Arc::new(AtomicallyCtxt {
                        update_binder: update_param.pat.hir_id,
                        call_spans: tx,
                    });

                    let atomically = Some(actx.clone());
                    let bctx_inner = BodyCtxt { atomically, in_ghost: true, ..bctx.clone() };

                    let value = expr_to_vir_consume(&bctx_inner, body.value)?;

                    let update_span = update_param.span.clone();
                    let call_spans = rx.try_iter().collect::<Vec<_>>();
                    match call_spans.len() {
                        0 => err_span(update_span, "function must be called in `atomically` block"),
                        1 => mk_expr(ExprX::Atomically(kind, ghost_au_var, value)),
                        _ => Err(Arc::new(vir::messages::MessageX {
                            level: air::messages::MessageLevel::Error,
                            note: "function must be called exactly once in `atomically` block"
                                .into(),
                            spans: call_spans,
                            labels: Vec::new(),
                            help: Vec::new(),
                            fancy_note: None,
                        })),
                    }
                }
            }
        }
        VerusItem::Quant(quant_item) => {
            record_spec_fn_pure_args_only(bctx, expr);
            unsupported_err_unless!(args_len == 1, expr.span, "expected forall/exists", &args);
            let quant = match quant_item {
                QuantItem::Forall => air::ast::Quant::Forall,
                QuantItem::Exists => air::ast::Quant::Exists,
            };
            let quant = Quant { quant };
            extract_quant(bctx, expr.span, quant, args[0])
        }
        VerusItem::Directive(directive_item) => match directive_item {
            DirectiveItem::ExtraDependency => {
                record_spec_fn_pure_args_only(bctx, expr);
                unsupported_err_unless!(
                    args_len == 1,
                    expr.span,
                    "expected hide / extra dependency",
                    &args
                );
                let x = get_fn_path(bctx, &args[0])?;
                let header = Arc::new(HeaderExprX::ExtraDependency(x));
                mk_expr(ExprX::Header(header))
            }
            DirectiveItem::RevealHide => {
                // {
                //     ::verus_builtin::reveal_({
                //             #[verus::internal(reveal_fn)]
                //             fn __VERUS_REVEAL_INTERNAL__() {
                //                 ::verus_builtin::reveal_internal_path_(function::path)
                //             }
                //             ;
                //             __VERUS_REVEAL_INTERNAL__
                //         }, 1);
                // }

                record_spec_fn_pure_args_only(bctx, expr);
                let RevealHideResult::Expr(expr) = crate::reveal_hide::handle_reveal_hide(
                    &bctx.ctxt,
                    expr,
                    args_len,
                    args,
                    tcx,
                    Some(mk_expr),
                )?
                else {
                    panic!("handle_reveal_hide must return an Expr");
                };
                Ok(expr)
            }
            DirectiveItem::RevealHideInternalPath => {
                err_span(expr.span, "reveal_internal_path is only for internal verus use")
            }
            DirectiveItem::RevealStrlit => {
                record_spec_fn_pure_args_only(bctx, expr);
                if let Some(s) = if let ExprKind::Lit(lit0) = &args[0].kind {
                    if let rustc_ast::LitKind::Str(s, _) = lit0.node { Some(s) } else { None }
                } else {
                    None
                } {
                    mk_expr(ExprX::RevealString(Arc::new(s.to_string())))
                } else {
                    err_span(args[0].span, "string literal expected".to_string())
                }
            }
            DirectiveItem::RevealByteslit => {
                record_spec_fn_pure_args_only(bctx, expr);
                unsupported_err_unless!(
                    args_len == 1,
                    expr.span,
                    "reveal_byteslit expects one argument"
                );
                let bytes = if let ExprKind::Lit(lit) = &args[0].kind {
                    match lit.node {
                        rustc_ast::LitKind::ByteStr(bytes, _) => Some(bytes.as_byte_str().to_vec()),
                        _ => None,
                    }
                } else {
                    None
                };
                match bytes {
                    Some(bytes) => mk_expr(ExprX::RevealByteString(Arc::new(bytes))),
                    None => err_span(args[0].span, "byte-string literal expected"),
                }
            }
            DirectiveItem::InlineAirStmt => {
                if bctx.ctxt.cmd_line_args.allow_inline_air {
                    record_spec_fn_pure_args_only(bctx, expr);
                    unsupported_err_unless!(
                        args_len == 1,
                        expr.span,
                        "expected air statement",
                        &args
                    );
                    let s = get_string_lit_arg(&args[0], &f_name)?;
                    mk_expr(ExprX::AirStmt(Arc::new(s)))
                } else {
                    err_span(
                        expr.span,
                        "inline AIR is only allowed with the relevant command line flag"
                            .to_string(),
                    )
                }
            }
        },
        VerusItem::Expr(expr_item) => match expr_item {
            ExprItem::Choose => {
                record_spec_fn_pure_args_only(bctx, expr);
                unsupported_err_unless!(args_len == 1, expr.span, "expected choose", &args);
                extract_choose(bctx, expr.span, args[0], false, expr_typ()?)
            }
            ExprItem::ChooseTuple => {
                record_spec_fn_pure_args_only(bctx, expr);
                unsupported_err_unless!(args_len == 1, expr.span, "expected choose", &args);
                extract_choose(bctx, expr.span, args[0], true, expr_typ()?)
            }
            ExprItem::Old => {
                record_spec_fn_pure_args_only(bctx, expr);
                // TODO(new_mut_ref): (blocking) restrict to form like `old(x)` or `old(x.field)`?
                // TODO(new_mut_ref): (fix when done) old type signature should accept any type
                let bctx = &BodyCtxt { in_old: true, ..bctx.clone() };
                let arg = expr_to_vir_consume(bctx, &args[0])?;
                mk_expr(ExprX::Old(arg))
            }
            ExprItem::ArrayIndex => {
                record_spec_fn(bctx, expr);
                match &expr.kind {
                    ExprKind::Call(_, args) if args.len() == 2 => {
                        let arg0 = args.first().unwrap();
                        let arg0 = expr_to_vir_consume(bctx, arg0).expect(
                            "invalid parameter for verus_builtin::array_index at arg0, arg0 must be self",
                        );
                        let arg1 = &args[1];
                        let arg1 = expr_to_vir_consume(bctx, arg1)
                            .expect("invalid parameter for verus_builtin::array_index at arg1; arg1 must be an integer");
                        mk_expr(ExprX::Binary(
                            BinaryOp::Index(ArrayKind::Array, BoundsCheck::Allow),
                            arg0,
                            arg1,
                        ))
                    }
                    _ => panic!(
                        "Expected a call for verus_builtin::array_index with two argument but did not receive it"
                    ),
                }
            }
            ExprItem::F32ToBits => {
                record_spec_fn(bctx, expr);
                match &expr.kind {
                    ExprKind::Call(_, args) => {
                        assert!(args.len() == 1);
                        let arg0 = args.first().unwrap();
                        let arg0 =
                            expr_to_vir_consume(bctx, arg0).expect("internal compiler error");
                        mk_expr(ExprX::Unary(UnaryOp::FloatToBits, arg0))
                    }
                    _ => panic!(
                        "Expected a call for verus_builtin::f32_to_bits with one argument but did not receive it"
                    ),
                }
            }
            ExprItem::F64ToBits => {
                record_spec_fn(bctx, expr);
                match &expr.kind {
                    ExprKind::Call(_, args) => {
                        assert!(args.len() == 1);
                        let arg0 = args.first().unwrap();
                        let arg0 =
                            expr_to_vir_consume(bctx, arg0).expect("internal compiler error");
                        mk_expr(ExprX::Unary(UnaryOp::FloatToBits, arg0))
                    }
                    _ => panic!(
                        "Expected a call for verus_builtin::f64_to_bits with one argument but did not receive it"
                    ),
                }
            }
            ExprItem::NewStrLit => {
                record_spec_fn(bctx, expr);
                match &expr.kind {
                    ExprKind::Call(_, args) => {
                        assert!(args.len() == 1);
                        let arg0 = args.first().unwrap();
                        let arg0 =
                            expr_to_vir_consume(bctx, arg0).expect("internal compiler error");
                        mk_expr(ExprX::Unary(UnaryOp::NewStrLit, arg0))
                    }
                    _ => panic!(
                        "Expected a call for verus_builtin::strslice_new_strlit with one argument but did not receive it"
                    ),
                }
            }
            ExprItem::StrSliceLen => {
                record_spec_fn(bctx, expr);
                match &expr.kind {
                    ExprKind::Call(_, args) => {
                        assert!(args.len() == 1);
                        let arg0 = args.first().unwrap();
                        let arg0 =
                            expr_to_vir_consume(bctx, arg0).expect("internal compiler error");
                        mk_expr(ExprX::Unary(UnaryOp::StrLen, arg0))
                    }
                    _ => panic!(
                        "Expected a call for verus_builtin::strslice_len with one argument but did not receive it"
                    ),
                }
            }
            ExprItem::StrSliceGetChar => {
                record_spec_fn(bctx, expr);
                match &expr.kind {
                    ExprKind::Call(_, args) if args.len() == 2 => {
                        let arg0 = args.first().unwrap();
                        let arg0 = expr_to_vir_consume(bctx, arg0).expect(
                            "invalid parameter for verus_builtin::strslice_get_char at arg0, arg0 must be self",
                        );
                        let arg1 = &args[1];
                        let arg1 = expr_to_vir_consume(bctx, arg1)
                            .expect("invalid parameter for verus_builtin::strslice_get_char at arg1, arg1 must be an integer");
                        mk_expr(ExprX::Binary(BinaryOp::StrGetChar, arg0, arg1))
                    }
                    _ => panic!(
                        "Expected a call for verus_builtin::strslice_get_char with two argument but did not receive it"
                    ),
                }
            }
            ExprItem::ArchWordBits => {
                record_spec_fn(bctx, expr);
                assert!(args.len() == 0);
                let arg = bctx.spanned_typed_new(
                    expr.span,
                    &Arc::new(TypX::Int(IntRange::Int)),
                    ExprX::Const(vir::ast_util::const_int_from_u128(0)),
                );

                let kind = IntegerTypeBoundKind::ArchWordBits;

                mk_expr(ExprX::UnaryOpr(UnaryOpr::IntegerTypeBound(kind), arg))
            }
            ExprItem::ClosureToFnSpec | ExprItem::ClosureToFnProof => {
                unsupported_err_unless!(args_len == 1, expr.span, "expected closure_to_fn", &args);
                if !bctx.in_ghost {
                    if matches!(expr_item, ExprItem::ClosureToFnSpec) {
                        return err_span(args[0].span, "cannot use spec_fn closure in 'exec' mode");
                    } else {
                        return err_span(
                            args[0].span,
                            "cannot use proof_fn closure in 'exec' mode",
                        );
                    }
                }
                if let ExprKind::Closure(..) = &args[0].kind {
                    let is_spec_fn = matches!(expr_item, ExprItem::ClosureToFnSpec);

                    let proof_fn_modes = if matches!(expr_item, ExprItem::ClosureToFnProof) {
                        let ty = bctx.types.node_type(expr.hir_id);
                        if let Some((arg_modes, ret_mode)) =
                            crate::rust_to_vir_base::try_get_proof_fn_modes(
                                &bctx.ctxt, expr.span, &ty,
                            )?
                        {
                            let op = MiscCall::ClosureToFnProof(ret_mode);
                            record_call(bctx, expr, ResolvedCall::MiscCall(op));
                            Some((Arc::new(arg_modes), ret_mode))
                        } else {
                            panic!("unexpected closure_to_proof_fn type")
                        }
                    } else {
                        record_spec_fn_pure_args_only(bctx, expr);
                        None
                    };
                    closure_to_vir(bctx, &args[0], expr_typ()?, is_spec_fn, proof_fn_modes)
                } else {
                    err_span(args[0].span, "the argument to `closure_to_fn` must be a closure")
                }
            }
            ExprItem::SignedMin | ExprItem::SignedMax | ExprItem::UnsignedMax => {
                record_spec_fn(bctx, expr);
                assert!(args.len() == 1);
                let arg = expr_to_vir_consume(bctx, &args[0])?;
                let kind = match expr_item {
                    ExprItem::SignedMin => IntegerTypeBoundKind::SignedMin,
                    ExprItem::SignedMax => IntegerTypeBoundKind::SignedMax,
                    ExprItem::UnsignedMax => IntegerTypeBoundKind::UnsignedMax,
                    _ => unreachable!(),
                };
                mk_expr(ExprX::UnaryOpr(UnaryOpr::IntegerTypeBound(kind), arg))
            }
            ExprItem::IsSmallerThan
            | ExprItem::IsSmallerThanLexicographic
            | ExprItem::IsSmallerThanRecursiveFunctionField => {
                record_spec_fn(bctx, expr);
                assert!(args.len() == 2);
                let (args0, args1) = if expr_item == &ExprItem::IsSmallerThanLexicographic {
                    match (&args[0].kind, &args[1].kind) {
                        (ExprKind::Tup(_), ExprKind::Tup(_)) => {
                            (extract_tuple(args[0]), extract_tuple(args[1]))
                        }
                        _ => unsupported_err!(
                            expr.span,
                            "is_smaller_than_lexicographic requires tuple arguments"
                        ),
                    }
                } else {
                    (vec![args[0]], vec![args[1]])
                };
                mk_is_smaller_than(
                    bctx,
                    expr.span,
                    args0,
                    args1,
                    expr_item == &ExprItem::IsSmallerThanRecursiveFunctionField,
                )
            }
            ExprItem::DefaultEnsures => {
                return err_span(expr.span, "default_ensures not allowed here");
            }
            ExprItem::IsVariant => {
                record_spec_fn(bctx, expr);
                assert!(args.len() == 2);
                let adt_arg = expr_to_vir_consume(bctx, &args[0])?;
                let variant_name = get_string_lit_arg(&args[1], &f_name)?;

                let (adt_path, _) =
                    check_variant_field(bctx, expr.span, args[0], &variant_name, None)?;

                mk_expr(ExprX::UnaryOpr(
                    UnaryOpr::IsVariant { datatype: adt_path, variant: str_ident(&variant_name) },
                    adt_arg,
                ))
            }
            ExprItem::GetVariantField => {
                record_spec_fn(bctx, expr);
                assert!(args.len() == 3);
                let adt_arg = expr_to_vir_consume(bctx, &args[0])?;
                let variant_name = get_string_lit_arg(&args[1], &f_name)?;
                let field_name = get_string_lit_arg(&args[2], &f_name)?;

                let (adt_path, variant_field) = check_variant_field(
                    bctx,
                    expr.span,
                    args[0],
                    &variant_name,
                    Some((field_name, &bctx.types.expr_ty(expr))),
                )?;

                mk_expr(ExprX::UnaryOpr(
                    UnaryOpr::Field(FieldOpr {
                        datatype: adt_path,
                        variant: str_ident(&variant_name),
                        field: variant_field.unwrap(),
                        get_variant: true,
                        check: VariantCheck::Recommends,
                    }),
                    adt_arg,
                ))
            }
            ExprItem::GetUnionField => {
                record_spec_fn(bctx, expr);
                assert!(args.len() == 2);
                let adt_arg = expr_to_vir_consume(bctx, &args[0])?;
                let field_name = get_string_lit_arg(&args[1], &f_name)?;

                let adt_path = check_union_field(
                    bctx,
                    expr.span,
                    args[0],
                    &field_name,
                    &bctx.types.expr_ty(expr),
                )?;

                let field_ident = str_ident(&field_name);
                mk_expr(ExprX::UnaryOpr(
                    UnaryOpr::Field(FieldOpr {
                        datatype: adt_path,
                        variant: field_ident.clone(),
                        field: field_ident_from_rust(&field_ident),
                        get_variant: true,
                        check: VariantCheck::None,
                    }),
                    adt_arg,
                ))
            }
            ExprItem::ShrRefStructWrap => {
                record_misc(bctx, expr, MiscCall::ShrRefStructWrap);
                assert!(args.len() == 4);
                let arg0 = expr_to_vir_consume(bctx, &args[0])?;
                let arg1 = expr_to_vir_consume(bctx, &args[1])?;
                let variant_name = get_string_lit_arg(&args[2], &f_name)?;
                let field_name = get_string_lit_arg(&args[3], &f_name)?;
                let typ_args = mk_typ_args(bctx, node_substs, f, expr.span)?;
                assert!(typ_args.len() == 2);
                mk_expr(ExprX::ShrRefStructWrap(
                    arg0,
                    arg1,
                    typ_args[0].clone(),
                    typ_args[1].clone(),
                    str_ident(&variant_name),
                    str_ident(&field_name),
                ))
            }
        },
        VerusItem::CompilableOpr(
            compilable_opr @ (CompilableOprItem::GhostExec | CompilableOprItem::TrackedExec),
        ) => {
            record_misc(
                bctx,
                expr,
                match compilable_opr {
                    CompilableOprItem::GhostExec => MiscCall::GhostExec,
                    CompilableOprItem::TrackedExec => MiscCall::TrackedExec,
                    _ => unreachable!(),
                },
            );

            unsupported_err_unless!(args_len == 1, expr.span, "expected Ghost/Tracked", &args);
            let arg = &args[0];
            if get_ghost_block_opt(bctx.ctxt.tcx.hir_attrs(expr.hir_id))
                == Some(GhostBlockAttr::Wrapper)
            {
                let bctx = &BodyCtxt { in_ghost: true, ..bctx.clone() };
                let vir_args = mk_vir_args(bctx, &args)?;
                let vir_arg = strip_two_phase(&vir_args[0]);
                match (compilable_opr, get_ghost_block_opt(bctx.ctxt.tcx.hir_attrs(arg.hir_id))) {
                    (CompilableOprItem::GhostExec, Some(GhostBlockAttr::GhostWrapped)) => {
                        let exprx = ExprX::Ghost {
                            alloc_wrapper: true,
                            tracked: false,
                            expr: vir_arg.clone(),
                        };
                        Ok(bctx.spanned_typed_new(arg.span, &vir_arg.typ.clone(), exprx))
                    }
                    (CompilableOprItem::TrackedExec, Some(GhostBlockAttr::TrackedWrapped)) => {
                        let exprx = ExprX::Ghost {
                            alloc_wrapper: true,
                            tracked: true,
                            expr: vir_arg.clone(),
                        };
                        Ok(bctx.spanned_typed_new(arg.span, &vir_arg.typ.clone(), exprx))
                    }
                    (_, attr) => {
                        err_span(expr.span, format!("unexpected ghost block attribute {:?}", attr))
                    }
                }
            } else {
                let vir_args = mk_vir_args(bctx, &args)?;
                let vir_arg = strip_two_phase(&vir_args[0]);
                if matches!(verus_item, VerusItem::CompilableOpr(CompilableOprItem::GhostExec)) {
                    let op = UnaryOp::CoerceMode {
                        op_mode: Mode::Exec,
                        from_mode: Mode::Spec,
                        to_mode: Mode::Exec,
                        kind: ModeCoercion::Constructor,
                    };
                    mk_expr(ExprX::Unary(op, vir_arg))
                } else {
                    // TrackedExec
                    let op = UnaryOp::CoerceMode {
                        op_mode: Mode::Exec,
                        from_mode: Mode::Proof,
                        to_mode: Mode::Exec,
                        kind: ModeCoercion::Constructor,
                    };
                    mk_expr(ExprX::Unary(op, vir_arg))
                }
            }
        }
        VerusItem::Assert(assert_item) => {
            record_spec_fn_pure_args_only(bctx, expr);
            match assert_item {
                AssertItem::Assert => {
                    unsupported_err_unless!(args_len == 1, expr.span, "expected assert", &args);
                    let exp = expr_to_vir_consume(bctx, &args[0])?;
                    mk_expr(ExprX::AssertAssume { is_assume: false, expr: exp, msg: None })
                }
                AssertItem::AssertBy => {
                    unsupported_err_unless!(args_len == 2, expr.span, "expected assert_by", &args);
                    let vars = Arc::new(vec![]);
                    let require = bctx.spanned_typed_new(
                        expr.span,
                        &Arc::new(TypX::Bool),
                        ExprX::Const(Constant::Bool(true)),
                    );
                    let ensure = expr_to_vir_consume(bctx, &args[0])?;
                    let proof = expr_to_vir_consume(bctx, &args[1])?;
                    mk_expr(ExprX::AssertBy { vars, require, ensure, proof })
                }
                AssertItem::AssertByCompute => {
                    unsupported_err_unless!(
                        args_len == 1,
                        expr.span,
                        "expected assert_by_compute",
                        &args
                    );
                    let exp = expr_to_vir_consume(bctx, &args[0])?;
                    mk_expr(ExprX::AssertCompute(exp, ComputeMode::Z3))
                }
                AssertItem::AssertByComputeOnly => {
                    unsupported_err_unless!(
                        args_len == 1,
                        expr.span,
                        "expected assert_by_compute_only",
                        &args
                    );
                    let exp = expr_to_vir_consume(bctx, &args[0])?;
                    mk_expr(ExprX::AssertCompute(exp, ComputeMode::ComputeOnly))
                }
                AssertItem::AssertNonlinearBy | AssertItem::AssertBitvectorBy => {
                    unsupported_err_unless!(
                        args_len == 1,
                        expr.span,
                        "expected assert_nonlinear_by/assert_bitvector_by with one argument",
                        &args
                    );
                    let bctx = bctx.set_header_setting(HeaderSetting::Assert);
                    let mut vir_expr = expr_to_vir_consume(&bctx, &args[0])?;
                    use vir::headers::{HeaderAllow, HeaderAllows};
                    let header = vir::headers::read_header(
                        &mut vir_expr,
                        &HeaderAllows::Some(vec![HeaderAllow::Require, HeaderAllow::Ensure]),
                    )?;
                    let requires = if header.require.len() >= 1 {
                        header.require
                    } else {
                        Arc::new(vec![bctx.spanned_typed_new(
                            expr.span,
                            &Arc::new(TypX::Bool),
                            ExprX::Const(Constant::Bool(true)),
                        )])
                    };
                    if header.ensure.0.len() == 0 {
                        return err_span(
                            expr.span,
                            "assert_nonlinear_by/assert_bitvector_by must have at least one ensures",
                        );
                    }
                    assert!(header.ensure.1.len() == 0);
                    let ensures = header.ensure.0;
                    let proof = vir_expr;

                    let expr_attrs = bctx.ctxt.tcx.hir_attrs(expr.hir_id);
                    let expr_vattrs = bctx.ctxt.get_verifier_attrs(expr_attrs)?;
                    if expr_vattrs.spinoff_prover {
                        return err_span(
                            expr.span,
                            "#[verifier::spinoff_prover] is implied for assert by nonlinear_arith and assert by bit_vector",
                        );
                    }
                    mk_expr(ExprX::AssertQuery {
                        requires,
                        ensures,
                        proof,
                        mode: match assert_item {
                            AssertItem::AssertNonlinearBy => AssertQueryMode::NonLinear,
                            AssertItem::AssertBitvectorBy => AssertQueryMode::BitVector,
                            _ => unreachable!(),
                        },
                    })
                }
                AssertItem::AssertForallBy => {
                    unsupported_err_unless!(
                        args_len == 1,
                        expr.span,
                        "expected assert_forall_by",
                        &args
                    );
                    extract_assert_forall_by(bctx, expr.span, args[0])
                }
                // internally translate this into `assert_bitvector_by`. REVIEW: consider deprecating this at all
                AssertItem::AssertBitVector => {
                    let vir_expr = expr_to_vir_consume(bctx, &args[0])?;
                    let requires = Arc::new(vec![bctx.spanned_typed_new(
                        expr.span,
                        &Arc::new(TypX::Bool),
                        ExprX::Const(Constant::Bool(true)),
                    )]);
                    let ensures = Arc::new(vec![vir_expr]);
                    let proof = bctx.spanned_typed_new(
                        expr.span,
                        &unit_typ(),
                        ExprX::Block(Arc::new(vec![]), None),
                    );
                    mk_expr(ExprX::AssertQuery {
                        requires,
                        ensures,
                        proof,
                        mode: AssertQueryMode::BitVector,
                    })
                }
            }
        }
        VerusItem::UseTypeInvariant => {
            record_misc(bctx, expr, MiscCall::UseTypeInvariant);
            unsupported_err_unless!(args_len == 1, expr.span, "expected use_type_invariant", &args);
            if !bctx.in_ghost {
                return err_span(expr.span, "use_type_invariant must be in a 'proof' block");
            }
            let exp = expr_to_vir_consume(bctx, &args[0])?;

            // We need to check there's no 'Ghost' decoration.
            let arg_typ = bctx.types.expr_ty_adjusted(&args[0]);
            let t = bctx.mid_ty_to_vir(expr.span, &arg_typ)?;
            vir::user_defined_type_invariants::check_typ_ok_for_use_typ_invariant(&exp.span, &t)?;

            // The correct fun is filled in later, in the pass that elaborates these conditions
            mk_expr(ExprX::AssertAssumeUserDefinedTypeInvariant {
                is_assume: true,
                expr: exp,
                fun: vir::fun!(CrateId::Internal => "use_type_invariant_fake_placeholder_fun"),
            })
        }
        VerusItem::WithTriggers => {
            record_spec_fn(bctx, expr);
            unsupported_err_unless!(args_len == 2, expr.span, "expected with_triggers", &args);
            let triggers_tuples = expr_to_vir_consume(bctx, args[0])?;
            let body = expr_to_vir_consume(bctx, args[1])?;
            let mut trigs: Vec<vir::ast::Exprs> = Vec::new();
            match unpack_tuple(&triggers_tuples) {
                Some(triggers) => {
                    for trigger_tuple in triggers.iter() {
                        match unpack_tuple(trigger_tuple) {
                            Some(terms) => {
                                trigs.push(Arc::new(terms));
                            }
                            _ => {
                                return err_span(
                                    expr.span,
                                    "expected tuple arguments to with_triggers",
                                );
                            }
                        }
                    }
                }
                _ => {
                    return err_span(expr.span, "expected tuple arguments to with_triggers");
                }
            }
            let triggers = Arc::new(trigs);
            mk_expr(ExprX::WithTriggers { triggers, body })
        }
        VerusItem::UnaryOp(UnaryOpItem::SpecCastReal) => {
            record_spec_fn(bctx, expr);
            unsupported_err_unless!(args.len() == 1, expr.span, "expected 1 argument", &args);
            let source_vir0 = expr_to_vir(bctx, &args[0])?;
            let source_vir = source_vir0.consume(bctx, bctx.types.expr_ty_adjusted(&args[0]));
            let source_ty = undecorate_typ(&source_vir.typ);
            match &*source_ty {
                TypX::Int(_) => mk_expr(ExprX::Unary(UnaryOp::IntToReal, source_vir)),
                TypX::Float(_) => mk_expr(ExprX::Unary(
                    UnaryOp::IeeeFloat(vir::ast::IeeeFloatUnaryOp::Cast),
                    source_vir,
                )),
                _ => err_span(expr.span, "Only integer and float types can be cast to real"),
            }
        }
        VerusItem::UnaryOp(UnaryOpItem::RealFloor) => {
            record_spec_fn(bctx, expr);
            unsupported_err_unless!(args.len() == 1, expr.span, "expected 1 argument", &args);
            let source_vir0 = expr_to_vir(bctx, &args[0])?;
            let source_vir = source_vir0.consume(bctx, bctx.types.expr_ty_adjusted(&args[0]));
            let source_ty = undecorate_typ(&source_vir.typ);
            assert!(matches!(&*source_ty, TypX::Real));
            mk_expr(ExprX::Unary(UnaryOp::RealToInt, source_vir))
        }
        VerusItem::UnaryOp(UnaryOpItem::SpecCastFloat) => {
            record_spec_fn(bctx, expr);
            unsupported_err_unless!(args.len() == 1, expr.span, "expected 1 argument", &args);
            let source_vir0 = expr_to_vir(bctx, &args[0])?;
            let source_vir = source_vir0.consume(bctx, bctx.types.expr_ty_adjusted(&args[0]));
            let source_ty = undecorate_typ(&source_vir.typ);
            match &*source_ty {
                TypX::Int(IntRange::I(_) | IntRange::U(_) | IntRange::USize | IntRange::ISize)
                | TypX::Real
                | TypX::Float(_) => {
                    let op = UnaryOp::IeeeFloat(vir::ast::IeeeFloatUnaryOp::Cast);
                    mk_expr(ExprX::Unary(op, source_vir))
                }
                _ => err_span(
                    expr.span,
                    "Only i8...u128, isize, usize, real, and float types can be cast to float",
                ),
            }
        }
        VerusItem::UnaryOp(UnaryOpItem::SpecCastInteger) => {
            record_spec_fn(bctx, expr);
            let to_ty = undecorate_typ(&expr_typ()?);

            unsupported_err_unless!(args.len() == 1, expr.span, "expected 1 argument", &args);
            let source_vir0 = expr_to_vir(bctx, &args[0])?;
            let source_vir0_ty = bctx.types.expr_ty_adjusted(&args[0]);
            let source_vir = source_vir0.consume(bctx, source_vir0_ty);
            let source_ty = undecorate_typ(&source_vir.typ);

            if let Some(expr) =
                crate::rust_to_vir_expr::maybe_do_ptr_cast(bctx, expr, &args[0], &source_vir)?
            {
                return Ok(expr);
            }

            let source_is_integer = {
                let integer_trait_def_id = bctx.ctxt.verus_items.name_to_id
                    [&VerusItem::BuiltinTrait(verus_items::BuiltinTraitItem::Integer)];
                let ty = bctx.types.node_type(args[0].hir_id);
                let infcx = rustc_infer::infer::TyCtxtInferExt::infer_ctxt(tcx)
                    .build(rustc_type_ir::TypingMode::PostAnalysis);
                matches!(&*source_vir.typ, TypX::TypParam(_))
                    && infcx
                        .type_implements_trait(
                            integer_trait_def_id,
                            vec![ty],
                            tcx.param_env(bctx.fun_id),
                        )
                        .must_apply_modulo_regions()
            };
            match ((&*source_ty, source_is_integer), &*to_ty) {
                ((TypX::Int(IntRange::U(_)), _), TypX::Int(IntRange::Nat)) => Ok(source_vir),
                ((TypX::Int(IntRange::USize), _), TypX::Int(IntRange::Nat)) => Ok(source_vir),
                ((TypX::Int(IntRange::Nat), _), TypX::Int(IntRange::Nat)) => Ok(source_vir),
                ((TypX::Int(IntRange::Int), _), TypX::Int(IntRange::Nat)) => {
                    Ok(mk_ty_clip(bctx, &to_ty, &source_vir, true))
                }
                ((TypX::Int(_), _), TypX::Int(_)) => {
                    let expr_attrs = bctx.ctxt.tcx.hir_attrs(expr.hir_id);
                    let expr_vattrs = bctx.ctxt.get_verifier_attrs(expr_attrs)?;
                    Ok(mk_ty_clip(bctx, &to_ty, &source_vir, expr_vattrs.truncate))
                }
                ((TypX::Bool, _), TypX::Int(_)) => {
                    let zero = mk_expr(ExprX::Const(vir::ast_util::const_int_from_u128(0)))?;
                    let one = mk_expr(ExprX::Const(vir::ast_util::const_int_from_u128(1)))?;
                    mk_expr(ExprX::If(source_vir, one, Some(zero)))
                }
                ((_, true), TypX::Int(IntRange::Int)) => {
                    mk_expr(ExprX::Unary(UnaryOp::CastToInteger, source_vir))
                }
                ((_, true), TypX::Int(IntRange::Nat)) => {
                    let cast_to_integer =
                        mk_expr(ExprX::Unary(UnaryOp::CastToInteger, source_vir))?;
                    let expr_attrs = bctx.ctxt.tcx.hir_attrs(expr.hir_id);
                    let expr_vattrs = bctx.ctxt.get_verifier_attrs(expr_attrs)?;
                    Ok(mk_ty_clip(bctx, &to_ty, &cast_to_integer, expr_vattrs.truncate))
                }
                ((_, false), TypX::Int(_)) if bctx.types.node_type(args[0].hir_id).is_enum() => {
                    let cast_to = crate::rust_to_vir_expr::expr_cast_enum_int_to_vir(
                        bctx,
                        args[0],
                        source_vir0.to_place(bctx, expr.span, source_vir0_ty)?,
                        mk_expr,
                    )?;
                    let expr_attrs = bctx.ctxt.tcx.hir_attrs(expr.hir_id);
                    let expr_vattrs = bctx.ctxt.get_verifier_attrs(expr_attrs)?;
                    Ok(mk_ty_clip(bctx, &to_ty, &cast_to, expr_vattrs.truncate))
                }
                (
                    (TypX::Float(_), _),
                    TypX::Int(IntRange::U(_) | IntRange::I(_) | IntRange::USize | IntRange::ISize),
                ) => {
                    let op = UnaryOp::IeeeFloat(vir::ast::IeeeFloatUnaryOp::Cast);
                    mk_expr(ExprX::Unary(op, source_vir))
                }
                ((TypX::Float(_), _), TypX::Int(_)) => err_span(
                    expr.span,
                    "for floats, only casts to i8..u128, isize, and usize are supported",
                ),
                ((TypX::Real, _), TypX::Int(_)) => err_span(
                    expr.span,
                    "cannot cast real to int directly; use .floor() instead (e.g., x.floor() or x.floor() as u64)",
                ),
                _ => err_span(
                    expr.span,
                    "Verus currently only supports casts from integer types, floats, bool, enum (unit-only or field-less), `char`, and pointer types to integer types",
                ),
            }
        }
        VerusItem::UnaryOp(UnaryOpItem::SpecNeg) => {
            record_spec_fn(bctx, expr);

            let arg_typ =
                undecorate_typ(&typ_of_expr_adjusted(bctx, args[0].span, &args[0].hir_id)?);

            let varg = mk_one_vir_arg(bctx, expr.span, &args)?;

            match &*arg_typ {
                TypX::Int(_) => {
                    let zero_const = vir::ast_util::const_int_from_u128(0);
                    let zero = mk_expr(ExprX::Const(zero_const))?;
                    mk_expr(ExprX::Binary(
                        BinaryOp::Arith(ArithOp::Sub(OverflowBehavior::Allow)),
                        zero,
                        varg,
                    ))
                }
                TypX::Real => {
                    let zero = mk_expr(ExprX::Const(Constant::Real("0.0".to_string())))?;
                    mk_expr(ExprX::Binary(
                        BinaryOp::RealArith(vir::ast::RealArithOp::Sub),
                        zero,
                        varg,
                    ))
                }
                TypX::Float(_) => {
                    mk_expr(ExprX::Unary(UnaryOp::IeeeFloat(vir::ast::IeeeFloatUnaryOp::Neg), varg))
                }
                _ => {
                    return err_span(expr.span, "spec_neg expected int or real or float type");
                }
            }
        }
        VerusItem::Chained(chained_item) => {
            record_spec_fn(bctx, expr);
            let vir_args = mk_vir_args(bctx, &args)?;
            match chained_item {
                ChainedItem::Value => {
                    unsupported_err_unless!(args_len == 1, expr.span, "spec_chained_value", &args);
                    unsupported_err_unless!(
                        matches!(
                            *undecorate_typ(&vir_args[0].typ),
                            TypX::Int(_) | TypX::Real | TypX::Float(_),
                        ),
                        expr.span,
                        "chained inequalities require integer or real or float types",
                        &args
                    );
                    let exprx = ExprX::Multi(
                        MultiOp::Chained(Arc::new(vec![])),
                        Arc::new(vec![vir_args[0].clone()]),
                    );
                    Ok(bctx.spanned_typed_new(expr.span, &Arc::new(TypX::Bool), exprx))
                }
                ChainedItem::Cmp => {
                    unsupported_err_unless!(args_len == 1, expr.span, "spec_chained_cmp", args);
                    Ok(vir_args[0].clone())
                }
                ChainedItem::Le
                | ChainedItem::Lt
                | ChainedItem::Ge
                | ChainedItem::Gt
                | ChainedItem::Eq => {
                    unsupported_err_unless!(args_len == 2, expr.span, "chained inequality", &args);
                    unsupported_err_unless!(
                        matches!(&vir_args[0].x, ExprX::Multi(MultiOp::Chained(_), _)),
                        expr.span,
                        "chained inequalities for non-integer types",
                        &args
                    );
                    unsupported_err_unless!(
                        matches!(
                            *undecorate_typ(&vir_args[1].typ),
                            TypX::Int(_) | TypX::Real | TypX::Float(_),
                        ),
                        expr.span,
                        "chained inequalities require integer or real or float types",
                        &args
                    );
                    if let ExprX::Multi(MultiOp::Chained(_), es) = &vir_args[0].x {
                        if es.len() > 0 {
                            let first_typ = undecorate_typ(&es[0].typ);
                            let new_typ = undecorate_typ(&vir_args[1].typ);
                            let types_match = match (&*first_typ, &*new_typ) {
                                (TypX::Int(_), TypX::Int(_)) => true,
                                (TypX::Real, TypX::Real) => true,
                                (TypX::Float(f1), TypX::Float(f2)) => f1 == f2,
                                _ => false,
                            };
                            unsupported_err_unless!(
                                types_match,
                                expr.span,
                                "chained inequalities require all elements to have the same type (all integers or all reals or all floats)"
                            );
                        }
                    }
                    let op = match chained_item {
                        ChainedItem::Le => ChainedOp::Inequality(InequalityOp::Le),
                        ChainedItem::Lt => ChainedOp::Inequality(InequalityOp::Lt),
                        ChainedItem::Ge => ChainedOp::Inequality(InequalityOp::Ge),
                        ChainedItem::Gt => ChainedOp::Inequality(InequalityOp::Gt),
                        ChainedItem::Eq => ChainedOp::MultiEq,
                        ChainedItem::Value | ChainedItem::Cmp => unreachable!(),
                    };
                    if let ExprX::Multi(MultiOp::Chained(ops), es) = &vir_args[0].x {
                        let mut ops = (**ops).clone();
                        let mut es = (**es).clone();
                        ops.push(op);
                        es.push(vir_args[1].clone());
                        let exprx = ExprX::Multi(MultiOp::Chained(Arc::new(ops)), Arc::new(es));
                        Ok(bctx.spanned_typed_new(expr.span, &Arc::new(TypX::Bool), exprx))
                    } else {
                        panic!("is_chained_ineq")
                    }
                }
            }
        }
        VerusItem::CompilableOpr(CompilableOprItem::GhostNew)
        | VerusItem::UnaryOp(UnaryOpItem::SpecGhostTracked(
            SpecGhostTrackedItem::GhostView
            | SpecGhostTrackedItem::GhostBorrow
            | SpecGhostTrackedItem::TrackedView,
        )) => {
            if matches!(verus_item, VerusItem::CompilableOpr(CompilableOprItem::GhostNew)) {
                record_misc(bctx, expr, MiscCall::GhostExec);
            } else {
                record_spec_fn(bctx, expr);
            }

            let vir_args = mk_vir_args(bctx, &args)?;
            assert!(vir_args.len() == 1);
            let is_ghost_new = verus_item == &VerusItem::CompilableOpr(CompilableOprItem::GhostNew);
            let op = UnaryOp::CoerceMode {
                op_mode: Mode::Spec,
                from_mode: Mode::Spec,
                to_mode: if is_ghost_new { Mode::Proof } else { Mode::Spec },
                kind: if is_ghost_new { ModeCoercion::Constructor } else { ModeCoercion::Field },
            };
            mk_expr(ExprX::Unary(op, vir_args[0].clone()))
        }
        VerusItem::CompilableOpr(CompilableOprItem::TrackedNew) => {
            record_misc(bctx, expr, MiscCall::TrackedNew);
            let vir_args = mk_vir_args(bctx, &args)?;
            assert!(vir_args.len() == 1);
            let op = UnaryOp::CoerceMode {
                // Allow the constructor to be weakened to spec when its result is spec-only.
                op_mode: Mode::Spec,
                from_mode: Mode::Proof,
                to_mode: Mode::Proof,
                kind: ModeCoercion::Constructor,
            };
            mk_expr(ExprX::Unary(op, vir_args[0].clone()))
        }
        VerusItem::CompilableOpr(CompilableOprItem::TrackedExecBorrow) => {
            record_misc(bctx, expr, MiscCall::TrackedExecBorrow);
            let vir_args = mk_vir_args(bctx, &args)?;
            assert!(vir_args.len() == 1);
            let op = UnaryOp::CoerceMode {
                op_mode: Mode::Exec,
                from_mode: Mode::Proof,
                to_mode: Mode::Exec,
                kind: ModeCoercion::Field,
            };
            mk_expr(ExprX::Unary(op, vir_args[0].clone()))
        }
        VerusItem::CompilableOpr(
            opr @ (CompilableOprItem::TrackedGet | CompilableOprItem::TrackedBorrow),
        ) => {
            record_misc(
                bctx,
                expr,
                match opr {
                    CompilableOprItem::TrackedGet => MiscCall::TrackedGet,
                    CompilableOprItem::TrackedBorrow => MiscCall::TrackedBorrow,
                    _ => unreachable!(),
                },
            );

            let vir_args = mk_vir_args(bctx, &args)?;
            assert!(vir_args.len() == 1);
            let op = UnaryOp::CoerceMode {
                op_mode: Mode::Proof,
                from_mode: Mode::Proof,
                to_mode: Mode::Proof,
                kind: ModeCoercion::Field,
            };
            mk_expr(ExprX::Unary(op, vir_args[0].clone()))
        }

        VerusItem::UnaryOp(UnaryOpItem::SpecGhostTracked(SpecGhostTrackedItem::GhostBorrowMut))
        | VerusItem::CompilableOpr(CompilableOprItem::TrackedBorrowMut) => {
            let tracked_mode =
                matches!(verus_item, VerusItem::CompilableOpr(CompilableOprItem::TrackedBorrowMut));

            if tracked_mode {
                record_misc(bctx, expr, MiscCall::TrackedBorrowMut);
            } else {
                record_misc(bctx, expr, MiscCall::GhostBorrowMut);
            }
            let mwm = if tracked_mode { ModeWrapperMode::Proof } else { ModeWrapperMode::Spec };

            assert!(args.len() == 1);

            let vir_arg = expr_to_vir_place(bctx, &args[0])?;

            // x.borrow_mut() takes &mut Tracked<T> and returns &mut T
            // so this is equivalent to `&mut (*x).unwrap`
            // where `unwrap` is the ModeUnwrap projection.
            // (i.e., the projection that maps a Tracked<T> to the Ghost<T> to the place
            // "inside" the Tracked or Ghost)
            // The ModeUnwrap projection can't exist on its own in Verus source,
            // though the &mut and * will often cancel out with adjacent code.
            // So we may end up with a nested Place expression where the ModeUnwrap projection
            // is in the middle.
            //
            // Note: for Ghost, the outer &mut HAS to cancel out with something,
            // or else we will error later on account of trying to take a mut borrow
            // on a spec-mode place. So writing this is ok (where x: Ghost<_>):
            //    *x.borrow_mut() = foo
            // but this is not:
            //    let y = x.borrow_mut()

            let p = crate::rust_to_vir_expr::deref_mut(bctx, expr.span, &vir_arg)?;
            let typ = match &*p.typ {
                TypX::Decorate(TypDecoration::Ghost | TypDecoration::Tracked, None, t) => t.clone(),
                _ => p.typ.clone(),
            };
            let p = bctx.spanned_typed_new(expr.span, &typ, PlaceX::ModeUnwrap(p, mwm));
            // This can't be two-phase since this is an opaque function call from
            // Rust's perspective.
            let e = crate::rust_to_vir_expr::borrow_mut_vir(
                bctx,
                expr.span,
                &p,
                rustc_middle::ty::adjustment::AllowTwoPhase::No,
            );

            Ok(e)
        }
        VerusItem::BinaryOp(BinaryOpItem::Equality(equ_item)) => {
            record_spec_fn(bctx, expr);

            if matches!(equ_item, EqualityItem::SpecEq) {
                let t1 = typ_of_expr_adjusted(bctx, args[0].span, &args[0].hir_id)?;
                let t2 = typ_of_expr_adjusted(bctx, args[1].span, &args[1].hir_id)?;
                // REVIEW: there's some code that (harmlessly) uses == on types that are
                // different in decoration; Rust would reject this, but we currently allow it:
                let t1 = undecorate_typ(&t1);
                let t2 = undecorate_typ(&t2);
                if !(types_equal(&t1, &t2)
                    || is_smt_arith(
                        bctx,
                        args[0].span,
                        args[1].span,
                        &args[0].hir_id,
                        &args[1].hir_id,
                    )?)
                {
                    return Err(vir_err_span_str(expr.span, "mismatched types; types must be compatible to use == or !=")
                        .secondary_label(&crate::spans::err_air_span(args[0].span), format!("this is `{}`", typ_to_diagnostic_str(&t1)))
                        .secondary_label(&crate::spans::err_air_span(args[1].span), format!("this is `{}`", typ_to_diagnostic_str(&t2)))
                        .help("decorations (like &,Ghost,Tracked,Box,Rc,...) are transparent for == or != in spec code"));
                }
            }

            let vir_args = mk_vir_args(bctx, &args)?;
            let lhs = vir_args[0].clone();
            let rhs = vir_args[1].clone();

            if matches!(equ_item, EqualityItem::ExtEqual | EqualityItem::ExtEqualDeep) {
                assert!(node_substs.len() == 1);
                let t = match node_substs[0].as_type() {
                    Some(ty) => bctx.mid_ty_to_vir(expr.span, &ty)?,
                    _ => panic!("unexpected ext_equal type argument"),
                };
                let vop = vir::ast::BinaryOpr::ExtEq(equ_item == &EqualityItem::ExtEqualDeep, t);
                mk_expr(ExprX::BinaryOpr(vop, lhs, rhs))
            } else {
                let vop = BinaryOp::Eq(Mode::Spec);
                mk_expr(ExprX::Binary(vop, lhs, rhs))
            }
        }
        VerusItem::CompilableOpr(CompilableOprItem::Implies) => {
            // REVIEW: should this really be a 'compilable operator'?
            // Imply is marked as unimplemented! in verus_builtin.
            record_misc(bctx, expr, MiscCall::Implies);

            let (lhs, rhs) = mk_two_vir_args(bctx, expr.span, &args)?;
            mk_expr(ExprX::Logical(LogicalOp::Implies, lhs, rhs))
        }
        VerusItem::UnaryOp(UnaryOpItem::IeeeFloat(fop)) => {
            use crate::verus_items::IeeeFloatUnaryItem;
            use vir::ast::IeeeFloatUnaryOp;
            record_spec_fn(bctx, expr);
            let varg = mk_one_vir_arg(bctx, expr.span, &args)?;
            if !matches!(fop, IeeeFloatUnaryItem::Cast) {
                check_ieee_float_operands(expr.span, &[&varg])?;
            }
            let vop = match fop {
                IeeeFloatUnaryItem::Cast => UnaryOp::IeeeFloat(IeeeFloatUnaryOp::Cast),
                IeeeFloatUnaryItem::Neg => UnaryOp::IeeeFloat(IeeeFloatUnaryOp::Neg),
                IeeeFloatUnaryItem::Floor => UnaryOp::IeeeFloat(IeeeFloatUnaryOp::Floor),
                IeeeFloatUnaryItem::Ceil => UnaryOp::IeeeFloat(IeeeFloatUnaryOp::Ceil),
                IeeeFloatUnaryItem::Round => UnaryOp::IeeeFloat(IeeeFloatUnaryOp::Round),
                IeeeFloatUnaryItem::RoundTiesEven => {
                    UnaryOp::IeeeFloat(IeeeFloatUnaryOp::RoundTiesEven)
                }
                IeeeFloatUnaryItem::Trunc => UnaryOp::IeeeFloat(IeeeFloatUnaryOp::Trunc),
                IeeeFloatUnaryItem::IsNormal => UnaryOp::IeeeFloat(IeeeFloatUnaryOp::IsNormal),
                IeeeFloatUnaryItem::IsSubnormal => {
                    UnaryOp::IeeeFloat(IeeeFloatUnaryOp::IsSubnormal)
                }
                IeeeFloatUnaryItem::IsZero => UnaryOp::IeeeFloat(IeeeFloatUnaryOp::IsZero),
                IeeeFloatUnaryItem::IsInfinite => UnaryOp::IeeeFloat(IeeeFloatUnaryOp::IsInfinite),
                IeeeFloatUnaryItem::IsNaN => UnaryOp::IeeeFloat(IeeeFloatUnaryOp::IsNaN),
                IeeeFloatUnaryItem::IsNegative => UnaryOp::IeeeFloat(IeeeFloatUnaryOp::IsNegative),
                IeeeFloatUnaryItem::IsPositive => UnaryOp::IeeeFloat(IeeeFloatUnaryOp::IsPositive),
            };
            mk_expr(ExprX::Unary(vop, varg))
        }
        VerusItem::BinaryOp(BinaryOpItem::IeeeFloat(fop)) => {
            use crate::verus_items::IeeeFloatBinaryItem;
            use vir::ast::IeeeFloatBinaryOp;
            record_spec_fn(bctx, expr);
            let (lhs, rhs) = mk_two_vir_args(bctx, expr.span, &args)?;
            check_ieee_float_operands(expr.span, &[&lhs, &rhs])?;
            let vop = match fop {
                IeeeFloatBinaryItem::Add => BinaryOp::IeeeFloat(IeeeFloatBinaryOp::Add),
                IeeeFloatBinaryItem::Sub => BinaryOp::IeeeFloat(IeeeFloatBinaryOp::Sub),
                IeeeFloatBinaryItem::Mul => BinaryOp::IeeeFloat(IeeeFloatBinaryOp::Mul),
                IeeeFloatBinaryItem::Div => BinaryOp::IeeeFloat(IeeeFloatBinaryOp::Div),
                IeeeFloatBinaryItem::Eq => BinaryOp::IeeeFloat(IeeeFloatBinaryOp::Eq),
                IeeeFloatBinaryItem::Le => {
                    BinaryOp::IeeeFloat(IeeeFloatBinaryOp::InEq(InequalityOp::Le))
                }
                IeeeFloatBinaryItem::Ge => {
                    BinaryOp::IeeeFloat(IeeeFloatBinaryOp::InEq(InequalityOp::Ge))
                }
                IeeeFloatBinaryItem::Lt => {
                    BinaryOp::IeeeFloat(IeeeFloatBinaryOp::InEq(InequalityOp::Lt))
                }
                IeeeFloatBinaryItem::Gt => {
                    BinaryOp::IeeeFloat(IeeeFloatBinaryOp::InEq(InequalityOp::Gt))
                }
            };
            mk_expr(ExprX::Binary(vop, lhs, rhs))
        }
        VerusItem::BinaryOp(
            BinaryOpItem::Arith(_)
            | BinaryOpItem::SpecArith(_)
            | BinaryOpItem::SpecBitwise(_)
            | BinaryOpItem::SpecOrd(_),
        ) => {
            use crate::rust_to_vir_base::is_float_arith;

            record_spec_fn(bctx, expr);

            let is_smt =
                is_smt_arith(bctx, args[0].span, args[1].span, &args[0].hir_id, &args[1].hir_id)?;
            let is_float =
                is_float_arith(bctx, args[0].span, args[1].span, &args[0].hir_id, &args[1].hir_id)?;
            if !is_smt && !is_float {
                let t1 = bctx.types.expr_ty_adjusted(&args[0]);
                let t2 = bctx.types.expr_ty_adjusted(&args[1]);
                return err_span(
                    expr.span,
                    format!(
                        "types are not compatible with this operator (got {:?} and {:?})",
                        t1, t2
                    ),
                );
            }

            let (lhs, rhs) = mk_two_vir_args(bctx, expr.span, &args)?;

            let vop = match verus_item {
                VerusItem::BinaryOp(BinaryOpItem::SpecOrd(spec_ord_item))
                    if matches!(&*undecorate_typ(&lhs.typ), TypX::Float(_)) =>
                {
                    use vir::ast::IeeeFloatBinaryOp;
                    match spec_ord_item {
                        SpecOrdItem::Le => {
                            BinaryOp::IeeeFloat(IeeeFloatBinaryOp::InEq(InequalityOp::Le))
                        }
                        SpecOrdItem::Ge => {
                            BinaryOp::IeeeFloat(IeeeFloatBinaryOp::InEq(InequalityOp::Ge))
                        }
                        SpecOrdItem::Lt => {
                            BinaryOp::IeeeFloat(IeeeFloatBinaryOp::InEq(InequalityOp::Lt))
                        }
                        SpecOrdItem::Gt => {
                            BinaryOp::IeeeFloat(IeeeFloatBinaryOp::InEq(InequalityOp::Gt))
                        }
                    }
                }
                VerusItem::BinaryOp(BinaryOpItem::SpecOrd(spec_ord_item)) => match spec_ord_item {
                    SpecOrdItem::Le => BinaryOp::Inequality(InequalityOp::Le),
                    SpecOrdItem::Ge => BinaryOp::Inequality(InequalityOp::Ge),
                    SpecOrdItem::Lt => BinaryOp::Inequality(InequalityOp::Lt),
                    SpecOrdItem::Gt => BinaryOp::Inequality(InequalityOp::Gt),
                },
                VerusItem::BinaryOp(BinaryOpItem::Arith(arith_item)) => {
                    let range = crate::rust_to_vir_base::get_range(&expr_typ()?);
                    let ob = if bctx.in_ghost {
                        OverflowBehavior::Truncate(range)
                    } else {
                        OverflowBehavior::Error(range)
                    };
                    match arith_item {
                        ArithItem::BuiltinAdd => BinaryOp::Arith(ArithOp::Add(ob)),
                        ArithItem::BuiltinSub => BinaryOp::Arith(ArithOp::Sub(ob)),
                        ArithItem::BuiltinMul => BinaryOp::Arith(ArithOp::Mul(ob)),
                    }
                }
                VerusItem::BinaryOp(BinaryOpItem::SpecArith(spec_arith_item))
                    if matches!(&*undecorate_typ(&expr_typ()?), TypX::Real) =>
                {
                    use vir::ast::RealArithOp;
                    match spec_arith_item {
                        SpecArithItem::Add => BinaryOp::RealArith(RealArithOp::Add),
                        SpecArithItem::Sub => BinaryOp::RealArith(RealArithOp::Sub),
                        SpecArithItem::Mul => BinaryOp::RealArith(RealArithOp::Mul),
                        SpecArithItem::EuclideanOrRealDiv => BinaryOp::RealArith(RealArithOp::Div),
                        SpecArithItem::EuclideanMod => {
                            unreachable!("spec mod operation cannot have type real")
                        }
                    }
                }
                VerusItem::BinaryOp(BinaryOpItem::SpecArith(spec_arith_item))
                    if matches!(&*undecorate_typ(&expr_typ()?), TypX::Float(_)) =>
                {
                    use vir::ast::IeeeFloatBinaryOp;
                    match spec_arith_item {
                        SpecArithItem::Add => BinaryOp::IeeeFloat(IeeeFloatBinaryOp::Add),
                        SpecArithItem::Sub => BinaryOp::IeeeFloat(IeeeFloatBinaryOp::Sub),
                        SpecArithItem::Mul => BinaryOp::IeeeFloat(IeeeFloatBinaryOp::Mul),
                        SpecArithItem::EuclideanOrRealDiv => {
                            BinaryOp::IeeeFloat(IeeeFloatBinaryOp::Div)
                        }
                        SpecArithItem::EuclideanMod => {
                            unreachable!("spec mod operation cannot have floating point type")
                        }
                    }
                }
                VerusItem::BinaryOp(BinaryOpItem::SpecArith(spec_arith_item)) => {
                    let range = crate::rust_to_vir_base::get_range(&expr_typ()?);
                    match spec_arith_item {
                        SpecArithItem::Add => {
                            BinaryOp::Arith(ArithOp::Add(OverflowBehavior::Truncate(range)))
                        }
                        SpecArithItem::Sub => {
                            BinaryOp::Arith(ArithOp::Sub(OverflowBehavior::Truncate(range)))
                        }
                        SpecArithItem::Mul => {
                            BinaryOp::Arith(ArithOp::Mul(OverflowBehavior::Truncate(range)))
                        }
                        SpecArithItem::EuclideanOrRealDiv => {
                            BinaryOp::Arith(ArithOp::EuclideanDiv(Div0Behavior::Allow))
                        }
                        SpecArithItem::EuclideanMod => {
                            BinaryOp::Arith(ArithOp::EuclideanMod(Div0Behavior::Allow))
                        }
                    }
                }
                VerusItem::BinaryOp(BinaryOpItem::SpecBitwise(spec_bitwise)) => {
                    match spec_bitwise {
                        verus_items::SpecBitwiseItem::BitAnd => {
                            BinaryOp::Bitwise(BitwiseOp::BitAnd, BitshiftBehavior::Allow)
                        }
                        verus_items::SpecBitwiseItem::BitOr => {
                            BinaryOp::Bitwise(BitwiseOp::BitOr, BitshiftBehavior::Allow)
                        }
                        verus_items::SpecBitwiseItem::BitXor => {
                            if matches!(*lhs.typ, TypX::Bool) {
                                BinaryOp::BoolXor
                            } else {
                                BinaryOp::Bitwise(BitwiseOp::BitXor, BitshiftBehavior::Allow)
                            }
                        }
                        verus_items::SpecBitwiseItem::Shl => {
                            let (Some(w), s) = bitwidth_and_signedness_of_integer_type(
                                &bctx.ctxt.verus_items,
                                bctx.types.expr_ty(expr),
                            ) else {
                                return err_span(expr.span, "expected finite integer width");
                            };
                            BinaryOp::Bitwise(BitwiseOp::Shl(w, s), BitshiftBehavior::Allow)
                        }
                        verus_items::SpecBitwiseItem::Shr => {
                            BinaryOp::Bitwise(BitwiseOp::Shr, BitshiftBehavior::Allow)
                        }
                    }
                }
                _ => {
                    crate::internal_err!(expr.span, "unexpected verus item")
                }
            };

            mk_expr(ExprX::Binary(vop, lhs, rhs))
        }
        VerusItem::BuiltinFunction(
            re @ (BuiltinFunctionItem::CallRequires | BuiltinFunctionItem::CallEnsures),
        ) => {
            record_spec_fn(bctx, expr);

            let bsf = match re {
                BuiltinFunctionItem::CallRequires => {
                    assert!(args.len() == 2);
                    BuiltinSpecFun::ClosureReq
                }
                BuiltinFunctionItem::CallEnsures => {
                    assert!(args.len() == 3);
                    BuiltinSpecFun::ClosureEns
                }
                BuiltinFunctionItem::ConstrainType => unreachable!(),
                BuiltinFunctionItem::GetFutureOutputType => unreachable!(),
            };

            let vir_args = args
                .iter()
                .map(|arg| expr_to_vir_consume(bctx, &arg))
                .collect::<Result<Vec<_>, _>>()?;

            let typ_args = mk_typ_args(bctx, node_substs, f, expr.span)?;
            let mut typ_args = (*typ_args).clone();
            // Put the args in the order [function type, args type]
            typ_args.swap(0, 1);
            let typ_args = Arc::new(typ_args);

            let impl_paths = get_impl_paths(bctx, f, node_substs, None, false, expr.span)?;

            return mk_expr(ExprX::Call {
                target: CallTarget::BuiltinSpecFun(bsf, typ_args, impl_paths),
                args: Arc::new(vir_args),
                post_args: None,
                body: None,
            });
        }
        VerusItem::ErasedGhostValue
        | VerusItem::ShadowGhostValue
        | VerusItem::DummyCapture(_)
        | VerusItem::MutableReferenceTie
        | VerusItem::TwoPhaseMutableReferenceTie
        | VerusItem::GetFirst => {
            return err_span(
                expr.span,
                format!("this builtin item should not appear in user code",),
            );
        }
        item @ (VerusItem::HasResolved | VerusItem::HasResolvedUnsized) => {
            record_spec_fn_pure_args_only(bctx, expr);
            if !bctx.in_ghost {
                return err_span(expr.span, "has_resolved must be in a 'proof' block");
            }
            let bctx = BodyCtxt { in_explicit_prophecy_node: true, ..bctx.clone() };
            let exp = expr_to_vir_consume(&bctx, &args[0])?;
            let arg_typ = bctx.types.expr_ty_adjusted(&args[0]);
            let arg_typ = match item {
                VerusItem::HasResolved => arg_typ,
                VerusItem::HasResolvedUnsized => match arg_typ.kind() {
                    TyKind::Ref(_, t, rustc_middle::ty::Mutability::Not) => *t,
                    _ => {
                        return err_span(expr.span, "has_resolved_unsized expects shared ref");
                    }
                },
                _ => unreachable!(),
            };
            let t = bctx.mid_ty_to_vir(expr.span, &arg_typ)?;
            mk_expr(ExprX::UnaryOpr(UnaryOpr::HasResolved(t), exp))
        }
        VerusItem::MutRefCurrent | VerusItem::MutRefFuture | VerusItem::Final => {
            let name = match verus_item {
                VerusItem::MutRefCurrent => "mut_ref_current",
                VerusItem::MutRefFuture => "mut_ref_future",
                VerusItem::Final => "final",
                _ => unreachable!(),
            };

            if bctx.migrate_postcondition_vars.is_some() {
                return err_span(
                    expr.span,
                    format!(
                        "to use `{name}`, disable mut-ref backwards-compatability (add #[verifier::deprecated_postcondition_mut_ref_style(false)] to the function)"
                    ),
                );
            }

            record_spec_fn(bctx, expr);
            let exp = expr_to_vir_consume(bctx, &args[0])?;
            let op = match verus_item {
                VerusItem::MutRefCurrent => UnaryOp::MutRefCurrent,
                VerusItem::MutRefFuture => {
                    UnaryOp::MutRefFuture(vir::ast::MutRefFutureSourceName::MutRefFuture)
                }
                VerusItem::Final => UnaryOp::MutRefFinal(false),
                _ => unreachable!(),
            };
            mk_expr(ExprX::Unary(op, exp))
        }
        VerusItem::AfterBorrow => {
            record_spec_fn(bctx, expr);
            let bctx = BodyCtxt { in_explicit_prophecy_node: true, ..bctx.clone() };
            let p = expr_to_vir_place(&bctx, &args[0])?;
            if !is_place_ok_for_spec_after_borrow(&p) {
                return err_span(
                    expr.span,
                    "`after_borrow` expects a local variable, possibly with dereferences or field accesses",
                );
            }

            let rk = vir::ast::ReadKind::SpecAfterBorrow;
            let rk = vir::ast::UnfinalizedReadKind {
                preliminary_kind: rk,
                id: bctx.ctxt.unique_read_kind_id(),
            };
            mk_expr(ExprX::ReadPlace(p, rk))
        }
        VerusItem::MutRefTracked => {
            record_misc(bctx, expr, MiscCall::MutRefTracked);
            let p = expr_to_vir_place(&bctx, &args[0])?;
            let p = crate::rust_to_vir_expr::deref_mut(bctx, expr.span, &p)?;
            let p = crate::rust_to_vir_expr::simplify_place_by_cancelling(&p);
            mk_expr(ExprX::BorrowMutTracked(p))
        }
        VerusItem::BuiltinDeref(d) => {
            // This would be easy to support (similar to handling borrow_mut etc.) but their usage
            // would be very rare so I'm skipping for now
            let tyname = match d {
                BuiltinDerefItem::TrackedDeref | BuiltinDerefItem::TrackedDerefMut => "Tracked",
                BuiltinDerefItem::GhostDeref | BuiltinDerefItem::GhostDerefMut => "Ghost",
            };
            let derefname = match d {
                BuiltinDerefItem::TrackedDeref | BuiltinDerefItem::GhostDeref => "deref",
                BuiltinDerefItem::TrackedDerefMut | BuiltinDerefItem::GhostDerefMut => "deref_mut",
            };
            return Err(vir::messages::error(
                &crate::spans::err_air_span(expr.span),
                format!("not supported: using {tyname}::{derefname}"),
            )
            .help("you can implicitly dereference this type using `*`"));
        }
        VerusItem::Vstd(_, _)
        | VerusItem::RustPrivate(_)
        | VerusItem::Marker(_)
        | VerusItem::BuiltinType(_)
        | VerusItem::BuiltinTrait(_)
        | VerusItem::External(_)
        | VerusItem::Global(_)
        | VerusItem::BuiltinFunction(BuiltinFunctionItem::ConstrainType)
        | VerusItem::BuiltinFunction(BuiltinFunctionItem::GetFutureOutputType) => unreachable!(),
    }
}

fn uncompilable_verus_fn(verus_item: &VerusItem) -> bool {
    match verus_item {
        // Disallowed, but handled in modes
        VerusItem::UnaryOp(UnaryOpItem::SpecGhostTracked(
            SpecGhostTrackedItem::GhostView
            | SpecGhostTrackedItem::GhostBorrow
            | SpecGhostTrackedItem::GhostBorrowMut
            | SpecGhostTrackedItem::TrackedView,
        )) => false,
        VerusItem::Quant(_) => false,
        VerusItem::Assert(_) => false,
        VerusItem::Expr(
            ExprItem::Choose
            | ExprItem::ChooseTuple
            | ExprItem::Old
            | ExprItem::GetVariantField
            | ExprItem::GetUnionField
            | ExprItem::IsVariant
            | ExprItem::ShrRefStructWrap,
        ) => false,

        // Disallowed, error here
        VerusItem::Expr(_)
        | VerusItem::UnaryOp(_)
        | VerusItem::BinaryOp(_)
        | VerusItem::Chained(_)
        | VerusItem::UseTypeInvariant
        | VerusItem::WithTriggers
        | VerusItem::OpenInvariantBlock(_)
        | VerusItem::OpenAtomicUpdate(_)
        | VerusItem::BuiltinFunction(_)
        | VerusItem::HasResolved
        | VerusItem::HasResolvedUnsized
        | VerusItem::MutRefCurrent
        | VerusItem::MutRefFuture
        | VerusItem::Final
        | VerusItem::AfterBorrow
        | VerusItem::ErasedGhostValue
        | VerusItem::ShadowGhostValue
        | VerusItem::MutableReferenceTie
        | VerusItem::TwoPhaseMutableReferenceTie
        | VerusItem::GetFirst
        | VerusItem::DummyCapture(_)
        | VerusItem::MutRefTracked => true,

        VerusItem::CompilableOpr(_) => false,
        VerusItem::RustPrivate(_) => false,

        // Handled properly by mode-checking
        VerusItem::BuiltinDeref(_) => false,
        VerusItem::Vstd(_, _) => false,

        // Handled properly by erasure
        VerusItem::Spec(_) => false,
        VerusItem::Directive(_) => false,

        // Not functions
        VerusItem::Marker(_) => false,
        VerusItem::BuiltinType(_) => false,
        VerusItem::BuiltinTrait(_) => false,
        VerusItem::Global(_) => false,
        VerusItem::External(_) => false,
    }
}

fn is_place_ok_for_spec_after_borrow(place: &Place) -> bool {
    match &place.x {
        PlaceX::Local(_) => true,
        PlaceX::DerefMut(p) => is_place_ok_for_spec_after_borrow(p),
        PlaceX::Field(opr, p) => {
            matches!(opr.check, VariantCheck::None) && is_place_ok_for_spec_after_borrow(p)
        }
        PlaceX::Temporary(_) => false,
        PlaceX::ModeUnwrap(p, _) => is_place_ok_for_spec_after_borrow(p),
        PlaceX::WithExpr(..) => false,
        PlaceX::Index(..) => false,
        PlaceX::UserDefinedTypInvariantObligation(..) => false,
    }
}

fn get_impl_paths<'tcx>(
    bctx: &BodyCtxt<'tcx>,
    f: DefId,
    node_substs: &'tcx rustc_middle::ty::List<rustc_middle::ty::GenericArg<'tcx>>,
    remove_self_trait_bound: Option<(DefId, &mut Option<vir::ast::ImplPath>)>,
    const_var: bool,
    span: Span,
) -> Result<vir::ast::ImplPaths, VirErr> {
    let fid = if const_var {
        f
    } else if let rustc_middle::ty::FnDef(fid, _fsubsts) =
        bctx.ctxt.tcx.type_of(f).skip_binder().kind()
    {
        *fid
    } else {
        panic!("unexpected function {:?}", f)
    };
    crate::rust_to_vir_base::get_impl_paths(
        bctx.ctxt.tcx,
        &bctx.ctxt.verus_items,
        bctx.fun_id,
        fid,
        node_substs,
        remove_self_trait_bound,
        span,
    )
}

fn check_is_builtin_constrain_typ<'tcx>(bctx: &BodyCtxt<'tcx>, e: &'tcx Expr<'tcx>) -> bool {
    if let ExprKind::Call(fun, ..) = e.kind {
        if let ExprKind::Path(QPath::Resolved(_, path)) = fun.kind {
            if let Some(def_id) = path.res.opt_def_id() {
                if bctx.ctxt.get_verus_item(def_id)
                    == Some(&VerusItem::BuiltinFunction(BuiltinFunctionItem::ConstrainType))
                {
                    record_call(bctx, e, ResolvedCall::MiscEraseAbsolutely);
                    return false;
                }
            }
        }
    }
    true
}

fn extract_ensures<'tcx>(
    bctx: &BodyCtxt<'tcx>,
    expr: &'tcx Expr<'tcx>,
) -> Result<HeaderExpr, VirErr> {
    let expr = skip_closure_coercion(bctx, expr);
    let tcx = bctx.ctxt.tcx;
    use vir::ast::Exprs;
    let get_args = |body_value: &'tcx Expr<'tcx>| -> Result<(Exprs, Exprs), VirErr> {
        let args = extract_array(body_value)
            .into_iter()
            .filter(|e| check_is_builtin_constrain_typ(bctx, e))
            .map(|e| get_ensures_arg(bctx, e))
            .collect::<Result<Vec<_>, _>>()?;

        let regular = args.iter().filter(|&(b, _)| !b).map(|(_, e)| e.clone()).collect();
        let default = args.iter().filter(|&(b, _)| *b).map(|(_, e)| e.clone()).collect();
        Ok((Arc::new(regular), Arc::new(default)))
    };
    match &expr.kind {
        ExprKind::Closure(closure) => {
            bctx.ctxt.push_body_erasure(
                closure.def_id,
                BodyErasure { erase_body: true, ret_spec: true },
            );

            let typs: Vec<Typ> = closure_param_typs(bctx, expr)?;
            let body = tcx.hir_body(closure.body);
            let mut xs: Vec<VarIdent> = Vec::new();
            for param in body.params.iter() {
                xs.push(pat_to_var(param.pat)?);
            }

            let expr = &body.value;
            let args = get_args(expr)?;
            if typs.len() == 0 && xs.len() == 1 {
                let id_typ = Some((xs[0].clone(), None));
                Ok(Arc::new(HeaderExprX::Ensures(id_typ, args)))
            } else if typs.len() == 1 && xs.len() == 1 {
                let id_typ = Some((xs[0].clone(), Some(typs[0].clone())));
                Ok(Arc::new(HeaderExprX::Ensures(id_typ, args)))
            } else if xs.len() == 0 {
                Ok(Arc::new(HeaderExprX::Ensures(None, args)))
            } else {
                err_span(expr.span, "expected at most 1 parameter in closure")
            }
        }
        _ => {
            let args = get_args(expr)?;
            Ok(Arc::new(HeaderExprX::Ensures(None, args)))
        }
    }
}

fn extract_quant<'tcx>(
    bctx: &BodyCtxt<'tcx>,
    span: Span,
    quant: Quant,
    expr: &'tcx Expr<'tcx>,
) -> Result<vir::ast::Expr, VirErr> {
    let expr = skip_closure_coercion(bctx, expr);
    let tcx = bctx.ctxt.tcx;
    match &expr.kind {
        ExprKind::Closure(closure) => {
            bctx.ctxt.push_body_erasure(
                closure.def_id,
                BodyErasure { erase_body: true, ret_spec: true },
            );

            let body = tcx.hir_body(closure.body);
            let typs = closure_param_typs(bctx, expr)?;
            assert!(typs.len() == body.params.len());
            let mut binders: Vec<VarBinder<Typ>> = Vec::new();
            for (x, t) in body.params.iter().zip(typs) {
                binders.push(Arc::new(VarBinderX { name: pat_to_var(x.pat)?, a: t }));
            }
            let expr = &body.value;
            let mut vir_expr = expr_to_vir_consume(bctx, expr)?;
            let _ = vir::headers::read_header(
                &mut vir_expr,
                &vir::headers::HeaderAllows::Some(vec![]),
            )?;
            let typ = Arc::new(TypX::Bool);
            if !matches!(bctx.types.expr_ty_adjusted(expr).kind(), TyKind::Bool) {
                return err_span(expr.span, "forall/ensures needs a bool expression");
            }
            Ok(bctx.spanned_typed_new(span, &typ, ExprX::Quant(quant, Arc::new(binders), vir_expr)))
        }
        _ => err_span(expr.span, "argument to forall/exists must be a closure"),
    }
}

fn get_ensures_arg<'tcx>(
    bctx: &BodyCtxt<'tcx>,
    mut expr: &Expr<'tcx>,
) -> Result<(bool, vir::ast::Expr), VirErr> {
    if matches!(bctx.types.expr_ty_adjusted(expr).kind(), TyKind::Bool) {
        let mut default_ensures = false;
        if let ExprKind::Call(fun, args) = &expr.kind {
            if let ExprKind::Path(qpath) = &fun.kind {
                let def = bctx.types.qpath_res(&qpath, fun.hir_id);
                if let rustc_hir::def::Res::Def(_, def_id) = def {
                    let verus_item = bctx.ctxt.verus_items.id_to_name.get(&def_id);
                    if verus_item == Some(&VerusItem::Expr(ExprItem::DefaultEnsures)) {
                        assert!(args.len() == 1);
                        default_ensures = true;
                        expr = &args[0];
                    }
                }
            }
        }
        let mut vir_expr = expr_to_vir_consume(bctx, expr)?;
        // Wrap expressions with #[verus::internal(auto_loop_ensures)] attribute
        let expr_attrs = bctx.ctxt.tcx.hir_attrs(expr.hir_id);
        if crate::attributes::has_auto_loop_ensures_attr(expr_attrs) {
            vir_expr = vir_expr.new_x(vir::ast::ExprX::UnaryOpr(
                vir::ast::UnaryOpr::AutoLoopEnsures,
                vir_expr.clone(),
            ));
        }
        Ok((default_ensures, vir_expr))
    } else {
        err_span(expr.span, "ensures needs a bool expression")
    }
}

fn extract_assert_forall_by<'tcx>(
    bctx: &BodyCtxt<'tcx>,
    span: Span,
    expr: &'tcx Expr<'tcx>,
) -> Result<vir::ast::Expr, VirErr> {
    let expr = skip_closure_coercion(bctx, expr);
    let tcx = bctx.ctxt.tcx;
    match &expr.kind {
        ExprKind::Closure(closure) => {
            bctx.ctxt.push_body_erasure(
                closure.def_id,
                BodyErasure { erase_body: true, ret_spec: true },
            );

            let body = tcx.hir_body(closure.body);
            let typs = closure_param_typs(bctx, expr)?;
            assert!(body.params.len() == typs.len());
            let mut binders: Vec<VarBinder<Typ>> = Vec::new();
            for (x, t) in body.params.iter().zip(typs) {
                binders.push(Arc::new(VarBinderX { name: pat_to_var(x.pat)?, a: t }));
            }
            let expr = &body.value;
            let bctx = &bctx.set_header_setting(HeaderSetting::Assert);
            let mut vir_expr = expr_to_vir_consume(bctx, expr)?;
            use vir::headers::{HeaderAllow, HeaderAllows};
            let header = vir::headers::read_header(
                &mut vir_expr,
                &HeaderAllows::Some(vec![HeaderAllow::Require, HeaderAllow::Ensure]),
            )?;
            assert!(header.ensure.1.len() == 0);
            if header.require.len() > 1 {
                return err_span(expr.span, "assert_forall_by can have at most one requires");
            }
            if header.ensure.0.len() != 1 {
                return err_span(expr.span, "assert_forall_by must have exactly one ensures");
            }
            if header.ensure_id_typ.is_some() {
                return err_span(expr.span, "ensures clause must be a bool");
            }
            let typ = unit_typ();
            let vars = Arc::new(binders);
            let require = if header.require.len() == 1 {
                header.require[0].clone()
            } else {
                bctx.spanned_typed_new(
                    span,
                    &Arc::new(TypX::Bool),
                    ExprX::Const(Constant::Bool(true)),
                )
            };
            let ensure = header.ensure.0[0].clone();
            let forallx = ExprX::AssertBy { vars, require, ensure, proof: vir_expr };
            Ok(bctx.spanned_typed_new(span, &typ, forallx))
        }
        _ => err_span(expr.span, "argument to forall/exists must be a closure"),
    }
}

fn extract_choose<'tcx>(
    bctx: &BodyCtxt<'tcx>,
    span: Span,
    expr: &'tcx Expr<'tcx>,
    tuple: bool,
    expr_typ: Typ,
) -> Result<vir::ast::Expr, VirErr> {
    let expr = skip_closure_coercion(bctx, expr);
    let tcx = bctx.ctxt.tcx;
    match &expr.kind {
        ExprKind::Closure(closure) => {
            bctx.ctxt.push_body_erasure(
                closure.def_id,
                BodyErasure { erase_body: true, ret_spec: true },
            );

            let closure_body = tcx.hir_body(closure.body);
            let mut params: Vec<VarBinder<Typ>> = Vec::new();
            let mut vars: Vec<vir::ast::Expr> = Vec::new();
            let typs = closure_param_typs(bctx, expr)?;
            assert!(closure_body.params.len() == typs.len());
            for (x, typ) in closure_body.params.iter().zip(typs) {
                let name = pat_to_var(x.pat)?;
                let vir_expr = bctx.spanned_typed_new(x.span, &typ, ExprX::Var(name.clone()));
                let mut erasure_info = bctx.ctxt.erasure_info.borrow_mut();
                erasure_info.local_hir_vir_ids.push((None, vir_expr.span.id));
                vars.push(vir_expr);
                params.push(Arc::new(VarBinderX { name, a: typ }));
            }
            let typs = vec_map(&params, |p| p.a.clone());
            let cond_expr = &closure_body.value;
            let cond = expr_to_vir_consume(bctx, cond_expr)?;
            let body = if tuple {
                let typ = mk_tuple_typ(&Arc::new(typs));
                if !vir::ast_util::types_equal(&typ, &expr_typ) {
                    return err_span(
                        expr.span,
                        format!(
                            "expected choose_tuple to have type {:?}, found type {:?}",
                            typ, expr_typ
                        ),
                    );
                }
                bctx.spanned_typed_new(span, &typ, mk_tuple_x(&Arc::new(vars)))
            } else {
                if params.len() != 1 {
                    return err_span(
                        expr.span,
                        "choose expects exactly one parameter (use choose_tuple for multiple parameters)",
                    );
                }
                vars[0].clone()
            };
            let params = Arc::new(params);
            Ok(bctx.spanned_typed_new(
                span,
                &body.clone().typ,
                ExprX::Choose { params, cond, body },
            ))
        }
        _ => {
            dbg!(&expr);
            err_span(expr.span, "argument to choose must be a closure")
        }
    }
}

/// If `expr` is of the form `closure_to_spec_fn(e)` then return `e`.
/// Otherwise, return `expr`.
///
/// This is needed because the syntax macro can often create expressions that look like:
/// forall(closure_to_fn_spec(|x| { ... }))
fn skip_closure_coercion<'tcx>(bctx: &BodyCtxt<'tcx>, expr: &'tcx Expr<'tcx>) -> &'tcx Expr<'tcx> {
    match &expr.kind {
        ExprKind::Call(fun, args_slice) => match &fun.kind {
            ExprKind::Path(qpath) => {
                let def = bctx.types.qpath_res(&qpath, fun.hir_id);
                match def {
                    rustc_hir::def::Res::Def(_, def_id) => {
                        let verus_item = bctx.ctxt.verus_items.id_to_name.get(&def_id);
                        if verus_item == Some(&VerusItem::Expr(ExprItem::ClosureToFnSpec)) {
                            return skip_closure_coercion(bctx, &args_slice[0]);
                        }
                    }
                    _ => {}
                }
            }
            _ => {}
        },
        ExprKind::Block(
            Block {
                stmts,
                expr: Some(e),
                hir_id: _,
                rules: BlockCheckMode::DefaultBlock,
                span: _,
                targeted_by_break: false,
            },
            None,
        ) => {
            if stmts.len() == 1 {
                match &stmts[0].kind {
                    StmtKind::Let(rustc_hir::LetStmt { init: Some(init), .. }) => {
                        if crate::rust_to_vir_expr::is_ignorable_dummy_capture_operation(bctx, init)
                        {
                            return skip_closure_coercion(bctx, e);
                        }
                    }
                    _ => {}
                }
            }
        }
        _ => {}
    }

    expr
}

fn mk_is_smaller_than<'tcx>(
    bctx: &BodyCtxt<'tcx>,
    span: Span,
    args0: Vec<&'tcx Expr>,
    args1: Vec<&'tcx Expr>,
    recursive_function_field: bool,
) -> Result<vir::ast::Expr, VirErr> {
    // convert is_smaller_than((x0, y0, z0), (x1, y1, z1)) into
    // x0 < x1 || (x0 == x1 && (y0 < y1 || (y0 == y1 && z0 < z1)))
    // see also check_decrease in recursion.rs
    let tbool = Arc::new(TypX::Bool);
    let tint = Arc::new(TypX::Int(IntRange::Int));
    let when_equalx = ExprX::Const(Constant::Bool(args1.len() < args0.len()));
    let when_equal = bctx.spanned_typed_new(span, &tbool, when_equalx);
    let mut dec_exp: vir::ast::Expr = when_equal;
    for (i, (exp0, exp1)) in args0.iter().zip(args1.iter()).rev().enumerate() {
        let mk_bop = |op: BinaryOp, e1: vir::ast::Expr, e2: vir::ast::Expr| {
            bctx.spanned_typed_new(span, &tbool, ExprX::Binary(op, e1, e2))
        };
        let mk_lop = |op: LogicalOp, e1: vir::ast::Expr, e2: vir::ast::Expr| {
            bctx.spanned_typed_new(span, &tbool, ExprX::Logical(op, e1, e2))
        };
        let mk_cmp = |lt: bool| -> Result<vir::ast::Expr, VirErr> {
            let e0 = expr_to_vir_consume(bctx, exp0)?;
            let e1 = expr_to_vir_consume(bctx, exp1)?;
            if vir::recursion::height_is_int(&e0.typ) && vir::recursion::height_is_int(&e1.typ) {
                if lt {
                    // 0 <= x < y
                    let zerox = ExprX::Const(vir::ast_util::const_int_from_u128(0));
                    let zero = bctx.spanned_typed_new(span, &tint, zerox);
                    let op0 = BinaryOp::Inequality(InequalityOp::Le);
                    let cmp0 = mk_bop(op0, zero, e0);
                    let op1 = BinaryOp::Inequality(InequalityOp::Lt);
                    let e0 = expr_to_vir_consume(bctx, exp0)?;
                    let cmp1 = mk_bop(op1, e0, e1);
                    Ok(mk_lop(LogicalOp::And, cmp0, cmp1))
                } else {
                    Ok(mk_bop(BinaryOp::Eq(Mode::Spec), e0, e1))
                }
            } else {
                let cmp = BinaryOp::HeightCompare { strictly_lt: lt, recursive_function_field };
                Ok(mk_bop(cmp, e0, e1))
            }
        };
        if i == 0 {
            // i == 0 means last shared exp0/exp1, which we visit first
            if args1.len() < args0.len() {
                // if z0 == z1, we can ignore the extra args0:
                // z0 < z1 || z0 == z1
                dec_exp = mk_lop(LogicalOp::Or, mk_cmp(true)?, mk_cmp(false)?);
            } else {
                // z0 < z1
                dec_exp = mk_cmp(true)?;
            }
        } else {
            // x0 < x1 || (x0 == x1 && dec_exp)
            let and = mk_lop(LogicalOp::And, mk_cmp(false)?, dec_exp);
            dec_exp = mk_lop(LogicalOp::Or, mk_cmp(true)?, and);
        }
    }
    return Ok(dec_exp);
}

pub(crate) fn fix_node_substs<'tcx, 'a>(
    tcx: rustc_middle::ty::TyCtxt<'tcx>,
    types: &'tcx rustc_middle::ty::TypeckResults<'tcx>,
    node_substs: &'tcx rustc_middle::ty::List<rustc_middle::ty::GenericArg<'tcx>>,
    rust_item: Option<RustItem>,
    args: &'a [&'tcx Expr<'tcx>],
    expr: &'a Expr<'tcx>,
) -> &'tcx rustc_middle::ty::List<rustc_middle::ty::GenericArg<'tcx>> {
    match rust_item {
        Some(RustItem::TryTraitBranch) => {
            // I don't understand why, but in this case, node_substs is empty instead
            // of having the type argument. Let's fix it here.
            // `branch` has type `fn branch(self) -> ...`
            // so we can get the Self argument from the first argument.
            let generic_arg = GenericArg::from(types.expr_ty_adjusted(&args[0]));
            tcx.mk_args(&[generic_arg])
        }
        Some(RustItem::ResidualTraitFromResidual) => {
            // `fn from_residual(residual: R) -> Self;`
            let generic_arg0 = GenericArg::from(types.expr_ty(expr));
            let generic_arg1 = GenericArg::from(types.expr_ty_adjusted(&args[0]));
            tcx.mk_args(&[generic_arg0, generic_arg1])
        }
        Some(RustItem::IntoIterFn) if node_substs.is_empty() => {
            // A `for` loop produced by a `macro_rules!` expansion is not rewritten
            // by the `verus!` macro, so it reaches rustc's native for-loop
            // desugaring, which emits an `IntoIterator::into_iter` call whose
            // node_substs is empty instead of carrying the Self type argument.
            let generic_arg = GenericArg::from(types.expr_ty_adjusted(&args[0]));
            tcx.mk_args(&[generic_arg])
        }
        _ => node_substs,
    }
}

pub(crate) fn mk_typ_args<'tcx>(
    bctx: &BodyCtxt<'tcx>,
    substs: &'tcx rustc_middle::ty::List<rustc_middle::ty::GenericArg<'tcx>>,
    _f: DefId,
    span: Span,
) -> Result<vir::ast::Typs, VirErr> {
    let tcx = bctx.ctxt.tcx;
    let mut typ_args: Vec<Typ> = Vec::new();
    for typ_arg in substs {
        match typ_arg.kind() {
            GenericArgKind::Type(ty) => {
                typ_args.push(bctx.mid_ty_to_vir(span, &ty)?);
            }
            GenericArgKind::Lifetime(_) => {}
            GenericArgKind::Const(cnst) => {
                typ_args.push(crate::rust_to_vir_base::mid_ty_const_to_vir(
                    tcx,
                    Some(span),
                    &cnst,
                )?);
            }
        }
    }
    Ok(Arc::new(typ_args))
}

fn mk_vir_args<'tcx>(
    bctx: &BodyCtxt<'tcx>,
    args: &[&'tcx Expr<'tcx>],
) -> Result<Vec<vir::ast::Expr>, VirErr> {
    args.iter().map(|arg| expr_to_vir_consume(bctx, arg)).collect::<Result<Vec<_>, _>>()
}

fn mk_one_vir_arg<'tcx>(
    bctx: &BodyCtxt<'tcx>,
    span: Span,
    args: &Vec<&'tcx Expr<'tcx>>,
) -> Result<vir::ast::Expr, VirErr> {
    unsupported_err_unless!(args.len() == 1, span, "expected 1 argument", &args);
    expr_to_vir_consume(bctx, &args[0])
}

fn mk_two_vir_args<'tcx>(
    bctx: &BodyCtxt<'tcx>,
    span: Span,
    args: &Vec<&'tcx Expr<'tcx>>,
) -> Result<(vir::ast::Expr, vir::ast::Expr), VirErr> {
    unsupported_err_unless!(args.len() == 2, span, "expected 2 arguments", &args);
    let e0 = expr_to_vir_consume(bctx, &args[0])?;
    let e1 = expr_to_vir_consume(bctx, &args[1])?;
    Ok((e0, e1))
}

/// IEEE float operations are encoded per float format, so each operand needs a concrete float type.
fn check_ieee_float_operands(span: Span, operands: &[&vir::ast::Expr]) -> Result<(), VirErr> {
    for operand in operands {
        if !matches!(&*undecorate_typ(&operand.typ), TypX::Float(_)) {
            return err_span(
                span,
                format!(
                    "IEEE floating point operations require f32 or f64 operands (got `{}`)",
                    typ_to_diagnostic_str(&operand.typ)
                ),
            );
        }
    }
    Ok(())
}

fn get_string_lit_arg<'tcx>(
    arg: &'tcx Expr<'tcx>,
    fn_name_for_error_msg: &str,
) -> Result<String, VirErr> {
    match arg {
        Expr { kind: ExprKind::Lit(Spanned { node: LitKind::Str(s, _), .. }), .. } => {
            Ok(s.to_string())
        }
        _ => err_span(
            arg.span,
            format!("Verus verus_builtin `{fn_name_for_error_msg:}` requires a string literal"),
        ),
    }
}

pub(crate) fn check_variant_field<'tcx>(
    bctx: &BodyCtxt<'tcx>,
    span: Span,
    adt_arg: &'tcx Expr<'tcx>,
    variant_name: &String,
    field_name_typ: Option<(String, &rustc_middle::ty::Ty<'tcx>)>,
) -> Result<(vir::ast::Dt, Option<vir::ast::Ident>), VirErr> {
    let tcx = bctx.ctxt.tcx;

    let ty = bctx.types.expr_ty_adjusted(adt_arg);
    let ty = match ty.kind() {
        rustc_middle::ty::TyKind::Ref(_, t, rustc_ast::Mutability::Not) => t,
        _ => &ty,
    };
    let (adt, substs) = match ty.kind() {
        rustc_middle::ty::TyKind::Adt(adt, substs) => (adt, substs),
        _ => {
            return err_span(span, format!("expected type to be datatype"));
        }
    };

    let vir_adt_ty = bctx.mid_ty_to_vir(span, &ty)?;
    let adt_path = match &*vir_adt_ty {
        TypX::Datatype(path, _, _) => path.clone(),
        _ => {
            return err_span(span, format!("expected type to be datatype"));
        }
    };

    if adt.is_union() {
        if field_name_typ.is_some() {
            // Don't use get_variant_field with unions
            return err_span(
                span,
                format!("this datatype is a union; consider `get_union_field` instead"),
            );
        }
        let variant = adt.non_enum_variant();
        let field_opt = variant.fields.iter().find(|f| f.ident(tcx).as_str() == variant_name);
        if field_opt.is_none() {
            return err_span(span, format!("no field `{variant_name:}` for this union"));
        }

        return Ok((adt_path, None));
    }

    // Enum case:

    let variant_opt = adt.variants().iter().find(|v| v.ident(tcx).as_str() == variant_name);
    let Some(variant) = variant_opt else {
        return err_span(span, format!("no variant `{variant_name:}` for this datatype"));
    };

    match field_name_typ {
        None => Ok((adt_path, None)),
        Some((field_name, expected_field_typ)) => {
            // The 'get_variant_field' case
            let field_opt = variant.fields.iter().find(|f| f.ident(tcx).as_str() == field_name);
            let Some(field) = field_opt else {
                return err_span(span, format!("no field `{field_name:}` for this variant"));
            };

            let typing_env = TypingEnv::post_analysis(tcx, bctx.fun_id);
            let field_ty = tcx.normalize_erasing_regions(typing_env, field.ty(tcx, substs));
            let vir_field_ty = bctx.mid_ty_to_vir(span, &field_ty)?;
            let vir_expected_field_ty = bctx.mid_ty_to_vir(span, &expected_field_typ)?;
            if !types_equal(&vir_field_ty, &vir_expected_field_ty) {
                return err_span(span, "field has the wrong type");
            }

            let field_ident = field_ident_from_rust(&field_name);

            Ok((adt_path, Some(field_ident)))
        }
    }
}

fn check_union_field<'tcx>(
    bctx: &BodyCtxt<'tcx>,
    span: Span,
    adt_arg: &'tcx Expr<'tcx>,
    field_name: &String,
    expected_field_typ: &rustc_middle::ty::Ty<'tcx>,
) -> Result<vir::ast::Dt, VirErr> {
    let tcx = bctx.ctxt.tcx;

    let ty = bctx.types.expr_ty_adjusted(adt_arg);
    let ty = match ty.kind() {
        rustc_middle::ty::TyKind::Ref(_, t, rustc_ast::Mutability::Not) => t,
        _ => &ty,
    };
    let (adt, substs) = match ty.kind() {
        rustc_middle::ty::TyKind::Adt(adt, substs) => (adt, substs),
        _ => {
            return err_span(span, format!("expected type to be datatype"));
        }
    };

    if !adt.is_union() {
        return err_span(span, format!("get_union_field expects a union type"));
    }

    let variant = adt.non_enum_variant();

    let field_opt = variant.fields.iter().find(|f| f.ident(tcx).as_str() == field_name);
    let Some(field) = field_opt else {
        return err_span(span, format!("no field `{field_name:}` for this union"));
    };

    let typing_env = TypingEnv::post_analysis(tcx, bctx.fun_id);
    let field_ty = tcx.normalize_erasing_regions(typing_env, field.ty(tcx, substs));
    let vir_field_ty = bctx.mid_ty_to_vir(span, &field_ty)?;
    let vir_expected_field_ty = bctx.mid_ty_to_vir(span, &expected_field_typ)?;
    if !types_equal(&vir_field_ty, &vir_expected_field_ty) {
        return err_span(span, "field has the wrong type");
    }

    let vir_adt_ty = bctx.mid_ty_to_vir(span, &ty)?;
    let adt_path = match &*vir_adt_ty {
        TypX::Datatype(path, _, _) => path.clone(),
        _ => {
            return err_span(span, format!("expected type to be datatype"));
        }
    };

    Ok(adt_path)
}

fn record_misc<'tcx>(bctx: &BodyCtxt<'tcx>, expr: &Expr, op: MiscCall) {
    record_call(bctx, expr, ResolvedCall::MiscCall(op));
}

fn record_spec_fn<'tcx>(bctx: &BodyCtxt<'tcx>, expr: &Expr) {
    record_call(bctx, expr, ResolvedCall::SpecAllowProofArgs);
}

/// This should only be used for calls that only accept pure spec expressions, with no
/// possibility of side effects or proof functions.
///
/// Any such function needs to set 'in_pure' in modes.rs, or some other way of guaranteeing
/// its contents should be non-meaningful to borrow-checking.
///
/// This is suitable for directives like `assert`, but not suitable for most
/// computational spec fns.
/// When in doubt, use `record_spec_fn` instead.
/// Also note that loop-related functions should use `record_loop_spec`.
fn record_spec_fn_pure_args_only<'tcx>(bctx: &BodyCtxt<'tcx>, expr: &Expr) {
    record_call(bctx, expr, ResolvedCall::SpecPure)
}

/// Record a loop spec function. Similar requirement to `record_spec_fn_pure_args_only`
fn record_loop_spec<'tcx>(
    bctx: &BodyCtxt<'tcx>,
    expr: &Expr,
    loop_hir_id: rustc_hir::HirId,
    kind: LoopSpecKind,
) {
    record_call(bctx, expr, ResolvedCall::LoopSpec(loop_hir_id, kind));
}

pub(crate) fn record_call<'tcx>(bctx: &BodyCtxt<'tcx>, expr: &Expr, resolved_call: ResolvedCall) {
    let resolved_call = match (resolved_call, &bctx.external_trait_from_to) {
        (ResolvedCall::Call(ufun, rfun, ae), Some(paths)) if paths.2.is_some() => {
            let (from_path, _to_path, to_spec_path) = &**paths;
            use vir::traits::rewrite_fun;
            let ufun = rewrite_fun(from_path, to_spec_path.as_ref().unwrap(), &ufun);
            let rfun = rewrite_fun(from_path, to_spec_path.as_ref().unwrap(), &rfun);
            ResolvedCall::Call(ufun, rfun, ae)
        }
        (resolved_call, _) => resolved_call,
    };
    let mut erasure_info = bctx.ctxt.erasure_info.borrow_mut();
    erasure_info.resolved_calls.push((expr.hir_id, expr.span.data(), resolved_call, bctx.in_ghost));
}

/// Remove two-phaseness from the root node of the given expression, if applicable.
/// This is helpful because VIR will complain if there are unexpected two-phase borrows.
///
/// This is only safe to call if removing two-phaseness can't affect lifetime checking.
/// For example, if the node is the only argument to the given call.
fn strip_two_phase(e: &vir::ast::Expr) -> vir::ast::Expr {
    match &e.x {
        ExprX::TwoPhaseBorrowMut(p) => e.new_x(ExprX::BorrowMut(p.clone())),
        ExprX::ImplicitReborrowOrSpecRead(p, true, s) => {
            e.new_x(ExprX::ImplicitReborrowOrSpecRead(p.clone(), false, s.clone()))
        }
        _ => e.clone(),
    }
}

fn native_option_call<'tcx>(
    bctx: &BodyCtxt<'tcx>,
    expr: &Expr<'tcx>,
    function: DefId,
    types: &'tcx rustc_middle::ty::List<GenericArg<'tcx>>,
    args: &[&'tcx Expr<'tcx>],
) -> Result<Option<vir::ast::Expr>, VirErr> {
    let tcx = bctx.ctxt.tcx;
    let path = bctx.ctxt.def_id_to_vir_path(function);
    if path.krate != CrateId::Core || path.segments.len() != 3 {
        return Ok(None);
    }
    let module = path.segments[0].as_str();
    let method = path.segments[2].as_str();
    if !matches!((module, method), ("bool", "then_some") | ("option", "map_or"))
        || tcx.trait_of_assoc(function).is_some()
    {
        return Ok(None);
    }
    let Some(implementation) = tcx.impl_of_assoc(function) else { return Ok(None) };
    let self_type = tcx.type_of(implementation).instantiate_identity().skip_norm_wip();
    let valid = match (module, method, self_type.kind()) {
        ("bool", "then_some", TyKind::Bool) => types.len() == 1 && args.len() == 2,
        ("option", "map_or", TyKind::Adt(datatype, _)) => {
            let option = bctx.ctxt.def_id_to_vir_path(datatype.did());
            option.krate == CrateId::Core
                && option.segments.iter().map(|part| part.as_str()).eq(["option", "Option"])
                && types.len() == 3
                && args.len() == 3
        }
        _ => false,
    };
    if !valid || types.iter().any(|argument| !matches!(argument.kind(), GenericArgKind::Type(_))) {
        return err_span(expr.span, "unsupported native Option bridge identity or signature");
    }
    let symbol = rustc_span::Symbol::intern(&format!("verus::vstd::native_option::{method}"));
    let Some(target) = tcx.get_diagnostic_item(symbol) else {
        return err_span(expr.span, "native Option model unavailable; rebuild matching vstd");
    };
    let target_path = bctx.ctxt.def_id_to_vir_path(target);
    if target_path.krate != CrateId::Vstd
        || !target_path.segments.iter().map(|part| part.as_str()).eq(["native_option", method])
    {
        return err_span(expr.span, "invalid native Option model identity");
    }
    let result = fn_call_to_vir(bctx, expr, target, types, expr.span, args.to_vec(), false)?;
    Ok(Some(result))
}

/// Resolve an original primitive before attaching the checked byte resource
/// effect. The witness must be an actual monomorphic core/alloc function item,
/// never a closure, function pointer or a user function with a similar name.
fn native_byte_vec_call<'tcx>(
    bctx: &BodyCtxt<'tcx>,
    expr: &Expr<'tcx>,
    f: DefId,
    args: &[&'tcx Expr<'tcx>],
) -> Result<Option<vir::ast::Expr>, VirErr> {
    let path = bctx.ctxt.def_id_to_vir_path(f);
    if path.krate != CrateId::Vstd
        || path.segments.len() != 2
        || path.segments[0].as_str() != "byte_vec"
    {
        return Ok(None);
    }
    let Some(op) = path.segments[1].strip_prefix("native_") else { return Ok(None) };
    if !["allocate", "acquire", "write", "advance", "finish"].contains(&op) {
        return Ok(None);
    }
    let Some(witness) = args.first() else {
        return err_span(expr.span, "byte-buffer bridge missing primitive witness");
    };
    if !matches!(witness.kind, ExprKind::Path(_)) {
        return err_span(
            witness.span,
            "unsupported byte-buffer primitive witness: expected a resolved function item",
        );
    }
    let TyKind::FnDef(original, types) = bctx.types.expr_ty(witness).kind() else {
        return err_span(witness.span, "unsupported byte-buffer primitive witness: indirect call");
    };
    let original_path = bctx.ctxt.def_id_to_vir_path(*original);
    let names: Vec<_> = original_path.segments.iter().map(|s| s.as_str()).collect();
    let identity = match op {
        "allocate" => {
            original_path.krate == CrateId::Alloc
                && matches!(names.as_slice(), ["vec", _, "with_capacity"])
        }
        "acquire" => {
            original_path.krate == CrateId::Alloc
                && matches!(names.as_slice(), ["vec", _, "as_mut_ptr"])
        }
        "write" => {
            original_path.krate == CrateId::Core && matches!(names.as_slice(), ["ptr", "write"])
        }
        "advance" => {
            original_path.krate == CrateId::Core
                && matches!(names.as_slice(), ["ptr", "mut_ptr", _, "add"])
        }
        "finish" => {
            original_path.krate == CrateId::Alloc
                && matches!(names.as_slice(), ["vec", _, "set_len"])
        }
        _ => false,
    };
    let byte_types = types.skip_binder().iter().all(|arg| match arg.kind() {
        GenericArgKind::Lifetime(_) => true,
        GenericArgKind::Type(t) => match t.kind() {
            TyKind::Uint(rustc_ast::ast::UintTy::U8) => true,
            TyKind::Adt(d, _) => {
                let p = bctx.ctxt.def_id_to_vir_path(d.did());
                p.krate == CrateId::Alloc
                    && p.segments.iter().map(|s| s.as_str()).eq(["alloc", "Global"])
            }
            _ => false,
        },
        _ => false,
    });
    if !identity || !byte_types {
        return err_span(
            witness.span,
            format!(
                "unsupported byte-buffer primitive identity or element type: {original_path:?}"
            ),
        );
    }
    let symbol = rustc_span::Symbol::intern(&format!("verus::vstd::byte_vec::{op}"));
    let Some(target) = bctx.ctxt.tcx.get_diagnostic_item(symbol) else {
        return err_span(
            expr.span,
            "byte-buffer resource model is unavailable; rebuild matching vstd",
        );
    };
    let result = fn_call_to_vir(
        bctx,
        expr,
        target,
        bctx.ctxt.tcx.mk_args(&[]),
        expr.span,
        args[1..].to_vec(),
        false,
    )?;
    // MIR sees the original carrier signature, including the erased witness.
    // Logical verification sees the validated resource effect and its obligations.
    let original_name = Arc::new(FunX { path });
    if let Some(call) = bctx
        .ctxt
        .erasure_info
        .borrow_mut()
        .resolved_calls
        .iter_mut()
        .rev()
        .find(|c| c.0 == expr.hir_id)
    {
        call.2 = ResolvedCall::Call(original_name.clone(), original_name, false);
    }
    Ok(Some(result))
}
