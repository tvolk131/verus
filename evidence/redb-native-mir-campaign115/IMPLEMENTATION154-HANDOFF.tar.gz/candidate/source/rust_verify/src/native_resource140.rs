use rustc_borrowck::consumers::{self, BodyWithBorrowckFacts, ConsumerOptions, PlaceExt, TwoPhaseActivation};
use rustc_hir::def_id::{DefId, LocalDefId};
use rustc_middle::mir::{self, Operand, Rvalue, StatementKind, TerminatorKind};
use rustc_middle::ty::{self, Ty, TyCtxt};
use rustc_span::Symbol;
use serde_json::json;
use sha2::{Digest, Sha256};
use std::cell::RefCell;
use std::collections::BTreeMap;
use std::path::Path;
use vir::native_resource::native as resource;

const ORIGINAL: &str = "/private/tmp/redb-original-crate-preflight115/redb";

thread_local! {
    static CAPTURES: RefCell<BTreeMap<String, Result<resource::Body, String>>> = RefCell::new(BTreeMap::new());
}

fn hash(bytes: &[u8]) -> String {
    hex::encode(Sha256::digest(bytes))
}

fn location(value: mir::Location) -> resource::Location {
    resource::Location { block: value.block.as_usize(), statement: value.statement_index }
}

fn place<'tcx>(value: mir::Place<'tcx>, body: &mir::Body<'tcx>, tcx: TyCtxt<'tcx>) -> resource::Place {
    resource::Place {
        local: value.local.as_usize(),
        projection: value.projection.iter().map(|element| match element {
            mir::PlaceElem::Deref => "Deref".into(),
            mir::PlaceElem::Field(index, _) => format!("Field({})", index.as_usize()),
            other => format!("UNSUPPORTED:{other:?}"),
        }).collect(),
        typ: format!("{}", value.ty(&body.local_decls, tcx).ty),
    }
}

fn operand<'tcx>(value: &Operand<'tcx>, body: &mir::Body<'tcx>, tcx: TyCtxt<'tcx>) -> resource::Value {
    match value {
        Operand::Copy(value) => resource::Value::Copy(place(*value, body, tcx)),
        Operand::Move(value) => resource::Value::Move(place(*value, body, tcx)),
        Operand::Constant(value) => resource::Value::Constant(format!("{value:?}")),
        other => resource::Value::Unsupported(format!("{other:?}")),
    }
}

fn unwind(value: mir::UnwindAction) -> resource::Unwind {
    match value {
        mir::UnwindAction::Cleanup(block) => resource::Unwind::Cleanup(block.as_usize()),
        mir::UnwindAction::Continue => resource::Unwind::Continue,
        mir::UnwindAction::Unreachable => resource::Unwind::Unreachable,
        mir::UnwindAction::Terminate(reason) => resource::Unwind::Terminate(format!("{reason:?}")),
    }
}

fn self_type<'tcx>(tcx: TyCtxt<'tcx>, did: DefId) -> Option<Ty<'tcx>> {
    let signature = tcx.fn_sig(did).instantiate_identity().skip_binder();
    signature.inputs().first().map(|typ| typ.peel_refs())
}

fn selected(tcx: TyCtxt<'_>, did: LocalDefId) -> bool {
    if !matches!(tcx.def_kind(did), rustc_hir::def::DefKind::AssocFn) { return false; }
    let method = tcx.item_name(did.to_def_id());
    let Some(typ) = self_type(tcx, did.to_def_id()) else { return false; };
    let ty::Adt(adt, _) = typ.kind() else { return false; };
    if !adt.did().is_local() { return false; }
    let name = tcx.item_name(adt.did());
    (name.as_str() == "WritablePage" && matches!(method.as_str(), "mem" | "mem_mut" | "drop"))
        || (name.as_str() == "LRUWriteCache" && matches!(method.as_str(), "return_value" | "take_value"))
        || (name.as_str() == "LRUCache" && method.as_str() == "get_mut")
        || (name.as_str() == "PagedCachedFile" && method.as_str() == "write")
        || (method.as_str() == "write_header" && tcx.def_path_str(did).contains("page_store::page_manager"))
}

fn nominal_name(tcx: TyCtxt<'_>, typ: Ty<'_>, expected: &str) -> bool {
    matches!(typ.kind(), ty::Adt(adt, _) if tcx.item_name(adt.did()).as_str() == expected)
}

fn api<'tcx>(tcx: TyCtxt<'tcx>, owner: LocalDefId, callee: &Operand<'tcx>, body: &mir::Body<'tcx>) -> Result<resource::Api, String> {
    let typ = callee.ty(&body.local_decls, tcx);
    let ty::FnDef(definition, arguments) = *typ.kind() else {
        return Err(format!("indirect call: {typ}"));
    };
    let arguments = arguments.skip_binder();
    let environment = ty::TypingEnv::post_analysis(tcx, owner);
    let instance = ty::Instance::try_resolve(tcx, environment, definition, arguments)
        .map_err(|error| format!("instance resolution: {error:?}"))?
        .ok_or_else(|| format!("unresolved call {}", tcx.def_path_str(definition)))?;
    let resolved = instance.def_id();
    let impl_type = tcx.impl_of_assoc(resolved).map(|implementation| tcx.type_of(implementation).instantiate(tcx, instance.args).skip_norm_wip());
    let method = tcx.item_name(resolved);
    let crate_name = tcx.crate_name(resolved.krate).to_string();
    let primitive = if resolved.is_local() {
        None
    } else if let Some(typ) = impl_type {
        let arc = match typ.kind() {
            ty::Adt(adt, _) => tcx.is_diagnostic_item(Symbol::intern("Arc"), adt.did()) && crate_name == "alloc",
            _ => false,
        };
        let option = match typ.kind() {
            ty::Adt(adt, _) => tcx.lang_items().option_type() == Some(adt.did()) && crate_name == "core",
            _ => false,
        };
        if arc {
            match method.as_str() {
                "deref" => Some(resource::Primitive::ArcDeref),
                "get_mut" => Some(resource::Primitive::ArcGetMut),
                "clone" => Some(resource::Primitive::ArcClone),
                _ => None,
            }
        } else if option {
            match method.as_str() {
                "unwrap" => Some(resource::Primitive::OptionUnwrap),
                "replace" => Some(resource::Primitive::OptionReplace),
                "take" => Some(resource::Primitive::OptionTake),
                _ => None,
            }
        } else if nominal_name(tcx, typ, "Mutex") && crate_name == "std" && method.as_str() == "lock" {
            Some(resource::Primitive::MutexLock)
        } else if nominal_name(tcx, typ, "MutexGuard") && crate_name == "std" && method.as_str() == "deref_mut" {
            Some(resource::Primitive::GuardDerefMut)
        } else if nominal_name(tcx, typ, "Result") && crate_name == "core" && method.as_str() == "unwrap" {
            Some(resource::Primitive::ResultUnwrap)
        } else if matches!(typ.kind(), ty::Slice(_)) && crate_name == "core" && method.as_str() == "copy_from_slice" {
            Some(resource::Primitive::SliceCopy)
        } else { None }
    } else { None };
    Ok(resource::Api {
        definition: tcx.def_path_str(definition), definition_hash: format!("{:?}", tcx.def_path_hash(definition)),
        resolved_instance: format!("{instance}"), resolved_hash: format!("{:?}", tcx.def_path_hash(resolved)),
        crate_name, crate_hash: format!("{:?}", tcx.crate_hash(resolved.krate)),
        signature: format!("{}", tcx.fn_sig(definition).instantiate(tcx, arguments).skip_binder()),
        self_type: impl_type.map(|typ| format!("{typ}")), primitive,
        application_body: resolved.as_local().map(|_| tcx.def_path_str(resolved)),
    })
}

fn produce<'tcx>(tcx: TyCtxt<'tcx>, did: LocalDefId, facts: &BodyWithBorrowckFacts<'tcx>) -> Result<resource::Body, String> {
    let body = &facts.body;
    let span = tcx.def_span(did);
    let source_map = tcx.sess.source_map();
    let file = source_map.lookup_char_pos(span.lo()).file.name.prefer_local_unconditionally().to_string();
    let canonical = std::fs::canonicalize(&file).map_err(|error| format!("source path: {error}"))?;
    if !canonical.starts_with(Path::new(ORIGINAL).join("src")) {
        return Err(format!("not original source: {}", canonical.display()));
    }
    let typ = self_type(tcx, did.to_def_id()).ok_or("missing self type")?;
    let ty::Adt(adt, args) = typ.kind() else { return Err("non-nominal self".into()); };
    let mut data_field = usize::MAX;
    if tcx.item_name(adt.did()).as_str() == "WritablePage" {
        for (index, field) in adt.non_enum_variant().fields.iter_enumerated() {
            if field.name.as_str() == "data" {
                let field_type = field.ty(tcx, args).skip_norm_wip();
                let ty::Adt(data_adt, data_args) = field_type.kind() else { return Err("data not Arc".into()); };
                if !tcx.is_diagnostic_item(Symbol::intern("Arc"), data_adt.did())
                    || !matches!(data_args.type_at(0).kind(), ty::Slice(element) if *element == tcx.types.u8)
                { return Err("actual data type is not alloc Arc<[u8]>".into()); }
                data_field = index.as_usize();
            }
        }
        if data_field == usize::MAX { return Err("actual WritablePage data field absent".into()); }
    }
    let ends = consumers::calculate_borrows_out_of_scope_at_location(body, &facts.region_inference_context, &facts.borrow_set);
    let loans = facts.borrow_set.iter_enumerated().map(|(index, loan)| resource::Loan {
        index: index.as_usize(), reservation: location(loan.reserve_location()),
        activation: match loan.activation_location() {
            TwoPhaseActivation::NotTwoPhase => resource::Activation::Immediate,
            TwoPhaseActivation::NotActivated => resource::Activation::Reserved,
            TwoPhaseActivation::ActivatedAt(value) => resource::Activation::At(location(value)),
        },
        kind: format!("{:?}", loan.kind()), region: format!("{:?}", loan.region()),
        borrowed: place(loan.borrowed_place(), body, tcx), assigned: place(loan.assigned_place(), body, tcx),
        ends: ends.iter().filter(|(_, indices)| indices.contains(&index)).map(|(value, _)| location(*value)).collect(),
    }).collect();
    let mut unsupported = Vec::new();
    let mut blocks = Vec::new();
    for (block_index, block) in body.basic_blocks.iter_enumerated() {
        let mut statements = Vec::new();
        for (statement_index, statement) in block.statements.iter().enumerate() {
            let native_location = mir::Location { block: block_index, statement_index };
            let value = match &statement.kind {
                StatementKind::Assign(assignment) => {
                    let (destination, value) = &**assignment;
                    let value = match value {
                        Rvalue::Use(value, retag) if retag.no() => operand(value, body, tcx),
                        Rvalue::Ref(_, kind, source) => resource::Value::Borrow {
                            source: place(*source, body, tcx), kind: format!("{kind:?}"),
                            ignored_by_borrowck: source.ignore_borrow(tcx, body, facts.borrow_set.locals_state_at_exit()),
                            loan: facts.borrow_set.iter_enumerated().find(|(_, loan)| loan.reserve_location() == native_location
                                && loan.borrowed_place() == *source && loan.assigned_place() == *destination).map(|(index, _)| index.as_usize()),
                        },
                        Rvalue::Aggregate(kind, operands) => match &**kind {
                            mir::AggregateKind::Adt(definition, variant, arguments, _, active_field)
                                if definition.is_local() && variant.as_usize() == 0 && active_field.is_none()
                                    && tcx.item_name(*definition).as_str() == "WritablePage" => {
                                let aggregate = tcx.adt_def(*definition);
                                resource::Value::NominalAggregate {
                                    definition_hash: format!("{:?}", tcx.def_path_hash(*definition)),
                                    typ: format!("{}", Ty::new_adt(tcx, aggregate, arguments)),
                                    fields: aggregate.non_enum_variant().fields.iter().zip(operands.iter())
                                        .map(|(field, value)| (field.name.to_string(), operand(value, body, tcx))).collect(),
                                }
                            }
                            _ => resource::Value::Unsupported(format!("{value:?}")),
                        },
                        other => resource::Value::Unsupported(format!("{other:?}")),
                    };
                    resource::Statement::Assign { destination: place(*destination, body, tcx), value }
                }
                StatementKind::StorageLive(local) => resource::Statement::Storage { local: local.as_usize(), live: true },
                StatementKind::StorageDead(local) => resource::Statement::Storage { local: local.as_usize(), live: false },
                StatementKind::Nop => resource::Statement::Nop,
                other => resource::Statement::Unsupported(format!("{other:?}")),
            };
            statements.push(value);
        }
        let terminator = block.terminator();
        let end = match &terminator.kind {
            TerminatorKind::Call { func, args, destination, target, unwind: action, .. } => match api(tcx, did, func, body) {
                Ok(api) => resource::End::Call {
                    api, arguments: args.iter().map(|argument| operand(&argument.node, body, tcx)).collect(),
                    destination: place(*destination, body, tcx), normal: target.map(|block| block.as_usize()), unwind: unwind(*action),
                },
                Err(error) => { unsupported.push(error.clone()); resource::End::Unsupported(error) }
            },
            TerminatorKind::Drop { place: value, target, unwind: action, .. } => resource::End::Drop {
                place: place(*value, body, tcx), normal: target.as_usize(), unwind: unwind(*action),
            },
            TerminatorKind::Goto { target } => resource::End::Goto(target.as_usize()),
            TerminatorKind::FalseEdge { real_target, imaginary_target } => resource::End::FalseEdge {
                real: real_target.as_usize(), imaginary: imaginary_target.as_usize(),
            },
            TerminatorKind::SwitchInt { discr, targets } => resource::End::Switch {
                operand: operand(discr, body, tcx), targets: targets.all_targets().iter().map(|target| target.as_usize()).collect(),
            },
            TerminatorKind::Return => resource::End::Return,
            TerminatorKind::UnwindResume => resource::End::Resume,
            TerminatorKind::UnwindTerminate(reason) => resource::End::Terminate(format!("{reason:?}")),
            TerminatorKind::Unreachable => resource::End::Unreachable,
            other => { unsupported.push(format!("bb{}: {other:?}", block_index.as_usize())); resource::End::Unsupported(format!("{other:?}")) }
        };
        blocks.push(resource::Block { cleanup: block.is_cleanup,
            original_statements: block.statements.iter().map(|statement| format!("{:?}", statement.kind)).collect(),
            original_terminator: format!("{:?}", terminator.kind), statements, end,
            compiler_successors: terminator.successors().map(|target| target.as_usize()).collect() });
    }
    Ok(resource::Body {
        definition: tcx.def_path_str(did), definition_hash: format!("{:?}", tcx.def_path_hash(did.to_def_id())),
        nominal_self: format!("{typ}"), nominal_self_hash: format!("{:?}", tcx.def_path_hash(adt.did())),
        source_file: canonical.display().to_string(),
        source_sha256: hash(&std::fs::read(canonical).map_err(|error| error.to_string())?),
        source_body: source_map.span_to_snippet(tcx.hir_span_with_body(tcx.local_def_id_to_hir_id(did))).map_err(|error| format!("source body: {error:?}"))?,
        mir_phase: format!("{:?}; exact BodyWithBorrowckFacts, not source scopes", body.phase),
        method: tcx.item_name(did.to_def_id()).to_string(), data_field,
        fields: adt.non_enum_variant().fields.iter().map(|field| (field.name.to_string(), format!("{}", field.ty(tcx, args).skip_norm_wip()))).collect(),
        destructor_hash: adt.destructor(tcx).map(|destructor| format!("{:?}", tcx.def_path_hash(destructor.did))),
        return_type: format!("{}", body.return_ty()), locals: body.local_decls.iter().map(|local| format!("{}", local.ty)).collect(),
        loans, blocks, unsupported,
    })
}

fn capture(tcx: TyCtxt<'_>, did: LocalDefId) {
    let facts = consumers::get_bodies_with_borrowck_facts(tcx, did, ConsumerOptions::PoloniusInputFacts);
    if let Some(facts) = facts.get(&did) {
        let result = produce(tcx, did, facts);
        CAPTURES.with(|captures| { captures.borrow_mut().insert(tcx.def_path_str(did), result); });
    }
}

struct Callbacks {
    output: String,
}

impl rustc_driver::Callbacks for Callbacks {
    fn config(&mut self, config: &mut rustc_interface::interface::Config) {
        config.override_queries = Some(|_, providers| {
            providers.queries.mir_borrowck = |tcx, did| {
                if selected(tcx, did) { capture(tcx, did); }
                (rustc_interface::DEFAULT_QUERY_PROVIDERS.queries.mir_borrowck)(tcx, did)
            };
        });
    }

    fn after_analysis<'tcx>(&mut self, compiler: &rustc_interface::interface::Compiler, tcx: TyCtxt<'tcx>) -> rustc_driver::Compilation {
        let mut selected_count = 0;
        for did in tcx.hir_body_owners() {
            if selected(tcx, did) {
                selected_count += 1;
                tcx.ensure_done().mir_borrowck(did);
            }
        }
        let results = CAPTURES.with(|captures| {
            captures.borrow().iter().map(|(definition, value)| match value {
                Ok(body) => {
                    let derivation = resource::derive(body);
                    let lowering = resource::lower_to_affine(body).err().unwrap_or_else(|| "BUG: OPEN graph admitted".into());
                    let negatives = if matches!(body.method.as_str(), "mem" | "mem_mut") { Some(resource::semantic_negatives(body)) } else { None };
                    json!({"definition": definition, "body": body, "derivation": derivation, "lowering_refusal": lowering, "semantic_negatives": negatives})
                }
                Err(error) => json!({"definition": definition, "producer_error": error}),
            }).collect::<Vec<_>>()
        });
        let bodies = CAPTURES.with(|captures| captures.borrow().values().filter_map(|value| value.as_ref().ok().cloned()).collect::<Vec<_>>());
        let header_consumer = resource::consume_original_header(&bodies);
        let header_negatives = resource::header_semantic_negatives(&bodies);
        let result = json!({"schema": "implementation140-open-original-body-v1", "selected_original_bodies": selected_count,
            "native_bodies_proved": 0, "primitive_laws_adopted": 0, "native_certificate": false,
            "body_results": results, "header_resource_consumer": header_consumer,
            "header_semantic_negatives": header_negatives,
            "status": "OPEN; compiler and internal resource checks are not native proof"});
        std::fs::write(&self.output, serde_json::to_vec_pretty(&result).unwrap()).unwrap();
        compiler.sess.dcx().err("NRE140_OPEN_NATIVE_OBLIGATIONS: original-body producer ran, no primitive law/caller-resource/VIR occurrence proof; native admission and export refused");
        rustc_driver::Compilation::Stop
    }
}

pub fn main() -> std::process::ExitCode {
    let mut arguments: Vec<String> = std::env::args().collect();
    if arguments.len() < 3 || arguments[1] != "--open-obligations-output" {
        eprintln!("internal default-off obligations producer only; expected --open-obligations-output PATH, followed by pinned rustc arguments; no certificate/export mode");
        std::process::exit(2);
    }
    let output = arguments.remove(2);
    arguments.remove(1);
    if arguments.iter().any(|argument| argument == "--export" || argument.starts_with("--export=")) {
        eprintln!("NRE140_EXPORT_REFUSED: open native obligations cannot be exported");
        std::process::exit(2);
    }
    let mut callbacks = Callbacks { output };
    rustc_driver::catch_with_exit_code(|| rustc_driver::run_compiler(&arguments, &mut callbacks))
}
