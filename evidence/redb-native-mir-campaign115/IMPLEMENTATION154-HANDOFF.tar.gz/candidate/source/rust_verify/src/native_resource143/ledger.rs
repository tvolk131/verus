use super::{operand_place, resolve};
use rustc_borrowck::consumers::{self, BodyWithBorrowckFacts, BorrowIndex, TwoPhaseActivation};
use rustc_hir::def_id::LocalDefId;
use rustc_middle::mir::visit::Visitor;
use rustc_middle::mir::{self, Operand, Place, Rvalue, StatementKind, TerminatorKind};
use rustc_middle::ty::{self, TyCtxt};
use std::collections::{HashMap, HashSet, VecDeque};

#[derive(Clone, Debug, PartialEq, Eq)]
pub(super) enum Effect {
    UnchangedByThisLoan,
    NormalCopy(mir::Location),
    UnwindPrefix(mir::Location),
}

#[derive(Clone, Debug)]
pub(super) enum Requirement<'tcx> {
    OriginalCall {
        at: mir::Location,
        instance: ty::Instance<'tcx>,
        arguments: Vec<Operand<'tcx>>,
        destination: Place<'tcx>,
    },
    IncomingCheckout {
        at: mir::Location,
        page: Place<'tcx>,
        receiver_loan: BorrowIndex,
        returned_slice: Place<'tcx>,
    },
    ByteMutation {
        at: mir::Location,
        returned_from: mir::Location,
        loan: BorrowIndex,
        source: Operand<'tcx>,
        effect: Effect,
    },
    LoanEndWriteback {
        at: mir::Location,
        loan: BorrowIndex,
        receiver: Place<'tcx>,
        returned: Place<'tcx>,
        effect: Effect,
        cleanup: bool,
    },
    CacheReservation {
        at: mir::Location,
        receiver: Place<'tcx>,
        instance: ty::Instance<'tcx>,
        replacing: bool,
        slot: Option<CacheSlot<'tcx>>,
        value: Option<Operand<'tcx>>,
    },
    OptionSomeProjection {
        at: mir::Location,
        source: Place<'tcx>,
        option: Place<'tcx>,
    },
    ExitFrame {
        at: mir::Location,
        pending_values: Vec<Place<'tcx>>,
        pending_reservations: Vec<CacheSlot<'tcx>>,
        outstanding_loans: Vec<BorrowIndex>,
    },
    ArcGetMutOutcomes {
        at: mir::Location,
        receiver_loan: BorrowIndex,
        arc: Place<'tcx>,
        returned_option: Place<'tcx>,
    },
    UnwrapOutcomes {
        at: mir::Location,
        from: mir::Location,
        option: Place<'tcx>,
        returned_slice: Place<'tcx>,
    },
    ReturnedLoanTransfer {
        at: mir::Location,
        from: mir::Location,
        parent: BorrowIndex,
        receiver: Place<'tcx>,
        returned: Place<'tcx>,
        root: Place<'tcx>,
        chain: Vec<BorrowIndex>,
    },
    AssertSemantics {
        at: mir::Location,
    },
    Unsupported {
        at: mir::Location,
    },
}

impl Requirement<'_> {
    pub(super) fn at(&self) -> mir::Location {
        match self {
            Self::OriginalCall { at, .. }
            | Self::IncomingCheckout { at, .. }
            | Self::ByteMutation { at, .. }
            | Self::LoanEndWriteback { at, .. }
            | Self::CacheReservation { at, .. }
            | Self::ArcGetMutOutcomes { at, .. }
            | Self::UnwrapOutcomes { at, .. }
            | Self::ReturnedLoanTransfer { at, .. }
            | Self::OptionSomeProjection { at, .. }
            | Self::ExitFrame { at, .. }
            | Self::AssertSemantics { at }
            | Self::Unsupported { at } => *at,
        }
    }
}

impl<'tcx> Requirement<'tcx> {
    pub(super) fn validate(
        &self,
        tcx: TyCtxt<'tcx>,
        owner: LocalDefId,
        facts: &BodyWithBorrowckFacts<'tcx>,
    ) -> Result<(), String> {
        let at = self.at();
        let body = &facts.body;
        let data = &body.basic_blocks[at.block];
        match self {
            Self::OriginalCall {
                instance,
                arguments,
                destination,
                ..
            } => {
                let TerminatorKind::Call {
                    func,
                    args,
                    destination: actual,
                    ..
                } = &data.terminator().kind
                else {
                    return Err("NRE143_OBLIGATION_NOT_ORIGINAL_CALL".into());
                };
                if at.statement_index != data.statements.len()
                    || *instance != resolve(tcx, owner, func.ty(&body.local_decls, tcx))?
                    || destination != actual
                    || arguments.len() != args.len()
                    || arguments
                        .iter()
                        .zip(args.iter())
                        .any(|(left, right)| left != &right.node)
                {
                    return Err("NRE143_OBLIGATION_CALL_CHANGED".into());
                }
            }
            Self::IncomingCheckout {
                page,
                receiver_loan,
                returned_slice,
                ..
            } => {
                let TerminatorKind::Call {
                    args, destination, ..
                } = &data.terminator().kind
                else {
                    return Err("NRE143_CHECKOUT_NOT_CALL".into());
                };
                let loan = &facts.borrow_set[*receiver_loan];
                if destination != returned_slice
                    || loan.borrowed_place() != *page
                    || args
                        .first()
                        .and_then(|argument| operand_place(&argument.node))
                        != Some(loan.assigned_place())
                    || loan.activation_location() != TwoPhaseActivation::ActivatedAt(at)
                {
                    return Err("NRE143_CHECKOUT_EXACT_RETURNED_LOAN".into());
                }
            }
            Self::ByteMutation {
                returned_from,
                loan,
                source,
                effect,
                ..
            } => {
                let TerminatorKind::Call { args, .. } = &data.terminator().kind else {
                    return Err("NRE143_MUTATION_NOT_CALL".into());
                };
                if args.len() != 2
                    || &args[1].node != source
                    || operand_place(&args[0].node)
                        != Some(facts.borrow_set[*loan].assigned_place())
                    || facts.borrow_set[*loan].activation_location()
                        != TwoPhaseActivation::ActivatedAt(at)
                    || !matches!(
                        body.basic_blocks[returned_from.block].terminator().kind,
                        TerminatorKind::Call { .. }
                    )
                    || !matches!(effect, Effect::NormalCopy(event) | Effect::UnwindPrefix(event) if *event == at)
                {
                    return Err("NRE143_MUTATION_EXACT_ORIGIN_AND_ACTIVATION".into());
                }
            }
            Self::LoanEndWriteback {
                loan,
                receiver,
                returned,
                effect,
                cleanup,
                ..
            } => {
                let ends = consumers::calculate_borrows_out_of_scope_at_location(
                    body,
                    &facts.region_inference_context,
                    &facts.borrow_set,
                );
                if !ends.get(&at).is_some_and(|ending| ending.contains(loan))
                    || facts.borrow_set[*loan].borrowed_place() != *receiver
                    || facts.borrow_set[*loan].assigned_place() != *returned
                    || data.is_cleanup != *cleanup
                {
                    return Err("NRE143_WRITEBACK_EXACT_ENDPOINT_RECEIVER".into());
                }
                if let Effect::NormalCopy(event) | Effect::UnwindPrefix(event) = effect {
                    let TerminatorKind::Call { func, .. } =
                        &body.basic_blocks[event.block].terminator().kind
                    else {
                        return Err("NRE143_WRITEBACK_HAS_NO_MUTATION_EVENT".into());
                    };
                    let instance = resolve(tcx, owner, func.ty(&body.local_decls, tcx))?;
                    if tcx.item_name(instance.def_id()).as_str() != "copy_from_slice"
                        || tcx.crate_name(instance.def_id().krate).as_str() != "core"
                    {
                        return Err("NRE143_WRITEBACK_HAS_NO_NATIVE_COPY_EVENT".into());
                    }
                }
            }
            Self::CacheReservation {
                receiver,
                instance,
                replacing,
                slot,
                value,
                ..
            } => {
                let TerminatorKind::Call { func, args, .. } = &data.terminator().kind else {
                    return Err("NRE143_RESERVATION_NOT_CALL".into());
                };
                if *instance != resolve(tcx, owner, func.ty(&body.local_decls, tcx))?
                    || operand_place(&args[0].node) != Some(*receiver)
                    || (tcx.item_name(instance.def_id()).as_str() == "replace") != *replacing
                {
                    return Err("NRE143_RESERVATION_EXACT_NATIVE_MUTATION".into());
                }
                if *replacing && value.as_ref() != args.get(1).map(|argument| &argument.node) {
                    return Err("NRE143_CACHE_RETURN_EXACT_VALUE".into());
                }
                if let Some(slot) = slot {
                    let TerminatorKind::Call { args, .. } =
                        &body.basic_blocks[slot.getter.block].terminator().kind
                    else {
                        return Err("NRE143_CACHE_SLOT_GETTER_NOT_CALL".into());
                    };
                    if operand_place(&args[0].node) != Some(slot.cache)
                        || args.get(1).map(|argument| &argument.node) != Some(&slot.key)
                    {
                        return Err("NRE143_CACHE_SLOT_KEY_OR_RECEIVER_CHANGED".into());
                    }
                }
            }
            Self::OptionSomeProjection { source, option, .. } => {
                if !some_projection(tcx, body, *option, *source) {
                    return Err("NRE143_EXACT_OPTION_SOME_PROJECTION".into());
                }
            }
            Self::ExitFrame {
                pending_values,
                pending_reservations,
                outstanding_loans,
                ..
            } => {
                for place in pending_values {
                    let _ = place.ty(&body.local_decls, tcx);
                }
                for slot in pending_reservations {
                    let _ = slot.cache.ty(&body.local_decls, tcx);
                }
                for loan in outstanding_loans {
                    let _ = facts.borrow_set[*loan].region();
                }
                return Err(
                    "NRE143_EXIT_PENDING_RESOURCE_FRAME_OPEN_NOT_EMPTY_AFFINE_OWNERSHIP".into(),
                );
            }
            Self::ArcGetMutOutcomes {
                receiver_loan,
                arc,
                returned_option,
                ..
            } => {
                let TerminatorKind::Call {
                    args, destination, ..
                } = &data.terminator().kind
                else {
                    return Err("NRE143_GET_MUT_NOT_CALL".into());
                };
                let loan = &facts.borrow_set[*receiver_loan];
                if destination != returned_option
                    || operand_place(&args[0].node) != Some(loan.assigned_place())
                    || loan.borrowed_place() != *arc
                    || loan.activation_location() != TwoPhaseActivation::ActivatedAt(at)
                {
                    return Err("NRE143_ARC_RETURNED_LOAN_BINDING".into());
                }
            }
            Self::UnwrapOutcomes {
                from,
                option,
                returned_slice,
                ..
            } => {
                let TerminatorKind::Call {
                    args, destination, ..
                } = &data.terminator().kind
                else {
                    return Err("NRE143_UNWRAP_NOT_CALL".into());
                };
                let TerminatorKind::Call {
                    destination: producer,
                    ..
                } = &body.basic_blocks[from.block].terminator().kind
                else {
                    return Err("NRE143_UNWRAP_WITHOUT_GET_MUT".into());
                };
                if operand_place(&args[0].node) != Some(*option)
                    || option != producer
                    || returned_slice != destination
                {
                    return Err("NRE143_UNWRAP_EXACT_OPTION".into());
                }
            }
            Self::ReturnedLoanTransfer {
                from,
                parent,
                receiver,
                returned,
                root,
                chain,
                ..
            } => {
                if *returned != Place::from(mir::RETURN_PLACE)
                    || !matches!(data.terminator().kind, TerminatorKind::Return)
                    || facts.borrow_set[*parent].borrowed_place() != *receiver
                    || !matches!(
                        body.basic_blocks[from.block].terminator().kind,
                        TerminatorKind::Call { .. }
                    )
                {
                    return Err("NRE143_RETURNED_LOAN_TRANSFER_BINDING".into());
                }
                let mut current = *receiver;
                for index in chain {
                    let ancestor = &facts.borrow_set[*index];
                    if current
                        != ancestor
                            .assigned_place()
                            .project_deeper(&[mir::ProjectionElem::Deref], tcx)
                        || !facts
                            .region_inference_context
                            .eval_outlives(ancestor.region(), facts.borrow_set[*parent].region())
                    {
                        return Err("NRE143_RETURNED_LOAN_ROOT_CHAIN".into());
                    }
                    current = ancestor.borrowed_place();
                }
                if current != *root {
                    return Err("NRE143_RETURNED_LOAN_ROOT_PLACE".into());
                }
            }
            Self::AssertSemantics { .. } => return Err("NRE143_ASSERT_SEMANTICS_OPEN".into()),
            Self::Unsupported { .. } => return Err("NRE143_ORIGINAL_EFFECT_SEMANTICS_OPEN".into()),
        }
        Ok(())
    }
}

#[derive(Clone, PartialEq, Eq)]
enum OriginKind {
    NativeMethod,
    ArcOption,
    ArcSlice,
}

#[derive(Clone, PartialEq, Eq)]
struct Returned<'tcx> {
    from: mir::Location,
    parent: BorrowIndex,
    page: Place<'tcx>,
    slice: Place<'tcx>,
    kind: OriginKind,
    root: Place<'tcx>,
    chain: Vec<BorrowIndex>,
}

#[derive(Clone, PartialEq, Eq)]
struct Loan<'tcx> {
    receiver: Place<'tcx>,
    returned: Place<'tcx>,
    receiver_root: Place<'tcx>,
    receiver_chain: Vec<BorrowIndex>,
    active: bool,
    native: Option<Returned<'tcx>>,
    effect: Effect,
}

#[derive(Clone, Debug, PartialEq)]
pub(super) struct CacheSlot<'tcx> {
    getter: mir::Location,
    cache: Place<'tcx>,
    key: Operand<'tcx>,
    optional: bool,
}

fn some_projection<'tcx>(
    tcx: TyCtxt<'tcx>,
    body: &mir::Body<'tcx>,
    option: Place<'tcx>,
    source: Place<'tcx>,
) -> bool {
    let ty::Adt(adt, arguments) = option.ty(&body.local_decls, tcx).ty.kind() else {
        return false;
    };
    if tcx.lang_items().option_type() != Some(adt.did()) {
        return false;
    }
    if source.local != option.local || !source.projection.starts_with(option.projection) {
        return false;
    }
    let [mir::ProjectionElem::Downcast(_, actual_variant), mir::ProjectionElem::Field(actual_field, actual_type)] =
        &source.projection[option.projection.len()..] else { return false; };
    adt.variants()
        .iter_enumerated()
        .any(|(variant_index, variant)| {
            if variant.name.as_str() != "Some" || variant.fields.len() != 1 {
                return false;
            }
            let (field, definition) = variant.fields.iter_enumerated().next().unwrap();
            *actual_variant == variant_index && *actual_field == field
                && tcx.erase_and_anonymize_regions(*actual_type)
                    == tcx.erase_and_anonymize_regions(definition.ty(tcx, arguments).skip_norm_wip())
        })
}

#[derive(Clone, Default)]
struct State<'tcx> {
    values: HashMap<Place<'tcx>, Returned<'tcx>>,
    loans: HashMap<BorrowIndex, Loan<'tcx>>,
    holders: HashMap<Place<'tcx>, BorrowIndex>,
    slots: HashMap<Place<'tcx>, CacheSlot<'tcx>>,
    reservations: Vec<CacheSlot<'tcx>>,
}

fn overlaps<'tcx>(left: Place<'tcx>, right: Place<'tcx>) -> bool {
    if left.local != right.local {
        return false;
    }
    for (left, right) in left.projection.iter().zip(right.projection.iter()) {
        if left != right {
            return !matches!((left, right), (mir::ProjectionElem::Field(left, _), mir::ProjectionElem::Field(right, _)) if left != right);
        }
    }
    true
}

impl<'tcx> State<'tcx> {
    fn root(
        &self,
        tcx: TyCtxt<'tcx>,
        place: Place<'tcx>,
    ) -> Result<(Place<'tcx>, Vec<BorrowIndex>), String> {
        let ancestors = self
            .holders
            .iter()
            .filter(|(holder, _)| {
                holder.project_deeper(&[mir::ProjectionElem::Deref], tcx) == place
            })
            .collect::<Vec<_>>();
        if ancestors.is_empty() {
            return Ok((place, Vec::new()));
        }
        if ancestors.len() != 1 {
            return Err("NRE143_AMBIGUOUS_RECEIVER_ROOT".into());
        }
        let index = *ancestors[0].1;
        let loan = self.loans.get(&index).ok_or("NRE148_HOLDER_WITHOUT_LOAN")?;
        let mut chain = vec![index];
        for ancestor in &loan.receiver_chain {
            if chain.contains(ancestor) || !self.loans.contains_key(ancestor) {
                return Err("NRE148_STALE_OR_CYCLIC_RECEIVER_CHAIN".into());
            }
            chain.push(*ancestor);
        }
        Ok((loan.receiver_root, chain))
    }
    fn kill(&mut self, destination: Place<'tcx>) {
        self.values
            .retain(|place, _| !overlaps(*place, destination));
        self.slots.retain(|place, _| !overlaps(*place, destination));
        self.holders.retain(|place, _| !overlaps(*place, destination));
    }

    fn consume(&mut self, operand: &Operand<'tcx>) {
        if let Operand::Move(place) = operand {
            self.kill(*place);
        }
    }

    fn read(&self, source: Place<'tcx>) -> Option<Returned<'tcx>> {
        self.values.get(&source).cloned()
    }

    fn slot(&self, source: Place<'tcx>) -> Option<CacheSlot<'tcx>> {
        self.slots.get(&source).cloned()
    }

    fn exit_frame(&self, at: mir::Location) -> Requirement<'tcx> {
        let mut pending_values = self.values.keys().copied().collect::<Vec<_>>();
        pending_values.sort_by_cached_key(|place| format!("{place:?}"));
        let mut outstanding_loans = self.loans.keys().copied().collect::<Vec<_>>();
        outstanding_loans.sort_by_key(|loan| loan.as_usize());
        Requirement::ExitFrame {
            at,
            pending_values,
            pending_reservations: self.reservations.clone(),
            outstanding_loans,
        }
    }

    fn transfer(&mut self, destination: Place<'tcx>, operand: &Operand<'tcx>) {
        let value = operand_place(operand).and_then(|source| self.read(source));
        let slot = operand_place(operand).and_then(|source| self.slot(source));
        let holder = operand_place(operand)
            .and_then(|source| self.holders.get(&source).copied());
        self.consume(operand);
        self.kill(destination);
        if let Some(value) = value {
            self.values.insert(destination, value);
        }
        if let Some(slot) = slot {
            self.slots.insert(destination, slot);
        }
        if let Some(index) = holder {
            self.holders.insert(destination, index);
        }
    }
}

struct Moves<'tcx> {
    places: Vec<Place<'tcx>>,
}

impl<'tcx> Visitor<'tcx> for Moves<'tcx> {
    fn visit_operand(&mut self, operand: &Operand<'tcx>, _at: mir::Location) {
        if let Operand::Move(place) = operand {
            self.places.push(*place);
        }
    }
}

pub(super) struct Lowering<'tcx> {
    pub requirements: Vec<Requirement<'tcx>>,
    pub exact_copy_paths: usize,
    pub returned_loans: usize,
    pub visited_occurrences: usize,
}

fn classify<'tcx>(
    tcx: TyCtxt<'tcx>,
    instance: ty::Instance<'tcx>,
    method: &str,
    receiver: &str,
) -> bool {
    if tcx.item_name(instance.def_id()).as_str() != method {
        return false;
    }
    let signature = tcx
        .fn_sig(instance.def_id())
        .instantiate(tcx, instance.args)
        .skip_binder();
    let Some(input) = signature.inputs().first() else {
        return false;
    };
    match input.peel_refs().kind() {
        ty::Adt(adt, _) => adt.did().is_local() && tcx.item_name(adt.did()).as_str() == receiver,
        _ => false,
    }
}

fn apply_ends<'tcx>(
    facts: &BodyWithBorrowckFacts<'tcx>,
    at: mir::Location,
    state: &mut State<'tcx>,
    requirements: &mut Vec<Requirement<'tcx>>,
) {
    let ends = consumers::calculate_borrows_out_of_scope_at_location(
        &facts.body,
        &facts.region_inference_context,
        &facts.borrow_set,
    );
    let Some(ending) = ends.get(&at) else {
        return;
    };
    let mut ordered = ending.iter().copied().collect::<Vec<_>>();
    ordered.sort_by_key(|index| {
        state.loans.get(index).is_some_and(|loan| {
            loan.native
                .as_ref()
                .is_some_and(|native| native.parent == *index)
        })
    });
    for index in ordered {
        if let Some(loan) = state.loans.remove(&index) {
            requirements.push(Requirement::LoanEndWriteback {
                at,
                loan: index,
                receiver: loan.receiver,
                returned: loan.returned,
                effect: loan.effect.clone(),
                cleanup: facts.body.basic_blocks[at.block].is_cleanup,
            });
            if let Some(native) = &loan.native {
                if let Some(parent) = state.loans.get_mut(&native.parent) {
                    if !matches!(loan.effect, Effect::UnchangedByThisLoan) {
                        parent.effect = loan.effect;
                    }
                }
            }
            let holders = state.holders.iter()
                .filter_map(|(holder, mapped)| (*mapped == index).then_some(*holder))
                .collect::<HashSet<_>>();
            state.holders.retain(|_, mapped| *mapped != index);
            state.values.retain(|holder, origin| {
                origin.parent != index && !holders.contains(holder)
            });
            state.slots.retain(|holder, _| !holders.contains(holder));
        }
    }
}

pub(super) fn lower<'tcx>(
    tcx: TyCtxt<'tcx>,
    owner: LocalDefId,
    facts: &BodyWithBorrowckFacts<'tcx>,
) -> Result<Lowering<'tcx>, String> {
    lower_with_challenge(tcx, owner, facts, Challenge::None)
}

#[derive(Clone, Copy, PartialEq, Eq)]
pub(super) enum Challenge {
    None,
    LostReturnedOrigin,
    MissingTerminatorEnds,
    WrongProjection,
    StaleWriteback,
}

pub(super) fn lower_with_challenge<'tcx>(
    tcx: TyCtxt<'tcx>,
    owner: LocalDefId,
    facts: &BodyWithBorrowckFacts<'tcx>,
    challenge: Challenge,
) -> Result<Lowering<'tcx>, String> {
    let body = &facts.body;
    let mut queue = VecDeque::from([(mir::START_BLOCK, State::default(), HashSet::new())]);
    let mut requirements = Vec::new();
    let mut visited_occurrences = 0;
    let mut exact_copy_paths = 0;
    let mut returned_loans = 0;
    let mut explored_paths = 0;
    while let Some((block, mut state, mut ancestors)) = queue.pop_front() {
        explored_paths += 1;
        if explored_paths > 2048 || !ancestors.insert(block) {
            return Err("NRE143_LOOP_RESOURCE_INVARIANT_OPEN".into());
        }
        let data = &body.basic_blocks[block];
        for statement_index in 0..=data.statements.len() {
            let at = mir::Location {
                block,
                statement_index,
            };
            if challenge != Challenge::MissingTerminatorEnds
                || statement_index != data.statements.len()
            {
                apply_ends(facts, at, &mut state, &mut requirements);
            }
            visited_occurrences += 1;
            if statement_index == data.statements.len() {
                break;
            }
            match &data.statements[statement_index].kind {
                StatementKind::Assign(assignment) => {
                    let (destination, value) = &**assignment;
                    match value {
                        Rvalue::Use(operand, _) => {
                            let projected = operand_place(operand).and_then(|source| {
                                state.slots.iter().find_map(|(option, slot)| {
                                    (slot.optional && some_projection(tcx, body, *option, source))
                                        .then(|| (*option, source, slot.clone()))
                                })
                            });
                            state.transfer(*destination, operand);
                            if let Some((option, source, mut slot)) = projected {
                                slot.optional = false;
                                state.slots.insert(*destination, slot);
                                requirements.push(Requirement::OptionSomeProjection {
                                    at,
                                    source,
                                    option,
                                });
                            }
                        }
                        Rvalue::Ref(_, _, source) => {
                            let native = state.read(*source).or_else(|| {
                                state.values.iter().find_map(|(place, native)| {
                                    (place.project_deeper(&[mir::ProjectionElem::Deref], tcx)
                                        == *source)
                                        .then(|| native.clone())
                                })
                            });
                            let projected = state.slots.iter().find_map(|(option, slot)| {
                                (slot.optional && some_projection(tcx, body, *option, *source))
                                    .then(|| (*option, slot.clone()))
                            });
                            let slot = state.slot(*source).or_else(|| {
                                state.slots.iter().find_map(|(place, slot)| {
                                    (!slot.optional
                                        && place.project_deeper(&[mir::ProjectionElem::Deref], tcx)
                                            == *source)
                                        .then(|| slot.clone())
                                })
                            });
                            let slot = slot.or_else(|| {
                                projected.as_ref().map(|(_, slot)| {
                                    let mut slot = slot.clone();
                                    slot.optional = false;
                                    slot
                                })
                            });
                            let (receiver_root, receiver_chain) = state.root(tcx, *source)?;
                            state.kill(*destination);
                            let candidates = facts
                                .borrow_set
                                .iter_enumerated()
                                .filter(|(_, loan)| {
                                    loan.reserve_location() == at
                                        && loan.assigned_place() == *destination
                                        && loan.borrowed_place() == *source
                                })
                                .collect::<Vec<_>>();
                            if candidates.len() == 1 {
                                let (index, loan) = candidates[0];
                                if state
                                    .loans
                                    .insert(
                                        index,
                                        Loan {
                                            receiver: *source,
                                            returned: *destination,
                                            receiver_root,
                                            receiver_chain,
                                            active: loan.activation_location()
                                                == TwoPhaseActivation::NotTwoPhase,
                                            native: native.clone(),
                                            effect: Effect::UnchangedByThisLoan,
                                        },
                                    )
                                    .is_some()
                                {
                                    return Err("NRE143_REISSUED_LOAN_WITHOUT_RETURN".into());
                                }
                                state.holders.insert(*destination, index);
                            }
                            if let Some(native) = native {
                                state.values.insert(*destination, native);
                            }
                            if let Some(slot) = slot {
                                state.slots.insert(*destination, slot);
                            }
                            if let Some((option, _)) = projected {
                                requirements.push(Requirement::OptionSomeProjection {
                                    at,
                                    source: *source,
                                    option,
                                });
                            }
                        }
                        _ => {
                            let mut moved = Moves { places: Vec::new() };
                            moved.visit_rvalue(value, at);
                            for source in moved.places {
                                state.kill(source);
                            }
                            state.kill(*destination);
                            requirements.push(Requirement::Unsupported { at });
                        }
                    }
                }
                StatementKind::StorageDead(local) => state.kill(Place::from(*local)),
                StatementKind::StorageLive(local) => state.kill(Place::from(*local)),
                StatementKind::Nop | StatementKind::FakeRead(_) | StatementKind::PlaceMention(_) => {}
                other => {
                    let mut moved = Moves { places: Vec::new() };
                    moved.visit_statement(&data.statements[statement_index], at);
                    for source in moved.places {
                        state.kill(source);
                    }
                    state.values.clear();
                    state.slots.clear();
                    state.holders.clear();
                    let _ = other;
                    requirements.push(Requirement::Unsupported { at });
                }
            }
        }
        let at = mir::Location {
            block,
            statement_index: data.statements.len(),
        };
        for index in facts.borrow_set.activations_at_location(&at) {
            let loan = state
                .loans
                .get_mut(index)
                .ok_or("NRE143_ACTIVATION_WITHOUT_RESERVATION")?;
            if loan.active {
                return Err("NRE143_DUPLICATE_ACTIVATION".into());
            }
            loan.active = true;
        }
        match &data.terminator().kind {
            TerminatorKind::Call {
                func,
                args,
                destination,
                target,
                unwind,
                ..
            } => {
                let instance = resolve(tcx, owner, func.ty(&body.local_decls, tcx))?;
                requirements.push(Requirement::OriginalCall {
                    at,
                    instance,
                    arguments: args.iter().map(|argument| argument.node.clone()).collect(),
                    destination: *destination,
                });
                let receiver = args
                    .first()
                    .and_then(|argument| operand_place(&argument.node));
                let native = receiver.and_then(|receiver| state.read(receiver));
                let slot = receiver.and_then(|receiver| state.slot(receiver));
                let mut normal = state.clone();
                let mut cleanup = state.clone();
                for argument in args.iter() {
                    normal.consume(&argument.node);
                    cleanup.consume(&argument.node);
                }
                normal.consume(func);
                cleanup.consume(func);
                normal.kill(*destination);
                cleanup.kill(*destination);
                if classify(tcx, instance, "mem_mut", "WritablePage") {
                    let receiver = receiver.ok_or("NRE143_MEM_MUT_RECEIVER_NOT_PLACE")?;
                    let matching = state
                        .loans
                        .iter()
                        .filter(|(index, loan)| {
                            state.holders.get(&receiver) == Some(*index) && loan.active
                        })
                        .collect::<Vec<_>>();
                    if matching.len() != 1 {
                        return Err("NRE143_MEM_MUT_RECEIVER_LOAN_OPEN".into());
                    }
                    let (index, loan) = matching[0];
                    let (root, chain) = (loan.receiver_root, loan.receiver_chain.clone());
                    let native = Returned {
                        from: at,
                        parent: *index,
                        page: loan.receiver,
                        slice: *destination,
                        kind: OriginKind::NativeMethod,
                        root,
                        chain,
                    };
                    normal.values.insert(*destination, native.clone());
                    normal.loans.get_mut(index).unwrap().native = Some(native);
                    returned_loans += 1;
                    requirements.push(Requirement::IncomingCheckout {
                        at,
                        page: loan.receiver,
                        receiver_loan: *index,
                        returned_slice: *destination,
                    });
                    if challenge == Challenge::LostReturnedOrigin {
                        normal
                            .transfer(*destination, &Operand::Move(Place::from(mir::RETURN_PLACE)));
                    }
                }
                let signature = tcx
                    .fn_sig(instance.def_id())
                    .instantiate(tcx, instance.args)
                    .skip_binder();
                if classify(tcx, instance, "get_mut", "LRUCache") && args.len() == 2 {
                    normal.slots.insert(
                        *destination,
                        CacheSlot {
                            getter: at,
                            cache: receiver.ok_or("NRE143_CACHE_GET_MUT_RECEIVER")?,
                            key: args[1].node.clone(),
                            optional: true,
                        },
                    );
                }
                let is_arc = tcx.impl_of_assoc(instance.def_id()).is_some_and(|implementation| {
                    matches!(tcx.type_of(implementation).instantiate(tcx, instance.args).skip_norm_wip().kind(), ty::Adt(adt, arguments)
                        if tcx.is_diagnostic_item(rustc_span::Symbol::intern("Arc"), adt.did())
                            && matches!(arguments.type_at(0).kind(), ty::Slice(element) if *element == tcx.types.u8))
                });
                if is_arc && tcx.item_name(instance.def_id()).as_str() == "get_mut" {
                    let receiver = receiver.ok_or("NRE143_ARC_RECEIVER_NOT_PLACE")?;
                    let matching = state
                        .loans
                        .iter()
                        .filter(|(index, loan)| {
                            state.holders.get(&receiver) == Some(*index) && loan.active
                        })
                        .collect::<Vec<_>>();
                    if matching.len() != 1 {
                        return Err("NRE143_ARC_GET_MUT_HAS_NO_ACTIVE_RECEIVER_LOAN".into());
                    }
                    let (index, loan) = matching[0];
                    let (root, chain) = (loan.receiver_root, loan.receiver_chain.clone());
                    let pending = Returned {
                        from: at,
                        parent: *index,
                        page: loan.receiver,
                        slice: *destination,
                        kind: OriginKind::ArcOption,
                        root,
                        chain,
                    };
                    normal.values.insert(*destination, pending.clone());
                    normal.loans.get_mut(index).unwrap().native = Some(pending);
                    requirements.push(Requirement::ArcGetMutOutcomes {
                        at,
                        receiver_loan: *index,
                        arc: loan.receiver,
                        returned_option: *destination,
                    });
                }
                let is_option = tcx.impl_of_assoc(instance.def_id()).is_some_and(|implementation|
                    matches!(tcx.type_of(implementation).instantiate(tcx, instance.args).skip_norm_wip().kind(), ty::Adt(adt, _)
                        if tcx.lang_items().option_type() == Some(adt.did())));
                if is_option && tcx.item_name(instance.def_id()).as_str() == "unwrap" {
                    if let Some(mut slot) = slot.clone() {
                        slot.optional = false;
                        normal.slots.insert(*destination, slot);
                    }
                    if let Some(mut pending) = native
                        .clone()
                        .filter(|pending| pending.kind == OriginKind::ArcOption)
                    {
                        requirements.push(Requirement::UnwrapOutcomes {
                            at,
                            from: pending.from,
                            option: receiver.ok_or("NRE143_UNWRAP_OPTION_NOT_PLACE")?,
                            returned_slice: *destination,
                        });
                        pending.kind = OriginKind::ArcSlice;
                        pending.slice = *destination;
                        normal.values.insert(*destination, pending);
                    }
                }
                let copy = tcx.item_name(instance.def_id()).as_str() == "copy_from_slice"
                    && tcx.crate_name(instance.def_id().krate).as_str() == "core"
                    && matches!(signature.inputs().first().map(|typ| typ.kind()), Some(ty::Ref(_, inner, rustc_ast::Mutability::Mut))
                        if matches!(inner.kind(), ty::Slice(element) if *element == tcx.types.u8));
                if copy {
                    let native = native.ok_or("NRE143_COPY_HAS_NO_EXACT_RETURNED_LOAN_ORIGIN")?;
                    if !state.loans.get(&native.parent).is_some_and(|loan| loan.active) {
                        return Err("NRE143_COPY_RETURNED_ORIGIN_RECEIVER_EXPIRED".into());
                    }
                    let receiver = receiver.ok_or("NRE143_COPY_RECEIVER_NOT_PLACE")?;
                    let matching = state
                        .loans
                        .iter()
                        .filter(|(index, loan)| {
                            state.holders.get(&receiver) == Some(*index)
                                && loan.active
                                && loan.native.as_ref() == Some(&native)
                        })
                        .collect::<Vec<_>>();
                    if matching.len() != 1 {
                        return Err("NRE143_COPY_HAS_NO_ACTIVE_RETURNED_LOAN".into());
                    }
                    let (index, _) = matching[0];
                    let expected = if challenge == Challenge::WrongProjection {
                        native.slice
                    } else {
                        native
                            .slice
                            .project_deeper(&[mir::ProjectionElem::Deref], tcx)
                    };
                    if facts.borrow_set[*index].borrowed_place() != expected {
                        return Err("NRE143_COPY_EXACT_FULL_PROJECTED_RETURNED_PLACE".into());
                    }
                    if !facts.region_inference_context.eval_outlives(
                        facts.borrow_set[native.parent].region(),
                        facts.borrow_set[*index].region(),
                    ) {
                        return Err("NRE143_RETURNED_LOAN_OUTLIVES_RECEIVER".into());
                    }
                    normal.loans.get_mut(index).unwrap().effect = Effect::NormalCopy(at);
                    if challenge == Challenge::StaleWriteback {
                        normal.loans.get_mut(index).unwrap().effect =
                            Effect::NormalCopy(native.from);
                    }
                    cleanup.loans.get_mut(index).unwrap().effect = Effect::UnwindPrefix(at);
                    for effect in [Effect::NormalCopy(at), Effect::UnwindPrefix(at)] {
                        requirements.push(Requirement::ByteMutation {
                            at,
                            returned_from: native.from,
                            loan: *index,
                            source: args[1].node.clone(),
                            effect,
                        });
                    }
                    exact_copy_paths += 1;
                }
                if matches!(tcx.item_name(instance.def_id()).as_str(), "take" | "replace")
                    && tcx.lang_items().option_type().is_some_and(|option| tcx.impl_of_assoc(instance.def_id())
                        .is_some_and(|implementation| matches!(tcx.type_of(implementation).instantiate(tcx, instance.args).skip_norm_wip().kind(), ty::Adt(adt, _) if adt.did() == option))) {
                    requirements.push(Requirement::CacheReservation { at, receiver: receiver.ok_or("NRE143_CACHE_MUTATION_NOT_PLACE")?, instance,
                        replacing: tcx.item_name(instance.def_id()).as_str() == "replace", slot: slot.clone(), value: args.get(1).map(|argument| argument.node.clone()) });
                    if let Some(slot) = slot { normal.reservations.push(slot); }
                }
                if let Some(target) = target {
                    queue.push_back((*target, normal, ancestors.clone()));
                }
                if let mir::UnwindAction::Cleanup(target) = unwind {
                    queue.push_back((*target, cleanup, ancestors));
                }
            }
            TerminatorKind::Assert { .. } => {
                requirements.push(Requirement::AssertSemantics { at });
                return Err(format!(
                    "NRE143_ASSERT_SEMANTICS_OPEN {at:?}: normal/failure/unwind effects are not lowered"
                ));
            }
            TerminatorKind::Return => {
                requirements.push(state.exit_frame(at));
                if let Some(pending) = state.values.get(&Place::from(mir::RETURN_PLACE)) {
                    if pending.kind == OriginKind::ArcSlice {
                        requirements.push(Requirement::ReturnedLoanTransfer {
                            at,
                            from: pending.from,
                            parent: pending.parent,
                            receiver: pending.page,
                            returned: Place::from(mir::RETURN_PLACE),
                            root: pending.root,
                            chain: pending.chain.clone(),
                        });
                        returned_loans += 1;
                    }
                }
                if !state.loans.is_empty() {
                    requirements.push(Requirement::Unsupported { at });
                }
            }
            TerminatorKind::UnwindResume | TerminatorKind::UnwindTerminate(_) => {
                requirements.push(state.exit_frame(at));
                if !state.loans.is_empty() {
                    requirements.push(Requirement::Unsupported { at });
                }
            }
            TerminatorKind::Goto { target } => queue.push_back((*target, state, ancestors)),
            TerminatorKind::FalseEdge { real_target, .. } => {
                queue.push_back((*real_target, state, ancestors))
            }
            TerminatorKind::SwitchInt { discr, .. } => {
                state.consume(discr);
                for successor in data.terminator().successors() {
                    queue.push_back((successor, state.clone(), ancestors.clone()));
                }
            }
            TerminatorKind::Drop { place, .. } => {
                if state.loans.values().any(|loan| {
                    loan.native
                        .as_ref()
                        .is_some_and(|pending| overlaps(pending.root, *place))
                }) {
                    return Err(format!("NRE143_DROP_WITH_OUTSTANDING_RETURNED_LOAN {at:?}"));
                }
                state.kill(*place);
                requirements.push(Requirement::Unsupported { at });
                for successor in data.terminator().successors() {
                    queue.push_back((successor, state.clone(), ancestors.clone()));
                }
            }
            TerminatorKind::FalseUnwind { .. } => {
                for successor in data.terminator().successors() {
                    queue.push_back((successor, state.clone(), ancestors.clone()));
                }
            }
            TerminatorKind::Unreachable => {}
            _ => requirements.push(Requirement::Unsupported { at }),
        }
    }
    for requirement in &requirements {
        if !matches!(
            requirement,
            Requirement::Unsupported { .. }
                | Requirement::AssertSemantics { .. }
                | Requirement::ExitFrame { .. }
        ) {
            requirement.validate(tcx, owner, facts)?;
        }
    }
    Ok(Lowering {
        requirements,
        exact_copy_paths,
        returned_loans,
        visited_occurrences,
    })
}

#[cfg(test)]
mod repair148_tests {
    use super::*;

    fn tracked<'tcx>() -> (State<'tcx>, BorrowIndex, Place<'tcx>, Place<'tcx>) {
        let receiver = Place::from(mir::Local::from_usize(1));
        let holder = Place::from(mir::Local::from_usize(2));
        let saved = Place::from(mir::Local::from_usize(3));
        let index = BorrowIndex::from_usize(0);
        let mut state = State::default();
        state.loans.insert(index, Loan {
            receiver,
            returned: holder,
            receiver_root: receiver,
            receiver_chain: Vec::new(),
            active: true,
            native: None,
            effect: Effect::UnchangedByThisLoan,
        });
        state.holders.insert(holder, index);
        (state, index, holder, saved)
    }

    #[test]
    fn move_relocates_holder_without_retiring_loan() {
        let (mut state, index, holder, saved) = tracked();
        state.transfer(saved, &Operand::Move(holder));
        assert_eq!(state.holders.get(&holder), None);
        assert_eq!(state.holders.get(&saved), Some(&index));
        assert!(state.loans.contains_key(&index));
        assert_eq!(state.loans[&index].returned, holder);
    }

    #[test]
    fn overwrite_unknown_reference_does_not_reuse_holder() {
        let (mut state, index, holder, saved) = tracked();
        state.transfer(saved, &Operand::Move(holder));
        let incoming = Place::from(mir::Local::from_usize(4));
        state.transfer(holder, &Operand::Move(incoming));
        assert_eq!(state.holders.get(&holder), None);
        assert_eq!(state.holders.get(&saved), Some(&index));
        assert!(state.loans.contains_key(&index));
    }

    #[test]
    fn storage_kill_preserves_outstanding_loan() {
        let (mut state, index, holder, _) = tracked();
        state.kill(holder);
        assert!(state.holders.is_empty());
        assert!(state.loans.contains_key(&index));
    }

    #[test]
    fn self_move_preserves_exact_holder() {
        let (mut state, index, holder, _) = tracked();
        state.transfer(holder, &Operand::Move(holder));
        assert_eq!(state.holders.get(&holder), Some(&index));
        assert_eq!(state.loans.len(), 1);
    }
}
