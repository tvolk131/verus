/*!
This file contains the conversion HIR -> VIR.

To properly process the HIR tree, it's important to understand how Rust handles
"implicit" operations (like auto-borrows, auto-deref, implicit coercions).
All such operations are represented as "adjustments", which should be thought of
as nodes of the tree in their own right.

Example: consider a function which in source looks like `f(foo, bar)`.
Suppose that `foo` is a mutable reference which is implicitly reborrowed,
and `bar` implicitly gets a pointer cast, so that the actual function
call is more like `f(&mut *foo, bar as *const T)`.

The HIR tree initially looks like this:

```
          Call `f(foo, bar)`
         /        |        \
        /         |         \
    Path `f`   Path `foo`   Path `bar`
```

Rust performs type-checking on a tree that looks like this. However,
during type-checking, Rust computes the "adjustments", which are
(conceptually) inserted into the tree:

```
          Call `f(&mut *foo, bar as *const T)`
         /           |                      \
        /            |                       \
    Path `f`   Adjust `&mut *foo`        Adjust `bar as *const T`
                     |                        |
                     |                        |
               Adjust `*foo`             Path `bar`
                     |
                     |
                  Path `foo`
```

Adjustments can have rich and complex behaviors, so it's important
to treat the adjustment nodes as nodes in their own right, and not
try to skip over them. When processing an explicit HIR node,
always use `expr_ty_adjusted` to get the type of its arguments.
If you try to work with the unadjusted type of the child HIR node,
you are essentially skipping over a bunch of nodes of the tree.
This often seems to work in common cases, but this is misleading
and generally leads to an incomplete mental model of what's going on.

For any confusion about how to interpret an HIR node or Adjustment node,
there is no substitute for simply consulting the rustc source.
The file `rustc_mir_build/src/thir/cx/expr.rs` is particularly useful.
(This file is checked into our repo as part of our rustc_mir_build fork).
*/

use crate::attributes::{
    Attr, GhostBlockAttr, get_ghost_block_opt, get_proof_note_annotation, get_trigger,
    get_var_mode, parse_attrs, parse_attrs_opt,
};
use crate::context::{BodyCtxt, Context, HeaderSetting};
use crate::erase::{MiscCall, ResolvedCall};
use crate::fn_call_to_vir::{const_var_to_vir, fn_call_to_vir};
use crate::rust_intrinsics_to_vir::int_intrinsic_constant_to_vir;
use crate::rust_to_vir_base::{
    bitwidth_and_signedness_of_integer_type, get_impl_paths_for_clauses, get_range, is_integer_ty,
    is_smt_arith, is_smt_equality, local_to_var, mid_ty_simplify, mk_range, ty_is_vec,
    typ_of_expr_adjusted, typ_of_node_unadjusted,
};
use crate::rust_to_vir_ctor::{resolve_braces_ctor, resolve_ctor};
use crate::util::{err_span, slice_vec_map_result, vec_map_result};
use crate::verus_items::{
    self, CompilableOprItem, DummyCaptureItem, InvariantItem, OpenAtomicUpdateItem,
    OpenInvariantBlockItem, RustItem, SpecGhostTrackedItem, UnaryOpItem, VerusItem, VstdItem,
};
use crate::{unsupported_err, unsupported_err_unless};
use air::ast::Binder;
use air::ast_util::str_ident;
use rustc_ast::LitKind;
use rustc_hir::def::{CtorKind, DefKind, Res};
use rustc_hir::{
    AssignOpKind, BinOpKind, Block, Closure, Destination, Expr, ExprKind, HirId, ItemKind, LetExpr,
    LetStmt, Lit, LoopSource, Node, Pat, PatExpr, PatExprKind, PatKind, QPath, Stmt, StmtKind,
    StructTailExpr, UnOp,
};
use rustc_hir::{Attribute, BindingMode, BorrowKind, ByRef, Mutability};
use rustc_middle::ty::adjustment::{
    Adjust, Adjustment, AllowTwoPhase, AutoBorrow, AutoBorrowMutability, DerefAdjustKind,
    PatAdjust, PatAdjustment, PointerCoercion,
};
use rustc_middle::ty::{
    AdtDef, ClauseKind, GenericArg, IntTy, TraitPredicate, TraitRef, TyCtxt, TyKind, TypingEnv,
    UintTy, Upcast,
};
use rustc_mir_build_verus::verus::BodyErasure;
use rustc_span::Span;
use rustc_span::Spanned;
use rustc_span::def_id::DefId;
use std::sync::Arc;
use vir::ast::{
    ArithOp, ArmX, AutospecUsage, BinaryOp, BitshiftBehavior, BitwiseOp, BoundsCheck, CallTarget,
    Constant, CrateId, Div0Behavior, Dt, ExprX, FieldOpr, FunX, HeaderExprX, ImplPath,
    InequalityOp, IntRange, IntegerTypeBitwidth, InvAtomicity, Mode, OverflowBehavior, PatternX,
    Place, PlaceX, Primitive, ProofNoteLabel, SignedDivEdgeCaseBehavior, SpannedTyped, StmtX,
    Stmts, Typ, TypDecoration, TypX, UnaryOp, UnaryOpr, UnfinalizedReadKind,
    UninterpretedFloatBinaryOp, VarBinder, VarBinderX, VarIdent, VariantCheck, VirErr,
};
use vir::ast_util::{
    bool_typ, ident_binder, mk_tuple_field_opr, mk_tuple_typ, mk_tuple_x, str_unique_var,
    typ_to_diagnostic_str, types_equal, undecorate_typ,
};
use vir::def::{field_ident_from_rust, positional_field_ident};
use vir::messages::WarningAllow;

/// Enum representing either an `Expr` (value expression) or a `Place` (place expression).
///
/// While converting HIR -> VIR, every HIR node is converted into one of these kinds
/// of expressions. Place expressions include local variables (`x`), field accesses (`x.foo`)
/// and dereferences (`*x`).
///
/// The Rust reference has more information on place expressions and "place expression contexts",
/// i.e., contexts that expect place expressions.
/// See: [https://doc.rust-lang.org/reference/expressions.html#place-expressions-and-value-expressions].
///
/// When constructing the VIR, we frequently need to convert between the two, so the `ExprOrPlace`
/// has various utility methods to coerce to either an `Expr` or `Place` (if necessary). Thus,
/// the recursive structure for lowering an expression to VIR has the following form:
///  - `expr_to_vir` returns an `ExprOrPlace`, depending on whether the expression is a
///    value expression or a place expression.
///  - The caller decides whether to use the result as an `Expr` or a `Place` depending on
///    the type of node it's creating and what that expects.
///
/// The easiest way to convert a `Place` to an `Expr` is to move or copy from it
/// (which we here call "consume"). To convert from an `Expr` to a `Place`, we can create
/// a "temporary" place.
///
/// It is very important to follow Rust's rules and put the Temporary nodes in the right places.
/// Consider, for example, the following nearly-identical snippets:
///
/// ```rust
/// fn test1() {
///     let mut a = 0;
///     let a_ref = &mut a;
///     *a_ref = 20;
///     println!("{:}", a);  // prints 20
/// }
///
/// fn test2() {
///     let mut a = 0;
///     let a_ref = &mut { a };
///     *a_ref = 20;
///     println!("{:}", a);  // prints 0
/// }
/// ```
///
/// The first (with `&mut a`) takes a mutable reference to `a`,
/// while the second (with `&mut { a }`) first copies `a` into a temporary, and then takes
/// a mutable reference to the temporary. Thus, `a` never gets updated! The 2 snippets
/// have different semantics, and the key difference in VIR is the presence of the Temporary node.
///
/// `&mut a`     : `MutRef(Local("a"))`
/// `&mut { a }` : `MutRef(Temporary(Block([], ReadPlace(Local("a")))))`

#[derive(Clone, Debug)]
pub(crate) enum ExprOrPlace {
    Expr(vir::ast::Expr),
    Place(Place),
}

impl ExprOrPlace {
    /// If necessary, coerce the expression to a `Place` by creating a temporary.
    pub(crate) fn to_place<'tcx>(
        &self,
        bctx: &BodyCtxt<'tcx>,
        span: Span,
        ty: rustc_middle::ty::Ty<'tcx>,
    ) -> Result<Place, VirErr> {
        match self {
            ExprOrPlace::Expr(e) => {
                let typ = bctx.mid_ty_to_vir(span, &ty)?;
                Ok(SpannedTyped::new(&e.span, &typ, PlaceX::Temporary(e.clone())))
            }
            ExprOrPlace::Place(p) => Ok(p.clone()),
        }
    }

    /// Get the `Expr` out, fail if this is a `Place`.
    pub(crate) fn expect_expr<'tcx>(&self) -> vir::ast::Expr {
        match self {
            ExprOrPlace::Expr(e) => e.clone(),
            ExprOrPlace::Place(_p) => {
                panic!("expect_expr failed");
            }
        }
    }

    /// Move or copy from the given place, depending on whether the type is `Copy` or not
    pub(crate) fn consume<'tcx>(
        &self,
        bctx: &BodyCtxt<'tcx>,
        ty: rustc_middle::ty::Ty<'tcx>,
    ) -> vir::ast::Expr {
        match self {
            ExprOrPlace::Expr(e) => {
                // We don't need to create a Temporary for the expression, since either:
                // (i) the expression is Copy, in which case 'resolution' is trivial
                // (ii) the expression is moved immediately, in which case we can't possibly
                //      resolve it.
                e.clone()
            }
            ExprOrPlace::Place(p) => {
                let rk = if bctx.is_copy(ty) {
                    vir::ast::ReadKind::Copy
                } else {
                    vir::ast::ReadKind::Move
                };
                let rk = UnfinalizedReadKind {
                    preliminary_kind: rk,
                    id: bctx.ctxt.unique_read_kind_id(),
                };
                bctx.ctxt.spanned_typed_new_vir(&p.span, &p.typ, ExprX::ReadPlace(p.clone(), rk))
            }
        }
    }

    /// Take an immutable borrow from the given place
    /// inner_ty: the type of the thing we're taking a reference of
    pub(crate) fn immut_bor<'tcx>(
        &self,
        bctx: &BodyCtxt<'tcx>,
        span: Span,
        inner_ty: rustc_middle::ty::Ty<'tcx>,
    ) -> Result<vir::ast::Expr, VirErr> {
        // We always need to create a Temporary here,
        // since the expression might require resolution.
        let p = self.to_place(bctx, span, inner_ty)?;
        let rk = vir::ast::ReadKind::ImmutBor;
        let rk = UnfinalizedReadKind { preliminary_kind: rk, id: bctx.ctxt.unique_read_kind_id() };
        let typ = Arc::new(TypX::Decorate(vir::ast::TypDecoration::Ref, None, p.typ.clone()));
        Ok(bctx.ctxt.spanned_typed_new_vir(&p.span, &typ, ExprX::ReadPlace(p.clone(), rk)))
    }

    /// Evaluate the expression but leave the value unused.
    pub(crate) fn unused<'tcx>(
        &self,
        bctx: &BodyCtxt<'tcx>,
        span: Span,
        ty: rustc_middle::ty::Ty<'tcx>,
    ) -> Result<vir::ast::Expr, VirErr> {
        // Try to avoid cluttering the VIR with Unused nodes when they aren't necessary
        if let ExprOrPlace::Expr(e) = self {
            if vir::ast_util::is_unit(&e.typ) {
                return Ok(e.clone());
            }
        }

        let p = self.to_place(bctx, span, ty)?;
        let rk = vir::ast::ReadKind::Unused;
        let rk = UnfinalizedReadKind { preliminary_kind: rk, id: bctx.ctxt.unique_read_kind_id() };
        Ok(bctx.ctxt.spanned_typed_new_vir(&p.span, &p.typ, ExprX::ReadPlace(p.clone(), rk)))
    }

    /// Take a spec snapshot of the give place.
    ///
    /// We only use this in a few places where we are certain that the code has to be 'spec'.
    /// When there's no way to tell (most of the time), always use consume, and mode-checking
    /// will figure out which ones are spec-snapshots later.
    pub(crate) fn to_spec_expr<'tcx>(&self, bctx: &BodyCtxt<'tcx>) -> vir::ast::Expr {
        match self {
            ExprOrPlace::Expr(e) => e.clone(),
            ExprOrPlace::Place(p) => {
                let rk = vir::ast::ReadKind::Spec;
                let rk = UnfinalizedReadKind {
                    preliminary_kind: rk,
                    id: bctx.ctxt.unique_read_kind_id(),
                };
                bctx.ctxt.spanned_typed_new_vir(&p.span, &p.typ, ExprX::ReadPlace(p.clone(), rk))
            }
        }
    }

    pub(crate) fn typ(&self) -> &vir::ast::Typ {
        match self {
            ExprOrPlace::Expr(e) => &e.typ,
            ExprOrPlace::Place(p) => &p.typ,
        }
    }
}

pub(crate) fn pat_to_mut_var<'tcx>(pat: &Pat) -> Result<(bool, VarIdent), VirErr> {
    let Pat { hir_id: _, kind, span, default_binding_modes } = pat;
    unsupported_err_unless!(default_binding_modes, *span, "default_binding_modes");
    match kind {
        PatKind::Binding(annotation, id, ident, _subpat) => {
            let BindingMode(_, mutability) = annotation;
            let mutable = match mutability {
                rustc_hir::Mutability::Mut => true,
                rustc_hir::Mutability::Not => false,
            };
            Ok((mutable, local_to_var(ident, id.local_id)))
        }
        _ => {
            unsupported_err!(*span, "only variables are supported here, not general patterns")
        }
    }
}

/// Translates a closure or function parameter pattern into a parameter variable.
/// An identifier such as `x` or `x @ p` is the parameter itself, while more complex patterns get
/// a hidden name. `param_pat_to_decl` declares the remaining bindings.
pub(crate) fn param_pat_to_mut_var(pat: &Pat) -> Result<(bool, VarIdent), VirErr> {
    if matches!(pat.kind, PatKind::Binding(BindingMode(ByRef::No, _), ..)) {
        pat_to_mut_var(pat)
    } else {
        let id = pat.hir_id.local_id.index();
        let name = format!("%param{id}");
        Ok((false, str_unique_var(&name, vir::ast::VarIdentDisambiguate::RustcId(id))))
    }
}

/// The part of a parameter pattern that needs a declaration
pub(crate) fn param_pat_to_destructure<'tcx>(pat: &'tcx Pat<'tcx>) -> Option<&'tcx Pat<'tcx>> {
    let pat = match pat.kind {
        PatKind::Binding(BindingMode(ByRef::No, _), _, _, subpat) => subpat?,
        _ => pat,
    };
    if matches!(pat.kind, PatKind::Wild) { None } else { Some(pat) }
}

/// Builds `let p = <param>;` in `mode` for the body and in spec mode for the contracts
pub(crate) fn param_pat_to_decl<'tcx>(
    bctx: &BodyCtxt<'tcx>,
    pat: &'tcx Pat<'tcx>,
    param: &VarIdent,
    typ: &Typ,
    mode: Mode,
) -> Result<Option<(vir::ast::Stmt, vir::ast::Stmt)>, VirErr> {
    let Some(pat) = param_pat_to_destructure(pat) else {
        return Ok(None);
    };
    let pattern = pattern_to_vir(bctx, pat)?;
    if let Some(span) = vir::patterns::pattern_find_mut_binding(&pattern) {
        return Err(vir::messages::error(
            &span,
            "mutable-reference bindings in parameters are not supported",
        ));
    }

    let init = bctx.spanned_typed_new(pat.span, typ, PlaceX::Local(param.clone()));
    // Generated initializer has no corresponding source HIR node.
    bctx.ctxt.erasure_info.borrow_mut().local_hir_vir_ids.push((None, init.span.id));

    let decl = |mode| {
        bctx.spanned_new(
            pat.span,
            StmtX::Decl {
                pattern: pattern.clone(),
                mode: Some((mode, vir::ast::DeclProph::Default)),
                init: Some(init.clone()),
                els: None,
                assert_irrefutable: false,
            },
        )
    };
    Ok(Some((decl(mode), decl(Mode::Spec))))
}

/// Adds the parameter pattern declarations to the body, and their spec versions to each
/// contract, so contracts can use the bindings
pub(crate) fn add_param_decls(
    ctxt: &Context,
    span: Span,
    header: &mut vir::headers::Header,
    body: &mut vir::ast::Expr,
    param_decls: Vec<(vir::ast::Stmt, vir::ast::Stmt)>,
) -> Result<(), VirErr> {
    use vir::ast::{MaskSpec, UnwindSpec};
    if param_decls.is_empty() {
        return Ok(());
    }
    let vir::headers::Header {
        require,
        recommend,
        ensure,
        returns,
        decrease,
        decrease_when,
        invariant_mask,
        atomic_update,
        unwind_spec,
        invariant_except_break: _,
        invariant: _,
        atomic_call_loop: _,
        no_method_body: _,
        unwrap_parameters: _,
        hidden: _,
        ensure_id_typ: _,
        decrease_by: _,
        extra_dependencies: _,
        open_visibility_qualifier: _,
    } = header;
    if atomic_update.is_some() {
        return err_span(span, "atomic specifications are not supported with parameter patterns");
    }
    let (body_decls, spec_decls): (Vec<_>, Vec<_>) = param_decls.into_iter().unzip();
    let wrap = |e: &vir::ast::Expr| {
        let decls = ctxt.clone_stmts_with_fresh_ids(&spec_decls);
        ctxt.spanned_typed_new_vir(&e.span, &e.typ, ExprX::Block(decls, Some(e.clone())))
    };
    let wrap_all = |es: &vir::ast::Exprs| Arc::new(es.iter().map(wrap).collect::<Vec<_>>());
    *require = wrap_all(require);
    *recommend = wrap_all(recommend);
    *ensure = (wrap_all(&ensure.0), wrap_all(&ensure.1));
    *returns = returns.as_ref().map(wrap);
    *decrease = wrap_all(decrease);
    *decrease_when = decrease_when.as_ref().map(wrap);
    *invariant_mask = invariant_mask.as_ref().map(|mask| match mask {
        MaskSpec::InvariantOpens(span, es) => MaskSpec::InvariantOpens(span.clone(), wrap_all(es)),
        MaskSpec::InvariantOpensExcept(span, es) => {
            MaskSpec::InvariantOpensExcept(span.clone(), wrap_all(es))
        }
        MaskSpec::InvariantOpensSet(e) => MaskSpec::InvariantOpensSet(wrap(e)),
    });
    *unwind_spec = unwind_spec.as_ref().map(|spec| match spec {
        UnwindSpec::NoUnwind => UnwindSpec::NoUnwind,
        UnwindSpec::NoUnwindWhen(e) => UnwindSpec::NoUnwindWhen(wrap(e)),
        UnwindSpec::MayUnwind => UnwindSpec::MayUnwind,
    });
    *body = ctxt.spanned_typed_new_vir(
        &body.span,
        &body.typ,
        ExprX::Block(Arc::new(body_decls), Some(body.clone())),
    );
    Ok(())
}

pub(crate) fn pat_to_var<'tcx>(pat: &Pat) -> Result<VarIdent, VirErr> {
    let (_, name) = pat_to_mut_var(pat)?;
    Ok(name)
}

pub(crate) fn extract_array<'tcx>(expr: &'tcx Expr<'tcx>) -> Vec<&'tcx Expr<'tcx>> {
    match &expr.kind {
        ExprKind::Array(fields) => fields.iter().collect(),
        _ => vec![expr],
    }
}

pub(crate) fn extract_tuple<'tcx>(expr: &'tcx Expr<'tcx>) -> Vec<&'tcx Expr<'tcx>> {
    match &expr.kind {
        ExprKind::Tup(exprs) => exprs.iter().collect(),
        _ => vec![expr],
    }
}

pub(crate) fn closure_param_typs<'tcx>(
    bctx: &BodyCtxt<'tcx>,
    expr: &Expr<'tcx>,
) -> Result<Vec<Typ>, VirErr> {
    let node_type = bctx.types.node_type(expr.hir_id);
    match node_type.kind() {
        TyKind::Closure(_def, substs) => {
            let sig = substs.as_closure().sig();
            let mut args: Vec<Typ> = Vec::new();
            // REVIEW: rustc docs refer to skip_binder as "dangerous"
            for t in sig.inputs().skip_binder().iter() {
                args.push(bctx.mid_ty_to_vir(expr.span, t)?);
            }
            assert!(args.len() == 1);
            match &*args[0] {
                TypX::Datatype(Dt::Tuple(_), typs, ..) => Ok((**typs).clone()),
                _ => panic!("expected tuple type"),
            }
        }
        _ => panic!("closure_param_types expected Closure type"),
    }
}

fn closure_ret_typ<'tcx>(bctx: &BodyCtxt<'tcx>, expr: &Expr<'tcx>) -> Result<Typ, VirErr> {
    let node_type = bctx.types.node_type(expr.hir_id);
    match node_type.kind() {
        TyKind::Closure(_def, substs) => {
            let sig = substs.as_closure().sig();
            let t = sig.output().skip_binder();
            bctx.mid_ty_to_vir(expr.span, &t)
        }
        _ => panic!("closure_param_types expected Closure type"),
    }
}

fn mk_clip<'tcx>(
    bctx: &BodyCtxt<'tcx>,
    range: &IntRange,
    expr: &vir::ast::Expr,
    recommends_assume_truncate: bool,
) -> vir::ast::Expr {
    match range {
        IntRange::Int => expr.clone(),
        range => bctx.ctxt.spanned_typed_new_vir(
            &expr.span,
            &Arc::new(TypX::Int(*range)),
            ExprX::Unary(
                UnaryOp::Clip { range: *range, truncate: recommends_assume_truncate },
                expr.clone(),
            ),
        ),
    }
}

pub(crate) fn mk_ty_clip<'tcx>(
    bctx: &BodyCtxt<'tcx>,
    typ: &Typ,
    expr: &vir::ast::Expr,
    recommends_assume_truncate: bool,
) -> vir::ast::Expr {
    mk_clip(bctx, &get_range(typ), expr, recommends_assume_truncate)
}

pub(crate) fn check_lit_int(
    ctxt: &Context,
    span: Span,
    in_negative_literal: bool,
    i: u128,
    typ: &Typ,
) -> Result<(), VirErr> {
    let i_bump = if in_negative_literal { 1 } else { 0 };
    if let TypX::Int(range) = *undecorate_typ(typ) {
        match range {
            IntRange::Int | IntRange::Nat => Ok(()),
            IntRange::U(n) if n == 128 || (n < 128 && i < (1u128 << n)) => Ok(()),
            IntRange::I(n) if n - 1 < 128 && i < (1u128 << (n - 1)) + i_bump => Ok(()),
            IntRange::USize
                if i < (1u128
                    << (ctxt.arch_word_bits.expect("unkown arch_word_bits").min_bits()
                        as u128)) =>
            {
                Ok(())
            }
            IntRange::ISize
                if i < (1u128
                    << (ctxt.arch_word_bits.expect("unkown arch_word_bits").min_bits() - 1))
                    + i_bump =>
            {
                Ok(())
            }
            _ => {
                return err_span(span, format!("integer literal out of range {:?}", range));
            }
        }
    } else {
        return err_span(span, "expected integer type");
    }
}

pub(crate) fn expr_to_vir_inner<'tcx>(
    bctx: &BodyCtxt<'tcx>,
    expr: &Expr<'tcx>,
) -> Result<ExprOrPlace, VirErr> {
    let expr = expr.peel_drop_temps();

    if bctx.external_body {
        // we want just requires/ensures, not the whole body
        match &expr.kind {
            ExprKind::Block(..) | ExprKind::Call(..) | ExprKind::Closure(_) => {}
            _ => {
                return Ok(ExprOrPlace::Expr(bctx.spanned_typed_new(
                    expr.span,
                    &Arc::new(TypX::Bool),
                    ExprX::Block(Arc::new(vec![]), None),
                )));
            }
        }
    }

    let adjustments = bctx.types.expr_adjustments(expr);

    expr_to_vir_with_adjustments(bctx, expr, adjustments, adjustments.len())
}

pub(crate) fn expr_to_vir_consume<'tcx>(
    bctx: &BodyCtxt<'tcx>,
    expr: &Expr<'tcx>,
) -> Result<vir::ast::Expr, VirErr> {
    let translated = expr_to_vir(bctx, expr)?.consume(bctx, bctx.types.expr_ty_adjusted(expr));
    #[cfg(feature = "experimental-native-resource")]
    crate::native_resource143::retain_expression(bctx.fun_id, expr.hir_id, &translated);
    Ok(translated)
}

pub(crate) fn expr_to_vir_place<'tcx>(
    bctx: &BodyCtxt<'tcx>,
    expr: &Expr<'tcx>,
) -> Result<vir::ast::Place, VirErr> {
    Ok(expr_to_vir(bctx, expr)?.to_place(bctx, expr.span, bctx.types.expr_ty_adjusted(expr))?)
}

pub(crate) fn expr_to_vir<'tcx>(
    bctx: &BodyCtxt<'tcx>,
    expr: &Expr<'tcx>,
) -> Result<ExprOrPlace, VirErr> {
    let mut vir_expr_or_place = expr_to_vir_inner(bctx, expr)?;
    let attrs = bctx.ctxt.tcx.hir_attrs(expr.hir_id);
    for group in get_trigger(attrs)? {
        let mut vir_expr = vir_expr_or_place.to_spec_expr(bctx);
        vir_expr = vir_expr.new_x(ExprX::Unary(UnaryOp::Trigger(group), vir_expr.clone()));
        vir_expr_or_place = ExprOrPlace::Expr(vir_expr);
    }
    if let Some((label, is_custom_err)) = get_proof_note_annotation(attrs)? {
        let mut vir_expr = vir_expr_or_place.to_spec_expr(bctx);
        vir_expr = vir_expr.new_x(ExprX::UnaryOpr(
            UnaryOpr::ProofNote(ProofNoteLabel { text: Arc::new(label), is_custom_err }),
            vir_expr.clone(),
        ));
        vir_expr_or_place = ExprOrPlace::Expr(vir_expr);
    }
    #[cfg(feature = "experimental-native-resource")]
    if let ExprOrPlace::Expr(translated) = &vir_expr_or_place {
        crate::native_resource143::retain_expression(bctx.fun_id, expr.hir_id, translated);
    }
    Ok(vir_expr_or_place)
}

fn patexpr_unsupported_type_err<'tcx>(
    bctx: &BodyCtxt<'tcx>,
    span: Span,
    pat: &Pat<'tcx>,
) -> Result<(), VirErr> {
    let pat_ty = bctx.types.node_type(pat.hir_id);
    if !crate::rust_to_vir_base::ty_has_smt_equality(bctx, span, pat_ty)? {
        unsupported_err!(span, format!("equality-testing this type in pattern: {:?}", pat_ty));
    }
    Ok(())
}

pub(crate) fn patexpr_to_vir<'tcx>(
    bctx: &BodyCtxt<'tcx>,
    span: Span,
    pat: &Pat<'tcx>,
    pat_typ: &Typ,
    pat_expr: &PatExpr<'tcx>,
) -> Result<PatternX, VirErr> {
    let tcx = bctx.ctxt.tcx;
    match pat_expr.kind {
        PatExprKind::Lit { lit, negated } => {
            patexpr_unsupported_type_err(bctx, span, pat)?;
            Ok(PatternX::Expr(lit_to_vir(bctx, span, lit, negated, pat_typ, None)?))
        }
        PatExprKind::Path(qpath) => {
            let res = bctx.types.qpath_res(&qpath, pat_expr.hir_id);
            match res {
                Res::Def(DefKind::Const { is_type_const: _ }, id) => {
                    patexpr_unsupported_type_err(bctx, span, pat)?;
                    let node_substs = bctx.types.node_args(pat_expr.hir_id);
                    let x = const_var_to_vir(bctx, None, id, node_substs, &pat_expr.hir_id, span)?;
                    let expr = bctx.spanned_typed_new(pat.span, &pat_typ, x.x.clone());

                    Ok(PatternX::Expr(expr))
                }
                Res::Def(DefKind::AssocConst { is_type_const: _ }, id) => {
                    patexpr_unsupported_type_err(bctx, span, pat)?;
                    if let Some(vir_expr) =
                        int_intrinsic_constant_to_vir(&bctx.ctxt, pat.span, &pat_typ, id)
                    {
                        Ok(PatternX::Expr(vir_expr))
                    } else {
                        let node_substs = bctx.types.node_args(pat_expr.hir_id);
                        let x =
                            const_var_to_vir(bctx, None, id, node_substs, &pat_expr.hir_id, span)?;
                        let expr = bctx.spanned_typed_new(pat.span, &pat_typ, x.x.clone());

                        Ok(PatternX::Expr(expr))
                    }
                }
                Res::Err => err_span(span, format!("Couldn't resolve {qpath:#?}")),
                _ => match resolve_ctor(bctx.ctxt.tcx, res) {
                    Some((ctor, CtorKind::Const)) => {
                        let variant_name = str_ident(&ctor.variant_def.ident(tcx).as_str());
                        let vir_path = bctx.ctxt.def_id_to_vir_path(ctor.adt_def_id);
                        Ok(PatternX::Constructor(
                            Dt::Path(vir_path),
                            variant_name,
                            Arc::new(vec![]),
                        ))
                    }
                    _ => {
                        unsupported_err!(pat.span, "this pattern: {:?}", res)
                    }
                },
            }
        }
    }
}

pub(crate) fn get_fn_path<'tcx>(
    bctx: &BodyCtxt<'tcx>,
    expr: &Expr<'tcx>,
) -> Result<vir::ast::Fun, VirErr> {
    match &expr.kind {
        ExprKind::Path(qpath) => {
            let id = bctx.types.qpath_res(qpath, expr.hir_id).def_id();
            if let Some(_) =
                bctx.ctxt.tcx.impl_of_assoc(id).and_then(|ii| bctx.ctxt.tcx.trait_impl_of_assoc(ii))
            {
                unsupported_err!(expr.span, format!("Fn {:?}", id))
            } else {
                let path = bctx.ctxt.def_id_to_vir_path(id);
                Ok(Arc::new(FunX { path }))
            }
        }
        _ => unsupported_err!(expr.span, format!("{:?}", expr)),
    }
}

pub(crate) fn expr_tuple_datatype_ctor_to_vir<'tcx>(
    bctx: &BodyCtxt<'tcx>,
    expr: &Expr<'tcx>,
    ctor: crate::rust_to_vir_ctor::Ctor,
    args_slice: &[Expr<'tcx>],
    fun_span: Span,
) -> Result<vir::ast::Expr, VirErr> {
    let tcx = bctx.ctxt.tcx;
    let expr_typ = typ_of_node_unadjusted(bctx, expr.span, &expr.hir_id)?;

    let variant_name = str_ident(&ctor.variant_def.ident(tcx).as_str());
    let vir_path = bctx.ctxt.def_id_to_vir_path(ctor.adt_def_id);

    let vir_fields = Arc::new(
        args_slice
            .iter()
            .enumerate()
            .map(|(i, e)| -> Result<_, VirErr> {
                let vir = expr_to_vir_consume(bctx, e)?;
                Ok(ident_binder(&positional_field_ident(i), &vir))
            })
            .collect::<Result<Vec<_>, _>>()?,
    );
    let mut erasure_info = bctx.ctxt.erasure_info.borrow_mut();
    let resolved_call = ResolvedCall::Ctor(vir_path.clone(), variant_name.clone());
    erasure_info.resolved_calls.push((expr.hir_id, fun_span.data(), resolved_call, bctx.in_ghost));
    let exprx = ExprX::Ctor(Dt::Path(vir_path), variant_name, vir_fields, None);
    let e = bctx.spanned_typed_new(expr.span, &expr_typ, exprx);
    erasure_info.ctor_hir_vir_ids.push((Some(expr.hir_id), e.span.id));
    Ok(e)
}

fn handle_dot_dot(
    num_entries_in_pat: usize,
    total_entries: usize,
    dot_dot_pos: &rustc_hir::DotDotPos,
) -> (usize, usize) {
    match dot_dot_pos.as_opt_usize() {
        None => {
            assert!(num_entries_in_pat == total_entries);
            (0, 0)
        }
        Some(pos) => {
            assert!(pos <= num_entries_in_pat);
            assert!(num_entries_in_pat <= total_entries);
            let n_wildcards = total_entries - num_entries_in_pat;
            (n_wildcards, pos)
        }
    }
}

pub(crate) fn pattern_to_vir<'tcx>(
    bctx: &BodyCtxt<'tcx>,
    pat: &Pat<'tcx>,
) -> Result<vir::ast::Pattern, VirErr> {
    let unadjusted_pat = pattern_to_vir_unadjusted(bctx, pat)?;
    if matches!(pat.kind, PatKind::Binding(..)) {
        let mut erasure_info = bctx.ctxt.erasure_info.borrow_mut();
        erasure_info.binder_hir_vir_ids.push((Some(pat.hir_id), unadjusted_pat.span.id));
    }

    // See rustc_mir_build/src/thir/pattern/mod.rs
    let adjustments: &[PatAdjustment<'tcx>] =
        bctx.types.pat_adjustments().get(pat.hir_id).map_or(&[], |v| &**v);
    let mut vir_pat = unadjusted_pat;

    for adjust in adjustments.iter().rev() {
        match adjust.kind {
            PatAdjust::BuiltinDeref => {
                let is_mut = match adjust.source.kind() {
                    TyKind::Ref(_, _, rustc_ast::Mutability::Mut) => true,
                    TyKind::Ref(_, _, rustc_ast::Mutability::Not) => false,
                    _ => {
                        crate::internal_err!(pat.span, "expected reference type")
                    }
                };

                if is_mut {
                    let typ = Arc::new(TypX::MutRef(vir_pat.typ.clone()));
                    let x = PatternX::MutRef(vir_pat);
                    vir_pat = bctx.spanned_typed_new(pat.span, &typ, x);
                } else {
                    let typ =
                        Arc::new(TypX::Decorate(TypDecoration::Ref, None, vir_pat.typ.clone()));
                    let x = PatternX::ImmutRef(vir_pat);
                    vir_pat = bctx.spanned_typed_new(pat.span, &typ, x);
                };
            }
            PatAdjust::OverloadedDeref => {
                unsupported_err!(pat.span, "overloaded deref in pattern");
            }
            PatAdjust::PinDeref => {
                unsupported_err!(pat.span, "pin deref in pattern");
            }
        }
    }

    Ok(vir_pat)
}

pub(crate) fn pattern_to_vir_unadjusted<'tcx>(
    bctx: &BodyCtxt<'tcx>,
    pat: &Pat<'tcx>,
) -> Result<vir::ast::Pattern, VirErr> {
    let tcx = bctx.ctxt.tcx;
    let mut pat_typ = typ_of_node_unadjusted(bctx, pat.span, &pat.hir_id)?;
    unsupported_err_unless!(pat.default_binding_modes, pat.span, "destructuring assignment");
    let pattern = match &pat.kind {
        PatKind::Wild => PatternX::Wildcard,
        PatKind::Binding(_binding_mode, canonical, x, subpat) => {
            // We want the computed binding mode, which accounts for match ergonomics,
            // rather than the source-level binding mode.
            let BindingMode(by_ref, mutability) =
                bctx.types.pat_binding_modes().get(pat.hir_id).expect("binding mode");

            let mutable = match mutability {
                Mutability::Not => false,
                Mutability::Mut => true,
            };

            let vir_by_ref = match by_ref {
                ByRef::No => vir::ast::ByRef::No,
                ByRef::Yes(_pinnedness, Mutability::Mut) => vir::ast::ByRef::MutRef,
                ByRef::Yes(_pinnedness, Mutability::Not) => vir::ast::ByRef::ImmutRef,
            };

            // For a PatKind::Binding node, the HIR node type is always the type of
            // the bound variable.
            // However, we want the pattern.typ to be the type that is being matched against,
            // which is different if there's a nontrivial binding mode.
            let var_typ = pat_typ.clone();
            let actual_pat_typ = match by_ref {
                ByRef::No => var_typ.clone(),
                ByRef::Yes(_pinnedness, Mutability::Mut) => match &*var_typ {
                    TypX::MutRef(t) => t.clone(),
                    _ => crate::internal_err!(pat.span, "expected &mut type"),
                },
                ByRef::Yes(_pinnedness, Mutability::Not) => match &*var_typ {
                    TypX::Decorate(TypDecoration::Ref, None, t) => t.clone(),
                    _ => crate::internal_err!(pat.span, "expected & type"),
                },
            };
            pat_typ = actual_pat_typ;

            let name = local_to_var(x, canonical.local_id);
            let binding = vir::ast::PatternBinding {
                name,
                user_mut: Some(mutable),
                by_ref: vir_by_ref,
                typ: var_typ.clone(),
                copy: bctx.is_copy(bctx.types.node_type(pat.hir_id)),
            };
            match subpat {
                None => PatternX::Var(binding),
                Some(subpat) => {
                    PatternX::Binding { binding, sub_pat: pattern_to_vir(bctx, subpat)? }
                }
            }
        }
        PatKind::Expr(expr) => patexpr_to_vir(bctx, expr.span, pat, &pat_typ, expr)?,
        PatKind::Tuple(pats, dot_dot_pos) => {
            let n = match &*pat_typ {
                TypX::Datatype(Dt::Tuple(n), typs, ..) => {
                    assert!(typs.len() == *n);
                    *n
                }
                _ => {
                    crate::internal_err!(pat.span, "expected tuple type")
                }
            };

            let (n_wildcards, pos_to_insert_wildcards) =
                handle_dot_dot(pats.len(), n, &dot_dot_pos);

            let mut binders: Vec<Binder<vir::ast::Pattern>> = Vec::new();
            for (i, pat) in pats.iter().enumerate() {
                let actual_idx = if i < pos_to_insert_wildcards { i } else { i + n_wildcards };

                let pattern = pattern_to_vir(bctx, pat)?;
                let binder = ident_binder(&positional_field_ident(actual_idx), &pattern);
                binders.push(binder);
            }

            let variant_name = vir::def::prefix_tuple_variant(n);
            PatternX::Constructor(Dt::Tuple(n), variant_name, Arc::new(binders))
        }
        PatKind::TupleStruct(qpath, pats, dot_dot_pos) => {
            let res = bctx.types.qpath_res(qpath, pat.hir_id);
            let ctor = resolve_ctor(bctx.ctxt.tcx, res);
            let Some((ctor, CtorKind::Fn)) = ctor else {
                crate::internal_err!(pat.span, "expected Fn constructor")
            };

            let variant_name = str_ident(&ctor.variant_def.ident(tcx).as_str());
            let vir_path = bctx.ctxt.def_id_to_vir_path(ctor.adt_def_id);

            let (n_wildcards, pos_to_insert_wildcards) =
                handle_dot_dot(pats.len(), ctor.variant_def.fields.len(), &dot_dot_pos);

            let mut binders: Vec<Binder<vir::ast::Pattern>> = Vec::new();
            for (i, pat) in pats.iter().enumerate() {
                let actual_idx = if i < pos_to_insert_wildcards { i } else { i + n_wildcards };

                let pattern = pattern_to_vir(bctx, pat)?;
                let binder = ident_binder(&positional_field_ident(actual_idx), &pattern);
                binders.push(binder);
            }

            PatternX::Constructor(Dt::Path(vir_path), variant_name, Arc::new(binders))
        }
        PatKind::Struct(qpath, pats, _) => {
            let res = bctx.types.qpath_res(qpath, pat.hir_id);
            let ty = bctx.types.node_type(pat.hir_id);
            let ctor = resolve_braces_ctor(tcx, res, ty, false, pat.span)?;
            let variant_name = str_ident(&ctor.variant_def.ident(tcx).as_str());
            let vir_path = bctx.ctxt.def_id_to_vir_path(ctor.adt_def_id);

            let mut binders: Vec<Binder<vir::ast::Pattern>> = Vec::new();
            for fpat in pats.iter() {
                let pattern = pattern_to_vir(bctx, &fpat.pat)?;
                let ident = field_ident_from_rust(fpat.ident.as_str());
                let binder = ident_binder(&ident, &pattern);
                binders.push(binder);
            }
            PatternX::Constructor(Dt::Path(vir_path), variant_name, Arc::new(binders))
        }
        PatKind::Box(pat) => {
            return pattern_to_vir(bctx, pat);
        }
        PatKind::Or(pats) => {
            if pats.len() == 1 {
                return pattern_to_vir(bctx, &pats[0]);
            }

            assert!(pats.len() >= 2);

            let mut patterns: Vec<vir::ast::Pattern> = Vec::new();
            for pat in pats.iter() {
                patterns.push(pattern_to_vir(bctx, pat)?);
            }

            // Arrange it like Or(a, Or(b, Or(c, d)))
            // Also, make sure to preserve the order.

            let mut pat_iter = patterns.into_iter().rev();
            let plast = pat_iter.next().unwrap();
            let plast2 = pat_iter.next().unwrap();
            let mut pat_or = PatternX::Or(plast2, plast);
            while let Some(p) = pat_iter.next() {
                pat_or = PatternX::Or(p, bctx.spanned_typed_new(pat.span, &pat_typ, pat_or));
            }
            pat_or
        }
        PatKind::Range(expr1_opt, expr2_opt, range_end) => {
            let e1 = match expr1_opt {
                None => None,
                Some(expr1) => {
                    let e1 = patexpr_to_vir(bctx, expr1.span, pat, &pat_typ, expr1)?;
                    if let PatternX::Expr(e1) = e1 {
                        if !matches!(&*e1.typ, TypX::Int(_)) {
                            unsupported_err!(expr1.span, "range pattern with non-int type");
                        }
                        Some(e1)
                    } else {
                        return err_span(expr1.span, "range pattern with unsupported type");
                    }
                }
            };
            let e2 = match expr2_opt {
                None => None,
                Some(expr2) => {
                    let e2 = patexpr_to_vir(bctx, expr2.span, pat, &pat_typ, expr2)?;
                    if let PatternX::Expr(e2) = e2 {
                        if !matches!(&*e2.typ, TypX::Int(_)) {
                            unsupported_err!(expr2.span, "range pattern with non-int type");
                        }
                        let ineq = match range_end {
                            rustc_hir::RangeEnd::Included => InequalityOp::Le,
                            rustc_hir::RangeEnd::Excluded => InequalityOp::Lt,
                        };
                        Some((e2, ineq))
                    } else {
                        return err_span(expr2.span, "range pattern with unsupported type");
                    }
                }
            };
            PatternX::Range(e1, e2)
        }
        PatKind::Guard(..) => unsupported_err!(pat.span, "pattern guards", pat),
        PatKind::Ref(subpat, pinnedness, mutability) => {
            // pinned patterns such as `&pin const x` unsupported
            unsupported_err_unless!(
                matches!(pinnedness, rustc_hir::Pinnedness::Not),
                pat.span,
                "pinned ref patterns"
            );

            // Follow rustc_mir_build/src/thir/pattern/mod.rs: when rustc marks this reference
            // pattern as skipped, lower only its inner pattern.
            // Adding a reference wrapper here would introduce an extra layer.
            if bctx.types.skipped_ref_pats().contains(pat.hir_id) {
                return pattern_to_vir(bctx, subpat);
            }

            let subpattern = pattern_to_vir(bctx, subpat)?;

            match mutability {
                Mutability::Not => PatternX::ImmutRef(subpattern), // '&' pattern
                Mutability::Mut => PatternX::MutRef(subpattern),   // '&mut' pattern
            }
        }
        PatKind::Slice(pats, inner, suffix) => {
            if inner.is_some() || suffix.len() > 0 {
                unsupported_err!(pat.span, "slice patterns with '..'", pat);
            }
            let mut patterns = vec![];
            for pat in pats.iter() {
                let pattern = pattern_to_vir(bctx, pat)?;
                patterns.push(pattern);
            }
            PatternX::Slice(Arc::new(patterns))
        }
        PatKind::Never => unsupported_err!(pat.span, "never patterns", pat),
        PatKind::Deref(_) => unsupported_err!(pat.span, "deref patterns", pat),
        PatKind::Err(_) => unsupported_err!(pat.span, "err patterns", pat),
        PatKind::Missing => unsupported_err!(pat.span, "missing patterns", pat),
    };
    let pattern = bctx.spanned_typed_new(pat.span, &pat_typ, pattern);
    let mut erasure_info = bctx.ctxt.erasure_info.borrow_mut();
    erasure_info.resolved_pats.push((pat.span.data(), pattern.clone()));
    Ok(pattern)
}

pub(crate) fn block_to_vir<'tcx>(
    bctx: &BodyCtxt<'tcx>,
    block: &Block<'tcx>,
    span: &Span,
    ty: &Typ,
) -> Result<vir::ast::Expr, VirErr> {
    let mut vir_stmts: Vec<vir::ast::Stmt> = Vec::new();
    let mut stmts_iter = block.stmts.iter();
    while let Some(mut some_stmts) = stmts_to_vir(bctx, &mut stmts_iter)? {
        vir_stmts.append(&mut some_stmts);
    }
    let vir_expr = block.expr.map(|expr| expr_to_vir_consume(bctx, &expr)).transpose()?;

    let x = ExprX::Block(Arc::new(vir_stmts), vir_expr);
    Ok(bctx.spanned_typed_new(span.clone(), ty, x))
}

/// Check for the #[verifier(invariant_block)] attribute
pub fn attrs_is_invariant_block(attrs: &[Attribute]) -> Result<bool, VirErr> {
    let attrs_vec = parse_attrs(attrs, None)?;
    for attr in &attrs_vec {
        match attr {
            Attr::InvariantBlock => {
                return Ok(true);
            }
            _ => {}
        }
    }
    Ok(false)
}

/// Check for the #[verifier(invariant_block)] attribute on a block
fn is_invariant_block(bctx: &BodyCtxt, expr: &Expr) -> Result<bool, VirErr> {
    let attrs = bctx.ctxt.tcx.hir_attrs(expr.hir_id);
    attrs_is_invariant_block(attrs)
}

fn malformed_inv_block_err<'tcx, X>(expr: &Expr<'tcx>) -> Result<X, VirErr> {
    err_span(
        expr.span,
        "malformed invariant block; use `open_atomic_invariant!` or `open_local_invariant!` macro instead",
    )
}

pub(crate) fn is_spend_open_invariant_credit_call(
    verus_items: &verus_items::VerusItems,
    spend_stmt: &Stmt,
) -> bool {
    match spend_stmt.kind {
        StmtKind::Semi(Expr {
            kind:
                ExprKind::Call(
                    Expr {
                        kind:
                            ExprKind::Path(QPath::Resolved(
                                None,
                                rustc_hir::Path { res: Res::Def(_, fun_id), .. },
                            )),
                        ..
                    },
                    [Expr { .. }],
                ),
            ..
        }) => match verus_items.id_to_name.get(&fun_id) {
            Some(&VerusItem::Vstd(
                VstdItem::Invariant(InvariantItem::SpendOpenInvariantCredit),
                _,
            )) => true,
            Some(&VerusItem::Vstd(
                VstdItem::Invariant(InvariantItem::SpendOpenInvariantCreditInProof),
                _,
            )) => true,
            _ => false,
        },
        _ => false,
    }
}

pub(crate) fn invariant_block_open<'a>(
    verus_items: &verus_items::VerusItems,
    open_stmt: &'a Stmt,
) -> Option<(HirId, HirId, &'a rustc_hir::Pat<'a>, &'a rustc_hir::Expr<'a>, InvAtomicity)> {
    match open_stmt.kind {
        StmtKind::Let(LetStmt {
            pat:
                Pat {
                    kind:
                        PatKind::Tuple(
                            [
                                Pat {
                                    kind:
                                        PatKind::Binding(
                                            BindingMode(_, Mutability::Not),
                                            guard_hir,
                                            _,
                                            None,
                                        ),
                                    default_binding_modes: true,
                                    ..
                                },
                                inner_pat @ Pat {
                                    kind:
                                        PatKind::Binding(
                                            BindingMode(_, Mutability::Mut),
                                            inner_hir,
                                            _,
                                            None,
                                        ),
                                    default_binding_modes: true,
                                    ..
                                },
                            ],
                            dot_dot_pos,
                        ),
                    ..
                },
            init:
                Some(Expr {
                    kind:
                        ExprKind::Call(
                            Expr {
                                kind:
                                    ExprKind::Path(QPath::Resolved(
                                        None,
                                        rustc_hir::Path {
                                            res: Res::Def(DefKind::Fn, fun_id), ..
                                        },
                                    )),
                                ..
                            },
                            [arg],
                        ),
                    ..
                }),
            els: None,
            ..
        }) if dot_dot_pos.as_opt_usize().is_none() => {
            let verus_item = verus_items.id_to_name.get(fun_id);
            let atomicity = match verus_item {
                Some(VerusItem::OpenInvariantBlock(
                    OpenInvariantBlockItem::OpenAtomicInvariantBegin,
                )) => InvAtomicity::Atomic,
                Some(VerusItem::OpenInvariantBlock(
                    OpenInvariantBlockItem::OpenLocalInvariantBegin,
                )) => InvAtomicity::NonAtomic,
                _ => {
                    return None;
                }
            };

            Some((*guard_hir, *inner_hir, inner_pat, arg, atomicity))
        }
        _ => {
            dbg!(&open_stmt);
            None
        }
    }
}

pub(crate) fn invariant_block_close(close_stmt: &Stmt) -> Option<(HirId, HirId, DefId)> {
    match close_stmt.kind {
        StmtKind::Semi(Expr {
            kind:
                ExprKind::Call(
                    Expr {
                        kind:
                            ExprKind::Path(QPath::Resolved(
                                None,
                                rustc_hir::Path { res: Res::Def(_, fun_id), .. },
                            )),
                        ..
                    },
                    [
                        Expr {
                            kind:
                                ExprKind::Path(QPath::Resolved(
                                    None,
                                    rustc_hir::Path { res: Res::Local(hir_id1), .. },
                                )),
                            ..
                        },
                        Expr {
                            kind:
                                ExprKind::Path(QPath::Resolved(
                                    None,
                                    rustc_hir::Path { res: Res::Local(hir_id2), .. },
                                )),
                            ..
                        },
                    ],
                ),
            ..
        }) => Some((*hir_id1, *hir_id2, *fun_id)),
        _ => None,
    }
}

fn invariant_block_to_vir<'tcx>(
    bctx: &BodyCtxt<'tcx>,
    expr: &Expr<'tcx>,
) -> Result<ExprOrPlace, VirErr> {
    // The open_atomic_invariant! macro produces code that looks like this
    // (and similarly for open_local_invariant!)
    //
    // #[verifier(invariant_block)] {
    //      spend_open_invariant_credit($credit_expr);
    //      let (guard, mut $inner) = open_atomic_invariant_begin($eexpr);
    //      $bblock
    //      open_invariant_end(guard, $inner);
    //  }
    //
    // We need to check that it really does have this form, including
    // that the identifiers `guard` and `inner` used in the last statement
    // are the same as in the first statement. This is what the giant
    // `match` statements below are for.
    //
    // We also need to "recover" the $inner, $eexpr, and $bblock for conversion to VIR.
    //
    // If the AST doesn't look exactly like we expect, print an error asking the user
    // to use the open_atomic_invariant! macro.

    let body = match &expr.kind {
        ExprKind::Block(body, None) => body,
        _ => panic!("invariant_block_to_vir called with non-Body expression"),
    };

    if body.stmts.len() != 4 || body.expr.is_some() {
        return malformed_inv_block_err(expr);
    }

    let spend_stmt = &body.stmts[0];
    let open_stmt = &body.stmts[1];
    let mid_stmt = &body.stmts[2];
    let close_stmt = &body.stmts[3];

    if !is_spend_open_invariant_credit_call(&bctx.ctxt.verus_items, spend_stmt) {
        return malformed_inv_block_err(expr);
    }

    let (guard_hir, inner_hir, inner_pat, inv_arg, atomicity) = {
        if let Some(block_open) = invariant_block_open(&bctx.ctxt.verus_items, open_stmt) {
            block_open
        } else {
            return malformed_inv_block_err(expr);
        }
    };

    if let Some((hir_id1, hir_id2, fun_id)) = invariant_block_close(close_stmt) {
        let verus_item = bctx.ctxt.verus_items.id_to_name.get(&fun_id);
        if verus_item
            != Some(&VerusItem::OpenInvariantBlock(OpenInvariantBlockItem::OpenInvariantEnd))
        {
            return malformed_inv_block_err(expr);
        }

        if hir_id1 != guard_hir || hir_id2 != inner_hir {
            return malformed_inv_block_err(expr);
        }
    } else {
        return malformed_inv_block_err(expr);
    }

    let (vir_body, block_hir_id) = match mid_stmt.kind {
        StmtKind::Expr(e @ Expr { kind: ExprKind::Block(body, None), .. }) => {
            assert!(!is_invariant_block(bctx, e)?);
            let vir_stmts: Stmts = Arc::new(
                slice_vec_map_result(body.stmts, |stmt| stmt_to_vir(bctx, stmt))?
                    .into_iter()
                    .flatten()
                    .collect(),
            );
            let vir_expr = body.expr.map(|expr| expr_to_vir_consume(bctx, &expr)).transpose()?;
            let ty = typ_of_node_unadjusted(bctx, e.span, &e.hir_id)?;
            // NOTE: we use body.span here instead of e.span
            // body.span leads to better error messages
            // (e.g., the "Cannot show invariant holds at end of block" error)
            // (e.span or mid_stmt.span would expose macro internals)
            let vir_body =
                bctx.spanned_typed_new(body.span, &ty, ExprX::Block(vir_stmts, vir_expr));
            (vir_body, body.hir_id)
        }
        _ => {
            return malformed_inv_block_err(expr);
        }
    };

    if matches!(atomicity, InvAtomicity::NonAtomic) {
        let mut erasure_info = bctx.ctxt.erasure_info.borrow_mut();
        erasure_info.local_invariant_bodies.push(
            rustc_mir_build_verus::verus::LocalInvariantBody {
                inner_block_hir_id: block_hir_id,
                span: expr.span,
                guard_var: rustc_middle::thir::LocalVarId(guard_hir),
            },
        );
    }

    let vir_arg = expr_to_vir_consume(bctx, &inv_arg)?;

    let name = pat_to_var(inner_pat)?;
    let inner_ty = typ_of_node_unadjusted(bctx, inner_pat.span, &inner_hir)?;
    let vir_binder = Arc::new(VarBinderX { name, a: inner_ty });

    let mid_exp = bctx.spanned_typed_new(
        mid_stmt.span,
        &typ_of_node_unadjusted(bctx, expr.span, &expr.hir_id)?,
        ExprX::OpenInvariant(vir_arg, vir_binder, vir_body, atomicity),
    );
    let spend_stmt_vir = stmt_to_vir(&bctx, spend_stmt)
        .expect("could not convert spend_open_invariant_credit call to vir");
    Ok(ExprOrPlace::Expr(bctx.spanned_typed_new(
        expr.span,
        &typ_of_node_unadjusted(bctx, expr.span, &expr.hir_id)?,
        ExprX::Block(Arc::new(spend_stmt_vir), Some(mid_exp)),
    )))
}

fn is_open_au_block(bctx: &BodyCtxt, expr: &Expr) -> Result<bool, VirErr> {
    let hir_attrs = bctx.ctxt.tcx.hir_attrs(expr.hir_id);
    let vir_attrs = parse_attrs(hir_attrs, None)?;
    Ok(vir_attrs.contains(&Attr::AtomicUpdateBlock))
}

fn malformed_au_block_err<'tcx, X>(expr: &Expr<'tcx>, line: u32) -> Result<X, VirErr> {
    err_span(
        expr.span,
        format!(
            "malformed atomic update block; use `try_open_atomic_update!` macro instead ({line})"
        ),
    )
}

fn open_au_block_to_vir<'tcx>(
    bctx: &BodyCtxt<'tcx>,
    expr: &Expr<'tcx>,
) -> Result<ExprOrPlace, VirErr> {
    // ```
    // #[verifier::open_au_block] {
    //     let guard = try_open_atomic_update_begin($au);
    //     let $x = bind_lifetime_internal(&guard);
    //     let res = $body;
    //     match res {
    //         res => try_open_atomic_update_end(guard, res),
    //         ..?
    //     }
    // }
    // ```

    let ExprKind::Block(block, _) = expr.kind else {
        panic!("expr should be a block expression");
    };

    let Block { stmts: [open_stmt, bind_stmt, mid_stmt], expr: Some(close_expr), .. } = block
    else {
        return malformed_au_block_err(expr, line!());
    };

    // ```
    // let (guard, $x) = try_open_atomic_update_begin($au);
    // ```
    let StmtKind::Let(LetStmt {
        pat:
            Pat {
                kind: PatKind::Binding(BindingMode(ByRef::No, Mutability::Not), guard_bind, _, None),
                default_binding_modes: true,
                ..
            },
        init:
            Some(Expr {
                kind:
                    ExprKind::Call(
                        Expr {
                            kind:
                                ExprKind::Path(QPath::Resolved(
                                    None,
                                    rustc_hir::Path {
                                        res: Res::Def(DefKind::Fn, begin_fun_id),
                                        ..
                                    },
                                )),
                            ..
                        },
                        [au_arg, ..],
                    ),
                ..
            }),
        els: None,
        ..
    }) = open_stmt.kind
    else {
        return malformed_au_block_err(expr, line!());
    };

    let Some(&VerusItem::OpenAtomicUpdate(OpenAtomicUpdateItem::TryOpenAtomicUpdateBegin)) =
        bctx.ctxt.verus_items.id_to_name.get(begin_fun_id)
    else {
        return malformed_au_block_err(expr, line!());
    };

    // ```
    // let $x = bind_lifetime_internal(&guard, x);
    // ```
    let StmtKind::Let(LetStmt {
        pat:
            x_pat @ Pat {
                kind: PatKind::Binding(BindingMode(ByRef::No, _), x_bind, _, None),
                default_binding_modes: true,
                ..
            },
        init: Some(_),
        els: None,
        ..
    }) = bind_stmt.kind
    else {
        dbg!(bind_stmt.kind);
        return malformed_au_block_err(expr, line!());
    };

    // ```
    // let res = $body;
    // ```
    let StmtKind::Let(LetStmt {
        pat:
            Pat {
                kind: PatKind::Binding(BindingMode(ByRef::No, Mutability::Not), res_bind, _, None),
                default_binding_modes: true,
                ..
            },
        init: Some(body_expr @ Expr { kind: ExprKind::Block(body_block, None), .. }),
        els: None,
        ..
    }) = mid_stmt.kind
    else {
        return malformed_au_block_err(expr, line!());
    };

    // ```
    // match res {
    //     res => ...,
    // }
    // ```
    let ExprKind::Match(
        Expr {
            kind:
                ExprKind::Path(QPath::Resolved(
                    None,
                    rustc_hir::Path { res: Res::Local(res_proxy_use), .. },
                )),
            ..
        },
        [
            rustc_hir::Arm {
                pat:
                    Pat {
                        kind:
                            PatKind::Binding(
                                BindingMode(ByRef::No, Mutability::Not),
                                res_proxy_bind,
                                _,
                                None,
                            ),
                        default_binding_modes: true,
                        ..
                    },
                guard: None,
                body: match_arm_body,
                ..
            },
            ..,
        ],
        _,
    ) = close_expr.kind
    else {
        return malformed_au_block_err(expr, line!());
    };

    if res_proxy_use != res_bind {
        return malformed_au_block_err(expr, line!());
    }

    let res_bind = res_proxy_bind;
    let close_expr = &**match_arm_body;

    // ```
    // try_open_atomic_update_end(guard, res)
    // ```
    let ExprKind::Call(
        Expr {
            kind:
                ExprKind::Path(QPath::Resolved(
                    None,
                    rustc_hir::Path { res: Res::Def(DefKind::Fn, end_fun_id), .. },
                )),
            ..
        },
        [
            Expr {
                kind:
                    ExprKind::Path(QPath::Resolved(
                        None,
                        rustc_hir::Path { res: Res::Local(guard_use), .. },
                    )),
                ..
            },
            Expr {
                kind:
                    ExprKind::Path(QPath::Resolved(
                        None,
                        rustc_hir::Path { res: Res::Local(res_use), .. },
                    )),
                ..
            },
        ],
    ) = close_expr.kind
    else {
        return malformed_au_block_err(expr, line!());
    };

    let Some(&VerusItem::OpenAtomicUpdate(OpenAtomicUpdateItem::TryOpenAtomicUpdateEnd)) =
        bctx.ctxt.verus_items.id_to_name.get(end_fun_id)
    else {
        return malformed_au_block_err(expr, line!());
    };

    if res_bind != res_use || guard_bind != guard_use {
        return malformed_au_block_err(expr, line!());
    }

    let mut vir_stmts = Vec::new();
    for stmt in body_block.stmts {
        vir_stmts.extend(stmt_to_vir(bctx, stmt)?);
    }

    let vir_body = bctx.spanned_typed_new(
        body_block.span,
        &typ_of_node_unadjusted(bctx, body_expr.span, &body_expr.hir_id)?,
        ExprX::Block(
            Arc::new(vir_stmts),
            body_block.expr.map(|expr| expr_to_vir_consume(bctx, &expr)).transpose()?,
        ),
    );

    let au_vir_arg = expr_to_vir_consume(bctx, au_arg)?;
    let au_vir_binder = Arc::new(VarBinderX {
        name: pat_to_var(x_pat)?,
        a: typ_of_node_unadjusted(bctx, x_pat.span, x_bind)?,
    });

    let mid_exp = bctx.spanned_typed_new(
        mid_stmt.span,
        &typ_of_node_unadjusted(bctx, expr.span, &expr.hir_id)?,
        ExprX::TryOpenAtomicUpdate(au_vir_arg, au_vir_binder, vir_body),
    );

    Ok(ExprOrPlace::Expr(bctx.spanned_typed_new(
        expr.span,
        &typ_of_node_unadjusted(bctx, expr.span, &expr.hir_id)?,
        ExprX::Block(Default::default(), Some(mid_exp)),
    )))
}

pub(crate) fn expr_to_vir_with_adjustments<'tcx>(
    bctx: &BodyCtxt<'tcx>,
    expr: &Expr<'tcx>,
    adjustments: &[Adjustment<'tcx>],
    adjustment_idx: usize,
) -> Result<ExprOrPlace, VirErr> {
    // Implicit conversions are stored in the "adjustments" for each node
    // See: https://doc.rust-lang.org/stable/nightly-rustc/rustc_middle/ty/adjustment/struct.Adjustment.html
    //
    // For example, suppose the user writes the expression `v` but Rust
    // inserts a borrow a deref so that we have to treat the node like `&*v`.
    //
    // Then we'd have:
    //
    //    adjustments[0] = Deref (*)
    //    adjustments[1] = Borrow (&)
    //
    // That is, the higher indices mean adjustments that are farther on the outside.
    //
    // The adjustment objects also have the type after each is applied, e.g.,
    //
    //    expr_ty(expr)                                    type of `v`
    //    adjustments[0].target                            type of `*v`
    //    adjumstmens[1].target = expr_ty_adjusted(expr)   type of `&*v`
    //
    // Since we're recursing inwards, we start with adjustment_idx = adjustments.len()
    // and decrement to recurse.
    // Specifically, the node (expr, i) means expr with the first i adjustments
    // applied. So (expr, i) has child node (expr, i - 1) which is obtained by
    // peeling off the adjustment (i-1).
    // Whereas the node (expr, 0) is just expr by itself.

    let expr_typ = || bctx.mid_ty_to_vir(expr.span, &adjustments[adjustment_idx - 1].target);

    if adjustment_idx == 0 {
        return expr_to_vir_innermost(bctx, expr);
    }

    // Gets the type of the *child* of the current node
    //
    // The `target` field gives the type *after* adjustment, so we need to get the
    // target of the previous adjustment. If this is already the first adjustment,
    // Use `expr_ty` which is the type of the expression with no adjustments applied.
    let get_inner_ty = || {
        if adjustment_idx == 1 {
            bctx.types.expr_ty(expr)
        } else {
            adjustments[adjustment_idx - 2].target
        }
    };

    let get_inner2_ty = || {
        if adjustment_idx == 2 {
            bctx.types.expr_ty(expr)
        } else {
            adjustments[adjustment_idx - 3].target
        }
    };

    let adjustment = &adjustments[adjustment_idx - 1];

    match &adjustment.kind {
        Adjust::NeverToAny => {
            let e = expr_to_vir_with_adjustments(bctx, expr, adjustments, adjustment_idx - 1)?
                .consume(bctx, get_inner_ty());
            let x = ExprX::NeverToAny(e);
            Ok(ExprOrPlace::Expr(bctx.spanned_typed_new(expr.span, &expr_typ()?, x)))
        }
        Adjust::Deref(DerefAdjustKind::Builtin) => {
            // handle same way as the UnOp::Deref case
            let inner_expr =
                expr_to_vir_with_adjustments(bctx, expr, adjustments, adjustment_idx - 1)?;
            let inner_ty = get_inner_ty();
            let inner_place = inner_expr.to_place(bctx, expr.span, inner_ty)?;
            let p = deref_primitive(bctx, expr.span, inner_ty, &inner_place)?;
            Ok(ExprOrPlace::Place(p))
        }
        Adjust::Deref(DerefAdjustKind::Overloaded(deref)) => {
            // note: deref has signature (&self) -> &Self::Target
            // and deref_mut has signature (&mut self) -> &mut Self::Target
            // The adjustment, though, goes from self -> Self::Target
            // without the refs.
            // We thus produce 3 operations in total:
            //  - Initial borrow (T -> &T) or (T -> &mut T)
            //  - Call to deref or deref_mut (gives us &Self::Target or &mut Self::Target)
            //  - A final dereference (giving us Self::Target)
            let inner = expr_to_vir_with_adjustments(bctx, expr, adjustments, adjustment_idx - 1)?;
            let mutbl = matches!(deref.mutbl, Mutability::Mut);

            let inner_ty = get_inner_ty();

            if let Some((ty, is_tracked)) =
                crate::rust_to_vir_base::is_tracked_or_ghost_ty(&bctx.ctxt.verus_items, inner_ty)
            {
                let mwm = if is_tracked {
                    vir::ast::ModeWrapperMode::Proof
                } else {
                    vir::ast::ModeWrapperMode::Spec
                };
                let typ = bctx.mid_ty_to_vir(expr.span, &ty)?;
                return Ok(ExprOrPlace::Place(bctx.spanned_typed_new(
                    expr.span,
                    &typ,
                    PlaceX::ModeUnwrap(inner.to_place(bctx, expr.span, inner_ty)?, mwm),
                )));
            }

            let ref_inner = if mutbl {
                let inner_place = inner.to_place(bctx, expr.span, inner_ty)?;
                borrow_mut_vir(bctx, expr.span, &inner_place, AllowTwoPhase::No)
            } else {
                inner.immut_bor(bctx, expr.span, inner_ty)?
            };
            let ref_inner_ty = bctx.ctxt.tcx.mk_ty_from_kind(TyKind::Ref(
                bctx.ctxt.tcx.lifetimes.re_erased,
                inner_ty,
                deref.mutbl,
            ));
            let out_ty = adjustment.target;
            let p = deref_overloaded(
                bctx,
                expr.span,
                deref.method_call(bctx.ctxt.tcx),
                ref_inner_ty,
                out_ty,
                &ref_inner,
            )?;
            Ok(ExprOrPlace::Place(p))
        }
        Adjust::Borrow(AutoBorrow::Ref(AutoBorrowMutability::Not)) => {
            // Similar to ExprKind::AddrOf
            let new_expr =
                expr_to_vir_with_adjustments(bctx, expr, adjustments, adjustment_idx - 1)?
                    .immut_bor(bctx, expr.span, get_inner_ty())?;
            Ok(ExprOrPlace::Expr(new_expr))
        }
        Adjust::Borrow(AutoBorrow::Ref(AutoBorrowMutability::Mut { allow_two_phase_borrow })) => {
            // Rust often inserts &mut* adjustments in argument positions.
            // e.g., `foo(a)` where `a: &mut T` really becomes `foo(&mut *a)`.
            // (This is done to force a reborrow.)
            // We actually don't want this in spec contexts, but we *do* want it in
            // exec/tracked contexts. So we need to handle this case specially.
            if bctx.in_ghost
                && adjustment_idx >= 2
                && matches!(
                    &adjustments[adjustment_idx - 2].kind,
                    Adjust::Deref(DerefAdjustKind::Builtin)
                )
            {
                let inner_inner_ty = get_inner2_ty();
                if matches!(inner_inner_ty.kind(), TyKind::Ref(_, _, rustc_ast::Mutability::Mut)) {
                    if inner_inner_ty != adjustment.target {
                        panic!("Verus Internal Error: Implicit &mut * expected the same type");
                    }
                    let inner_inner =
                        expr_to_vir_with_adjustments(bctx, expr, adjustments, adjustment_idx - 2)?;
                    if bctx.in_fn_sig || bctx.in_old {
                        // In some cases, we already know we can elide the reborrow
                        return Ok(inner_inner);
                    } else {
                        // In other cases, we need to delay the decision until mode checking
                        let p = inner_inner.to_place(bctx, expr.span, inner_inner_ty)?;
                        let b = match allow_two_phase_borrow {
                            AllowTwoPhase::Yes => true,
                            AllowTwoPhase::No => false,
                        };
                        let x = ExprX::ImplicitReborrowOrSpecRead(
                            p.clone(),
                            b,
                            bctx.ctxt.spans.to_air_span(expr.span),
                        );
                        let typ = bctx.mid_ty_to_vir(expr.span, &adjustment.target)?;
                        let e = bctx.spanned_typed_new(expr.span, &typ, x);
                        return Ok(ExprOrPlace::Expr(e));
                    }
                }
            }

            let place = expr_to_vir_with_adjustments(bctx, expr, adjustments, adjustment_idx - 1)?
                .to_place(bctx, expr.span, get_inner_ty())?;
            Ok(ExprOrPlace::Expr(borrow_mut_vir(bctx, expr.span, &place, *allow_two_phase_borrow)))
        }
        Adjust::GenericReborrow(_) => {
            unsupported_err!(expr.span, "User-defined Reborrow implementations")
        }
        Adjust::Borrow(AutoBorrow::RawPtr(_)) => {
            // Despite the name 'borrow', the docs seem to indicate this is a dereference
            unsupported_err!(
                expr.span,
                "dereferencing a pointer (here the dereference is implicit)"
            )
        }
        Adjust::Pointer(PointerCoercion::Unsize) => {
            let ty1 = get_inner_ty();
            let ty2 = adjustment.target;

            let arg = expr_to_vir_with_adjustments(bctx, expr, adjustments, adjustment_idx - 1)?;

            // rustc can emit no-op Pointer(Unsize) adjustments. If this is
            // lowered into a visible `ToDyn`, facts about the original value
            // are not propagated through the coercion, as in #2629.
            // Don't emit anything for no-op coercions.
            if ty1 == ty2 {
                return Ok(ExprOrPlace::Expr(arg.consume(bctx, ty1)));
            }

            let (tyr1, tyr2) = match (ty1.kind(), ty2.kind()) {
                (TyKind::Ref(_, t1, Mutability::Mut), TyKind::Ref(_, t2, Mutability::Mut))
                    if matches!(
                        (t1.kind(), t2.kind()),
                        (TyKind::Dynamic(..), TyKind::Dynamic(..))
                    ) =>
                {
                    unsupported_err!(
                        expr.span,
                        format!("trait upcasting from `{ty1:}` to `{ty2:}`")
                    )
                }
                // &mut T -> &mut dyn Trait: keep the &mut so ast_to_sst can build a new borrow
                (TyKind::Ref(_, t1, Mutability::Mut), TyKind::Ref(_, t2, Mutability::Mut))
                    if matches!(t2.kind(), TyKind::Dynamic(..)) =>
                {
                    (*t1, *t2)
                }
                _ => remove_decoration_typs_for_unsizing(bctx.ctxt.tcx, ty1, ty2),
            };
            let op = match (tyr1.kind(), tyr2.kind()) {
                (_, TyKind::Dynamic(preds, _)) => {
                    let vir_ty = bctx.mid_ty_to_vir(expr.span, &tyr1)?;
                    let clauses = preds
                        .principal()
                        .map(|trait_ref| {
                            let clause = trait_ref
                                .map_bound(|trait_ref| {
                                    ClauseKind::Trait(TraitPredicate {
                                        trait_ref: trait_ref.with_self_ty(bctx.ctxt.tcx, tyr1),
                                        polarity: rustc_middle::ty::PredicatePolarity::Positive,
                                    })
                                })
                                .upcast(bctx.ctxt.tcx);
                            (None, clause)
                        })
                        .into_iter()
                        .collect();
                    let impl_paths = get_impl_paths_for_clauses(
                        bctx.ctxt.tcx,
                        &bctx.ctxt.verus_items,
                        bctx.fun_id,
                        clauses,
                        None,
                        expr.span,
                    )?;
                    Some(UnaryOpr::ToDyn(vir_ty, impl_paths))
                }
                _ => None,
            };
            if let Some(op) = op {
                let arg = arg.consume(bctx, get_inner_ty());
                let x = ExprX::UnaryOpr(op, arg);
                let expr_typ = bctx.mid_ty_to_vir(expr.span, &ty2)?;
                return Ok(ExprOrPlace::Expr(bctx.spanned_typed_new(expr.span, &expr_typ, x)));
            }

            let f = match (ty1.kind(), ty2.kind()) {
                (TyKind::RawPtr(t1, _), TyKind::RawPtr(t2, _)) => {
                    match (t1.kind(), t2.kind()) {
                        (TyKind::Array(el_ty1, _const_len), TyKind::Slice(el_ty2)) => {
                            if el_ty1 == el_ty2 {
                                // coercing from *mut [el_ty, const_len] -> *mut [el_ty]
                                // (either *mut or *const is ok)
                                if bctx.ctxt.no_vstd {
                                    return err_span(
                                        expr.span,
                                        "Coercing an array to a slice is not supported with --no-vstd",
                                    );
                                }
                                let fun = vir::fun!(CrateId::Vstd => "raw_ptr", "cast_array_ptr_to_slice_ptr");

                                let arg_typ = undecorate_typ(arg.typ());
                                let array_typ = match &*arg_typ {
                                    TypX::Primitive(Primitive::Ptr, typs) => &typs[0],
                                    _ => {
                                        crate::internal_err!(expr.span, "expected Primitive::Ptr")
                                    }
                                };
                                let typ_args = match &*undecorate_typ(array_typ) {
                                    TypX::Primitive(Primitive::Array, typs) => typs.clone(),
                                    _ => {
                                        crate::internal_err!(expr.span, "expected array")
                                    }
                                };
                                Some((fun, typ_args))
                            } else {
                                None
                            }
                        }
                        _ => None,
                    }
                }
                (TyKind::Ref(_, t1, Mutability::Mut), TyKind::Ref(_, t2, Mutability::Mut)) => {
                    match (t1.kind(), t2.kind()) {
                        (TyKind::Array(el_ty1, _const_len), TyKind::Slice(el_ty2))
                            if el_ty1 == el_ty2 =>
                        {
                            let fun = vir::fun!(CrateId::Vstd => "array", "ref_mut_array_unsizing_coercion");
                            let array_typ = match &**arg.typ() {
                                TypX::MutRef(typ) => typ,
                                _ => crate::internal_err!(expr.span, "expected TypX::MutRef"),
                            };
                            let typ_args = match &**array_typ {
                                TypX::Primitive(Primitive::Array, typs) => typs.clone(),
                                _ => crate::internal_err!(expr.span, "expected array"),
                            };
                            Some((fun, typ_args))
                        }
                        _ => None,
                    }
                }
                _ => {
                    let (ty1, ty2) = remove_decoration_typs_for_unsizing(bctx.ctxt.tcx, ty1, ty2);
                    match (ty1.kind(), ty2.kind()) {
                        (TyKind::Array(el_ty1, _const_len), TyKind::Slice(el_ty2)) => {
                            if el_ty1 == el_ty2 {
                                // coercing from &[el_ty, const_len] -> &[el_ty]
                                if bctx.ctxt.no_vstd {
                                    return err_span(
                                        expr.span,
                                        "Coercing an array to a slice is not supported with --no-vstd",
                                    );
                                }

                                // TODO(mut_refs): likely needs Place considerations
                                let fun = vir::fun!(CrateId::Vstd => "array", "array_as_slice");

                                let typ_args = match &*undecorate_typ(arg.typ()) {
                                    TypX::Primitive(Primitive::Array, typs) => typs.clone(),
                                    _ => {
                                        crate::internal_err!(expr.span, "expected array")
                                    }
                                };
                                Some((fun, typ_args))
                            } else {
                                None
                            }
                        }
                        _ => None,
                    }
                }
            };

            if let Some((fun, typ_args)) = f {
                let autospec_usage =
                    if bctx.in_ghost { AutospecUsage::IfMarked } else { AutospecUsage::Final };
                let call_target_attrs = vir::ast::CallTargetAttrs {
                    autospec: autospec_usage,
                    const_var: false,
                    assume_external_allowed: false,
                };
                let call_target = CallTarget::Fun(
                    vir::ast::CallTargetKind::Static,
                    fun,
                    typ_args,
                    Arc::new(vec![]),
                    call_target_attrs,
                );
                let arg = arg.consume(bctx, get_inner_ty());
                let args = Arc::new(vec![arg.clone()]);
                let x = ExprX::Call { target: call_target, args, post_args: None, body: None };
                let expr_typ = bctx.mid_ty_to_vir(expr.span, &ty2)?;
                Ok(ExprOrPlace::Expr(bctx.spanned_typed_new(expr.span, &expr_typ, x)))
            } else {
                unsupported_err!(
                    expr.span,
                    format!("unsizing operation from `{ty1:}` to `{ty2:}`")
                );
            }
        }
        Adjust::Pointer(PointerCoercion::MutToConstPointer) => {
            let new_expr =
                expr_to_vir_with_adjustments(bctx, expr, adjustments, adjustment_idx - 1)?;
            let mut new_expr = new_expr.consume(bctx, get_inner_ty());
            let typ = Arc::new(TypX::Decorate(
                vir::ast::TypDecoration::ConstPtr,
                None,
                new_expr.typ.clone(),
            ));
            Arc::make_mut(&mut new_expr).typ = typ;
            Ok(ExprOrPlace::Expr(new_expr))
        }
        Adjust::Pointer(_cast) => {
            unsupported_err!(expr.span, "casting a pointer (here the cast is implicit)")
        }
        Adjust::Deref(DerefAdjustKind::Pin) => {
            unsupported_err!(expr.span, "automatic deref of a pinned reference")
        }
        Adjust::Borrow(AutoBorrow::Pin(_)) => {
            unsupported_err!(expr.span, "borrowing a pinned reference")
        }
    }
}

/// Callers must guarantee that expr_vir is a vir representation of expr.
pub(crate) fn expr_cast_enum_int_to_vir<'tcx>(
    bctx: &BodyCtxt<'tcx>,
    expr: &'tcx Expr<'tcx>,
    place_vir: vir::ast::Place,
    mk_expr: impl Fn(ExprX) -> Result<vir::ast::Expr, vir::messages::Message>,
) -> Result<vir::ast::Expr, VirErr> {
    let tcx = bctx.ctxt.tcx;
    let ty = bctx.types.expr_ty_adjusted(expr);
    assert!(ty.is_enum());

    /*
    if let ExprKind::Path(qpath) = &expr.kind {
        let res = bctx.types.qpath_res(&qpath, expr.hir_id);
        if let Some((ctor, CtorKind::Const)) = resolve_ctor(bctx.ctxt.tcx, res) {
            assert!(ctor.kind == AdtKind::Enum);
            let adt = tcx.adt_def(ctor.adt_def_id);
            let idx = adt.variant_index_with_id(ctor.variant_def.def_id);
            let val = adt.discriminant_for_variant(tcx, idx).val;
            return mk_expr(ExprX::Const(vir::ast_util::const_int_from_u128(val)));
        }
    }
    */

    let TyKind::Adt(adt, _) = ty.kind() else {
        unreachable!();
    };
    let mut vir_arms: Vec<vir::ast::Arm> = Vec::new();
    for (idx, vdef) in adt.variants().iter_enumerated() {
        let rustc_middle::ty::util::Discr { val, ty } = adt.discriminant_for_variant(tcx, idx);
        let val = match ty.kind() {
            TyKind::Uint(uint_ty) => match uint_ty {
                UintTy::U8 | UintTy::U16 | UintTy::U32 | UintTy::U64 | UintTy::U128 => {
                    vir::ast_util::const_int_from_u128(val)
                }
                UintTy::Usize => {
                    if val > u32::MAX as u128 {
                        unsupported_err!(
                            expr.span,
                            "discriminant does not fit in 32-bits when usize is used"
                        )
                    }
                    vir::ast_util::const_int_from_u128(val)
                }
            },
            TyKind::Int(int_ty) => match int_ty {
                IntTy::I8 => vir::ast_util::const_int_from_i128(val as i8 as i128),
                IntTy::I16 => vir::ast_util::const_int_from_i128(val as i16 as i128),
                IntTy::I32 => vir::ast_util::const_int_from_i128(val as i32 as i128),
                IntTy::I64 => vir::ast_util::const_int_from_i128(val as i64 as i128),
                IntTy::I128 => vir::ast_util::const_int_from_i128(val as i128),
                IntTy::Isize => {
                    let v = val as isize as i128;
                    if !(v >= i32::MIN as i128 && v <= i32::MAX as i128) {
                        unsupported_err!(
                            expr.span,
                            "discriminant does not fit in 32-bits when isize is used"
                        )
                    }
                    vir::ast_util::const_int_from_i128(v)
                }
            },
            _ => unsupported_err!(
                expr.span,
                format!("discriminant of enum when enum has type {:?}", ty)
            ),
        };
        let cast_to = mk_expr(ExprX::Const(val))?;
        unsupported_err_unless!(
            vdef.fields.len() == 0,
            expr.span,
            "Enum variant should not contain any fields."
        );
        let variant_name = vdef.name.to_string();
        let (adt_path, _) =
            crate::fn_call_to_vir::check_variant_field(bctx, expr.span, expr, &variant_name, None)?;

        let pattern = bctx.spanned_typed_new(
            expr.span,
            &place_vir.typ,
            PatternX::Constructor(adt_path, Arc::new(variant_name), Arc::new(vec![])),
        );
        let guard =
            bctx.spanned_typed_new(expr.span, &bool_typ(), ExprX::Const(Constant::Bool(true)));
        let body = cast_to;
        let vir_arm = bctx.spanned_new(expr.span, ArmX { pattern, guard, body });
        vir_arms.push(vir_arm);
    }
    unsupported_err_unless!(vir_arms.len() > 0, expr.span, "Zero-sized empty Enum expr");
    return Ok(mk_expr(ExprX::Match(place_vir, Arc::new(vir_arms), false))?);
}

pub(crate) fn expr_to_vir_innermost<'tcx>(
    bctx: &BodyCtxt<'tcx>,
    expr: &Expr<'tcx>,
) -> Result<ExprOrPlace, VirErr> {
    let bctx = if matches!(&expr.kind, ExprKind::Loop(..)) {
        &bctx.set_header_setting(HeaderSetting::Loop(expr.hir_id))
    } else {
        bctx
    };

    let tcx = bctx.ctxt.tcx;
    let tc = bctx.types;
    let expr_typ = || typ_of_node_unadjusted(bctx, expr.span, &expr.hir_id);
    let mk_expr =
        move |x: ExprX| Ok(ExprOrPlace::Expr(bctx.spanned_typed_new(expr.span, &expr_typ()?, x)));

    let mk_lit_int = |in_negative_literal: bool, i: u128, typ: Typ| {
        check_lit_int(&bctx.ctxt, expr.span, in_negative_literal, i, &typ)?;
        let c = vir::ast_util::const_int_from_u128(i);
        mk_expr(ExprX::Const(c))
    };

    let cond_let_expr_to_vir_match = |cond: &Expr<'tcx>,
                                      lhs_body,
                                      lhs_span,
                                      rhs_body,
                                      rhs_span|
     -> Result<ExprX, VirErr> {
        let ExprKind::Let(LetExpr { pat, init: expr, .. }) = &cond.kind else {
            panic!("Expected let expression");
        };
        // if let
        let vir_place = expr_to_vir_place(bctx, expr)?;
        let vir_place = simplify_place_by_cancelling(&vir_place);
        let mut vir_arms: Vec<vir::ast::Arm> = Vec::new();
        /* lhs */
        {
            let pattern = pattern_to_vir(bctx, pat)?;
            let guard =
                bctx.spanned_typed_new(expr.span, &bool_typ(), ExprX::Const(Constant::Bool(true)));
            let vir_arm = ArmX { pattern, guard, body: lhs_body };
            vir_arms.push(bctx.spanned_new(lhs_span, vir_arm));
        }
        /* rhs */
        {
            let pat_typ = vir_arms[0].x.pattern.typ.clone();
            let pattern = bctx.spanned_typed_new(cond.span, &pat_typ, PatternX::Wildcard);
            let guard =
                bctx.spanned_typed_new(expr.span, &bool_typ(), ExprX::Const(Constant::Bool(true)));
            let vir_arm = ArmX { pattern, guard, body: rhs_body };
            vir_arms.push(bctx.spanned_new(rhs_span, vir_arm));
        }
        Ok(ExprX::Match(vir_place, Arc::new(vir_arms), false))
    };

    let expr_attrs = bctx.ctxt.tcx.hir_attrs(expr.hir_id);
    let expr_vattrs = bctx.ctxt.get_verifier_attrs(expr_attrs)?;
    if expr_vattrs.truncate {
        if !match &expr.kind {
            ExprKind::Cast(_, _) => true,
            ExprKind::Call(target, _) => match &target.kind {
                ExprKind::Path(qpath) => {
                    let def = bctx.types.qpath_res(&qpath, expr.hir_id);
                    match def {
                        rustc_hir::def::Res::Def(_, def_id) => {
                            bctx.ctxt.verus_items.id_to_name.get(&def_id)
                                == Some(&VerusItem::UnaryOp(UnaryOpItem::SpecCastInteger))
                        }
                        _ => false,
                    }
                }
                _ => false,
            },
            _ => false,
        } {
            return err_span(
                expr.span,
                "the attribute #[verifier::truncate] is only allowed on casts (you may need parentheses around the cast)",
            );
        }
    }

    let loop_isolation = {
        if let Some(b) = expr_vattrs.loop_isolation {
            b
        } else {
            crate::attributes::get_loop_isolation_walk_parents(bctx.ctxt.tcx, bctx.fun_id)
                .unwrap_or(true)
        }
    };

    let allow_complex_invariants = || {
        if expr_vattrs.allow_complex_invariants {
            true
        } else {
            crate::attributes::get_allow_complex_invariants_walk_parents(bctx.ctxt.tcx, bctx.fun_id)
                .unwrap_or(false)
        }
    };

    match &expr.kind {
        ExprKind::Block(body, label) => {
            unsupported_err_unless!(label.is_none(), expr.span, "block with label");
            if is_invariant_block(bctx, expr)? {
                return invariant_block_to_vir(bctx, expr);
            }

            if is_open_au_block(bctx, expr)? {
                return open_au_block_to_vir(bctx, expr);
            }

            if let Some(g_attr) = get_ghost_block_opt(bctx.ctxt.tcx.hir_attrs(expr.hir_id)) {
                let bctx = &BodyCtxt { in_ghost: true, ..bctx.clone() };
                let block = block_to_vir(bctx, body, &expr.span, &expr_typ()?)?;
                let tracked = match g_attr {
                    GhostBlockAttr::Proof => false,
                    GhostBlockAttr::Tracked => true,
                    GhostBlockAttr::GhostWrapped | GhostBlockAttr::TrackedWrapped => {
                        return Ok(ExprOrPlace::Expr(block));
                    }
                    GhostBlockAttr::Wrapper => {
                        return err_span(expr.span, "unexpected ghost block wrapper");
                    }
                };
                mk_expr(ExprX::Ghost { alloc_wrapper: false, tracked, expr: block })
            } else {
                let block = block_to_vir(bctx, body, &expr.span, &expr_typ()?)?;
                if crate::attributes::is_proof_in_spec(bctx.ctxt.tcx.hir_attrs(expr.hir_id)) {
                    mk_expr(ExprX::ProofInSpec(block))
                } else if crate::attributes::is_loop_isolation_boundary(
                    bctx.ctxt.tcx.hir_attrs(expr.hir_id),
                ) {
                    let (wrap, label) = loop_isolation_boundary_check(expr.span, &block)?;
                    let block = if wrap {
                        let x = ExprX::UnaryOpr(UnaryOpr::LoopIsolationBoundary(label), block);
                        bctx.spanned_typed_new(expr.span, &expr_typ()?, x)
                    } else {
                        block
                    };
                    Ok(ExprOrPlace::Expr(block))
                } else {
                    Ok(ExprOrPlace::Expr(block))
                }
            }
        }
        ExprKind::Call(fun, args_slice) => {
            let res = match &fun.kind {
                ExprKind::Path(qpath) => {
                    let res = bctx.types.qpath_res(&qpath, fun.hir_id);
                    let ctor_opt = resolve_ctor(bctx.ctxt.tcx, res);
                    match (res, ctor_opt) {
                        (_, Some((ctor, CtorKind::Fn))) => Some(expr_tuple_datatype_ctor_to_vir(
                            bctx,
                            expr,
                            ctor,
                            *args_slice,
                            fun.span,
                        )?),
                        // a statically resolved function
                        (rustc_hir::def::Res::Def(_, def_id), _) => {
                            // this is necessary because we seemingly are skipping the deprecation check
                            // for free functions
                            tcx.check_stability(def_id, Some(expr.hir_id), expr.span, None);

                            let args = args_slice.iter().collect();
                            Some(fn_call_to_vir(
                                bctx,
                                expr,
                                def_id,
                                bctx.types.node_args(fun.hir_id),
                                fun.span,
                                args,
                                false,
                            )?)
                        }
                        (rustc_hir::def::Res::Local(local_hir_id), _) => {
                            match bctx.atomically.as_deref() {
                                Some(actx) if actx.update_binder == local_hir_id => {
                                    let vir_span = crate::spans::err_air_span(expr.span);
                                    actx.call_spans.send(vir_span).unwrap();
                                    let [input] = args_slice else {
                                        panic!("update function should have exactly one parameter")
                                    };

                                    let arg = expr_to_vir_consume(bctx, input)?;
                                    Some(bctx.spanned_typed_new(
                                        fun.span,
                                        &expr_typ()?,
                                        ExprX::Update(arg),
                                    ))
                                }

                                // dynamically computed function, see below
                                _ => None,
                            }
                        }
                        _ => {
                            unsupported_err!(
                                expr.span,
                                format!("function call {:?} {:?}", res, expr)
                            )
                        }
                    }
                }
                // dynamically computed function, see below
                _ => None,
            };
            match res {
                Some(res) => Ok(ExprOrPlace::Expr(res)),
                None => {
                    // a dynamically computed function
                    if bctx.external_body {
                        return mk_expr(ExprX::Block(Arc::new(vec![]), None));
                    }

                    // For FnMut, Rust automatically inserts a mutable reference, e.g.,
                    // (&mut f).call(...)
                    // We currently don't encode this as a mutation on the caller's side, though.
                    // So here, we pretend to dereference the object if it's a mut reference.
                    let fun_ty = bctx.types.expr_ty_adjusted(fun);
                    let vir_fun = expr_to_vir_consume(bctx, fun)?;

                    let args: Vec<&'tcx Expr<'tcx>> = args_slice.iter().collect();
                    let vir_args = vec_map_result(&args, |arg| expr_to_vir_consume(bctx, arg))?;
                    let expr_typ = typ_of_node_unadjusted(bctx, expr.span, &expr.hir_id)?;

                    let proof_fn = crate::rust_to_vir_base::try_get_proof_fn_modes(
                        &bctx.ctxt, expr.span, &fun_ty,
                    )?;
                    let is_proof_fun = proof_fn.is_some();
                    let is_spec_fn = match &*undecorate_typ(&vir_fun.typ) {
                        TypX::SpecFn(..) => true,
                        _ => false,
                    };

                    let (target, vir_args, resolved_call) = if is_spec_fn {
                        (CallTarget::FnSpec(vir_fun), vir_args, ResolvedCall::SpecPure)
                    } else {
                        if bctx.ctxt.no_vstd {
                            return err_span(
                                expr.span,
                                "Non-static calls are not supported with --no-vstd",
                            );
                        }

                        // non-static calls are translated into a static call to
                        // `exec_nonstatic_call` which is defined in the vstd lib.
                        let span = bctx.ctxt.spans.to_air_span(expr.span.clone());
                        let tup = vir::ast_util::mk_tuple(&span, &Arc::new(vir_args));
                        let helper_fun = vir::def::nonstatic_call_fun(is_proof_fun);
                        let ret_typ = expr_typ.clone();

                        // Anything that goes in `typ_args` needs to have the correct
                        // decoration, so call mid_ty_to_vir for these
                        // Compute `tup_typ` with the correct decoration:
                        let mut arg_typs = vec![];
                        for arg in args.iter() {
                            arg_typs.push(
                                bctx.mid_ty_to_vir(arg.span, &bctx.types.expr_ty_adjusted(arg))?,
                            );
                        }
                        let tup_typ = mk_tuple_typ(&Arc::new(arg_typs));

                        // Compute fun_typ with the correct decoration
                        // (technically not needed since the fun_typ decoration gets
                        // ignored later, but for consistency with other typ_args I
                        // decided to get the decorated version)
                        // Also, allow &mut refs here since that can happen for FnMut.
                        let fun_typ = bctx.mid_ty_to_vir(fun.span, &fun_ty)?;

                        let (kind, rcall) = if let Some((arg_modes, ret_mode)) = proof_fn {
                            if arg_modes.len() != args.len() {
                                return err_span(
                                    expr.span,
                                    "could not read mode annotations from proof_fn type",
                                );
                            }
                            let arg_modes = Arc::new(arg_modes);
                            let r = ResolvedCall::NonStaticProof(arg_modes.clone());
                            let k = vir::ast::CallTargetKind::ProofFn(arg_modes, ret_mode);
                            (k, r)
                        } else {
                            (vir::ast::CallTargetKind::Static, ResolvedCall::NonStaticExec)
                        };

                        // Get impl_paths for the trait bound
                        // fun_ty : FnOnce<Args>
                        let generic_arg0 = GenericArg::from(fun_ty);
                        let generic_arg1 = GenericArg::from(
                            tcx.mk_ty_from_kind(TyKind::Tuple(
                                tcx.mk_type_list(
                                    &args
                                        .iter()
                                        .map(|arg| bctx.types.expr_ty_adjusted(arg))
                                        .collect::<Vec<_>>(),
                                ),
                            )),
                        );
                        let clause =
                            rustc_middle::ty::Binder::dummy(ClauseKind::Trait(TraitPredicate {
                                trait_ref: TraitRef::new(
                                    tcx,
                                    tcx.lang_items().fn_once_trait().unwrap(),
                                    [generic_arg0, generic_arg1],
                                ),
                                polarity: rustc_middle::ty::PredicatePolarity::Positive,
                            }))
                            .upcast(tcx);
                        let impl_paths = get_impl_paths_for_clauses(
                            tcx,
                            &bctx.ctxt.verus_items,
                            bctx.fun_id,
                            vec![(None, clause)],
                            None,
                            expr.span,
                        )?;

                        let typ_args = Arc::new(vec![tup_typ, ret_typ, fun_typ]);
                        let call_target_attrs = vir::ast::CallTargetAttrs {
                            autospec: AutospecUsage::Final,
                            const_var: false,
                            assume_external_allowed: false,
                        };
                        (
                            CallTarget::Fun(
                                kind,
                                helper_fun,
                                typ_args,
                                impl_paths,
                                call_target_attrs,
                            ),
                            vec![vir_fun, tup],
                            rcall,
                        )
                    };

                    {
                        let mut erasure_info = bctx.ctxt.erasure_info.borrow_mut();
                        erasure_info.resolved_calls.push((
                            expr.hir_id,
                            fun.span.data(),
                            resolved_call,
                            bctx.in_ghost,
                        ));
                    }

                    Ok(ExprOrPlace::Expr(bctx.spanned_typed_new(
                        expr.span,
                        &expr_typ,
                        ExprX::Call {
                            target,
                            args: Arc::new(vir_args),
                            post_args: None,
                            body: None,
                        },
                    )))
                }
            }
        }
        ExprKind::Tup(exprs) => {
            let args: Result<Vec<vir::ast::Expr>, VirErr> =
                exprs.iter().map(|e| expr_to_vir_consume(bctx, e)).collect();
            mk_expr(mk_tuple_x(&Arc::new(args?)))
        }
        ExprKind::Array(exprs) => {
            if bctx.ctxt.no_vstd {
                return err_span(expr.span, "Array literals are not supported with --no-vstd");
            }
            let args: Result<Vec<vir::ast::Expr>, VirErr> =
                exprs.iter().map(|e| expr_to_vir_consume(bctx, e)).collect();
            mk_expr(ExprX::ArrayLiteral(Arc::new(args?)))
        }
        ExprKind::Repeat(e, _array_len) => {
            if bctx.ctxt.no_vstd {
                return err_span(expr.span, "Array literals are not supported with --no-vstd");
            }
            let ty = bctx.types.expr_ty_adjusted(e);
            let is_copy =
                tcx.type_is_copy_modulo_regions(TypingEnv::post_analysis(tcx, bctx.fun_id), ty);
            if is_copy {
                let arg_vir = expr_to_vir_consume(bctx, e)?;
                let fun = vir::fun!(CrateId::Vstd => "array", "array_fill_for_copy_types");
                let array_vir_typ = bctx.mid_ty_to_vir(expr.span, &bctx.types.expr_ty(expr))?;
                let typ_args = match &*array_vir_typ {
                    TypX::Primitive(Primitive::Array, typs) => typs.clone(),
                    _ => {
                        crate::internal_err!(expr.span, "expected Primitive::Array")
                    }
                };
                let autospec_usage =
                    if bctx.in_ghost { AutospecUsage::IfMarked } else { AutospecUsage::Final };
                let call_target_attrs = vir::ast::CallTargetAttrs {
                    autospec: autospec_usage,
                    const_var: false,
                    assume_external_allowed: false,
                };
                let call_target = CallTarget::Fun(
                    vir::ast::CallTargetKind::Static,
                    fun,
                    typ_args,
                    Arc::new(vec![]),
                    call_target_attrs,
                );
                let args = Arc::new(vec![arg_vir.clone()]);
                mk_expr(ExprX::Call { target: call_target, args, post_args: None, body: None })
            } else {
                // Could be a const. In this case the array needs to be translated like:
                //    forall |i| array[i] satisfies post-condition of const
                unsupported_err!(expr.span, format!("array-fill expresion with non-copy type"))
            }
        }
        ExprKind::Lit(lit) => Ok(ExprOrPlace::Expr(lit_to_vir(
            bctx,
            expr.span,
            *lit,
            false,
            &typ_of_node_unadjusted(bctx, expr.span, &expr.hir_id)?,
            Some(bctx.types.node_type(expr.hir_id)),
        )?)),
        ExprKind::Cast(source, _) => {
            let source_vir = expr_to_vir(bctx, source)?;

            let source_ty = bctx.types.expr_ty_adjusted(source);
            let source_vir_expr = source_vir.consume(bctx, source_ty);

            let source_vir_ty = &source_vir_expr.typ;
            let to_vir_ty = expr_typ()?;
            // If the source and destination types are the same, we don't need to do anything.
            // This case can show up unexpectedly. For example, in
            // `fn test(value: &u8) { let value = value as &dyn T; ... }`, the cast appears
            // non-trivial, but rustc inserts an explicit coercion on the source, making the
            // explicit `as` coercion trivial.
            if types_equal(source_vir_ty, &to_vir_ty) {
                return Ok(ExprOrPlace::Expr(source_vir_expr));
            }

            if let Some(expr) = maybe_do_ptr_cast(bctx, expr, source, &source_vir_expr)? {
                return Ok(ExprOrPlace::Expr(expr));
            }

            match (&*undecorate_typ(source_vir_ty), &*undecorate_typ(&to_vir_ty)) {
                (TypX::Int(_), TypX::Int(_)) => Ok(ExprOrPlace::Expr(mk_ty_clip(
                    bctx,
                    &to_vir_ty,
                    &source_vir_expr,
                    expr_vattrs.truncate,
                ))),
                (TypX::Bool, TypX::Int(_)) => {
                    let zero = mk_expr(ExprX::Const(vir::ast_util::const_int_from_u128(0)))?;
                    let one = mk_expr(ExprX::Const(vir::ast_util::const_int_from_u128(1)))?;
                    let zero = zero.expect_expr();
                    let one = one.expect_expr();
                    mk_expr(ExprX::If(source_vir_expr, one, Some(zero)))
                }
                (_, TypX::Int(_)) if bctx.types.expr_ty_adjusted(source).is_enum() => {
                    let mk_expr =
                        move |x: ExprX| Ok(bctx.spanned_typed_new(expr.span, &expr_typ()?, x));
                    let place = source_vir.to_place(bctx, expr.span, source_ty)?;
                    let place = simplify_place_by_cancelling(&place);
                    let cast_to = expr_cast_enum_int_to_vir(bctx, source, place, mk_expr)?;
                    Ok(ExprOrPlace::Expr(mk_ty_clip(
                        bctx,
                        &to_vir_ty,
                        &cast_to,
                        expr_vattrs.truncate,
                    )))
                }
                (TypX::Float(src_bits), TypX::Float(dst_bits)) if src_bits == dst_bits => {
                    // Same float type, identity cast
                    Ok(ExprOrPlace::Expr(source_vir_expr))
                }
                (t1 @ TypX::Float(_), t2 @ TypX::Float(_))
                | (t1 @ TypX::Int(_), t2 @ TypX::Float(_))
                | (t1 @ TypX::Float(_), t2 @ TypX::Int(_)) => {
                    let is_supported = |t: &TypX| match t {
                        TypX::Int(
                            IntRange::U(_) | IntRange::I(_) | IntRange::USize | IntRange::ISize,
                        ) => true,
                        TypX::Float(32 | 64) => true,
                        _ => false,
                    };
                    if !(is_supported(t1) && is_supported(t2)) {
                        return err_span(
                            expr.span,
                            format!(
                                "Verus does not support `as` cast from `{}` to `{}`",
                                typ_to_diagnostic_str(&source_vir_ty),
                                typ_to_diagnostic_str(&to_vir_ty),
                            ),
                        );
                    }
                    if bctx.ctxt.no_vstd {
                        return err_span(
                            expr.span,
                            "Float `as` cast is not supported with --no-vstd",
                        );
                    }
                    let fun = vir::fun!(CrateId::Vstd => "float", "float_cast");
                    let from_typ = undecorate_typ(source_vir_ty);
                    let to_typ = undecorate_typ(&to_vir_ty);
                    let typ_args = Arc::new(vec![from_typ, to_typ]);
                    let autospec_usage =
                        if bctx.in_ghost { AutospecUsage::IfMarked } else { AutospecUsage::Final };
                    let call_target_attrs = vir::ast::CallTargetAttrs {
                        autospec: autospec_usage,
                        const_var: false,
                        assume_external_allowed: false,
                    };
                    let call_target = CallTarget::Fun(
                        vir::ast::CallTargetKind::Static,
                        fun,
                        typ_args,
                        Arc::new(vec![]),
                        call_target_attrs,
                    );
                    let args = Arc::new(vec![source_vir_expr.clone()]);
                    mk_expr(ExprX::Call { target: call_target, args, post_args: None, body: None })
                }
                _ => {
                    let to_ty = bctx.types.expr_ty(expr);
                    return err_span(
                        expr.span,
                        format!(
                            "Verus does not support this cast: `{:#?}` to `{:#?}`",
                            source_ty, to_ty
                        ),
                    );
                }
            }
        }
        ExprKind::AddrOf(BorrowKind::Ref, Mutability::Not, e) => {
            let inner_ty = bctx.types.expr_ty_adjusted(e);
            let new_expr = expr_to_vir_inner(bctx, e)?.immut_bor(bctx, expr.span, inner_ty)?;
            Ok(ExprOrPlace::Expr(new_expr))
        }
        ExprKind::AddrOf(BorrowKind::Ref, Mutability::Mut, e) => {
            let place = expr_to_vir_place(bctx, e)?;
            Ok(ExprOrPlace::Expr(borrow_mut_vir(bctx, expr.span, &place, AllowTwoPhase::No)))
        }
        ExprKind::AddrOf(BorrowKind::Raw, _, _) => {
            unsupported_err!(expr.span, format!("raw borrows"))
        }
        ExprKind::OffsetOf(_container, _fields) => {
            unsupported_err!(expr.span, format!("offset_of!()"))
        }
        ExprKind::Unary(op, arg) => match op {
            UnOp::Not | UnOp::Neg => {
                let arg_ty = bctx.types.expr_ty_adjusted(arg);

                // ! bool
                if matches!(op, UnOp::Not) && ty_is_bool_or_ref_bool(arg_ty) {
                    let varg = expr_to_vir_consume(bctx, arg)?;
                    return mk_expr(ExprX::Unary(UnaryOp::Not, varg));
                }

                // ! integer type (bitwise negation)
                if matches!(op, UnOp::Not) && ty_is_integer_or_ref_integer(bctx, arg_ty) {
                    let varg = expr_to_vir_consume(bctx, arg)?;

                    let expr_ty = bctx.types.expr_ty(expr);
                    let (Some(w), s) =
                        bitwidth_and_signedness_of_integer_type(&bctx.ctxt.verus_items, expr_ty)
                    else {
                        crate::internal_err!(
                            expr.span,
                            "unexpected result of ! operator: {:?}",
                            expr_ty
                        );
                    };
                    let op = UnaryOp::BitNot(if s { None } else { Some(w) });
                    return mk_expr(ExprX::Unary(op, varg));
                }

                // Neg of an integer type
                if matches!(op, UnOp::Neg) && ty_is_integer_or_ref_integer(bctx, arg_ty) {
                    // Translate `-a` to the binary op `0 - a`.
                    // Special-case the negation of literals.
                    let zero_const = vir::ast_util::const_int_from_u128(0);
                    let zero = mk_expr(ExprX::Const(zero_const))?.expect_expr();
                    let (ob, varg) = if let ExprKind::Lit(Spanned {
                        node: LitKind::Int(i, _),
                        ..
                    }) = &arg.kind
                    {
                        if bctx.types.expr_adjustments(arg).len() != 0 {
                            crate::internal_err!(
                                expr.span,
                                "negation of literal expected no implicit adjustments"
                            );
                        }
                        let ob = OverflowBehavior::Allow;
                        let expr = mk_lit_int(
                            true,
                            i.get(),
                            typ_of_node_unadjusted(bctx, expr.span, &expr.hir_id)?,
                        )?;
                        (ob, expr)
                    } else {
                        if bctx.in_ghost {
                            return err_span(
                                expr.span,
                                "bare unary negation (-) in ghost code; it is expected that (-) is translated by the verus macro",
                            );
                        }
                        let range = crate::rust_to_vir_base::get_range(&expr_typ()?);
                        let ob = OverflowBehavior::Error(range);
                        let expr = expr_to_vir(bctx, arg)?;
                        (ob, expr)
                    };
                    let varg = varg.consume(bctx, bctx.types.expr_ty_adjusted(arg));
                    return mk_expr(ExprX::Binary(BinaryOp::Arith(ArithOp::Sub(ob)), zero, varg));
                }

                // Neg of a floating point type
                if matches!(op, UnOp::Neg) && ty_is_float_or_ref_float(arg_ty) {
                    // Special-case the negation of literals.
                    if let ExprKind::Lit(lit @ Spanned { node: LitKind::Float(..), .. }) = &arg.kind
                    {
                        if bctx.types.expr_adjustments(arg).len() != 0 {
                            crate::internal_err!(
                                expr.span,
                                "negation of literal expected no implicit adjustments"
                            );
                        }
                        return Ok(ExprOrPlace::Expr(lit_to_vir(
                            bctx,
                            expr.span,
                            *lit,
                            true,
                            &typ_of_expr_adjusted(bctx, expr.span, &arg.hir_id)?,
                            Some(arg_ty),
                        )?));
                    } else {
                        unsupported_err!(expr.span, "unary op negation of floating point")
                    };
                }

                // The above cases should handle (at mininum) all non-method-call cases.
                if !bctx.types.is_method_call(expr) {
                    unsupported_err!(
                        expr.span,
                        format!("applying unary operator {:?} to type {:?}", op, arg_ty)
                    )
                }

                // Handle any method call case
                let fn_def_id = bctx
                    .types
                    .type_dependent_def_id(expr.hir_id)
                    .expect("cannot get the function definition id for a unary op");
                let arg_vir = expr_to_vir_consume(bctx, arg)?;
                Ok(ExprOrPlace::Expr(crate::fn_call_to_vir::call_overloaded_method(
                    bctx,
                    expr.span,
                    expr_typ()?,
                    fn_def_id,
                    Arc::new(vec![arg_vir]),
                    bctx.types.node_args(expr.hir_id),
                )?))
            }
            UnOp::Deref => {
                if bctx.types.is_method_call(expr) {
                    // deref/deref_mut are typed:
                    //   deref     : &T     -> &Target
                    //   deref_mut : &mut T -> &mut Target
                    // the HIR op is typed:
                    //   &(mut?) T -> Target

                    let ref_ty = bctx.types.expr_ty_adjusted(arg);
                    let (inner_ty, mutbl) = match ref_ty.kind() {
                        TyKind::Ref(_, ty, rustc_ast::Mutability::Mut) => (ty, true),
                        TyKind::Ref(_, ty, rustc_ast::Mutability::Not) => (ty, false),
                        _ => crate::internal_err!(expr.span, "expected TyKind::Ref"),
                    };
                    if let Some((ty, is_tracked)) = crate::rust_to_vir_base::is_tracked_or_ghost_ty(
                        &bctx.ctxt.verus_items,
                        *inner_ty,
                    ) {
                        // &(mut?) Tracked<T>  -->  Tracked<T>  -->  T
                        //                     (*)           ModeUnwrap

                        let inner = expr_to_vir_place(bctx, arg)?;
                        let inner = if mutbl {
                            deref_mut(bctx, expr.span, &inner)?
                        } else {
                            // Implicit immut-deref
                            inner
                        };

                        let mwm = if is_tracked {
                            vir::ast::ModeWrapperMode::Proof
                        } else {
                            vir::ast::ModeWrapperMode::Spec
                        };
                        let typ = bctx.mid_ty_to_vir(expr.span, &ty)?;
                        return Ok(ExprOrPlace::Place(bctx.spanned_typed_new(
                            expr.span,
                            &typ,
                            PlaceX::ModeUnwrap(inner, mwm),
                        )));
                    }

                    let inner_ty = bctx.types.expr_ty_adjusted(arg);
                    let inner = expr_to_vir_consume(bctx, arg)?;
                    let out_ty = bctx.types.expr_ty(expr);
                    let fn_def_id = bctx
                        .types
                        .type_dependent_def_id(expr.hir_id)
                        .expect("cannot get the function definition id for a deref");
                    let p = deref_overloaded(bctx, expr.span, fn_def_id, inner_ty, out_ty, &inner)?;
                    return Ok(ExprOrPlace::Place(p));
                } else {
                    let inner_ty = bctx.types.expr_ty_adjusted(arg);
                    let inner = expr_to_vir_place(bctx, arg)?;
                    let p = deref_primitive(bctx, expr.span, inner_ty, &inner)?;
                    return Ok(ExprOrPlace::Place(p));
                }
            }
        },
        ExprKind::Binary(Spanned { node: op @ (BinOpKind::And | BinOpKind::Or), .. }, lhs, rhs) => {
            let vlhs = expr_to_vir_consume(bctx, lhs)?;
            let vrhs = expr_to_vir_consume(bctx, rhs)?;
            let vop = match op {
                BinOpKind::And => vir::ast::LogicalOp::And,
                BinOpKind::Or => vir::ast::LogicalOp::Or,
                _ => unreachable!(),
            };
            mk_expr(ExprX::Logical(vop, vlhs, vrhs))
        }
        ExprKind::Binary(
            Spanned {
                node:
                    op @ (BinOpKind::Eq
                    | BinOpKind::Ne
                    | BinOpKind::Lt
                    | BinOpKind::Gt
                    | BinOpKind::Le
                    | BinOpKind::Ge),
                ..
            },
            lhs,
            rhs,
        ) if ty_is_raw_ptr(bctx.types.expr_ty_adjusted(lhs))
            && ty_is_raw_ptr(bctx.types.expr_ty_adjusted(rhs)) =>
        {
            // Pointer equality is considered primitive to Rust,
            // but we want to dispatch to the trait function, so we have to manually
            // go get the DefId for the trait function.
            let lang = bctx.ctxt.tcx.lang_items();
            let (trait_id, fun_sym) = match op {
                BinOpKind::Eq => (lang.eq_trait(), rustc_span::sym::eq),
                BinOpKind::Ne => (lang.eq_trait(), rustc_span::sym::ne),
                BinOpKind::Lt => (lang.partial_ord_trait(), rustc_span::sym::lt),
                BinOpKind::Le => (lang.partial_ord_trait(), rustc_span::sym::le),
                BinOpKind::Gt => (lang.partial_ord_trait(), rustc_span::sym::gt),
                BinOpKind::Ge => (lang.partial_ord_trait(), rustc_span::sym::ge),
                _ => unreachable!(),
            };
            // The signature for eq is `fn eq(&self, other: &Rhs) -> bool;`,
            // (and similarly for ne, lt, le, gt, ge)
            // so normally we would strip a reference off here.
            // But since ptr equality is primitive, there's no shared reference.
            // So we just use the types of the 2 arguments to get Self and Rhs
            // without stripping a reference off.
            let lhs_ty = bctx.types.expr_ty_adjusted(lhs);
            let rhs_ty = bctx.types.expr_ty_adjusted(rhs);
            let ty_args = tcx.mk_args(&[lhs_ty.into(), rhs_ty.into()]);
            let args = vec![*lhs, *rhs];
            let Some(assoc_fn) = tcx
                .associated_items(trait_id.unwrap())
                .filter_by_name_unhygienic(fun_sym)
                .find(|item| matches!(item.kind, rustc_middle::ty::AssocKind::Fn { .. }))
            else {
                crate::internal_err!(expr.span, "could not find associated function");
            };
            let fun_def_id = assoc_fn.def_id;
            Ok(ExprOrPlace::Expr(fn_call_to_vir(
                bctx, expr, fun_def_id, ty_args, expr.span, args, true,
            )?))
        }
        ExprKind::Binary(op, lhs, rhs) => {
            let lhs_vir = expr_to_vir_consume(bctx, lhs)?;
            let rhs_vir = expr_to_vir_consume(bctx, rhs)?;

            let op_vir = binopkind_to_binaryop(bctx, op, expr.span, lhs, rhs)?;
            if let Some(op_vir) = op_vir {
                let e = mk_expr(ExprX::Binary(op_vir, lhs_vir, rhs_vir))?.expect_expr();
                if matches!(op.node, BinOpKind::Div | BinOpKind::Rem)
                    && is_smt_arith(bctx, lhs.span, rhs.span, &lhs.hir_id, &rhs.hir_id)?
                {
                    match mk_range(&bctx.ctxt.verus_items, &tc.node_type(expr.hir_id)) {
                        IntRange::Int
                        | IntRange::Nat
                        | IntRange::U(_)
                        | IntRange::USize
                        | IntRange::I(_)
                        | IntRange::ISize => {
                            // This clip is to help the smt solver see that the result
                            // of the operation is in-bounds.
                            // REVIEW: Should this be applied to AssignOp as well?
                            // Consider moving this clipping logic to ast_to_sst for consistency
                            return Ok(ExprOrPlace::Expr(mk_ty_clip(bctx, &expr_typ()?, &e, true)));
                        }
                        IntRange::Char => {
                            unsupported_err!(expr.span, "div/mod on char type")
                        }
                    }
                }
                return Ok(ExprOrPlace::Expr(e));
            }

            // The above cases should handle (at mininum) all non-method-call cases.
            if !bctx.types.is_method_call(expr) {
                let lhs_ty = bctx.types.expr_ty_adjusted(lhs);
                let rhs_ty = bctx.types.expr_ty_adjusted(rhs);
                unsupported_err!(
                    expr.span,
                    format!(
                        "applying binary operator {:?} to types {lhs_ty:?}, {rhs_ty:?}",
                        op.node
                    )
                )
            }

            // Handle any method call case
            let fn_def_id = bctx
                .types
                .type_dependent_def_id(expr.hir_id)
                .expect("cannot get the function definition id for a unary op");
            Ok(ExprOrPlace::Expr(crate::fn_call_to_vir::call_overloaded_method(
                bctx,
                expr.span,
                expr_typ()?,
                fn_def_id,
                Arc::new(vec![lhs_vir, rhs_vir]),
                bctx.types.node_args(expr.hir_id),
            )?))
        }
        ExprKind::Path(qpath) => {
            let res = bctx.types.qpath_res(&qpath, expr.hir_id);
            let ctor_opt = resolve_ctor(bctx.ctxt.tcx, res);
            match (res, ctor_opt) {
                (Res::Local(id), _)
                    if let Some(actx) = bctx.atomically.as_deref()
                        && actx.update_binder == id =>
                {
                    return err_span(expr.span, "update function must be called directly");
                }
                (Res::Local(id), _) => match tcx.hir_node(id) {
                    Node::Pat(pat) => {
                        let name = pat_to_var(pat)?;
                        let x = PlaceX::Local(pat_to_var(pat)?);
                        let typ = &expr_typ()?;
                        let place = bctx.spanned_typed_new(expr.span, typ, x);

                        //let ids = (id.owner.def_id.local_def_index.as_usize(), id.local_id);
                        //println!("{:?}", (&name.0, ids));

                        // Does this var need the shadow check?
                        // (See verus_time_travel_prevention.rs)
                        let shadow_check = !(bctx.in_old || bctx.in_explicit_prophecy_node);
                        if shadow_check {
                            let mut erasure_info = bctx.ctxt.erasure_info.borrow_mut();
                            erasure_info.shadow_check.push(expr.hir_id);
                        }

                        if bctx.in_postcondition && !bctx.in_old && bctx.is_param_migrated(&name) {
                            {
                                let mut erasure_info = bctx.ctxt.erasure_info.borrow_mut();
                                erasure_info
                                    .local_hir_vir_ids
                                    .push((Some(expr.hir_id), place.span.id));
                            }
                            let e = ExprOrPlace::Place(place).to_spec_expr(bctx);
                            let x = ExprX::Unary(UnaryOp::MutRefFinal(true), e);
                            let e = bctx.spanned_typed_new(expr.span, typ, x);
                            Ok(ExprOrPlace::Expr(e))
                        } else if bctx.in_old {
                            // old(x) should create a VarAt(Pre) if we're in the body of a function
                            // with x as a param.
                            // If we're in the signature of the function that declares x,
                            // use a normal Var
                            if bctx.is_param_for_fn_or_non_spec_closure(&name) {
                                if bctx.in_fn_sig
                                    && bctx.is_param_for_innermost_fn_or_non_spec_closure(&name)
                                {
                                    let mut erasure_info = bctx.ctxt.erasure_info.borrow_mut();
                                    erasure_info
                                        .local_hir_vir_ids
                                        .push((Some(expr.hir_id), place.span.id));
                                    Ok(ExprOrPlace::Place(place))
                                } else {
                                    let x = ExprX::VarAt(name, vir::ast::VarAt::Pre);
                                    let e = bctx.spanned_typed_new(expr.span, typ, x);
                                    let mut erasure_info = bctx.ctxt.erasure_info.borrow_mut();
                                    erasure_info
                                        .local_hir_vir_ids
                                        .push((Some(expr.hir_id), e.span.id));
                                    Ok(ExprOrPlace::Expr(e))
                                }
                            } else {
                                err_span(
                                    expr.span,
                                    "`old` for a local variable that isn't a parameter",
                                )
                            }
                        } else {
                            let mut erasure_info = bctx.ctxt.erasure_info.borrow_mut();
                            erasure_info.local_hir_vir_ids.push((Some(expr.hir_id), place.span.id));
                            Ok(ExprOrPlace::Place(place))
                        }
                    }
                    node => unsupported_err!(expr.span, format!("Path {:?}", node)),
                },
                (_, Some((ctor, ctor_kind))) => {
                    if ctor_kind != CtorKind::Const {
                        unsupported_err!(
                            expr.span,
                            "using a datatype constructor as a function value"
                        );
                    }
                    Ok(ExprOrPlace::Expr(expr_tuple_datatype_ctor_to_vir(
                        bctx,
                        expr,
                        ctor,
                        &[],
                        expr.span,
                    )?))
                }
                (Res::Def(DefKind::AssocConst { is_type_const: _ }, id), _) => {
                    if let Some(vir_expr) =
                        int_intrinsic_constant_to_vir(&bctx.ctxt, expr.span, &expr_typ()?, id)
                    {
                        let mut erasure_info = bctx.ctxt.erasure_info.borrow_mut();
                        erasure_info.resolved_calls.push((
                            expr.hir_id,
                            expr.span.data(),
                            ResolvedCall::MiscCall(MiscCall::IntIntrinsic),
                            bctx.in_ghost,
                        ));
                        return Ok(ExprOrPlace::Expr(vir_expr));
                    } else {
                        let node_substs = bctx.types.node_args(expr.hir_id);
                        let e = const_var_to_vir(
                            bctx,
                            Some(expr),
                            id,
                            node_substs,
                            &expr.hir_id,
                            expr.span,
                        )?;
                        bctx.ctxt
                            .erasure_info
                            .borrow_mut()
                            .local_hir_vir_ids
                            .push((None, e.span.id));
                        Ok(ExprOrPlace::Expr(e))
                    }
                }
                (Res::Def(DefKind::Const { is_type_const: _ }, id), _) => {
                    let node_substs = bctx.types.node_args(expr.hir_id);
                    let e = const_var_to_vir(
                        bctx,
                        Some(expr),
                        id,
                        node_substs,
                        &expr.hir_id,
                        expr.span,
                    )?;
                    bctx.ctxt.erasure_info.borrow_mut().local_hir_vir_ids.push((None, e.span.id));
                    Ok(ExprOrPlace::Expr(e))
                }
                (
                    Res::Def(
                        DefKind::Static { mutability: Mutability::Not, nested: false, .. },
                        id,
                    ),
                    _,
                ) => {
                    let path = bctx.ctxt.def_id_to_vir_path(id);
                    let fun = FunX { path };
                    let e = bctx.spanned_typed_new(
                        expr.span,
                        &expr_typ()?,
                        ExprX::StaticVar(Arc::new(fun)),
                    );
                    bctx.ctxt.erasure_info.borrow_mut().local_hir_vir_ids.push((None, e.span.id));
                    Ok(ExprOrPlace::Expr(e))
                }
                (Res::Def(DefKind::Fn, id) | Res::Def(DefKind::AssocFn, id), _) => {
                    let path = bctx.ctxt.def_id_to_vir_path(id);
                    let fun = Arc::new(vir::ast::FunX { path });
                    mk_expr(ExprX::ExecFnByName(fun))
                }
                (Res::Def(DefKind::ConstParam, id), _) => {
                    let gparam = if let Some(local_id) = id.as_local() {
                        let hir_id = tcx.local_def_id_to_hir_id(local_id);
                        match tcx.hir_node(hir_id) {
                            Node::GenericParam(rustc_hir::GenericParam {
                                name,
                                kind: rustc_hir::GenericParamKind::Const { .. },
                                ..
                            }) => Some(name),
                            _ => None,
                        }
                    } else {
                        None
                    };
                    match *undecorate_typ(&expr_typ()?) {
                        TypX::Int(_) => {}
                        TypX::Bool => {}
                        _ => {
                            unsupported_err!(expr.span, format!("non-int ConstParam {:?}", id))
                        }
                    }
                    if let Some(name) = gparam {
                        let typ = Arc::new(TypX::TypParam(Arc::new(name.ident().to_string())));
                        let opr = vir::ast::NullaryOpr::ConstGeneric(typ);
                        mk_expr(ExprX::NullaryOpr(opr))
                    } else {
                        unsupported_err!(expr.span, format!("ConstParam {:?}", id))
                    }
                }
                (res, _) => unsupported_err!(expr.span, format!("Path {:?}", res)),
            }
        }
        ExprKind::Assign(lhs, rhs, _) => {
            expr_assign_to_vir_innermost(bctx, expr.span, lhs, mk_expr, rhs, None)
        }
        ExprKind::Field(lhs, name) => {
            let vir_lhs = expr_to_vir_place(bctx, lhs)?;

            let lhs_ty = tc.expr_ty_adjusted(lhs);
            // REVIEW: this call to mid_ty_simplify seems unneeded?
            let lhs_ty = mid_ty_simplify(tcx, &bctx.ctxt.verus_items, &lhs_ty);
            let field_opr = if let Some(adt_def) = lhs_ty.ty_adt_def() {
                unsupported_err_unless!(
                    adt_def.variants().len() == 1,
                    expr.span,
                    "field_of_adt_with_multiple_variants",
                    expr
                );
                let datatype_path = bctx.ctxt.def_id_to_vir_path(adt_def.did());
                let hir_def = bctx.ctxt.tcx.adt_def(adt_def.did());
                let variant = hir_def.variants().iter().next().unwrap();
                let field_name = field_ident_from_rust(&name.as_str());
                match variant.ctor_kind() {
                    Some(rustc_hir::def::CtorKind::Fn) => {}
                    None => {}
                    Some(rustc_hir::def::CtorKind::Const) => panic!("unexpected tuple constructor"),
                }
                let variant_name = if adt_def.is_union() {
                    str_ident(name.as_str())
                } else {
                    str_ident(&variant.ident(tcx).as_str())
                };
                let check =
                    if adt_def.is_union() { VariantCheck::Union } else { VariantCheck::None };
                FieldOpr {
                    datatype: Dt::Path(datatype_path),
                    variant: variant_name,
                    field: field_name,
                    get_variant: false,
                    check,
                }
            } else {
                if let TyKind::Tuple(t_args) = lhs_ty.kind() {
                    let field: usize =
                        str::parse(&name.as_str()).expect("integer index into tuple");
                    mk_tuple_field_opr(t_args.len(), field)
                } else {
                    unsupported_err!(expr.span, "field_of_non_adt", expr)
                }
            };
            let field_type = expr_typ()?.clone();
            let vir =
                bctx.spanned_typed_new(expr.span, &field_type, PlaceX::Field(field_opr, vir_lhs));
            Ok(ExprOrPlace::Place(vir))
        }
        ExprKind::If(cond, lhs, rhs) => {
            let cond = cond.peel_drop_temps();
            match cond.kind {
                ExprKind::Let(_) => {
                    let (rhs_vir, rhs_span) = if let Some(rhs) = rhs {
                        (expr_to_vir_consume(bctx, &rhs)?, rhs.span)
                    } else {
                        (
                            mk_expr(ExprX::Block(Arc::new(Vec::new()), None))?.expect_expr(),
                            cond.span,
                        )
                    };
                    mk_expr(cond_let_expr_to_vir_match(
                        cond,
                        expr_to_vir_consume(bctx, &lhs)?,
                        lhs.span,
                        rhs_vir,
                        rhs_span,
                    )?)
                }
                _ => {
                    let vir_cond = expr_to_vir_consume(bctx, cond)?;
                    let vir_lhs = expr_to_vir_consume(bctx, lhs)?;
                    let vir_rhs = rhs.map(|e| expr_to_vir_consume(bctx, e)).transpose()?;
                    mk_expr(ExprX::If(vir_cond, vir_lhs, vir_rhs))
                }
            }
        }
        // This a desugered `await` expression
        ExprKind::Match(
            Expr { hir_id: _, kind: ExprKind::Call(_expr, call_args), span: _ },
            _arms,
            rustc_hir::MatchSource::AwaitDesugar,
        ) => {
            let vir_expr = expr_to_vir_consume(bctx, &call_args[0])?;
            mk_expr(ExprX::Await(vir_expr))
        }
        ExprKind::Match(expr, arms, _match_source) => {
            let vir_place = expr_to_vir_place(bctx, expr)?;
            let vir_place = simplify_place_by_cancelling(&vir_place);
            let mut vir_arms: Vec<vir::ast::Arm> = Vec::new();
            for arm in arms.iter() {
                let pattern = pattern_to_vir(bctx, &arm.pat)?;
                let guard = match &arm.guard {
                    None => bctx.spanned_typed_new(
                        expr.span,
                        &bool_typ(),
                        ExprX::Const(Constant::Bool(true)),
                    ),
                    Some(guard_expr) => expr_to_vir_consume(bctx, guard_expr)?,
                };
                let body = expr_to_vir_consume(bctx, &arm.body)?;
                let vir_arm = ArmX { pattern, guard, body };
                vir_arms.push(bctx.spanned_new(arm.span, vir_arm));
            }
            mk_expr(ExprX::Match(vir_place, Arc::new(vir_arms), false))
        }
        ExprKind::Loop(block, label, LoopSource::Loop, header_span) => {
            let label = bctx.fresh_label(expr.hir_id, label);
            let allow_complex_invariants = allow_complex_invariants();
            let typ = typ_of_node_unadjusted(bctx, block.span, &block.hir_id)?;
            let mut body = block_to_vir(bctx, block, &expr.span, &typ)?;
            let mut header =
                vir::headers::read_header(&mut body, &vir::headers::HeaderAllows::Loop)?;
            let allow_no_decreases = expr_vattrs.assume_termination
                || crate::attributes::get_allow_exec_allows_no_decreases_clause_walk_parents(
                    bctx.ctxt.tcx,
                    bctx.fun_id,
                );
            let decrease = if expr_vattrs.auto_decreases && allow_no_decreases {
                for dec in header.decrease.iter() {
                    crate::erase::mark_tree_for_erasure(&bctx.ctxt, dec);
                }
                Arc::new(vec![])
            } else {
                header.decrease.clone()
            };
            if expr_vattrs.auto_decreases && allow_no_decreases {
                // Filter out auto_decreases invariants if we're not checking for termination
                // (at present, we only add them to invariant_except_break)
                Arc::make_mut(&mut header.invariant_except_break).retain(|e| {
                    if matches!(&e.x, ExprX::UnaryOpr(UnaryOpr::AutoDecreases, _)) {
                        crate::erase::mark_tree_for_erasure(&bctx.ctxt, e);
                        false
                    } else {
                        true
                    }
                });
            }
            Ok(ExprOrPlace::Expr(bctx.spanned_typed_new(
                *header_span,
                &expr_typ()?,
                ExprX::Loop {
                    loop_isolation,
                    allow_complex_invariants,
                    is_for_loop: expr_vattrs.for_loop,
                    assume_termination: expr_vattrs.assume_termination,
                    label,
                    cond: None,
                    body,
                    invs: header.loop_invariants(),
                    //invs,
                    decrease,
                    atomic_call: header.atomic_call_loop,
                },
            )))
        }
        ExprKind::Loop(
            Block {
                stmts: [], expr: Some(Expr { kind: ExprKind::If(cond, body, other), .. }), ..
            },
            label,
            LoopSource::While,
            header_span,
        ) => {
            let label = bctx.fresh_label(expr.hir_id, label);
            // rustc desugars a while loop of the form `while cond { body }`
            // to `loop { if cond { body } else { break; } }`
            // We want to "un-desugar" it to represent it as a while loop.
            // (We also need to retrieve the invariants from the body inside the If.)
            // We already got `body` from the if-branch; now sanity check that the
            // 'else' branch really has a 'break' statement as expected.
            if let Some(Expr {
                kind:
                    ExprKind::Block(
                        Block {
                            stmts:
                                [
                                    Stmt {
                                        kind:
                                            StmtKind::Expr(Expr {
                                                kind:
                                                    ExprKind::Break(
                                                        Destination { label: None, .. },
                                                        None,
                                                    ),
                                                ..
                                            }),
                                        ..
                                    },
                                ],
                            expr: None,
                            ..
                        },
                        None,
                    ),
                ..
            }) = other
            {
            } else {
                unsupported_err!(expr.span, "loop else");
            }
            let body_span = body.span;
            let mut body = expr_to_vir_consume(bctx, body)?;
            let header = vir::headers::read_header(&mut body, &vir::headers::HeaderAllows::Loop)?;
            let (cond, body) = match &cond.peel_drop_temps().kind {
                ExprKind::Let(_) => {
                    let body_ty = body.typ.clone();
                    let wildcard_body = bctx.spanned_typed_new(
                        cond.span,
                        &body_ty,
                        ExprX::BreakOrContinue {
                            label: label.clone(),
                            is_break: true,
                            value: None,
                        },
                    );
                    (
                        None,
                        bctx.spanned_typed_new(
                            cond.span,
                            &body_ty,
                            cond_let_expr_to_vir_match(
                                cond,
                                body,
                                body_span,
                                wildcard_body,
                                cond.span,
                            )?,
                        ),
                    )
                }
                _ => (Some(expr_to_vir_consume(bctx, cond)?), body),
            };
            Ok(ExprOrPlace::Expr(bctx.spanned_typed_new(
                *header_span,
                &expr_typ()?,
                ExprX::Loop {
                    loop_isolation,
                    allow_complex_invariants: allow_complex_invariants(),
                    is_for_loop: false,
                    assume_termination: expr_vattrs.assume_termination,
                    label,
                    cond,
                    body,
                    invs: header.loop_invariants(),
                    decrease: header.decrease,
                    atomic_call: header.atomic_call_loop,
                },
            )))
        }
        ExprKind::Ret(expr) => {
            let expr = match expr {
                None => None,
                Some(expr) => Some(expr_to_vir_consume(bctx, expr)?),
            };
            mk_expr(ExprX::Return(expr))
        }
        ExprKind::Break(dest, value) => {
            let label = bctx.label_from_dest(expr.span, dest)?;
            let value = value.map(|value| expr_to_vir_consume(bctx, value)).transpose()?;
            mk_expr(ExprX::BreakOrContinue { label, is_break: true, value })
        }
        ExprKind::Continue(dest) => {
            let label = bctx.label_from_dest(expr.span, dest)?;
            mk_expr(ExprX::BreakOrContinue { label, is_break: false, value: None })
        }
        ExprKind::Struct(qpath, fields, struct_tail) => {
            let update = match struct_tail {
                StructTailExpr::Base(tail_expr) => {
                    let place = expr_to_vir_place(bctx, tail_expr)?;
                    let place = simplify_place_by_cancelling(&place);
                    let tf = ctor_tail_get_taken_fields(bctx, expr)?;
                    Some(vir::ast::CtorUpdateTail { place: place, taken_fields: tf })
                }
                StructTailExpr::DefaultFields(..) => {
                    unsupported_err!(
                        expr.span,
                        "default fields in struct expression not supported"
                    );
                }
                _ => None,
            };

            let res = bctx.types.qpath_res(qpath, expr.hir_id);
            let ty = bctx.types.node_type(expr.hir_id);
            let ctor = resolve_braces_ctor(bctx.ctxt.tcx, res, ty, true, expr.span)?;
            let variant_name = ctor.variant_name(bctx.ctxt.tcx, fields);
            let path = bctx.ctxt.def_id_to_vir_path(ctor.adt_def_id);

            let vir_fields = Arc::new(
                fields
                    .iter()
                    .map(|f| -> Result<_, VirErr> {
                        let vir = expr_to_vir_consume(bctx, f.expr)?;
                        let ident = field_ident_from_rust(f.ident.as_str());
                        Ok(ident_binder(&ident, &vir))
                    })
                    .collect::<Result<Vec<_>, _>>()?,
            );

            let mut erasure_info = bctx.ctxt.erasure_info.borrow_mut();
            let resolved_call = ResolvedCall::BracesCtor(
                path.clone(),
                variant_name.clone(),
                Arc::new(vir_fields.iter().map(|f| f.name.clone()).collect::<Vec<_>>()),
                update.is_some(),
            );
            erasure_info.resolved_calls.push((
                expr.hir_id,
                expr.span.data(),
                resolved_call,
                bctx.in_ghost,
            ));
            let x = ExprX::Ctor(Dt::Path(path), variant_name, vir_fields, update);
            let e = bctx.spanned_typed_new(expr.span, &expr_typ()?, x);
            erasure_info.ctor_hir_vir_ids.push((Some(expr.hir_id), e.span.id));
            Ok(ExprOrPlace::Expr(e))
        }
        ExprKind::MethodCall(_name_and_generics, receiver, other_args, fn_span) => {
            let fn_def_id = bctx
                .types
                .type_dependent_def_id(expr.hir_id)
                .expect("def id of the method definition");

            let all_args = std::iter::once(*receiver).chain(other_args.iter()).collect::<Vec<_>>();
            Ok(ExprOrPlace::Expr(fn_call_to_vir(
                bctx,
                expr,
                fn_def_id,
                bctx.types.node_args(expr.hir_id),
                *fn_span,
                all_args,
                true,
            )?))
        }
        ExprKind::Closure(Closure { .. }) => {
            Ok(ExprOrPlace::Expr(closure_to_vir(bctx, expr, expr_typ()?, false, None)?))
        }
        ExprKind::Index(tgt_expr, idx_expr, _span) => {
            if bctx.in_ghost {
                crate::internal_err!(
                    expr.span,
                    "index operator [] in ghost code (note: usually the syntax macro would turn this into a call to `spec_index`"
                )
            }
            let tgt_expr_ty = bctx.types.expr_ty_adjusted(tgt_expr);
            let idx_ty = bctx.types.expr_ty_adjusted(idx_expr);
            // For borrow checking and SMT efficiency, ((array | slice), usize) is special case
            // For SMT efficiency, (Vec, usize) is special case
            // All other cases go through general Index trait
            if !bctx.types.is_method_call(expr) {
                assert!(idx_ty.is_usize());
                let kind = match tgt_expr_ty.kind() {
                    TyKind::Array(..) => vir::ast::ArrayKind::Array,
                    TyKind::Slice(..) => vir::ast::ArrayKind::Slice,
                    _ => panic!("expected array or slice, found {tgt_expr_ty}"),
                };
                let tgt_vir = expr_to_vir_place(bctx, tgt_expr)?;
                let idx_vir = expr_to_vir(bctx, idx_expr)?.consume(bctx, idx_ty);
                let placex = PlaceX::Index(tgt_vir, idx_vir, kind, BoundsCheck::Error);
                let vir = bctx.spanned_typed_new(expr.span, &expr_typ()?, placex);
                Ok(ExprOrPlace::Place(vir))
            } else {
                let is_array_or_slice =
                    matches!(tgt_expr_ty.kind(), TyKind::Array(..) | TyKind::Slice(..));
                assert!(!(is_array_or_slice && idx_ty.is_usize()));
                // Determine if this is Index or IndexMut
                // Based on ./rustc_mir_build/src/thir/cx/expr.rs in rustc
                // this is determined by the (adjusted) type of the receiver
                let rustc_middle::ty::Ref(_, tgt_ty, mutbl) = tgt_expr_ty.kind() else {
                    crate::internal_err!(
                        expr.span,
                        "overloaded_place: receiver is not a reference"
                    );
                };
                let mutbl = match mutbl {
                    Mutability::Not => false,
                    Mutability::Mut => true,
                };

                let tgt_vir = expr_to_vir_consume(bctx, tgt_expr)?;
                let idx_vir = expr_to_vir_consume(bctx, idx_expr)?;

                // typ args to Index:
                // target typ without & or &mut
                let tgt_typ_vir = bctx.mid_ty_to_vir(tgt_expr.span, &tgt_ty)?;

                let fun_typ_args = if ty_is_vec(bctx.ctxt.tcx, *tgt_ty) && idx_ty.is_usize() {
                    let fun = if mutbl {
                        vir::fun!(CrateId::Vstd => "std_specs", "vec", "vec_index_mut")
                    } else {
                        vir::fun!(CrateId::Vstd => "std_specs", "vec", "vec_index")
                    };

                    let typ_args = match &*tgt_typ_vir {
                        TypX::Datatype(_, typ_args, _) => typ_args.clone(),
                        _ => crate::internal_err!(
                            expr.span,
                            "Index operator expected TypX::Datatype"
                        ),
                    };
                    Some((fun, typ_args))
                } else {
                    None
                };

                let call_ret_typ = if mutbl {
                    Arc::new(TypX::MutRef(expr_typ()?))
                } else {
                    Arc::new(TypX::Decorate(TypDecoration::Ref, None, expr_typ()?))
                };

                let e = if let Some((fun, typ_args)) = fun_typ_args {
                    let call_target_attrs = vir::ast::CallTargetAttrs {
                        autospec: AutospecUsage::Final,
                        const_var: false,
                        assume_external_allowed: false,
                    };
                    // special fast path
                    let call_target = CallTarget::Fun(
                        vir::ast::CallTargetKind::Static,
                        fun,
                        typ_args,
                        // arbitrary impl_path
                        // REVIEW: why is this needed?
                        Arc::new(vec![ImplPath::TraitImplPath(vir::def::prefix_spec_fn_type(0))]),
                        call_target_attrs,
                    );
                    let args = Arc::new(vec![tgt_vir.clone(), idx_vir.clone()]);
                    let x = ExprX::Call {
                        target: call_target,
                        args: args,
                        post_args: None,
                        body: None,
                    };
                    bctx.spanned_typed_new(expr.span, &call_ret_typ, x)
                } else {
                    let fn_def_id = bctx
                        .types
                        .type_dependent_def_id(expr.hir_id)
                        .expect("cannot get the function definition id for index");
                    crate::fn_call_to_vir::call_index(
                        bctx,
                        expr.span,
                        call_ret_typ.clone(),
                        fn_def_id,
                        tgt_vir,
                        tgt_expr_ty,
                        idx_vir,
                        idx_ty,
                    )?
                };

                // tgt[idx] is equivalent to either *index(tgt, idx) or *index_mut(tgt, idx)
                // (The * on the outside isn't part of the adjustments; we add it here)
                let mut p = bctx.spanned_typed_new(expr.span, &call_ret_typ, PlaceX::Temporary(e));
                if mutbl {
                    // mutable deref
                    p = deref_mut(bctx, expr.span, &p)?;
                } else {
                    // immutable deref is implicit
                }
                Ok(ExprOrPlace::Place(p))
            }
        }
        ExprKind::Loop(_, _, LoopSource::ForLoop, _) => {
            // The `verus!` macro rewrites `for` loops internally before they
            // reach rustc's native for-loop desugaring, so a `LoopSource::ForLoop`
            // only shows up here when the `for` loop was not visited by `verus!`
            unsupported_err!(
                expr.span,
                format!(
                    "`for` loops produced by a macro expansion (wrap the loop in the macro body with `verus_exec_expr! {{ ... }}`)"
                )
            )
        }
        ExprKind::Loop(..) => unsupported_err!(expr.span, format!("complex loop expressions")),
        ExprKind::AssignOp(op, lhs, rhs) => {
            // Note: The semantics are VERY DIFFERENT for method_call vs !method_call cases.
            // The 2 cases MUST be handled separately.
            //
            // In particular:
            //  - For !method_call, evaluation order is RHS FIRST, so the op must be lowered
            //    to a VIR operation which is RHS FIRST, like AssignToPlace
            //  - For method_call, evaluation order is LHS FIRST, so the op must be lowered
            //    to something that evaluates in the appropriate order.

            if bctx.types.is_method_call(expr) {
                let lhs_ty = bctx.types.expr_ty_adjusted(lhs);
                let rhs_ty = bctx.types.expr_ty_adjusted(rhs);
                let lhs_vir = expr_to_vir_consume(bctx, lhs)?;
                let rhs_vir = expr_to_vir_consume(bctx, rhs)?;
                let fn_def_id = bctx
                    .types
                    .type_dependent_def_id(expr.hir_id)
                    .expect("cannot get the function definition id for AssignOp");
                let TyKind::Ref(_, self_ty, _) = lhs_ty.kind() else {
                    crate::internal_err!(expr.span, "AssignOp: expected ref")
                };
                let trait_args =
                    bctx.ctxt.tcx.mk_args(&[GenericArg::from(*self_ty), GenericArg::from(rhs_ty)]);
                let args = Arc::new(vec![lhs_vir, rhs_vir]);
                let e = crate::fn_call_to_vir::call_overloaded_method(
                    bctx,
                    expr.span,
                    vir::ast_util::unit_typ(),
                    fn_def_id,
                    args,
                    trait_args,
                )?;
                return Ok(ExprOrPlace::Expr(e));
            }

            expr_assign_to_vir_innermost(bctx, expr.span, lhs, mk_expr, rhs, Some(op))
        }
        ExprKind::ConstBlock(..) => unsupported_err!(expr.span, format!("const block expressions")),
        ExprKind::Type(..) => unsupported_err!(expr.span, format!("type expressions")),
        ExprKind::DropTemps(..) => unsupported_err!(expr.span, format!("drop-temps expressions")),
        ExprKind::Let(..) => unsupported_err!(expr.span, format!("let expressions")),
        ExprKind::Yield(..) => unsupported_err!(expr.span, format!("yield expressions")),
        ExprKind::InlineAsm(..) => unsupported_err!(expr.span, format!("inline-asm expressions")),
        ExprKind::Err(..) => unsupported_err!(expr.span, format!("Err expressions")),
        ExprKind::Become(..) => unsupported_err!(expr.span, format!("Become expressions")),
        ExprKind::UnsafeBinderCast(..) => {
            unsupported_err!(expr.span, format!("unsafe binder cast"))
        }
        ExprKind::Use(..) => unsupported_err!(expr.span, "use expressions"),
        ExprKind::AddrOf(rustc_ast::BorrowKind::Pin, _, _) => unsupported_err!(expr.span, "pin"),
    }
}

fn lit_to_vir<'tcx>(
    bctx: &BodyCtxt<'tcx>,
    span: Span,
    lit: Lit,
    negated: bool,
    typ: &Typ,
    ty: Option<rustc_middle::ty::Ty<'tcx>>,
) -> Result<vir::ast::Expr, VirErr> {
    let mk_expr = move |x: ExprX| Ok(bctx.spanned_typed_new(span, &typ, x));
    let mk_lit_int = |in_negative_literal: bool, i: u128, typ: &Typ| {
        check_lit_int(&bctx.ctxt, span, in_negative_literal, i, typ)?;
        let mut big_int = num_bigint::BigInt::from(i);
        if negated {
            big_int = -1 * big_int;
        }
        mk_expr(ExprX::Const(Constant::Int(big_int)))
    };
    match lit.node {
        LitKind::Bool(b) => {
            let c = vir::ast::Constant::Bool(b);
            mk_expr(ExprX::Const(c))
        }
        LitKind::Int(i, _) => mk_lit_int(false, i.get(), typ),
        LitKind::Char(c) => {
            let c = vir::ast::Constant::Char(c);
            mk_expr(ExprX::Const(c))
        }
        LitKind::Byte(b) => mk_lit_int(false, u128::from(b), typ),
        LitKind::Str(s, _str_style) => {
            let c = vir::ast::Constant::StrSlice(Arc::new(s.to_string()));
            mk_expr(ExprX::Const(c))
        }
        LitKind::ByteStr(bs, _str_style) => {
            let c = Constant::ByteStr(Arc::new(bs.as_byte_str().to_vec()));
            mk_expr(ExprX::Const(c))
        }
        LitKind::Float(..) => {
            if let Some(ty) = ty {
                use rustc_middle::ty::LitToConstInput;
                let lit_const = LitToConstInput { lit: lit.node, ty: Some(ty), neg: negated };
                if let Some(v) = bctx.ctxt.tcx.lit_to_const(lit_const) {
                    if let Some(i) = v.valtree.try_to_leaf() {
                        match i.size().bytes() {
                            4 => {
                                let c = vir::ast::Constant::Float32(i.to_u32());
                                return mk_expr(ExprX::Const(c));
                            }
                            8 => {
                                let c = vir::ast::Constant::Float64(i.to_u64());
                                return mk_expr(ExprX::Const(c));
                            }
                            _ => {}
                        }
                    }
                }
            }
            return err_span(span, "Unsupported floating point literal");
        }
        _ => {
            return err_span(span, "Unsupported constant type");
        }
    }
}

fn assignop_kind_to_binaryop<'tcx>(
    bctx: &BodyCtxt<'tcx>,
    op: &Spanned<AssignOpKind>,
    span: Span,
    lhs: &Expr<'tcx>,
    rhs: &Expr<'tcx>,
) -> Result<Option<BinaryOp>, VirErr> {
    let bop: BinOpKind = match op.node {
        AssignOpKind::AddAssign => BinOpKind::Add,
        AssignOpKind::SubAssign => BinOpKind::Sub,
        AssignOpKind::MulAssign => BinOpKind::Mul,
        AssignOpKind::DivAssign => BinOpKind::Div,
        AssignOpKind::RemAssign => BinOpKind::Rem,
        AssignOpKind::BitXorAssign => BinOpKind::BitXor,
        AssignOpKind::BitAndAssign => BinOpKind::BitAnd,
        AssignOpKind::BitOrAssign => BinOpKind::BitOr,
        AssignOpKind::ShlAssign => BinOpKind::Shl,
        AssignOpKind::ShrAssign => BinOpKind::Shr,
    };
    binopkind_to_binaryop_inner(bctx, bop, span, lhs, rhs)
}

fn euclidean_or_truncating_div<'tcx>(
    bctx: &BodyCtxt<'tcx>,
    lhs: &Expr<'tcx>,
    rhs: &Expr<'tcx>,
) -> Result<Option<IntegerTypeBitwidth>, VirErr> {
    let lhs_ty = bctx.types.expr_ty_adjusted(lhs);
    let lhs_typ = bctx.mid_ty_to_vir(lhs.span, &lhs_ty)?;
    let TypX::Int(lhs_int_range) = &*undecorate_typ(&lhs_typ) else {
        crate::internal_err!(lhs.span, "For div/mod, expected some kind of int typ");
    };

    let rhs_ty = bctx.types.expr_ty_adjusted(rhs);
    let rhs_typ = bctx.mid_ty_to_vir(rhs.span, &rhs_ty)?;
    let TypX::Int(rhs_int_range) = &*undecorate_typ(&rhs_typ) else {
        crate::internal_err!(rhs.span, "For div/mod, expected some kind of int typ");
    };

    if lhs_int_range != rhs_int_range {
        crate::internal_err!(lhs.span, "For div/mod, expected both sides to have the same type");
    }

    match lhs_int_range {
        IntRange::USize | IntRange::U(_) => Ok(None),
        IntRange::ISize => Ok(Some(IntegerTypeBitwidth::ArchWordSize)),
        IntRange::I(w) => Ok(Some(IntegerTypeBitwidth::Width(*w))),
        IntRange::Int | IntRange::Nat | IntRange::Char => {
            crate::internal_err!(lhs.span, "For div/mod, got unexpected typ {:}", lhs_ty)
        }
    }
}

/// Lower a Rust BinaryOp to a VIR BinaryOp.
/// For ops which are allowed in AssignOps, this function must handle,
/// at minimum, all the "primitive" bin ops, since these need to be lowered
/// through VIR's Assign node, which takes a BinaryOp.
fn binopkind_to_binaryop_inner<'tcx>(
    bctx: &BodyCtxt<'tcx>,
    op: BinOpKind,
    span: Span,
    lhs: &Expr<'tcx>,
    rhs: &Expr<'tcx>,
) -> Result<Option<BinaryOp>, VirErr> {
    let tc = bctx.types;

    match op {
        BinOpKind::And | BinOpKind::Or => {
            // And and Or aren't allowed for AssignOp, and for normal BinOps,
            // these are handled separately.
            unsupported_err!(lhs.span, "use of `&&` or `||` here");
        }
        BinOpKind::Eq | BinOpKind::Ne if is_smt_equality(bctx, span, &lhs.hir_id, &rhs.hir_id)? => {
            let op = match op {
                BinOpKind::Eq => BinaryOp::Eq(Mode::Exec),
                BinOpKind::Ne => BinaryOp::Ne,
                _ => unreachable!(),
            };
            return Ok(Some(op));
        }
        _ => {}
    }

    let lhs_ty = bctx.types.expr_ty_adjusted(lhs);
    let rhs_ty = bctx.types.expr_ty_adjusted(rhs);

    if ty_is_float_or_ref_float(lhs_ty) && lhs_ty == rhs_ty {
        if bctx.in_ghost {
            unsupported_err!(span, "floating point operation in ghost code");
        }
        match op {
            BinOpKind::Add => {
                return Ok(Some(BinaryOp::UninterpretedFloat(UninterpretedFloatBinaryOp::Add)));
            }
            BinOpKind::Sub => {
                return Ok(Some(BinaryOp::UninterpretedFloat(UninterpretedFloatBinaryOp::Sub)));
            }
            BinOpKind::Mul => {
                return Ok(Some(BinaryOp::UninterpretedFloat(UninterpretedFloatBinaryOp::Mul)));
            }
            BinOpKind::Div => {
                return Ok(Some(BinaryOp::UninterpretedFloat(UninterpretedFloatBinaryOp::Div)));
            }
            BinOpKind::Eq => {
                return Ok(Some(BinaryOp::UninterpretedFloat(UninterpretedFloatBinaryOp::Eq)));
            }
            BinOpKind::Ne => {
                return Ok(Some(BinaryOp::UninterpretedFloat(UninterpretedFloatBinaryOp::Ne)));
            }
            BinOpKind::Le => {
                return Ok(Some(BinaryOp::UninterpretedFloat(UninterpretedFloatBinaryOp::Le)));
            }
            BinOpKind::Lt => {
                return Ok(Some(BinaryOp::UninterpretedFloat(UninterpretedFloatBinaryOp::Lt)));
            }
            BinOpKind::Ge => {
                return Ok(Some(BinaryOp::UninterpretedFloat(UninterpretedFloatBinaryOp::Ge)));
            }
            BinOpKind::Gt => {
                return Ok(Some(BinaryOp::UninterpretedFloat(UninterpretedFloatBinaryOp::Gt)));
            }
            _ => {}
        }
    }

    if is_smt_arith(bctx, lhs.span, rhs.span, &lhs.hir_id, &rhs.hir_id)? {
        let lhs_inner_ty = maybe_strip_shared_ref(lhs_ty);
        let rhs_inner_ty = maybe_strip_shared_ref(rhs_ty);
        let d0b = if bctx.in_ghost { Div0Behavior::Allow } else { Div0Behavior::Error };
        let vop = match op {
            BinOpKind::Le => BinaryOp::Inequality(InequalityOp::Le),
            BinOpKind::Ge => BinaryOp::Inequality(InequalityOp::Ge),
            BinOpKind::Lt => BinaryOp::Inequality(InequalityOp::Lt),
            BinOpKind::Gt => BinaryOp::Inequality(InequalityOp::Gt),
            BinOpKind::Add | BinOpKind::Sub | BinOpKind::Mul => {
                let ty = bctx.mid_ty_to_vir(lhs.span, &tc.expr_ty_adjusted(lhs))?;
                let range = get_range(&ty);
                let ob = if bctx.in_ghost {
                    OverflowBehavior::Truncate(range)
                } else {
                    OverflowBehavior::Error(range)
                };

                match op {
                    BinOpKind::Add => BinaryOp::Arith(ArithOp::Add(ob)),
                    BinOpKind::Sub => BinaryOp::Arith(ArithOp::Sub(ob)),
                    BinOpKind::Mul => BinaryOp::Arith(ArithOp::Mul(ob)),
                    _ => unreachable!(),
                }
            }
            BinOpKind::Div => match euclidean_or_truncating_div(bctx, lhs, rhs)? {
                Some(width) => {
                    // REVIEW: The non-ghost case is unexpected here; since `/` and `%`
                    // are replaced by builtin spec functions in spec code, this case
                    // should only happen for exec code.
                    if bctx.in_ghost {
                        return err_span(
                            span,
                            "bare division operator (/) in ghost code; it is expected that (/) is translated by the verus macro",
                        );
                    }
                    let sdecb = SignedDivEdgeCaseBehavior::Error(width);
                    BinaryOp::Arith(ArithOp::TruncatingDiv(d0b, sdecb))
                }
                None => BinaryOp::Arith(ArithOp::EuclideanDiv(d0b)),
            },
            BinOpKind::Rem => match euclidean_or_truncating_div(bctx, lhs, rhs)? {
                Some(width) => {
                    if bctx.in_ghost {
                        return err_span(
                            span,
                            "bare modulo operator (%) in ghost code; it is expected that (%) is translated by the verus macro",
                        );
                    }
                    let sdecb = SignedDivEdgeCaseBehavior::Error(width);
                    BinaryOp::Arith(ArithOp::TruncatingMod(d0b, sdecb))
                }
                None => BinaryOp::Arith(ArithOp::EuclideanMod(d0b)),
            },
            BinOpKind::BitXor => match (lhs_inner_ty.kind(), rhs_inner_ty.kind()) {
                (TyKind::Bool, TyKind::Bool) => BinaryOp::BoolXor,
                (TyKind::Int(_), TyKind::Int(_)) => {
                    BinaryOp::Bitwise(BitwiseOp::BitXor, BitshiftBehavior::Allow)
                }
                (TyKind::Uint(_), TyKind::Uint(_)) => {
                    BinaryOp::Bitwise(BitwiseOp::BitXor, BitshiftBehavior::Allow)
                }
                _ => panic!("bitwise XOR for this type not supported"),
            },
            BinOpKind::BitAnd => match (lhs_inner_ty.kind(), rhs_inner_ty.kind()) {
                (TyKind::Bool, TyKind::Bool) => BinaryOp::BoolAndNoSC,
                (TyKind::Int(_), TyKind::Int(_)) => {
                    BinaryOp::Bitwise(BitwiseOp::BitAnd, BitshiftBehavior::Allow)
                }
                (TyKind::Uint(_), TyKind::Uint(_)) => {
                    BinaryOp::Bitwise(BitwiseOp::BitAnd, BitshiftBehavior::Allow)
                }
                t => panic!("bitwise AND for this type not supported {:#?}", t),
            },
            BinOpKind::BitOr => match (lhs_inner_ty.kind(), rhs_inner_ty.kind()) {
                (TyKind::Bool, TyKind::Bool) => BinaryOp::BoolOrNoSC,
                (TyKind::Int(_), TyKind::Int(_)) => {
                    BinaryOp::Bitwise(BitwiseOp::BitOr, BitshiftBehavior::Allow)
                }
                (TyKind::Uint(_), TyKind::Uint(_)) => {
                    BinaryOp::Bitwise(BitwiseOp::BitOr, BitshiftBehavior::Allow)
                }
                _ => panic!("bitwise OR for this type not supported"),
            },
            BinOpKind::Shl => {
                let (Some(w), s) =
                    bitwidth_and_signedness_of_integer_type(&bctx.ctxt.verus_items, lhs_inner_ty)
                else {
                    return err_span(lhs.span, "expected finite integer width for <<");
                };
                let bb_for_ghostness = if bctx.in_ghost {
                    BitshiftBehavior::Allow
                } else {
                    BitshiftBehavior::Error(w)
                };
                BinaryOp::Bitwise(BitwiseOp::Shl(w, s), bb_for_ghostness)
            }
            BinOpKind::Shr => {
                let (Some(w), _s) =
                    bitwidth_and_signedness_of_integer_type(&bctx.ctxt.verus_items, lhs_inner_ty)
                else {
                    return err_span(lhs.span, "expected finite integer width for >>");
                };
                let bb_for_ghostness = if bctx.in_ghost {
                    BitshiftBehavior::Allow
                } else {
                    BitshiftBehavior::Error(w)
                };
                BinaryOp::Bitwise(BitwiseOp::Shr, bb_for_ghostness)
            }
            _ => {
                return Ok(None);
            }
        };
        return Ok(Some(vop));
    };

    Ok(None)
}

fn binopkind_to_binaryop<'tcx>(
    bctx: &BodyCtxt<'tcx>,
    op: &Spanned<BinOpKind>,
    span: Span,
    lhs: &Expr<'tcx>,
    rhs: &Expr<'tcx>,
) -> Result<Option<BinaryOp>, VirErr> {
    binopkind_to_binaryop_inner(bctx, op.node, span, lhs, rhs)
}

fn expr_assign_to_vir_innermost<'tcx>(
    bctx: &BodyCtxt<'tcx>,
    span: Span,
    lhs: &Expr<'tcx>,
    mk_expr: impl Fn(ExprX) -> Result<ExprOrPlace, vir::messages::Message>,
    rhs: &Expr<'tcx>,
    op_kind: Option<&Spanned<AssignOpKind>>,
) -> Result<ExprOrPlace, vir::messages::Message> {
    let vir_lhs = expr_to_vir_place(bctx, lhs)?;
    let vir_lhs = simplify_place_by_cancelling(&vir_lhs);

    let vir_rhs = expr_to_vir_consume(bctx, rhs)?;

    let op = match op_kind {
        Some(op) => match assignop_kind_to_binaryop(bctx, op, span, lhs, rhs)? {
            Some(op) => Some(op),
            None => {
                let lhs_ty = bctx.types.expr_ty_adjusted(lhs);
                let rhs_ty = bctx.types.expr_ty_adjusted(rhs);
                unsupported_err!(
                    span,
                    format!("unsupported binary op: {:?} for {lhs_ty:} and {rhs_ty:}", op.node)
                )
            }
        },
        None => None,
    };

    mk_expr(ExprX::Assign {
        place: vir_lhs,
        rhs: vir_rhs,
        op: op,
        resolve: false,
        typ: bctx.mid_ty_to_vir(lhs.span, &bctx.types.expr_ty_adjusted(lhs))?,
    })
}

pub(crate) fn let_stmt_to_vir<'tcx>(
    bctx: &BodyCtxt<'tcx>,
    pattern: &rustc_hir::Pat<'tcx>,
    initializer: &Option<&Expr<'tcx>>,
    els: &Option<&Block<'tcx>>,
    attrs: &[Attribute],
) -> Result<Vec<vir::ast::Stmt>, VirErr> {
    let mode = get_var_mode(bctx.mode, attrs);
    let parsed_attrs = parse_attrs_opt(attrs, None);
    let infer_mode = parsed_attrs.contains(&Attr::InferMode);
    let prophetic = parsed_attrs.contains(&Attr::Prophetic);
    let els = if let Some(els) = els {
        if matches!(mode, Mode::Spec | Mode::Proof) {
            unsupported_err!(els.span, "let-else in spec/proof", els);
        }
        let init = initializer.unwrap();
        let init_type = typ_of_expr_adjusted(bctx, els.span, &init.hir_id)?;
        let els_typ = typ_of_node_unadjusted(bctx, els.span, &els.hir_id)?;
        let els_block = block_to_vir(bctx, els, &els.span, &els_typ)?;
        Some(bctx.spanned_typed_new(els.span, &init_type, ExprX::NeverToAny(els_block)))
    } else {
        None
    };
    let init = match initializer {
        Some(e) => Some(simplify_place_by_cancelling(&expr_to_vir_place(bctx, e)?)),
        None => None,
    };

    let unwrapped_binding = parse_attrs_opt(attrs, Some(&mut *bctx.ctxt.diagnostics.borrow_mut()))
        .contains(&Attr::UnwrappedBinding);
    if unwrapped_binding {
        let pat_typ = &bctx.types.node_type(pattern.hir_id);
        if let TyKind::Adt(AdtDef(adt_def_data), _args) = pat_typ.kind() {
            let pat_typ_verus_item = bctx.ctxt.verus_items.id_to_name.get(&adt_def_data.did);
            if pat_typ_verus_item
                == Some(&VerusItem::BuiltinType(verus_items::BuiltinTypeItem::Tracked))
                && mode == Mode::Proof
            {
                bctx.warning_maybe(
                    pattern.span,
                    &WarningAllow::NonExecGhostTrackedWrappers,
                    || "the right-hand side is already wrapped with `Tracked`, you likely don't need a `tracked` variable",
                    |msg| {
                        let msg = msg.help("consider `.get()` on the right-hand side, or removing `tracked` on the left-hand side");
                        bctx.ctxt.diagnostics.borrow_mut().push(vir::ast::VirErrAs::Warning(msg));
                    }
                );
            } else if pat_typ_verus_item
                == Some(&VerusItem::BuiltinType(verus_items::BuiltinTypeItem::Ghost))
                && mode == Mode::Spec
            {
                bctx.warning_maybe(
                    pattern.span,
                    &WarningAllow::NonExecGhostTrackedWrappers,
                    || "the right-hand side is already wrapped with `Ghost`, you likely don't need a `ghost` variable",
                    |msg| {
                        let msg = msg.help("consider `@` on the right-hand side, or removing `ghost` on the left-hand side");
                        bctx.ctxt.diagnostics.borrow_mut().push(vir::ast::VirErrAs::Warning(msg));
                    }
                );
            }
        }
    }

    if infer_mode && prophetic {
        crate::internal_err!(pattern.span, "decl is marked infer_mode and prophetic");
    }

    let proph_mode = if prophetic {
        vir::ast::DeclProph::Prophetic
    } else if parsed_attrs.contains(&Attr::InferProph) {
        if mode == Mode::Spec {
            vir::ast::DeclProph::DelayedInfer
        } else {
            vir::ast::DeclProph::Default
        }
    } else {
        vir::ast::DeclProph::Default
    };

    let vir_pattern = pattern_to_vir(bctx, pattern)?;
    let mode = if infer_mode { None } else { Some((mode, proph_mode)) };
    Ok(vec![bctx.spanned_new(
        pattern.span,
        StmtX::Decl { pattern: vir_pattern, mode, init, els, assert_irrefutable: false },
    )])
}

fn unwrap_parameter_to_vir<'tcx>(
    bctx: &BodyCtxt<'tcx>,
    stmt1: &Stmt<'tcx>,
    stmt2: &Stmt<'tcx>,
) -> Result<Vec<vir::ast::Stmt>, VirErr> {
    // match "let x;"
    let x = if let StmtKind::Let(LetStmt {
        pat:
            pat @ Pat {
                kind: PatKind::Binding(BindingMode(ByRef::No, Mutability::Not), hir_id, x, None),
                ..
            },
        ty: None,
        init: None,
        els: None,
        ..
    }) = &stmt1.kind
    {
        Some((pat.hir_id, local_to_var(x, hir_id.local_id)))
    } else {
        None
    };
    // match #[verifier(proof_block)]
    let ghost = get_ghost_block_opt(bctx.ctxt.tcx.hir_attrs(stmt2.hir_id));
    // match { x = y.get() } or { x = y.view() }
    let xy_mode = if let StmtKind::Semi(Expr {
        kind:
            ExprKind::Block(
                Block {
                    stmts: [],
                    expr:
                        Some(Expr {
                            kind:
                                ExprKind::Assign(
                                    expr_x @ Expr { kind: ExprKind::Path(path_x), .. },
                                    expr_get @ Expr {
                                        kind:
                                            ExprKind::MethodCall(
                                                _ident,
                                                expr_y @ Expr {
                                                    kind: ExprKind::Path(path_y), ..
                                                },
                                                [],
                                                _span2,
                                            ),
                                        ..
                                    },
                                    _,
                                ),
                            ..
                        }),
                    ..
                },
                None,
            ),
        ..
    }) = &stmt2.kind
    {
        let fn_def_id = bctx
            .types
            .type_dependent_def_id(expr_get.hir_id)
            .expect("def id of the method definition");
        let verus_item = bctx.ctxt.verus_items.id_to_name.get(&fn_def_id);
        let ident_x = crate::rust_to_vir_base::qpath_to_ident(bctx.ctxt.tcx, path_x);
        let ident_y = crate::rust_to_vir_base::qpath_to_ident(bctx.ctxt.tcx, path_y);
        let mode = match verus_item {
            Some(VerusItem::UnaryOp(UnaryOpItem::SpecGhostTracked(
                SpecGhostTrackedItem::GhostView,
            ))) => Some((Mode::Spec, ResolvedCall::SpecAllowProofArgs)),
            Some(VerusItem::CompilableOpr(CompilableOprItem::TrackedGet)) => {
                Some((Mode::Proof, ResolvedCall::MiscCall(MiscCall::TrackedGet)))
            }
            _ => None,
        };
        Some((expr_x.hir_id, expr_y.hir_id, expr_get.hir_id, ident_x, ident_y, mode))
    } else {
        None
    };
    match (x, ghost, xy_mode) {
        (
            Some((hir_id1, x1)),
            Some(GhostBlockAttr::Proof),
            Some((hir_id2, hir_id_y, hir_id_get, Some(x2), Some(y), Some((mode, resolved_call)))),
        ) if x1 == x2 => {
            let mut erasure_info = bctx.ctxt.erasure_info.borrow_mut();
            erasure_info.direct_var_modes.push((hir_id1, mode));
            erasure_info.direct_var_modes.push((hir_id2, mode));
            erasure_info.direct_var_modes.push((hir_id_y, Mode::Exec));
            erasure_info.resolved_calls.push((
                hir_id_get,
                stmt2.span.data(),
                resolved_call,
                bctx.in_ghost,
            ));
            let unwrap = vir::ast::UnwrapParameter { mode, outer_name: y, inner_name: x1 };
            let headerx = HeaderExprX::UnwrapParameter(unwrap.clone());
            let exprx = ExprX::Header(Arc::new(headerx));
            let expr = bctx.spanned_typed_new(stmt1.span, &Arc::new(TypX::Bool), exprx);
            let stmt = bctx.spanned_new(stmt1.span, StmtX::Expr(expr));
            Ok(vec![stmt])
        }
        _ => err_span(stmt1.span, "ill-formed unwrap_parameter header"),
    }
}

pub(crate) fn stmt_to_vir<'tcx>(
    bctx: &BodyCtxt<'tcx>,
    stmt: &Stmt<'tcx>,
) -> Result<Vec<vir::ast::Stmt>, VirErr> {
    if bctx.external_body {
        // we want just requires/ensures, not the whole body
        match &stmt.kind {
            StmtKind::Expr(..) | StmtKind::Semi(..) => {}
            _ => return Ok(vec![]),
        }
    }

    match &stmt.kind {
        StmtKind::Expr(expr) | StmtKind::Semi(expr) => {
            if is_ignorable_dummy_capture_operation(bctx, expr) {
                record_ignore_dummy_capture_operation(bctx, expr);
                return Ok(vec![]);
            }

            let ep = expr_to_vir(bctx, expr)?;
            let vir_expr = match &ep {
                ExprOrPlace::Expr(expr) if matches!(&expr.x, ExprX::Header(..)) => expr.clone(),
                _ => {
                    // Just writing `x;` technically counts as a move of a `x`
                    // but for the sake of resolution analysis, we don't want to treat
                    // it as a move (since it will just get dropped) so it gets the special
                    // 'Unused' kind
                    let expr_ty = bctx.types.expr_ty_adjusted(expr);
                    ep.unused(bctx, expr.span, expr_ty)?
                }
            };
            Ok(vec![bctx.spanned_new(expr.span, StmtX::Expr(vir_expr))])
        }
        StmtKind::Item(item_id) => {
            let attrs = bctx.ctxt.tcx.hir_attrs(item_id.hir_id());
            let vattrs = bctx.ctxt.get_verifier_attrs(attrs)?;
            if vattrs.internal_reveal_fn {
                dbg!(&item_id.hir_id());
                unreachable!();
            } else if vattrs.internal_const_body {
                dbg!(&item_id.hir_id());
                unreachable!();
            } else if vattrs.open_visibility_qualifier {
                let vis = get_open_visibility_qualifier(&bctx.ctxt, *item_id)?;
                let vir_expr = bctx.spanned_typed_new(
                    stmt.span,
                    &vir::ast_util::unit_typ(),
                    ExprX::Header(Arc::new(HeaderExprX::OpenVisibilityQualifier(vis))),
                );

                Ok(vec![bctx.spanned_new(stmt.span, StmtX::Expr(vir_expr))])
            } else {
                let item = bctx.ctxt.tcx.hir_item(*item_id);
                match &item.kind {
                    ItemKind::Use(..) | ItemKind::Macro(..) => {
                        return Ok(vec![]);
                    }
                    ItemKind::Struct(..) | ItemKind::Enum(..) => {
                        // Nested datatypes are handled elsewhere as standalone items
                        // It doesn't matter that they also appear here as statements
                        return Ok(vec![]);
                    }
                    ItemKind::Fn { .. }
                    | ItemKind::Const(..)
                    | ItemKind::Static(Mutability::Not, ..) => {
                        // Nested functions, constants and immutable statics are handled
                        // elsewhere as standalone items, including their initializer proofs.
                        // It doesn't matter that they also appear here as statements
                        return Ok(vec![]);
                    }
                    _ => {
                        unsupported_err!(stmt.span, "internal item statements", stmt)
                    }
                }
            }
        }
        StmtKind::Let(LetStmt { pat, ty: _, init, els, .. }) => {
            if let Some(init) = init {
                if is_ignorable_dummy_capture_operation(bctx, init) {
                    record_ignore_dummy_capture_operation(bctx, init);
                    return Ok(vec![]);
                }
            }

            let_stmt_to_vir(bctx, pat, init, els, bctx.ctxt.tcx.hir_attrs(stmt.hir_id))
        }
    }
}

pub(crate) fn get_open_visibility_qualifier<'tcx>(
    ctxt: &Context<'tcx>,
    item_id: rustc_hir::ItemId,
) -> Result<vir::ast::Visibility, VirErr> {
    let item = ctxt.tcx.hir_item(item_id);
    if !matches!(&item.kind, ItemKind::Use(..)) {
        crate::internal_err!(item.span, "open_visibility_qualifier should be on a 'use' item");
    }

    let hir_id = item.hir_id();
    let owner_id = hir_id.expect_owner();
    let def_id = owner_id.to_def_id();

    let vis = ctxt.tcx.visibility(def_id);
    Ok(crate::rust_to_vir_base::mk_visibility_from_vis(ctxt, vis))
}

pub(crate) fn stmts_to_vir<'tcx>(
    bctx: &BodyCtxt<'tcx>,
    stmts: &mut impl Iterator<Item = &'tcx Stmt<'tcx>>,
) -> Result<Option<Vec<vir::ast::Stmt>>, VirErr> {
    if let Some(stmt) = stmts.next() {
        let attrs = crate::attributes::parse_attrs_opt(bctx.ctxt.tcx.hir_attrs(stmt.hir_id), None);
        if let [Attr::UnwrapParameter] = attrs[..] {
            if let Some(stmt2) = stmts.next() {
                return Ok(Some(unwrap_parameter_to_vir(bctx, stmt, stmt2)?));
            } else {
                return err_span(stmt.span, "ill-formed unwrap_parameter header");
            }
        }
        Ok(Some(stmt_to_vir(bctx, stmt)?))
    } else {
        Ok(None)
    }
}

pub(crate) fn is_ignorable_dummy_capture_operation<'tcx>(
    bctx: &BodyCtxt<'tcx>,
    expr: &Expr<'tcx>,
) -> bool {
    match &expr.kind {
        ExprKind::Call(fun, _) => match &fun.kind {
            ExprKind::Path(QPath::Resolved(
                None,
                rustc_hir::Path { res: Res::Def(_, fun_id), .. },
            )) => {
                let verus_item = bctx.ctxt.get_verus_item(*fun_id);
                matches!(
                    verus_item,
                    Some(VerusItem::DummyCapture(
                        DummyCaptureItem::New | DummyCaptureItem::Consume
                    ))
                )
            }
            _ => false,
        },
        _ => false,
    }
}

pub(crate) fn record_ignore_dummy_capture_operation<'tcx>(
    bctx: &BodyCtxt<'tcx>,
    expr: &Expr<'tcx>,
) {
    crate::fn_call_to_vir::record_call(bctx, expr, ResolvedCall::MiscEraseAbsolutely);
}

pub(crate) fn closure_to_vir<'tcx>(
    bctx: &BodyCtxt<'tcx>,
    closure_expr: &Expr<'tcx>,
    closure_vir_typ: Typ,
    is_spec_fn: bool,
    proof_fn_modes: Option<(Arc<Vec<Mode>>, Mode)>,
) -> Result<vir::ast::Expr, VirErr> {
    if let ExprKind::Closure(Closure { fn_decl, body: body_id, def_id, .. }) = &closure_expr.kind {
        unsupported_err_unless!(!fn_decl.c_variadic(), closure_expr.span, "c_variadic");
        unsupported_err_unless!(
            matches!(fn_decl.implicit_self(), rustc_hir::ImplicitSelfKind::None),
            closure_expr.span,
            "implicit_self in closure"
        );
        let body = bctx.ctxt.tcx.hir_body(*body_id);

        let typs = closure_param_typs(bctx, closure_expr)?;
        assert!(typs.len() == body.params.len());

        let mut pattern_stmts = Vec::new();

        let params: Vec<VarBinder<Typ>> = body
            .params
            .iter()
            .zip(typs.clone())
            .map(|(x, t)| {
                let attrs = bctx.ctxt.tcx.hir_attrs(x.hir_id);
                let mode = crate::attributes::get_mode(Mode::Exec, attrs);
                if mode != Mode::Exec {
                    return err_span(x.span, "closures only accept exec-mode parameters");
                }

                let (_is_mut, name) = param_pat_to_mut_var(x.pat)?;
                let decl = param_pat_to_decl(bctx, x.pat, &name, &t, Mode::Exec)?;
                pattern_stmts.extend(decl);
                Ok(Arc::new(VarBinderX { name, a: t }))
            })
            .collect::<Result<Vec<_>, _>>()?;

        // Closures may be called multiple times, so their bodies must not inherit
        // the enclosing atomically block's update function.
        let bctx = &BodyCtxt { atomically: None, ..bctx.clone() };
        let body_bctx = if is_spec_fn {
            bctx
        } else {
            let mut all_params = (*bctx.params).clone();
            all_params.push(params.iter().map(|p| p.name.clone()).collect());
            let bctx = bctx.set_header_setting(HeaderSetting::Fn);
            &BodyCtxt { params: std::rc::Rc::new(all_params), ..bctx }
        };

        let mut body = expr_to_vir_consume(body_bctx, &body.value)?;

        let mut header =
            vir::headers::read_header(&mut body, &vir::headers::HeaderAllows::Closure)?;
        add_param_decls(&bctx.ctxt, closure_expr.span, &mut header, &mut body, pattern_stmts)?;
        let vir::headers::Header { require, ensure, ensure_id_typ, .. } = header;
        assert!(ensure.1.len() == 0);

        let exprx = if is_spec_fn {
            bctx.ctxt.push_body_erasure(*def_id, BodyErasure { erase_body: true, ret_spec: true });

            if require.len() > 0 || ensure.0.len() > 0 {
                return err_span(
                    closure_expr.span,
                    "SpecFn should not have `requires` clause or `ensures` clause",
                );
            }
            ExprX::Closure(Arc::new(params), body)
        } else {
            bctx.ctxt.push_body_erasure(
                *def_id,
                BodyErasure {
                    erase_body: false,
                    ret_spec: match proof_fn_modes {
                        None => false,
                        Some((_, ret_mode)) => ret_mode == Mode::Spec,
                    },
                },
            );

            let ret_typ = closure_ret_typ(bctx, closure_expr)?;

            let id = match ensure_id_typ {
                Some((id, Some(ensures_typ))) => {
                    if !types_equal(&ensures_typ, &ret_typ) {
                        return err_span(
                            closure_expr.span,
                            "return type given in `ensures` clause should match the actual closure return type",
                        );
                    }
                    id
                }
                Some((id, None)) => id,
                None => str_unique_var(
                    vir::def::CLOSURE_RETURN_VALUE_PREFIX,
                    vir::ast::VarIdentDisambiguate::RustcId(body_id.hir_id.local_id.index()),
                ),
            };

            let ret = Arc::new(VarBinderX { name: id, a: ret_typ });

            ExprX::NonSpecClosure {
                params: Arc::new(params),
                proof_fn_modes,
                body,
                requires: require,
                ensures: ensure.0,
                ret: ret,
                external_spec: None, // filled in by ast_simplify
            }
        };
        Ok(bctx.spanned_typed_new(closure_expr.span, &closure_vir_typ, exprx))
    } else {
        panic!("closure_to_vir expects ExprKind::Closure");
    }
}

fn remove_decoration_typs_for_unsizing<'tcx>(
    tcx: TyCtxt<'tcx>,
    ty1: rustc_middle::ty::Ty<'tcx>,
    ty2: rustc_middle::ty::Ty<'tcx>,
) -> (rustc_middle::ty::Ty<'tcx>, rustc_middle::ty::Ty<'tcx>) {
    match (ty1.kind(), ty2.kind()) {
        (TyKind::Ref(_, t1, Mutability::Not), TyKind::Ref(_, t2, Mutability::Not)) => {
            remove_decoration_typs_for_unsizing(tcx, *t1, *t2)
        }
        (TyKind::Adt(AdtDef(adt_def_data1), args1), TyKind::Adt(AdtDef(adt_def_data2), args2))
            if (verus_items::get_rust_item(tcx, adt_def_data1.did)
                == Some(verus_items::RustItem::Box)
                && verus_items::get_rust_item(tcx, adt_def_data2.did)
                    == Some(verus_items::RustItem::Box))
                || (verus_items::get_rust_item(tcx, adt_def_data1.did)
                    == Some(verus_items::RustItem::Arc)
                    && verus_items::get_rust_item(tcx, adt_def_data2.did)
                        == Some(verus_items::RustItem::Arc))
                || (verus_items::get_rust_item(tcx, adt_def_data1.did)
                    == Some(verus_items::RustItem::Rc)
                    && verus_items::get_rust_item(tcx, adt_def_data2.did)
                        == Some(verus_items::RustItem::Rc)) =>
        {
            let Some(t1) = args1[0].as_type() else { panic!("unexpected type argument") };
            let Some(t2) = args2[0].as_type() else { panic!("unexpected type argument") };
            remove_decoration_typs_for_unsizing(tcx, t1, t2)
        }
        _ => (ty1, ty2),
    }
}

enum PtrCastKind {
    Trivial,
    Complex(vir::ast::Fun, vir::ast::Typs, bool),
}

fn is_ptr_cast<'tcx>(
    bctx: &BodyCtxt<'tcx>,
    span: Span,
    src: rustc_middle::ty::Ty<'tcx>,
    dst: rustc_middle::ty::Ty<'tcx>,
) -> Result<Option<PtrCastKind>, VirErr> {
    // Mutability can always be ignored
    match (src.kind(), dst.kind()) {
        (TyKind::RawPtr(ty1, _), TyKind::RawPtr(ty2, _)) => {
            if ty1 == ty2 {
                return Ok(Some(PtrCastKind::Trivial));
            } else if ty2
                .is_sized(bctx.ctxt.tcx, TypingEnv::post_analysis(bctx.ctxt.tcx, bctx.fun_id))
            {
                let src_ty = bctx.mid_ty_to_vir(span, ty1)?;
                let dst_ty = bctx.mid_ty_to_vir(span, ty2)?;
                let fun = vir::fun!(CrateId::Vstd => "raw_ptr", "cast_ptr_to_thin_ptr");
                let typs = Arc::new(vec![src_ty, dst_ty]);
                return Ok(Some(PtrCastKind::Complex(fun, typs, false)));
            } else {
                match (ty1.kind(), ty2.kind()) {
                    (TyKind::Slice(s1), TyKind::Slice(s2)) => {
                        let arg1 = bctx.mid_ty_to_vir(span, s1)?;
                        let arg2 = bctx.mid_ty_to_vir(span, s2)?;
                        let fun =
                            vir::fun!(CrateId::Vstd => "raw_ptr", "cast_slice_ptr_to_slice_ptr");
                        let typs = Arc::new(vec![arg1, arg2]);
                        return Ok(Some(PtrCastKind::Complex(fun, typs, false)));
                    }
                    (TyKind::Slice(s1), TyKind::Str) => {
                        let arg = bctx.mid_ty_to_vir(span, s1)?;
                        let fun =
                            vir::fun!(CrateId::Vstd => "raw_ptr", "cast_slice_ptr_to_str_ptr");
                        let typs = Arc::new(vec![arg]);
                        return Ok(Some(PtrCastKind::Complex(fun, typs, false)));
                    }
                    (TyKind::Str, TyKind::Slice(s2)) => {
                        let arg = bctx.mid_ty_to_vir(span, s2)?;
                        let fun =
                            vir::fun!(CrateId::Vstd => "raw_ptr", "cast_str_ptr_to_slice_ptr");
                        let typs = Arc::new(vec![arg]);
                        return Ok(Some(PtrCastKind::Complex(fun, typs, false)));
                    }
                    _ => {}
                }
            }
            return Ok(None);
        }
        (TyKind::RawPtr(ty1, _), _ty2)
            if crate::rust_to_vir_base::is_integer_ty(&bctx.ctxt.verus_items, &dst) =>
        {
            let src_ty = bctx.mid_ty_to_vir(span, ty1)?;
            let typs = Arc::new(vec![src_ty]);
            let fun = vir::fun!(CrateId::Vstd => "raw_ptr", "cast_ptr_to_usize");

            // cast_ptr_to_usize casts to a usize; we might need to do an additional
            // clip afterwards, so return with clip=true
            return Ok(Some(PtrCastKind::Complex(fun, typs, true)));
        }
        _ => Ok(None),
    }
}

pub(crate) fn maybe_do_ptr_cast<'tcx>(
    bctx: &BodyCtxt<'tcx>,
    dst_expr: &Expr,
    src_expr: &Expr,
    src_vir: &vir::ast::Expr,
) -> Result<Option<vir::ast::Expr>, VirErr> {
    let source_ty = bctx.types.expr_ty_adjusted(src_expr);
    let to_ty = bctx.types.expr_ty(dst_expr);
    match is_ptr_cast(bctx, dst_expr.span, source_ty, to_ty)? {
        Some(PtrCastKind::Trivial) => {
            return Ok(Some(src_vir.clone()));
        }
        Some(PtrCastKind::Complex(fun, typ_args, clip)) => {
            let autospec_usage =
                if bctx.in_ghost { AutospecUsage::IfMarked } else { AutospecUsage::Final };
            let call_target_attrs = vir::ast::CallTargetAttrs {
                autospec: autospec_usage,
                const_var: false,
                assume_external_allowed: false,
            };
            let call_target = CallTarget::Fun(
                vir::ast::CallTargetKind::Static,
                fun,
                typ_args,
                Arc::new(vec![]),
                call_target_attrs,
            );
            let args = Arc::new(vec![src_vir.clone()]);
            let x = ExprX::Call { target: call_target, args, post_args: None, body: None };
            let expr_typ = typ_of_node_unadjusted(bctx, dst_expr.span, &dst_expr.hir_id)?;

            if clip {
                let expr_attrs = bctx.ctxt.tcx.hir_attrs(dst_expr.hir_id);
                let expr_vattrs = bctx.ctxt.get_verifier_attrs(expr_attrs)?;

                let expr =
                    bctx.spanned_typed_new(dst_expr.span, &Arc::new(TypX::Int(IntRange::USize)), x);
                return Ok(Some(mk_ty_clip(bctx, &expr_typ, &expr, expr_vattrs.truncate)));
            } else {
                let expr = bctx.spanned_typed_new(dst_expr.span, &expr_typ, x);
                return Ok(Some(expr));
            }
        }
        None => Ok(None),
    }
}

/// Handle deref for "primitive" deref operations:
///   - Box<T> -> T
///   - &T -> T
///   - &mut T -> T
///   - *mut T -> T (unsupported)
pub(crate) fn deref_primitive<'tcx>(
    bctx: &BodyCtxt<'tcx>,
    span: Span,
    ty: rustc_middle::ty::Ty<'tcx>,
    place: &Place,
) -> Result<Place, VirErr> {
    match ty.kind() {
        TyKind::Ref(_, _, rustc_ast::Mutability::Mut) => {
            // &mut T -> T
            deref_mut(bctx, span, place)
        }
        TyKind::Ref(_, _, rustc_ast::Mutability::Not) => {
            // &T -> T
            // Immutable reference is implicit
            Ok(place.clone())
        }
        TyKind::Adt(adt_def, args)
            if Some(adt_def.did()) == bctx.ctxt.tcx.lang_items().owned_box() =>
        {
            // Box<T> -> T
            // Box is implicit
            Ok(place.clone())
        }
        TyKind::RawPtr(..) => {
            unsupported_err!(
                span,
                format!(
                    "dereferencing a raw pointer. Currently, Verus only supports raw pointers through the permissioned raw_ptr interface: https://verus-lang.github.io/verus/verusdoc/vstd/raw_ptr/index.html"
                )
            );
        }
        _ => {
            unsupported_err!(span, format!("primitive deref operation for {ty:?}"))
        }
    }
}

/// Handle overloaded deref. This is equivalent to either:
///  *deref(e)
/// or:
///  *deref_mut(e)
///
/// Depending on the mutability of the type.
/// Note that this operation has type
/// `&T -> <T as Deref>::Target` or `&mut T -> <T as Deref>::Target`
/// This matches UnOp::Deref.
///
/// Note that _adjustment derefs_, you start with T, so you need to apply
/// the & or &mut first before calling.
///
/// Doesn't handle Tracked or Ghost, those should be handled by caller.
///
/// fn_def_id: DefId of deref or deref_mut
/// ty: the `&T` or `&mut T`
/// target_ty: the output type, `<T as Deref>::Target`
pub(crate) fn deref_overloaded<'tcx>(
    bctx: &BodyCtxt<'tcx>,
    span: Span,
    fn_def_id: DefId,
    ty: rustc_middle::ty::Ty<'tcx>,
    target_ty: rustc_middle::ty::Ty<'tcx>,
    expr: &vir::ast::Expr,
) -> Result<Place, VirErr> {
    match ty.kind() {
        TyKind::Ref(_, inner_ty, rustc_ast::Mutability::Not) => {
            // deref

            let ref_of_target_ty = bctx.ctxt.tcx.mk_ty_from_kind(TyKind::Ref(
                bctx.ctxt.tcx.lifetimes.re_erased,
                target_ty,
                Mutability::Not,
            ));
            let ref_of_target_typ = bctx.mid_ty_to_vir(span, &ref_of_target_ty)?;

            // Method call first:
            let call_expr = match inner_ty.kind() {
                TyKind::Adt(adt_def, args)
                    if matches!(
                        verus_items::get_rust_item(bctx.ctxt.tcx, adt_def.did()),
                        Some(RustItem::Rc | RustItem::Arc)
                    ) =>
                {
                    // &Rc<T> -> T or &Arc<T> -> T
                    // This is special-cased to elide any method call since these are the identity
                    // in our encoding
                    expr.clone()
                }
                _ => crate::fn_call_to_vir::call_deref(
                    bctx,
                    span,
                    ref_of_target_typ.clone(),
                    fn_def_id,
                    expr.clone(),
                    ty,
                )?,
            };
            let temp_place = bctx.spanned_typed_new(
                span,
                &ref_of_target_typ,
                PlaceX::Temporary(call_expr.clone()),
            );
            // Immutable dereference is implicit
            Ok(temp_place)
        }
        TyKind::Ref(_, _inner_ty, rustc_ast::Mutability::Mut) => {
            let ref_of_target_ty = bctx.ctxt.tcx.mk_ty_from_kind(TyKind::Ref(
                bctx.ctxt.tcx.lifetimes.re_erased,
                target_ty,
                Mutability::Mut,
            ));
            let ref_of_target_typ = bctx.mid_ty_to_vir(span, &ref_of_target_ty)?;

            let call_expr = crate::fn_call_to_vir::call_deref(
                bctx,
                span,
                ref_of_target_typ.clone(),
                fn_def_id,
                expr.clone(),
                ty,
            )?;

            let temp_place = bctx.spanned_typed_new(
                span,
                &ref_of_target_typ,
                PlaceX::Temporary(call_expr.clone()),
            );

            deref_mut(bctx, span, &temp_place)
        }
        _ => {
            crate::internal_err!(span, format!("overloaded deref expected ref or mut ref"))
        }
    }
}

pub(crate) fn deref_mut(bctx: &BodyCtxt, span: Span, place: &Place) -> Result<Place, VirErr> {
    // Error if `*x` is used in the postcondition where `x` is a mutable reference
    //
    // Ok:
    //    *old(x)
    //    *old(x.field)
    //    old(*x)
    //    *fin(x)
    // Bad:
    //    *x
    //    *x.field
    //    fin(*x)
    //
    // Note that in order to display an error we need both:
    //  - dereference is not inside an `old` node
    //  - there is no `old` node between the dereference and the variable
    if bctx.in_postcondition && !bctx.in_old {
        if let Some(local_place) = vir::ast_util::place_get_local(place) {
            let PlaceX::Local(name) = &local_place.x else { unreachable!() };
            if bctx.is_param_for_innermost_fn_or_non_spec_closure(name) {
                return Err(vir::messages::error(
                    &place.span,
                    "to dereference a mutable reference parameter in a postcondition, disambiguate by wrapping it in either `old` or `final`",
                ).help("For information on the new mutable reference support, see: https://github.com/verus-lang/verus/blob/main/source/docs/migration-mut-ref.md"));
            }
        }
    }

    // *final(x) is equivalent to mut_ref_future(x)

    match &place.x {
        PlaceX::Temporary(e) => match &e.x {
            ExprX::Unary(UnaryOp::MutRefFinal(_), arg) => {
                let t = match &*undecorate_typ(&place.typ) {
                    TypX::MutRef(t) => t.clone(),
                    _ => panic!("expected mut ref"),
                };

                let op = UnaryOp::MutRefFuture(vir::ast::MutRefFutureSourceName::Final);
                let e = bctx.spanned_typed_new(span, &t, ExprX::Unary(op, arg.clone()));
                return Ok(bctx.spanned_typed_new(span, &t, PlaceX::Temporary(e)));
            }
            _ => {}
        },
        _ => {}
    }

    let t = match &*undecorate_typ(&place.typ) {
        TypX::MutRef(t) => t.clone(),
        _ => panic!("expected mut ref"),
    };
    Ok(bctx.spanned_typed_new(span, &t, PlaceX::DerefMut(place.clone())))
}

pub(crate) fn borrow_mut_vir(
    bctx: &BodyCtxt,
    span: Span,
    place: &Place,
    allow_two_phase: AllowTwoPhase,
) -> vir::ast::Expr {
    let place = simplify_place_by_cancelling(place);

    // In general, `&mut *x` does NOT cancel itself out;
    // this is a reborrow which has nontrivial semantics.
    // However, if x is a temporary, then it's ok.

    match &place.x {
        PlaceX::DerefMut(inner_place) => match &inner_place.x {
            PlaceX::Temporary(temp) => {
                return temp.clone();
            }
            _ => {}
        },
        _ => {}
    }

    let x = match allow_two_phase {
        AllowTwoPhase::Yes => {
            if place.x.uses_unnamed_temporary() {
                ExprX::BorrowMut(place.clone())
            } else {
                ExprX::TwoPhaseBorrowMut(place.clone())
            }
        }
        AllowTwoPhase::No => ExprX::BorrowMut(place.clone()),
    };
    let typ = Arc::new(TypX::MutRef(place.typ.clone()));
    bctx.spanned_typed_new(span, &typ, x)
}

fn ctor_tail_get_taken_fields<'tcx>(
    bctx: &BodyCtxt<'tcx>,
    expr: &Expr<'tcx>,
) -> Result<Arc<Vec<(vir::ast::Ident, UnfinalizedReadKind)>>, VirErr> {
    let ExprKind::Struct(_, fields, _) = &expr.kind else {
        crate::internal_err!(
            expr.span,
            "ctor_tail_get_taken_fields should only be called for ExprKind::Struct"
        );
    };

    let ty = bctx.types.node_type(expr.hir_id);
    let TyKind::Adt(adt_def, args) = ty.kind() else {
        crate::internal_err!(expr.span, "Expected TyKind::Adt for struct expression");
    };

    if !adt_def.is_struct() {
        crate::internal_err!(expr.span, "Expected struct for struct expression with tail");
    }
    let variant_def = adt_def.non_enum_variant();

    let mut taken_fields = vec![];
    // Iterate over all fields that are NOT present in the given struct expression.
    for field_def in variant_def.fields.iter() {
        if fields.iter().any(|f| f.ident.name == field_def.name) {
            continue;
        }
        let ty = bctx.ctxt.tcx.normalize_erasing_regions(
            TypingEnv::post_analysis(bctx.ctxt.tcx, bctx.fun_id),
            field_def.ty(bctx.ctxt.tcx, args),
        );
        let rk = if bctx.is_copy(ty) { vir::ast::ReadKind::Copy } else { vir::ast::ReadKind::Move };
        let rk = UnfinalizedReadKind { preliminary_kind: rk, id: bctx.ctxt.unique_read_kind_id() };
        let ident = field_ident_from_rust(field_def.name.as_str());
        taken_fields.push((ident, rk));
    }

    if fields.len() + taken_fields.len() != variant_def.fields.len() {
        crate::internal_err!(expr.span, "ctor_tail_get_taken_fields: field counts are wrong");
    }

    Ok(Arc::new(taken_fields))
}

/**
This performs the simplification `*&mut P  -->  P` throughout a given Place.

This is needed mainly because our handling of Ghost::borrow_mut and Tracked::borrow_mut
requires it (see the explanation in fn_call_to_vir).
It also has the side-benefit of simplifying the VCs in some cases, though the cases
where it matters are not very common, I think.

However, we need to be careful, because this simplification is not always semantics-preserving.
The tricky cases are (see the mut_ref_temporary_cant_be_elided test case):

```rust
fn test1() {
    let mut a: [u64; 2] = [0, 1];
    let mut b: [u64; 2] = [2, 3];
    let mut x = &mut a;

    let z = x[ ({ x = &mut b; 0 }) ];
    assert(z == 2);
}
```

vs.

```rust
fn test2() {
    let mut a: [u64; 2] = [0, 1];
    let mut b: [u64; 2] = [2, 3];
    let mut x = &mut a;

    let z = (&mut *x)[ ({ x = &mut b; 0 }) ];
    assert(z == 0);
}
```

The difference is in the evaluation order. In the first case, there is effectively one
place expression, `(*x)[_]`. This means the `*x` is not evaluated until AFTER the index expression.
In the second case, the explicit mutable reference "splits" the place expression, forcing the
evaluation of `*x` early.

Therefore, this should only be called on a place when you know how that place is being used.
For example, when constructing an expression like `&mut P` or `P = rhs`, you can go ahead
and call `simplify_place_by_cancelling` on P. But if P is only partially constructed
might be composed with an Index place later, it's not safe to call this yet.
*/
pub(crate) fn simplify_place_by_cancelling(place: &Place) -> Place {
    match &place.x {
        PlaceX::Field(opr, p) => {
            let p = simplify_place_by_cancelling(p);
            SpannedTyped::new(&place.span, &place.typ, PlaceX::Field(opr.clone(), p))
        }
        PlaceX::ModeUnwrap(p, mwm) => {
            let p = simplify_place_by_cancelling(p);
            SpannedTyped::new(&place.span, &place.typ, PlaceX::ModeUnwrap(p, *mwm))
        }
        PlaceX::DerefMut(p) => {
            match &p.x {
                PlaceX::Temporary(e) => {
                    match &e.x {
                        ExprX::BorrowMut(p) => {
                            return p.clone();
                        }
                        ExprX::TwoPhaseBorrowMut(p) => {
                            return p.clone();
                        }
                        ExprX::ImplicitReborrowOrSpecRead(inner_place, _, _inner_span) => {
                            // There's the case where the ImplicitReborrowOrSpecRead is ignored,
                            // and the case where it's not ignored.
                            // If it's not ignored, then:
                            //      * ImplicitReborrow(x) --> * &mut *x --> *x
                            // If it IS ignored, then we just immediately have:
                            //      * ImplicitReborrow(x) --> * x
                            //
                            // Also note that in this case, we won't have called
                            // `simplify_place_by_cancelling` on the inner_place yet,
                            // so do so now.
                            let p = SpannedTyped::new(
                                &place.span,
                                &place.typ,
                                PlaceX::DerefMut(inner_place.clone()),
                            );
                            return simplify_place_by_cancelling(&p);
                        }
                        _ => {}
                    }
                }
                _ => {}
            }
            let p = simplify_place_by_cancelling(p);
            SpannedTyped::new(&place.span, &place.typ, PlaceX::DerefMut(p))
        }
        PlaceX::Local(..) => place.clone(),
        // For the reasons above, we stop if we encounter an Index place.
        PlaceX::Index(..) => place.clone(),
        PlaceX::Temporary(..) => place.clone(),
        PlaceX::WithExpr(..) | PlaceX::UserDefinedTypInvariantObligation(..) => {
            panic!("simplify_place_by_cancelling got unexpected place kind");
        }
    }
}

fn ty_is_raw_ptr<'tcx>(ty: rustc_middle::ty::Ty<'tcx>) -> bool {
    matches!(ty.kind(), TyKind::RawPtr(_, Mutability::Not | Mutability::Mut))
}

fn ty_is_bool_or_ref_bool<'tcx>(ty: rustc_middle::ty::Ty<'tcx>) -> bool {
    match ty.kind() {
        TyKind::Bool => true,
        TyKind::Ref(_, t, rustc_ast::Mutability::Not) => match t.kind() {
            TyKind::Bool => true,
            _ => false,
        },
        _ => false,
    }
}

fn maybe_strip_shared_ref<'tcx>(ty: rustc_middle::ty::Ty<'tcx>) -> rustc_middle::ty::Ty<'tcx> {
    match ty.kind() {
        TyKind::Ref(_, t, rustc_ast::Mutability::Not) => *t,
        _ => ty,
    }
}

fn ty_is_integer_or_ref_integer<'tcx>(
    bctx: &BodyCtxt<'tcx>,
    ty: rustc_middle::ty::Ty<'tcx>,
) -> bool {
    is_integer_ty(&bctx.ctxt.verus_items, &maybe_strip_shared_ref(ty))
}

fn ty_is_float_or_ref_float<'tcx>(ty: rustc_middle::ty::Ty<'tcx>) -> bool {
    maybe_strip_shared_ref(ty).is_floating_point()
}

/// Check that we can unambiguously identify a loop inside this loop_isolation_boundary block,
/// and return the 'loop_isolation' parameter and Label of that loop.
///
/// The exact form of the block isn't really important;
/// we just need to make sure that the loop we pick
/// corresponds to the one that is intended for any source
/// code that the syntax macro might emit.
/// (After this point, we use the Label to identify the loop.)
fn loop_isolation_boundary_check(
    span: Span,
    block: &vir::ast::Expr,
) -> Result<(bool, vir::ast::Label), VirErr> {
    let err =
        || crate::internal_err!(span, "loop_isolation_boundary block not of the expected form");

    let ExprX::Block(stmts, Some(e)) = &block.x else {
        return err();
    };
    if let ExprX::Loop { loop_isolation, label, .. } = &e.x {
        return Ok((*loop_isolation, label.clone()));
    }

    // Check that this block has the form:
    // {
    //   let x = match y { mut z => loop { } }; x
    // }

    let ExprX::ReadPlace(place, _) = &e.x else {
        return err();
    };
    let PlaceX::Local(l) = &place.x else {
        return err();
    };

    if stmts.len() == 0 {
        return err();
    }
    let StmtX::Decl { pattern, mode: _, init: Some(init), els: None, assert_irrefutable: false } =
        &stmts[stmts.len() - 1].x
    else {
        return err();
    };
    let PatternX::Var(pattern_binding) = &pattern.x else {
        return err();
    };
    if &pattern_binding.name != l {
        return err();
    }

    let PlaceX::Temporary(temp) = &init.x else {
        return err();
    };
    let ExprX::Match(_, arms, false) = &temp.x else {
        return err();
    };
    if arms.len() != 1 {
        return err();
    }

    if let ExprX::Loop { loop_isolation, label, .. } = &arms[0].x.body.x {
        return Ok((*loop_isolation, label.clone()));
    }

    err()
}
