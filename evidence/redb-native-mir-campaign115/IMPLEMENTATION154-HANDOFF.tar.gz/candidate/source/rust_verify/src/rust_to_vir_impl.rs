use crate::automatic_derive::is_automatically_derived;
use crate::context::Context;
use crate::external::CrateItems;
use crate::rust_to_vir::State;
use crate::rust_to_vir_base::{
    def_id_to_vir_path_option, mid_ty_const_to_vir, mk_visibility, typ_path_and_ident_to_vir_path,
};
use crate::rust_to_vir_func::{CheckItemFnEither, FunctionOrConstInfo, check_item_fn};
use crate::unsupported_err;
use crate::util::{err_span, err_span_vec, vir_err_span_str};
use crate::verus_items::{self, MarkerItem, RustItem, VerusItem};
use indexmap::{IndexMap, IndexSet};
use rustc_hir::{ConstItemRhs, ImplItemKind, Item, QPath, Safety, TraitImplHeader, TraitRef};
use rustc_middle::ty::{AssocKind, GenericArgKind, PseudoCanonicalInput, RegionExt, TypingEnv};
use rustc_span::def_id::DefId;
use rustc_span::hygiene::MacroKind;
use rustc_span::{ExpnKind, Span, sym};
use std::collections::{HashMap, HashSet};
use std::sync::Arc;
use vir::ast::{
    AssocTypeImpl, AssocTypeImplX, Dt, Fun, FunX, FunctionKind, Ident, Krate, KrateX, Mode, Path,
    Trait, TraitImpl, Typ, Typs, VirErr,
};

// Used to collect all needed external trait implementations
pub(crate) struct ExternalInfo {
    // all known local traits (both declared-in-verus and #[verifier::external_trait_specification])
    // TODO: include marker traits, once we're confident we can handle them
    pub(crate) local_trait_ids: Vec<DefId>,
    // all known traits (both declared-in-verus and #[verifier::external_trait_specification])
    pub(crate) trait_id_set: HashSet<DefId>,
    // all known datatypes (both declared-in-verus and #[verifier::external_type_specification])
    // bool flag is false for imported, true for new to this crate
    type_paths: HashMap<Path, bool>,
    // type_id_map[d] will be Some(b) if path(d) is in type_paths; otherwise None or absent
    // bool flag is false for imported, true for new to this crate
    type_id_map: HashMap<DefId, Option<bool>>,
    // all non-external trait impls
    pub(crate) internal_trait_impls: HashSet<DefId>,
    // all #[verifier::external_fn_specification] functions that implement a trait
    pub(crate) external_fn_specification_trait_method_impls: Vec<(DefId, rustc_span::Span)>,
    // For verifier::external_trait_extension(TSpec via TSpecImpl),
    // replace all "impl TSpecImpl" with "impl TSpec"
    pub(crate) external_trait_extension_impl_map: HashMap<Path, Path>,
}

impl ExternalInfo {
    pub(crate) fn new() -> ExternalInfo {
        ExternalInfo {
            local_trait_ids: Vec::new(),
            trait_id_set: HashSet::new(),
            type_paths: HashMap::new(),
            type_id_map: HashMap::new(),
            internal_trait_impls: HashSet::new(),
            external_fn_specification_trait_method_impls: Vec::new(),
            external_trait_extension_impl_map: HashMap::new(),
        }
    }

    // None if doesn't have type_id
    // Some(b) is has type id (b is false for imported, true for new to this crate)
    pub(crate) fn has_type_id<'tcx>(
        &mut self,
        ctxt: &Context<'tcx>,
        def_id: DefId,
    ) -> Option<bool> {
        match self.type_id_map.get(&def_id).copied() {
            None => {
                let path = def_id_to_vir_path_option(ctxt.tcx, Some(&*ctxt.verus_items), def_id);
                let has = path.and_then(|p| self.type_paths.get(&p).copied());
                self.type_id_map.insert(def_id, has);
                has
            }
            Some(b) => b,
        }
    }
}

fn trait_impl_to_vir<'tcx>(
    ctxt: &Context<'tcx>,
    span: rustc_span::Span,
    path_span: rustc_span::Span,
    impl_def_id: DefId,
    hir_generics: Option<&'tcx rustc_hir::Generics<'tcx>>,
    external_info: &mut ExternalInfo,
    module_path: Path,
    auto_imported: bool,
    external_trait_blanket: bool,
) -> Result<Option<(Path, Typs, TraitImpl)>, VirErr> {
    let trait_polarity = ctxt.tcx.impl_polarity(impl_def_id);
    if trait_polarity == rustc_middle::ty::ImplPolarity::Negative {
        // Negative impls currently show up in two expected cases:
        // - Send
        // - Sync
        // and in one surprising case:
        // - Iterator
        //   - see https://github.com/rust-lang/rust/commit/1a8109253196064e26a427d9184874ae14c55f6e
        // Currently, we ignore negative impls;
        // trait_conflicts.rs should protect us from any overlap caused by ignoring negative impls
        // TODO: better handling of negative impls
        return Ok(None);
    }

    let trait_ref = ctxt.tcx.impl_trait_ref(impl_def_id);
    let trait_did = trait_ref.skip_binder().def_id;
    let impl_paths = crate::rust_to_vir_base::get_impl_paths(
        ctxt.tcx,
        &ctxt.verus_items,
        impl_def_id,
        trait_did,
        trait_ref.skip_binder().args,
        None,
        span,
    )?;

    // If we have `impl X for Z<A, B, C>` then the list of types is [X, A, B, C].
    // We keep this full list, with the first element being the Self type X
    let mut types: Vec<Typ> = Vec::new();
    let args = trait_ref.skip_binder().args;
    for arg in args.iter() {
        match arg.kind() {
            GenericArgKind::Lifetime(_) => {}
            GenericArgKind::Type(ty) => {
                types.push(ctxt.mid_ty_to_vir(impl_def_id, span, &ty, None)?);
            }
            GenericArgKind::Const(cnst) => {
                types.push(mid_ty_const_to_vir(ctxt.tcx, Some(span), &cnst)?);
            }
        }
    }

    let types = Arc::new(types);
    let mut trait_path = ctxt.def_id_to_vir_path(trait_did);
    if let Some(spec) = external_info.external_trait_extension_impl_map.get(&trait_path) {
        trait_path = spec.clone();
    }
    let (typ_params, typ_bounds) = crate::rust_to_vir_base::check_generics_bounds_no_polarity(
        ctxt.tcx,
        &ctxt.verus_items,
        span,
        hir_generics,
        impl_def_id,
        Some(&mut *ctxt.diagnostics.borrow_mut()),
    )?;
    let impl_path = ctxt.def_id_to_vir_path(impl_def_id);
    let trait_impl = vir::ast::TraitImplX {
        impl_path: impl_path.clone(),
        typ_params,
        typ_bounds,
        trait_path: trait_path.clone(),
        trait_typ_args: types.clone(),
        trait_typ_arg_impls: ctxt.spanned_new(path_span, impl_paths),
        owning_module: Some(module_path),
        auto_imported,
        external_trait_blanket,
    };
    let trait_impl = ctxt.spanned_new(span, trait_impl);
    Ok(Some((trait_path, types, trait_impl)))
}

fn translate_assoc_type<'tcx>(
    ctxt: &Context<'tcx>,
    name: Ident,
    impll_generics_span: Span,
    impll_generics: Option<&'tcx rustc_hir::Generics<'tcx>>,
    impl_item_span: Span,
    impl_item_id: DefId,
    impl_def_id: DefId,
    trait_path: Path,
    trait_typ_args: Typs,
) -> Result<AssocTypeImpl, VirErr> {
    let impl_path = ctxt.def_id_to_vir_path(impl_def_id);
    let trait_ref = ctxt.tcx.impl_trait_ref(impl_def_id);
    let ty = ctxt.tcx.type_of(impl_item_id).skip_binder();
    let typ = ctxt.mid_ty_to_vir(impl_item_id, impl_item_span, &ty, None)?;
    let (typ_params, typ_bounds) = crate::rust_to_vir_base::check_generics_bounds_no_polarity(
        ctxt.tcx,
        &ctxt.verus_items,
        impll_generics_span,
        impll_generics,
        impl_def_id,
        Some(&mut *ctxt.diagnostics.borrow_mut()),
    )?;

    let ai = ctxt.tcx.associated_item(impl_item_id);
    let assoc_def_id = ai.trait_item_def_id().unwrap();
    let bounds = ctxt.tcx.item_bounds(assoc_def_id);
    let assoc_generics = ctxt.tcx.generics_of(assoc_def_id);
    let mut assoc_args: Vec<rustc_middle::ty::GenericArg> = ctxt
        .tcx
        .normalize_erasing_regions(
            TypingEnv::post_analysis(ctxt.tcx, impl_item_id),
            trait_ref.instantiate_identity(),
        )
        .args
        .into_iter()
        .collect();
    for p in &assoc_generics.own_params {
        let e = rustc_middle::ty::EarlyParamRegion {
            //def_id: p.def_id,
            index: assoc_generics.param_def_id_to_index(ctxt.tcx, p.def_id).expect("param_def"),
            name: p.name,
        };
        let r = rustc_middle::ty::Region::new_early_param(ctxt.tcx, e);
        assoc_args.push(rustc_middle::ty::GenericArg::from(r));
    }
    let inst_bounds = bounds.instantiate(ctxt.tcx, &*assoc_args);
    let typing_env = TypingEnv::post_analysis(ctxt.tcx, impl_item_id);
    let inst_bounds = ctxt.tcx.normalize_erasing_regions(typing_env, inst_bounds);

    // Include the instantiated bounds of selected impls, not just the impls themselves.
    let impl_paths = crate::rust_to_vir_base::get_impl_paths_for_clauses(
        ctxt.tcx,
        &ctxt.verus_items,
        impl_item_id,
        inst_bounds.into_iter().map(|clause| (None, clause)).collect(),
        None,
        impl_item_span,
    )?;

    let assocx = AssocTypeImplX {
        name,
        impl_path: impl_path.clone(),
        typ_params,
        typ_bounds,
        trait_path,
        trait_typ_args,
        typ,
        impl_paths,
    };
    Ok(ctxt.spanned_new(impl_item_span, assocx))
}

pub(crate) fn translate_impl<'tcx>(
    ctxt: &Context<'tcx>,
    state: &mut State,
    vir: &mut KrateX,
    infos: &mut Vec<FunctionOrConstInfo<'tcx>>,
    item: &'tcx Item<'tcx>,
    impll: &rustc_hir::Impl<'tcx>,
    module_path: Path,
    crate_items: &CrateItems,
    attrs: &[rustc_hir::Attribute],
) -> Result<(), Vec<VirErr>> {
    let impl_def_id = item.owner_id.to_def_id();
    let impl_path = ctxt.def_id_to_vir_path(impl_def_id);

    if let Some(TraitImplHeader { trait_ref: TraitRef { path, hir_ref_id: _ }, safety, .. }) =
        impll.of_trait
    {
        let trait_def_id = path.res.def_id();

        let rust_item = verus_items::get_rust_item(ctxt.tcx, trait_def_id);
        if matches!(rust_item, Some(RustItem::Fn | RustItem::FnOnce | RustItem::FnMut)) {
            return err_span_vec(
                item.span,
                "Verus does not support implementing this trait via an `impl` block",
            );
        }

        let verus_item = ctxt.verus_items.id_to_name.get(&trait_def_id);

        if *safety != Safety::Safe {
            if matches!(rust_item, Some(RustItem::Send)) {
                return err_span_vec(item.span, "unsafe impl for `Send` is not allowed");
            }
            if matches!(rust_item, Some(RustItem::Sync)) {
                return err_span_vec(item.span, "unsafe impl for `Sync` is not allowed");
            }
        }

        let ignore = if let Some(VerusItem::Marker(MarkerItem::Structural)) = verus_item {
            let ty = {
                // TODO extract to rust_to_vir_base, or use
                // https://doc.rust-lang.org/nightly/nightly-rustc/rustc_typeck/fn.hir_ty_to_ty.html
                // ?
                let def_id = match impll.self_ty.kind {
                    rustc_hir::TyKind::Path(QPath::Resolved(None, path)) => path.res.def_id(),
                    _ => {
                        return err_span_vec(
                            item.span,
                            "`Structural` can only be implemented for struct or enum types",
                        );
                    }
                };
                ctxt.tcx.type_of(def_id).skip_binder()
            };
            // TODO: this may be a bit of a hack: to query the TyCtxt for the StructuralEq impl it seems we need
            // a concrete type, so apply ! to all type parameters
            let ty_kind_applied_never = if let rustc_middle::ty::TyKind::Adt(def, substs) =
                ty.kind()
            {
                // SMT equality includes ghost and tracked fields, whereas executable
                // equality cannot observe their erased updates.
                for field in def.all_fields() {
                    if let Some(field_id) = field.did.as_local() {
                        let attrs = ctxt.tcx.hir_attrs(ctxt.tcx.local_def_id_to_hir_id(field_id));
                        if crate::attributes::get_mode(Mode::Exec, attrs) != Mode::Exec {
                            return err_span_vec(
                                ctxt.tcx.def_span(field.did),
                                "`Structural` types cannot have ghost or tracked fields",
                            );
                        }
                    }
                }
                rustc_middle::ty::TyKind::Adt(
                    def.to_owned(),
                    ctxt.tcx.mk_args_from_iter(substs.iter().map(|g| match g.kind() {
                        rustc_middle::ty::GenericArgKind::Type(_) => (*ctxt.tcx).types.never.into(),
                        _ => g,
                    })),
                )
            } else {
                return err_span_vec(
                    item.span,
                    "`Structural` can only be implemented for struct or enum types",
                );
            };
            let ty_applied_never = ctxt.tcx.mk_ty_from_kind(ty_kind_applied_never);
            if !ty_applied_never.is_structural_eq_shallow(ctxt.tcx) {
                return Err(vec![
                    vir_err_span_str(
                        item.span,
                        &format!("structural impl for non-structural type {:?}", ty),
                    )
                    .help("make sure `PartialEq` is also auto-derived for this type"),
                ]);
            }
            // StructuralPartialEq is a safe marker that can be implemented by hand.
            // Check the actual PartialEq impl's expansion, not an automatically_derived
            // attribute, which can also be written by hand.
            let partial_eq = ctxt.tcx.lang_items().eq_trait().expect("PartialEq trait");
            let trait_ref = rustc_middle::ty::TraitRef::new(
                ctxt.tcx,
                partial_eq,
                [ty_applied_never, ty_applied_never],
            );
            let typing_env = TypingEnv::post_analysis(ctxt.tcx, impl_def_id);
            let derived_partial_eq = match ctxt
                .tcx
                .codegen_select_candidate(PseudoCanonicalInput { typing_env, value: trait_ref })
            {
                Ok(rustc_middle::traits::ImplSource::UserDefined(u)) => {
                    let expansion = ctxt.tcx.def_span(u.impl_def_id).ctxt().outer_expn_data();
                    match (expansion.kind, expansion.macro_def_id) {
                        (ExpnKind::Macro(MacroKind::Derive, _), Some(macro_id)) => {
                            rustc_hir::find_attr!(ctxt.tcx, macro_id,
                                RustcBuiltinMacro { builtin_name, .. } =>
                                    builtin_name.unwrap_or_else(|| ctxt.tcx.item_name(macro_id))
                            ) == Some(sym::PartialEq)
                        }
                        _ => false,
                    }
                }
                _ => false,
            };
            if !derived_partial_eq {
                return err_span_vec(
                    item.span,
                    "`Structural` requires a built-in derived `PartialEq` implementation",
                );
            }
            true
        } else {
            false
        };

        if ignore {
            for impl_item_id in impll.items {
                let assoc_item = ctxt.tcx.associated_item(impl_item_id.hir_id().owner.to_def_id());
                match assoc_item.kind {
                    AssocKind::Fn { has_self, .. } if has_self => {
                        let impl_item = ctxt.tcx.hir_impl_item(*impl_item_id);
                        if let ImplItemKind::Fn(sig, _) = &impl_item.kind {
                            ctxt.erasure_info
                                .borrow_mut()
                                .ignored_functions
                                .push((impl_item.owner_id.to_def_id(), sig.span.data()));
                        } else {
                            panic!("Fn impl item expected");
                        }
                    }
                    _ => {}
                }
            }
            return Ok(());
        } else {
            /* sealed, `unsafe` */
            // Verus attributes are `Unparsed` where get_all_attrs is acceptable per its
            // deprecation message.
            #[allow(deprecated)]
            let trait_attrs = ctxt.tcx.get_all_attrs(trait_def_id);
            let sealed = crate::attributes::is_sealed(
                trait_attrs,
                Some(&mut *ctxt.diagnostics.borrow_mut()),
            )
            .map_err(|e| vec![e])?;

            if sealed {
                return err_span_vec(item.span, "cannot implement `sealed` trait");
            }
        }
    }

    let vattrs = ctxt.get_verifier_attrs(attrs).map_err(|e| vec![e])?;
    let trait_path_typ_args =
        if let Some(TraitImplHeader { trait_ref: TraitRef { path, .. }, .. }) = &impll.of_trait {
            let impl_def_id = item.owner_id.to_def_id();
            state.external_info.internal_trait_impls.insert(impl_def_id);
            let path_span = path.span.to(impll.self_ty.span);
            match trait_impl_to_vir(
                ctxt,
                item.span,
                path_span,
                impl_def_id,
                Some(impll.generics),
                &mut state.external_info,
                module_path.clone(),
                false,
                vattrs.external_trait_blanket,
            )
            .map_err(|e| vec![e])?
            {
                Some((trait_path, types, trait_impl)) => {
                    vir.trait_impls.push(trait_impl);
                    Some((trait_path, types))
                }
                _ => None,
            }
        } else {
            None
        };

    let autoderive_action = if let Some(of_trait) = impll.of_trait
        && is_automatically_derived(attrs)
    {
        let trait_def_id = of_trait.trait_ref.path.res.def_id();
        let rust_item = crate::verus_items::get_rust_item(ctxt.tcx, trait_def_id);
        let action = crate::automatic_derive::get_action(rust_item);
        Some(action)
    } else {
        None
    };

    let mut errors = vec![];
    for impl_item_id in impll.items {
        if vattrs.external_trait_blanket {
            return Ok(());
        }
        let r = translate_impl_item(
            ctxt,
            state,
            vir,
            infos,
            item,
            impll,
            &module_path,
            crate_items,
            impl_item_id,
            &trait_path_typ_args,
            impl_def_id,
            &impl_path,
            &autoderive_action,
        );
        if let Err(r) = r {
            errors.push(r);
        }
    }
    if errors.len() > 0 { Err(errors) } else { Ok(()) }
}

pub(crate) fn translate_impl_item<'tcx>(
    ctxt: &Context<'tcx>,
    state: &mut State,
    vir: &mut KrateX,
    infos: &mut Vec<FunctionOrConstInfo<'tcx>>,
    item: &'tcx Item<'tcx>,
    impll: &rustc_hir::Impl<'tcx>,
    module_path: &Path,
    crate_items: &CrateItems,
    impl_item_id: &rustc_hir::ImplItemId,
    trait_path_typ_args: &Option<(Path, Typs)>,
    impl_def_id: DefId,
    impl_path: &Path,
    autoderive_action: &Option<crate::automatic_derive::AutomaticDeriveAction>,
) -> Result<(), VirErr> {
    let impl_item = ctxt.tcx.hir_impl_item(*impl_item_id);
    let fn_attrs = ctxt.tcx.hir_attrs(impl_item.hir_id());

    if crate_items.is_impl_item_external(*impl_item_id) {
        if trait_path_typ_args.is_some() {
            // sanity check - this should be redundant with prior check in external.rs
            return err_span(
                item.span,
                "an item in a trait impl cannot be marked external - you can either use external_body, or mark the entire trait impl as external",
            );
        }
        return Ok(());
    }
    let assoc_item = ctxt.tcx.associated_item(impl_item_id.hir_id().owner.to_def_id());
    let mk_trait_function_kind = || -> FunctionKind {
        if let Some((trait_path, trait_typ_args)) = trait_path_typ_args.clone() {
            let ident = impl_item.ident.to_string();
            let ident = Arc::new(ident);
            let path = typ_path_and_ident_to_vir_path(&trait_path, ident);
            let fun = FunX { path };
            let method = Arc::new(fun);
            FunctionKind::TraitMethodImpl {
                method,
                impl_path: impl_path.clone(),
                trait_path,
                trait_typ_args,
                inherit_body_from: None,
            }
        } else {
            FunctionKind::Static
        }
    };
    match assoc_item.kind {
        AssocKind::Fn { name: _name, has_self: true | false } => {
            let impl_item_visibility = mk_visibility(&ctxt, impl_item.owner_id.to_def_id());
            match &impl_item.kind {
                ImplItemKind::Fn(sig, body_id) => {
                    let kind = mk_trait_function_kind();

                    check_item_fn(
                        ctxt,
                        state,
                        &mut *infos,
                        Some(&mut vir.reveal_groups),
                        impl_item.owner_id.to_def_id(),
                        kind,
                        impl_item_visibility,
                        &module_path,
                        fn_attrs,
                        crate::rust_to_vir_func::FnOrConstSig::sig(&sig),
                        Some((&impll.generics, impl_def_id)),
                        &impl_item.generics,
                        CheckItemFnEither::BodyId(&body_id),
                        None,
                        None,
                        *autoderive_action,
                        &mut vir.opaque_types,
                    )?;
                }
                _ => unsupported_err!(item.span, "unsupported item in impl", impl_item_id),
            }
        }
        AssocKind::Type { .. } => {
            if impl_item.generics.predicates.len() != 0
                || impl_item.generics.has_where_clause_predicates
            {
                unsupported_err!(
                    item.span,
                    "unsupported generics on associated type",
                    impl_item_id
                );
            }
            if let ImplItemKind::Type(_ty) = impl_item.kind {
                if let Some((trait_path, trait_typ_args)) = trait_path_typ_args.clone() {
                    let name = Arc::new(impl_item.ident.to_string());
                    let assoc_type_impl = translate_assoc_type(
                        ctxt,
                        name,
                        impll.generics.span,
                        Some(&impll.generics),
                        impl_item.span,
                        impl_item.owner_id.to_def_id(),
                        impl_def_id,
                        trait_path,
                        trait_typ_args,
                    )?;
                    vir.assoc_type_impls.push(assoc_type_impl);
                } else {
                    unsupported_err!(item.span, "unsupported item ref in impl", impl_item_id);
                }
            } else {
                unsupported_err!(item.span, "unsupported item ref in impl", impl_item_id);
            }
        }
        AssocKind::Const { name: _name, is_type_const: _ } => {
            if let ImplItemKind::Const(_ty, ConstItemRhs::Body(body_id)) = &impl_item.kind {
                let def_id = body_id.hir_id.owner.to_def_id();
                let mid_ty = ctxt.tcx.type_of(def_id).skip_binder();
                let vir_ty = ctxt.mid_ty_to_vir(def_id, impl_item.span, &mid_ty, None)?;
                if trait_path_typ_args.is_none() {
                    crate::rust_to_vir_func::check_item_const_or_static(
                        ctxt,
                        state,
                        &mut *infos,
                        impl_item.span,
                        impl_item.owner_id.to_def_id(),
                        mk_visibility(ctxt, impl_item.owner_id.to_def_id()),
                        &module_path,
                        ctxt.tcx.hir_attrs(impl_item.hir_id()),
                        &vir_ty,
                        &body_id,
                        false,
                        Some((&impll.generics, impl_def_id)),
                    )?;
                } else {
                    let kind = mk_trait_function_kind();
                    crate::rust_to_vir_func::check_item_fn(
                        ctxt,
                        state,
                        &mut *infos,
                        Some(&mut vir.reveal_groups),
                        impl_item.owner_id.to_def_id(),
                        kind,
                        mk_visibility(ctxt, impl_item.owner_id.to_def_id()),
                        &module_path,
                        ctxt.tcx.hir_attrs(impl_item.hir_id()),
                        crate::rust_to_vir_func::FnOrConstSig::const_var(impl_item.span, vir_ty),
                        Some((&impll.generics, impl_def_id)),
                        &impl_item.generics,
                        crate::rust_to_vir_func::CheckItemFnEither::BodyId(&body_id),
                        None,
                        None,
                        None,
                        &mut vir.opaque_types,
                    )?;
                }
            } else {
                unsupported_err!(item.span, "unsupported item ref in impl", impl_item_id);
            }
        }
    }
    Ok(())
}

pub(crate) fn collect_external_trait_impls<'tcx>(
    ctxt: &Context<'tcx>,
    imported: &Vec<Krate>,
    krate: &mut KrateX,
    external_info: &mut ExternalInfo,
    function_stubs: &Vec<vir::ast::FunctionStub>,
) -> Result<(), VirErr> {
    let tcx = ctxt.tcx;
    let mut considered_impls: HashSet<DefId> = HashSet::new();
    let mut collected_impls: HashSet<DefId> = HashSet::new();

    // All known datatypes:
    for (is_new, k) in
        imported.iter().map(|k| (false, &**k)).chain(vec![(true, &*krate)].into_iter())
    {
        for d in k.datatypes.iter() {
            if let Dt::Path(path) = &d.x.name {
                external_info.type_paths.insert(path.clone(), is_new);
            }
        }
    }

    // Traits declared to Verus (as internal or external) in earlier crates
    let mut old_traits: HashSet<Path> = HashSet::new();
    // Traits declared to Verus (as internal or external) only in current crate
    // (may be current crate's external declaration of trait from another crate)
    let mut new_traits: HashSet<Path> = HashSet::new();

    // First, collect all traits known to Verus:
    for t in imported.iter().flat_map(|k| k.traits.iter()) {
        old_traits.insert(t.x.name.clone());
    }
    for t in krate.traits.iter() {
        if !old_traits.contains(&t.x.name) {
            new_traits.insert(t.x.name.clone());
        }
    }
    let mut all_traits = old_traits;
    all_traits.extend(new_traits.iter().cloned());
    let mut all_trait_ids: Vec<DefId> = Vec::new();
    for c in tcx.crates(()) {
        assert!(*c != rustc_span::def_id::LOCAL_CRATE);
        for trait_id in tcx.traits(*c) {
            let path = def_id_to_vir_path_option(tcx, Some(&ctxt.verus_items), *trait_id);
            if let Some(path) = path {
                if all_traits.contains(&path) {
                    all_trait_ids.push(*trait_id);
                }
            }
        }
    }
    // LOCAL_CRATE traits are separate:
    all_trait_ids.extend(external_info.local_trait_ids.iter().cloned());
    external_info.trait_id_set.extend(all_trait_ids.iter().cloned());

    let mut trait_map: HashMap<Path, Vec<Trait>> =
        krate.traits.iter().map(|t| (t.x.name.clone(), vec![t.clone()])).collect();
    for k in imported {
        for t in k.traits.iter() {
            trait_map.entry(t.x.name.clone()).or_default().push(t.clone());
        }
    }

    // Next, collect all possible new implementations of traits known to Verus:
    let mut auto_import_impls: Vec<DefId> = Vec::new();
    for trait_id in all_trait_ids {
        let path = ctxt.def_id_to_vir_path(trait_id);
        for impl_def_id in tcx.all_impls(trait_id) {
            if considered_impls.contains(&impl_def_id) {
                continue;
            }
            considered_impls.insert(impl_def_id);
            if external_info.internal_trait_impls.contains(&impl_def_id) {
                // already processed our own trait impls
                continue;
            }
            let is_new_trait = new_traits.contains(&path);
            let is_local_impl = impl_def_id.krate == rustc_span::def_id::LOCAL_CRATE;
            let mut has_new_types = false;
            for arg in tcx.impl_trait_ref(impl_def_id).skip_binder().args.iter() {
                for arg in arg.walk() {
                    if let Some(ty) = arg.as_type() {
                        use rustc_middle::ty::TyKind;
                        if let TyKind::Adt(rustc_middle::ty::AdtDef(adt_def_data), _) = ty.kind() {
                            if external_info.has_type_id(ctxt, adt_def_data.did) == Some(true) {
                                has_new_types = true;
                            }
                        }
                    }
                }
            }
            if is_new_trait || is_local_impl || has_new_types {
                // Either the trait is new to us, or the impl is new to us
                auto_import_impls.push(impl_def_id);
            }
        }
    }

    // Process only the new implementations that could be visible to Verus:
    'impls: for impl_def_id in auto_import_impls {
        let trait_ref = tcx.impl_trait_ref(impl_def_id);
        for arg in trait_ref.skip_binder().args.iter() {
            if !crate::rust_to_vir_base::mid_arg_filter_for_external_impls(
                ctxt,
                arg.walk(),
                external_info,
            ) {
                continue 'impls;
            }
        }
        if !crate::rust_to_vir_base::mid_generics_filter_for_external_impls(
            ctxt,
            impl_def_id,
            external_info,
        ) {
            continue;
        }
        let span = tcx.def_span(impl_def_id);
        let impl_path = ctxt.def_id_to_vir_path(impl_def_id);
        let module_path = impl_path.pop_segment();
        let t_impl_opt = trait_impl_to_vir(
            ctxt,
            span,
            span,
            impl_def_id,
            None,
            external_info,
            module_path,
            true,
            false,
        );
        if let Ok(Some((trait_path, trait_typ_args, trait_impl))) = t_impl_opt {
            let mut assoc_type_impls: Vec<AssocTypeImpl> = Vec::new();
            for assoc_item in tcx.associated_items(impl_def_id).in_definition_order() {
                match assoc_item.kind {
                    rustc_middle::ty::AssocKind::Type { .. } => {
                        let name = Arc::new(assoc_item.ident(tcx).to_string());
                        if !trait_map[&trait_path].iter().any(|t| t.x.assoc_typs.contains(&name)) {
                            continue;
                        }
                        if !crate::rust_to_vir_base::mid_ty_filter_for_external_impls(
                            ctxt,
                            &tcx.type_of(assoc_item.def_id).skip_binder(),
                            external_info,
                        ) {
                            continue 'impls;
                        }
                        match translate_assoc_type(
                            ctxt,
                            name,
                            span,
                            None,
                            span,
                            assoc_item.def_id,
                            impl_def_id,
                            trait_path.clone(),
                            trait_typ_args.clone(),
                        ) {
                            Ok(assoc_type_impl) => {
                                assoc_type_impls.push(assoc_type_impl);
                            }
                            _ => {
                                continue 'impls;
                            }
                        }
                    }
                    _ => {}
                }
            }
            krate.trait_impls.push(trait_impl);
            krate.assoc_type_impls.append(&mut assoc_type_impls);
            collected_impls.insert(impl_def_id);
        } else if let Ok(None) = t_impl_opt {
            // Negative impl; do nothing for now
        } else {
            // Ideally, our filtering should prevent us from reaching here.
            // Probably, we didn't want to include the external impl anyway,
            // so drop it rather than failing.
            // TODO: add a mode for rust_verify_test that fails if this is reached.
        }
    }

    let mut func_map = HashMap::<Fun, vir::ast::FunctionStub>::new();
    for function in function_stubs.iter() {
        func_map.insert(function.x.name.clone(), function.clone());
    }
    let mut trait_map = HashMap::<Path, Trait>::new();
    for traitt in krate.traits.iter() {
        trait_map.insert(traitt.x.name.clone(), traitt.clone());
    }

    let mut new_trait_impls = IndexMap::<Path, (DefId, Vec<(DefId, rustc_span::Span)>)>::new();

    for (def_id, span) in external_info.external_fn_specification_trait_method_impls.iter() {
        let trait_method_impl = ctxt.def_id_to_vir_path(*def_id);
        let trait_impl = trait_method_impl.pop_segment();
        match new_trait_impls.get_mut(&trait_impl) {
            Some(m) => {
                m.1.push((*def_id, *span));
            }
            None => {
                let impl_def_id = tcx.impl_of_assoc(*def_id).unwrap();
                new_trait_impls.insert(trait_impl, (impl_def_id, vec![(*def_id, *span)]));
            }
        }
    }

    for (impl_path, (impl_def_id, funs)) in new_trait_impls.iter() {
        let trait_ref = tcx.impl_trait_ref(*impl_def_id);
        let trait_did = trait_ref.skip_binder().def_id;
        let trait_path = ctxt.def_id_to_vir_path(trait_did);
        let Some(traitt) = trait_map.get(&trait_path) else {
            continue;
        };

        let span = funs[0].1;

        let mut methods_we_have = IndexSet::<vir::ast::Ident>::new();
        for (fun_def_id, fun_span) in funs.iter() {
            let path = ctxt.def_id_to_vir_path(*fun_def_id);
            if !methods_we_have.insert(path.last_segment()) {
                return err_span(*fun_span, "duplicate assume_specification for this method");
            }
        }

        // Methods for which the trait itself supplies a body don't need their own
        // assume_specification: calls to them are redirected to the trait declaration's spec.
        let trait_provided_methods: IndexSet<String> = tcx
            .associated_items(trait_did)
            .in_definition_order()
            .filter(|assoc_item| {
                matches!(assoc_item.kind, AssocKind::Fn { .. })
                    && assoc_item.defaultness(tcx).has_value()
            })
            .map(|assoc_item| assoc_item.ident(tcx).to_string())
            .collect();

        for method in traitt.x.methods.iter() {
            let f = &func_map[method];
            if matches!(&f.x.kind, FunctionKind::TraitMethodDecl { has_default: true, .. }) {
                continue;
            }
            if trait_provided_methods.contains(&*method.path.last_segment()) {
                continue;
            }
            if !methods_we_have.contains::<vir::ast::Ident>(&method.path.last_segment()) {
                return err_span(
                    span,
                    format!(
                        "using assume_specification for this function requires you to specify all other functions for the same trait impl, but the method `{:}` is missing",
                        method.path.last_segment()
                    ),
                );
            }
        }

        if collected_impls.contains(impl_def_id) {
            continue;
        }

        let module_path = impl_path.pop_segment();

        if let Some((_trait_path, _types, trait_impl)) = trait_impl_to_vir(
            ctxt,
            span,
            span,
            *impl_def_id,
            None,
            external_info,
            module_path,
            false,
            false,
        )? {
            krate.trait_impls.push(trait_impl);
        }
    }

    Ok(())
}
