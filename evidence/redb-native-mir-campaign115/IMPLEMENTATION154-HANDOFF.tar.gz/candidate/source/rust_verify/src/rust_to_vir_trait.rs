use crate::attributes::VerifierAttrs;
use crate::context::Context;
use crate::external::CrateItems;
use crate::rust_to_vir::State;
use crate::rust_to_vir_base::{check_generics_bounds_with_polarity, process_predicate_bounds};
use crate::rust_to_vir_func::{
    CheckItemFnEither, FunctionInfo, FunctionOrConstInfo, check_item_fn,
};
use crate::rust_to_vir_impl::ExternalInfo;
use crate::unsupported_err_unless;
use crate::util::{err_span, err_span_bare};
use rustc_hir::{Generics, Safety, TraitFn, TraitItem, TraitItemId, TraitItemKind};
use rustc_middle::ty::{
    AliasTyKind, ClauseKind, TraitPredicate, TraitRef, Ty, TyCtxt, TyKind, TypeFoldable,
    TypeFolder, TypeSuperFoldable, TypingEnv,
};
use rustc_span::Span;
use rustc_span::def_id::DefId;
use std::collections::HashMap;
use std::sync::Arc;
use vir::ast::{Fun, FunctionKind, GenericBound, Ident, KrateX, TraitX, VirErr, Visibility};
use vir::ast_util::params_equal_opt;
use vir::def::VERUS_SPEC;
use vir::messages::error;

// The proxy and the target declare distinct associated types in Rust. Rewrite
// only projections from this proxy to the matching target member so that their
// trait bounds can be compared using the same associated-type identities.
// The marker stands in for Self in both predicate lists and must not be mapped,
// even when the target declares an associated type with the same name.
struct ExternalTraitProjectionRewriter<'tcx> {
    tcx: TyCtxt<'tcx>,
    proxy_trait_id: DefId,
    target_trait_id: DefId,
    marker_type_id: DefId,
}

impl<'tcx> TypeFolder<TyCtxt<'tcx>> for ExternalTraitProjectionRewriter<'tcx> {
    fn cx(&self) -> TyCtxt<'tcx> {
        self.tcx
    }

    fn fold_ty(&mut self, ty: Ty<'tcx>) -> Ty<'tcx> {
        let ty = ty.super_fold_with(self);
        if let TyKind::Alias(rigid, alias_ty) = *ty.kind()
            && let AliasTyKind::Projection { def_id } = alias_ty.kind
            && self.tcx.parent(def_id) == self.proxy_trait_id
            && def_id != self.marker_type_id
        {
            let proxy_item = self.tcx.associated_item(def_id);
            let target_item =
                self.tcx.associated_items(self.target_trait_id).find_by_ident_and_kind(
                    self.tcx,
                    proxy_item.ident(self.tcx),
                    proxy_item.tag(),
                    self.target_trait_id,
                );
            if let Some(target_item) = target_item {
                let alias_ty = rustc_middle::ty::AliasTy::new(
                    self.tcx,
                    AliasTyKind::Projection { def_id: target_item.def_id },
                    alias_ty.args,
                );
                return self.tcx.mk_ty_from_kind(TyKind::Alias(rigid, alias_ty));
            }
        }
        ty
    }
}

pub(crate) fn make_external_trait_extension_impl_map<'tcx>(
    ctxt: &Context<'tcx>,
    external_info: &mut ExternalInfo,
    imported: &Vec<vir::ast::Krate>,
    crate_items: &CrateItems,
) -> Result<(), VirErr> {
    use crate::external::{GeneralItemId, VerifOrExternal};
    use rustc_hir::ItemKind;

    for krate in imported.iter() {
        for t in &krate.traits {
            if let Some((spec, imp)) = &t.x.external_trait_extension {
                let m = &mut external_info.external_trait_extension_impl_map;
                assert!(!m.contains_key(imp));
                m.insert(imp.clone(), spec.clone());
            }
        }
    }

    for crate_item in crate_items.items.iter() {
        match &crate_item.verif {
            VerifOrExternal::VerusAware { .. } => match crate_item.id {
                GeneralItemId::ItemId(item_id) => {
                    let item = ctxt.tcx.hir_item(item_id);
                    let trait_def_id = item.owner_id.to_def_id();
                    match &item.kind {
                        ItemKind::Trait { .. } => {
                            let attrs = ctxt.tcx.hir_attrs(item.hir_id());
                            let vattrs = ctxt.get_verifier_attrs(attrs)?;
                            if let Some((spec, imp)) = vattrs.external_trait_extension {
                                let path = ctxt.def_id_to_vir_path(trait_def_id);
                                let spec = path.replace_last(Arc::new(spec.clone()));
                                let imp = path.replace_last(Arc::new(imp.clone()));
                                let m = &mut external_info.external_trait_extension_impl_map;
                                assert!(!m.contains_key(&imp));
                                m.insert(imp, spec);
                            }
                        }
                        _ => {}
                    }
                }
                _ => {}
            },
            _ => {}
        }
    }
    Ok(())
}

pub(crate) fn external_trait_specification_of<'tcx>(
    tcx: TyCtxt<'tcx>,
    trait_items: &'tcx [TraitItemId],
    trait_vattrs: &VerifierAttrs,
) -> Result<Option<TraitRef<'tcx>>, VirErr> {
    let mut ex_trait_ref_for: Option<TraitRef> = None;
    for trait_item_id in trait_items {
        let trait_item = tcx.hir_trait_item(*trait_item_id);
        let TraitItem { ident, kind, span, .. } = trait_item;
        match kind {
            TraitItemKind::Type(_generic_bounds, None) => {
                if Some(ident.to_string()) == trait_vattrs.external_trait_specification {
                    let bounds = tcx
                        .explicit_item_bounds(trait_item.owner_id.def_id.to_def_id())
                        .skip_binder();
                    for (bound, _) in bounds {
                        match bound.kind().skip_binder() {
                            ClauseKind::Trait(TraitPredicate {
                                trait_ref,
                                polarity: rustc_middle::ty::PredicatePolarity::Positive,
                            }) => {
                                let trait_def_id = trait_ref.def_id;
                                if Some(trait_def_id) == tcx.lang_items().sized_trait() {
                                    continue;
                                }
                                if ex_trait_ref_for.is_some() {
                                    return err_span(
                                        *span,
                                        format!("only one bound allowed in {ident}"),
                                    );
                                }
                                ex_trait_ref_for = Some(trait_ref);
                            }
                            _ => {
                                return err_span(*span, format!("unexpected bound in {ident}"));
                            }
                        }
                    }
                    if ex_trait_ref_for.is_none() {
                        return err_span(*span, format!("{ident} must have a bound"));
                    }
                }
            }
            _ => {}
        }
    }
    Ok(ex_trait_ref_for)
}

pub(crate) fn translate_trait<'tcx>(
    ctxt: &Context<'tcx>,
    state: &mut State,
    vir: &mut KrateX,
    infos: &mut Vec<FunctionOrConstInfo<'tcx>>,
    trait_span: Span,
    trait_def_id: DefId,
    visibility: Visibility,
    module_path: &vir::ast::Path,
    trait_generics: &'tcx Generics,
    trait_items: &'tcx [TraitItemId],
    trait_vattrs: &VerifierAttrs,
    crate_items: &CrateItems,
    safety: Safety,
) -> Result<(), VirErr> {
    let tcx = ctxt.tcx;
    let orig_trait_path = ctxt.def_id_to_vir_path(trait_def_id);
    let mut trait_path = orig_trait_path.clone();
    let (generics_params, mut typ_bounds) = {
        let (generics_params, mut typ_bounds) = check_generics_bounds_with_polarity(
            tcx,
            &ctxt.verus_items,
            trait_generics.span,
            Some(trait_generics),
            false,
            trait_def_id,
            None,
            Some(&mut *ctxt.diagnostics.borrow_mut()),
        )?;
        vir::traits::remove_self_is_itself_bound(&mut typ_bounds, &trait_path, &generics_params);
        (generics_params, typ_bounds)
    };
    let mut assoc_typs: Vec<Ident> = Vec::new();
    let mut assoc_typs_bounds: Vec<GenericBound> = Vec::new();
    let mut methods: Vec<FunctionOrConstInfo> = Vec::new();
    let mut method_names: Vec<Fun> = Vec::new();
    let ex_trait_ref_for = external_trait_specification_of(tcx, trait_items, trait_vattrs)?;
    let external_trait_extension = &trait_vattrs.external_trait_extension;
    let typing_env = TypingEnv::fully_monomorphized();
    let trait_extension = if let Some((spec, _)) = external_trait_extension {
        if ex_trait_ref_for.is_none() {
            return err_span(trait_span, "unexpected `external_trait_extension`");
        }
        Some(spec.clone())
    } else {
        None
    };
    if let Some(ex_trait_ref_for) = ex_trait_ref_for {
        crate::rust_to_vir_base::check_item_external_generics(
            ctxt.tcx,
            None,
            trait_generics,
            false,
            ex_trait_ref_for.args,
            true,
            trait_generics.span,
        )?;
        let external_predicates = tcx.clauses_of(ex_trait_ref_for.def_id);
        let proxy_predicates = tcx.clauses_of(trait_def_id);
        let mut preds1 = external_predicates
            .instantiate(tcx, ex_trait_ref_for.args)
            .clauses
            .into_iter()
            .map(|clause| {
                tcx.try_normalize_erasing_regions(typing_env, clause)
                    .unwrap_or_else(|_| clause.skip_norm_wip())
            })
            .collect();
        let marker_type_id = if let TyKind::Alias(_, marker_ty) = *ex_trait_ref_for.self_ty().kind()
            && let AliasTyKind::Projection { def_id } = marker_ty.kind
        {
            def_id
        } else {
            unreachable!("external trait specification Self must be the marker projection")
        };
        let mut projection_rewriter = ExternalTraitProjectionRewriter {
            tcx,
            proxy_trait_id: trait_def_id,
            target_trait_id: ex_trait_ref_for.def_id,
            marker_type_id,
        };
        let mut preds2 = proxy_predicates
            .instantiate(tcx, ex_trait_ref_for.args)
            .clauses
            .into_iter()
            .map(|clause| {
                let clause = clause.fold_with(&mut projection_rewriter);
                tcx.try_normalize_erasing_regions(typing_env, clause)
                    .unwrap_or_else(|_| clause.skip_norm_wip())
            })
            .collect();
        let mut external_trait_private_bounds = trait_vattrs.external_trait_private_bounds.clone();
        use crate::rust_to_vir_func::remove_ignored_trait_bounds_from_predicates;
        remove_ignored_trait_bounds_from_predicates(
            ctxt,
            true,
            Some(&mut external_trait_private_bounds),
            &[ex_trait_ref_for.def_id],
            Some(ex_trait_ref_for.args[0]),
            &mut preds1,
        );
        remove_ignored_trait_bounds_from_predicates(
            ctxt,
            true,
            None,
            &[ex_trait_ref_for.def_id, trait_def_id],
            Some(ex_trait_ref_for.args[0]),
            &mut preds2,
        );
        if let Some(bound) = external_trait_private_bounds.get(0) {
            return err_span(
                trait_span,
                format!(
                    "external_trait_private_bound {:?} is not a private non-local bound for this trait",
                    bound,
                ),
            );
        }
        if !crate::rust_to_vir_func::predicates_match(ctxt.tcx, &preds1, &preds2) {
            let err =
                err_span_bare(trait_span, "external_trait_specification trait bound mismatch")
                    .help(format!(
                        "external_trait_specification requires trait bounds to match exactly \
                    but the proxy's trait bounds are:\n{}\nthe external trait bounds are:\n{}",
                        preds2.iter().map(|x| format!("  - {x}")).collect::<Vec<_>>().join("\n"),
                        preds1.iter().map(|x| format!("  - {x}")).collect::<Vec<_>>().join("\n")
                    ));
            return Err(err);
        }
    }
    let ex_trait_id_for = ex_trait_ref_for.map(|r| r.def_id);
    if let Some(ex_trait_id_for) = ex_trait_id_for {
        trait_path = ctxt.def_id_to_vir_path(ex_trait_id_for);
    }
    if let Some(x) = &trait_vattrs.external_trait_specification {
        if ex_trait_id_for.is_none() {
            return err_span(
                trait_span,
                format!("`external_trait_specification` trait must declare a type {x}"),
            );
        }
    }

    for trait_item_id in trait_items {
        let trait_item = tcx.hir_trait_item(*trait_item_id);
        let TraitItem { ident, owner_id, generics: item_generics, kind, span, defaultness: _ } =
            trait_item;
        let (item_generics_params, item_typ_bounds) = check_generics_bounds_with_polarity(
            tcx,
            &ctxt.verus_items,
            item_generics.span,
            Some(item_generics),
            false,
            owner_id.to_def_id(),
            None,
            Some(&mut *ctxt.diagnostics.borrow_mut()),
        )?;

        if crate_items.is_trait_item_external(*trait_item_id) {
            return err_span(
                *span,
                "a trait item cannot be marked 'external' - perhaps you meant to mark the entire trait external?",
            );
        }

        let item_path = ctxt.def_id_to_vir_path(owner_id.to_def_id());
        let is_verus_spec =
            item_path.segments.last().expect("segment.last").starts_with(VERUS_SPEC);
        let attrs = tcx.hir_attrs(trait_item.hir_id());
        let ex_item_id_for = if let Some(ex_trait_id_for) = ex_trait_id_for {
            match kind {
                TraitItemKind::Type(_generic_bounds, None) => {
                    if Some(ident.to_string()) == trait_vattrs.external_trait_specification {
                        continue;
                    }
                }
                _ => {}
            }
            use vir::ast::Mode;
            let mode = crate::attributes::get_mode(Mode::Exec, attrs);
            let assoc_item = tcx.associated_item(owner_id.to_def_id());
            let ex_assoc_items = tcx.associated_items(ex_trait_id_for);
            let ex_assoc_item = ex_assoc_items.find_by_ident_and_kind(
                tcx,
                *ident,
                assoc_item.tag(),
                ex_trait_id_for,
            );
            if mode == Mode::Spec {
                if external_trait_extension.is_some() {
                    if let TraitItemKind::Fn(_, TraitFn::Provided(_)) = kind {
                        if !is_verus_spec {
                            return err_span(
                                *span,
                                "feature not yet supported: external spec extensions cannot yet provide default bodies",
                            );
                        }
                        // TODO: support defaults
                        // (they would currently just get dropped here if we didn't return an error)
                    }
                    // spec functions live in extension trait, not in our trait
                    continue;
                } else if !is_verus_spec && ex_assoc_item.is_none() {
                    return err_span(
                        *span,
                        "external spec extensions only allowed in `external_trait_extension` traits",
                    );
                }
            }
            if is_verus_spec {
                None
            } else if let Some(ex_assoc_item) = ex_assoc_item {
                Some(ex_assoc_item.def_id)
            } else {
                let name = tcx.def_path_str(ex_trait_id_for);
                return err_span(
                    *span,
                    format!("cannot find member named {ident} in trait {name}"),
                );
            }
        } else {
            None
        };

        let trait_extension_in_spec = if is_verus_spec { trait_extension.clone() } else { None };
        match kind {
            TraitItemKind::Fn(sig, fun) => {
                // putting param_names here ensures that Vec in TraitFn::Required case below lives long enough
                let param_names;
                let (body_id, has_default) = match fun {
                    TraitFn::Provided(_) if ex_trait_id_for.is_some() && !is_verus_spec => {
                        return err_span(
                            *span,
                            format!("`external_trait_specification` functions cannot have bodies"),
                        );
                    }
                    TraitFn::Provided(body_id) => (CheckItemFnEither::BodyId(body_id), true),
                    TraitFn::Required(opt_param_names) => {
                        // REVIEW: Is filtering out `None`s the right thing to do here?
                        param_names =
                            opt_param_names.into_iter().flatten().cloned().collect::<Vec<_>>();
                        (CheckItemFnEither::ParamNames(param_names.as_slice()), false)
                    }
                };
                // requires and ensures on exec functions can refer to spec extension trait:
                let fun = check_item_fn(
                    ctxt,
                    state,
                    &mut methods,
                    None,
                    owner_id.to_def_id(),
                    FunctionKind::TraitMethodDecl { trait_path: trait_path.clone(), has_default },
                    visibility.clone(),
                    module_path,
                    attrs,
                    crate::rust_to_vir_func::FnOrConstSig::sig(sig),
                    Some((trait_generics, trait_def_id)),
                    item_generics,
                    body_id,
                    ex_trait_id_for.map(|d| (d, trait_extension_in_spec)),
                    ex_item_id_for,
                    None,
                    &mut vir.opaque_types,
                )?;
                if let Some(fun) = fun {
                    method_names.push(fun);
                }
            }
            TraitItemKind::Const(_ty, body_opt) => {
                let param_names = vec![];
                let (body_id, has_default) = match body_opt {
                    Some(_) if ex_trait_id_for.is_some() && !is_verus_spec => {
                        return err_span(
                            *span,
                            format!("`external_trait_specification` functions cannot have bodies"),
                        );
                    }
                    Some(rustc_hir::ConstItemRhs::Body(body_id)) => {
                        (CheckItemFnEither::BodyId(body_id), true)
                    }
                    Some(_) => {
                        crate::unsupported_err!(trait_span, "non-expression trait const default")
                    }
                    None => (CheckItemFnEither::ParamNames(param_names.as_slice()), false),
                };
                let mid_ty = ctxt.tcx.type_of(owner_id.to_def_id()).skip_binder();
                let typ = ctxt.mid_ty_to_vir(owner_id.to_def_id(), *span, &mid_ty, None)?;
                let fun = crate::rust_to_vir_func::check_item_fn(
                    ctxt,
                    state,
                    &mut methods,
                    None,
                    owner_id.to_def_id(),
                    FunctionKind::TraitMethodDecl { trait_path: trait_path.clone(), has_default },
                    visibility.clone(),
                    module_path,
                    attrs,
                    crate::rust_to_vir_func::FnOrConstSig::const_var(*span, typ),
                    Some((trait_generics, trait_def_id)),
                    item_generics,
                    body_id,
                    ex_trait_id_for.map(|d| (d, trait_extension_in_spec)),
                    ex_item_id_for,
                    None,
                    &mut vir.opaque_types,
                )?;
                if let Some(fun) = fun {
                    method_names.push(fun);
                }
            }
            TraitItemKind::Type(_, Some(_)) => {
                return err_span(
                    trait_span,
                    "Verus does not yet support associated types with a concrete type",
                );
            }
            TraitItemKind::Type(_generic_bounds, None) => {
                unsupported_err_unless!(item_generics_params.len() == 0, *span, "trait generics");
                unsupported_err_unless!(item_typ_bounds.len() == 0, *span, "trait generics");
                assoc_typs.push(Arc::new(ident.to_string()));

                let bounds = tcx.item_bounds(trait_item.owner_id.def_id.to_def_id()).skip_binder();
                let bounds = bounds.iter().map(|p| (p, *span)).collect::<Vec<_>>();
                let vir_bounds = process_predicate_bounds(
                    tcx,
                    trait_def_id,
                    &ctxt.verus_items,
                    bounds.iter(),
                    tcx.generics_of(trait_def_id),
                )?;
                assoc_typs_bounds.extend(vir_bounds);

                if let Some(ex_trait_ref_for) = ex_trait_ref_for {
                    let ex_item_id_for = ex_item_id_for.expect("ex_item_id_for");
                    let external_predicates = tcx.item_bounds(ex_item_id_for);
                    let proxy_predicates = tcx.item_bounds(owner_id.to_def_id());
                    let external_instantiated =
                        external_predicates.instantiate(tcx, ex_trait_ref_for.args);
                    let preds1 = tcx
                        .try_normalize_erasing_regions(typing_env, external_instantiated)
                        .unwrap_or_else(|_| external_instantiated.skip_norm_wip());
                    let proxy_instantiated =
                        proxy_predicates.instantiate(tcx, ex_trait_ref_for.args);
                    let preds2 = tcx
                        .try_normalize_erasing_regions(typing_env, proxy_instantiated)
                        .unwrap_or_else(|_| proxy_instantiated.skip_norm_wip());
                    // TODO, but low priority, since this is just a check for trusted declarations:
                    // crate::rust_to_vir_func::predicates_match(tcx, true, &preds1.iter().collect(), &preds2.iter().collect())?;
                    // (would need to fix up the TyKind::Alias projections inside the clauses)

                    let mut preds1 = preds1.to_vec();
                    let mut preds2 = preds2.to_vec();
                    preds1.sort_by_key(|x| x.to_string());
                    preds2.sort_by_key(|x| x.to_string());

                    if preds1.len() != preds2.len() {
                        let mut t = format!(
                            "Mismatched bounds on associated type ({} != {})\n",
                            preds1.len(),
                            preds2.len(),
                        );
                        t.push_str("Target:\n");
                        for p1 in preds1.iter() {
                            t.push_str(&format!("  - {}\n", p1));
                        }
                        t.push_str("External specification:\n");
                        for p2 in preds2.iter() {
                            t.push_str(&format!("  - {}\n", p2));
                        }
                        return err_span(trait_span, t);
                    }

                    for (p1, p2) in preds1.iter().zip(preds2.iter()) {
                        match (p1.kind().skip_binder(), p2.kind().skip_binder()) {
                            (ClauseKind::Trait(p1), ClauseKind::Trait(p2)) => {
                                if p1.def_id() != p2.def_id() {
                                    return err_span(
                                        trait_span,
                                        format!(
                                            "Mismatched bounds on associated type ({} != {})",
                                            p1, p2
                                        ),
                                    );
                                }
                            }
                            (ClauseKind::Projection(p1), ClauseKind::Projection(p2)) => {
                                if p1.projection_term.expect_projection_def_id()
                                    != p2.projection_term.expect_projection_def_id()
                                {
                                    return err_span(
                                        trait_span,
                                        format!(
                                            "Mismatched projection bounds on associated type ({} != {})",
                                            p1, p2
                                        ),
                                    );
                                }
                            }
                            (ClauseKind::RegionOutlives(..), ClauseKind::RegionOutlives(..))
                            | (ClauseKind::TypeOutlives(..), ClauseKind::TypeOutlives(..)) => {
                                // Lifetime bounds don't affect verification soundness —
                                // they are handled entirely by the Rust borrow checker.
                                // This is consistent with process_predicate_bounds and
                                // compare_clause_kind, which also skip lifetime bounds.
                            }
                            _ => {
                                return err_span(
                                    trait_span,
                                    "Verus does not yet support this bound on external specs",
                                );
                            }
                        }
                    }
                }
            }
        }
    }
    let mut methods = make_trait_decls(methods)?;
    infos.append(&mut methods);
    let mut assoc_typs_bounds = Arc::new(assoc_typs_bounds);
    let target_trait_id = if let Some(target_trait_id) = ex_trait_id_for {
        typ_bounds =
            vir::traits::rewrite_external_bounds(&orig_trait_path, &trait_path, &typ_bounds);
        assoc_typs_bounds =
            vir::traits::rewrite_external_bounds(&orig_trait_path, &trait_path, &assoc_typs_bounds);
        target_trait_id
    } else {
        trait_def_id
    };
    state.external_info.local_trait_ids.push(target_trait_id);
    let external_trait_extension = if let Some((spec, imp)) = external_trait_extension {
        let spec = orig_trait_path.replace_last(Arc::new(spec.clone()));
        let imp = orig_trait_path.replace_last(Arc::new(imp.clone()));
        Some((spec, imp))
    } else {
        None
    };
    let traitx = TraitX {
        name: trait_path,
        proxy: ex_trait_id_for.map(|_| (*ctxt.spanned_new(trait_span, orig_trait_path)).clone()),
        visibility,
        methods: Arc::new(method_names),
        assoc_typs: Arc::new(assoc_typs),
        typ_params: generics_params,
        typ_bounds,
        assoc_typs_bounds,
        is_unsafe: match safety {
            Safety::Safe => false,
            Safety::Unsafe => true,
        },
        dyn_compatible: None,
        external_trait_extension,
    };
    vir.traits.push(ctxt.spanned_new(trait_span, traitx));
    Ok(())
}

// Each trait method declaration is encoded as a pair of methods:
//   fn VERUS_SPEC__f() { requires(x); ... }
//   fn f();
// This is done to preserve f's lack of a body,
// so that Rust's type checker can check that implementations of f provide a body.
// When generating VIR, merge the methods back into a single method:
//   fn f() requires x;
fn make_trait_decls(methods: Vec<FunctionOrConstInfo>) -> Result<Vec<FunctionOrConstInfo>, VirErr> {
    let mut decls: Vec<FunctionOrConstInfo> = Vec::new();
    let mut specs: HashMap<String, FunctionInfo> = HashMap::new();
    for method in methods.into_iter() {
        if let FunctionOrConstInfo::Function(f) = method {
            let mut name =
                f.function.x.name.path.segments.last().expect("method name last").to_string();
            if name.starts_with(VERUS_SPEC) {
                let name = name.split_off(VERUS_SPEC.len());
                specs.insert(name, f);
            } else {
                decls.push(FunctionOrConstInfo::Function(f));
            }
        } else {
            decls.push(method);
        }
    }
    for method in decls.iter_mut() {
        if let FunctionOrConstInfo::Function(f) = method {
            let name =
                f.function.x.name.path.segments.last().expect("method name last").to_string();
            // Note: None case means no specification method, which means no requires, ensures, etc.
            if let Some(spec_method) = specs.remove(&name) {
                *method = FunctionOrConstInfo::Function(make_trait_decl(f, &spec_method)?);
            }
        }
    }
    if specs.is_empty() {
        Ok(decls)
    } else {
        Err(vir::messages::multiple_errors(
            specs.values().map(|spec| &spec.function.span),
            format!(
                "no matching method found for method specification{}",
                if specs.len() > 1 { "s" } else { "" },
            ),
        ))
    }
}

fn make_trait_decl<'tcx>(
    method_info: &FunctionInfo<'tcx>,
    spec_method_info: &FunctionInfo<'tcx>,
) -> Result<FunctionInfo<'tcx>, VirErr> {
    let method = &method_info.function;
    let spec_method = &spec_method_info.function;

    let vir::ast::FunctionStubX {
        name: _,
        proxy: _,
        kind: _,
        visibility: _,
        body_visibility: _,
        opaqueness,
        owning_module: _,
        mode: _,
        typ_params,
        mut typ_bounds,
        params,
        outer_ret,
        item_kind: _,
        attrs,
        returns,
        decreases_len,
    } = spec_method.x.clone();
    let mut methodx = method.x.clone();
    if methodx.attrs.is_async != attrs.is_async {
        return Err(error(
            &spec_method.span,
            "method specification has different async-ness from method",
        ));
    }
    while typ_bounds.len() > methodx.typ_bounds.len() {
        // The syntax macro may add Sized bounds to spec_method so that Rust accepts the function.
        // Remove these added Sized bounds so that we can match the remaining bounds.
        use vir::ast::{GenericBoundX, TraitId};
        if let GenericBoundX::Trait(TraitId::Sizedness(vir::ast::Sizedness::Sized), _) =
            &**typ_bounds.last().unwrap()
        {
            Arc::make_mut(&mut typ_bounds).pop();
        }
    }
    if methodx.typ_params.len() != typ_params.len() {
        return Err(error(
            &spec_method.span,
            "method specification has different number of type parameters from method",
        ));
    }
    if methodx.typ_bounds.len() != typ_bounds.len() {
        return Err(error(
            &spec_method.span,
            "method specification has different number of type bounds from method",
        ));
    }
    for (x1, x2) in methodx.typ_params.iter().zip(typ_params.iter()) {
        if x1 != x2 {
            return Err(error(
                &spec_method.span,
                "method specification has different type parameters from method",
            ));
        }
    }
    for (b1, b2) in methodx.typ_bounds.iter().zip(typ_bounds.iter()) {
        if !vir::ast_util::generic_bounds_equal(b1, b2) {
            return Err(error(
                &spec_method.span,
                "method specification has different type parameters or bounds from method",
            ));
        }
    }
    if methodx.params.len() != params.len() {
        return Err(error(
            &spec_method.span,
            "method specification has different number of parameters from method",
        ));
    }
    for (p1, p2) in methodx.params.iter().zip(params.iter()) {
        if !params_equal_opt(p1, p2, false, false) {
            return Err(error(
                &spec_method.span,
                "method specification has different parameters from method",
            ));
        }
    }
    if !params_equal_opt(&methodx.outer_ret, &outer_ret, false, false) {
        return Err(error(
            &spec_method.span,
            "method specification has a different return from method",
        ));
    }

    let has_default_ensures = spec_method_info.pre_header.default_ensures;
    match &mut methodx.kind {
        vir::ast::FunctionKind::TraitMethodDecl { trait_path: _, has_default }
            if methodx.proxy.is_some() && has_default_ensures =>
        {
            // We use an external trait function default only if the spec mentions it:
            *has_default = true;
        }
        _ => {}
    };

    if spec_method_info.function_for_autospec.is_some()
        || method_info.function_for_autospec.is_some()
    {
        return Err(error(&spec_method.span, "not support: autospec on trait"));
    }

    methodx.opaqueness = opaqueness;
    methodx.params = params; // this is important; the correct parameter modes are in spec_method
    methodx.outer_ret = outer_ret;
    methodx.decreases_len = decreases_len;
    methodx.returns = returns;
    assert!(matches!(spec_method_info.body_id, CheckItemFnEither::BodyId(_)));
    if !matches!(method_info.body_id, CheckItemFnEither::ParamNames(_)) {
        return Err(error(
            &spec_method.span,
            "a VERUS_SPEC function should be paired with a function that has no body",
        ));
    }

    Ok(FunctionInfo {
        function: vir::def::Spanned::new(method.span.clone(), methodx),
        function_for_autospec: None,
        pre_header: spec_method_info.pre_header.clone(),
        def_id: spec_method_info.def_id,
        body_id: spec_method_info.body_id.clone(),
        sig: spec_method_info.sig.clone(),
        vattrs: spec_method_info.vattrs.clone(),
        external_trait_from_to: spec_method_info.external_trait_from_to.clone(),
        migrate_postcondition_vars: spec_method_info.migrate_postcondition_vars.clone(),
        assume_specification_opaque_type_map: spec_method_info
            .assume_specification_opaque_type_map
            .clone(),
        return_opaque_type_eqs: spec_method_info.return_opaque_type_eqs.clone(),
        ret_typ_mode: spec_method_info.ret_typ_mode.clone(),
        autoderive_action: None,
        is_external_const: false,
    })
}
