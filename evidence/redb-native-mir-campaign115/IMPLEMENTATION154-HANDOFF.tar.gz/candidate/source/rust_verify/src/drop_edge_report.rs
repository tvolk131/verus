use rustc_hir::def_id::{DefId, LocalDefId};
use rustc_middle::mir::visit::Visitor;
use rustc_middle::mir::{self, Body, Location, Operand, Place, TerminatorKind, UnwindAction};
use rustc_middle::ty::{self, Ty, TyCtxt};
use rustc_span::{Span, sym};
use serde_json::{Value, json};
use std::fs::OpenOptions;
use std::io::Write;
use std::path::{Path, PathBuf};
use std::sync::Mutex;
use std::sync::atomic::{AtomicBool, Ordering};

static ENABLED: AtomicBool = AtomicBool::new(false);
static REPORT: Mutex<Option<Report>> = Mutex::new(None);

struct Report {
    destination: PathBuf,
    reserved_files: Vec<PathBuf>,
    reserved_directories: Vec<PathBuf>,
    value: Value,
}

fn update(change: impl FnOnce(&mut Value)) {
    let Ok(mut guard) = REPORT.lock() else { return };
    let Some(report) = guard.as_mut() else { return };
    change(&mut report.value);
}

pub(crate) fn enabled() -> bool {
    ENABLED.load(Ordering::Relaxed)
}

fn output_identity(path: &Path) -> Option<PathBuf> {
    if let Ok(canonical) = path.canonicalize() {
        return Some(canonical);
    }
    let parent = path.parent().filter(|parent| !parent.as_os_str().is_empty()).unwrap_or(Path::new("."));
    Some(output_identity(parent)?.join(path.file_name()?))
}

fn reserved_destination(report: &Report) -> bool {
    let Some(destination) = output_identity(&report.destination) else { return true };
    report.reserved_files.iter().any(|path| {
        output_identity(path).is_some_and(|reserved| reserved.starts_with(&destination))
    }) || report.reserved_directories.iter().any(|path| {
        output_identity(path).is_some_and(|reserved| {
            destination.starts_with(&reserved) || reserved.starts_with(&destination)
        })
    })
}

pub(crate) fn reserve_proof_output(path: &Path) {
    let Ok(mut guard) = REPORT.lock() else { return };
    let Some(report) = guard.as_mut() else { return };
    report.reserved_files.push(path.to_path_buf());
    report.reserved_files.push(crate::import_export::export_temporary_path(path));
}

pub(crate) struct PublicationGuard;

impl Drop for PublicationGuard {
    fn drop(&mut self) {
        let Ok(mut guard) = REPORT.lock() else { return };
        let Some(report) = guard.take() else { return };
        ENABLED.store(false, Ordering::Relaxed);
        if reserved_destination(&report) {
            eprintln!("warning: experimental drop-edge report conflicts with a reserved output; report disabled, verifier status unchanged");
            return;
        }
        let result = (|| -> std::io::Result<()> {
            let bytes = serde_json::to_vec_pretty(&report.value)?;
            let mut file = OpenOptions::new().write(true).create_new(true).open(&report.destination)?;
            file.write_all(&bytes)?;
            file.flush()
        })();
        if let Err(error) = result {
            eprintln!("warning: experimental drop-edge report not published: {error}; verifier status unchanged");
        }
    }
}

pub(crate) fn begin(
    path: &str,
    export: Option<&str>,
    reserved_files: Vec<PathBuf>,
    reserved_directories: Vec<PathBuf>,
    no_lifetime: bool,
    user_scope: Value,
    provider: &str,
) {
    let destination = Path::new(path);
    if destination
        .extension()
        .is_some_and(|extension| extension == "vir")
    {
        eprintln!(
            "warning: experimental drop-edge report cannot use a proof export path; report disabled, verifier status unchanged"
        );
        return;
    }
    let value = json!({
        "schema": "verus.experimental.drop-edge-report", "schema_version": 1,
        "classification": "DIAGNOSTIC_ONLY_NOT_A_NATIVE_PROOF",
        "semantic_obligations": "NOT_CHECKED", "proof_acceptance": false,
        "native_proof": false, "checked_destruction_events": 0,
        "complete_destruction_certification": false,
        "coverage": "PARTIAL_PRE_ELABORATION_OBSERVATIONS_ONLY_EVEN_IF_EMPTY",
        "compiler_source_identity": option_env!("VARGO_BUILD_SHA"),
        "query": "mir_built", "provider": provider,
        "authoritative_drop_elaboration_query": "mir_drops_elaborated_and_const_checked",
        "authoritative_query_requested_by_reporter": false,
        "limitations": [
            "Observes only existing custom mir_built queries; never forces a body or bypasses lifetime checks",
            "Pre-ElaborateDrops: syntactic whole-place drops may be conditional, dead, or no-ops",
            "Drop flags, initialization dataflow, field order and generic/monomorphized glue are unresolved",
            "No MIR-to-VIR place/loan/VC correspondence is established by spans, names or HirId/AstId inventory",
            "Cleanup membership is not a model or assumption of actual thread panic state",
            "External, erased, unqueried, failed translation and unsupported bodies may have no graph",
            "All calls, escapes, unwind effects and unknown instructions remain semantically unchecked",
            "No theorem/body credit, contextual Drop markers, std contracts, axioms or proof exports are produced"
        ],
        "lifetime_checks_disabled_by_existing_user_option": no_lifetime,
        "user_scope": user_scope,
        "inventory_available": false, "body_inventory": [], "bodies": [],
        "erasure_bindings": null, "milestones": ["report_started_no_verification_outcome_implied"]
    });
    if let Ok(mut guard) = REPORT.lock() {
        *guard = Some(Report { destination: destination.to_path_buf(), reserved_files, reserved_directories, value });
        ENABLED.store(true, Ordering::Relaxed);
    }
    if let Some(export) = export {
        reserve_proof_output(Path::new(export));
    }
}

pub(crate) fn milestone(name: &str) {
    update(|report| {
        if let Some(milestones) = report["milestones"].as_array_mut() {
            milestones.push(json!(name));
        }
    });
}

fn identity(tcx: TyCtxt<'_>, def: DefId) -> Value {
    json!({"def_id": format!("{def:?}"), "def_path": tcx.def_path_str(def),
        "def_path_hash": format!("{:?}", tcx.def_path_hash(def)),
        "crate": tcx.crate_name(def.krate).to_string()})
}

fn span(tcx: TyCtxt<'_>, source: Span) -> Value {
    json!({"display": tcx.sess.source_map().span_to_diagnostic_string(source),
        "raw": format!("{source:?}"), "expanded": source.from_expansion(),
        "syntax_context": format!("{:?}", source.ctxt())})
}

pub(crate) fn scope(tcx: TyCtxt<'_>) {
    if !enabled() {
        return;
    }
    let owners: Vec<_> = tcx
        .hir_body_owners()
        .map(|def| {
            json!({
                "owner": identity(tcx, def.to_def_id()), "span": span(tcx, tcx.def_span(def)),
                "coverage": "NOT_CHECKED_GRAPH_PRESENT_ONLY_IF_OBSERVED"
            })
        })
        .collect();
    update(|report| {
        report["inventory_available"] = json!(true);
        report["body_inventory"] = json!(owners);
    });
}

pub(crate) fn hir_bindings(tcx: TyCtxt<'_>, entries: &[(Option<rustc_hir::HirId>, u64)]) -> Value {
    json!(
        entries
            .iter()
            .map(|(hir, ast)| json!({
                "hir_id": hir.map(|id| format!("{id:?}")), "ast_id": format!("{ast:?}"),
                "owner": hir.map(|id| identity(tcx, id.owner.def_id.to_def_id())),
                "mir_place_correspondence": "UNRESOLVED_NOT_CHECKED"
            }))
            .collect::<Vec<_>>()
    )
}

pub(crate) fn erasure_bindings(value: Value) {
    update(|report| report["erasure_bindings"] = value);
    milestone("existing_erasure_setup_completed_no_mir_to_vir_proof_mapping");
}

fn type_identity<'tcx>(tcx: TyCtxt<'tcx>, typ: Ty<'tcx>) -> Value {
    json!({"display": typ.to_string(), "rustc_type": format!("{typ:?}"),
        "adt": if let ty::Adt(def, arguments) = typ.kind() {
            json!({"identity": identity(tcx, def.did()), "arguments": format!("{arguments:?}"),
                "glue": "OPAQUE_NOT_ELABORATED_OR_CHECKED"})
        } else { Value::Null }, "ownership_and_drop_effects": "NOT_CHECKED"})
}

fn place<'tcx>(tcx: TyCtxt<'tcx>, body: &Body<'tcx>, value: Place<'tcx>) -> Value {
    json!({"local": format!("{:?}", value.local), "projection": format!("{:?}", value.projection),
        "display": format!("{value:?}"), "type": type_identity(tcx, value.ty(&body.local_decls, tcx).ty),
        "hir_vir_loan_correspondence": "UNRESOLVED"})
}

fn operand<'tcx>(tcx: TyCtxt<'tcx>, body: &Body<'tcx>, value: &Operand<'tcx>) -> Value {
    let (kind, source) = match value {
        Operand::Move(source) => ("move", Some(place(tcx, body, *source))),
        Operand::Copy(source) => ("copy", Some(place(tcx, body, *source))),
        Operand::Constant(_) => ("constant", None),
        Operand::RuntimeChecks(_) => ("runtime_checks_unhandled_semantics", None),
    };
    json!({"kind": kind, "place": source, "display": format!("{value:?}"),
        "type": type_identity(tcx, value.ty(&body.local_decls, tcx)), "effects": "NOT_CHECKED"})
}

fn unwind(action: UnwindAction) -> Value {
    json!({"action": format!("{action:?}"), "cleanup_target":
        if let UnwindAction::Cleanup(target) = action { Some(format!("{target:?}")) } else { None },
        "panic_state": "UNKNOWN_NOT_ASSUMED", "effects": "NOT_CHECKED"})
}

struct Moves<'a, 'tcx> {
    tcx: TyCtxt<'tcx>,
    body: &'a Body<'tcx>,
    events: Vec<Value>,
}

impl<'tcx> Visitor<'tcx> for Moves<'_, 'tcx> {
    fn visit_operand(&mut self, value: &Operand<'tcx>, location: Location) {
        if matches!(value, Operand::Move(_) | Operand::Copy(_)) {
            self.events.push(json!({"location": format!("{location:?}"),
                "span": span(self.tcx, self.body.source_info(location).span),
                "operand": operand(self.tcx, self.body, value), "obligation_transfer": "UNRESOLVED_NOT_CHECKED"}));
        }
        self.super_operand(value, location);
    }
}

pub(crate) fn observe<'tcx>(tcx: TyCtxt<'tcx>, def: LocalDefId, body: &Body<'tcx>) {
    let locals: Vec<_> = body.local_decls.iter_enumerated().map(|(local, declaration)| json!({
        "local": format!("{local:?}"), "type": type_identity(tcx, declaration.ty),
        "span": span(tcx, declaration.source_info.span), "source_scope": format!("{:?}", declaration.source_info.scope),
        "kind": if local == mir::RETURN_PLACE { "return" } else if local.as_usize() <= body.arg_count { "argument" } else { "local_or_temporary" },
        "drop_flag_role": "NOT_KNOWN_AT_THIS_QUERY_STAGE"
    })).collect();
    let debug: Vec<_> = body.var_debug_info.iter().map(|variable| json!({
        "name": variable.name.to_string(), "value": format!("{:?}", variable.value),
        "span": span(tcx, variable.source_info.span), "mapping": "DEBUG_INFO_NOT_A_CHECKED_HIR_BINDING"
    })).collect();
    let mut blocks = Vec::new();
    for (block, data) in body.basic_blocks.iter_enumerated() {
        let statements: Vec<_> = data.statements.iter().enumerate().map(|(index, statement)| {
            let assignment = if let mir::StatementKind::Assign(value) = &statement.kind {
                json!({"destination": place(tcx, body, value.0), "rvalue": format!("{:?}", value.1),
                    "initialization_or_overwrite": "UNRESOLVED_NO_DROP_FLAG_DATAFLOW"})
            } else { Value::Null };
            json!({"index": index, "span": span(tcx, statement.source_info.span),
                "kind": format!("{:?}", statement.kind), "assignment": assignment, "semantics": "NOT_CHECKED"})
        }).collect();
        let terminator = data.terminator();
        let event = match &terminator.kind {
            TerminatorKind::Drop {
                place: source,
                target,
                unwind: action,
                replace,
                drop,
            } => json!({
                "kind": "syntactic_drop", "place": place(tcx, body, *source),
                "normal_target": format!("{target:?}"), "unwind": unwind(*action),
                "replace": replace, "async_drop_target": drop.map(|target| format!("{target:?}")),
                "glue": "OPAQUE_PRE_ELABORATION_NOT_CHECKED", "actually_runs": "UNRESOLVED_DROP_FLAGS"
            }),
            TerminatorKind::Call {
                func,
                args,
                destination,
                target,
                unwind: action,
                call_source,
                fn_span,
            } => {
                let callee_type = func.ty(&body.local_decls, tcx);
                let (callee, class) = if let ty::FnDef(callee, substitutions) = callee_type.kind() {
                    let class = if tcx.is_diagnostic_item(sym::mem_drop, *callee) {
                        "resolved_core_mem_drop"
                    } else if tcx.is_diagnostic_item(sym::mem_forget, *callee) {
                        "resolved_core_mem_forget_non_drop_escape"
                    } else {
                        "resolved_call_opaque_effects"
                    };
                    (
                        json!({"identity": identity(tcx, *callee), "substitutions": format!("{substitutions:?}")}),
                        class,
                    )
                } else {
                    (Value::Null, "indirect_call_unresolved_escape")
                };
                json!({"kind": "call", "classification": class, "callee": callee,
                    "function_operand": operand(tcx, body, func), "function_span": span(tcx, *fn_span),
                    "call_source": format!("{call_source:?}"), "arguments": args.iter().map(|argument| json!({
                        "span": span(tcx, argument.span), "operand": operand(tcx, body, &argument.node)
                    })).collect::<Vec<_>>(), "destination": place(tcx, body, *destination),
                    "normal_target": target.map(|target| format!("{target:?}")), "unwind": unwind(*action),
                    "translation_or_effect_boundary": "IDENTITY_OBSERVED_ONLY_NO_VIR_SUPPORT_OR_DROP_EFFECT_CLAIM"})
            }
            TerminatorKind::Assert {
                target,
                unwind: action,
                ..
            } => json!({
                "kind": "assert", "normal_target": format!("{target:?}"), "unwind": unwind(*action),
                "panic_state": "UNKNOWN_NOT_ASSUMED"}),
            TerminatorKind::Return => {
                json!({"kind": "return", "return_place": place(tcx, body, Place::from(mir::RETURN_PLACE)),
                "owner_escape": "UNRESOLVED_TRANSFER_NOT_DESTRUCTION"})
            }
            _ => {
                json!({"kind": "other_terminator", "boundary": "OBSERVED_ONLY_UNHANDLED_SEMANTICS_NOT_CHECKED"})
            }
        };
        blocks.push(json!({"block": format!("{block:?}"), "is_cleanup": data.is_cleanup,
            "cleanup_is_not_thread_panic_state": true, "statements": statements,
            "terminator": {"span": span(tcx, terminator.source_info.span), "raw": format!("{:?}", terminator.kind),
                "successors": terminator.successors().map(|target| format!("{target:?}")).collect::<Vec<_>>(),
                "event": event, "semantic_obligations": "NOT_CHECKED"}}));
    }
    let mut moves = Moves {
        tcx,
        body,
        events: Vec::new(),
    };
    moves.visit_body(body);
    let observed = json!({"owner": identity(tcx, def.to_def_id()),
        "owner_hir_id": format!("{:?}", tcx.local_def_id_to_hir_id(def)),
        "span": span(tcx, body.span), "query": "mir_built", "mir_phase": format!("{:?}", body.phase),
        "tainted_by_errors": body.tainted_by_errors.is_some(), "locals": locals, "debug_variables": debug,
        "blocks": blocks, "move_copy_events": moves.events, "known_elaborated_drop_flags": [],
        "drop_flags_status": "UNAVAILABLE_PRE_ELABORATION_NOT_ZERO_FLAGS",
        "nested_generic_manuallydrop_and_other_glue": "OPAQUE_UNRESOLVED_NOT_CHECKED",
        "semantic_obligations": "NOT_CHECKED", "proof_acceptance": false});
    update(|report| {
        if let Some(bodies) = report["bodies"].as_array_mut() {
            bodies.push(observed);
        }
    });
}
