# Review131 accounting and custody

- Start: 2026-11-08T18:35:48Z (UTC), observed before any substantive read. Hard stop including seal/readback: 18:48:48Z. The fresh directory name uses the observed start time, not a claimed historical artifact timestamp.
- Entry free space: 33,067,608 KiB (>16,777,216 KiB =16GiB, strictly). A new numerical free-space check guards every write group. Outputs limited to this fresh directory, under 2MiB combined; no source/archive/input modification, copying, bulk extraction, cleanup or integration.
- Allowed operations used: date, df, ls/stat, filename inventory (`rg --files`), source searches (`rg`), bounded line reads (`nl`/`sed`, plus bounded head/tail searches), SHA-256 reads, selective tar listing and single-member streaming into SHA-256; report construction with apply_patch; seal/readback hashing. No other task worker state queried.
- No compiler/Cargo/rustfmt/verifier/solver/test/diagnostic/native application execution. No network, Git, trust/admission/import/export change, goal operation or subdelegate. No proof or model submitted to an engine.

## Anchor dictionary

All paths and full SHA-256 values are in INPUTS.sha256. `L` below is the supplied expanded local library root; `V` is the specifically permitted matched-vstd snapshot/source/vstd root; `Nroot` is /private/tmp/redb-original-crate-preflight115/redb.

- N = Nroot/src/tree_store/page_store/cached_file.rs; Sync = Nroot/src/sync.rs; StorageBackend = Nroot/src/db.rs.
- M = L/std/src/sync/poison/mutex.rs; P = L/std/src/sync/poison.rs; S = L/std/src/sys/sync/mutex/mod.rs; T = L/std/src/sys/sync/mutex/pthread.rs; U = L/std/src/sys/pal/unix/sync/mutex.rs.
- A = L/core/src/sync/atomic.rs; I = L/core/src/intrinsics/mod.rs; R = L/core/src/result.rs.
- PalMod = L/std/src/sys/pal/mod.rs; PalUnix = L/std/src/sys/pal/unix/mod.rs; PalSync = L/std/src/sys/pal/unix/sync/mod.rs.
- Vatomic = V/std_specs/atomic.rs; Vresult = V/std_specs/result.rs; Vmod = V/std_specs/mod.rs; Patomic = V/atomic.rs; Gatomic = V/atomic_ghost.rs; Vrwlock = V/rwlock.rs; Resource = V/resource/storage_protocol.rs. V/thread.rs and V/resource/mod.rs received limited search/read only.

## Authentication scope

The five pre-supplied SHA-256 entry pins were checked first: selection JSON, archive (also observed size 5,863,216 bytes), M, N, Vatomic. Every matched the user's pin. Additional selected sources were prehashed before content analysis. Extra library members A/I/P/S/T/U/R/PalMod/PalUnix/PalSync were streamed individually from exact archive member names and their SHA-256 values matched the prehashed expanded files. This is selective archive reading, not bulk extraction. M had the explicit entry pin; an additional archive equality check is included in the final seal procedure.

Ten added library-member comparisons plus the final M comparison establish byte continuity to this local archive only. The component manifest itself was NOT inspected; the JSON's version/full-commit binding (1.99.1, 58cf8f9c35b355199727627d07ae34a4e2846d67) remains a supplied local-binding claim, not upstream authentication or current compiler/bootstrap correspondence. Historical parent custody/recheck assertions in the JSON were not rerun or adopted as review131 checks.

Additional first-seen file hashes are current observed baselines, NOT independent prior supplied pins. The inventory includes five hash-only candidates to avoid concealing discovery: vstd/invariant.rs and four native file_backend files. They were not substantively analyzed. CheckedBackend was located in the already pinned cached_file.rs by an in-file source search, not by looking at another worker's outputs. Native src/db.rs was located by filename inventory before hashing and reading the StorageBackend declaration. Native sync.rs was hashed before reading the std/no_std alias.

## Bounded reads and limited negative finding

Primary reads/searches: N's drop/reservation helpers, CheckedBackend, initialization, cache flush/discard/shrink/read/cancel/write/eviction lock boundaries (roughly source lines 1–980; test code was not analyzed); M's poison documentation, construction, lock/try_lock, guard access/drop; P's flag/guard/result mapping; S/T/U's selection, initialization, lock/unlock/drop; A's bool constructor/load/store, ordering docs and primitive dispatch; I's atomic ordering and load/store declarations; R's unwrap/panic helper. Pal files were prehashed and selectively searched/read to bind the Unix dispatch.

Vstd inspection: Vmod's module list; Vatomic's native type and method specs; Vresult's unwrap/map_err requirements; Patomic's wrapper identity/permission/new/load/store APIs; Gatomic's wrapper/invariant construction; Vrwlock's structure/release/acquire interfaces and explicit drop qualification; Resource's ghost interface and declarations; resource/mod exports; thread.rs only in a keyword search. A native-Mutex-related keyword search was limited to Vatomic/Vresult/Vmod/Vrwlock/thread/Resource, yielding only core::sync atomic imports in Vatomic. Filename discovery also found no Mutex-named source file in that permitted vstd tree. No native Mutex bridge was found in these inspected interfaces; no exhaustive all-files/native-engine absence claim is made.

Initial broad cached-file grep incidentally printed test identifiers and other AtomicUsize/metric lines. Initial full sync.rs output incidentally included some cfg-gated spinning-lock source. Neither tests nor that alternative runtime implementation was executed/analyzed as the native std target. No Arc count implementation or map/hasher implementation was read. No caller115 report/table was used; no Arc130/custom-hasher124/old110 replay or other live worker-output inspection occurred.

## Failures / incomplete delivery retained

No file-not-found, permissions, hash mismatch, tar diagnostic or nonzero command exit was observed during source discovery/reading. Nine multi-read tool responses DID report `Warning: truncated output`; these are incomplete deliveries, not complete source reads and not successful exhaustive searches:

1. 4892fb: selection JSON + filename inventories + N lines 1–260 + Vatomic 1–240. Important N/Vatomic slices were reread in narrower later calls; inventories were repeated with narrower selectors.
2. 5b5cfe: filename inventories + broad cached-file grep + four hash-only backend digests + selective archive listing. CheckedBackend and used lock paths were subsequently directly read; no conclusion relies on omitted grep hits.
3. ff56ef: Sync prehash + N 1–59/120–260 + S/T. Used N fragments were reread; visible S/T sections and subsequent targeted reads supply the used anchors.
4. c1464d: accidentally requested all Sync source, N 188–278, PAL inventory and Vmod. Std alias 4–12 was visible; spin implementation is outside analysis. Needed CheckedBackend flag branch was reread later. Vmod module list was visible.
5. 5a2c8a: poison search/flag slice and U 1–160. U initialization was reread narrowly; used lock/unlock/drop sections and poison state transition were visible.
6. 749bc4: N 486–584/642–704/765–813. Dirty-page lock path was reread. Used flush/shrink/cancel anchors were visible; no claim relies on omitted intervening lines.
7. 93fafc: A memory-model/Ordering/bool slices. Acquire/Release semantics were reread; primitive dispatch was separately read. No omitted ordering prose was treated as checked semantics.
8. 309912: R/StorageBackend search + Patomic/resource/Gatomic slices. Patomic and Gatomic critical interfaces were reread narrowly; StorageBackend declaration and R unwrap helper were directly read later.
9. f0bb82: first output readback combined REPORT.md 86–112 with ACCOUNTING.md 1–28 and was truncated. The omitted report tail is reread separately; this warning is retained, the accounting/count updated, and the bundle resealed before final authentication/readback. No source conclusion changes.

These warnings remain in this accounting despite later successful narrowed reads. Deliberately bounded head/tail/search selections do not assert complete-file inspection. Archive streams initially printed both hashes with no error; final authentication uses pipefail for the selected M stream and input inventory verification, rather than interpreting a pipeline's last status as evidence of absent upstream errors.

## Seal procedure / terminal accounting

The report, inventory and this accounting are sealed together by SEAL.sha256. Before handoff: verify all 30 inventory entries against their entry/current baselines; recheck archive byte length and M's selective archive member equality; numerically check free space and combined bundle size; record actual seal time and byte count in FINAL-STATUS.txt; hash these four payload files into SEAL.sha256; verify the seal and read all payloads back in bounded pieces. The terminal tool results, not this prospective procedure, establish completion of those steps. The seal is an integrity record, not external authentication or a proof/trust artifact. No changes follow the successful final authentication/readback.

All18 OPEN. Native/resource/trust/proof credit 0. The handoff's only proposed action is the explicit primitive-admission decision in REPORT.md, not an automatic follow-on audit or fabricated checked theorem.
