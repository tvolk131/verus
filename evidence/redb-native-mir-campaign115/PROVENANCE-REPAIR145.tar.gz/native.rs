use super::affine;
use serde::{Deserialize, Serialize};
use std::collections::{BTreeMap, BTreeSet, VecDeque};

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq, Eq, PartialOrd, Ord)]
pub struct Place {
    pub local: usize,
    pub projection: Vec<String>,
    pub typ: String,
}

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq, Eq, PartialOrd, Ord)]
pub struct Location {
    pub block: usize,
    pub statement: usize,
}

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq, Eq)]
pub enum Activation {
    Immediate,
    Reserved,
    At(Location),
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct Loan {
    pub index: usize,
    pub reservation: Location,
    pub activation: Activation,
    pub kind: String,
    pub region: String,
    pub borrowed: Place,
    pub assigned: Place,
    pub ends: Vec<Location>,
}

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq, Eq)]
pub enum Primitive {
    ArcDeref,
    ArcGetMut,
    OptionUnwrap,
    ArcClone,
    MutexLock,
    ResultUnwrap,
    GuardDerefMut,
    SliceCopy,
    OptionReplace,
    OptionTake,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct Api {
    pub definition: String,
    pub definition_hash: String,
    pub resolved_instance: String,
    pub resolved_hash: String,
    pub crate_name: String,
    pub crate_hash: String,
    pub signature: String,
    pub self_type: Option<String>,
    pub primitive: Option<Primitive>,
    pub application_body: Option<String>,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub enum Value {
    Copy(Place),
    Move(Place),
    Constant(String),
    Borrow { source: Place, loan: Option<usize>, ignored_by_borrowck: bool, kind: String },
    NominalAggregate { definition_hash: String, typ: String, fields: Vec<(String, Value)> },
    Unsupported(String),
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub enum Statement {
    Assign { destination: Place, value: Value },
    Storage { local: usize, live: bool },
    Nop,
    Unsupported(String),
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub enum Unwind {
    Cleanup(usize),
    Continue,
    Unreachable,
    Terminate(String),
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub enum End {
    Call { api: Api, arguments: Vec<Value>, destination: Place, normal: Option<usize>, unwind: Unwind },
    Drop { place: Place, normal: usize, unwind: Unwind },
    Goto(usize),
    FalseEdge { real: usize, imaginary: usize },
    Switch { operand: Value, targets: Vec<usize> },
    Return,
    Resume,
    Terminate(String),
    Unreachable,
    Unsupported(String),
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct Block {
    pub cleanup: bool,
    pub original_statements: Vec<String>,
    pub original_terminator: String,
    pub statements: Vec<Statement>,
    pub end: End,
    pub compiler_successors: Vec<usize>,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct Body {
    pub definition: String,
    pub definition_hash: String,
    pub nominal_self: String,
    pub nominal_self_hash: String,
    pub source_file: String,
    pub source_sha256: String,
    pub source_body: String,
    pub mir_phase: String,
    pub method: String,
    pub data_field: usize,
    pub fields: Vec<(String, String)>,
    pub destructor_hash: Option<String>,
    pub return_type: String,
    pub locals: Vec<String>,
    pub loans: Vec<Loan>,
    pub blocks: Vec<Block>,
    pub unsupported: Vec<String>,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct Obligation {
    pub location: Option<Location>,
    pub kind: String,
    pub requirement: String,
    pub disposition: String,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct ConditionalDerivation {
    pub body_hash: String,
    pub method: String,
    pub steps: Vec<String>,
    pub obligations: Vec<Obligation>,
    pub returned_data_view: bool,
    pub native_bodies_proved: usize,
    pub status: String,
}

#[derive(Clone, Debug, PartialEq, Eq)]
enum PendingKind {
    SelfArgument,
    DataArcBorrow,
    OptionalUniqueData,
    DataView,
}

#[derive(Clone, Debug, PartialEq, Eq)]
struct Pending {
    kind: PendingKind,
    loan: Option<usize>,
}

type PendingState = BTreeMap<Place, Pending>;

fn open(location: Option<Location>, kind: &str, requirement: String) -> Obligation {
    Obligation { location, kind: kind.into(), requirement, disposition: "OPEN; not adopted or assumed".into() }
}

fn successors(end: &End) -> Vec<usize> {
    let mut result = Vec::new();
    match end {
        End::Call { normal, unwind, .. } => {
            result.extend(normal);
            if let Unwind::Cleanup(target) = unwind { result.push(*target); }
        }
        End::Drop { normal, unwind, .. } => {
            result.push(*normal);
            if let Unwind::Cleanup(target) = unwind { result.push(*target); }
        }
        End::Goto(target) => result.push(*target),
        End::FalseEdge { real, imaginary } => result.extend([real, imaginary]),
        End::Switch { targets, .. } => result.extend(targets),
        _ => {}
    }
    result.sort_unstable();
    result.dedup();
    result
}

fn source_of(value: &Value) -> Option<&Place> {
    match value {
        Value::Copy(place) | Value::Move(place) => Some(place),
        _ => None,
    }
}

fn local_place(body: &Body, local: usize) -> Result<Place, String> {
    let typ = body.locals.get(local).ok_or("NRE145_LOCAL_TYPE_MISSING")?;
    Ok(Place { local, projection: Vec::new(), typ: typ.clone() })
}

fn invalidate_place(pending: &mut PendingState, written: &Place) {
    pending.retain(|place, _| {
        let common = place.projection.len().min(written.projection.len());
        place.local != written.local
            || place.projection[..common] != written.projection[..common]
    });
}

fn consume_moves(pending: &mut PendingState, value: &Value) {
    match value {
        Value::Move(place) => invalidate_place(pending, place),
        Value::NominalAggregate { fields, .. } => {
            for (_, field) in fields { consume_moves(pending, field); }
        }
        Value::Unsupported(_) => pending.clear(),
        _ => {}
    }
}

fn transfer_call(
    pending: &mut PendingState,
    arguments: &[Value],
    destination: &Place,
    result: Option<Pending>,
) -> Result<(), String> {
    for argument in arguments { consume_moves(pending, argument); }
    invalidate_place(pending, destination);
    if let Some(resource) = result {
        if !destination.projection.is_empty() {
            return Err("NRE145_PROJECTED_CALL_RESULT".into());
        }
        pending.insert(destination.clone(), resource);
    }
    Ok(())
}

fn apply_loan_ends(
    body: &Body,
    location: &Location,
    pending: &mut PendingState,
    steps: &mut Vec<String>,
    obligations: &mut Vec<Obligation>,
) {
    for loan in &body.loans {
        if loan.ends.contains(location) {
            pending.retain(|_, resource| resource.loan != Some(loan.index));
            steps.push(format!("actual NLL end {} at {location:?}; pending view invalidated", loan.index));
            obligations.push(open(Some(location.clone()), "loan-end-writeback", format!(
                "loan {} ending at actual {location:?} requires checked byte writeback, receiver resumption and normal/cleanup frame; invalidating pending provenance proves none of these effects",
                loan.index)));
        }
    }
}

fn transfer_statement(
    body: &Body,
    location: &Location,
    statement: &Statement,
    pending: &mut PendingState,
    steps: &mut Vec<String>,
    obligations: &mut Vec<Obligation>,
) -> Result<(), String> {
    match statement {
        Statement::Assign { destination, value } => {
            let replacement = match value {
                Value::Borrow { source, loan, ignored_by_borrowck, kind } => {
                    let native_loan = if let Some(loan_index) = loan {
                        let native_loan = body.loans.iter().find(|entry| entry.index == *loan_index)
                            .ok_or("NRE140_MISSING_LOAN")?;
                        if native_loan.reservation != *location || native_loan.borrowed != *source
                            || native_loan.assigned != *destination || native_loan.kind != *kind
                        {
                            return Err("NRE140_LOAN_ORIGIN_MISMATCH".into());
                        }
                        Some(native_loan)
                    } else if *ignored_by_borrowck && kind == "Shared" {
                        steps.push(format!("{location:?}: compiler PlaceExt::ignore_borrow explicitly omits this shared borrow; no invented loan/end"));
                        None
                    } else {
                        return Err(format!("NRE140_UNBOUND_LOAN {location:?}"));
                    };
                    if !destination.projection.is_empty() {
                        return Err("NRE140_PROJECTED_LOAN_DESTINATION".into());
                    }
                    let receiver = local_place(body, 1)?;
                    if source.local == 1
                        && source.projection == ["Deref".to_string(), format!("Field({})", body.data_field)]
                        && pending.get(&receiver).is_some_and(|resource| resource.kind == PendingKind::SelfArgument)
                    {
                        steps.push(format!("{location:?}: actual data-field borrow; native loan {native_loan:?}"));
                        Some(Pending { kind: PendingKind::DataArcBorrow, loan: *loan })
                    } else if source.projection == ["Deref".to_string()] {
                        let parent_place = local_place(body, source.local)?;
                        if let Some(parent) = pending.get(&parent_place) {
                            steps.push(format!("{location:?}: actual reborrow {source:?} -> {destination:?}; native loan {native_loan:?}"));
                            Some(Pending { kind: parent.kind.clone(), loan: *loan })
                        } else {
                            obligations.push(open(Some(location.clone()), "place-resource", format!("reborrow has no pending full-place origin {parent_place:?}")));
                            None
                        }
                    } else {
                        obligations.push(open(Some(location.clone()), "place-resource", format!("unsupported borrowed resource {source:?}")));
                        None
                    }
                }
                Value::Copy(source) | Value::Move(source) => {
                    if !source.projection.is_empty() || !destination.projection.is_empty()
                        || source.typ != destination.typ
                    {
                        obligations.push(open(Some(location.clone()), "place-transfer", format!("unsupported full-place transfer {source:?} -> {destination:?}")));
                        None
                    } else {
                        let resource = pending.get(source).cloned();
                        if resource.is_none() {
                            obligations.push(open(Some(location.clone()), "place-transfer", format!("untracked source overwrites {destination:?}: {source:?}; no byte/resource transfer derived")));
                        }
                        resource
                    }
                }
                _ => {
                    obligations.push(open(Some(location.clone()), "unsupported-statement", format!("{statement:?}")));
                    None
                }
            };
            consume_moves(pending, value);
            invalidate_place(pending, destination);
            if let Some(resource) = replacement {
                pending.insert(destination.clone(), resource);
            }
        }
        Statement::Storage { local, .. } => pending.retain(|place, _| place.local != *local),
        Statement::Nop => {}
        Statement::Unsupported(_) => {
            pending.clear();
            obligations.push(open(Some(location.clone()), "unsupported-statement", format!("{statement:?}; all pending provenance invalidated")));
        }
    }
    Ok(())
}

fn required_interface(api: &Api) -> String {
    match api.primitive {
        Some(Primitive::ArcDeref) => "OPEN provider obligation: relate this exact Arc handle and allocation to the returned shared byte-view, its lifetime and frame; no Arc allocation/refcount effect is erased",
        Some(Primitive::ArcGetMut) => "OPEN provider obligation: exact Some/None eligibility, allocation identity, uniqueness and mutable loan lifetime/frame, including concurrency and alias/refcount conditions; no condition or successful outcome is assumed",
        Some(Primitive::OptionUnwrap) => "OPEN provider obligation: transfer the precise Some payload on the normal edge; preserve None's panic/unwind/abort/divergence outcomes and partial effects; caller must establish any required Some premise",
        Some(Primitive::ArcClone) => "OPEN provider obligation: allocation/handle identity and actual refcount/overflow/abort/divergence effects; cloning is not pure or inert",
        Some(Primitive::MutexLock) => "OPEN provider obligation: acquired/poisoned/blocked/unwind/abort/divergence alternatives and protected invariant transfer; no successful lock or reservation survival is assumed",
        Some(Primitive::GuardDerefMut) => "OPEN provider obligation: exact guard-to-protected-place mutable loan, lifetime, frame and unlock/drop obligations",
        Some(Primitive::ResultUnwrap) => "OPEN provider obligation: exact Ok payload and Err panic/cleanup behavior, including ownership of PoisonError's guard; no poison-free premise assumed",
        Some(Primitive::SliceCopy) => "OPEN provider obligation: actual source/destination bytes, alias and equal-length conditions; distinguish normal copy from length-mismatch panic and its partial/frame behavior",
        Some(Primitive::OptionReplace) => "OPEN provider obligation: exact old/new payload ownership and slot update at the native place; return_value must separately prove that the old payload is None",
        Some(Primitive::OptionTake) => "OPEN provider obligation: exact old payload and replacement None; caller must prove map slot correspondence and reservation continuity",
        None if api.application_body.is_some() => "OPEN checked ORIGINAL callee obligation, never a primitive law: body semantics, resource pre/postconditions, all successors, frame and caller invariants must be proved",
        None => "OPEN unsupported external effect: no primitive interface is inferred from this method's name",
    }.into()
}

pub fn derive(body: &Body) -> Result<ConditionalDerivation, String> {
    if body.blocks.is_empty() || body.locals.len() < 2 || body.source_sha256.len() != 64
        || body.definition_hash.is_empty() || body.source_body.is_empty()
    {
        return Err("NRE140_BODY_IDENTITY_OR_CFG_MISSING".into());
    }
    for (index, block) in body.blocks.iter().enumerate() {
        let mut expected = block.compiler_successors.clone();
        expected.sort_unstable();
        expected.dedup();
        if successors(&block.end) != expected || expected.iter().any(|target| *target >= body.blocks.len()) {
            return Err(format!("NRE140_SUCCESSOR_LOSS bb{index}"));
        }
        match &block.end {
            End::Call { unwind: Unwind::Cleanup(target), .. }
            | End::Drop { unwind: Unwind::Cleanup(target), .. } if !body.blocks[*target].cleanup => {
                return Err(format!("NRE140_CLEANUP_CONTEXT bb{index}"));
            }
            _ => {}
        }
    }
    let mut obligations = vec![open(None, "caller-resource", format!(
        "actual {} argument and data field {} need affine ownership/view and caller frame; no checked-out cache reservation is assumed",
        body.nominal_self, body.data_field))];
    let mut steps = Vec::new();
    for failure in &body.unsupported {
        obligations.push(open(None, "unsupported-effect", failure.clone()));
    }
    let mut queue = VecDeque::from([(0usize, BTreeMap::from([(local_place(body, 1)?, Pending { kind: PendingKind::SelfArgument, loan: None })]))]);
    let mut visited = BTreeSet::new();
    let mut returned = false;
    while let Some((index, mut pending)) = queue.pop_front() {
        if !visited.insert(index) {
            obligations.push(open(None, "cfg-join", format!("bb{index}: join/loop needs a checked affine state merge")));
            continue;
        }
        let block = &body.blocks[index];
        for (statement_index, statement) in block.statements.iter().enumerate() {
            let location = Location { block: index, statement: statement_index };
            apply_loan_ends(body, &location, &mut pending, &mut steps, &mut obligations);
            transfer_statement(body, &location, statement, &mut pending, &mut steps, &mut obligations)?;
        }
        let location = Location { block: index, statement: block.statements.len() };
        apply_loan_ends(body, &location, &mut pending, &mut steps, &mut obligations);
        match &block.end {
            End::Call { api, arguments, destination, normal, unwind } => {
                let input = arguments.first().and_then(source_of).and_then(|place| pending.get(place)).cloned();
                if let Some(loan_index) = input.as_ref().and_then(|value| value.loan) {
                    let loan = body.loans.iter().find(|loan| loan.index == loan_index).ok_or("NRE140_MISSING_ACTIVATION_LOAN")?;
                    if loan.activation != Activation::Immediate && loan.activation != Activation::At(location.clone()) {
                        return Err("NRE140_UNACTIVATED_TWO_PHASE_USE".into());
                    }
                    steps.push(format!("typed call {location:?} consumes pending receiver after actual activation {:?}", loan.activation));
                }
                let candidate = match (&api.primitive, input.as_ref().map(|value| &value.kind)) {
                    (Some(Primitive::ArcDeref), Some(PendingKind::DataArcBorrow)) => Some(PendingKind::DataView),
                    (Some(Primitive::ArcGetMut), Some(PendingKind::DataArcBorrow)) => Some(PendingKind::OptionalUniqueData),
                    (Some(Primitive::OptionUnwrap), Some(PendingKind::OptionalUniqueData)) => Some(PendingKind::DataView),
                    _ => None,
                };
                if api.resolved_hash.is_empty() || api.signature.is_empty() {
                    return Err("NRE140_UNRESOLVED_TYPED_CALL".into());
                }
                let kind = if api.application_body.is_some() { "original-callee-body" } else { "primitive-contract" };
                obligations.push(open(Some(location.clone()), kind, format!(
                    "typed {} [{}] {:?}: normal target {normal:?}, unwind {unwind:?}, error/poison/panic/abort/divergence and partial/frame effects need exact review; candidate resource {candidate:?}; no law installed",
                    api.resolved_instance, api.resolved_hash, api.primitive)));
                obligations.push(open(Some(location.clone()), "required-interface", required_interface(api)));
                if let Some(target) = normal {
                    let result = candidate.map(|kind| Pending { kind, loan: input.as_ref().and_then(|value| value.loan) });
                    transfer_call(&mut pending, arguments, destination, result)?;
                    queue.push_back((*target, pending.clone()));
                }
                if let Unwind::Cleanup(target) = unwind {
                    obligations.push(open(Some(location), "cleanup-affine-frame", format!("bb{target}: call's unwind resource state cannot be guessed from its normal postcondition")));
                    queue.push_back((*target, PendingState::new()));
                }
            }
            End::Goto(target) => queue.push_back((*target, pending)),
            End::FalseEdge { real, imaginary } => {
                steps.push(format!("bb{index}: compiler falseEdge real bb{real}, imaginary bb{imaginary}; retain both, execute only real"));
                queue.push_back((*real, pending));
            }
            End::Switch { operand, targets } => {
                consume_moves(&mut pending, operand);
                obligations.push(open(Some(location), "branch-refinement", "all actual switch successors retained; no Result/Try/Option discriminant fact or path premise is assumed".into()));
                for target in targets { queue.push_back((*target, pending.clone())); }
            }
            End::Drop { place, normal, unwind } => {
                obligations.push(open(Some(location.clone()), "original-drop-body", format!("native drop of {place:?}; normal bb{normal}, unwind {unwind:?}; actual destructor/glue/resource effects and cleanup frame must be checked, not replaced by a primitive")));
                invalidate_place(&mut pending, place);
                queue.push_back((*normal, pending));
                if let Unwind::Cleanup(target) = unwind {
                    obligations.push(open(Some(location), "cleanup-affine-frame", format!("bb{target}: drop's partial effects and unwind resources are unknown; empty pending provenance is not an empty live-resource ledger")));
                    queue.push_back((*target, PendingState::new()));
                }
            }
            End::Return => {
                if pending.get(&local_place(body, 0)?).map(|value| &value.kind) == Some(&PendingKind::DataView) && matches!(body.method.as_str(), "mem" | "mem_mut") {
                    returned = true;
                    steps.push(format!("bb{index}: pending data view reaches actual return place _0; not an admitted/live resource"));
                } else {
                    obligations.push(open(Some(location), "return-resource", "actual return value lacks a derived data-view resource".into()));
                }
            }
            other => obligations.push(open(Some(location), "unsupported-terminator", format!("{other:?}"))),
        }
    }
    obligations.push(open(None, "source-to-vir", "actual rustc Body/loan graph is bound by DefId, not a verifier body occurrence; original nominal VIR body translation and native correspondence remain required".into()));
    obligations.push(open(None, "primitive-disposition", "no independently reviewed exact primitive disposition exists; no requirement can be treated as a precondition, axiom or admitted native fact".into()));
    Ok(ConditionalDerivation { body_hash: body.definition_hash.clone(), method: body.method.clone(), steps,
        obligations, returned_data_view: returned, native_bodies_proved: 0,
        status: "OPEN: conditional original-body resource derivation only".into() })
}

pub fn lower_to_affine(body: &Body) -> Result<affine::Program, String> {
    let derivation = derive(body)?;
    Err(format!("NRE140_OPEN_NATIVE_OBLIGATIONS: {}; existing affine instrument accepts only empty internal fixtures, not this original nominal body; no SST/AIR proof or certificate", derivation.obligations.len()))
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct HeaderConsumer {
    pub header_body: String,
    pub loan_producer_body: String,
    pub page: Place,
    pub mem_mut_site: Location,
    pub copy_site: Location,
    pub normal_drop_site: Location,
    pub cleanup_drop_sites: Vec<Location>,
    pub original_drop_body: String,
    pub original_return_value_body: String,
    pub original_lru_get_mut_body: String,
    pub original_checkout_body: String,
    pub checkout_call_site: Location,
    pub checkout_result: Place,
    pub checkout_construction: Location,
    pub checkout_fields: Vec<(String, Value)>,
    pub checkout_take_sites: Vec<Location>,
    pub obligations: Vec<Obligation>,
    pub status: String,
    pub native_bodies_proved: usize,
}

pub fn consume_original_header(bodies: &[Body]) -> Result<HeaderConsumer, String> {
    let producer = bodies.iter().find(|body| body.method == "mem_mut" && body.data_field != usize::MAX)
        .ok_or("NRE140_ORIGINAL_LOAN_PRODUCER_MISSING")?;
    let derivation = derive(producer)?;
    if !derivation.returned_data_view { return Err("NRE140_NO_PENDING_DATA_VIEW".into()); }
    let header = bodies.iter().find(|body| body.method == "write_header").ok_or("NRE140_ORIGINAL_HEADER_MISSING")?;
    let header_derivation = derive(header)?;
    let destructor = bodies.iter().find(|body| producer.destructor_hash.as_ref() == Some(&body.definition_hash))
        .ok_or("NRE140_NOMINAL_DESTRUCTOR_BODY_MISSING")?;
    let return_value = bodies.iter().find(|body| body.method == "return_value").ok_or("NRE140_RETURN_VALUE_BODY_MISSING")?;
    let lru = bodies.iter().find(|body| body.method == "get_mut" && body.nominal_self != return_value.nominal_self)
        .ok_or("NRE140_LRU_GET_MUT_BODY_MISSING")?;
    let checkout = bodies.iter().find(|body| body.method == "write" && body.nominal_self.ends_with("PagedCachedFile"))
        .ok_or("NRE140_ORIGINAL_CHECKOUT_BODY_MISSING")?;
    let take = bodies.iter().find(|body| body.method == "take_value" && body.nominal_self == return_value.nominal_self)
        .ok_or("NRE140_ORIGINAL_TAKE_BODY_MISSING")?;
    let (checkout_call_site, checkout_result) = header.blocks.iter().enumerate().find_map(|(index, block)| match &block.end {
        End::Call { api, destination, .. } if api.resolved_hash == checkout.definition_hash
            && api.primitive.is_none() && api.application_body.is_some() =>
            Some((Location { block: index, statement: block.statements.len() }, destination.clone())),
        _ => None,
    }).ok_or("NRE140_HEADER_CHECKOUT_TYPED_BODY_LINK_MISSING")?;
    let (checkout_construction, checkout_fields) = checkout.blocks.iter().enumerate().find_map(|(index, block)| {
        block.statements.iter().enumerate().find_map(|(statement, value)| match value {
            Statement::Assign { value: Value::NominalAggregate { definition_hash, typ, fields }, .. }
                if definition_hash == &producer.nominal_self_hash && typ == &producer.nominal_self =>
                Some((Location { block: index, statement }, fields.clone())),
            _ => None,
        })
    }).ok_or("NRE140_CHECKOUT_NOMINAL_PAGE_CONSTRUCTION_MISSING")?;
    if checkout_fields.len() != producer.fields.len()
        || !checkout_fields.iter().zip(&producer.fields).all(|((name, _), (expected, _))| name == expected) {
        return Err("NRE140_CHECKOUT_FIELD_LAYOUT_MISMATCH".into());
    }
    let checkout_take_sites = checkout.blocks.iter().enumerate().filter_map(|(index, block)| match &block.end {
        End::Call { api, .. } if api.resolved_hash == take.definition_hash
            && api.primitive.is_none() && api.application_body.is_some() =>
            Some(Location { block: index, statement: block.statements.len() }),
        _ => None,
    }).collect::<Vec<_>>();
    if checkout_take_sites.is_empty() { return Err("NRE140_CHECKOUT_TAKE_BODY_LINK_MISSING".into()); }
    let mut obligations = derivation.obligations;
    obligations.extend(header_derivation.obligations);
    let return_call = destructor.blocks.iter().find_map(|block| match &block.end {
        End::Call { api, arguments, .. } if api.resolved_hash == return_value.definition_hash
            && api.primitive.is_none() && api.application_body.is_some() => Some(arguments),
        _ => None,
    }).ok_or("NRE140_DROP_RETURN_VALUE_TYPED_BODY_LINK_MISSING")?;
    if return_call.len() != 3 { return Err("NRE140_RETURN_VALUE_ARGUMENTS".into()); }
    let data_argument = source_of(&return_call[2]).ok_or("NRE140_RETURNED_ARC_NOT_NATIVE_PLACE")?;
    let clone_call = destructor.blocks.iter().find_map(|block| match &block.end {
        End::Call { api, destination, .. } if api.primitive == Some(Primitive::ArcClone)
            && destination.local == data_argument.local => Some(api),
        _ => None,
    }).ok_or("NRE140_ORIGINAL_ARC_CLONE_OUTPUT_LINK_MISSING")?;
    if !return_value.blocks.iter().any(|block| matches!(&block.end,
        End::Call { api, .. } if api.resolved_hash == lru.definition_hash && api.primitive.is_none() && api.application_body.is_some())) {
        return Err("NRE140_RETURN_VALUE_LRU_BODY_LINK_MISSING".into());
    }
    let mut selected = None;
    for (index, block) in header.blocks.iter().enumerate() {
        let End::Call { api, arguments, destination, normal: Some(target), .. } = &block.end else { continue };
        if api.resolved_hash != producer.definition_hash || api.primitive.is_some() || api.application_body.is_none() { continue; }
        let site = Location { block: index, statement: block.statements.len() };
        let receiver = arguments.first().and_then(source_of).ok_or("NRE140_HEADER_RECEIVER_NOT_A_PLACE")?;
        let loan = header.loans.iter().find(|loan| loan.assigned.local == receiver.local
            && loan.activation == Activation::At(site.clone())).ok_or("NRE140_HEADER_RECEIVER_ACTIVATION_MISSING")?;
        if loan.borrowed.typ != producer.nominal_self || !loan.borrowed.projection.is_empty() {
            return Err("NRE140_HEADER_PAGE_NOMINAL_PLACE_MISMATCH".into());
        }
        selected = Some((site, loan.borrowed.clone(), destination.clone(), loan.index, *target));
    }
    let (mem_mut_site, page, output_place, origin_loan, mut current) = selected.ok_or("NRE140_HEADER_TYPED_PRODUCER_CALL_MISSING")?;
    let mut pending = BTreeMap::from([(output_place, Pending { kind: PendingKind::DataView, loan: Some(origin_loan) })]);
    let mut transfer_steps = Vec::new();
    let mut visited = BTreeSet::new();
    let mut copy_site = None;
    let mut normal_drop_site = None;
    while visited.insert(current) {
        let block = &header.blocks[current];
        for (statement_index, statement) in block.statements.iter().enumerate() {
            let location = Location { block: current, statement: statement_index };
            apply_loan_ends(header, &location, &mut pending, &mut transfer_steps, &mut obligations);
            transfer_statement(header, &location, statement, &mut pending, &mut transfer_steps, &mut obligations)?;
        }
        let site = Location { block: current, statement: block.statements.len() };
        apply_loan_ends(header, &site, &mut pending, &mut transfer_steps, &mut obligations);
        match &block.end {
            End::Call { api, arguments, destination, normal: Some(target), .. } => {
                if api.primitive == Some(Primitive::SliceCopy) {
                    let receiver = arguments.first().and_then(source_of).ok_or("NRE140_COPY_RECEIVER_MISSING")?;
                    if !pending.contains_key(receiver) { return Err("NRE140_COPY_NOT_FROM_ORIGINAL_MEM_MUT".into()); }
                    if !header.loans.iter().any(|loan| loan.assigned.local == receiver.local && loan.activation == Activation::At(site.clone())) {
                        return Err("NRE140_COPY_ACTIVATION_MISSING".into());
                    }
                    copy_site = Some(site.clone());
                }
                transfer_call(&mut pending, arguments, destination, None)?;
                obligations.push(open(Some(site), "header-callee-effect", required_interface(api)));
                current = *target;
            }
            End::Goto(target) => current = *target,
            End::Drop { place: dropped, .. } if *dropped == page && copy_site.is_some() => {
                invalidate_place(&mut pending, dropped);
                normal_drop_site = Some(site);
                break;
            }
            _ => return Err("NRE140_UNSUPPORTED_HEADER_CONSUMER_PATH".into()),
        }
    }
    let copy_site = copy_site.ok_or("NRE140_ORIGINAL_COPY_CONSUMER_MISSING")?;
    let normal_drop_site = normal_drop_site.ok_or("NRE140_ORIGINAL_NORMAL_DROP_MISSING")?;
    let cleanup_drop_sites = header.blocks.iter().enumerate().filter_map(|(index, block)| {
        if block.cleanup && matches!(&block.end, End::Drop { place: dropped, .. } if *dropped == page) {
            Some(Location { block: index, statement: block.statements.len() })
        } else { None }
    }).collect::<Vec<_>>();
    if cleanup_drop_sites.is_empty() { return Err("NRE140_ORIGINAL_CLEANUP_DROP_MISSING".into()); }
    for site in [&mem_mut_site, &copy_site] {
        let End::Call { unwind: Unwind::Cleanup(entry), .. } = &header.blocks[site.block].end else {
            return Err("NRE140_HEADER_CONSUMER_CLEANUP_EDGE_MISSING".into());
        };
        let mut queue = VecDeque::from([(*entry, PendingState::new())]);
        let mut visited = BTreeSet::new();
        let mut matched = false;
        while let Some((index, mut cleanup_pending)) = queue.pop_front() {
            if !visited.insert(index) { continue; }
            let block = &header.blocks[index];
            if !block.cleanup { return Err("NRE140_HEADER_UNWIND_LEFT_CLEANUP".into()); }
            for (statement_index, statement) in block.statements.iter().enumerate() {
                let location = Location { block: index, statement: statement_index };
                apply_loan_ends(header, &location, &mut cleanup_pending, &mut transfer_steps, &mut obligations);
                transfer_statement(header, &location, statement, &mut cleanup_pending, &mut transfer_steps, &mut obligations)?;
            }
            let location = Location { block: index, statement: block.statements.len() };
            apply_loan_ends(header, &location, &mut cleanup_pending, &mut transfer_steps, &mut obligations);
            if matches!(&block.end, End::Drop { place: dropped, .. } if *dropped == page) {
                matched = true;
                break;
            }
            obligations.push(open(Some(location), "cleanup-occurrence-state", "cleanup effects and resource/frame writeback remain unchecked; empty pending provenance grants no authority".into()));
            queue.extend(successors(&block.end).into_iter().map(|target| (target, PendingState::new())));
        }
        if !matched { return Err("NRE140_HEADER_UNWIND_PAGE_DROP_NOT_REACHABLE".into()); }
    }
    obligations.push(open(Some(checkout_construction.clone()), "original-checkout", format!("actual original {} constructs the exact nominal page from {checkout_fields:?}, with original take_value sites {checkout_take_sites:?}; prove every branch, data/offset/buffer relation, lock/guard effects, unique Arc eligibility and the cache's None reservation across unlock. These syntactic bindings confer NO authority", checkout.definition)));
    obligations.push(open(Some(checkout_call_site.clone()), "checkout-result-to-page", format!("actual header write result {checkout_result:?} must be related through original Try/Result extraction to page {page:?}; no return-path equality, successful checkout, reservation or affine multi-resource ledger is established")));
    obligations.push(open(Some(copy_site.clone()), "original-copy-bytes", "prove original to_bytes(true), unsize coercion, actual slice source bytes and copy preconditions; the conditional view alone does not prove any byte update".into()));
    obligations.push(open(None, "original-drop-cache-return", format!("{} output place {:?} reaches original return_value argument; Arc clone, Mutex/poison/guard effects and resource frame remain OPEN; no native application helper is a primitive", clone_call.resolved_instance, data_argument)));
    obligations.push(open(None, "original-cache-map", "prove original LRUCache::get_mut HashMap/BuildHasherDefault/FastHasher64 and AtomicBool second-chance effect; no hasher totality, mutable writeback law or map-slot correspondence is assumed".into()));
    Ok(HeaderConsumer { header_body: header.definition_hash.clone(), loan_producer_body: producer.definition_hash.clone(), page,
        mem_mut_site, copy_site, normal_drop_site, cleanup_drop_sites, original_drop_body: destructor.definition_hash.clone(),
        original_return_value_body: return_value.definition_hash.clone(), original_lru_get_mut_body: lru.definition_hash.clone(),
        original_checkout_body: checkout.definition_hash.clone(), checkout_call_site, checkout_result,
        checkout_construction, checkout_fields, checkout_take_sites,
        obligations, status: "OPEN: original conditional producer consumed by actual header-copy/drop/cache-return path; not a resource proof, native certificate or Scope-edge join".into(), native_bodies_proved: 0 })
}

pub fn header_semantic_negatives(bodies: &[Body]) -> Result<Vec<String>, String> {
    let original = consume_original_header(bodies)?;
    let mut results = Vec::new();
    let mut changed = bodies.to_vec();
    let header = changed.iter_mut().find(|body| body.definition_hash == original.header_body).ok_or("missing header")?;
    if let End::Call { api, .. } = &mut header.blocks[original.mem_mut_site.block].end {
        api.resolved_hash.push_str("-wrong-native-instance");
    }
    let failure = consume_original_header(&changed).err().ok_or("wrong native callee was accepted")?;
    if failure != "NRE140_HEADER_TYPED_PRODUCER_CALL_MISSING" { return Err(failure); }
    results.push(format!("same method name, wrong typed callee rejected: {failure}"));
    let mut changed = bodies.to_vec();
    let header = changed.iter_mut().find(|body| body.definition_hash == original.header_body).unwrap();
    if let End::Call { arguments, .. } = &mut header.blocks[original.copy_site.block].end {
        if let Value::Move(place) | Value::Copy(place) = &mut arguments[0] { place.local = original.page.local; }
    }
    let failure = consume_original_header(&changed).err().ok_or("wrong copied resource was accepted")?;
    if failure != "NRE140_COPY_NOT_FROM_ORIGINAL_MEM_MUT" { return Err(failure); }
    results.push(format!("copy receiver resource substitution rejected: {failure}"));
    let mut changed = bodies.to_vec();
    let producer = changed.iter_mut().find(|body| body.definition_hash == original.loan_producer_body).unwrap();
    producer.destructor_hash = Some("wrong-native-destructor".into());
    let failure = consume_original_header(&changed).err().ok_or("name-only destructor fallback was accepted")?;
    if failure != "NRE140_NOMINAL_DESTRUCTOR_BODY_MISSING" { return Err(failure); }
    results.push(format!("nominal destructor identity substitution rejected: {failure}"));
    let restored = consume_original_header(bodies)?;
    if serde_json::to_vec(&restored).unwrap() != serde_json::to_vec(&original).unwrap() {
        return Err("NRE140_HEADER_RESTORATION_DIFFERS".into());
    }
    results.push("restored original graph returns exactly the same OPEN header resource consumer; no native proof".into());
    Ok(results)
}

pub fn semantic_negatives(body: &Body) -> Result<Vec<String>, String> {
    let original = derive(body)?;
    let mut results = Vec::new();
    let mut changed = body.clone();
    let mut changed_edge = false;
    for block in &mut changed.blocks {
        if let End::Call { normal: Some(_), .. } = &block.end {
            if let End::Call { normal, .. } = &mut block.end { *normal = None; }
            changed_edge = true;
            break;
        }
    }
    if changed_edge {
        let failure = derive(&changed).err().ok_or("lost normal successor was accepted")?;
        if !failure.starts_with("NRE140_SUCCESSOR_LOSS") { return Err(failure); }
        results.push(format!("normal-successor removal rejected: {failure}"));
    }
    let mut changed = body.clone();
    let mut cleanup_changed = false;
    for block in &mut changed.blocks {
        if let End::Call { unwind: Unwind::Cleanup(_), .. } = &block.end {
            if let End::Call { unwind, .. } = &mut block.end { *unwind = Unwind::Continue; }
            cleanup_changed = true;
            break;
        }
    }
    if cleanup_changed {
        let failure = derive(&changed).err().ok_or("lost cleanup successor was accepted")?;
        if !failure.starts_with("NRE140_SUCCESSOR_LOSS") { return Err(failure); }
        results.push(format!("cleanup-successor removal rejected: {failure}"));
    }
    let mut changed = body.clone();
    for block in &mut changed.blocks {
        if let End::Call { api, .. } = &mut block.end {
            if matches!(api.primitive, Some(Primitive::ArcDeref | Primitive::ArcGetMut)) {
                api.primitive = None;
                break;
            }
        }
    }
    if original.returned_data_view && derive(&changed)?.returned_data_view {
        return Err("unsupported Arc primitive still produced a data view".into());
    }
    results.push("removing the typed Arc primitive slot prevents conditional data-view derivation".into());
    let mut changed = body.clone();
    if let Some(loan) = changed.loans.first_mut() {
        loan.borrowed.local += 1;
        let failure = derive(&changed).err().ok_or("wrong loan origin was accepted")?;
        if failure != "NRE140_LOAN_ORIGIN_MISMATCH" { return Err(failure); }
        results.push(format!("loan-origin mutation rejected: {failure}"));
    }
    let mut changed = body.clone();
    if let Some(loan) = changed.loans.iter_mut().find(|loan| matches!(loan.activation, Activation::At(_))) {
        loan.activation = Activation::Reserved;
        let failure = derive(&changed).err().ok_or("unactivated two-phase receiver was accepted")?;
        if failure != "NRE140_UNACTIVATED_TWO_PHASE_USE" { return Err(failure); }
        results.push(format!("two-phase activation removal rejected: {failure}"));
    }
    let restored = derive(body)?;
    if restored.steps != original.steps || restored.obligations.len() != original.obligations.len() {
        return Err("restoration differs".into());
    }
    if lower_to_affine(body).is_ok() { return Err("OPEN graph entered affine lowering".into()); }
    results.push("restored original graph yields the same OPEN derivation; affine lowering refuses".into());
    Ok(results)
}

#[cfg(test)]
mod transfer_regressions {
    use super::*;

    fn place(local: usize) -> Place {
        Place { local, projection: Vec::new(), typ: "T".into() }
    }

    fn view(loan: Option<usize>) -> Pending {
        Pending { kind: PendingKind::DataView, loan }
    }

    fn fixture() -> Body {
        Body {
            definition: "synthetic_transfer_fixture".into(),
            definition_hash: "synthetic-only".into(),
            nominal_self: "Fixture".into(),
            nominal_self_hash: "synthetic-only".into(),
            source_file: "synthetic_transfer_fixture.rs".into(),
            source_sha256: "0".repeat(64),
            source_body: "synthetic transfer fixture, not an original native body".into(),
            mir_phase: "synthetic-only".into(),
            method: "mem".into(),
            data_field: 0,
            fields: Vec::new(),
            destructor_hash: None,
            return_type: "T".into(),
            locals: vec!["T".into(); 5],
            loans: Vec::new(),
            blocks: vec![Block {
                cleanup: false,
                original_statements: Vec::new(),
                original_terminator: "synthetic Return".into(),
                statements: Vec::new(),
                end: End::Return,
                compiler_successors: Vec::new(),
            }],
            unsupported: Vec::new(),
        }
    }

    fn assign(pending: &mut PendingState, destination: Place, value: Value) {
        transfer_statement(
            &fixture(),
            &Location { block: 0, statement: 0 },
            &Statement::Assign { destination, value },
            pending,
            &mut Vec::new(),
            &mut Vec::new(),
        ).unwrap();
    }

    #[test]
    fn untracked_assignment_invalidates_old_return_provenance() {
        for value in [Value::Copy(place(3)), Value::Move(place(3)), Value::Constant("unknown".into())] {
            let mut pending = BTreeMap::from([(place(0), view(None))]);
            assign(&mut pending, place(0), value);
            assert!(!pending.contains_key(&place(0)));
        }
    }

    #[test]
    fn projected_source_does_not_reuse_base_provenance() {
        let mut source = place(2);
        source.projection.push("Deref".into());
        let mut pending = BTreeMap::from([(place(0), view(None)), (place(2), view(None))]);
        assign(&mut pending, place(0), Value::Copy(source));
        assert!(!pending.contains_key(&place(0)));
        assert!(pending.contains_key(&place(2)));
    }

    #[test]
    fn call_receiver_lookup_requires_full_place_and_type() {
        let pending = BTreeMap::from([(place(2), view(None))]);
        let mut projected = place(2);
        projected.projection.push("Deref".into());
        let mut different_type = place(2);
        different_type.typ = "different".into();
        assert!(pending.get(&projected).is_none());
        assert!(pending.get(&different_type).is_none());
    }

    #[test]
    fn unrelated_call_consumes_moves_and_overwrites_destination() {
        let mut pending = BTreeMap::from([
            (place(0), view(None)), (place(2), view(None)), (place(4), view(None)),
        ]);
        transfer_call(&mut pending, &[Value::Move(place(2)), Value::Copy(place(4))], &place(0), None).unwrap();
        assert!(!pending.contains_key(&place(0)));
        assert!(!pending.contains_key(&place(2)));
        assert!(pending.contains_key(&place(4)));
    }

    #[test]
    fn projected_destination_invalidates_overlapping_base() {
        let mut destination = place(0);
        destination.projection.push("Deref".into());
        let mut pending = BTreeMap::from([(place(0), view(None)), (place(2), view(None))]);
        assign(&mut pending, destination, Value::Copy(place(2)));
        assert!(!pending.contains_key(&place(0)));
    }

    #[test]
    fn aggregate_moves_consume_sources_without_recognized_output() {
        let mut pending = BTreeMap::from([(place(0), view(None)), (place(2), view(None))]);
        assign(&mut pending, place(0), Value::NominalAggregate {
            definition_hash: "synthetic-only".into(), typ: "T".into(),
            fields: vec![("field".into(), Value::Move(place(2)))],
        });
        assert!(pending.is_empty());
    }

    #[test]
    fn storage_live_does_not_revive_old_provenance() {
        let mut pending = BTreeMap::from([(place(0), view(None))]);
        transfer_statement(
            &fixture(), &Location { block: 0, statement: 0 },
            &Statement::Storage { local: 0, live: true },
            &mut pending, &mut Vec::new(), &mut Vec::new(),
        ).unwrap();
        assert!(pending.is_empty());
    }

    #[test]
    fn unknown_statement_cannot_leave_pending_authority() {
        let mut pending = BTreeMap::from([(place(0), view(None))]);
        transfer_statement(
            &fixture(), &Location { block: 0, statement: 0 },
            &Statement::Unsupported("unknown write".into()),
            &mut pending, &mut Vec::new(), &mut Vec::new(),
        ).unwrap();
        assert!(pending.is_empty());
    }

    #[test]
    fn call_result_origin_expires_at_loan_end() {
        let location = Location { block: 0, statement: 0 };
        let mut body = fixture();
        body.loans.push(Loan {
            index: 7, reservation: location.clone(), activation: Activation::Immediate,
            kind: "synthetic-only".into(), region: "synthetic-only".into(),
            borrowed: place(1), assigned: place(2), ends: vec![location.clone()],
        });
        let mut pending = BTreeMap::from([(place(2), view(Some(7)))]);
        let result = pending.get(&place(2)).cloned();
        transfer_call(&mut pending, &[Value::Move(place(2))], &place(0), result).unwrap();
        assert_eq!(pending.get(&place(0)).unwrap().loan, Some(7));
        let mut obligations = Vec::new();
        apply_loan_ends(&body, &location, &mut pending, &mut Vec::new(), &mut obligations);
        assert!(pending.is_empty());
        assert_eq!(obligations.len(), 1);
        assert_eq!(obligations[0].kind, "loan-end-writeback");
        assert_eq!(obligations[0].disposition, "OPEN; not adopted or assumed");
    }

    #[test]
    fn empty_cleanup_terminator_records_actual_end_obligations() {
        let location = Location { block: 0, statement: 0 };
        let mut body = fixture();
        body.blocks[0].cleanup = true;
        body.loans.push(Loan {
            index: 7, reservation: location.clone(), activation: Activation::Immediate,
            kind: "synthetic-only".into(), region: "synthetic-only".into(),
            borrowed: place(1), assigned: place(2), ends: vec![location.clone()],
        });
        let derivation = derive(&body).unwrap();
        assert!(derivation.obligations.iter().any(|obligation|
            obligation.kind == "loan-end-writeback" && obligation.location.as_ref() == Some(&location)));
        assert_eq!(derivation.native_bodies_proved, 0);
        assert!(lower_to_affine(&body).is_err());
    }
}
