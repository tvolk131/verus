# Parent repair145 for source findings R144-1 and R144-2

SOURCE-ONLY STAGED REPAIR; UNBUILT AND UNTESTED. NOT ADOPTED.
All18 OPEN; original native/resource/trust/proof credit added:0/0/0/0.

## Scope and immutable baseline

This parent-authored delta repairs the small transfer/scheduling findings from
review144 without starting another delegate. It is relative ONLY to
implementation140's candidate/source/vir/src/native_resource/native.rs,
SHA25685ef1774e8d2790a91d08801479b736217b86d9179f5242ff9fab3f1d74ed7cd.
That baseline and the original native sources remain unchanged. Do not apply
this patch blindly over implementation143's evolving code. Port the underlying
invalidation/scheduling rules into its actual compiler-owned occurrence lowerer
where necessary; it may already have different, stronger representations.

Review144 root is /private/tmp/review144-20261108-zvUvswJB. Parent authenticated
its thirteen sealed payloads at2026-11-08T20:10:30.935175UTC after reading the
findings; no earlier parent custody is invented. Its SEAL.json digest is
0c2a23fc004f3e48049f9260dca95cc868dd75e30a299729a9560302b8547cd3.

## Staged changes

- Pending syntactic provenance is keyed by complete Place, including projection
  and recorded type, rather than by local number alone. Call operands use exact
  full-place lookup. Only explicitly supported dereference/reborrow transport
  can project an existing reference; unknown projections do not inherit it.
- Assignment computes a potential source before the destructive write, consumes
  moved inputs including aggregate fields, invalidates overlapping destinations
  even when the source is unknown, and does not reissue unknown provenance.
  Unknown statements clear pending state. Both StorageLive and StorageDead
  invalidate the reused local. Call destinations are overwritten independently
  of whether a primitive result is recognized.
- Candidate call results retain their pending origin loan instead of replacing
  it with None. This is conservative dependency retention, NOT a checked native
  returned-loan issuance rule. Expiration may now refuse paths previously
  labelled as pending data views; no compatibility result is assumed.
- One apply_loan_ends transfer runs before every statement and every terminator,
  including empty cleanup blocks. Each actual endpoint creates an explicit OPEN
  writeback/receiver-resumption/frame obligation. Invalidation or a step string
  does not prove that obligation. Cleanup traversal with unknown pending state
  is not an assertion that no live affine resources exist.
- The header consumer uses the same full-place statement/call/end transfers,
  retains header derivation obligations and visits cleanup endpoints before
  accepting syntactic page-drop reachability. Its status remains conditional;
  it is not native memory, byte-copy or cleanup resource proof.

Ten synthetic Rust regression tests are authored in transfer_regressions.
They target unknown overwrites, projected operands, unrelated call destinations,
aggregate moves, reused storage, unknown statements, origin expiration and empty
cleanup terminators. NONE HAS RUN. They are helper tests, not original-body
verification or evidence of compiler correspondence. There is no successful
build, test, native run, solver result or independent repair acceptance here.

## Required use and remaining boundary

Implementation143 owns the exclusive compiler/build/verifier slot. Parent ran
no compiler, formatter, Cargo, tests, verifier or native application to prepare
this delta. Validation or incorporation, if useful, must fit143's existing
budget; this does not reset or extend it. Its actual original-body ledger,
typed occurrence binding, returned-loan lifetime and byte writeback remain the
priority, not rebuilding the producer solely to obtain another diagnostic.

The representation here still includes serialized/debug string identity and
pending provenance. It is not an authoritative compiler capability, a global
affine ledger, native incoming checkout authority, legal atomic execution,
owned frame, primitive-law disposition or accepted source-to-VIR correspondence.
Unconditional native lowering refusal, zero-native-body accounting and all
admission/export barriers remain intact. Candidate141 stays rejected.

Before closing either review finding, validate the actual port and new helper
regressions, retain any failures, and check original empty cleanup/endpoints.
Do not report this unbuilt parent patch as independent closure or cell progress.
No parent/native integration, law adoption, network, Git writes, destructive
cleanup, original native application execution or new delegation occurred.
