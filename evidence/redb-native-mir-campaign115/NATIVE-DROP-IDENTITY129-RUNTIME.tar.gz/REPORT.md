# Task129 sealed diagnostic runtime report

All seven registered observer exit expectations matched. Independent semantic validation: 61 checks, 0 failed.
Nine attempts charged: two setup-only failures plus seven standalone observer commands. No allowance reset or builds.

| Registered case | Actual exit | Expected exit | Seconds |
|---|---:|---:|---:|
| old_five_pair_mode | 2 | 2 | 1.936 |
| exact_header_identity | 2 | 2 | 1.521 |
| wrong_qualified_target | 65 | 65 | 1.013 |
| seeded_sidecar | 64 | 64 | 0.032 |
| aliased_report_and_raw | 64 | 64 | 0.033 |
| raw_publication_permission_failure | 70 | 70 | 0.996 |
| extra_link_argument | 64 | 64 | 0.033 |

## Actual identity result

One resolver invocation returned an actual nonempty `Shim(DropGlue(core::ptr::drop_glue, Some(WritablePage)))`
instance with complete requested/returned arguments `[tree_store::page_store::cached_file::WritablePage]`.
The independently recorded destructor is the distinct local
`<tree_store::page_store::cached_file::WritablePage as std::ops::Drop>::drop`,
`cached_file.rs:41`, with the implementation at line 40 and exact Self-type equality observed.
Complete raw bytes and UTF8 length match the started receipt; typed owner/ADT tokens match all snapshots.
The one identity result remains attached to DISTINCT bb16/noncleanup and bb19/cleanup contexts, not merged events.
Both raw e78 temporary observations retain `scope=None` and zero exact Scope.value_expression=e78 edges; no HirId join.

Compiler run returned without panic, separately from callback error state: emitted_errors=false and
errors_or_delayed_bugs=false at the observed callback snapshots. Those snapshots remain PENDING.
`NO_LIVE_TCX_AFTER_RETURN_ERROR_FINALITY_NOT_ASSERTED` is retained; neither PENDING nor clean callback samples
establish a completed proof, final absence of delayed compiler errors, dynamic event uniqueness, or resource ownership.

## Controls and limits

The fresh owned canonical mode-0555 raw-only directory genuinely failed publication with EACCES/IO_FAILURE,
exit 70, resolver0 and no started file; explicit query refusal survives in sidecar/report.
Seed bytes remain intact. Wrong qualified owner exits 65 with raw/refusal but resolver0/no start.
Aliased paths, seeded sidecar, and the extra link argument refuse before compiler callback by reviewed source control flow.
No helper-controls, original redb application, codegen, link, shim-body, or optimized-MIR request ran.
No source/candidate/parent edits, Git, network commands, cleanup, or delegation occurred.
Original setup traceback and shell expansion error are preserved and conservatively charged; no hidden retry.
All raw stdout/stderr, effective environments, complete argv, wait4 statuses, rusage, external epoch-ns probes,
source/receipt bundle, and entry/exit authentication are retained.

All 132 build-manifest payloads, 4903 historical122 records, 54 tested source records, 15 review126 payloads,
and explicit pins authenticate at current entry and exit. This is current endpoint equality, not historical
continuous custody. Actual dyld-selected observer/rustc_driver/LLVM paths and hashes match entry identities.
OS shared-cache image UUIDs/paths are observed, not independently content-hashed standalone files.
Files first seen together do not acquire an invented strict temporal ordering.
The slot is explicitly released; all seven owned children are wait4-reaped and all owned process groups absent.

Genuine resolver Err/panic/fatal-after-start controls remain UNVALIDATED because not naturally observed.
Strict oracle115 verdict: NOT REQUESTED/NOT GRANTED. Approved native/HIR/VIR mapping: NONE.
All18 remain OPEN; native/resource/trust/proof credits are all 0.

## Smallest semantic next cut (not an automatic followup)

Read-only correspondence review of the already identified `WritablePage::drop -> LRUWriteCache::return_value`
obligation, keeping bb16 and bb19 separate and the missing e78 Scope edge unresolved. Identity evidence alone
does not supply a resource contract, linearity/ownership, or a HIR/VIR mapping; no new compiler query is authorized.
