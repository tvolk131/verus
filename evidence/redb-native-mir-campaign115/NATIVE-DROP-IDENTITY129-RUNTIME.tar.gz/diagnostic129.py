import hashlib
import io
import json
import os
from pathlib import Path
import re
import resource
import shutil
import stat
import subprocess
import sys
import tarfile
import time

ROOT = Path(__file__).resolve().parent
BUILD = Path('/private/tmp/redb-build127-20261108TZZvZKo')
PARENT = Path('/Users/tommyvolk/.t3/worktrees/verus/t3-60978068/evidence/redb-native-mir-campaign115')
REVIEW = Path('/private/tmp/candidate123-independent-review-20261108T1810-L5OBoz')
SOURCE = Path('/private/tmp/redb-original-crate-preflight115/redb/src/lib.rs')
LIBC = Path('/private/tmp/redb-native-mir-observer116-20261108T164457Z/target-libc-audited/debug/deps/liblibc-3b1090a6c1c370ea.rmeta')
SYSROOT = Path('/Users/tommyvolk/.rustup/toolchains/1.99.1-aarch64-apple-darwin')
OBSERVER = BUILD / 'target/debug/redb-native-mir-observer'
OWNER = 'tree_store::page_store::page_manager::TransactionalMemory::write_header'
START_NS = 1794162826000000000
DEADLINE_NS = START_NS + 17 * 60 * 1000000000
LIMIT = 128 * 1024 * 1024
PINS = {
    str(PARENT / 'DROP-IDENTITY129-PREEXECUTION-EXPECTATIONS.json'): 'a03ceb48ef65602b275e4cb1c0dc0472e0dee28115d8381c76e8ac3d13b58d9a',
    str(PARENT / 'DROP-IDENTITY127-SOURCE-DISPOSITION.json'): '90d84b8d6ea0021a31972b4bb6a6c28006c6a38cd741af8c3ba054c13309d463',
    str(BUILD / 'SEALED-MANIFEST.json'): 'fea7aad3aa234696df44dcae52a081eba8384b0e9d07374df67f7036d9115a31',
    str(REVIEW / 'MANIFEST.sha256'): '2890e04af62bde2f494c4e5b613882f3829651745ec62c03aefcf1aec2d6b1e2',
    str(OBSERVER): 'ac2862745c6fa41943c56658bb626bfdd0797ee5ffb1e213ca2a6649b8545942',
    str(LIBC): '964becb973a8749cc06fa4c95e0916fd6755b5ee282547950f4fa3d2c936327c',
    str(BUILD / 'stage/observer/src/main.rs'): 'b03b2bc43440a36bd87280d8f38139fe8f4ec71f05f6f126e6d1840a4f9c7830',
    str(BUILD / 'stage/observer/src/identity.rs'): '5c10ee69f54eca70073ae1109c63585599c5ab44fbd0ad4e8fed5ef847b4a8c2',
    str(BUILD / 'stage/source/rustc_mir_build/src/builder/checked_drop_origins.rs'): '1aa55b6d95997e1950cc548119ae6b9b83ff3c69af98c36f0790cff895c0ca79',
    '/usr/bin/python3': 'b8763cf250e607a778bb4603cecb5b90338814d0a3dfcba0d57b1de242f610e9',
    '/Library/Developer/CommandLineTools/usr/bin/python3': 'bdea59019a38eb6600cc9e71e984a97fedadc406448431281e7657030f54987e',
}


def read(path):
    return json.loads(Path(path).read_text())


def write(path, value):
    path = ROOT / path
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x') as output:
        json.dump(value, output, indent=2, sort_keys=True)
        output.write('\n')
        output.flush()
        os.fsync(output.fileno())


def identity(path):
    path = Path(path)
    before = time.time_ns()
    metadata = path.stat()
    if not stat.S_ISREG(metadata.st_mode):
        raise RuntimeError('not a regular file: ' + str(path))
    digest = hashlib.sha256()
    with path.open('rb') as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b''):
            digest.update(chunk)
    after = path.stat()
    return {'path': str(path), 'realpath': str(path.resolve()), 'sha256': digest.hexdigest(),
            'bytes': metadata.st_size, 'mtime_ns': metadata.st_mtime_ns,
            'observation_before_epoch_ns': before, 'observation_after_epoch_ns': time.time_ns(),
            'stable_stat_during_read': (metadata.st_ino, metadata.st_size, metadata.st_mtime_ns) ==
                                      (after.st_ino, after.st_size, after.st_mtime_ns)}


def guard():
    logical = allocated = 0
    for directory, directories, files in os.walk(ROOT):
        for name in files:
            metadata = (Path(directory) / name).lstat()
            logical += metadata.st_size
            allocated += metadata.st_blocks * 512
    sample = {'epoch_ns': time.time_ns(), 'free_bytes': shutil.disk_usage(ROOT).free,
              'scratch_logical_bytes': logical, 'scratch_allocated_bytes': allocated}
    with (ROOT / 'resource-samples.jsonl').open('a') as output:
        output.write(json.dumps(sample, sort_keys=True) + '\n')
    if sample['free_bytes'] <= 16 * 1024**3 or max(logical, allocated) > LIMIT:
        raise RuntimeError('resource boundary violated: ' + json.dumps(sample))
    if sample['epoch_ns'] >= DEADLINE_NS:
        raise RuntimeError('task deadline reached')
    return sample


def authenticate(records):
    results = []
    for index, record in enumerate(records):
        try:
            result = identity(record['path'])
            expected = record.get('expected_sha256') or record['sha256']
            result['expected_sha256'] = expected
            result['matches'] = result['sha256'] == expected and result['stable_stat_during_read']
            if record.get('bytes') is not None:
                result['matches'] = result['matches'] and result['bytes'] == record['bytes']
        except Exception as error:
            result = {'path': record['path'], 'matches': False, 'error': repr(error)}
        results.append(result)
        if index % 200 == 0:
            guard()
    return results


def python_inputs():
    paths = {str(Path(sys.executable).resolve()), '/usr/bin/python3', str(Path(__file__).resolve())}
    for module in list(sys.modules.values()):
        value = getattr(module, '__file__', None)
        if value and Path(value).is_file():
            paths.add(str(Path(value).resolve()))
            if value.endswith('.pyc') and Path(value[:-1]).is_file():
                paths.add(str(Path(value[:-1]).resolve()))
    framework = Path('/Library/Developer/CommandLineTools/Library/Frameworks/Python3.framework/Versions/3.9/Python3')
    if framework.is_file():
        paths.add(str(framework))
    return [identity(path) for path in sorted(paths)]


def all_inputs():
    historical = read(BUILD / 'inputs/122-ENTRY-AUTHENTICATION.json')['records']
    sealed = read(BUILD / 'SEALED-MANIFEST.json')['records']
    sources = read(BUILD / 'TESTED-SOURCE-IDENTITY.json')['records']
    review = []
    for line in (REVIEW / 'MANIFEST.sha256').read_text().splitlines():
        digest, name = line.split('  ', 1)
        review.append({'path': str(REVIEW / name), 'sha256': digest})
    return {'explicit_pins': [{'path': path, 'sha256': digest} for path, digest in PINS.items()],
            'sealed_build127_payloads': sealed, 'historical122_records': historical,
            'tested_source_records': sources, 'review126_payloads': review}


def auth_phase(phase):
    started = time.time_ns()
    groups = {name: authenticate(records) for name, records in all_inputs().items()}
    value = {'before_epoch_ns': started, 'after_epoch_ns': time.time_ns(), 'groups': groups,
             'historical_custody': 'CURRENT_ENDPOINT_EQUALITY_ONLY_NOT_HISTORICAL_CONTINUOUS_CUSTODY',
             'python_inputs': python_inputs(), 'resource': guard()}
    write(phase + '-AUTHENTICATION.json', value)
    failures = [item for group in groups.values() for item in group if not item['matches']]
    print(phase, {name: len(group) for name, group in groups.items()}, 'mismatches', len(failures), flush=True)
    if failures:
        raise RuntimeError('authentication failed; no further observer command authorized')


def prepare():
    for name in ['home', 'tmp', 'bin', 'cases', 'bundle']:
        (ROOT / name).mkdir()
    write('COMPILER-SLOT-ACQUIRED.json', {'epoch_ns': time.time_ns(), 'task': 129,
          'authority': 'user sole diagnostic slot; build127 explicitly released and reaped',
          'scope': 'ONLY_PINNED_STANDALONE_METADATA_OBSERVER', 'task_start_epoch_ns': START_NS,
          'deadline_epoch_ns': DEADLINE_NS, 'no_build_allowances': True})
    failures = [
        {'attempt': 1, 'kind': 'SETUP_ONLY_NO_OBSERVER', 'status': 'SHELL_EXPANSION_FAILURE',
         'raw': 'zsh:1: no matches found: /private/tmp/redb-build127-20261108TZZvZKo/stage/source/rustc_mir_build/src/verus*.rs\n',
         'boundary': 'before scratch creation; enclosing shell final command returned 0', 'preservation': 'verbatim tool error copied; not a fabricated rerun'},
        {'attempt': 2, 'kind': 'SETUP_ONLY_NO_OBSERVER', 'status': 1,
         'raw': 'Traceback (most recent call last):\n  File "<string>", line 1, in <module>\nKeyError: \'files\'\n',
         'boundary': 'before scratch creation', 'preservation': 'verbatim tool traceback copied; original stdout retained in conversation'},
    ]
    write('SETUP-FAILURES.json', failures)
    for item in failures:
        (ROOT / ('setup-attempt' + str(item['attempt']) + '.stderr.raw')).write_text(item['raw'])
    auth_phase('ENTRY')
    recipe = read(BUILD / 'inputs/122-plans-build1.json')['environment']
    environment = {key: recipe[key] for key in ['DYLD_LIBRARY_PATH', 'RUSTC', 'RUSTC_BOOTSTRAP', 'RUST_MIN_STACK', 'LANG', 'LC_ALL', 'TZ']}
    environment.update({'PATH': str(ROOT / 'bin'), 'HOME': str(ROOT / 'home'), 'TMPDIR': str(ROOT / 'tmp'),
                        'DYLD_PRINT_LIBRARIES': '1'})
    write('ENVIRONMENT.json', {'observer_environment': environment, 'harness_environment': dict(os.environ),
          'harness_argv': sys.argv, 'python_version': sys.version, 'python_inputs': python_inputs(),
          'recipe': str(BUILD / 'inputs/122-plans-build1.json'),
          'changes': 'scratch-only PATH HOME TMPDIR; omit build-only Cargo/RUSTFLAGS/RUSTDOC; add read-only DYLD_PRINT_LIBRARIES tracing'})
    source_paths = [Path(item['path']) for item in read(BUILD / 'TESTED-SOURCE-IDENTITY.json')['records']]
    source_paths += list(SOURCE.parent.rglob('*.rs'))
    receipt_paths = [BUILD / name for name in ['SEALED-MANIFEST.json', 'BUILD-BINDING.json', 'TESTED-SOURCE-IDENTITY.json',
                     'DEPFILE-INDEX.json', 'USED-DEPFILE-INPUTS.json', 'CORRECTION-BINDING.json', 'CORRECTION.md',
                     'compiler-required-correction.patch', 'FINAL-SOURCE-DELTA-VALIDATION.json', 'COMPILER-SLOT-RELEASED.json',
                     'inputs/122-plans-build1.json', 'inputs/123-MANIFEST.json']]
    receipt_paths += [PARENT / 'DROP-IDENTITY129-PREEXECUTION-EXPECTATIONS.json', PARENT / 'DROP-IDENTITY127-SOURCE-DISPOSITION.json', REVIEW / 'MANIFEST.sha256']
    receipt_paths += [path for path in (BUILD / 'records').rglob('*') if path.is_file()]
    receipt_paths += [path for path in (BUILD / 'depfiles').rglob('*') if path.is_file()]
    copied = []
    for source in sorted(set(source_paths + receipt_paths)):
        destination = ROOT / 'bundle' / str(source).lstrip('/')
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, destination)
        copied.append({'source': str(source), 'copy': str(destination.relative_to(ROOT)), 'identity': identity(destination)})
    write('SOURCE-AND-RECEIPT-BUNDLE.json', copied)
    write('SOURCE-READ-AND-PROFILE.json', {'epoch_ns': time.time_ns(),
          'actual_source_read': [str(BUILD / 'stage/observer/src/main.rs'), str(BUILD / 'stage/observer/src/identity.rs'),
                                 str(BUILD / 'stage/source/rustc_mir_build/src/builder/checked_drop_origins.rs'), str(SOURCE),
                                 str(SOURCE.parent / 'tree_store/page_store/page_manager.rs'), str(SOURCE.parent / 'tree_store/page_store/cached_file.rs')],
          'profile': '--emit=metadata; Compilation::Stop after_analysis; no codegen/link/shim-body/optimized-MIR request',
          'resolver': 'Instance::try_resolve once only after raw/refusal durable publication and started receipt',
          'no_hir_id_join': True, 'no_application_execution': True})
    guard()


def observe_outputs(case, paths, previous):
    observations = []
    for label, path in paths.items():
        before = time.time_ns()
        if path.is_file():
            metadata = path.stat()
            signature = [metadata.st_ino, metadata.st_size, metadata.st_mtime_ns]
            if previous.get(label) != signature:
                item = identity(path)
                item.update({'label': label, 'external_probe_before_epoch_ns': before,
                             'external_probe_after_epoch_ns': time.time_ns()})
                observations.append(item)
                previous[label] = signature
    if observations:
        with (case / 'file-observations.jsonl').open('a') as output:
            output.write(json.dumps({'probe_batch_epoch_ns': time.time_ns(), 'observations': observations,
                                    'strict_order_between_same_batch_files': 'NOT_INFERRED'}, sort_keys=True) + '\n')


def run_case(index):
    expectation = read(PARENT / 'DROP-IDENTITY129-PREEXECUTION-EXPECTATIONS.json')['cases'][index]
    name = expectation['name']
    case = ROOT / 'cases' / ('%02d-' % (index + 1) + name)
    case.mkdir()
    outputs = {'report': case / 'report.json', 'raw': case / 'raw.json',
               'sidecar': case / 'identity.json', 'started': case / 'identity.started.json'}
    if name == 'seeded_sidecar':
        outputs['sidecar'].write_bytes(b'TASK129-SEEDED-SIDECAR-DO-NOT-REPLACE\n')
    if name == 'aliased_report_and_raw':
        outputs['raw'] = outputs['report']
    if name == 'raw_publication_permission_failure':
        raw_directory = case / 'owned-nonwritable-raw'
        raw_directory.mkdir()
        raw_directory.chmod(0o555)
        outputs['raw'] = raw_directory / 'raw.json'
        write(str(case.relative_to(ROOT) / 'permission-setup.json'), {
            'epoch_ns': time.time_ns(), 'directory': str(raw_directory), 'mode': oct(raw_directory.stat().st_mode & 0o777),
            'owner_uid': raw_directory.stat().st_uid, 'effective_uid': os.geteuid(),
            'access_write': os.access(raw_directory, os.W_OK), 'scope': 'fresh owned raw-only directory; no cleanup or mode restoration'})
    definition = OWNER if name != 'wrong_qualified_target' else 'tree_store::page_store::page_manager::WrongOwner::write_header'
    argv = [str(OBSERVER), '--report', str(outputs['report']), '--definition', definition,
            '--crate-source', str(SOURCE), '--libc', str(LIBC), '--sysroot', str(SYSROOT)]
    if name != 'old_five_pair_mode':
        argv += ['--raw-before-query', str(outputs['raw']), '--identity-sidecar', str(outputs['sidecar'])]
    if name == 'extra_link_argument':
        argv += ['--emit=link']
    environment = read(ROOT / 'ENVIRONMENT.json')['observer_environment']
    attempt = index + 3
    plan = {'charged_attempt': attempt, 'observer_command_number': index + 1, 'argv': argv,
            'environment': environment, 'cwd': str(case), 'expected': expectation,
            'outputs': {key: str(value) for key, value in outputs.items()}, 'timeout_seconds': 90,
            'preexecution_epoch_ns': time.time_ns(), 'resource': guard(), 'executable': identity(OBSERVER)}
    if plan['executable']['sha256'] != PINS[str(OBSERVER)]:
        raise RuntimeError('observer binary changed')
    write(str(case.relative_to(ROOT) / 'plan.json'), plan)
    previous = {}
    observe_outputs(case, outputs, previous)
    before = time.time_ns()
    monotonic = time.monotonic()
    with (case / 'stdout.raw').open('xb') as stdout, (case / 'stderr.raw').open('xb') as stderr:
        process = subprocess.Popen(argv, cwd=case, env=environment, stdin=subprocess.DEVNULL,
                                   stdout=stdout, stderr=stderr, start_new_session=True)
        write(str(case.relative_to(ROOT) / 'process.json'), {'pid': process.pid, 'pgid': os.getpgid(process.pid),
              'external_spawn_before_epoch_ns': before, 'external_spawn_after_epoch_ns': time.time_ns()})
        last_resource = 0.0
        while True:
            observe_outputs(case, outputs, previous)
            child, status, usage = os.wait4(process.pid, os.WNOHANG)
            if child:
                process.returncode = os.waitstatus_to_exitcode(status)
                break
            if time.monotonic() - last_resource > 0.1:
                guard()
                last_resource = time.monotonic()
            if time.monotonic() - monotonic >= 90:
                write(str(case.relative_to(ROOT) / 'TIMEOUT-BOUNDARY.json'), {'epoch_ns': time.time_ns(),
                      'pid': process.pid, 'no_arbitrary_process_kill': True})
                raise RuntimeError('90 second boundary reached; no arbitrary process kill authorized')
            time.sleep(0.01)
    after = time.time_ns()
    observe_outputs(case, outputs, previous)
    try:
        os.killpg(process.pid, 0)
        group_absent = False
    except ProcessLookupError:
        group_absent = True
    receipt = {'charged_attempt': attempt, 'observer_command_number': index + 1, 'case': name,
               'external_before_epoch_ns': before, 'external_after_wait4_epoch_ns': after,
               'elapsed_seconds_monotonic': time.monotonic() - monotonic, 'status': process.returncode,
               'expected_exit': expectation['expected_exit'], 'exit_matches': process.returncode == expectation['expected_exit'],
               'wait4_raw_status': status, 'wait4_reaped': True, 'owned_group_absent_after_reap': group_absent,
               'rusage': {'user_seconds': usage.ru_utime, 'system_seconds': usage.ru_stime, 'max_rss_bytes_macos': usage.ru_maxrss,
                          'input_blocks': usage.ru_inblock, 'output_blocks': usage.ru_oublock},
               'resource': guard(), 'outputs': {label: identity(path) for label, path in outputs.items() if path.is_file()},
               'stdout': identity(case / 'stdout.raw'), 'stderr': identity(case / 'stderr.raw'),
               'temporal_limit': 'external samples do not infer order of files first seen in one probe batch'}
    write(str(case.relative_to(ROOT) / 'receipt.json'), receipt)
    print(name, 'exit', process.returncode, 'expected', expectation['expected_exit'],
          'seconds', round(receipt['elapsed_seconds_monotonic'], 3), flush=True)


if __name__ == '__main__':
    if sys.argv[1] == 'prepare':
        prepare()
    elif sys.argv[1] == 'case':
        run_case(int(sys.argv[2]))
    elif sys.argv[1] == 'authenticate-exit':
        auth_phase('EXIT')
