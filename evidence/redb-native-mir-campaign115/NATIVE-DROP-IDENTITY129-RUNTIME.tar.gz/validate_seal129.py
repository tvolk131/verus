import importlib.util
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
specification = importlib.util.spec_from_file_location('diagnostic129', ROOT / 'diagnostic129.py')
lane = importlib.util.module_from_spec(specification)
specification.loader.exec_module(lane)
hashlib = lane.hashlib
json = lane.json
os = lane.os
stat = lane.stat
tarfile = lane.tarfile
time = lane.time
shutil = lane.shutil
checks = []


def check(name, condition, details=None):
    checks.append({'name': name, 'passed': bool(condition), 'details': details})


def load_case(index):
    case = sorted((ROOT / 'cases').iterdir())[index]
    plan = lane.read(case / 'plan.json')
    outputs = {key: Path(value) for key, value in plan['outputs'].items()}
    receipt = lane.read(case / 'receipt.json')
    return case, plan, outputs, receipt


def refusal(value):
    return (value.get('proof_acceptance') is False and value.get('native_resource_correspondence') is False
            and value.get('all18') == 'OPEN' and value.get('resource_credit') == 0
            and value.get('trust_credit') == 0
            and (value.get('native_credit') == 0 or value.get('native_proof_credit') == 0))


def validate():
    for index in range(7):
        case, plan, outputs, receipt = load_case(index)
        check(case.name + ': exit', receipt['status'] == plan['expected']['expected_exit'], receipt['status'])
        check(case.name + ': bounded and reaped', receipt['elapsed_seconds_monotonic'] <= 90
              and receipt['wait4_reaped'] and receipt['owned_group_absent_after_reap'])
        check(case.name + ': fixed environment', plan['environment'] == lane.read(ROOT / 'ENVIRONMENT.json')['observer_environment'])
        report = lane.read(outputs['report']) if outputs['report'].is_file() else None
        if report:
            check(case.name + ': proof refused credits zero', refusal(report)
                  and report['interface_exported'] is False and report['resource_semantics_checked'] is False)
            check(case.name + ': metadata-only argv', '--emit=metadata' in report['compiler_argv']
                  and not any('link' in item or 'optimized-mir' in item or 'dump-mir' in item for item in report['compiler_argv'])
                  and report['code_generation_requested_by_observer'] is False)
        check(case.name + ': no codegen artifacts', not any(path.suffix in ['.rmeta', '.rlib', '.o', '.dylib'] for path in case.rglob('*')))
    case, plan, outputs, receipt = load_case(0)
    old = lane.read(outputs['report'])
    check('old: one original header capture', len(old['captures']) == 1 and old['target_definition'] == lane.OWNER
          and old['exactly_one_definition_observed'] is True)
    check('old: no optional identity or outputs', 'optional_identity' not in old
          and all(not outputs[label].exists() for label in ['raw', 'sidecar', 'started']))
    case, plan, outputs, receipt = load_case(1)
    report = lane.read(outputs['report'])
    raw_bytes = outputs['raw'].read_bytes()
    raw = json.loads(raw_bytes)
    started = lane.read(outputs['started'])
    sidecar = lane.read(outputs['sidecar'])
    status = report['optional_identity']['status']
    check('exact: complete raw UTF8 independently byte-equal to started',
          started['raw_complete_utf8'].encode('utf-8') == raw_bytes
          and started['raw_bytes'] == len(raw_bytes), {'bytes': len(raw_bytes), 'sha256': hashlib.sha256(raw_bytes).hexdigest()})
    check('exact: raw refusal durable and explicit', refusal(raw['native_proof_refusal_snapshot'])
          and raw['native_proof_refusal_snapshot']['interface_exported'] is False
          and raw['native_proof_refusal_snapshot']['hir_vir_mapping_approved'] is False
          and raw['query_started'] == 'NOT_STARTED'
          and status['raw_persistence'] == 'DURABLE_NO_CLOBBER' and status['refusal'] == 'NATIVE_PROOF_REFUSED_DURABLE')
    check('exact: immutable snapshots remain PENDING', raw['compiler_completion'] == started['compiler_completion']
          == sidecar['compiler_completion'] == sidecar['status']['compiler_completion'] == 'PENDING'
          and report['optional_identity']['immutable_pre_return_snapshots_remain_pending'] is True
          and status['partial'] == 'IDENTITIES_OBSERVED_COMPILER_COMPLETION_PENDING')
    check('exact: final compiler return distinct from error finality', report['compiler_completed_without_panic'] is True
          and status['compiler_completion'] == 'RUN_COMPILER_RETURNED_WITHOUT_PANIC'
          and status['compiler_error_finality'] == 'NO_LIVE_TCX_AFTER_RETURN_ERROR_FINALITY_NOT_ASSERTED')
    snapshots = [raw['compiler_error_snapshot'], status['errors_before_identity_queries'],
                 status['errors'], status['destructor']['errors_before']]
    check('exact: callback errors and delayed bugs separately clear but PENDING', all(
          snapshot['emitted_errors'] is False and snapshot['errors_or_delayed_bugs'] is False
          and snapshot['compiler_outcome'] == 'PENDING' and snapshot['clean_absence_permitted'] is False
          for snapshot in snapshots), snapshots)
    tokens = raw['typed_identity_tokens']
    check('exact: typed tokens identical across raw started sidecar', tokens == started['typed_identity_tokens'] == sidecar['tokens'])
    check('exact: unique capture selected exact owner', len(tokens) == len(raw['raw_capture']['captures']) == 1
          and tokens[0]['owner_same_session'] == status['owner']['same_session_def_id']
          and raw['raw_capture']['target_definition'] == lane.OWNER
          and raw['raw_capture']['selected_definitions'] == [lane.OWNER]
          and raw['raw_capture']['explicit_selected_query_requests'] == 1
          and status['selection'] == 'EXACT_TWO_DISTINCT_CFG_CONTEXTS')
    sites = sorted(tokens[0]['sites'], key=lambda site: site['context']['block'])
    raw_sites = sorted(raw['raw_capture']['captures'][0]['drops'], key=lambda site: site['block'])
    result_sites = sorted(status['site_results'], key=lambda site: site['context']['block'])
    check('exact: one resolver only after start returned', status['glue_resolver_invocations'] == 1
          and status['query_started'] == 'RETURNED' and started['query_started'] == 'STARTED_INCOMPLETE')
    check('exact: distinct bb16 bb19 contexts retained', len(sites) == len(result_sites) == len(raw_sites) == 2
          and [site['context']['block'] for site in sites] == [16, 19]
          and [site['context']['block'] for site in result_sites] == [16, 19]
          and sites[0]['context'] != sites[1]['context']
          and raw_sites[0]['cleanup'] is False and raw_sites[0]['normal_target'] == 17 and raw_sites[0]['unwind'] == 'Cleanup(bb20)'
          and raw_sites[1]['cleanup'] is True and raw_sites[1]['normal_target'] == 20 and raw_sites[1]['unwind'] == 'Terminate(InCleanup)')
    for ordinal, site in enumerate(sites):
        check('exact: typed token/context binding site ' + str(ordinal),
              site['adt_same_session'] == status['adt']['same_session_def_id'] and site['checked_empty_args'] is True
              and site['context'] == result_sites[ordinal]['context']
              and site['context']['site_records'] == [raw_sites[ordinal]])
    for raw_site in raw_sites:
        origins = raw_site['matching_temporary_observations']
        origin = origins[0]
        edge = origin['exact_thir_scope_edges_with_value_equal_to_expression']
        check('exact: e78 ScopeNone zero matching Scope edges bb' + str(raw_site['block']),
              len(origins) == 1 and origin['expression'] == 'e78' and origin['local'] == 20
              and origin['scope'] is None and edge['edges'] == [] and edge['matching_status'] == 'COMPLETE_EMPTY'
              and edge['relation'] == 'scope.value_expression == temporary.expression')
    glue = status['glue']
    actual = glue['actual_result']
    target_type = 'tree_store::page_store::cached_file::WritablePage'
    payload = actual['drop_glue_payload']
    check('exact: actual full nonempty DropGlue instance args payload',
          glue['status'] == actual['status'] == 'RESOLVED_NONEMPTY_GLUE' and actual['resolver_result'] == 'Ok(Some)'
          and actual['full_instance_kind'].startswith('Shim(DropGlue(')
          and actual['full_instance'] == 'Instance { def: ' + actual['full_instance_kind'] + ', args: ' + actual['returned_args'] + ' }'
          and actual['returned_args'] == glue['requested_args'] == '[' + target_type + ']'
          and actual['requested_returned_args_equal'] is True and actual['expected_target_identity_matches'] is True
          and payload['variant'] == 'Some' and payload['type'] == glue['requested_type'] == target_type
          and payload['type_equal_requested'] is True and payload['glue_def_id_equal_lang_item'] is True
          and glue['lang_item']['same_session_def_id'] in actual['full_instance_kind'], actual)
    destructor = status['destructor']['actual_result']
    check('exact: actual distinct destructor definition and self type',
          destructor['status'] == 'DEFINITION_OBSERVED_SOURCE_MATCH'
          and destructor['implementation_self_type_equal_exact_adt'] is True
          and destructor['definition']['local'] is True and destructor['definition']['source_line'] == 41
          and destructor['implementation']['source_line'] == 40
          and destructor['definition']['source_file'] == str(lane.SOURCE.parent / 'tree_store/page_store/cached_file.rs')
          and destructor['definition']['same_session_def_id'] != glue['lang_item']['same_session_def_id']
          and destructor['definition']['def_path'] == '<' + target_type + ' as std::ops::Drop>::drop'
          and status['destructor_instance'] == 'NOT_REQUESTED', destructor)
    check('exact: no event merge or ownership claim', status['site_identity_comparison']['unique_dynamic_event'] == 'NOT_ESTABLISHED'
          and status['site_identity_comparison']['distinct_cfg_contexts'] is True
          and all(site['shared_actual_identity_result'] == {'glue': status['glue'], 'destructor': status['destructor']} for site in result_sites))
    case, plan, outputs, receipt = load_case(2)
    wrong = lane.read(outputs['report'])
    wrong_raw = lane.read(outputs['raw'])
    wrong_status = wrong['optional_identity']['status']
    check('wrong owner: raw/refusal preserved no resolver no start',
          wrong_raw['selection'] == wrong_status['selection'] == 'WRONG_OR_AMBIGUOUS_OWNER'
          and refusal(wrong_raw['native_proof_refusal_snapshot']) and wrong_status['glue_resolver_invocations'] == 0
          and wrong_status['query_started'] == 'REFUSED_SELECTION_MISMATCH'
          and not outputs['started'].exists() and outputs['sidecar'].is_file())
    case, plan, outputs, receipt = load_case(3)
    check('seed: original bytes preserved no output/callback', outputs['sidecar'].read_bytes() == b'TASK129-SEEDED-SIDECAR-DO-NOT-REPLACE\n'
          and all(not outputs[label].exists() for label in ['report', 'raw', 'started'])
          and not list(case.glob('.*observer-stage*')) and not list(case.glob('.*candidate123-stage*')))
    for index, label in [(4, 'alias'), (6, 'extra link argument')]:
        case, plan, outputs, receipt = load_case(index)
        check(label + ': no output/callback', all(not path.exists() for path in outputs.values())
              and not list(case.glob('.*observer-stage*')) and not list(case.glob('.*candidate123-stage*')))
    case, plan, outputs, receipt = load_case(5)
    permission = lane.read(outputs['report'])['optional_identity']['status']
    permission_reproduced = not outputs['raw'].exists() and permission['raw_persistence'].get('status') == 'IO_FAILURE'
    check('permission: genuine raw publication IO_FAILURE', permission_reproduced,
          permission['raw_persistence'] if permission_reproduced else 'NOT_REPRODUCED')
    check('permission: query refused resolver0 no started refusal retained', permission['glue_resolver_invocations'] == 0
          and permission['query_started'] == 'REFUSED_RAW_REFUSAL_PERSISTENCE_FAILED'
          and not outputs['started'].exists() and lane.read(outputs['sidecar'])['status']['query_started'] == permission['query_started']
          and permission['proof_acceptance'] is False)
    permission_setup = lane.read(case / 'permission-setup.json')
    check('permission: fresh canonical owned nonwritable directory', permission_setup['mode'] == '0o555'
          and permission_setup['owner_uid'] == permission_setup['effective_uid']
          and outputs['raw'].parent.resolve() == outputs['raw'].parent)
    value = {'epoch_ns': time.time_ns(), 'checks': checks, 'all_checks_passed': all(item['passed'] for item in checks),
             'semantic_status': 'DIAGNOSTIC_IDENTITIES_OBSERVED_NOT_A_COMPLETED_PROOF',
             'all18': 'OPEN', 'native_credit': 0, 'resource_credit': 0, 'trust_credit': 0, 'proof_credit': 0,
             'scope_edge_gap': 'e78 scope=None; no exact Scope.value_expression=e78 edges; no HirId join',
             'genuine_resolver_error_or_panic': 'NOT_VALIDATED_NOT_NATURALLY_OBSERVED',
             'strict_oracle115_verdict': 'NOT_REQUESTED_NOT_GRANTED', 'approved_mapping': False}
    lane.write('VALIDATION.json', value)
    lane.write('ACTUAL-IDENTITY-RESULT.json', {'glue': glue, 'destructor': status['destructor'],
               'compiler_return': status['compiler_completion'], 'compiler_error_finality': status['compiler_error_finality'],
               'callback_error_snapshot': status['errors'], 'partial': status['partial'], 'distinct_contexts': [16, 19],
               'resolver_count': 1, 'proof_acceptance': False, 'all18': 'OPEN',
               'native_credit': 0, 'resource_credit': 0, 'trust_credit': 0, 'proof_credit': 0})
    print('validation', len(checks), 'checks; failures', [item['name'] for item in checks if not item['passed']], flush=True)


def loaded_inputs():
    entry = lane.read(ROOT / 'ENTRY-AUTHENTICATION.json')
    entry_map = {item['path']: item for group in entry['groups'].values() for item in group}
    loaded = []
    warnings = []
    for case in sorted((ROOT / 'cases').iterdir()):
        text = (case / 'stderr.raw').read_text()
        records = []
        for line in text.splitlines():
            match = lane.re.match(r'dyld\[\d+\]: <([^>]+)> (/.+)$', line)
            if match:
                path = Path(match.group(2))
                record = {'uuid': match.group(1), 'path': str(path), 'selected_toolchain_or_observer':
                          str(path).startswith(str(lane.SYSROOT)) or path == lane.OBSERVER}
                if path.is_file():
                    record['current_identity'] = lane.identity(path)
                    expected = entry_map.get(str(path))
                    record['matches_entry_identity'] = expected is not None and expected['sha256'] == record['current_identity']['sha256']
                else:
                    record['content_authentication'] = 'OS_SHARED_CACHE_IMAGE_NOT_A_STANDALONE_REGULAR_FILE'
                records.append(record)
            elif not line.startswith('dyld['):
                warnings.append({'case': case.name, 'line': line})
        selected = [item for item in records if item['selected_toolchain_or_observer']]
        loaded.append({'case': case.name, 'records': records, 'selected_count': len(selected),
                       'all_selected_match_entry': len(selected) == 3 and all(item.get('matches_entry_identity') for item in selected)})
    lane.write('LOADED-LIBRARY-AUTHENTICATION.json', {'epoch_ns': time.time_ns(), 'cases': loaded,
               'all_selected_match_entry': all(item['all_selected_match_entry'] for item in loaded),
               'basis': 'actual DYLD_PRINT_LIBRARIES image paths/UUIDs from preserved raw stderr; SHA256 compared with entry'})
    lane.write('WARNINGS-AND-RAW-DIAGNOSTICS.json', {'all_non_dyld_lines': warnings,
               'unexpected_results': [item for item in checks if not item['passed']],
               'setup_failures_preserved_and_charged': 2,
               'limitations': ['loader tracing itself is not a compiler callback',
                   'OS shared-cache images are path/UUID observations, not independently hashed standalone files',
                   'PENDING snapshots are immutable and are not retrospectively marked successful',
                   'no strict temporal ordering inferred for files first observed in one external probe batch']})
    print('loaded selected libraries match entry', all(item['all_selected_match_entry'] for item in loaded), flush=True)


def seal():
    lane.auth_phase('EXIT')
    entry_python = {item['path']: item for item in lane.read(ROOT / 'ENTRY-AUTHENTICATION.json')['python_inputs']}
    python_now = lane.python_inputs()
    lane.write('PYTHON-EXIT-IDENTITY.json', {'records': python_now,
               'entry_modules_unchanged': all(lane.identity(path)['sha256'] == item['sha256'] for path, item in entry_python.items()),
               'new_sealing_script': lane.identity(__file__), 'effective_environment': dict(os.environ),
               'argv': sys.argv, 'python_version': sys.version})
    receipts = [lane.read(path) for path in sorted((ROOT / 'cases').glob('*/receipt.json'))]
    samples = [json.loads(line) for line in (ROOT / 'resource-samples.jsonl').read_text().splitlines()]
    validation = lane.read(ROOT / 'VALIDATION.json')
    lane.write('ACCOUNTING.json', {'task': 129, 'task_start_epoch_ns': lane.START_NS,
               'before_seal_epoch_ns': time.time_ns(), 'deadline_epoch_ns': lane.DEADLINE_NS,
               'charged_attempts': 9, 'setup_only_failures': 2, 'observer_commands': 7, 'attempt_limit': 9,
               'remaining_allowance': 0, 'compiler_builds': 0, 'cargo_commands': 0, 'rustfmt_commands': 0,
               'verifier_solver_helper_control_commands': 0, 'application_executions': 0,
               'codegen_link_shim_body_optimized_mir_requests': 0, 'network_commands': 0, 'git_commands': 0,
               'source_candidate_parent_edits': 0, 'subdelegations': 0, 'cleanup': False,
               'old116_allowances': 'UNCHANGED_NO_RESET', 'build127_allowances': 'UNCHANGED_EXHAUSTED',
               'managed_observer_seconds': [receipt['elapsed_seconds_monotonic'] for receipt in receipts],
               'all_wait4_reaped': all(receipt['wait4_reaped'] for receipt in receipts),
               'all_groups_absent': all(receipt['owned_group_absent_after_reap'] for receipt in receipts),
               'minimum_sampled_free_bytes': min(sample['free_bytes'] for sample in samples),
               'maximum_sampled_scratch_bytes_before_seal': max(max(sample['scratch_logical_bytes'], sample['scratch_allocated_bytes']) for sample in samples),
               'resource_bound': 'periodic current samples; not a claim of historically continuous measurement',
               'all18': 'OPEN', 'native_credit': 0, 'resource_credit': 0, 'trust_credit': 0, 'proof_credit': 0})
    group_checks = []
    for path in sorted((ROOT / 'cases').glob('*/process.json')):
        process = lane.read(path)
        try:
            os.killpg(process['pgid'], 0)
            absent = False
        except ProcessLookupError:
            absent = True
        group_checks.append({'pid': process['pid'], 'pgid': process['pgid'], 'absent': absent})
    lane.write('COMPILER-SLOT-RELEASED.json', {'epoch_ns': time.time_ns(), 'compiler_slot': 'EXPLICITLY_RELEASED',
               'all_owned_processes_wait4_reaped': all(receipt['wait4_reaped'] for receipt in receipts),
               'all_owned_groups_absent': all(item['absent'] for item in group_checks), 'groups': group_checks,
               'authority_scope': 'task129 diagnostic runtime only', 'automatic_followup': False})
    rows = '\n'.join('| ' + receipt['case'] + ' | ' + str(receipt['status']) + ' | ' +
                     str(receipt['expected_exit']) + ' | ' + str(round(receipt['elapsed_seconds_monotonic'], 3)) + ' |'
                     for receipt in receipts)
    report = '''# Task129 sealed diagnostic runtime report

All seven registered observer exit expectations matched. Independent semantic validation: %s checks, %s failed.
Nine attempts charged: two setup-only failures plus seven standalone observer commands. No allowance reset or builds.

| Registered case | Actual exit | Expected exit | Seconds |
|---|---:|---:|---:|
%s

## Actual identity result

One resolver invocation returned an actual nonempty `Shim(DropGlue(core::ptr::drop_glue, Some(WritablePage)))`
instance with complete requested/returned arguments `[tree_store::page_store::cached_file::WritablePage]`.
The independently recorded destructor is the distinct local
`<tree_store::page_store::cached_file::WritablePage as std::ops::Drop>::drop`,
`cached_file.rs:41`, with the implementation at line 40 and exact Self-type equality observed.
Complete raw bytes and UTF8 length match the started receipt; typed owner/ADT tokens match all snapshots.
The one identity result remains attached to DISTINCT bb16/noncleanup and bb19/cleanup contexts, not merged events.
Both raw e78 temporary observations retain `scope=None` and zero exact Scope.value_expression=e78 edges; no HirId join.

Compiler run returned without panic, separately from callback error state: emitted_errors=false and
errors_or_delayed_bugs=false at the observed callback snapshots. Those snapshots remain PENDING.
`NO_LIVE_TCX_AFTER_RETURN_ERROR_FINALITY_NOT_ASSERTED` is retained; neither PENDING nor clean callback samples
establish a completed proof, final absence of delayed compiler errors, dynamic event uniqueness, or resource ownership.

## Controls and limits

The fresh owned canonical mode-0555 raw-only directory genuinely failed publication with EACCES/IO_FAILURE,
exit 70, resolver0 and no started file; explicit query refusal survives in sidecar/report.
Seed bytes remain intact. Wrong qualified owner exits 65 with raw/refusal but resolver0/no start.
Aliased paths, seeded sidecar, and the extra link argument refuse before compiler callback by reviewed source control flow.
No helper-controls, original redb application, codegen, link, shim-body, or optimized-MIR request ran.
No source/candidate/parent edits, Git, network commands, cleanup, or delegation occurred.
Original setup traceback and shell expansion error are preserved and conservatively charged; no hidden retry.
All raw stdout/stderr, effective environments, complete argv, wait4 statuses, rusage, external epoch-ns probes,
source/receipt bundle, and entry/exit authentication are retained.

All 132 build-manifest payloads, 4903 historical122 records, 54 tested source records, 15 review126 payloads,
and explicit pins authenticate at current entry and exit. This is current endpoint equality, not historical
continuous custody. Actual dyld-selected observer/rustc_driver/LLVM paths and hashes match entry identities.
OS shared-cache image UUIDs/paths are observed, not independently content-hashed standalone files.
Files first seen together do not acquire an invented strict temporal ordering.
The slot is explicitly released; all seven owned children are wait4-reaped and all owned process groups absent.

Genuine resolver Err/panic/fatal-after-start controls remain UNVALIDATED because not naturally observed.
Strict oracle115 verdict: NOT REQUESTED/NOT GRANTED. Approved native/HIR/VIR mapping: NONE.
All18 remain OPEN; native/resource/trust/proof credits are all 0.

## Smallest semantic next cut (not an automatic followup)

Read-only correspondence review of the already identified `WritablePage::drop -> LRUWriteCache::return_value`
obligation, keeping bb16 and bb19 separate and the missing e78 Scope edge unresolved. Identity evidence alone
does not supply a resource contract, linearity/ownership, or a HIR/VIR mapping; no new compiler query is authorized.
''' % (len(validation['checks']), sum(not item['passed'] for item in validation['checks']), rows)
    (ROOT / 'REPORT.md').write_text(report)
    lane.guard()
    frozen_samples = []

    def frozen_guard():
        logical = allocated = 0
        for directory, directories, files in os.walk(ROOT):
            for name in files:
                metadata = (Path(directory) / name).lstat()
                logical += metadata.st_size
                allocated += metadata.st_blocks * 512
        sample = {'epoch_ns': time.time_ns(), 'free_bytes': shutil.disk_usage(ROOT).free,
                  'scratch_logical_bytes': logical, 'scratch_allocated_bytes': allocated}
        frozen_samples.append(sample)
        if sample['free_bytes'] <= 16 * 1024**3 or max(logical, allocated) > lane.LIMIT or sample['epoch_ns'] >= lane.DEADLINE_NS:
            raise RuntimeError('seal resource/deadline boundary')

    payloads = []
    for path in sorted(ROOT.rglob('*')):
        if path.is_dir():
            continue
        if not stat.S_ISREG(path.lstat().st_mode):
            raise RuntimeError('nonregular archive payload: ' + str(path))
        record = lane.identity(path)
        record['relative_path'] = str(path.relative_to(ROOT))
        payloads.append(record)
    lane.write('SEALED-MANIFEST.json', {'epoch_ns': time.time_ns(), 'records': payloads,
               'excluded_final_seal_files': ['SEALED-MANIFEST.json', 'HANDOFF.tar.gz', 'ARCHIVE-READBACK.json', 'SEAL.json'],
               'all18': 'OPEN', 'native_credit': 0, 'resource_credit': 0, 'trust_credit': 0, 'proof_credit': 0})
    manifest_identity = lane.identity(ROOT / 'SEALED-MANIFEST.json')
    expected = {item['relative_path']: item for item in payloads}
    expected['SEALED-MANIFEST.json'] = manifest_identity
    archive = ROOT / 'HANDOFF.tar.gz'
    with tarfile.open(archive, 'w:gz', compresslevel=3, dereference=True) as output:
        for index, name in enumerate(sorted(expected)):
            output.add(ROOT / name, arcname=name, recursive=False)
            if index % 50 == 0:
                frozen_guard()
    readback = []
    with tarfile.open(archive, 'r:gz') as source:
        for index, member in enumerate(source):
            if not member.isfile() or member.name.startswith('/') or '..' in Path(member.name).parts or member.name not in expected:
                raise RuntimeError('unsafe or unregistered archive member')
            content = source.extractfile(member)
            digest = hashlib.sha256()
            length = 0
            for chunk in iter(lambda: content.read(1024 * 1024), b''):
                length += len(chunk)
                digest.update(chunk)
            matches = length == expected[member.name]['bytes'] and digest.hexdigest() == expected[member.name]['sha256']
            readback.append({'name': member.name, 'bytes': length, 'sha256': digest.hexdigest(), 'regular_only': True, 'matches': matches})
            if index % 50 == 0:
                frozen_guard()
    all_match = len(readback) == len(expected) and len({item['name'] for item in readback}) == len(expected) and all(item['matches'] for item in readback)
    lane.write('ARCHIVE-READBACK.json', {'epoch_ns': time.time_ns(), 'records': readback,
               'all_match': all_match, 'archive': lane.identity(archive), 'regular_only': True, 'extracted_to_disk': False})
    frozen_guard()
    lane.write('SEAL.json', {'epoch_ns': time.time_ns(), 'task_start_epoch_ns': lane.START_NS,
               'elapsed_seconds_including_seal_so_far': (time.time_ns() - lane.START_NS) / 1000000000,
               'archive': lane.identity(archive), 'manifest': manifest_identity,
               'readback': lane.identity(ROOT / 'ARCHIVE-READBACK.json'), 'report': lane.identity(ROOT / 'REPORT.md'),
               'accounting': lane.identity(ROOT / 'ACCOUNTING.json'), 'validation': lane.identity(ROOT / 'VALIDATION.json'),
               'source_receipt_bundle': lane.identity(ROOT / 'SOURCE-AND-RECEIPT-BUNDLE.json'),
               'compiler_slot_release': lane.identity(ROOT / 'COMPILER-SLOT-RELEASED.json'),
               'seal_resource_samples': frozen_samples, 'regular_only_archive_readback_matches': all_match,
               'all18': 'OPEN', 'native_credit': 0, 'resource_credit': 0, 'trust_credit': 0, 'proof_credit': 0})
    print('sealed', len(payloads), 'payloads; archive', lane.identity(archive)['sha256'], 'regular readback', all_match, flush=True)


if __name__ == '__main__':
    validate()
    loaded_inputs()
    seal()
