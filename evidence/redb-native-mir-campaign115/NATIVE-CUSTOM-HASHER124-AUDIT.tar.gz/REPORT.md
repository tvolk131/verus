# audit124: original std-profile native cache semantic dependency

## Decision and scope

**No sufficient checked derivation identified.** Even conditional on clearing
the earlier nominal-type and Mutex blockers, the matched contracts do not supply
a checked route to
`builds_valid_hashers::<BuildHasherDefault<FastHasher64>>()`. This is an
independent specification-linkage cut, not evidence that the u64 hasher algorithm
is defective and not a metatheoretic unprovability result. The actual unchanged
cache also calls `HashMap::get_mut`, for which no direct contract was identified
in the matched vstd Rust sources. Merely supplying the builder predicate would
therefore not complete the native functional state proof.

All18 remain OPEN; native/resource/trust credit = 0. No integration, acceptance,
native-semantics result, or full18 proof is claimed. Audit124 is source-only and
distinct from earlier113 nominal-refusal diagnostics, parallel compiler122 and
implementation123 work. Neither those workers nor their state/results were
inspected or polled. Prior113 REPORT.md was not read and no old refusal was
reproduced. The known independent110 atomic stored-value cut remains untouched.

## Anchor notation and authenticated target

Paths below expand as follows (line anchors refer to observed selected bytes):

- N = `/private/tmp/redb-original-crate-preflight115/redb/src/tree_store/page_store`
- V = `/private/tmp/redb-compiler-validation114-worker-20261108T151020Z/snapshot/source/vstd`
- L = `/Users/tommyvolk/.rustup/toolchains/stable-aarch64-apple-darwin/lib/rustlib/src/rust/library`
- H = `/Users/tommyvolk/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/hashbrown-0.17.1`

The frozen manifest SHA256 equals the supplied
`c73d2fba54d4144d3705d78a6d5d6cf9d29bf5eaeeb80dce6d9736fd001d6dd9`.
Selected hashes/sizes are in INPUTS.tsv; entry/exit artifacts authenticate only
those selected files plus the explicitly inventoried vstd search scope, not the
whole worker tree. The original content pin
`c82ab865bb362bc4af067d332adc44978ff64813` is user-supplied provenance: no Git
operation independently establishes commit continuity. Native observed bytes are
hashed, not asserted to be Git-authenticated.

N/fast_hash.rs:4,13 selects the original std alias
`HashMap<u64,V,BuildHasherDefault<FastHasher64>>`, not the no_std BTreeMap at :43.
N/lru_cache.rs:5,10,20 uses that alias with values `(T,AtomicBool,u32)`.
Its insert :30 first calls native `get_mut` :31, then `insert` :37; removal is
:42, `get_mut` :76, eviction removal :102. N/cached_file.rs:64 instantiates
`LRUCache<Option<Arc<[u8]>>>`; `return_value` :91 and `take_value` :95 mutate
the stored Option through `get_mut`. Thus the needed proof is not merely an
empty-map theorem, read-only lookup, or a nominal type declaration.

## Exactly what the matched contracts offer

Let K = u64 and S = BuildHasherDefault<FastHasher64>, and let
G = `obeys_key_model::<K>() && builds_valid_hashers::<S>()`.

- **View, unconditional subject to cfg/type recognition:** V/view.rs:137,164
  implements `View<V=Map<Key,Value>>` for arbitrary S (allocator/non-allocator
  cfg variants). Its view is uninterpreted. V/std_specs/hash.rs:420 gives the
  generic external HashMap nominal specification; :438 forwards spec indexing
  to map indexing. Neither entails builder validity or executable state changes.
- **insert**, V/std_specs/hash.rs:651: only under G, final view is old view
  `.insert(k,v)`; Some(oldv) identifies previous membership/value and None
  identifies previous nonmembership. With G unavailable, this implication does
  not supply that functional postcondition.
- **remove**, :822: only under G, old/final views satisfy
  `borrowed_key_removed`, and Some(v)/None identifies previous mapping/absence.
  For Q=Key=u64, :797 equates that relation to final = old.remove(*k);
  :686 equates borrowed membership to ordinary membership; :741 equates
  borrowed mapping to ordinary membership plus indexed value equality.
  These bridge axioms need no new borrowed-key assumption for u64, but do not
  discharge G.
- **get**, :760: only under G, Some(&v) has the borrowed mapping and None means
  absence. **contains_key** :702 is similarly conditional. The existing key
  axiom :141 supplies `obeys_key_model::<u64>()`; it does not establish the
  builder conjunct.
- **get_mut**: full matched vstd Rust-source search identifies no direct
  `HashMap::get_mut` specification. The only `get_mut` in hash.rs is
  `OccupiedEntry::get_mut` :1378: current referent = old entry value, final
  entry value = final referent, key and prophetic final value preserved.
  This is a different receiver/API. `HashMap::entry` :1302 connects entries to
  map views only under G. It cannot justify the unchanged native call sites.
  No compiler support/unsupported-call diagnostic is asserted by this audit.
- **Unconditional residual guarantees:** :619 default and :634 with_hasher
  return empty views; :610 new/:628 with_capacity are RandomState constructors;
  :641 reserve preserves view; :840 clear empties it; :590 is_empty equals view
  emptiness; :597 clone relates domains and cloned values. None concludes G.
  `len` :576 returns spec_hash_map_len, but its equality to view length is gated
  by G at :565; capacity :583 only bounds that spec length. Iter :384,
  keys :847 and values :860 also gate their content correspondence on G.
  Do not overstate this as "all custom-builder specs give nothing."

V/map.rs:54 defines the mathematical map interface; :79,96,103 define empty,
insert and remove using mathematical domains/values. Those definitions establish
logical-map facts, not the missing executable-HashMap connection or builder fact.

## Producer/escape-route audit: more than a documentation/search-miss argument

All 137 discovered V/*.rs files were hashed before the recursive content search;
VSTD-SEARCH-ENTRY.sha256 records the exact scope. PREDICATE-USES.txt preserves
every occurrence of the predicate and candidate builder/trait names in that
scope. All predicate occurrences are in V/std_specs/hash.rs:

1. :254 declares a type-indexed **uninterpreted** Boolean predicate, with no
   defining equation reducing it to executable Hasher behavior.
2. :220 ExHasher has only the external-trait marker. :233 ExBuildHasher adds
   only the external-trait marker and associated `Hasher: Hasher`; there is no
   build_hasher postcondition, validity supercondition, or certificate rule.
   V/std_specs/core.rs:93 similarly gives ExHash only its external-trait marker.
   Rust trait satisfaction is therefore not a theorem producing this predicate.
3. :266 axiom_random_state_builds_valid_hashers concludes it for **RandomState**
   only; :1480 broadcasts that existing axiom. S is not RandomState. Default of
   the builder, Default of the map, or its same Hasher associated type supplies
   no type equality or generic validity theorem. No BuildHasherDefault
   declaration/specification/lemma occurs in the inventoried vstd sources.
4. :43-87 model **DefaultHasher**, not arbitrary implementations: a
   Seq<Seq<u8>> view, uninterpreted spec_finish, and specifications for its own
   new/write/finish. This cannot be instantiated as FastHasher64 or transported
   merely because both implement Hasher. There is no native FastHasher64 view
   or event-to-predicate correspondence in those definitions.
5. Every remaining operational predicate occurrence is an antecedent/consumer:
   HashMap :388,569,658,713,770,831,851,864,1309;
   HashSet :936,1009,1052,1098,1148,1165. The entry-resolution axioms
   :1270-1299, borrowed-key bridges and map/deep-view laws do not conclude
   builder validity. HashSet/entry do not provide an alternate producer.

This positively identifies the available concrete producer and the lack of a
formal introduction/linkage rule in the inspected interface. It does NOT prove
consistency of all Verus axioms, rule out every derivation in the complete
verifier/environment, or assert that the predicate is false/unprovable. No
solver, verifier, or implementation-level diagnostics were run.

## Actual hashing behavior, with primary-source/version qualification

The requested installed 1.99.1 `rustc-src/rust/library/core/src/hash/mod.rs` is
absent. Conservative filename-only discovery beneath installed toolchains found
core/std sources in stable and 1.75.0, not 1.99.1. Only stable was used. Its
channel manifest :2534,33825 identifies rust and rust-src as **1.99.0
(b940084d7 2026-09-28)**; the separately hashed pinned channel manifest identifies
1.99.1 (58cf8f9c3 2026-10-13). Therefore the following is primary-source evidence
for the discovered 1.99.0 implementation, NOT authentication of the exact pinned
1.99.1 executable/library. No source download or compiler query was made.

- N/fast_hash.rs:17 derives Default for a single u64 field; source-level
  interpretation initializes hash to zero. :36 write_u64 asserts prior zero in
  debug builds, then stores x.wrapping_mul(K), K=:11. :23 finish rotates left
  26 on 64-bit pointers, 15 on 32-bit; it does not mutate the state. For one
  fresh scalar-u64 hash, the result is deterministically rotl(x*K mod 2^64).
  K is odd; multiplication and rotation are permutations on 64-bit words,
  although collision-freedom is not a needed HashMap premise. This arithmetic
  observation and derive interpretation are not machine-checked proofs.
- L/core/src/hash/mod.rs:770 build_hasher returns H::default(); :787 builder
  Default only creates the phantom builder. :694 hash_one creates a fresh
  hasher, calls x.hash once, then finish. :807 macro expansion and :834's
  `(u64,write_u64)` entry explicitly anchor scalar-u64 Hash to write_u64;
  reference Hash forwards at :940. This is not an assumption that every Hash
  implementation or every future std version uses write_u64.
- L/std/src/collections/hash/map.rs:4 wraps hashbrown; :1296,1332,1390 delegate
  get_mut/insert/remove to base. L/std/Cargo.toml:23 and L/Cargo.lock:127 select
  hashbrown 0.17.1 with rustc-dep-of-std. The local archive SHA256 matches that
  lockfile checksum; `tar -xOf ... | shasum` matches the selected extracted
  lib.rs and map.rs bytes without writing extracted files. Missing
  .cargo-checksum.json is preserved as a failure, not silently treated as
  successful authentication.
- H/src/map.rs:236 make_hash calls hash_one; :1415 get_mut uses it when
  nonempty; :1806 insert uses it; :1956 remove calls remove_entry, which hashes
  at :1992; :206 make_hasher's resize/reinsert closure hashes each scalar key
  through the same route. Thus these inspected hashing entry points produce
  fresh single-write_u64 traces, not writes of a u64 byte slice. This is a
  source-level dispatch trace, not a complete proof of the hash-table internals.

**Panic and totality distinction.** N/fast_hash.rs:32 unconditionally panics
on `write(&[u8])`, even for eight bytes. A subsequent nonzero-state write_u64
can also fail its debug assertion. This is not a total arbitrary-write-stream
hasher; arrays/slices, other integer widths, and composite keys are not thereby
validated (L/core/src/hash/mod.rs:817 uses write for numeric slices, and :380
is merely the default write_u64 implementation that this hasher overrides).
It does not demonstrate a defect on the anchored fresh scalar-u64 path.

The vstd comment :225 and documentation :240 describe any two generated
hashers receiving the same write sequence and producing equal states/digests.
The actual predicate has no event semantics, termination clauses or totality
definition. We cannot infer that it formally requires arbitrary-sequence
totality, nor that equal panic behavior satisfies its intended "produce a
digest" language. A total interpretation would reject this hasher; a
partial-correctness/allowed-scalar-trace interpretation needs an explicit
formalization. Neither interpretation is adopted. Even a checked scalar-trace
determinism theorem alone would not introduce the existing opaque predicate,
whose type parameter is the builder and has no key/trace restriction.

## Next defensible action / additional boundary (not adopted)

**No current-restrictions checked derivation identified.** The minimal next
design decision is whether to authorize a future key/trace-restricted checked
specification-refinement route for the unchanged native builder/map. Its open
bindings must explicitly include exact pinned library-source provenance,
Default/Hash/build_hasher dispatch, admissible event and panic semantics,
FastHasher64 arithmetic, and a checked relation to HashMap's functional view
and mutable-reference writeback for the existing get_mut calls. One must decide
how that checked certificate connects to operation contracts: the present
uninterpreted predicate supplies no certificate introduction rule. Calling a
new axiom, assume_specification, external_body, or assumed predicate a
"certificate" would still be an additional trusted boundary, not this route.
No such refinement, trust producer or authorization is installed here. No
RandomState/no_std/key/executable substitution is proposed. Nominal/Mutex
clearance and atomic stored-value semantics remain separate obligations.

## Failures, discovery qualifications and resource seal

- Requested 1.99.1 core-source path/hash-directory lookup failed (missing);
  the broader installed-source discovery did not find matching 1.99.1 sources.
- Speculative V/lib.rs lookup/hash/byte count failed (missing); no contents used.
- H/.cargo-checksum.json hash/byte count/jq lookup failed (missing); archive
  checksum and streamed member hashes separately provide the stated binding.
- A search for a section-form `[dependencies.hashbrown]` returned no match;
  the already-hashed std Cargo.toml uses an inline dependency at :23 instead.
- Main hash.rs, view.rs and map.rs were matched to frozen manifest entries
  before substantive reads. core.rs was prehashed with the 137-file search
  inventory before its content search/read, but its manifest-entry comparison
  occurred later; retain this ordering qualification, not a retrofitted
  pre-read manifest-comparison claim. Source discovery used filenames first;
  no source contents were read before their entry hash.
- Some tool displays truncated long read outputs. Exact file/line searches and
  small selected rereads supplied the cited anchors; no failed command or
  absent file is counted as successful semantic evidence.

Entry time 2026-11-08T17:56:49Z; deadline 18:04:49Z. Final observed resources,
exit reauthentication and file hashes are in RESOURCES.json,
SELECTED-EXIT.tsv, VSTD-SEARCH-EXIT.sha256 and SEAL.sha256. Only new scratch
in this audit directory was written; no source/evidence edits, Git/network,
compiler/Cargo/rustfmt/verifier/solver/tests/diagnostics/target-native execution,
subdelegation or followup chain. Ordinary shell read/hash/archive utilities and
apply_patch were used. No Infer/S0/admission/import/export change or new
assumption/law/trusted producer occurred.
