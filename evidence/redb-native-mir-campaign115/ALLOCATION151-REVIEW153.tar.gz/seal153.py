import datetime
import hashlib
import json
from pathlib import Path
import shutil
import tarfile

scratch = Path('/private/tmp/redb-review153-20261108-m75vzQWZ')
start = datetime.datetime.fromisoformat('2026-11-08T22:32:01+00:00')
deadline = start + datetime.timedelta(minutes=16)
cap = 4 * 1024**2
free_floor = 16 * 1024**3

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def save(name, value):
    (scratch / name).write_text(json.dumps(value, indent=2) + '\n')

def sample():
    files = [path for path in scratch.rglob('*') if path.is_file()]
    return dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), logical_bytes=sum(path.stat().st_size for path in files), allocated_bytes=sum(path.stat().st_blocks * 512 for path in files), free_bytes=shutil.disk_usage('/private/tmp').free)

def enforce(record):
    assert record['logical_bytes'] <= cap
    assert record['allocated_bytes'] <= cap
    assert record['free_bytes'] > free_floor
    assert datetime.datetime.fromisoformat(record['utc']) <= deadline

assert json.loads((scratch / 'authentication-exit.json').read_text())['success']
assert json.loads((scratch / 'dependency-links-exit153.json').read_text())['success']
review152 = Path('/private/tmp/review152-20261108-yB2rKJYT')
assert sha(review152 / 'SEAL.json') == '80a06e4978e2a27398c522ad8503c935b466f8a64a43c3d93690483da21048a4'
assert sha(review152 / 'REPORT.md') == '1d96a0cfcd12653fa3ee5ee8d0035fdf6ac5c1e4c7eae5ad4b59800b964c37fe'
save('review152-selected-exit153.json', dict(seal_sha256=sha(review152 / 'SEAL.json'), report_sha256=sha(review152 / 'REPORT.md'), match=True, qualification='Selected current endpoint against parent-selected seal; no historical continuity.'))
before = sample()
enforce(before)
historical_free_samples = [29411196 * 1024]
for name in ['authentication-entry.json', 'authentication-entry-corrected.json', 'authentication-exit.json']:
    historical_free_samples.append(json.loads((scratch / name).read_text())['free_bytes'])
accounting = dict(review=153, start_utc=start.isoformat(), deadline_utc=deadline.isoformat(), compiler_slot='NEVER_ACQUIRED', compiler_build_verifier_test_solver_native_application_executions=0, subdelegates=0, network_git_destructive_actions=0, parent_baseline_source_edits=0, live154_inspection=False, authored_paths_scope=str(scratch), scratch_cap_bytes=cap, free_disk_strict_floor_bytes=free_floor, initial_audit_failure_preserved=True, initial_audit_failure='Expected HANDOFF151.json rather than actual SEAL.sha256 as third archive seal record; corrected without overwriting failure.', tool_truncations_preserved=6, truncated_content_recovered_by_bounded_reads=True, historical_allowances=dict(implementation151='SEALED29/36_NO_REUSE', implementation143='EXHAUSTED36/36', validation150='EXHAUSTED8/8', implementation147='SEALED30/32_NO_RESET', worker116='INTERRUPTED_UNCHANGED'), preseal_sample=before, minimum_free_bytes_so_far=min(historical_free_samples + [before['free_bytes']]), qualification='Sampled resource bounds, not continuous filesystem/runtime attestation. Final seal/readback bounds in detached READBACK153.json and HANDOFF153.json.', all18='OPEN', original_native_bodies_proved=0, laws_adopted=0, source_native_resource_trust_proof_credit_added=[0, 0, 0, 0, 0])
save('ACCOUNTING153.json', accounting)
payloads = sorted(path for path in scratch.iterdir() if path.is_file())
manifest = [dict(path=path.name, bytes=path.stat().st_size, sha256=sha(path)) for path in payloads]
save('MANIFEST153.json', manifest)
seal = dict(schema='review153-selected-exact-u8-store-v1', review=153, utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), manifest_sha256=sha(scratch / 'MANIFEST153.json'), payloads=len(manifest), report_sha256=sha(scratch / 'REPORT153.md'), disposition_sha256=sha(scratch / 'DISPOSITION153.json'), accounting_sha256=sha(scratch / 'ACCOUNTING153.json'), input_authentication='authentication-entry-corrected.json; authentication-exit.json; dependency-links153.json; dependency-links-exit153.json', pin_qualification='Parent-derived151 metadata pins, not independent historical pins; selected endpoint custody only.', native_export='REFUSED', original_native_bodies_proved=0, laws_adopted=0, all18='OPEN', compiler_slot='NEVER_ACQUIRED', adoption='NONE_RECOMMENDATION_ONLY', next='PARENT_EXPLICIT_DISPOSITION_NO_FURTHER_REVIEW_BUILD_CHAIN')
save('SEAL153.json', seal)
(scratch / 'SEAL153.sha256').write_text(sha(scratch / 'SEAL153.json') + '  SEAL153.json\n')
members = payloads + [scratch / name for name in ['MANIFEST153.json', 'SEAL153.json', 'SEAL153.sha256']]
archive_path = scratch / 'HANDOFF153.tar.gz'
assert not archive_path.exists()
with tarfile.open(archive_path, 'w:gz') as archive:
    for path in members:
        archive.add(path, arcname=path.name, recursive=False)
expected = {path.name: dict(bytes=path.stat().st_size, sha256=sha(path)) for path in members}
readback = []
with tarfile.open(archive_path, 'r:gz') as archive:
    for member in archive:
        assert member.isfile() and member.name in expected
        stream = archive.extractfile(member)
        data = stream.read()
        actual = hashlib.sha256(data).hexdigest()
        assert len(data) == expected[member.name]['bytes'] and actual == expected[member.name]['sha256']
        readback.append(dict(path=member.name, bytes=len(data), sha256=actual, match=True))
assert len(readback) == len(expected) == len({entry['path'] for entry in readback})
after = sample()
enforce(after)
readback_record = dict(review=153, archive=str(archive_path), archive_sha256=sha(archive_path), regular_unique_members=len(readback), all_members_byte_identical=True, members=readback, after_archive_readback_sample=after, elapsed_including_archive_readback_seconds=(datetime.datetime.fromisoformat(after['utc']) - start).total_seconds(), final_input_authentication='authentication-exit.json and dependency-links-exit153.json; review152-selected-exit153.json', report_sha256=sha(scratch / 'REPORT153.md'), minimum_sampled_free_bytes=min(historical_free_samples + [before['free_bytes'], after['free_bytes']]), remaining_output_bound='Pre-handoff sample plus at most16384 bytes for final detached readback/handoff metadata.')
assert after['logical_bytes'] + 16384 < cap and after['allocated_bytes'] + 32768 < cap
save('READBACK153.json', readback_record)
handoff = dict(review=153, root=str(scratch), archive=str(archive_path), archive_sha256=sha(archive_path), archive_bytes=archive_path.stat().st_size, manifest_sha256=sha(scratch / 'MANIFEST153.json'), seal_sha256=sha(scratch / 'SEAL153.json'), report=str(scratch / 'REPORT153.md'), report_sha256=sha(scratch / 'REPORT153.md'), readback_sha256=sha(scratch / 'READBACK153.json'), regular_unique_byte_identical_members=len(readback), verdict='RETAIN151_CONDITIONAL_ONLY_RECOMMEND_EXACT_INHERITED_U8_POINTSTO_REUSE_SUBJECT_TO_CHECKED_CORRESPONDENCE', parent_explicit_disposition_required=True, laws_installed=0, original_native_bodies_proved=0, all18='OPEN', compiler_slot='NEVER_ACQUIRED', followup_chain='NONE', pin_qualification=seal['pin_qualification'], elapsed_through_readback_seconds=readback_record['elapsed_including_archive_readback_seconds'], minimum_sampled_free_bytes=readback_record['minimum_sampled_free_bytes'])
save('HANDOFF153.json', handoff)
final = sample()
enforce(final)
print(json.dumps(dict(handoff=handoff, final_sample=final, elapsed_including_seal_seconds=(datetime.datetime.fromisoformat(final['utc']) - start).total_seconds(), scratch_within_cap=True, free_strictly_above_16GiB=True, selected_inputs_authenticated_at_exit=True), indent=2))
