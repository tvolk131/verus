import hashlib
import json
from pathlib import Path

root = Path('/private/tmp/redb-allocation151-20261108-cyzsxn1u')
scratch = Path('/private/tmp/redb-review153-20261108-m75vzQWZ')

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

history = json.loads((root / 'SOURCE-HISTORY151.json').read_text())
runner_hashes = {entry['sha256'] for entry in history if 'runner' in entry['path']}
runner_hashes.update(sha(root / name) for name in ['runner-initial151.py', 'runner-final151.py', 'seal151.py'])
records = []
for path in sorted(root.glob('*.receipt.json')):
    receipt = json.loads(path.read_text())
    name = path.name.removesuffix('.receipt.json')
    record = dict(name=name, number=receipt.get('number'), status=receipt.get('returncode'), streams=[], runner_sha256=receipt.get('runner_sha256'), runner_bytes_available=receipt.get('runner_sha256') in runner_hashes if receipt.get('runner_sha256') else None)
    for stream_name in ['stdout', 'stderr']:
        if isinstance(receipt.get(stream_name), dict):
            stream_path = root / (name + '.' + stream_name)
            stream = receipt[stream_name]
            record['streams'].append(dict(stream=stream_name, match=stream_path.stat().st_size == stream['bytes'] and sha(stream_path) == stream['sha256']))
    if receipt.get('argument_inputs'):
        initial = {entry['path']: entry['sha256'] for entry in receipt['argument_inputs']}
        endpoints = receipt.get('argument_input_endpoints', [])
        record['argument_endpoints'] = [dict(path=entry['path'], same=entry['sha256'] == initial.get(entry['path']), declared_unchanged=entry.get('unchanged')) for entry in endpoints]
    record['current_metadata_outputs'] = []
    arguments = receipt.get('argv', [])
    for index, argument in enumerate(arguments[:-1]):
        if argument == '-o':
            output = Path(arguments[index + 1])
            record['current_metadata_outputs'].append(dict(path=str(output), exists=output.exists()))
    records.append(record)
summary = dict(records=records, charged_numbers=sorted(record['number'] for record in records), all_streams_match=all(stream['match'] for record in records for stream in record['streams']), runner_bytes_qualification='Current availability or exact reconstruction only, not historical interpreter-load attestation.', native_proof_credit=0, laws_adopted=0)
(scratch / 'receipt-links153.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(dict(receipts=len(records), numbers=summary['charged_numbers'], streams_match=summary['all_streams_match'], missing_runner_bytes=[record['name'] for record in records if record['runner_bytes_available'] is False], selected=[record for record in records if record['name'] in ['final-source-bound-solver', 'semantic-byte-mutant-solver', 'restored-source-bound-solver', 'final-original-export-refusal']]), indent=2))
review = Path('/private/tmp/review152-20261108-yB2rKJYT')
seal = json.loads((review / 'SEAL.json').read_text())
selected = [entry for entry in seal['files'] if entry['path'] == 'REPORT.md']
assert len(selected) == 1
entry = selected[0]
assert sha(review / 'REPORT.md') == entry['sha256']
(scratch / 'review152-selected153.json').write_text(json.dumps(dict(seal_sha256=sha(review / 'SEAL.json'), report=entry, match=True, qualification='Hash follows parent-selected seal; no new historical pin.'), indent=2) + '\n')
if not summary['all_streams_match']:
    raise SystemExit(1)
