import hashlib
import json
from pathlib import Path
import sys

root = Path('/private/tmp/redb-allocation151-20261108-cyzsxn1u')
scratch = Path('/private/tmp/redb-review153-20261108-m75vzQWZ')

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

checks = []
for name in ['final-cut', 'mutant-cut', 'restored-cut']:
    binding = json.loads((root / (name + '.binding.json')).read_text())
    for role, path, expected in [
        ('capture', binding['capture'], binding['capture_sha256']),
        ('generated', binding['generated_source'], binding['generated_sha256']),
        ('template', root / 'proof/allocation151.template', binding['template_sha256']),
    ]:
        actual = sha(path)
        checks.append(dict(binding=name, role=role, path=str(path), expected=expected, actual=actual, match=actual == expected))
    for member in binding['members']:
        path = Path(member['path'])
        actual = sha(path)
        fragment = ''.join(path.read_text().splitlines(keepends=True)[member['first_line'] - 1:member['last_line']])
        archived_fragment = root / (name + '-' + member['role'] + '.source.txt')
        fragment_sha = hashlib.sha256(fragment.encode()).hexdigest()
        checks.append(dict(binding=name, role=member['role'], path=str(path), expected=member['sha256'], actual=actual, match=actual == member['sha256'] and fragment_sha == member['fragment_sha256'] == sha(archived_fragment)))
restoration = json.loads((root / 'restoration151.json').read_text())
for path in [Path('/private/tmp/redb-original-crate-preflight115/redb/src/tree_store/page_store/cached_file.rs'), root / 'mutant-redb/src/tree_store/page_store/cached_file.rs']:
    actual = sha(path)
    checks.append(dict(role='restored-original-source', path=str(path), expected=restoration['original_cached_file_sha256'], actual=actual, match=actual == restoration['original_cached_file_sha256']))
original_source = Path('/private/tmp/redb-original-crate-preflight115/redb/src/tree_store/page_store/cached_file.rs').read_bytes()
mutant_source = (root / 'semantic-byte-mutant.cached_file.rs').read_bytes()
checks.append(dict(role='actual-source-mutant-only-byte-operand', match=original_source.count(b'repeat_n(0u8, len)') == 1 and mutant_source == original_source.replace(b'repeat_n(0u8, len)', b'repeat_n(1u8, len)') and sha(root / 'semantic-byte-mutant.cached_file.rs') == restoration['mutant_cached_file_sha256']))
proof = (root / 'proof/final-cut.rs').read_bytes()
checks.append(dict(role='proof-mutant-only-source-element', match=(root / 'proof/mutant-cut.rs').read_bytes() == proof.replace(b'source_element() -> u8 { 0u8 }', b'source_element() -> u8 { 1u8 }')))
checks.append(dict(role='proof-restoration-byte-identity', match=(root / 'proof/restored-cut.rs').read_bytes() == proof))
record = dict(success=all(check['match'] for check in checks), checks=checks, qualification='Current selected bytes and internal dependency links only; not compiler/bootstrap/historical source identity.')
destination = 'dependency-links-exit153.json' if sys.argv[1:] == ['exit'] else 'dependency-links153.json'
(scratch / destination).write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(dict(success=record['success'], checks=len(checks), failures=[check for check in checks if not check['match']]), indent=2))
if not record['success']:
    raise SystemExit(1)
