import datetime
import hashlib
import json
from pathlib import Path
import shutil
import sys
import tarfile

root = Path('/private/tmp/redb-allocation151-20261108-cyzsxn1u')
scratch = Path('/private/tmp/redb-review153-20261108-m75vzQWZ')
workspace = Path('/Users/tommyvolk/.t3/worktrees/verus/t3-60978068')
pins = {
    'HANDOFF151.tar.gz': 'b6f483772602746145d9ae5514a1e27e467edd7fd9288e029906de0709caa408',
    'MANIFEST151.json': '6cd2fef505065c7179bc33f1d608bf3b34e62821b49c031122581b961d9d073a',
    'SEAL.json': 'd42a78c271e41809dcaac5f587116ce885d4eef4065f5afc5baed8bbfe2f4a13',
}
authority_pins = {
    'AUTHORIZATION139.md': 'a43edb91db46e203fc82bcc70555fc46371b1db09848085cd43324ed77386317',
    'FIRST-CELL139.md': '1f4140500eff7e7c71c1d43ee54921404a672a91074a1607f610c648bae4f74b',
    'IMPLEMENTATION151-HANDOFF.json': '8b1dc88c50adeb1fa68c39cc20437cddc05c4b5d529dbd40cddf593d691240df',
    'PROVENANCE-REPAIR148-REVIEW152.json': '1799cbf9d39e3899244f748d4380ac1fbd2e13957f9b6cfc48696277e2af5359',
    'IMPLEMENTATION147-REVIEW149.json': 'ee2a7332009e79e0ef3dfec464121a50decf90f7d49a7a3a826210cd775fadfc',
    'PRIMITIVE141-REVIEW142.json': 'f2eb32c34ee2200042b191a81bf18c6725ce6c5c99eff9e09e8540e6fe4f87cd',
    'IMPLEMENTATION143-HANDOFF.json': 'b21a1bd9ae037417c9b2037761c17fbf974e8ce925a7386d43e2002a4d05516d',
    'PROVENANCE-REPAIR148-VALIDATION150.json': '9a7883b3152fa89aa351a2d456af45e5ddc0ebae2ab3ae38be833caaf596826c',
    'NATIVE116-PARENT-HANDOFF.json': '1d4d870e820a51b5fe47aebb01d261d8ca7ca4fd8aeecedbb8b3a01ca36bdded',
}

def digest(path):
    hasher = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            hasher.update(block)
    return hasher.hexdigest()

phase = sys.argv[1]
record = {
    'phase': phase,
    'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'pin_qualification': 'Parent-derived from supplied local HANDOFF151 metadata; not independently supplied historical pins. Endpoint custody only; no target/source/compiler/bootstrap closure.',
    'free_bytes': shutil.disk_usage('/private/tmp').free,
    'pins': [],
    'payload_mismatches': [],
    'archive_mismatches': [],
    'authority_inputs': [],
}
for relative, expected in pins.items():
    actual = digest(root / relative)
    record['pins'].append({'path': relative, 'expected': expected, 'actual': actual, 'match': actual == expected})
manifest = json.loads((root / 'MANIFEST151.json').read_text())
record['payload_count'] = len(manifest)
record['payload_bytes'] = sum(entry['bytes'] for entry in manifest)
for entry in manifest:
    path = root / entry['path']
    if not path.is_file() or path.stat().st_size != entry['bytes'] or digest(path) != entry['sha256']:
        record['payload_mismatches'].append(entry['path'])
expected_archive = {entry['path']: entry['sha256'] for entry in manifest}
for relative in ['MANIFEST151.json', 'SEAL.json', 'SEAL.sha256']:
    expected_archive[relative] = digest(root / relative)
archive_names = []
with tarfile.open(root / 'HANDOFF151.tar.gz', 'r:gz') as archive:
    for member in archive:
        archive_names.append(member.name)
        stream = archive.extractfile(member) if member.isfile() else None
        actual = hashlib.sha256(stream.read()).hexdigest() if stream else None
        if member.name not in expected_archive or actual != expected_archive[member.name]:
            record['archive_mismatches'].append(member.name)
record['archive_count'] = len(archive_names)
record['archive_duplicates'] = len(archive_names) - len(set(archive_names))
record['archive_missing'] = sorted(set(expected_archive) - set(archive_names))
record['seal_checksum_record'] = (root / 'SEAL.sha256').read_text().strip()
record['seal_checksum_record_valid'] = record['seal_checksum_record'].split()[0] == pins['SEAL.json']
for relative, expected in authority_pins.items():
    path = workspace / 'evidence/redb-native-mir-campaign115' / relative
    actual = digest(path)
    record['authority_inputs'].append({'path': str(path), 'bytes': path.stat().st_size, 'sha256': actual, 'expected_local_measurement': expected, 'match': actual == expected, 'qualification': 'Locally measured before content read; no independent historical pin supplied.'})
record['success'] = all(entry['match'] for entry in record['pins'] + record['authority_inputs']) and record['seal_checksum_record_valid'] and not any(record[key] for key in ['payload_mismatches', 'archive_mismatches', 'archive_duplicates', 'archive_missing']) and record['free_bytes'] > 16 * 1024**3
(scratch / ('authentication-' + phase + '.json')).write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record, indent=2))
if not record['success']:
    raise SystemExit(1)
