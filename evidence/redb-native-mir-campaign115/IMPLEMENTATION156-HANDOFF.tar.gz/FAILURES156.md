# Retained failures and bounded outcomes156

- Number2 compiler-allocation-build exits101: integer indexing of rustc FieldIdx
  fields fails E0277. Number3 repairs this with typed field iteration and builds.
- Number5 initial-proof and number9 event-proof exit1 at u8 into_typed alignment.
  The broad layout broadcast group does not include the existing align_of_u8
  theorem. Number10 imports that theorem explicitly; later positives verify.
- Number6 builds a transient candidate whose backend block observation is read
  back from an internally constructed JSON value. Number7 repairs that to use
  the original typed block value BEFORE any event-cut analysis uses the transient
  build. It is retained as a discarded correspondence-development version.
- Number12 aligned-proof and number15 final-normal verify7 units. Later source
  adds explicit conservation and pure typed traversal bookkeeping; final26 and
  restored33 again verify7 units. These do not add original/native-body credit.
- Number21's earlier wrong-provenance control also fails the foreign allocator's
  layout precondition. It is a CONFOUNDED negative, not the final isolated result.
  Number20's two-byte extent control can also violate subset at the last index.
  Number24 repairs both: foreign allocation uses the proven issuer, and extent
  uses an interior-index guard. Final28 fails exact u8 range plus complement
  postcondition; final29 fails only full-pointer identity, after equal-address
  assertion and valid foreign allocation. No unrelated allocation is used by
  the normal generator as a claimed original-event witness.
- Final27 offset,28 extent,29 provenance and31 byte reject VCs with primary SMT
  unknown/incomplete quantifiers. None is represented as a SAT counterexample.
  Final30 missing-issuance rejects uninitialized real tracked raw/deallocation
  tokens with E0381, before SMT. These are lowering faults, not original mutants.
- Every source-binding invocation intentionally exits1 at native-export refusal.
  It may produce separate generated proof input, but no requested native rmeta.
  Restored32 again observes the unchanged original and refuses its export.
- Two uninstrumented custody-redaction attempts (first apply_patch context
  failure, second repair success) are conservatively added to the command total;
  CUSTODY156.md states their exact evidence limits. They change no proof program.

No timeout, state-changing process signal, original application/test execution,
network request, law adoption or parent/native source integration occurs.
Full numbered-command statuses and raw streams remain in each receipt/file;
the setup/custody gaps are disclosed rather than fabricated retrospectively.
