# Task156: actual original issuance remains OPEN

## Result, without substitution of the target

The requested SAME-ORIGINAL-EVENT allocation-to-cell issuance is NOT established.
Original executable whole bodies verified: 0. Original allocation occurrences
accepted: 0. Original store occurrences accepted unconditionally: 0. New laws
installed/adopted: 0. Original export is refused. All18 campaign94 cells remain
OPEN, including full original two-phase acknowledged durability.

The checked subset is stronger than a permission-input decomposition helper:
ordinary generated executable code calls the inherited vstd allocate itself,
obtains real affine PointsToRaw and Dealloc, splits a genuine one-byte payload
cell, proves full specification-pointer identity and borrows it into the exact
154 conditional store. It takes NO PointsTo/PointsToRaw/Dealloc caller inputs.
However that authored allocation is not proven to be THIS original allocation
event. It earns no original allocation/body/store credit. No equality to an
independently allocated original pointer is assumed or claimed.

Final normal and restoration each report 7 verified, 0 errors. These are verifier
units, NOT seven native bodies. There are five distinct generated executable
bodies: the reused154 generic store plus four new156 helpers (allocate,
allocation-to-store, reclaim, and zero-length). One additional open spec
function defines the proposed padded size. Repeated runs do not add bodies.
The four new helpers are conditional, authored/generated, not native Arc bodies.

## Source-connected implementation

The fresh candidate is copied from the authenticated154 candidate. Only its
scratch permission154 binary source and new allocation156.rs are changed.
The exact154 typed store selection is reused. Its actual base/index/operand
locals are carried in compiler data, not selected by their observed numbers.
The root is the unchanged original zero_filled_arc; the original resolved
Arc-returning route still selects from_iter_exact::<u8, RepeatN<u8>>.

The added typed analysis connects its unique allocate_for_slice call result to
the raw ArcInner.data projection, its thin-pointer cast and the existing Offset
base. It checks unique plain/call result definitions for the allocation result,
normal-graph domination, concrete allocation closure/runtime call, actual false
zeroed constant, unique __rust_alloc call, u8 pointer return and inlined alloc
owner. Records include actual Instances, substitutions, MIR, paths, call operands,
normal targets, unwind contexts and source scopes. None is resource authority.

Compiler layout_of on actual ArcInner<[u8]> gives payload offset16, alignment8,
strong offset0 and weak offset8 for this recorded aarch64-apple-darwin target.
Constants are emitted FROM this compiler query, not assumed as portable laws.
The proposed normal size is offset + ceil(len/align)*align. Its validity,
positive header allocation and arithmetic bounds are proved in the GENERATED
program under explicit scalar len constraints; actual native array/extend/pad
refinement and branch premises remain OPEN. len0 still allocates the header and
has an empty payload domain; a concrete generated zero-length reclaim verifies.

The main source traversal now de-duplicates real compiler Instances; Debug
strings are emitted only as evidence in that traversal. This does not establish
a debug-free/general/native-admission theorem. Inherited unique_definition,
inline identity and indirect-effect/alias coverage remain limited. No general
alias/history engine or automatic native producer is claimed.

## Checked resources, and what the model does not cover

All generated resources originate in the inherited allocate NORMAL RETURN.
The same returned base/provenance flows through with_addr's thin-pointer
specification to the proposed Offset address. Bounded index and object/end
arithmetic are checked for arbitrary scalar index<len, not assumed to hold for
the original iterator. Exact one-byte split and into_typed are consumptive.

The result retains disjoint raw header and payload complement, their exact
domains, pairwise disjointness, full-domain union, same live provenance and the
matching affine Dealloc. A real header-byte token is temporarily borrowed as
154's explicit disjoint frame, is proved unchanged/uninitialized, and is rejoined
with the rest of the raw header. A checked reclaim helper forgets only the u8
value, rejoins the entire domain and consumes the matching Dealloc in deallocate.

This RAW UNINITIALIZED HEADER is NOT the native strong/weak initialization.
Native AtomicUsize construction/writes, metadata, guard construction, previous
loop elements and effects of iterator/caller activations are NOT silently
simulated. Raw complement alone does not retain prior initialized-value facts.
No native Arc count, valid caller, global map/cache or callback frame is assumed.

## Controls and restoration

Final controls use the same final compiler and generated template. Wrong offset
selects the allocation/header start instead of the payload cell; split subset
and frame disjointness VCs reject. Wrong extent uses a two-byte split under an
explicit interior-index guard, so the final failure includes the exact u8
into_typed one-byte range premise, not an invalid-layout allocation failure.

Wrong provenance uses a SECOND inherited allocation ONLY AS A NEGATIVE, replaces
its numeric address with the desired cell address and proves address equality
before failing the full specification-pointer equality assertion. No distinct
provenance/freshness axiom is added: the test checks that foreign-event provenance
cannot be assumed identical. The earlier confounded version also failed a layout
premise; it remains retained, but the final isolated control does not.

Wrong byte writes byte XOR1 and rejects the promised Init(byte) postcondition.
For these semantic controls primary SMT replies are unknown (incomplete
quantifiers), NOT SAT. They are expected fail-closed VC rejections at the recorded
sites, not concrete counterexamples or exhaustive mutation proofs. Missing
issuance removes the actual allocator call and tries to use uninitialized real
PointsToRaw/Dealloc; ordinary WF/lifetime checking rejects E0381, not SMT.

Independent final normal regeneration restores byte-identical generated source
and verification succeeds again. Source/negative diffs, input hashes and complete
VIR/SST/AIR/SMT/transcripts are retained. No original program/source mutant or
original application/test execution occurs.

## Exact remaining cut

BRIDGE156.md fixes G1/G2: a checked, source-specific refinement from THIS original
nonzero/nonzeroed Global allocation NORMAL-SUCCESS transition to the EXACT
inherited allocate transition, with ONE allocation event and the SAME executable
return pointer and affine resource issuance. The candidate observes the native
event and proves a separate inherited allocation program; it does not prove
that refinement. Source resemblance/the same alloc leaf does not discharge it.
No grant, external native leaf spec, assumed token or primitive law is installed
to hide this gap.153/155 permit conditional contracts, not bridge acceptance.

After G1/G2, actual successful combined layout and header/metadata resource flow,
RepeatN/enumeration length/index proof, loop/prior values, native caller/Arc
wrapping/cleanup and later cache/buffer/durability composition remain checked
dependencies. This report does not demand hypothetical whole-Rust semantics to
retain the useful conditional subset, and does not relabel that subset as the
original task's achieved milestone.

## Accounting and custody

The original45-minute clock starts 2026-11-08T23:02:38Z. No allowance is reused.
Final HANDOFF156.json gives actual counts, elapsed time, byte-readback archive
pins and explicit slot release AFTER all charged children are reaped. The
numbered runner commands, including setup/build failures and sealing, plus two
conservatively charged custody-redaction attempts remain within36. Bounds are
jobs1/offline/locked, build<=600s, proof<=180s; no network/Git writes, native
integration, application execution, subdelegation, admission weakening or axioms.

Free disk is enforced strictly>16GiB at every recorded sample, and both logical
and allocated scratch remain<=3GiB. This is sampled enforcement, not a continuous
filesystem theorem. Only owned unreaped process groups can be signaled; all
recorded children are reaped and group-absence probes are retained. Signal0 is
an absence observation, not a general descendant-containment proof.

Full compiler/proof argv, minimal environment, clocks, status, streams, source
history and argument endpoints are retained. Setup inherited a credential-valued
environment variable; its VALUE was redacted before packaging and never forwarded
to compiler/verifier children. Its name and redaction time remain. Thus setup
environment value completeness is qualified. The first redaction edit failed
apply_patch context and the repair succeeded; they are conservatively charged
custody attempts, with tool-transcript-only clocks/raw streams as qualified in
CUSTODY156.md. They do not alter any proof/source/resource fact.

Supplied154 archive/manifest/seal pins and all1587 regular unique archive members
are byte-readback checked.155 parent disposition is a separate retained authority
endpoint. Local source/library/tool/binary hashes are consistency evidence, NOT
historical authentication, bootstrap or proof that selected source produced the
loaded compiler/vstd/sysroot. Target binaries are inventoried, not shipped as a
bootstrap bundle. Archive manifest excludes its own archive and postarchive seal,
current seal-command streams/receipt and final handoff/release; these are retained
separately without circular provenance. No automatic follow-up/review chain runs.
