# Custody qualifications156

Numbered runner commands2 onward record compiler/build/verifier/seal
children with full argv/minimal env/cwd, wall/monotonic clocks, status, raw streams,
resource samples, input endpoints and owned-process reaping/absence observations.
Source history retains effective compiler and runner versions for each command.
Setup1 has argv/environment/start/end/status/resource endpoints, but its stdout
and stderr and execution-container process custody are only tool-transcript
observations, not private runner streams/process-group records. Its cwd is
available as recorded environment PWD rather than a separate cwd field.
First build source bytes were copied before its repair and are matched by hashes;
this establishes available matching bytes, not historical interpreter attestation.

Two additional custody-redaction invocations are CONSERVATIVELY charged against
the36-command ceiling, although they do not build/verify/test native code. Their
exact execution clocks/environment/raw streams are only in the tool transcript,
not a contemporaneous runner record. No reconstructed exact-clock claim is made.

First argv: python3 /private/tmp/redact156.py. It fails with status1 after
apply_patch reports: Failed to find context '-51,7 +51,7 @@'. The generated custom
patch incorrectly retained unified-diff numeric hunk syntax. Repair adds re and
replaces numeric hunk headers with @@. The second identical argv succeeds with
status0 and names only SAKANA_API_KEY as redacted. No credential value is printed,
forwarded to compiler/proof children or retained in this package. The script's
initial version is reconstructed explicitly from the retained repaired source and
known repair delta; no historical script hash or loaded-script continuity theorem
is asserted for those two uninstrumented custody edits.

The first failure occurs before numbered command16's recorded launch; repaired
redaction time is in setup.receipt.json.env_redaction. These are time bounds, not
invented nanosecond endpoints. Setup's recorded original environment is therefore
complete by key but not by credential value. All numbered compiler/verifier
children use the distinct recorded minimal154 environment, which lacks this key.

Simple inspection, apply_patch source/evidence edits and read-only inventory
discovery are not relabeled as compiler tests. No failed compiler/test is omitted.
MANIFEST156.json covers payloads only. Current archive-command result/streams,
SEAL.json/HANDOFF156.json/RELEASE156.json are separate postarchive endpoints;
no archive or manifest claims to authenticate its own future finalization.
