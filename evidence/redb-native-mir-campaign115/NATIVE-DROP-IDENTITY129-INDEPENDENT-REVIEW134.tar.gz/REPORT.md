# Review134: independent review of completed task129

## Findings and objections first

1. **No new blocking P1/P2 finding is established for the stated bounded diagnostic contract.** The actual seven registered cases match their expected statuses and substantive evidence. The positive case contains a genuine recorded nonempty drop-glue identity result and a separately observed destructor definition, not merely a guessed destructor name or the exit code 2. Verdict: **DIAGNOSTIC_CONTRACT_SUPPORTED_ONLY**.
2. **Object to any upgrade to completed error-free compiler analysis.** Immutable raw, STARTED, sidecar, destructor and callback error snapshots remain PENDING. The final report records only RUN_COMPILER_RETURNED_WITHOUT_PANIC and explicitly retains NO_LIVE_TCX_AFTER_RETURN_ERROR_FINALITY_NOT_ASSERTED. False error flags at callback sampling points are not final absence of compiler errors/delayed bugs. This is an explicit retained limitation, not a newly found discrepancy.
3. **Object to interpreting identity as mapping, execution, ownership or primitive semantics.** bb16/noncleanup and bb19/cleanup remain different CFG contexts. Both e78 observations retain scope=None and zero exact Scope.value_expression=e78 edges despite the complete 37-edge scope capture. No HirId join repairs that absence; dynamic-event uniqueness, native/HIR/VIR correspondence, resource ownership/linearity, glue execution and primitive effects remain unestablished.
4. **Coverage objection remains open:** source/helper tests, genuine resolver Err/panic and fatal-after-durable-STARTED behavior were not dynamically validated by task129 and were not executed in this review. The reproduced EACCES control tests raw-publication failure, not a resolver failure. No broader failure-path certification is granted.

## Authentication and review boundary

- Supplied root: /private/tmp/drop-identity129-20261108-giDfL1. REPORT.md, SEAL.json and SEALED-MANIFEST.json were read as data, not trusted as conclusions.
- HANDOFF.tar.gz matches the user-supplied SHA256 `9b3a53d589b5b7b02cede0c6a15838e8c166289a51330a2d740d73d2e421d830`.
- The archive was streamed without extraction. All 236 members are regular, safe relative, uniquely named payloads with no links/special files. The exact set is the 235 task129 manifest records plus SEALED-MANIFEST.json; every archived byte hash matches its corresponding authenticated on-disk payload.
- The selected-input ledger covers all task129 sealed payloads/final seal bindings, bundled originals, all selected build127 payload/source records, registry/disposition, actual observer and loaded compiler-library identities, the wrapper API and applicable source instructions. Entry and exit ledgers record current hashes and stable-stat observations. They do not establish historical continuous custody or a reproducible/attested compiler bootstrap.
- The independently selected task129 payloads include raw streams, plans, receipts, process records, setup failures, source/receipt bundle, task129 entry/exit/library authentication, independent-check inputs and resource/accounting evidence. Unrelated historical122 records are retained and their recorded claims are inspectable inside authenticated task129 payloads; review134 does not pretend to have freshly rehashed every unrelated historical122 source.
- Actual binary identity is externally pinned/authenticated; this source/receipt archive is not represented as a self-contained observer/compiler binary distribution.
- Applicable instructions include /private/tmp/redb-original-crate-preflight115/redb/AGENTS.md. Its test requirement expressly excludes report/analysis work without code changes. No source, parent evidence or completed-root file was written.

## Exact source and binary bindings

| Input | Authenticated SHA256 |
|---|---|
| Pre-execution registry DROP-IDENTITY129-PREEXECUTION-EXPECTATIONS.json | a03ceb48ef65602b275e4cb1c0dc0472e0dee28115d8381c76e8ac3d13b58d9a |
| Fixed build127 observer executable | ac2862745c6fa41943c56658bb626bfdd0797ee5ffb1e213ca2a6649b8545942 |
| Fixed observer main.rs | b03b2bc43440a36bd87280d8f38139fe8f4ec71f05f6f126e6d1840a4f9c7830 |
| Fixed observer identity.rs | 5c10ee69f54eca70073ae1109c63585599c5ab44fbd0ad4e8fed5ef847b4a8c2 |
| checked_drop_origins.rs | 1aa55b6d95997e1950cc548119ae6b9b83ff3c69af98c36f0790cff895c0ca79 |
| Source disposition | 90d84b8d6ea0021a31972b4bb6a6c28006c6a38cd741af8c3ba054c13309d463 |
| Build127 manifest | fea7aad3aa234696df44dcae52a081eba8384b0e9d07374df67f7036d9115a31 |

The registry binds the initially reviewed identity hash a2c81a5e084bbeca67c390c69ce0a4b84b607e52c1b408457ebe2dd7e9718d7f and expressly permits a separate source disposition. Independent byte comparison confirms that the fixed file differs by exactly the one disposed replacement: `instantiate_identity() == exact_ty` becomes `instantiate_identity().skip_norm_wip() == exact_ty`. The authenticated local compiler API unnormalized.rs (SHA256 2866242de5ce141596ee0e95b17159013d5d7679eea9e9dfb83de4133fab2fbd) returns self.value at line 71; this addition performs no normalization query. Build127's E0308 failure, successful second build receipt, source identity, depfile index and binary binding remain coherent; no new build or source-only review126 rerun occurred.

Each task129 case has its own preexecution plan, complete argv/environment, the same executable hash, external clocks, raw stdout/stderr and wait4 receipt. Actual dyld-selected observer/rustc_driver/LLVM records agree with the authenticated files. OS shared-cache image observations are not silently upgraded into independent full cache-content attestation.

## Actual cases and 9/9 accounting

| Registered case | Actual / expected exit | Charge | Substantive result |
|---|---:|---:|---|
| old_five_pair_mode | 2 / 2 | 3 | One original capture; optional_identity absent; native proof refused. |
| exact_header_identity | 2 / 2 | 4 | Raw/refusal, STARTED, one resolver result, separate destructor, final report. |
| wrong_qualified_target | 65 / 65 | 5 | WrongOwner::write_header; raw/refusal survive; resolver0; no STARTED. |
| seeded_sidecar | 64 / 64 | 6 | Exact original 38 seed bytes retained; no new raw/STARTED/report. |
| aliased_report_and_raw | 64 / 64 | 7 | Source preflight alias refusal; no published outputs. |
| raw_publication_permission_failure | 70 / 70 | 8 | Genuine EACCES; raw absent; refusal and failure evidence retained; resolver0. |
| extra_link_argument | 64 / 64 | 9 | Exact grammar rejects --emit=link; no outputs. |

Charges 1 and 2 are conservatively retained setup-only failures: original shell glob failure and original Python KeyError('files'), respectively. Both preserved stderr payloads match SETUP-FAILURES.json verbatim; the first enclosing shell's final status 0 is not misdescribed as an observer run. Seven wait4 raw statuses decode to the listed exits. All seven recorded children were reaped and their owned process groups reported absent. Total 2+7=9/9, remaining0; build127 allowances stay exhausted and original116 allowances are unchanged, not reset. No original116 completion is inferred. The completed task129 slot-release record is read-only evidence; review134 does not acquire or consume the parent's reserved compiler slot.

## Persistence gate and failure evidence

At fixed identity.rs:249, publish serializes complete JSON, creates a fresh staging file, writes, flushes and syncs it, hard-links without clobber, syncs the parent directory and performs exact readback. At identity.rs:450, the raw snapshot includes explicit proof refusal and a NOT_STARTED marker. Its successful publication returns before STARTED construction at identity.rs:494. STARTED uses the same publication routine and must return before resolve is called at identity.rs:509. Instance::try_resolve appears only inside resolve at identity.rs:333. This is the source-bound basis for the durable-before-resolver ordering; external file probes constrain observation time, not an invented universal filesystem history.

The actual STARTED receipt's raw_complete_utf8 re-encodes byte-for-byte to the entire 152824-byte raw.json, and raw_bytes is exactly 152824. This is full-byte binding, not a digest-only receipt or selected-field reconstruction. Raw/STARTED/sidecar typed owner+ADT tokens agree exactly; raw captures also equal final-report captures. STARTED's durable incompleteness semantics remain explicit if a final sidecar were missing. JSON serialization supplies valid UTF8 here, so the source's from_utf8_lossy does not lose these actual bytes.

The permission control uses the fresh canonical raw-only directory owned by uid501, mode0555, with recorded access_write=false. Current directory identity/mode agree. Both authenticated sidecar and final report preserve `raw_persistence={status:IO_FAILURE,error:Permission denied (os error 13)}`. Both say REFUSED_RAW_REFUSAL_PERSISTENCE_FAILED, glue/destructor NOT_QUERIED and resolver invocation count0. Neither raw nor STARTED exists. The error branch at identity.rs:473 publishes the sidecar and returns before calling resolve, not merely before a second query. Its final report preserves the complete original capture, both sites and refusal; the refusal is correctly NOT_YET_DURABLE in the failed raw snapshot channel, not falsely relabeled durable there. Sidecar publication itself succeeds and is recorded durable in the final report. Raw stdout/stderr and original permission-setup evidence remain intact. This does not test hostile directory replacement.

The alias/seed/extra-argument compiler-callback refusals are supported by the fixed pre-run main/configure branches, matching statuses and preserved raw diagnostics/output absence; review134 did not add independent callback instrumentation. A sidecar's own `sidecar_publication=NOT_ATTEMPTED` is its pre-publication snapshot, not a claim that the file failed to publish: final report updates it to DURABLE_NO_CLOBBER.

## Actual identities without context merger

- The actual resolver record is `Shim(DropGlue(DefId(2:3436 ~ core[2525]::ptr::drop_glue), Some(tree_store::page_store::cached_file::WritablePage)))`, with a complete Instance debug record. Both requested and returned full argument lists are `[tree_store::page_store::cached_file::WritablePage]`; recorded typed equality and lang-item DefId equality are true. Empty glue, Ok(None), Err and unexpected kinds are not relabeled positive by the reviewed matching code.
- Independently, adt.destructor(tcx) supplies local `<tree_store::page_store::cached_file::WritablePage as std::ops::Drop>::drop`, cached_file.rs:41, DefId(0:3684); its impl is at line40, DefId(0:3683), with actual implementation Self equal to the exact ADT. This is not the glue DefId and no separate destructor Instance query is claimed. The source body calls return_value, but its runtime/resource behavior is not established by this review.
- The result is shared by type/environment but attached separately to bb16 (noncleanup, target17, Cleanup(bb20)) and bb19 (cleanup, target20, Terminate(InCleanup)), both for unprojected local20. One resolver call is not two dynamic destructor events, and same-type identity is not permission to merge these contexts.
- Both raw matching temporary observations retain expression e78, scope=None, exact matching edges=[], matching_status=COMPLETE_EMPTY. The whole capture's COMPLETE_NONEMPTY state and 37 edges do not fill the missing e78 edge. Main.rs:59 filters actual value_expression equality within the same body/session; it supplies no HirId-based alternative join.

## Verification, limits and verdict

INDEPENDENT-CHECKS.json records 82/82 passing independent static/data-only checks, separate from task129's own validator. Task129 diagnostic129.py, validate_seal129.py, observer/helper binaries, compiler/Cargo/verifier/solver and original application were never executed by review134. No network, Git, subdelegation, parent writes, cleanup, source edits, native execution or proof execution occurred. Scratch remains fresh and bounded; ACCOUNTING.json and SEAL.json record sampled disk/scratch and elapsed bounds, not a fictitious continuous measurement guarantee.

The contract is supported only as an authenticated, source-bound, actually observed **identity diagnostic with fail-closed publication controls**. It is not approval of final error-free compiler analysis, native semantics, mapping/resource ownership, destructor/glue execution or any theorem. All18 remain OPEN; native/resource/trust/proof credits are all0. Resolver Err/panic/fatal-after-start and source/runtime test gaps remain UNVALIDATED. Original116 remains interrupted with unchanged allowances. No allowance reset, automatic followup or compiler-slot work is authorized or scheduled.
