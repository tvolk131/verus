# Parent source-only quarantine repair167

Repairs the narrow F165-1 P2 mechanism in fresh scratch, without touching
sealed164, live166, original application or parent compiler sources. Retain
review165's disabled-development-only disposition, not native or issuer approval.

The attribute marker test remains. Its fallback now invokes the canonical
whole-function expression visitor, not only body traversal. The existing
expression-only helper remains available for its separate diagnostic callers.

Two new tests are authored, UNCOMPILED/UNEXECUTED here. The first serializes and
deserializes unmarked whole functions containing a nested allocator opcode in
13 locations: require, both ensure lists, returns, decrease, decrease_when,
all three mask forms, atomic_update, unwind condition, body and fndef_axioms.
It checks import/export/native-source quarantine for each. Except the body case,
these functions have no body. The second is an unmarked opcode-free positive.
Fixtures exercise syntactic quarantine before WF, not valid contract execution.
They are unconditional tests, intended for both default-off and feature-on runs.

No compiler, Cargo, test, verifier, solver, original-MIR analysis or application
execution occurs in167;166 exclusively owns the heavy slot. The immutable patch
will be supplied for166's final source and relevant tests within its unchanged
allowance. Do not call this runtime closure of F165-1 before actual validation.

Review165's separate validity-changing-transmute safety objection is not repaired
here. It has been forwarded to166 for conservative validity-direction checks
or genuine path obligations in both scalar handlers before operative reuse.
No caller validity premise, primitive law, memory frame or native authority is
introduced. G1/G2 and all18 OPEN; schema1; operative laws/issuance/accepted
original allocations/stores/bodies0. Native export REFUSED.

Sealing reauthenticates the three unchanged baseline files against164's pinned
manifest and review165's sealed records. Initial copying was not separately
timestamped; no continuous custody is claimed. All authored final source bytes,
exact164-relative patch, input hashes and this report are retained/read back.
