use crate::ast::*;
use crate::ast_util::{mk_tuple_typ, types_equal};
use crate::ast_visitor::{VisitorControlFlow, expr_visitor_walk};
use crate::def::Spanned;
use crate::messages::{Span, error};
use crate::sst::{Dest, Exps, Stm, StmX};
use std::sync::Arc;

pub const ISSUANCE_GATE164: &str = "PENDING_EXACT_CODE_REVIEW_AND_NATIVE_CORRESPONDENCE";

pub fn admission_error(span: &Span) -> VirErr {
    error(span, "native allocator164: exact-code review, runtime binding, dynamic native activation/event and full-pointer correspondence remain unestablished; no issuer application or AIR assumption is permitted")
}

fn raw_type(name: &str) -> Typ {
    Arc::new(TypX::Datatype(Dt::Path(Arc::new(PathX {
        krate: CrateId::Vstd,
        segments: Arc::new(vec![Arc::new("raw_ptr".into()), Arc::new(name.into())]),
    })), Arc::new(vec![]), Arc::new(vec![])))
}

pub fn result_type() -> Typ {
    let tracked = |name| Arc::new(TypX::Decorate(TypDecoration::Tracked, None, raw_type(name)));
    let pointer = Arc::new(TypX::Primitive(Primitive::Ptr,
        Arc::new(vec![Arc::new(TypX::Int(IntRange::U(8)))])));
    mk_tuple_typ(&Arc::new(vec![pointer, tracked("PointsToRaw"), tracked("Dealloc")]))
}

pub fn validate_call(expr: &Expr, args: &Exprs, body: &Option<Expr>) -> Result<(), VirErr> {
    if !cfg!(feature = "native-resource-adapter164") {
        return Err(error(&expr.span, "native allocator164 is disabled"));
    }
    if body.is_some() || args.len() != 2 || !types_equal(&expr.typ, &result_type())
        || args.iter().any(|arg| !matches!(&*arg.typ, TypX::Int(IntRange::USize)))
    {
        return Err(error(&expr.span, "native allocator164 has a fixed signature and no supplied relation/body"));
    }
    Ok(())
}

pub fn contains_native_call(body: &Expr) -> bool {
    let mut found = false;
    expr_visitor_walk(body, &mut |expr| {
        if matches!(&expr.x, ExprX::Call { target: CallTarget::NativeAllocator164, .. }) {
            found = true;
        }
        VisitorControlFlow::Recurse
    });
    found
}

pub fn function_contains_native_call(function: &Function) -> bool {
    let mut scope = air::scope_map::ScopeMap::new();
    matches!(
        crate::ast_visitor::function_visitor_dfs(function, &mut scope, &mut |_, expr| {
            if matches!(&expr.x, ExprX::Call { target: CallTarget::NativeAllocator164, .. }) {
                VisitorControlFlow::Stop(())
            } else {
                VisitorControlFlow::Recurse
            }
        }),
        VisitorControlFlow::Stop(())
    )
}

pub(crate) fn sst_call(span: &Span, args: Exps, dest: Dest) -> Result<Stm, VirErr> {
    if !cfg!(feature = "native-resource-adapter164") || args.len() != 2
        || !types_equal(&dest.dest.typ, &result_type()) || !dest.is_init
        || args.iter().any(|arg| !matches!(&*arg.typ, TypX::Int(IntRange::USize)))
    {
        return Err(error(span, "native allocator164 SST signature/binder mismatch"));
    }
    Ok(Spanned::new(span.clone(), StmX::Call {
        fun: crate::sst::CallTarget::NativeAllocator164,
        resolved_method: None, mode: Mode::Exec, is_trait_default: None,
        typ_args: Arc::new(vec![]), args, split: None, dest: Some(dest),
        assert_id: None, body: None,
    }))
}

#[cfg(feature = "native-resource-adapter164")]
pub fn review_lower_to_sst(function: Function) -> Result<crate::sst::KrateSst, VirErr> {
    use crate::context::{Ctx, GlobalCtx, WarningCtx};
    use std::collections::{HashMap, HashSet};
    let span = function.span.clone();
    let module = Spanned::new(span.clone(), ModuleX {
        path: Arc::new(PathX { krate: function.x.name.path.krate.clone(), segments: Arc::new(vec![]) }),
        reveals: None,
    });
    let mut source = Arc::new(KrateX {
        functions: vec![function], reveal_groups: vec![], datatypes: vec![], traits: vec![],
        trait_impls: vec![], assoc_type_impls: vec![], modules: vec![module.clone()],
        external_fns: vec![], external_types: vec![], path_as_rust_names: vec![], opaque_types: vec![],
        arch: Arch { word_bits: ArchWordBits::Exactly(64) },
    });
    if source.functions.iter().any(|function| function.x.body.as_ref().is_some_and(contains_native_call)) {
        return Err(error(&span, "review harness has no verifier-loaded vstd raw-pointer datatype definitions; native resource continuation refused"));
    }
    let functions = Arc::new(source.functions.iter().map(|function|
        (function.x.name.clone(), crate::ast_util::function_to_stub(function))).collect::<HashMap<_, _>>());
    let merged = crate::traits::merge_external_traits(&source, &[])?;
    let (initial_wf, deferred, _) = crate::well_formed::check_crate_initial(
        &source, &[], functions.clone(), merged, true,
    );
    if let Some(failure) = deferred.first() { return Err(failure.clone()); }
    let initial_wf = initial_wf.map_err(|failure| failure.errors.first().cloned()
        .unwrap_or_else(|| error(&span, "native164 initial WF boundary refused")))?;
    let demote = crate::traits::DemoteTraitLookup::new(&source, &[], &functions);
    let warning_ctx = WarningCtx { fun_warn_configs: source.functions.iter().map(|function|
        (function.x.name.clone(), Some(crate::context::WarningConfig(vec![])))).collect() };
    let mut checked_functions = Vec::new();
    for function in &source.functions {
        let (wf, deferred, _) = crate::well_formed::check_function(
            &source, functions.clone(), initial_wf.lookup.clone(), &demote,
            function, &warning_ctx, true, false,
        );
        if let Some(failure) = deferred.first() { return Err(failure.clone()); }
        wf.map_err(|failure| failure.errors.first().cloned()
            .unwrap_or_else(|| error(&span, "native164 function WF boundary refused")))?;
        let (function, _, _) = crate::modes::check_function(
            functions.clone(), initial_wf.lookup.clone(), function, &demote,
        ).map_err(|failures| failures.first().cloned()
            .unwrap_or_else(|| error(&span, "native164 mode check refused")))?;
        checked_functions.push(function);
    }
    Arc::make_mut(&mut source).functions = checked_functions;
    let global = |krate: &Krate, simplified| GlobalCtx::new(
        krate, krate.functions[0].x.name.path.krate.clone(), span.clone(), 10.0,
        Arc::new(std::sync::Mutex::new(None)), Arc::new(std::sync::Mutex::new(None)),
        Arc::new(WarningCtx { fun_warn_configs: HashMap::new() }),
        air::context::SmtSolver::Z3, simplified, false, false, false, false,
    );
    let mut initial_global = global(&source, false)?;
    let simplified = crate::ast_simplify::simplify_krate(&mut initial_global, &source)?;
    let mut ctx = Ctx::new(&simplified, global(&simplified, true)?, module,
        vec![], vec![], HashSet::new(), crate::prune::UsedBuiltins {
            uses_array: false, uses_bytestr: false, uses_pointee_metadata: false, uses_ieee_float: false,
        }, vec![], vec![])?;
    let functions = simplified.functions.iter().map(|function| function.x.name.clone()).collect();
    crate::ast_to_sst_crate::ast_to_sst_krate(&mut ctx, &air::messages::Reporter {}, &functions, &simplified)
}

#[cfg(all(test, feature = "native-resource-adapter164"))]
mod tests {
    use super::*;

    fn span() -> Span {
        Span { raw_span: Arc::new(()), id: 164, data: vec![], as_string: "adapter164 structural test".into() }
    }

    #[test]
    fn fixed_call_lowers_to_real_sst_instruction() {
        let span = span();
        let usize_typ = Arc::new(TypX::Int(IntRange::USize));
        let value = crate::ast::SpannedTyped::new(&span, &usize_typ,
            crate::sst::ExpX::Const(Constant::Int(16.into())));
        let ident = VarIdent(Arc::new("native164_result".into()),
            VarIdentDisambiguate::NativeResource(164));
        let dest = Dest { dest: crate::ast::SpannedTyped::new(&span, &result_type(),
            crate::sst::ExpX::VarLoc(ident)), is_init: true };
        let instruction = sst_call(&span, Arc::new(vec![value.clone(), value]), dest).unwrap();
        assert!(matches!(&instruction.x, StmX::Call {
            fun: crate::sst::CallTarget::NativeAllocator164, mode: Mode::Exec, body: None, ..
        }));
        assert!(admission_error(&span).note.contains("no issuer application"));
    }

    #[test]
    fn raw_port_names_cannot_substitute_for_tracked_outputs() {
        let span = span();
        let raw = mk_tuple_typ(&Arc::new(vec![raw_type("PointsToRaw"), raw_type("Dealloc")]));
        let expr = SpannedTyped::new(&span, &raw, ExprX::Call {
            target: CallTarget::NativeAllocator164, args: Arc::new(vec![]), post_args: None, body: None,
        });
        assert!(validate_call(&expr, &Arc::new(vec![]), &None).is_err());
    }

    #[test]
    fn allocator_instruction_is_detected_without_an_attribute_marker() {
        let span = span();
        let value = SpannedTyped::new(&span, &Arc::new(TypX::Int(IntRange::USize)),
            ExprX::Const(Constant::Int(16.into())));
        let expr = SpannedTyped::new(&span, &result_type(), ExprX::Call {
            target: CallTarget::NativeAllocator164, args: Arc::new(vec![value.clone(), value]),
            post_args: None, body: None,
        });
        assert!(contains_native_call(&expr));
        let encoded = serde_json::to_vec(&expr).unwrap();
        let decoded: Expr = serde_json::from_slice(&encoded).unwrap();
        assert!(contains_native_call(&decoded));
    }
}

#[cfg(all(test, not(feature = "native-resource-adapter164")))]
mod disabled_tests {
    use super::*;

    #[test]
    fn source_feature_cannot_silently_enable_native_instruction() {
        let span = Span { raw_span: Arc::new(()), id: 164, data: vec![], as_string: "default-off164".into() };
        let expr = SpannedTyped::new(&span, &result_type(), ExprX::Call {
            target: CallTarget::NativeAllocator164, args: Arc::new(vec![]), post_args: None, body: None,
        });
        assert!(validate_call(&expr, &Arc::new(vec![]), &None).unwrap_err().note.contains("disabled"));
    }
}
