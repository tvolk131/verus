import datetime
import difflib
import hashlib
import json
from pathlib import Path
import shutil
import tarfile


ROOT = Path('/private/tmp/redb-quarantine167')
BASE = Path('/private/tmp/redb-native-adapter164-20261109-004200')
REVIEW = Path('/private/tmp/redb-native-review165-20261109-014910')
NAMES = ['vir/src/native_resource.rs', 'vir/src/native_resource/adapter164.rs',
    'vir/src/native_resource/tests.rs']


def digest(payload):
    return hashlib.sha256(payload).hexdigest()


manifest_bytes = (BASE / 'MANIFEST164.json').read_bytes()
assert digest(manifest_bytes) == 'd4042d23dea2fcaf56af5fa6f7bfeef303ec66ea6bceb3b7f5a21370efeef7c4'
records = {record['path']: record for record in json.loads(manifest_bytes)['files']}
review_seal = json.loads((REVIEW / 'SEAL165.json').read_text())
inputs = {}
for record in review_seal['files']:
    payload = (REVIEW / record['path']).read_bytes()
    assert len(payload) == record['bytes'] and digest(payload) == record['sha256']
    inputs[str(REVIEW / record['path'])] = digest(payload)
assert inputs[str(REVIEW / 'REPORT165.md')] == '222bc82035c9a7bcb0464c81412c4b7a72e55ad6e344c9010a67b05fc2c83875'
output = ROOT / 'payload'
output.mkdir(exist_ok=False)
patch = ''
for name in NAMES:
    original = BASE / 'candidate' / 'source' / name
    payload = original.read_bytes()
    record = records['candidate/source/' + name]
    assert len(payload) == record['bytes'] and digest(payload) == record['sha256']
    inputs[str(original)] = digest(payload)
    changed = ROOT / 'source' / name
    target = output / 'source' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(changed, target)
    patch += ''.join(difflib.unified_diff(payload.decode().splitlines(True),
        changed.read_text().splitlines(True), fromfile='a/' + name, tofile='b/' + name))
(output / 'repair167.patch').write_text(patch)
(output / 'INPUTS167.json').write_text(json.dumps(inputs, indent=2) + '\n')
for name in ['REPORT167.md', 'seal.py']:
    shutil.copy2(ROOT / name, output / name)
summary = dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    status='SOURCE_ONLY_UNCOMPILED_UNEXECUTED', finding='F165-1',
    patch_sha256=digest((output / 'repair167.patch').read_bytes()),
    authored_tests=2, expression_locations=13, compiler_commands=0,
    heavy_slot='NOT_ACQUIRED_166_EXCLUSIVE', all18='OPEN', operative_laws=0,
    issuance=0, original_native_acceptance=0)
(output / 'SUMMARY167.json').write_text(json.dumps(summary, indent=2) + '\n')
files = []
for path in sorted(output.rglob('*')):
    if path.is_file():
        payload = path.read_bytes()
        files.append(dict(path=str(path.relative_to(output)), bytes=len(payload), sha256=digest(payload)))
manifest = output / 'MANIFEST167.json'
manifest.write_text(json.dumps(files, indent=2) + '\n')
archive = ROOT / 'HANDOFF167.tar.gz'
with archive.open('xb') as stream:
    with tarfile.open(fileobj=stream, mode='w:gz') as package:
        for record in files:
            package.add(output / record['path'], arcname=record['path'], recursive=False)
        package.add(manifest, arcname=manifest.name, recursive=False)
with tarfile.open(archive, 'r:gz') as package:
    members = package.getmembers()
    assert len(members) == len({member.name for member in members}) == len(files) + 1
    for member in members:
        assert member.isfile() and package.extractfile(member).read() == (output / member.name).read_bytes()
for name, expected in inputs.items():
    assert digest(Path(name).read_bytes()) == expected
handoff = dict(summary=summary, root=str(ROOT), archive_sha256=digest(archive.read_bytes()),
    manifest_sha256=digest(manifest.read_bytes()), archive_members=len(members),
    input_endpoint_mismatches=[], qualification='Source-only correction; tests not executed and baseline copy not separately timestamped')
(ROOT / 'HANDOFF167.json').write_text(json.dumps(handoff, indent=2) + '\n')
print(json.dumps(dict(handoff_sha256=digest((ROOT / 'HANDOFF167.json').read_bytes()),
    archive_sha256=handoff['archive_sha256'], patch_sha256=summary['patch_sha256'], archive_members=len(members))))
