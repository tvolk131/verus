import collections
import hashlib
import json
from pathlib import Path
import re

scratch = Path('/private/tmp/review152-20261108-yB2rKJYT')
root = Path('/private/tmp/redb-parent-validation150-20261108-vumyv529')
repair = Path('/private/tmp/redb-provenance-repair148-20261108-j01r2pgl')
report = json.loads((root / 'original-repair148.json').read_text())
selected = set(report['bodies'])
dependency_counts = collections.Counter()
outside_local = set()
bodies = []
for owner, body in report['bodies'].items():
    occurrences = body.get('occurrences', {})
    bound = occurrences.get('Ok', []) if isinstance(occurrences, dict) else []
    anchors = {item['Ok']['location'] for item in bound if 'Ok' in item}
    lowering = body.get('native_lowering', {}).get('Ok', {})
    requirements = lowering.get('requirements', [])
    calls = [item for item in requirements if item.startswith('OriginalCall {')]
    unbound = [item for item in calls if re.search(r'at: (bb\d+\[\d+\])', item).group(1) not in anchors]
    proof_result = lowering.get('original_body_proof_lowering', {})
    proof = proof_result.get('Ok', {})
    obligations = body.get('obligations', [])
    for obligation in obligations:
        dependency_counts[obligation['kind']] += 1
        if obligation['kind'] == 'CHECKED_ORIGINAL_BODY_REQUIRED' and obligation['callee'] not in selected:
            outside_local.add(obligation['callee'])
    bodies.append({
        'owner': owner,
        'frontend': body.get('ordinary_frontend'),
        'ledger_refusal': body.get('native_lowering', {}).get('Err'),
        'proof_refusal': proof_result.get('Err'),
        'bound_count': len(anchors),
        'binding_errors': [item['Err'] for item in bound if 'Err' in item],
        'required_original_calls': len(calls),
        'all_unbound_original_call_bundles': unbound,
        'requirement_counts': dict(collections.Counter(item.split('{')[0].strip() for item in requirements)),
        'source_bound_false_assertions': proof.get('source_bound_open_assertions'),
        'all_open_requirements': proof.get('unlowered_or_open', []),
        'all_validation_errors': [item['Err'] for item in proof.get('typed_constraint_validation', []) if isinstance(item, dict) and 'Err' in item],
        'all_declared_obligations': obligations,
    })
receipts = []
for name in ('repair148-tests-build', 'repair148-tests', 'repair148-native-build', 'original-repair148', 'stale-holder-negative', 'holder-restored', 'duplicate-origin-negative', 'origin-restored'):
    receipt = json.loads((root / (name + '.receipt.json')).read_text())
    streams = {}
    for stream in ('stdout', 'stderr'):
        data = (root / (name + '.' + stream)).read_bytes()
        actual = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
        streams[stream] = {'actual': actual, 'matches_receipt': actual == receipt[stream]}
    receipts.append({key: receipt[key] for key in ('number', 'name', 'kind', 'returncode', 'owned_group_absent', 'source_unchanged_during_command')} | {'stream_checks': streams})
baseline = json.loads((root / 'baseline143.json').read_text())
initial = json.loads((root / 'initial-source.json').read_text())
final = json.loads((root / 'source-final.json').read_text())
before = {item['path']: item for item in baseline}
after = {item['path']: item for item in initial}
delta = [path for path in sorted(before.keys() | after.keys()) if before.get(path) != after.get(path)]
manifest = json.loads((repair / 'MANIFEST.json').read_text())
repair_sources = {item['path'].removeprefix('candidate/'): item for item in manifest if item['path'].startswith('candidate/')}
result = {
    'scope': 'Retained-record interpretation only; no native execution or full dependency/compiler/bootstrap attestation',
    'baseline_initial_final_entries': [len(baseline), len(initial), len(final)],
    'inventory_delta': delta,
    'inventory_delta_matches_exact_two148_sources': set(delta) == set(repair_sources) and all(after[path]['sha256'] == repair_sources[path]['sha256'] for path in delta),
    'initial_final_inventories_equal': initial == final,
    'all_declared_dependency_counts': dict(dependency_counts),
    'local_dependencies_outside_selected_bodies': sorted(outside_local),
    'total_unbound_original_call_bundles': sum(len(body['all_unbound_original_call_bundles']) for body in bodies),
    'bodies': bodies,
    'receipts': receipts,
}
(scratch / 'RECORD-REVIEW.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: result[key] for key in ('baseline_initial_final_entries', 'inventory_delta', 'inventory_delta_matches_exact_two148_sources', 'initial_final_inventories_equal', 'all_declared_dependency_counts', 'total_unbound_original_call_bundles')}, indent=2))
print('Receipt stream checks:', all(stream['matches_receipt'] for receipt in receipts for stream in receipt['stream_checks'].values()))
