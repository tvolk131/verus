import datetime
import hashlib
import json
import os
from pathlib import Path

scratch = Path('/private/tmp/review152-20261108-yB2rKJYT')
started = datetime.datetime.fromisoformat('2026-11-08T21:56:38+00:00')
deadline = started + datetime.timedelta(minutes=15)
limit = 4 * 1024 ** 2

def digest(path):
    data = path.read_bytes()
    return {'path': path.name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

def usage():
    files = [path for path in scratch.rglob('*') if path.is_file()]
    space = os.statvfs(scratch)
    return {'files': len(files), 'logical_bytes': sum(path.stat().st_size for path in files), 'allocated_bytes': sum(path.stat().st_blocks * 512 for path in files), 'free_bytes': space.f_bavail * space.f_frsize}

entry = json.loads((scratch / 'authentication-entry.json').read_text())
exit_record = json.loads((scratch / 'authentication-exit.json').read_text())
baseline_exit = json.loads((scratch / 'baseline-selected-exit.json').read_text())
assert not entry['errors'] and not exit_record['errors'] and exit_record['entry_exit_equal']
assert all(record['matches'] for record in baseline_exit)
summary = json.loads((scratch / 'RECORD-REVIEW.json').read_text())
assert summary['inventory_delta_matches_exact_two148_sources'] and summary['initial_final_inventories_equal']
assert summary['total_unbound_original_call_bundles'] == 10
assert all(stream['matches_receipt'] for receipt in summary['receipts'] for stream in receipt['stream_checks'].values())
now = datetime.datetime.now(datetime.timezone.utc)
before = usage()
minimum_free = min(entry['free_bytes'], exit_record['free_bytes'], before['free_bytes'], 30884528 * 1024, 29655256 * 1024)
accounting = {
    'review': 152,
    'start_utc': started.isoformat(),
    'seal_utc': now.isoformat(),
    'deadline_utc': deadline.isoformat(),
    'elapsed_seconds_before_seal': (now - started).total_seconds(),
    'time_limit_seconds': 900,
    'scratch_limit_bytes': limit,
    'usage_before_seal': before,
    'minimum_sampled_free_bytes': minimum_free,
    'free_disk_requirement': 'strictly greater than 16GiB at samples; no continuous sampling claim',
    'selected_sealed_authority_endpoints': len(entry['records']),
    'additional_selected_historical143_source_endpoints': len(baseline_exit),
    'selected_input_entry_exit_equal': True,
    'custody_scope': 'Selected endpoints only, not full target/compiler/source/runtime/bootstrap or historical continuity',
    'compiler_slot': 'NO compiler slot acquired',
    'compiler_build_test_verifier_application_commands': 0,
    'network_commands': 0,
    'git_writes': 0,
    'parent_baseline_edits': 0,
    'implementation151_live_files_inspected': 0,
    'delegation': 0,
    'automatic_followup': False,
    'truncations_preserved': 6,
    'read_only_schema_discovery_failures_preserved': 1,
    'historical_allowances': {'150': 'EXHAUSTED8/8', '143': 'EXHAUSTED36/36', '147': 'SEALED30/32_UNADOPTED', '116': 'INTERRUPTED_UNCHANGED'},
    'source_native_resource_trust_proof_acceptance': 0,
    'native_bodies_proved': 0,
    'laws_adopted': 0,
    'all18': 'OPEN',
}
assert now <= deadline
assert before['logical_bytes'] < limit and before['allocated_bytes'] < limit
assert minimum_free > 16 * 1024 ** 3
(scratch / 'ACCOUNTING.json').write_text(json.dumps(accounting, indent=2) + '\n')
excluded = {'SEAL.json', 'SEAL.sha256', 'READBACK.json', 'READBACK.sha256'}
payloads = [digest(path) for path in sorted(scratch.iterdir()) if path.is_file() and path.name not in excluded]
seal = {
    'review': 152,
    'verdict': 'NO_NEW_BLOCKING_SCOPED_SOURCE_DEFECT_DEMONSTRATED; STRUCTURAL_REMEDIATION_OBSERVED; NOT_ADOPTED; NATIVE_RESOURCE_TRUST_PROOF_ACCEPTANCE0',
    'utc': now.isoformat(),
    'files': payloads,
    'input_hashes': 'authentication-entry.json and authentication-exit.json; baseline-selected-entry.json and baseline-selected-exit.json',
    'output_report': next(record for record in payloads if record['path'] == 'REPORT.md'),
    'detached_readback': 'READBACK.json and READBACK.sha256; detached seal digest SEAL.sha256',
    'release': 'NO compiler slot acquired; no automatic followup',
}
(scratch / 'SEAL.json').write_text(json.dumps(seal, indent=2) + '\n')
seal_digest = digest(scratch / 'SEAL.json')
(scratch / 'SEAL.sha256').write_text(seal_digest['sha256'] + '  SEAL.json\n')
read_seal = json.loads((scratch / 'SEAL.json').read_text())
checks = []
for record in read_seal['files']:
    actual = digest(scratch / record['path'])
    checks.append({'path': record['path'], 'matches': actual == record})
assert all(record['matches'] for record in checks)
finished = datetime.datetime.now(datetime.timezone.utc)
readback = {
    'review': 152,
    'utc': finished.isoformat(),
    'seal': seal_digest,
    'all_payloads_match': True,
    'payload_checks': checks,
    'elapsed_seconds_through_readback': (finished - started).total_seconds(),
    'usage_before_detached_readback': usage(),
    'compiler_slot': 'NO compiler slot acquired',
}
(scratch / 'READBACK.json').write_text(json.dumps(readback, indent=2) + '\n')
(scratch / 'READBACK.sha256').write_text(digest(scratch / 'READBACK.json')['sha256'] + '  READBACK.json\n')
final_usage = usage()
assert final_usage['logical_bytes'] < limit and final_usage['allocated_bytes'] < limit
assert final_usage['free_bytes'] > 16 * 1024 ** 3
assert datetime.datetime.now(datetime.timezone.utc) <= deadline
print(json.dumps({'report': seal['output_report'], 'seal': seal_digest, 'readback': digest(scratch / 'READBACK.json'), 'all_payloads_match': True, 'elapsed_seconds_through_readback': readback['elapsed_seconds_through_readback'], 'final_usage': final_usage, 'compiler_slot': 'NO compiler slot acquired'}, indent=2))
