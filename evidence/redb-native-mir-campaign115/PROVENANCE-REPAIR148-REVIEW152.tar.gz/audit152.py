import datetime
import hashlib
import json
import os
from pathlib import Path
import sys

scratch = Path('/private/tmp/review152-20261108-yB2rKJYT')
workspace = Path('/Users/tommyvolk/.t3/worktrees/verus/t3-60978068')
roots = {
    'review146': (Path('/private/tmp/review146-20261108-PNPfRNC4'), 'SEAL.json', 'be03f003c5e3c9fef2826fddb64f3edb7a4980fca90285034f0c82e4b714752d'),
    'repair148': (Path('/private/tmp/redb-provenance-repair148-20261108-j01r2pgl'), 'MANIFEST.json', '7659d7f7811bda10dd984dc547c8ddd114fd2ef1a115ce449724ba7e5a76766d'),
    'validation150': (Path('/private/tmp/redb-parent-validation150-20261108-vumyv529'), 'SEAL.json', 'c1491e800f1980aa2d3ee14d51dd220e80606c7ae346e53d157208dbb98cc27f'),
}

def describe(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

def authenticate(phase):
    records = []
    errors = []
    for label, (root, seal_name, expected_seal) in roots.items():
        seal_record = describe(root / seal_name)
        seal_record['expected_sha256'] = expected_seal
        records.append(seal_record)
        if seal_record['sha256'] != expected_seal:
            errors.append({'label': label, 'error': 'seal mismatch'})
            continue
        seal = json.loads((root / seal_name).read_text())
        entries = seal if isinstance(seal, list) else seal['files']
        if label == 'review146':
            entries = [entry for entry in entries if entry['path'] in ('REPORT.md', 'ACCOUNTING.json', 'findings.json')]
        for entry in entries:
            path = root / entry['path']
            try:
                record = describe(path)
                record['expected_sha256'] = entry['sha256']
                record['expected_bytes'] = entry['bytes']
                records.append(record)
                if record['sha256'] != entry['sha256'] or record['bytes'] != entry['bytes']:
                    errors.append({'path': str(path), 'error': 'entry mismatch'})
            except Exception as error:
                errors.append({'path': str(path), 'error': str(error)})
    for name in ('AUTHORIZATION139.md', 'FIRST-CELL139.md', 'PROVENANCE-REPAIR148.json', 'PROVENANCE-REPAIR148-VALIDATION150.json'):
        records.append(describe(workspace / 'evidence/redb-native-mir-campaign115' / name))
    space = os.statvfs(scratch)
    result = {'phase': phase, 'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'scope': 'Selected sealed record endpoints only; no referenced full source/target/compiler/bootstrap continuity.', 'records': records, 'errors': errors, 'free_bytes': space.f_bavail * space.f_frsize}
    if phase == 'exit':
        entry = json.loads((scratch / 'authentication-entry.json').read_text())
        before = {item['path']: (item['bytes'], item['sha256']) for item in entry['records']}
        after = {item['path']: (item['bytes'], item['sha256']) for item in records}
        result['entry_exit_equal'] = before == after
        if before != after:
            result['errors'].append({'error': 'entry/exit selected input mismatch'})
    destination = scratch / ('authentication-' + phase + '.json')
    destination.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'phase': phase, 'records': len(records), 'errors': errors, 'free_bytes': result['free_bytes'], 'entry_exit_equal': result.get('entry_exit_equal')}, indent=2))
    if errors or result['free_bytes'] <= 16 * 1024 ** 3:
        sys.exit(1)

authenticate(sys.argv[1])
if sys.argv[1] == 'exit':
    baseline_entry = json.loads((scratch / 'baseline-selected-entry.json').read_text())
    baseline_exit = []
    for entry in baseline_entry:
        actual = describe(Path(entry['path']))
        actual['expected_sha256'] = entry['expected_sha256']
        actual['matches'] = actual['sha256'] == entry['sha256'] == entry['expected_sha256'] and actual['bytes'] == entry['bytes']
        baseline_exit.append(actual)
    (scratch / 'baseline-selected-exit.json').write_text(json.dumps(baseline_exit, indent=2) + '\n')
    print('Selected historical143 entry/exit equal:', all(entry['matches'] for entry in baseline_exit))
    if not all(entry['matches'] for entry in baseline_exit):
        sys.exit(1)
