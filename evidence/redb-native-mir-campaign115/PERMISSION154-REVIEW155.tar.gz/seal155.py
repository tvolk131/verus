import datetime
import hashlib
import json
import os
from pathlib import Path
import stat
import sys
import tarfile

root = Path(__file__).parent
started = datetime.datetime.fromisoformat('2026-11-08T23:01:29+00:00')
deadline = started + datetime.timedelta(minutes=16)

def now():
    return datetime.datetime.now(datetime.timezone.utc)

def digest(path):
    hasher = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            hasher.update(block)
    return hasher.hexdigest()

def put(name, data):
    (root / name).write_text(json.dumps(data, indent=2, sort_keys=True) + '\n')

def usage():
    paths = [path for path in root.rglob('*') if path.is_file()]
    return {'logical_bytes': sum(path.stat().st_size for path in paths), 'allocated_bytes': sum(path.stat().st_blocks * 512 for path in paths), 'files': len(paths), 'free_bytes': os.statvfs(root).f_bavail * os.statvfs(root).f_frsize}

records = [json.loads(line) for line in (root / 'INSPECTIONS155.jsonl').read_text().splitlines()]
if records[-2]['argv'][1] != 'auth' or records[-2]['exit_code'] != 0 or records[-1]['argv'][1] != 'exit-endpoints' or records[-1]['exit_code'] != 0:
    raise ValueError('successful exit archive and endpoint authentication must be last inspections')
initial_usage = usage()
minimum_free = min([record['sampled_free_bytes'] for record in records] + [initial_usage['free_bytes'], 28658156 * 1024])
if now() >= deadline or minimum_free <= 16 * 1024**3 or max(initial_usage['logical_bytes'], initial_usage['allocated_bytes']) > 4 * 1024**2:
    raise ValueError('review bounds violated before seal')
put('ACCOUNTING155.json', {'start_utc': started.isoformat(), 'deadline_utc': deadline.isoformat(), 'accounting_utc': now().isoformat(), 'inspection_invocations': len(records), 'failed_inspections': [record for record in records if record['exit_code'] != 0], 'authoring_failure': 'One apply_patch context mismatch retained in LOG-QUALIFICATION155.md and tool transcript', 'minimum_sampled_free_bytes': minimum_free, 'minimum_required_free_bytes_strict': 16 * 1024**3, 'scratch_limit_bytes': 4 * 1024**2, 'preseal_usage': initial_usage, 'compiler_build_verifier_solver_test_application_commands': 0, 'compiler_slot': 'NEVER_ACQUIRED', 'network_git_destructive_commands': 0, 'delegates': 0, 'live156_reads': 0, 'parent_baseline_edits': 0, 'archive_authentication_runs': sum(record['argv'][1] == 'auth' for record in records), 'sealer_argv': sys.argv, 'qualification': 'Timing/usage of final archive and byte readback is postarchive in SEAL155.json; no circular member claim.'})
put('REVIEW155.json', {'disposition': 'RETAIN_ONE_GENERATED_CONDITIONAL_TRANSFER_WITH_QUALIFICATIONS', 'generated_conditional_bodies_in_sealed154': 1, 'original_whole_bodies': 0, 'unconditionally_accepted_native_store_occurrences': 0, 'new_laws_adopted': 0, 'new_native_resource_trust_proof_acceptance': 0, 'native_export': 'REFUSED', 'all18': 'OPEN', 'allocation_contract_recommendation': 'EXACT_INHERITED_SAME_EVENT_NORMAL_SUCCESS_REUSE_ONLY_AFTER_PARENT_DISPOSITION_AND_CHECKED_MATCHING', 'allocation_issuance': 'OPEN', 'P151A': 'UNADOPTED', 'implementation156': 'NOT_APPROVED', 'findings': [{'id': '155-1', 'severity': 'medium-evidentiary', 'finding': 'Semantic negatives reject; primary solver answers unknown/incomplete quantifiers, not SAT'}, {'id': '155-2', 'severity': 'low-scope', 'finding': 'Missing/duplicate/spec tests are appended WF/affinity/mode failures, not original caller issuance'}, {'id': '155-3', 'severity': 'medium-admission-boundary', 'finding': 'Narrow actual selector is not a general producer; no concrete inspected misselection'}], '154_allowance': 'SEALED28/32_NO_REUSE', '151_allowance': 'SEALED29/36_NO_REUSE', '147': 'UNADOPTED_H1H2', '141': 'REJECTED', '148': 'SCOPED_PER152_10_UNBOUND_CALLS_PLUS_OPEN_ERRS', '143': 'EXHAUSTED36/36', '150': 'EXHAUSTED8/8', '116': 'INTERRUPTED'})
excluded = {'MANIFEST155.json', 'HANDOFF155.tar.gz', 'ARCHIVE-READBACK155.json', 'SEAL155.json', 'HANDOFF155.json'}
payloads = sorted([path for path in root.iterdir() if path.name not in excluded], key=lambda path: path.name)
for path in payloads:
    if not stat.S_ISREG(path.lstat().st_mode):
        raise ValueError(f'nonregular payload {path}')
manifest = [{'path': path.name, 'bytes': path.stat().st_size, 'sha256': digest(path)} for path in payloads]
put('MANIFEST155.json', manifest)
expected = {entry['path']: entry for entry in manifest}
expected['MANIFEST155.json'] = {'path': 'MANIFEST155.json', 'bytes': (root / 'MANIFEST155.json').stat().st_size, 'sha256': digest(root / 'MANIFEST155.json')}
archive_path = root / 'HANDOFF155.tar.gz'
with tarfile.open(archive_path, 'w:gz') as archive:
    for name in sorted(expected):
        archive.add(root / name, arcname=name, recursive=False)
seen = set()
member_records = []
with tarfile.open(archive_path, 'r|gz') as archive:
    for member in archive:
        if not member.isfile() or member.name in seen or member.name not in expected:
            raise ValueError(f'nonregular/duplicate/unexpected member {member.name}')
        seen.add(member.name)
        content = archive.extractfile(member).read()
        entry = expected[member.name]
        actual = hashlib.sha256(content).hexdigest()
        if len(content) != entry['bytes'] or actual != entry['sha256'] or content != (root / member.name).read_bytes():
            raise ValueError(f'archive readback mismatch {member.name}')
        member_records.append({'path': member.name, 'bytes': len(content), 'sha256': actual, 'regular_unique_byte_identical': True})
if seen != set(expected):
    raise ValueError('archive members missing')
put('ARCHIVE-READBACK155.json', {'archive_sha256': digest(archive_path), 'regular_unique_byte_identical_members': len(seen), 'manifest_payloads': len(manifest), 'members': member_records, 'postarchive': True})
final_usage = usage()
finished = now()
seal = {'schema': 'independent-review155-seal-v1', 'root': str(root), 'start_utc': started.isoformat(), 'finished_utc': finished.isoformat(), 'elapsed_seconds_including_archive_readback': (finished-started).total_seconds(), 'deadline_utc': deadline.isoformat(), 'archive_bytes': archive_path.stat().st_size, 'archive_sha256': digest(archive_path), 'manifest_sha256': digest(root / 'MANIFEST155.json'), 'readback_sha256': digest(root / 'ARCHIVE-READBACK155.json'), 'regular_unique_byte_identical_members': len(seen), 'manifest_payloads': len(manifest), 'minimum_sampled_free_bytes': min(minimum_free, final_usage['free_bytes']), 'usage_before_postarchive_metadata': final_usage, 'compiler_slot': 'NEVER_ACQUIRED', 'original_whole_bodies': 0, 'native_acceptance': 0, 'laws_adopted': 0, 'all18': 'OPEN', 'postarchive': True, 'qualification': 'SEAL155/HANDOFF155/readback excluded from archive; selected endpoints only, no full target/runtime/bootstrap/historical continuity claim.'}
put('SEAL155.json', seal)
put('HANDOFF155.json', {**seal, 'seal_sha256': digest(root / 'SEAL155.json'), 'report': 'REPORT155.md', 'allocation_boundary': 'ALLOCATION-CONTRACT-BOUNDARY155.md', 'disposition': 'RETAIN_CONDITIONAL154_WITH_QUALIFICATIONS_NO_NEW_ADOPTION'})
final_usage = usage()
if now() >= deadline or final_usage['free_bytes'] <= 16 * 1024**3 or max(final_usage['logical_bytes'], final_usage['allocated_bytes']) > 4 * 1024**2:
    raise ValueError('final review bounds violated')
print(json.dumps({'archive': str(archive_path), 'archive_sha256': digest(archive_path), 'manifest_sha256': digest(root / 'MANIFEST155.json'), 'seal_sha256': digest(root / 'SEAL155.json'), 'archive_members': len(seen), 'manifest_payloads': len(manifest), 'finished_utc': now().isoformat(), 'elapsed_seconds': (now()-started).total_seconds(), 'final_usage': final_usage, 'minimum_sampled_free_bytes': seal['minimum_sampled_free_bytes'], 'exit_authentication': 'SUCCESS'}, indent=2))
