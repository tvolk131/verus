import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import sys
import tarfile
import time

SCRATCH = Path(__file__).parent
ROOT = Path('/private/tmp/redb-permission154-20261108-223323')
PINS = {'HANDOFF154.tar.gz': '2e8a8848e3dac8e9703d1d3c7cafd74473933f2b121b41dac89b5055087be564', 'MANIFEST154.json': '6082b546b89c7364f228f9d564d9dda5a4d5dfd3bd606b965a09b2804f2abfb2', 'SEAL.json': '0ad4de2d25f48330ca53784f42a5eedf3b0fd392bc013a304df4101039294cbe'}

def digest(path):
    hasher = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            hasher.update(block)
    return hasher.hexdigest()

def authenticate():
    result = {'pins': {}, 'manifest_payloads': 0, 'archive_members': 0, 'live_payloads': 0, 'errors': []}
    for name, expected in PINS.items():
        actual = digest(ROOT / name)
        result['pins'][name] = actual
        if actual != expected:
            raise ValueError(f'pin mismatch {name}')
    entries = json.loads((ROOT / 'MANIFEST154.json').read_text())
    expected = {entry['path']: entry for entry in entries}
    if len(entries) != len(expected):
        raise ValueError('duplicate manifest path')
    expected['MANIFEST154.json'] = {'bytes': (ROOT / 'MANIFEST154.json').stat().st_size, 'sha256': PINS['MANIFEST154.json']}
    names = set()
    with tarfile.open(ROOT / 'HANDOFF154.tar.gz', 'r|gz') as archive:
        for member in archive:
            name = member.name
            if not member.isfile() or name in names or name not in expected or Path(name).is_absolute() or '..' in Path(name).parts:
                raise ValueError(f'invalid archive member {name}')
            names.add(name)
            content = archive.extractfile(member).read()
            entry = expected[name]
            if len(content) != entry['bytes'] or hashlib.sha256(content).hexdigest() != entry['sha256']:
                raise ValueError(f'archive byte mismatch {name}')
    if names != set(expected):
        raise ValueError('archive inventory mismatch')
    for name, entry in expected.items():
        path = ROOT / name
        if not stat.S_ISREG(path.lstat().st_mode) or path.stat().st_size != entry['bytes'] or digest(path) != entry['sha256']:
            raise ValueError(f'live byte mismatch {name}')
    result.update(manifest_payloads=len(entries), archive_members=len(names), live_payloads=len(expected), total_payload_bytes=sum(entry['bytes'] for entry in entries), qualification='Selected manifested endpoints, not target/runtime/bootstrap or historical continuity. SEAL/HANDOFF are postarchive.')
    return json.dumps(result, indent=2)

def inspect():
    mode = sys.argv[1]
    if mode == 'auth':
        return authenticate()
    if mode == 'inventory':
        pattern = re.compile(sys.argv[2])
        entries = json.loads((ROOT / 'MANIFEST154.json').read_text())
        return '\n'.join(f"{entry['bytes']:9} {entry['path']}" for entry in entries if pattern.search(entry['path']))
    if mode == 'summary':
        results = []
        for name in sys.argv[2:]:
            path = ROOT / name
            data = json.loads(path.read_text())
            with (SCRATCH / 'ENDPOINTS155.jsonl').open('a') as stream:
                stream.write(json.dumps({'path': str(path), 'sha256': digest(path), 'bytes': path.stat().st_size}) + '\n')
            if isinstance(data, dict):
                selected = {key: value for key, value in data.items() if key not in ('argument_inputs', 'argument_outputs', 'before', 'after', 'environment', 'source_files', 'files', 'root_mir', 'store')}
                if 'store' in data:
                    selected['store'] = {key: value for key, value in data['store'].items() if key != 'owner_mir'}
                results.append({'path': name, 'data': selected})
            else:
                results.append({'path': name, 'type': str(type(data))})
        return json.dumps(results, indent=2)
    if mode in ('field', 'fieldsearch'):
        path = ROOT / sys.argv[2]
        data = json.loads(path.read_text())
        for key in sys.argv[3].split('.'):
            data = data[key]
        with (SCRATCH / 'ENDPOINTS155.jsonl').open('a') as stream:
            stream.write(json.dumps({'path': str(path), 'sha256': digest(path), 'bytes': path.stat().st_size}) + '\n')
        lines = str(data).splitlines()
        if mode == 'fieldsearch':
            pattern = re.compile(sys.argv[4])
            context = int(sys.argv[5]) if len(sys.argv) > 5 else 2
            indices = sorted({nearby for index, line in enumerate(lines) if pattern.search(line) for nearby in range(max(0, index-context), min(len(lines), index+context+1))})
        else:
            start = int(sys.argv[4]) if len(sys.argv) > 4 else 1
            end = int(sys.argv[5]) if len(sys.argv) > 5 else len(lines)
            indices = range(start-1, min(end, len(lines)))
        return '\n'.join(f'{index+1:5}: {lines[index]}' for index in indices)
    if mode == 'library':
        library = Path('/private/tmp/verus-pinned-rust-source-20261107-9FT58F/rust-src-1.99.1/rust-src/lib/rustlib/src/rust/library')
        inventory = json.loads((ROOT / 'library-final.json').read_text())
        by_name = {entry['path']: entry for entry in inventory}
        inputs = json.loads((ROOT / 'inputs.json').read_text())
        results = []
        for name in sys.argv[2:]:
            path = library / name
            expected = by_name[name]
            actual = digest(path)
            if actual != expected['sha256'] or path.stat().st_size != expected['bytes']:
                raise ValueError(f'library mismatch {name}')
            selected_inputs = [entry for entry in inputs if entry['path'] == str(path)]
            if not selected_inputs or any(entry['sha256'] != actual for entry in selected_inputs):
                raise ValueError(f'library input mismatch {name}')
            result = {'path': str(path), 'sha256': actual, 'bytes': path.stat().st_size, 'matches_library_final_and_inputs': True}
            results.append(result)
            with (SCRATCH / 'ENDPOINTS155.jsonl').open('a') as stream:
                stream.write(json.dumps(result) + '\n')
        return json.dumps(results, indent=2)
    if mode == 'relations':
        result = {'proof_links': [], 'source_changes': [], 'normal_hashes': {}, 'absent_outputs': {}}
        for path in sorted(ROOT.glob('checked-*.receipt.json')):
            data = json.loads(path.read_text())
            for entry in data.get('argument_inputs', []):
                source = Path(entry['path'])
                if source.suffix != '.rs' or source.parent != ROOT / 'proof':
                    continue
                actual = digest(source)
                binding_path = source.with_suffix('.binding.json')
                binding = json.loads(binding_path.read_text())
                if actual != entry['sha256'] or actual != binding['generated_sha256']:
                    raise ValueError(f'proof crossprocess endpoint mismatch {source.name}')
                result['proof_links'].append({'source': source.name, 'sha256': actual, 'receipt': path.name, 'binding_matches': True})
        for name in ['checked-store-normal', 'restored-store', 'final-original-export-refusal']:
            result['normal_hashes'][name] = digest(ROOT / 'proof' / f'{name}.rs')
        if len(set(result['normal_hashes'].values())) != 1:
            raise ValueError('normal restoration mismatch')
        for name in ['proof/rejected-outcome.rs', 'proof/rejected-outcome.binding.json', 'rejected-outcome-refused.rmeta', 'final-original-export-refusal-refused.rmeta']:
            result['absent_outputs'][name] = not (ROOT / name).exists()
            if not result['absent_outputs'][name]:
                raise ValueError(f'unexpected output {name}')
        initial = {entry['path']: entry for entry in json.loads((ROOT / 'initial-source.json').read_text())}
        final = {entry['path']: entry for entry in json.loads((ROOT / 'final-original-export-refusal.source-final.json').read_text())}
        for name in sorted(set(initial) | set(final)):
            if initial.get(name) != final.get(name):
                result['source_changes'].append({'path': name, 'initial': initial.get(name), 'final': final.get(name)})
        patch = (ROOT / 'CHANGES154.patch').read_text()
        driver_patch = patch.split('@@ -0,0 +1,321 @@\n')[1]
        reconstructed = ''.join(line[1:] for line in driver_patch.splitlines(keepends=True) if line.startswith('+'))
        result['patch_driver_matches_actual'] = reconstructed.encode() == (ROOT / 'candidate/source/rust_verify/src/bin/permission154.rs').read_bytes()
        if not result['patch_driver_matches_actual']:
            raise ValueError('patch driver mismatch')
        return json.dumps(result, indent=2)
    if mode == 'exit-endpoints':
        observations = [json.loads(line) for line in (SCRATCH / 'ENDPOINTS155.jsonl').read_text().splitlines()]
        expected = {}
        for entry in observations:
            if entry['path'] in expected and expected[entry['path']]['sha256'] != entry['sha256']:
                raise ValueError(f'endpoint changed during review {entry["path"]}')
            expected[entry['path']] = entry
        for name, entry in expected.items():
            path = Path(name)
            if digest(path) != entry['sha256'] or path.stat().st_size != entry['bytes']:
                raise ValueError(f'endpoint changed on exit {name}')
        return json.dumps({'unique_endpoints_rehashed_on_exit': len(expected), 'changed': [], 'qualification': 'Selected endpoints only, not full target/runtime/bootstrap or historical continuity.'}, indent=2)
    if mode == 'receipts':
        results = []
        for path in sorted(ROOT.glob('*.receipt.json')):
            data = json.loads(path.read_text())
            name = data.get('name', path.name.removesuffix('.receipt.json'))
            if len(sys.argv) > 2 and not re.search(sys.argv[2], name):
                continue
            streams = {}
            for kind, expected in data.get('streams', {}).items():
                stream_path = ROOT / f'{name}.{kind}'
                actual = digest(stream_path)
                if actual != expected['sha256'] or stream_path.stat().st_size != expected['bytes']:
                    raise ValueError(f'stream mismatch {name} {kind}')
                streams[kind] = stream_path.read_text()[:1200]
            results.append({'name': name, 'returncode': data.get('returncode'), 'number': data.get('number'), 'reaped': data.get('reaped'), 'streams': streams})
        return json.dumps(results, indent=2)
    if mode in ('read', 'search'):
        path = Path(sys.argv[2])
        if not path.is_absolute():
            path = ROOT / path
        content = path.read_bytes()
        endpoint = {'path': str(path), 'sha256': hashlib.sha256(content).hexdigest(), 'bytes': len(content)}
        with (SCRATCH / 'ENDPOINTS155.jsonl').open('a') as stream:
            stream.write(json.dumps(endpoint) + '\n')
        lines = content.decode('utf-8', errors='replace').splitlines()
        if mode == 'read':
            start = int(sys.argv[3]) if len(sys.argv) > 3 else 1
            end = int(sys.argv[4]) if len(sys.argv) > 4 else len(lines)
            selected = range(max(start - 1, 0), min(end, len(lines)))
        else:
            pattern = re.compile(sys.argv[3])
            context = int(sys.argv[4]) if len(sys.argv) > 4 else 3
            selected = sorted({nearby for index, line in enumerate(lines) if pattern.search(line) for nearby in range(max(0, index-context), min(len(lines), index+context+1))})
        return json.dumps(endpoint) + '\n' + '\n'.join(f'{index+1:5}: {lines[index]}' for index in selected)
    raise ValueError(f'unknown inspection {mode}')

started = time.monotonic()
record = {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'argv': sys.argv, 'cwd': os.getcwd()}
try:
    output = inspect()
    record.update(exit_code=0, stdout=output, stderr='')
except Exception as error:
    record.update(exit_code=1, stdout='', stderr=repr(error))
record['elapsed_seconds'] = time.monotonic() - started
record['sampled_free_bytes'] = os.statvfs('/private/tmp').f_bavail * os.statvfs('/private/tmp').f_frsize
with (SCRATCH / 'INSPECTIONS155.jsonl').open('a') as stream:
    stream.write(json.dumps(record) + '\n')
print(record['stdout'])
if record['stderr']:
    print(record['stderr'], file=sys.stderr)
if record['sampled_free_bytes'] <= 16 * 1024**3:
    raise SystemExit('free disk boundary violated')
raise SystemExit(record['exit_code'])
