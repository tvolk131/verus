# Exact minimal allocation-contract reuse boundary155

## Per-contract recommendation, not adoption

- `candidate/source/vstd/raw_ptr.rs:908` allocate(size,align): RECOMMEND CONDITIONAL EXACT INHERITED NORMAL-RETURN REUSE ONLY, after explicit later parent disposition AND checked same-original-event correspondence. Not automatically a spec for Global.allocate or __rust_alloc. No current original issuance theorem.
- `raw_ptr.rs:800` split: existing inherited axiom/API, only with genuine original-event raw resource, proved subset, consumptive split and retained exact complement/provenance.
- `raw_ptr.rs:832` into_typed::<u8>: existing inherited axiom/API, only exact one-byte range/alignment/nonnull-or-nonzero-size and full spec-pointer equality to ORIGINAL Offset result. Consumes raw cell, yields Uninit typed token.
- `raw_ptr.rs:579` ptr_mut_write::<u8>:153 conditional existing-contract disposition unchanged, not extended to allocation/caller invariants.

DO NOT ADOPT P151(A), generic allocation grant, runtime issuance rule,147/H1H2 exception, automatic producer, or156 implementation. No new generic axiom is needed merely for checked reuse of existing contracts; unmatched native issuance stays OPEN.

## Exact inherited allocate contract

`raw_ptr.rs:906` cfg std, external_body. Requires valid_layout(size,align) AND size!=0. `vstd/layout.rs:13` is power-of-two align and size<=isize::MAX-(isize::MAX%align). On normal return gives executable p:*mut u8, genuine Tracked<PointsToRaw> raw and Tracked<Dealloc> dealloc:

1. raw.is_range(p.addr as int,size as int), p.addr+size<=usize::MAX+1.
2. dealloc data EXACTLY p.addr,size,align,raw.provenance.
3. p.addr divisible by align; p spec provenance==raw.provenance.

Body `:929` builds Layout::from_size_align_unchecked; `:932` calls ACTUAL alloc::alloc::alloc(layout); `:933` aborts on null; `:936` returns inherited trusted resources. External_body is inherited trust, NOT a newly verified body. Opens_invariants none, **NO no_unwind annotation**. Do not borrow ptrstore no_unwind or infer totality. No initialized zeros, Arc representation/counts, caller success, inert/finite allocator callbacks, global ambient frame, or completed deallocation is promised. Live provenance follows genuine resources' inherited meaning, not an extra numeric generation label. Keep matching Dealloc affine through actual cleanup; it does not excuse missing whole-domain permissions or double-free.

## Actual original path and failure divergence

Original cached_file.rs:19 repeat_n(0u8,len).collect() selects Arc<[u8]>/RepeatN<u8> from_iter_exact. Pinned `library/alloc/src/sync.rs:2303`,:2326 first allocate_for_slice, then actual data-field pointer; loop ptr::write(elems.add(i),item) at2337.

`sync.rs:2274` allocate_for_slice uses Layout::array::<T>(len).unwrap(), concrete `|layout| Global.allocate(layout)`, and mem cast/slice(len) ArcInner metadata closure. `:2189` allocate_for_layout builds combined layout, invokes closure, maps Err with handle_alloc_error, then initialize_arcinner. Not an arbitrary callback or a new allocation witness.

`library/alloc/src/alloc.rs:540` Global.allocate -> alloc_impl(layout,false). `:423` const_eval_select requires actual RUNTIME branch, not const_allocate. Runtime `:297`:

- size0 -> Ok(dangling_ptr.cast_slice(0)), no actual allocation;
- positive size -> alloc_zeroed if zeroed, otherwise alloc(layout);
- null -> Err(AllocError); nonnull -> Ok(SAME raw pointer cast_slice(size)).

`alloc.rs:124` alloc calls shim guard then __rust_alloc(size,alignment). Same lower native alloc event is the matching opportunity with vstd wrapper's alloc call, not blanket issuance for allocator APIs. Bind actual selected allocator/cfg/profile/shim identities in future checked correspondence, not spelling/address alone.

Native null path Global Err->Arc handle_alloc_error DIFFERS from vstd null->std::process::abort. `alloc.rs:641` runtime error handler calls __rust_alloc_error_handler; cfg can choose immediate-abort/constant path. Keep null,Err,error-handler,abort,unwind and nonreturn distinct. Under shim nounwind ABI, unwinding across that ABI is not a legitimate normal return; no finite hook/callback completion follows. Success-only correspondence excludes a branch only after proving THIS event returned normally/nonnull. It does not equate whole functions' failures. Zeroed and size0 paths are not covered by this exact allocate contract mapping.

## Header/layout derivation, including len0

Pinned `sync.rs:392` is repr(C,align(2)) ArcInner<T>: strong Atomic<usize>, weak Atomic<usize>, data T. `:409` uses Layout::new::<ArcInner<()>>().extend(value_layout).unwrap_or_else(capacity-overflow panic).0.pad_to_align(). Never hardcode16 in the contract or use len as allocation size.

Let header=Layout::new::<ArcInner<()>>, payload=Layout::array::<u8>(len), (combined_unpadded,offset)=header.extend(payload), combined=pad_to_align. Actual allocation size/align are combined.size/align. Prove successful array/extend/pad and Layout invariants -> exact valid_layout, bounded arithmetic, positive size due to two-counter header. Array fitting does NOT imply header extension fits. `library/core/src/alloc/layout.rs:500` extends with aligned offset/max alignment and checked layout; `:565` bounds array multiplication/isize extent. Preserve layout failure/panic rather than assuming success.

For recorded aarch64/64-bit cfg: `core/src/sync/atomic.rs:358` usize Storage=Align8<usize>; `:269` align8; `:383` Atomic repr(C) over UnsafeCell<Storage>. Two size8/align8 counters under ArcInner repr(C,align2) yield header size16/align8. u8 data has offset16, combined size round_up(16+len,8),align8, PROVIDED successful checked layout. This is a source-derived specialization for that recorded target, not a portable law or newly obtained compiler layout receipt. General boundary retains actual target/cfg/type layout evidence. No compiler was run.

len0 has no payload store, but STILL has nonzero two-counter header allocation. Exclude Global's zero-size dangling branch from combined size>0, NOT from len>0 or omitted header. `sync.rs:2221` initialize_arcinner converts pointer/metadata, debug-asserts layout, then performs ACTUAL strong=AtomicUsize::new(1) and weak=AtomicUsize::new(1) writes at2225/2226 BEFORE payload store. Resource flow must justify those effects and pointer metadata, not assume inert initialization or caller-valid Arc state.

## Minimal checked same-event and resource gates

**G1 Event and normal success.** Bind original source/Instance/call activation/order, actual computed Layout and returned pointer at Global->runtime->alloc leaf. Bind concrete closure, runtime branch,false zeroed flag,positive combined size,nonnull NORMAL return. One original event to one inherited issuance; no unrelated wrapper allocation or existential equal address. Hashes/JSON/names alone are not dynamic correspondence.

**G2 Exact contract application, not invented leaf spec.** vstd allocate external_body belongs to vstd allocate. A checked producer/refinement must connect THIS original normal-success transition with that EXACT inherited behavior/resource result. Source-text similarity of internal alloc calls does not itself derive a token. If the same-event bridge is absent, issuance stays OPEN. PointsToRaw input alone proves only downstream conditional conversion. A bare assume_new/axiom at native leaf is NEW trust, not checked reuse. Later parent permission does not prove G1/G2.

**G3 Layout/outcomes.** Prove valid_layout,size!=0,exact size/align match,successful array/extend/pad and no wrapping arithmetic. Preserve layout panic,null,Global Err,Arc error handler,abort,unwind,nonreturn. No successful or terminating allocator/hook assumption. Nonzeroed allocate supplies uninitialized bytes; zero comes from actual iterator item/write, not allocation.

**G4 Genuine exclusive ownership/live provenance.** Bind raw domain [p.addr,p.addr+size) and matched Dealloc to THIS event. Track affine resources through actual header writes,data casts/slice metadata,guard construction,iterator calls/prior writes. No silent deallocation/reallocation/stale substitution/alias transfer/duplication. Original caller/allocator/callback/reentry frames must be checked for those effects; no ambient/global/callback frame follows from allocator contract or freshness.

**G5 Actual pointer/index bounds.** Derive payload base from real ArcInner.data projection with actual len metadata and original provenance. Prove actual Some((i,item)) index satisfies0<=i<len, multiplication/add/Offset defined in same live object, byte end<=payload end<=allocation end. Some guard alone proves no bound. Full SPEC pointer identity includes provenance/metadata; runtime PartialEq/numeric address equality is insufficient.

**G6 Exact consumptive split/conversion.** Let q be ORIGINAL store pointer; cell=Set::range(q@.addr as int,q@.addr as int+1). Prove cell subset of CURRENT original raw.dom. split consumes raw, returns exact cell+complement with SAME provenance. into_typed::<u8>(q.addr) requires size1,align1,exact is_range,nonnull-or-size!=0. Its result pointer equals ptr_mut_from_data({addr:q.addr,provenance:raw.provenance,metadata:()}); prove this is q in SPEC equality. Empty domain cannot cover one byte. Descriptors/non-nullness/labels cannot mint domain. Result Uninit, not initialized value.

**G7 Retained complement and store.** Borrow derived real PointsTo<u8>, invoke153 store with actual byte Local, retain SAME pointer/Init(actual item), disjoint complement and matching Dealloc. Account for prior strong/weak writes,guard n_elems,earlier initialized elements and cleanup ownership. A raw uninitialized complement does not assert earlier initialized values: retain typed/value resources or explicit checked representation. Generic retained frame proves only that token, not whole allocation/global state. No assumed Arc counts/length/sequence or successful caller invariant.

Boundary is local original allocation->header->one live payload cell->conditional store. It does not demand hypothetical complete Rust semantics to retain154, nor close any original body/cell. Iterator enumeration/len,Arc wrapping/drop/cleanup,cache/reservation/checkout and later buffered durability remain OPEN at actual checked boundaries.
