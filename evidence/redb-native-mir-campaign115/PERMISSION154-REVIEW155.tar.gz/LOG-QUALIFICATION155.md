# Raw failures and display qualification

Failed review receipt inspection: argv inspect155.py receipts '^checked-|^restored-|^rejected-outcome$|^final-original-export-refusal$', exit1, stderr exactly `KeyError('name')`. Full record retained in INSPECTIONS155.jsonl. Filename fallback repaired review inspection only.

Failed review apply_patch at about23:11Z: `apply_patch verification failed: Failed to find expected lines in /private/tmp/redb-review155-20261108-230129/inspect155.py: if mode == 'relations':`. Combined patch failed validation; no input was changed and report additions were then applied in a separate patch. Exact attempted patch is in tool transcript. Followup discovery argv `rg -n "relations|return json.dumps|mode ==" .../inspect155.py; date -u '+%H:%M:%SZ'; ls ...` exit0 confirmed scratch state. This is an authoring/setup failure, not proof evidence.

Presentation-truncated responses included b996dd,6b2ea1,da26b6,638cae,0e7d95,ba73dc,7f60b5,2763b3. Raw warning: `Warning: truncated output (original token count: ...)`. Helper writes full SELECTED stdout before display, preserved in JSONL; narrower followup reads covered substantive missing ranges. Initial shell discovery/pins and argv are recorded in SETUP155.md/conversation. No initial discovery failure.

read/search/field intentionally select lines/context; summary excludes huge fields. These are not full-view claims; endpoints are fully hashed. receipts validates full actual stream hashes/sizes but its displayed summary is intentionally first1200 characters per stream, not full raw log preservation. Full originals remain authenticated154 members; wrong-pointer/provenance full stderr and historical build diagnostics were separately read. All1587 archive members were byte-read completely during authentication.

No archived source/runner/compiler/verifier/solver/application was executed. Review helper only hashes/reads/decodes evidence, samples resources and performs byte relation inspection. All authored edits use apply_patch; no new inline code comments. Historical setup1 incomplete contemporaneous custody stays disclosed rather than reconstructed.
