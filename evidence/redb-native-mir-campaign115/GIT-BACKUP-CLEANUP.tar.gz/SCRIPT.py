import argparse
import datetime
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import stat


ROOTS = (
    Path('/private/tmp/redb-native-adapter164-20261109-004200/target'),
    Path('/private/tmp/redb-native-implementation166-20261109-015200/target'),
    Path('/private/tmp/redb-native-implementation170-20261108-204838/target'),
)
OUTPUT = Path('/private/tmp/redb-git-backup-cleanup-20261109')
PROOF_SUFFIXES = {'.air', '.smt', '.smt2', '.vir', '.proof', '.prooflog', '.log', '.stdout', '.stderr', '.jsonl', '.rs', '.c', '.h', '.s', '.S'}
REFERENCED = set()


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def free_bytes():
    information = os.statvfs('/private/tmp')
    return information.f_bavail * information.f_frsize


def digest(path):
    checksum = hashlib.sha256()
    with path.open('rb') as source:
        while True:
            chunk = source.read(1048576)
            if not chunk:
                break
            checksum.update(chunk)
    return checksum.hexdigest()


def record(path):
    before = path.lstat()
    if not stat.S_ISREG(before.st_mode):
        raise ValueError('nonregular file: ' + str(path))
    checksum = digest(path)
    after = path.lstat()
    identity = lambda value: (value.st_dev, value.st_ino, value.st_size, value.st_mtime_ns)
    if identity(before) != identity(after):
        raise ValueError('file changed during authentication: ' + str(path))
    return dict(path=str(path), bytes=before.st_size, allocated=before.st_blocks * 512,
                mode=stat.S_IMODE(before.st_mode), inode=before.st_ino,
                device=before.st_dev, mtime_ns=before.st_mtime_ns, sha256=checksum)


def walk_files(root, skip_target=False):
    for directory, names, files in os.walk(root, followlinks=False):
        directory_path = Path(directory)
        if skip_target and directory_path == root:
            names[:] = [name for name in names if name != 'target']
        for name in names:
            if (directory_path / name).is_symlink():
                raise ValueError('unexpected directory symlink: ' + str(directory_path / name))
        for name in files:
            yield directory_path / name


def preserve(path, root):
    relative = path.relative_to(root)
    information = path.lstat()
    return (str(path) in REFERENCED
            or relative.parent == Path('debug') and information.st_size > 0
            or bool(information.st_mode & 0o111)
            or path.suffix in PROOF_SUFFIXES
            or path.suffix == '.d'
            or path.suffix in {'.dylib', '.so', '.dll'}
            or any(label in path.name.lower() for label in ('receipt', 'stdout', 'stderr'))
            or path.name in {'output', 'root-output'})


def write_json(path, value):
    with path.open('x') as output:
        json.dump(value, output, indent=2, sort_keys=True)
        output.write('\n')


def acquire_locks():
    descriptors = []
    for root in ROOTS:
        if root.is_symlink() or root.resolve() != root or not root.is_dir():
            raise ValueError('approved target identity mismatch: ' + str(root))
        for name in ('.cargo-artifact-lock', '.cargo-build-lock', '.cargo-lock'):
            lock = root / 'debug' / name
            if lock.exists():
                descriptor = os.open(str(lock), os.O_RDONLY)
                fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
                descriptors.append(descriptor)
    return descriptors


def inventory():
    OUTPUT.mkdir(exist_ok=False)
    started = now()
    initial_free = free_bytes()
    entries = []
    protected = []
    descriptors = acquire_locks()
    try:
        for root in ROOTS:
            pattern = re.compile(re.escape(str(root)) + r'''/[^\s"'\\<>;,\]\[{}()]+''')
            for path in walk_files(root.parent, skip_target=True):
                if path.suffix in {'.json', '.jsonl', '.md', '.py', '.txt', '.stdout', '.stderr'}:
                    for match in pattern.finditer(path.read_text(errors='replace')):
                        referenced = Path(match.group())
                        if referenced.is_file():
                            REFERENCED.add(str(referenced))
        for root in ROOTS:
            for path in walk_files(root):
                entry = record(path)
                entry['preserve'] = preserve(path, root)
                if entry['preserve']:
                    backup = OUTPUT / 'retained' / root.parent.name / path.relative_to(root)
                    backup.parent.mkdir(parents=True, exist_ok=True)
                    os.link(path, backup, follow_symlinks=False)
                    if digest(backup) != entry['sha256']:
                        raise ValueError('retained bytes mismatch')
                    entry['retained_path'] = str(backup)
                entries.append(entry)
            for path in walk_files(root.parent, skip_target=True):
                protected.append(record(path))
        write_json(OUTPUT / 'INVENTORY.json', dict(started=started, completed=now(),
            approval='User Yes please do to selective cleanup of target164/166/170, then candidate preservation, commit and push',
            free_before=initial_free, free_after_inventory=free_bytes(), entries=entries))
        write_json(OUTPUT / 'PROTECTED.json', protected)
    finally:
        for descriptor in descriptors:
            os.close(descriptor)
    print(json.dumps(dict(files=len(entries), retained=sum(entry['preserve'] for entry in entries),
        protected_outside_targets=len(protected), free_bytes=free_bytes(),
        inventory_sha256=digest(OUTPUT / 'INVENTORY.json'), protected_sha256=digest(OUTPUT / 'PROTECTED.json'))))


def remove():
    inventory_path = OUTPUT / 'INVENTORY.json'
    inventory_value = json.loads(inventory_path.read_text())
    protected = json.loads((OUTPUT / 'PROTECTED.json').read_text())
    entries = inventory_value['entries']
    allowed = {str(root) for root in ROOTS}
    descriptors = acquire_locks()
    started = now()
    before_free = free_bytes()
    removed = 0
    try:
        expected = {entry['path'] for entry in entries}
        actual = {str(path) for root in ROOTS for path in walk_files(root)}
        if actual != expected:
            raise ValueError('target inventory changed')
        for entry in entries:
            path = Path(entry['path'])
            if not any(path.is_relative_to(root) for root in ROOTS):
                raise ValueError('out-of-scope target')
            if path.is_symlink() or path.resolve() != path:
                raise ValueError('path identity changed')
            current = record(path)
            if any(current[key] != entry[key] for key in ('bytes', 'inode', 'device', 'mtime_ns', 'sha256')):
                raise ValueError('target endpoint drift: ' + str(path))
            if entry['preserve'] and digest(Path(entry['retained_path'])) != entry['sha256']:
                raise ValueError('preserved backup drift')
        for entry in protected:
            if digest(Path(entry['path'])) != entry['sha256']:
                raise ValueError('protected endpoint drift')
        with (OUTPUT / 'REMOVALS.jsonl').open('x') as ledger:
            for entry in entries:
                if entry['preserve']:
                    continue
                path = Path(entry['path'])
                path.unlink()
                ledger.write(json.dumps(dict(path=str(path), sha256=entry['sha256'], bytes=entry['bytes'], utc=now())) + '\n')
                ledger.flush()
                removed += 1
        for root in ROOTS:
            for directory, names, files in os.walk(root, topdown=False, followlinks=False):
                directory_path = Path(directory)
                if str(directory_path) not in allowed:
                    try:
                        directory_path.rmdir()
                    except OSError:
                        if not any(directory_path.iterdir()):
                            raise
        for entry in protected:
            if digest(Path(entry['path'])) != entry['sha256']:
                raise ValueError('protected postcleanup drift')
        for entry in entries:
            if entry['preserve']:
                if digest(Path(entry['path'])) != entry['sha256'] or digest(Path(entry['retained_path'])) != entry['sha256']:
                    raise ValueError('retained postcleanup drift')
            elif Path(entry['path']).exists():
                raise ValueError('removed file remains')
        result = dict(started=started, completed=now(), free_before=before_free,
            free_after=free_bytes(), removed_files=removed,
            retained_files=sum(entry['preserve'] for entry in entries),
            protected_files=len(protected), targets=[str(root) for root in ROOTS],
            qualification='Required artifacts remain at original paths and verified hardlink backups; no source/log/proof/archive/history deletion; disk samples not causal filesystem theorem',
            all18='OPEN', schema_count=1, operative_laws=0, native_acceptance=0)
        write_json(OUTPUT / 'RESULT.json', result)
        print(json.dumps(result))
    finally:
        for descriptor in descriptors:
            os.close(descriptor)


parser = argparse.ArgumentParser()
parser.add_argument('operation', choices=['inventory', 'remove'])
arguments = parser.parse_args()
if arguments.operation == 'inventory':
    inventory()
else:
    remove()
