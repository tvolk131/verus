# Campaign94 / task171: source-only G3 scalar dependency

**UNCOMPILED / UNVERIFIED / CASES UNEXECUTED. NO SLOT ACQUIRED.**

This package supplies authored Verus arithmetic bodies and an exact textual
consumer delta relative to immutable156. It does not establish original native
applicability. No compiler, solver, formatter, build, test, native application,
network, Git, delegate, or other worker inspection was used. Source reads,
instruction reads, hashes, textual patch accounting and archive operations are
not proof checking. The consumer delta is not applied to156 or any native body.

## What is implemented

`g3_scalar171.rs` exports:

- `OriginalLayoutValues171`: only typed `usize` scalar observations, not a
  tracked token, event identity, native `Layout`, native `Alignment`, or issuer.
- Separate `original_u8_value_relations171` and
  `original_u8_normal_guards171`: normalized actual u8 value relations and
  the array/extend numeric success inequalities, respectively. The former uses
  the original bitwise padded-size expression, not a premise asserting the
  desired division-based allocation formula.
- `lemma_extend_threshold171` and `lemma_round_up171`: reusable statements
  over queried integer parameters, with bodies calling existing arithmetic
  lemmas. There is no new axiom, assumption, admission or external-body stub.
- `lemma_mask8_171` and `lemma_signed_limit8_171`: proof bodies for the native
  numeric mask/division correspondence and signed-limit remainder.
- `lemma_original_threshold_iff171`: exact equivalence of BOTH numeric normal
  guards with `len <= isize::MAX - 16 - 7`, given the explicit value relations
  and observed16/8 header binding. This does not silently restrict successful
  lengths to a smaller convenient range.
- `derive_original_layout171`: nonoverflow, exact padded size
  `16 + ((len + 7) / 8) * 8`, positive combined and padded sizes, padding0..7,
  `valid_layout(combined,8)` and `valid_layout(padded,8)`, and the len0 result
  combined16/padded16/empty payload extent. It assumes no initialized bytes.
- `derive_original_cell171` and `derive_original_address171`: arbitrary
  `index < len` relative byte-Offset/one-byte endpoint bounds, and numeric
  address-addition bounds conditional on the genuine allocation endpoint
  contract. They do not prove provenance, native pointer equality, pointer
  validity, permission ownership, or that native enumeration yields the index.

`consumer156.patch` changes only the existing allocation-to-store consumer and
its generated reclaim caller, plus module imports. Place this scalar module
next to the future consumer's `restored-cut.rs` when deliberately applying that
delta in a separately authorized checkout. The patch:

1. Replaces the store consumer's conservative caller length premise with a
   ghost scalar snapshot, its exact length equality, normalized source value
   relations, numeric normal guards, and explicit observed header binding.
2. Calls the layout/cell proofs before156's existing `generated_allocate156`
   call, obtaining its unchanged scalar precondition and exact formula.
3. Uses that generated call's actual endpoint postcondition for the numeric
   address lemma before the unchanged split/typed-cell/store continuation.
4. Threads the same ghost snapshot through `generated_reclaim156`.

The existing allocator, store, pointer equality, permission split/frame/rejoin,
and deallocation bodies and result contracts are not replaced. There is exactly
the existing generated allocation call in the store dependency, not a new call
to original allocation plus another vstd allocation. This generated allocation
is STILL A DIFFERENT EVENT from the original native activation. The delta is
usable scalar wiring for156, NOT an original resource producer or new cell.

## Exact original call / guard / value provenance

All line numbers below refer to the authenticated inputs in `manifest171.json`.
The rust source root is the pinned1.99.1 `library` directory. The binding's
`/rustc/58cf8f9c35b355199727627d07ae34a4e2846d67/...` spans are recorded compiler
observations, not proof that a dynamic activation consumes a snapshot.

| Original source / binding selection | Typed value or normal-success fact needed by the lemmas | Bound now / remaining injection |
|---|---|---|
| `cached_file.rs:19-22`, `zero_filled_arc(len: usize)` | `repeat_n(0u8,len).collect::<Arc<[u8]>>()`; caller len | Source exact; propagation from this activation to `values.len` remains checked-adapter work. |
| `sync.rs:4218-4235`, TrustedLen `ToArcSlice<u8>` specialization | `size_hint` Some(high), low/high equality, `from_iter_exact(self,low)` | Binding `resolved_path` selects `[u8, RepeatN<u8>]`; no iterator/caller summary or dynamic low==root-len theorem is introduced. |
| `sync.rs:2303,2326`, `from_iter_exact` -> `allocate_for_slice(len)` | usize argument, pointer result | Binding `allocation156.entry_call`: caller DefId3:8388, callee3:8384, args `[u8]`, `move _2`, result `_3`, normal `Some(bb1)`, unwind `Cleanup(bb13)`. Debug/block names identify observations only. |
| `sync.rs:2274-2281`, `allocate_for_slice::<u8>` | `Layout::array::<u8>(len).unwrap()`; nonzero u8 element size1 and alignment1 | Typed selected MIR hash39322ac7... has `Layout::array::inner(const <T as SizedTypeProperties>::LAYOUT, copy _1)` then Result unwrap. Need checked actual u8 LAYOUT projection and Ok edge facts. |
| `core/alloc/layout.rs:565-592`, array inner | `array_limit = I+1-element_alignment`; `len <= array_limit / element_size`; `payload_size = element_size*len` without overflow | Explicit scalar premises, not imported native semantics. Actual source returns Err if nonzero element size and len exceeds the quotient. For u8 this gives len<=I, not yet156's stronger bound. |
| `sync.rs:2184-2193`, selected allocate_for_layout | calls `arcinner_layout_for_value_layout(value_layout)` before passing its result to the concrete allocation closure | Selected MIR hash5e854096... retains this helper CALL. It does not contain checked expansions of all core constructors. |
| `sync.rs:409-419`, layout helper | `Layout::new::<ArcInner<()>>().extend(layout).unwrap_or_else(panic).0.pad_to_align()` | This exact original route is read. No new alternate layout builder is used. |
| `sync.rs:389-405` + binding `allocation156.compiler_layout` | queried prefix/header16, alignment8, payload offset16 | Binding actually records `ArcInner<[u8]>` (sized:false), size16, align8, field offsets0/8/16. It does NOT separately record a compiler query for `ArcInner<()>`. `observed_header156_171` is an explicit compatibility premise, never a theorem that the dynamic helper's header is16/8. Checked query/projection of the helper's actual header remains required. |
| `core/alloc/layout.rs:500-515`, extend | next alignment1; `offset = (header_size+0)&!0 = header_size`; max alignment8; `combined=offset+payload_size`; successful `from_size_alignment` | The usize-to-int equality for the original unchecked addition must be justified by checked native lowering/type invariants, not supplied from debug names. The source's own no-overflow argument bounds the sum by usize::MAX before constructor success. |
| `core/alloc/layout.rs:81-112,125-140`, constructor | actual `max_size_for_alignment(a) = unchecked_sub(I+1,a.as_usize())`; `combined <= extend_limit` | IMPORTANT: this pin uses subtraction, NOT a max-size bitmask implementation. For numeric8 the body proves equivalence to `(I as usize)&!7`, using I%8=7. Native `Alignment::as_usize()` is a numeric value; its enum discriminant or raw internal-field representation is not automatically that number. |
| `core/alloc/layout.rs:352-373,387-398`, pad | `(combined+7)&!7` with preserved alignment8 | Body proves combined+7<=I and converts the exact native mask to division. No overflow or padding relation is granted by a fake native wrapper. |
| `sync.rs:2278,2191` allocation closure/normal return | concrete `Global.allocate(layout)` receives exactly this padded Layout | Existence of that typed call is recorded; dynamic layout argument consumption, nonzero/nonzeroed route, actual normal success, same event/full pointer and genuine affine resource issuance remain separate gates. No native allocation is performed here. |
| `sync.rs:2332-2338`, data field / enumerate / write | payload base from `&raw mut (*ptr).data`, `.add(index)`, byte from the same Some item | Binding `_3` allocation result, `_7` payload base, `_17` index, `Offset(copy _7,copy _17)`, `_19:*mut u8`, `_18:u8`, Some -> bb6. Owner MIR7af624c6... . Index<len, exact item/caller flow, original resources and store activation remain unwired. |
| `vstd/layout.rs:13-15` | `valid_layout(size,align) = is_pow2(align) && size <= I-I%align` | Existing predicate only. The body proves both sizes satisfy it for8; there is no native/resource contract addition. |

`I` denotes `isize::MAX`. Complete hashes, not the shortened table labels,
appear in the manifest for the files. Selected full MIR hashes are:

- allocate_for_slice: `39322ac76ab0b7d7e2d4e8bcabf9688f18f2e475d337235b814edfb329e1987f`
- allocate_for_layout: `5e8540966ffad0cb60a05442e140b60fd1f6101c93d5d9a603073c11cfd66f5b`
- from_iter_exact owner/store: `7af624c656544f958114bbe3c673229bb24adcda171a8877129adbe1e73e7d52`

The binding's selected typed_instances_and_paths names are allocate_for_slice,
allocate_for_layout, two closures, and alloc_impl_runtime. There is no selected
array-inner, extend, or arcinner-helper body record in that list. Source bodies
plus typed calls constrain what to prove; they are not an applicability witness.

## Exact limit, padding and zero length

For the bound observations, the original extend guard is
`16+len <= I+1-8 = I-7`. Therefore it is equivalent, not merely sufficient, to
`len <= I-23`, precisely156's premise. The array guard adds no restriction here.
At len=`I-23`, combined and padded are both `I-7`, a multiple of8. At the next
length the array guard still passes but extend fails; rounding that invalid
combined size would yield `I+1`. No accepted original normal length is dropped.

Padding examples (len -> combined / padded) are0->16/16,1->17/24,7->23/24,
8->24/24,9->25/32. Payload len0 is not allocation size0. The header-only
allocation has size16 and an empty payload extent. There is no cell index<len
when len0. Padding is not initialized payload and does not authorize an item
index merely because its numeric address would be within allocated memory.

## Remaining checked adapter-injection obligation / later170 consumption

No action on170 is performed or requested by this package. In a later authorized
compiler slot, the parent or170 can consume these files as follows:

1. Deliberately compile/verify the scalar module and proposed cases under the
   same pinned Verus/vstd and target. They have NOT been syntax-checked or
   solver-checked here; proof elaboration or solver failures must be preserved.
2. Apply the exact consumer delta in an authorized nonimmutable consumer,
   preserving the existing allocation/store result contracts. The textual
   sealing check only checks hunk context/counts against156, not proof validity.
3. Build/check typed extraction for this exact normalized Instance/call path.
   It must supply `.as_usize()` alignment facts, actual header query, guard Ok
   edges, numeric no-overflow projections and the padded Layout field values
   from the SAME activation, then call `derive_original_layout171`. A handmade
   record with matching constants or file hashes cannot discharge this step.
4. Consume the result at the actual native allocation continuation, establishing
   that its exact Layout argument is positive, valid and has the derived size
   and alignment8. Preserve the pre-existing nonzeroed/normal-success/event/pointer/
   permission/caller gates. Applying the inherited allocate contract to this
   event and delivering genuine original raw/Dealloc remain G1/G2, not results
   of arithmetic. Do NOT invoke another allocation to fabricate those tokens.
5. Establish native enumerate index<len and the SAME original data-field base,
   item, full specification pointer and live resource flow before using the
   cell/address bounds with the existing split/store proof dependency.

Dynamic path/normal-success relation consumption is **UNWIRED**. The record has
no event key and no tracked witness on purpose: there is no invented issuer,
uninterpreted resource gift or newly trusted caller premise. The original
caller is not asked to assume156's length bound. Its checked continuation must
obtain the original normal guards instead. Equal numbers from another length,
header, call or activation are not dynamic source correspondence.

This is partial correctness of scalar normal-success relations only. No error,
panic, null/abort, callback, initialized-atomic/header, loop, or outcome
equivalence is proved. All18/G1/G2 remain OPEN. Original G3 applicability also
remains OPEN pending the typed/dynamic injection just specified. Native,
export, issuer and original proof credits are0; original accepted allocations,
stores and bodies are0. No laws, memory model or admission/trust changes.

## Case status and seal conventions

`g3_cases171.rs` contains source-only proposed positive and negative scalar
cases. EVERY CASE IS UNEXECUTED. Rejection lemmas prove intended numeric refusal;
they are not a log of compiler/verifier failures. Cases cover0/1/7/8/9,
the exact upper accepted length and its successor, array overflow, size0 versus
len0, wrong numeric alignment projection, wrong header/offset, substituted len,
first/last cells, index=len in padding, and len0/index0. A wrong native Alignment
projection that accidentally has the same number or wrong activation with the
same scalars is NOT rejected by scalar equality; only the checked adapter can
reject that provenance/type mismatch.

The unique regular archive contains only these authored small files, the
manifest and accounting. It contains no source-tree/target copies. The manifest
records entry/exit byte sizes and SHA256 pins, and hashes of authored payloads.
Archive member byte readback is compared to those files. Final archive and
manifest hashes are reported outside the self-containing archive to avoid a
self-hash cycle. Accounting includes the regular archive in scratch logical
and allocated totals; directory-block allocation is counted separately too.
No cleanup is performed, including on a sealing failure.
