pub fn diagnostic_envelope_marker() {}
