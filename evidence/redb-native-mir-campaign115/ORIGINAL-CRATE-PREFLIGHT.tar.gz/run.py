import datetime
import hashlib
import json
import os
import pathlib
import shutil
import signal
import subprocess
import sys
import time


ROOT = pathlib.Path(__file__).parent
RECOVERY = pathlib.Path('/private/tmp/verus-crash-consistency94-20261105/native-leaf-lookup-007/recovery.json')
NATIVE = pathlib.Path('/private/tmp/verus-crash-consistency94-20261105/native-leaf-lookup-007/recovered-native/redb')
TOOLCHAIN = pathlib.Path('/Users/tommyvolk/.rustup/toolchains/1.99.1-aarch64-apple-darwin')


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(name, value):
    path = ROOT / name
    assert not path.exists(), str(path)
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def authenticate_sources(blobs):
    records = []
    for relative, expected in sorted(blobs.items()):
        pure = pathlib.PurePosixPath(relative)
        assert not pure.is_absolute() and '..' not in pure.parts
        path = NATIVE / relative
        data = path.read_bytes()
        actual_sha256 = hashlib.sha256(data).hexdigest()
        actual_git_blob = hashlib.sha1(('blob ' + str(len(data)) + '\0').encode() + data).hexdigest()
        assert actual_sha256 == expected['sha256'] and len(data) == expected['size_bytes'], relative
        assert actual_git_blob == expected['git_blob'], relative
        records.append({'path': relative, 'bytes': len(data), 'sha256': actual_sha256,
                        'git_blob_content_hash': actual_git_blob})
    return records


def run(name, argv, environment):
    before = now()
    start = time.monotonic()
    write(name + '.launch.json', {'utc': before, 'argv': argv, 'cwd': str(ROOT / 'redb'),
                                'environment': environment, 'timeout_seconds': 90,
                                'compiler_producing': False, 'native_application_execution': False})
    child = None
    status = 'NOT_STARTED'
    interrupted = None
    with (ROOT / (name + '.stdout')).open('wb') as stdout, (ROOT / (name + '.stderr')).open('wb') as stderr:
        try:
            child = subprocess.Popen(argv, cwd=ROOT / 'redb', env=environment,
                                     stdout=stdout, stderr=stderr, start_new_session=True)
            child.wait(timeout=90)
            status = 'EXITED_ZERO' if child.returncode == 0 else 'EXITED_NONZERO'
        except subprocess.TimeoutExpired:
            status = 'TIMEOUT'
        except KeyboardInterrupt as error:
            status = 'CANCELLED'
            interrupted = error
        except OSError as error:
            status = 'SPAWN_ERROR'
            stderr.write((repr(error) + '\n').encode())
        finally:
            if child is not None:
                try:
                    os.killpg(child.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                child.wait()
    result = {'start_utc': before, 'end_utc': now(), 'elapsed_seconds': time.monotonic() - start,
              'status': status, 'child_exit_code': child.returncode if child is not None else None,
              'success': status == 'EXITED_ZERO', 'stdout_sha256': sha256(ROOT / (name + '.stdout')),
              'stderr_sha256': sha256(ROOT / (name + '.stderr')), 'compiler_producing': False,
              'native_application_execution': False}
    write(name + '.receipt.json', result)
    if interrupted is not None:
        raise interrupted
    return result


def main():
    assert shutil.disk_usage(ROOT).free > 16 * 1024 ** 3
    recovery = json.loads(RECOVERY.read_bytes())['repositories']['redb']
    assert recovery['pin'] == 'c82ab865bb362bc4af067d332adc44978ff64813'
    records = authenticate_sources(recovery['blobs'])
    assert len(records) == 132
    assert {str(path.relative_to(NATIVE)) for path in NATIVE.rglob('*') if path.is_file()} == {
        row['path'] for row in records}
    write('entry.json', {'utc': now(), 'recovery_sha256': sha256(RECOVERY), 'records': records,
                         'original_path_continuity': 'FAILED', 'git_continuity': 'UNAVAILABLE',
                         'source_discovery_before_authentication': True})
    stage = ROOT / 'redb'
    assert not stage.exists()
    for row in records:
        destination = stage / row['path']
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(NATIVE / row['path'], destination)
        assert sha256(destination) == row['sha256']
    (ROOT / 'tmp').mkdir()
    environment = {
        'PATH': str(TOOLCHAIN / 'bin') + ':/usr/bin:/bin:/usr/sbin:/sbin',
        'HOME': '/Users/tommyvolk', 'CARGO_HOME': '/Users/tommyvolk/.cargo',
        'CARGO_NET_OFFLINE': 'true', 'CARGO_BUILD_JOBS': '1',
        'CARGO_TARGET_DIR': str(ROOT / 'target-unused'),
        'RUSTC': str(TOOLCHAIN / 'bin/rustc'), 'RUSTDOC': str(TOOLCHAIN / 'bin/rustdoc'),
        'TMPDIR': str(ROOT / 'tmp'), 'LANG': 'C', 'LC_ALL': 'C', 'TZ': 'UTC',
    }
    tools = [TOOLCHAIN / 'bin/cargo', TOOLCHAIN / 'bin/rustc', pathlib.Path(sys.executable)]
    write('tools.json', {'utc': now(), 'records': [{'path': str(path), 'sha256': sha256(path)} for path in tools]})
    argv = [str(TOOLCHAIN / 'bin/cargo'), 'metadata', '--offline', '--locked', '--format-version', '1']
    nodeps = run('metadata-no-deps', argv + ['--no-deps'], environment)
    resolution = run('metadata-resolved', argv, environment) if nodeps['success'] else None
    source_after = authenticate_sources(recovery['blobs'])
    assert source_after == records
    staged_after = [{'path': str(path.relative_to(stage)), 'bytes': path.stat().st_size,
                     'sha256': sha256(path)} for path in sorted(stage.rglob('*')) if path.is_file()]
    original = {row['path']: row for row in records}
    extra_paths = [row['path'] for row in staged_after if row['path'] not in original]
    for row in staged_after:
        if row['path'] in original:
            assert row['sha256'] == original[row['path']]['sha256']
    write('result.json', {'utc': now(), 'nodeps': nodeps, 'resolution': resolution,
                          'source_files_authenticated': len(records), 'sources_unchanged': True,
                          'staged_extra_files': extra_paths, 'records_after': staged_after,
                          'free_bytes': shutil.disk_usage(ROOT).free,
                          'native_application_execution': False, 'compilation': False,
                          'all18': 'OPEN', 'native_proof_credit': False})
    print(json.dumps({'nodeps': nodeps['status'], 'resolution': resolution['status'] if resolution else 'NOT_RUN',
                      'authenticated_files': len(records), 'root': str(ROOT)}))


if __name__ == '__main__':
    main()
