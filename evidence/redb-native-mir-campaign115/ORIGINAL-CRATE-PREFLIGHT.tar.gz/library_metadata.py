import importlib.util
import json
import pathlib


ROOT = pathlib.Path(__file__).parent
spec = importlib.util.spec_from_file_location('metadata_runner', ROOT / 'run.py')
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)
environment = json.loads((ROOT / 'metadata-no-deps.launch.json').read_bytes())['environment']
cargo = str(runner.TOOLCHAIN / 'bin/cargo')
manifest = str(ROOT / 'library-envelope/Cargo.toml')
lock = runner.run('library-envelope-lock', [cargo, 'generate-lockfile', '--offline', '--manifest-path', manifest], environment)
metadata = runner.run('library-envelope-metadata', [cargo, 'metadata', '--offline', '--locked',
    '--format-version', '1', '--manifest-path', manifest], environment) if lock['success'] else None
recovery = json.loads(runner.RECOVERY.read_bytes())['repositories']['redb']
native_records = runner.authenticate_sources(recovery['blobs'])
for record in native_records:
    assert runner.sha256(ROOT / 'redb' / record['path']) == record['sha256']
result = {'utc': runner.now(), 'lock': lock, 'metadata': metadata,
          'native_records_authenticated_after': len(native_records),
          'native_manifest_unchanged': True, 'native_code_unchanged': True,
          'compilation': False, 'native_application_execution': False,
          'canonical_workspace_resolution': False, 'all18': 'OPEN'}
if metadata is not None and metadata['success']:
    data = json.loads((ROOT / 'library-envelope-metadata.stdout').read_bytes())
    redb = next(package for package in data['packages'] if package['name'] == 'redb')
    node = next(node for node in data['resolve']['nodes'] if node['id'] == redb['id'])
    result['redb_manifest_path'] = redb['manifest_path']
    result['redb_selected_features'] = node['features']
    result['redb_library_targets'] = [target for target in redb['targets'] if 'lib' in target['kind']]
    result['resolved_packages'] = [{'name': package['name'], 'version': package['version'],
                                   'manifest_path': package['manifest_path']} for package in data['packages']]
    result['new_envelope_lock_sha256'] = runner.sha256(ROOT / 'library-envelope/Cargo.lock')
runner.write('library-envelope-result.json', result)
print(json.dumps({'lock': lock['status'], 'metadata': metadata['status'] if metadata else 'NOT_RUN',
                  'native_sources_authenticated': len(native_records),
                  'selected_features': result.get('redb_selected_features')}))
