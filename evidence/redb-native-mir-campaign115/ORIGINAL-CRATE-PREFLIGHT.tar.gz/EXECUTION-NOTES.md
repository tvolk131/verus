# Original-crate offline dependency preflight115

This is a new noncompiling Cargo metadata task, not a native application build,
execution, proof replay or a reset of any previous diagnostic allowance. It
authenticates all132 recovered redb files against recovery SHA256/length and
Git blob CONTENT hashes, stages exact bytes in fresh scratch, and probes the
unchanged original workspace manifest offline and locked. It does not restore
historical paths, metadata or Git continuity. Initial source discovery preceded
whole-tree authentication; this is not first-read attestation.

The exploratory command attempting Python's tomllib failed because the installed
Python3.9 lacks that module. That traceback is in the tool transcript, not a
retained raw file. A subsequent read-only check found installed toml and pip's
vendored tomli, but this preflight needs no TOML parser: it uses Cargo's actual
workspace parser. No package was installed, downloaded or substituted.

Both metadata commands retain true completed child status and full raw output.
No-deps success is workspace parsing only, not resolved offline availability.
A locked offline resolution failure is a real preflight blocker for the exact
original workspace configuration, not a failure of the native theorem. No
manifest weakening, dependency override or synthetic lockfile is applied here.
All18 remain OPEN; no compiler/source or native resource credit follows.
