import datetime
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import stat
import sys
import tarfile

ROOT = Path('/private/tmp/redb-review159-20261109-000016')
INPUT = Path('/private/tmp/redb-primitive158-20261108-234646')
SUPPORT = Path('/private/tmp/redb-review157-20261108-234518')
PARENT = Path('/Users/tommyvolk/.t3/worktrees/verus/t3-60978068')
EXPECTED_HANDOFF = '8edfd8ddb0d47676d205d72deb78da9104b12fa95708ddc6679a9e2aa0853587'
EXPECTED_ARCHIVE = '94df662fb942f9ec69f55f9b83828750591dbe741e6ea2afebe57bd8ccc350c2'

def digest(data):
    return hashlib.sha256(data).hexdigest()

def read_regular(path):
    metadata = path.lstat()
    assert stat.S_ISREG(metadata.st_mode), str(path)
    with path.open('rb') as handle:
        data = handle.read()
    assert len(data) == metadata.st_size, str(path)
    return data

def endpoint(path):
    data = read_regular(path)
    return {'path': str(path), 'bytes': len(data), 'sha256': digest(data)}

def authenticate(root, handoff_name, manifest_name, archive_name, expected_handoff=None, expected_archive=None):
    handoff_data = read_regular(root / handoff_name)
    handoff = json.loads(handoff_data)
    archive_data = read_regular(root / archive_name)
    manifest_data = read_regular(root / manifest_name)
    assert expected_handoff is None or digest(handoff_data) == expected_handoff
    assert expected_archive is None or digest(archive_data) == expected_archive
    assert digest(archive_data) == handoff['archive_sha256']
    assert digest(manifest_data) == handoff['manifest_sha256']
    manifest = json.loads(manifest_data)
    payloads = manifest['payloads']
    expected = {}
    observations = []
    for entry in payloads:
        relative = entry['path']
        parts = PurePosixPath(relative).parts
        assert not PurePosixPath(relative).is_absolute() and '..' not in parts
        assert relative not in expected
        data = read_regular(root / relative)
        assert len(data) == entry['bytes'] and digest(data) == entry['sha256'], relative
        expected[relative] = data
        observations.append(endpoint(root / relative))
    expected[manifest_name] = manifest_data
    with tarfile.open(fileobj=io.BytesIO(archive_data), mode='r:gz') as archive:
        members = archive.getmembers()
        assert len(members) == len(expected)
        names = [member.name for member in members]
        assert len(set(names)) == len(names) and set(names) == set(expected)
        for member in members:
            assert member.isfile() and not member.issym() and not member.islnk(), member.name
            assert archive.extractfile(member).read() == expected[member.name], member.name
    return {'root': str(root), 'handoff': endpoint(root / handoff_name), 'manifest': endpoint(root / manifest_name), 'archive': endpoint(root / archive_name), 'payload_count': len(payloads), 'archive_regular_unique_byte_readback_count': len(expected), 'payload_endpoints': observations}

phase = sys.argv[1]
record = {'phase': phase, 'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'coverage': 'All manifested158 payloads and manifest plus archive and handoff; selected157 support only; selected parent files and inherited raw_ptr semantics. Endpoint observations, not continuous custody, signatures, compilation or execution.'}
record['input158'] = authenticate(INPUT, 'HANDOFF158.json', 'MANIFEST158.json', 'HANDOFF158.tar.gz', EXPECTED_HANDOFF, EXPECTED_ARCHIVE)
record['support_selected'] = [endpoint(SUPPORT / name) for name in ['PRIMITIVE-BOUNDARY157.md', 'HANDOFF157.json', 'MANIFEST157.json']]
support_handoff = json.loads(read_regular(SUPPORT / 'HANDOFF157.json'))
support_manifest = json.loads(read_regular(SUPPORT / 'MANIFEST157.json'))
assert digest(read_regular(SUPPORT / 'HANDOFF157.json')) == 'a3d4a20911a091eb75ea4db3d633034a8bcff962f5142e80be52cbd80f2e8ec0'
assert digest(read_regular(SUPPORT / 'MANIFEST157.json')) == support_handoff['manifest_sha256']
support_entry = next(entry for entry in support_manifest['payloads'] if entry['path'] == 'PRIMITIVE-BOUNDARY157.md')
assert digest(read_regular(SUPPORT / 'PRIMITIVE-BOUNDARY157.md')) == support_entry['sha256']
record['parent_selected'] = [endpoint(PARENT / name) for name in ['evidence/redb-native-mir-campaign115/AUTHORIZATION139.md', 'evidence/redb-native-mir-campaign115/ALLOCATION156-DISPOSITION157.md', 'source/vstd/raw_ptr.rs']]
record['candidate_inherited_raw_ptr'] = endpoint(INPUT / 'candidate/source/vstd/raw_ptr.rs')
if phase == 'exit':
    previous = json.loads(read_regular(ROOT / 'AUTHENTICATION159-entry.json'))
    for key in ['input158', 'support_selected', 'parent_selected', 'candidate_inherited_raw_ptr']:
        assert previous[key] == record[key], key
    record['selected_endpoints_equal_entry'] = True
destination = ROOT / ('AUTHENTICATION159-' + phase + '.json')
destination.write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
print(json.dumps({'phase': phase, 'payloads158': record['input158']['payload_count'], 'members158': record['input158']['archive_regular_unique_byte_readback_count'], 'support157': len(record['support_selected']), 'parent_selected': len(record['parent_selected']), 'free_bytes': os.statvfs(ROOT).f_bavail * os.statvfs(ROOT).f_frsize, 'utc': record['utc']}))
