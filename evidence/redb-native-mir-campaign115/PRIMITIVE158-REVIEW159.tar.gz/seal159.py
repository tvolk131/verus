import datetime
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import stat
import tarfile

ROOT = Path('/private/tmp/redb-review159-20261109-000016')
START = datetime.datetime.fromisoformat('2026-11-09T00:00:16+00:00')
DEADLINE = START + datetime.timedelta(minutes=14)
SCRATCH_LIMIT = 4 * 1024 * 1024
FREE_FLOOR = 16 * 1024 * 1024 * 1024
POST_METADATA_RESERVE = 65536

def now():
    return datetime.datetime.now(datetime.timezone.utc)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def read_regular(path):
    metadata = path.lstat()
    assert stat.S_ISREG(metadata.st_mode), str(path)
    data = path.read_bytes()
    assert len(data) == metadata.st_size
    return data

def write_json(name, value):
    destination = ROOT / name
    assert not destination.exists(), name
    destination.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

def sample(label):
    paths = [ROOT] + sorted(ROOT.iterdir())
    allocated = 0
    logical = 0
    identities = set()
    regular_count = 0
    for path in paths:
        metadata = path.lstat()
        assert (metadata.st_dev, metadata.st_ino) not in identities
        identities.add((metadata.st_dev, metadata.st_ino))
        assert stat.S_ISREG(metadata.st_mode) or path == ROOT and stat.S_ISDIR(metadata.st_mode)
        allocated += metadata.st_blocks * 512
        if stat.S_ISREG(metadata.st_mode):
            logical += metadata.st_size
            regular_count += 1
    disk = os.statvfs(ROOT)
    free = disk.f_bavail * disk.f_frsize
    clock = now()
    assert clock < DEADLINE, clock.isoformat()
    assert allocated <= SCRATCH_LIMIT, allocated
    assert free > FREE_FLOOR, free
    return {'label': label, 'utc': clock.isoformat(), 'elapsed_seconds': (clock - START).total_seconds(), 'logical_regular_bytes': logical, 'allocated_bytes_including_root': allocated, 'free_bytes': free, 'regular_files': regular_count, 'unique_file_and_directory_inodes': len(identities)}

entry = json.loads(read_regular(ROOT / 'AUTHENTICATION159-entry.json'))
exit_record = json.loads(read_regular(ROOT / 'AUTHENTICATION159-exit.json'))
supplemental = json.loads(read_regular(ROOT / 'SUPPLEMENTAL159-exit.json'))
assert exit_record['selected_endpoints_equal_entry']
assert supplemental['selected_endpoints_equal_supplemental_entry']
assert entry['input158'] == exit_record['input158']
assert entry['input158']['payload_count'] == 65
assert entry['input158']['archive_regular_unique_byte_readback_count'] == 66
before = sample('before_accounting_manifest_archive')
assert before['allocated_bytes_including_root'] + POST_METADATA_RESERVE < SCRATCH_LIMIT
write_json('ACCOUNTING159.json', {
    'task': 'campaign94-review159',
    'first_observation_utc': START.isoformat(),
    'deadline_utc': DEADLINE.isoformat(),
    'maximum_elapsed_seconds_including_seal': 840,
    'fresh_scratch_limit_allocated_bytes': SCRATCH_LIMIT,
    'free_disk_must_be_strictly_greater_than_bytes': FREE_FLOOR,
    'first_df_free_bytes': 27474055168,
    'first_authentication_free_bytes': 27453239296,
    'preseal_sample': before,
    'postarchive_small_metadata_reserve_bytes': POST_METADATA_RESERVE,
    'final_exact_sample': 'Printed in final seal tool transcript after all files are written; no false self-referential accounting hash.',
    'measurement_limits': 'Endpoint samples only, including all fresh regular files and root directory blocks; no continuous global disk monitor.',
    'compiler_slot': 'NOT_USED_NO_COMPILER_CHILDREN_CREATED',
    'compiler_build_verifier_native_executions': 0,
    'solver_runs': 0,
    'tests': 'NOT_RUN_SOURCE_ONLY',
    'network_git_writes_parent_candidate_edits_destructive_cleanup_subdelegation': False,
    'original_application_executed': False,
    'accepted_original_bodies': 0,
    'accepted_original_allocations': 0,
    'accepted_original_stores': 0,
    'real_resource_issues': 0,
    'laws_adopted': 0,
    'all18': 'OPEN',
    'preserved158': '17/32; strict2GiB violation2174758912 allocated before seal metadata; killed/reaped per sealed evidence; raw exit and normal build receipt missing; no retry/repair/reset.'
})
payload_names = sorted(path.name for path in ROOT.iterdir())
excluded = {'MANIFEST159.json', 'HANDOFF159.tar.gz', 'SEAL159.json', 'HANDOFF159.json', 'SHA256SUMS159.txt'}
assert not excluded.intersection(payload_names)
payload_bytes = {name: read_regular(ROOT / name) for name in payload_names}
manifest = {
    'task': 'campaign94-review159',
    'classification': 'INDEPENDENT_SOURCE_ONLY_EXACT_LAW_REVIEW_NO_ADOPTION_NO_ISSUER_APPROVAL',
    'payloads': [{'path': name, 'bytes': len(data), 'sha256': sha(data)} for name, data in payload_bytes.items()],
    'postarchive_metadata_excluded': sorted(excluded - {'MANIFEST159.json', 'HANDOFF159.tar.gz'}),
    'input158_handoff_sha256': entry['input158']['handoff']['sha256'],
    'input158_archive_sha256': entry['input158']['archive']['sha256'],
    'all18': 'OPEN', 'laws_adopted': 0,
}
write_json('MANIFEST159.json', manifest)
archive_bytes = dict(payload_bytes)
archive_bytes['MANIFEST159.json'] = read_regular(ROOT / 'MANIFEST159.json')
archive_path = ROOT / 'HANDOFF159.tar.gz'
with archive_path.open('xb') as raw:
    with gzip.GzipFile(filename='', fileobj=raw, mode='wb', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w', format=tarfile.USTAR_FORMAT) as archive:
            for name, data in sorted(archive_bytes.items()):
                member = tarfile.TarInfo(name)
                member.type = tarfile.REGTYPE
                member.size = len(data)
                member.mode = 0o444
                member.mtime = 0
                archive.addfile(member, io.BytesIO(data))
with tarfile.open(archive_path, mode='r:gz') as archive:
    members = archive.getmembers()
    names = [member.name for member in members]
    assert len(names) == len(set(names)) == len(archive_bytes)
    assert set(names) == set(archive_bytes)
    for member in members:
        assert member.isfile() and not member.islnk() and not member.issym()
        assert archive.extractfile(member).read() == archive_bytes[member.name]
        assert read_regular(ROOT / member.name) == archive_bytes[member.name]
archive_sha = sha(read_regular(archive_path))
manifest_sha = sha(read_regular(ROOT / 'MANIFEST159.json'))
after_archive = sample('after_archive_regular_unique_byte_readback')
assert after_archive['allocated_bytes_including_root'] + POST_METADATA_RESERVE < SCRATCH_LIMIT
write_json('SEAL159.json', {
    'task': 'campaign94-review159', 'utc': now().isoformat(),
    'manifest_sha256': manifest_sha,
    'archive_sha256': archive_sha,
    'manifested_payload_count': len(payload_bytes),
    'archive_regular_unique_byte_identical_members': len(archive_bytes),
    'upstream158_all65_payloads_and66_archive_members_authenticated_entry_exit': True,
    'selected157_and_parent_endpoints_unchanged': True,
    'supplemental_selected_sources_unchanged': True,
    'postarchive_sample': after_archive,
    'compiler_slot': 'NOT_USED_NO_COMPILER_CHILDREN_CREATED',
    'source_only_not_compiled_issuer_validation': True,
    'producer_approved': False, 'laws_adopted': 0,
    'accepted_original_allocations': 0, 'accepted_original_stores': 0, 'accepted_original_bodies': 0,
    'all18': 'OPEN', 'native_export': 'REFUSED',
})
write_json('HANDOFF159.json', {
    'task': 'campaign94-review159', 'root': str(ROOT),
    'completion_utc': now().isoformat(),
    'report': 'REPORT159.md', 'findings': 'FINDINGS159.json',
    'result': 'CONDITIONAL_MATHEMATICAL_LAW_DISPOSITION_PERMITTED_PRODUCER_BLOCKED_ALIGNMENT_ABI_DEFECT',
    'parent_disposition_required_and_not_performed_by_review159': True,
    'producer_approved': False, 'resource_issuer_approved': False,
    'archive': archive_path.name, 'archive_sha256': archive_sha,
    'manifest_sha256': manifest_sha,
    'seal_sha256': sha(read_regular(ROOT / 'SEAL159.json')),
    'accounting_sha256': sha(read_regular(ROOT / 'ACCOUNTING159.json')),
    'input158_handoff_sha256': entry['input158']['handoff']['sha256'],
    'input158_archive_sha256': entry['input158']['archive']['sha256'],
    'input158_authenticated_payloads': 65, 'input158_regular_unique_archive_members': 66,
    'archive_regular_unique_byte_identical_members': len(archive_bytes),
    'compiler_slot': 'NOT_USED_NO_COMPILER_CHILDREN_CREATED',
    'solver_runs': 0, 'tests': 'NOT_RUN_SOURCE_ONLY',
    'real_resource_issues': 0, 'accepted_original_allocations': 0,
    'accepted_original_stores': 0, 'accepted_original_bodies': 0, 'laws_adopted': 0,
    'native_export': 'REFUSED', 'all18': 'OPEN',
    'parent_continues_independently': True,
    'review159_followup_subdelegation_integration': False,
    'preserved158': 'FAILED_2GIB_NO_RETRY_NO_REPAIR_NO_RESET_NO_MISSING_RECEIPT_RECONSTRUCTION',
})
checksum_names = ['HANDOFF159.json', 'HANDOFF159.tar.gz', 'MANIFEST159.json', 'SEAL159.json', 'ACCOUNTING159.json']
checksum_data = ''.join(sha(read_regular(ROOT / name)) + '  ' + name + '\n' for name in checksum_names)
(ROOT / 'SHA256SUMS159.txt').write_text(checksum_data)
for line in read_regular(ROOT / 'SHA256SUMS159.txt').decode().splitlines():
    expected, name = line.split('  ', 1)
    assert sha(read_regular(ROOT / name)) == expected
for name, data in archive_bytes.items():
    assert read_regular(ROOT / name) == data
final_sample = sample('final_after_handoff_seal_checksums_and_byte_readback')
print(json.dumps({'result': 'SEALED_STOP', 'root': str(ROOT), 'handoff_sha256': sha(read_regular(ROOT / 'HANDOFF159.json')), 'archive_sha256': archive_sha, 'manifest_sha256': manifest_sha, 'seal_sha256': sha(read_regular(ROOT / 'SEAL159.json')), 'archive_members': len(archive_bytes), 'manifested_payloads': len(payload_bytes), 'final_sample': final_sample}, indent=2, sort_keys=True))
