# Independent exact-law review159 — sealed158

## Decision, scope, and non-approval

Review date: November 8, 2026 America/Chicago; review work begins at
2026-11-09T00:00:16Z (November 8 at 18:00:16 CST). Deadline including sealing:
2026-11-09T00:14:16Z. This is independent source-only review under
evidence/redb-native-mir-campaign115/AUTHORIZATION139.md and the user's task159
restrictions. No implementation, adoption, integration, repair, retry, or
subdelegation is performed.

**A — No blocking contradiction is demonstrated in the isolated mathematical
normal-success law, with its stated checked premises and genuine event-linked
resource semantics.** Its pure predicate alone would NOT suffice. In particular,
the native allocation-generation/ownership and one-shot same-event issuance
relations are necessary primitive semantics, explicitly required by LAW158,
and cannot be replaced by a Boolean, JSON descriptor, or application assumption.
The concrete typed ABI-to-numeric alignment relation remains required and open;
the current selector actually gets that ABI wrong (F159-1 below).

**B — YES: the parent may separately conditionally dispose the exact mathematical
normal-success schema as proposed NEW TCB, after this review.** Such a disposition
must be limited to its named version/equations and retain every applicability,
runtime/ABI/allocator, memory-model and issuer gate. It is not an unconditional
disposition of a concrete native issuer, not a proof of allocator implementation,
not inherited-wrapper reuse, and not internal installation/adoption by this
review. A proposed parent condition is that A means the numeric alignment of
the actual typed operand, not an independently chosen usize; on this pinned
runtime the missing binding is A = Alignment::as_usize(actual_align_operand(E)).
That mapping belongs to the primitive ABI bridge, NOT Arc/application work.
If the requested disposition were unconditional approval of the pinned1.99.1
producer or a resource-producing implementation, the answer would be NO.

**C — The uncompiled static selector has a definite target-specific type-check
assertion defect, F159-1.** Two smaller metadata/documentation discrepancies
are retained below. No predicate-equation defect or hard Rust compilation error
is established by this source-only review; no typecheck was attempted.

**D — Exact remaining runtime and owned-memory frame assumptions are enumerated
below.** They are conditions for using a native primitive, not optional future
application polish. No Arc/durability theorem is required to judge this leaf
schema, and no missing primitive ABI, event, ownership, or frame semantics is
hidden under the label application work.

This review approves neither the producer nor any issuer. It creates no original
authority, accepts no original native allocation/store/body, closes no original
cell, and adopts no law. Native export remains REFUSED; all18 remain OPEN;
accepted original native allocations/stores/bodies = 0/0/0; laws adopted = 0.

## Authenticated inputs and precise coverage

The supplied HANDOFF158.json pin is
8edfd8ddb0d47676d205d72deb78da9104b12fa95708ddc6679a9e2aa0853587.
The supplied HANDOFF158.tar.gz pin is
94df662fb942f9ec69f55f9b83828750591dbe741e6ea2afebe57bd8ccc350c2.
Both match entry byte reads. The handoff's manifest pin matches. All65 manifested
payloads were individually read and matched for size/SHA256; the archive's
66 entries are regular, uniquely named, exactly the payloads plus manifest,
and individually byte-identical to their current endpoints. This is stronger
than merely accepting the parent's reported65/66 count, but is endpoint custody,
not continuous custody, bootstrap trust, or a compilation result.

Supporting157 coverage is deliberately selected: HANDOFF157.json matches the
pin retained in parent disposition157; MANIFEST157.json matches that handoff;
PRIMITIVE-BOUNDARY157.md matches its manifest entry. This review does NOT claim
to reauthenticate every157 payload or its entire archive. AUTHORIZATION139,
ALLOCATION156-DISPOSITION157, and parent raw_ptr.rs endpoints are recorded.

Seven supplementary endpoints were separately authenticated after their initial
textual inspection, against inventories contained in the authenticated158
payloads: candidate inherited allocation156.rs, raw_ptr.rs, layout.rs, vstd.rs;
and pinned local runtime alloc/src/alloc.rs, core/src/alloc/global.rs,
core/src/mem/alignment.rs. They are NOT a rehash of the whole inherited tree,
all external inputs, compiler binaries, native executable, or loaded libraries.
All three added source files in source-relative158.patch byte-match candidate
source. Cargo's feature/bin hunk was inspected; no patch was applied to inputs.
Full entry/exit details are retained in the authentication JSON files.

Important selected158 pins:

- LAW158.md: 0e95e3c2a8182c12573c57d71d4b93162a1162de343580ff896b45f5bdf8443f
- API158.json: 0aef60b4859ae8f2182b3ec19aaafb9237d002f11ccb22ee672fa6f6e3c7252c
- vstd predicate: 9262621632de7e3942f75d7286a9f70f0a1cf6038ee69e07209340437d532f76
- pending source: 1bedb36cbb36c6d9ddb96451b4fb60950c4424ab6d25ad77ba7cad3a8addbd8a
- diagnostic bin: 32673a9944417fab40c1daa0331f27bd1993026f86b61976f8065cc162d03011
- patch: fe618210c71a4181531e8ab3f64616330eda1c5e2b0ff4205b8de2e7fb53cabb

## Exact mathematical assessment

For one actual dynamic event E, S is its actual size, A its actual numeric
alignment, and P the full actual returned specification pointer. The antecedent
must establish the exact selected nonzero/nonzeroed allocator call, a valid
pre-state, valid_layout(S,A), S > 0, actual normal return to that continuation,
nonnull P, complete pointer interpretation, and an unused unforgeable event
witness in the native live-resource environment. Valid layout includes positive
power-of-two alignment and the allocation-size/isize bound; neither is a gift
about native Layout arithmetic.

The explicitly proposed new trust is the transition, for THAT event, from no
issuance to exactly one genuine live affine pair (R,D) in its normal continuation:

1. P@ equals the actual return destination's full specification pointer,
   including provenance and thin-u8 unit metadata; no second allocation occurs.
2. R's domain is exactly [addr(P), addr(P)+S), with R.provenance() = P@.provenance.
   It grants raw/uninitialized permission, not readable initialized byte values.
3. D's view is exactly {addr: addr(P), size: S, align: A,
   provenance: P@.provenance}, for the same live allocation generation and the
   matching global API deallocation regime.
4. addr(P)+S <= usize::MAX+1 uses mathematical integers, and addr(P) mod A = 0.
5. The single E witness is consumed; genuine authority is not duplicated across
   repeated activations, aliases, old generations, imports, stale holders, loans,
   or other live tracked claims. Logical simultaneous issuance is not a theorem
   about machine-atomic instructions or global allocator linearizability.

normal_resources158 matches the numeric/raw/Dealloc equations of that post-state.
Its lines12-24 state valid layout, positivity, nonnull, exact range/end bound,
alignment and actual pointer provenance/Dealloc view. It is an open Boolean
specification; it does not create or existentially construct tracked resources.
It has no E parameter or live-state transition. Thus it is only the fixed
post-state component of the law, NOT its event/linearity implementation. That
limitation is expressly acknowledged and is not itself an inconsistency.

The raw equations agree with inherited vstd/raw_ptr.rs:908 normal-success
allocate contract (lines917-926). This is a consistency comparison, not a checked
refinement between two executable allocation calls. The extra nonnull condition
is an admission premise. Dealloc's public view plus raw domain/provenance must
denote genuine live authority, not an empty token or unrelated existential
witness. Source predicates and private Rust struct ownership cannot supply it.

No separate global numeric address-freshness axiom is needed or approved. Reuse
after deallocation is allowed; generation identity and no overlapping live
authority must follow from the resource/event semantics and allocator contract.
No initialized header, Arc counters, payload zeros, iterator lengths, successful
cleanup, caller invariant, totality, progress, termination, panic rollback,
or unrelated-state frame follows. The leaf is conditional: null/error/unwind/
abort/divergence produce no normal-success witness or pair. They are not equated
with one another or with vstd allocate's null-to-abort wrapper behavior.

### Counterarguments considered

- Requiring the whole Arc/durability proof before judging this leaf would
  conflate a conditional primitive schema with its application. Rejected.
- Treating agreement with inherited allocate equations as an original-event
  resource producer would omit the exact new trust being reviewed. Rejected.
- Calling event identity, writable live ownership, deallocation-generation
  correspondence, ABI alignment interpretation, or one-shot issuance merely
  application work would omit necessary primitive semantics. Rejected.
- Demanding an arbitrary ambient frame as part of the minimal success clause
  is unnecessary. Keeping pre-existing memory facts across the call, however,
  does require a justified footprint/frame relation before composition.
- A thin pointer's numeric address and a same-shaped DeallocData do not prove
  authority. The complete pointer/generation and genuine-resource clauses are
  essential; the pure predicate must never be installed as an unrestricted axiom.

## Concrete findings in uncompiled static source

### F159-1 — HIGH producer blocker: second raw ABI operand is Alignment, not usize

candidate/source/rust_verify/src/primitive158.rs:75 asserts two operands and
lines76-78 assert BOTH instantiated operand types equal tcx.types.usize.
For the pinned runtime the declaration is instead:
alloc/src/alloc.rs:22, __rust_alloc(size: usize, align: Alignment) -> *mut u8;
it is unsafe extern "Rust", with rustc_allocator and rustc_nounwind attributes.
alloc.rs:130 passes layout.size(), layout.alignment().

This is independently visible in authenticated inspect-native.stdout:256,
where the selected raw call passes copy _3, move _26, and the immediately prior
statement assigns _26 = copy (_1.1: std::mem::Alignment). That is the inherited156
observation read by158, NOT a new158 run. The inherited allocation156.rs:122 only
asserts the FIRST operand is usize;158 incorrectly strengthened that to both.

Alignment is a repr(transparent) struct with AlignmentEnum, not a usize type
alias (core/src/mem/alignment.rs:16). The equal size/alignment representation
assertions do NOT make Rust Ty equality hold. instantiate erases regions and
normalizes types; it does not erase a nominal newtype into usize. Therefore,
if this selector reaches that pinned leaf, its second-argument assertion fails
before producing the pending record. This is a definite source-level selection
defect, not a missing Arc proof and not a demonstrated Rust compilation error
or observed selector panic. No compiler/native execution was used to infer it.

Necessary future correction, not performed here: identify the exact typed
Alignment definition/ABI and bind its numeric interpretation (as_usize at
alignment.rs:205) to A and to the matching deallocator layout. Merely deleting
the assertion, substituting align8, or treating repr equivalence as type or
semantic equality would not establish that binding. This is a primitive ABI
boundary obligation and blocks concrete use even if the math schema is disposed.

### F159-2 — LOW opt-in contract discrepancy, no resource issue

LAW158's claim that no pending node is created without --pending-occurrence158
is literally stronger than the implementation. primitive158.rs:87 constructs
PendingIssue158 unconditionally; line92 consults enabled only before consuming
it into JSON. Thus the flag gates serialization of the node, not construction
of the internal metadata node. The Cargo feature still gates the binary;
neither path issues native resources. This does not invalidate the mathematical
law or demonstrate an authority leak. It is not a request to repair158.

### F159-3 — MEDIUM evidence wording discrepancy, no new158 MIR output exists

LAW158.md:33-35 says compiler-observed typed instances/operands/normal successor
and runtime MIR are retained in checks/*.pending.json. No such158 files exist:
the authenticated manifest includes only the three affinity .rs checks.
REPORT158.md:32-35 accurately says the bin did not finish building and produced
no pending.json; original-route observations are inherited156. The correct
evidence is inherited material including inspect-native.stdout, not executed
158 producer output. Parent should retain the accurate report's qualification
and not repeat LAW's unsupported artifact assertion.

### Deliberately not reported as newly discovered code defects

Dynamic event witnesses, replay/stale-holder checking, pointer interpretation,
applicability VCs and real resource lowering are unimplemented and openly marked
OPEN. They block any issuer acceptance but are not a new bypass exploit in this
disabled metadata-only path. Broad symbol-name selectors, raw syntactic call
graphs and uniqueness assertions are not semantic admission; I do not claim a
wrong occurrence is actually selected on these pinned inputs without evidence.
No hard Rust compile failure or incorrect numeric predicate clause is established.
The unconditional error at bin/primitive158.rs:289 refuses native export after
the callback; no verified AIR/SST/VIR issuer or assume_new path was installed.

## D. Runtime, ABI, allocator, and frame obligations still required

1. Bind the exact rustc/sysroot/library/runtime revisions and target
   aarch64-apple-darwin, target layout, edition2024, std feature/cfg, build profile,
   panic=unwind and relevant optimization/inlining settings. Hash endpoints do
   not prove source-to-binary/bootstrap or final linked-code correspondence.
2. Bind the actual selected typed shim ABI: usize size, core::mem::Alignment
   alignment, *mut u8 return, extern Rust and its allocator/nounwind semantics.
   Establish S and A from the actual typed operands, not Debug text or a
   machine-representation guess. Bind __rust_dealloc's NonNull<u8>, usize,
   Alignment interpretation and the API-level same-layout deallocation regime.
3. Identify the actual global allocator selected by #[global_allocator] versus
   std's default __rdl route, its linked shim/provider and exact allocator /
   deallocator pairing. Source library contracts are not a proof of the linked
   implementation. Assume/justify that implementation satisfies the reviewed
   success ownership/layout/provenance contract on well-defined executions.
4. Distinguish logical global allocation API events from underlying allocator
   method calls. The pinned core/alloc/global.rs:99-117 permits elimination or
   merging, specifies logical exact allocation size/alignment and derived-pointer
   restrictions, and separates API allocations from direct GlobalAlloc methods.
   Do not infer one physical allocator call per source/MIR occurrence, allocation
   counters, or a direct-method Dealloc from symbol identity. Any such lowering
   must preserve this exact event's allocation/resource semantics, or fail closed.
5. Prove the actual false/nonzero branch, positive valid size/alignment, normal
   nonnull return, exact return pointer interpretation, one-shot witness and
   native live-resource environment correspondence. The primitive's genuine
   owned allocation and matching deallocator relation must be established at
   this boundary; these are not delegated to Arc or application invariants.
6. If retaining pre-existing currently allocated owned-memory resources, identify
   exactly their live allocations, initialized contents, provenance, loans and
   permissions, and justify preservation across all actual call effects. There
   is a concrete candidate basis: pinned core/src/alloc/global.rs:155-156 forbids
   the allocator reading, writing or deallocating currently allocated user memory.
   Lines108-110 additionally disallow accessing an API allocation through unrelated
   retained underlying allocator pointers until API deallocation/reallocation.
   Applying these contracts requires the selected implementation, API boundary,
   well-defined execution and frame ownership to match. This review adds NO
   such frame equation to LAW158; any trusted frame extension needs its own
   exact justification/review. Without it, carrying those old resources is blocked.
7. That owned-memory frame is not allocator metadata/private arenas, arbitrary
   ambient state, stacks, caches, locks, atomics, callback effects, panic hooks,
   caller invariants or reentry inertness. Separate actual effects and resources
   must cover those. opens_invariants none is not a heap/ambient frame theorem.
   In particular, an Arc header already written later cannot be transported as
   the original untouched raw/uninitialized header, nor may initialized values
   be recovered after their permissions are forgotten or invalidated.
8. The pinned shim has rustc_nounwind and recorded unwind Unreachable, and the
   unsafe GlobalAlloc contract forbids unwind (global.rs:158-160). These are
   precise ABI/defined-behavior qualifications to bind, not a termination theorem
   or blanket no_unwind for Global/Arc, error handlers, caller hooks, or the
   application. Null/error/abort/divergence and any unsupported unwind path
   remain distinct, issue no pair here and gain no rollback/frame guarantee.

Native layout/array/extend/pad proofs, Arc header/metadata and initialization,
iterator/offset/index/object bounds, current resource splitting/stores, cleanup,
caller flow and eventual durability are still checked composition obligations.
They are not preconditions for this limited mathematical review and receive no
credit from it.

## Preserved failure and custody limits

158's strict2GiB violation is not excused: FAILURE158 records2174758912 allocated
bytes at violation versus2147483648 allowed, with additional sealing metadata
later. HANDOFF158 reports17/32 charged commands. Its normal build receipt and
raw child exit status are missing. The sealed release records killed/reaped
groups absent; this review does not manufacture historical process observations
or repeat a build. No158 binary, tests, solver run or pending producer output
is claimed. All failed/partial artifacts are preserved unchanged.

Review159 uses no compiler/build/verifier/native execution, compiler slot,
network, credentials, Git writes, parent/candidate edits, original application
execution, destructive cleanup, or subdelegation. Only fresh task159 report /
authentication / sealing files are written under its new /private/tmp root.
Exit authentication and archive readback are custody checks, not program tests.
Bounds are endpoint observations with a conservative final metadata reserve,
not a continuous external disk monitor. Parent disposition and any further work
are exclusively the parent's responsibility after this sealed review stops.
