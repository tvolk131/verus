import datetime
import hashlib
import json
from pathlib import Path
import stat
import sys

ROOT = Path('/private/tmp/redb-review159-20261109-000016')
INPUT = Path('/private/tmp/redb-primitive158-20261108-234646')
RUNTIME = Path('/private/tmp/verus-pinned-rust-source-20261107-9FT58F/rust-src-1.99.1/rust-src/lib/rustlib/src/rust/library')
inventory = {entry['path']: entry for entry in json.loads((INPUT / 'initial-source.json').read_bytes())}
external = {entry['path']: entry for entry in json.loads((INPUT / 'inputs.json').read_bytes())}

def check(path, expected):
    assert stat.S_ISREG(path.lstat().st_mode), str(path)
    data = path.read_bytes()
    observed = {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
    assert observed['bytes'] == expected['bytes'] and observed['sha256'] == expected['sha256'], str(path)
    return observed

selected = []
for relative in ['source/rust_verify/src/allocation156.rs', 'source/vstd/raw_ptr.rs', 'source/vstd/layout.rs', 'source/vstd/vstd.rs']:
    selected.append(check(INPUT / 'candidate' / relative, inventory[relative]))
for relative in ['alloc/src/alloc.rs', 'core/src/alloc/global.rs', 'core/src/mem/alignment.rs']:
    path = RUNTIME / relative
    selected.append(check(path, external[str(path)]))

patch = (INPUT / 'source-relative158.patch').read_text().splitlines(keepends=True)
patch_checks = []
position = 0
while position < len(patch):
    if patch[position] == '--- /dev/null\n':
        relative = patch[position + 1].removeprefix('+++ b/').rstrip('\n')
        position += 3
        additions = []
        while position < len(patch) and not patch[position].startswith('--- '):
            assert patch[position].startswith('+'), relative
            additions.append(patch[position][1:])
            position += 1
        expected = ''.join(additions).encode()
        assert (INPUT / 'candidate/source' / relative).read_bytes() == expected
        patch_checks.append({'path': relative, 'bytes': len(expected), 'patch_addition_equals_candidate': True})
    else:
        position += 1
assert len(patch_checks) == 3
phase = sys.argv[1]
result = {'phase': phase, 'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'coverage': 'Supplemental selected source endpoints, authenticated after initial textual inspection against sealed158 initial-source/inputs inventories; no whole inherited tree or runtime binary audit.', 'selected': selected, 'new_file_patch_readback': patch_checks}
if phase == 'exit':
    previous = json.loads((ROOT / 'SUPPLEMENTAL159-entry.json').read_bytes())
    assert previous['selected'] == selected and previous['new_file_patch_readback'] == patch_checks
    result['selected_endpoints_equal_supplemental_entry'] = True
(ROOT / ('SUPPLEMENTAL159-' + phase + '.json')).write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
print(json.dumps({'phase': phase, 'selected_source_endpoints': len(selected), 'new_patch_files_byte_identical': len(patch_checks), 'utc': result['utc']}))
