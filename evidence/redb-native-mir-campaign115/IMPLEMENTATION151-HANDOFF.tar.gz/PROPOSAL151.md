# Allocation151: fixed normal-result proposal, NOT adopted

## Exact selected application and library path

The original source is `/private/tmp/redb-original-crate-preflight115/redb`.
Only the compiler analyzes it. No original application or test executes, and
no original source is edited. The selected target is aarch64-apple-darwin,
edition2024, std enabled, panic=unwind, rustc1.99.1. Source inventories and
full argv/environment/streams are sealed. Bootstrap and compiler-to-library
source correspondence remain unestablished. The supplied archive SHA
e485a88c45db546b73571df7bebfcb4454ba4fb552c492e25fc5b00eeb5bf22d
is inherited selection information, not a newly established bootstrap claim.

Actual typed MIR binds the original zero_filled_arc call to repeat_n::<u8>
with operands `const 0_u8`, `copy _1`, followed by Iterator::collect with
RepeatN<u8> and Arc<[u8],Global>. Resolved specialization selects the
TrustedLen ToArcSlice implementation and Arc::from_iter_exact::<u8,RepeatN<u8>>.
There are20 captured instantiated MIR bodies and17 explicitly uncomposed
dependencies. This is a bounded graph, NOT a proved transitive closure.

The actual from_iter_exact payload store is bb6 statement6:
`(*_19) = copy _18`, typed u8. The same MIR obtains index _17 and item _18
from the Some((usize,T)) iterator result, and computes
`_19 = Offset(copy _7, copy _17)`. Arc::allocate_for_layout has actual strong
and weak atomic-field stores at bb11 statements5/9, both copying _25;
the checked MIR computes `_25 = const 1_usize as Atomic<usize> (Transmute)`.
These are compiler observations, not admitted ownership/byte equations.
The exact MIR, source spans, instantiated call arguments and store records
are in original-store.json/final-original.json and final-cut.binding.json.

## Exact primitive proposal P151-v1

P151-v1 is ONLY a proposed raw normal allocation grant and typed u8 store
boundary. It does not grant a trusted repeat_n, Arc collector, cache, hasher,
caller invariant, or checkout summary. No law is installed into the compiler.

1. A normal raw allocation grant, for an already-proved valid nonzero layout
   L, supplies one affine, exclusively writable uninitialized block resource
   B(p,g,L). Here p is the base and g is a fresh live allocation/provenance
   generation, not a globally fresh numeric address. Size/alignment and the
   available uninitialized byte mask equal L. The grant is not derivable from
   syntactic constructor identity, successful Rust compilation, or non-nullness.
   All caller-visible allocator/runtime/reentry effects must be represented
   separately. No unchanged ambient frame or inert callback is implicit.
2. A normal typed u8 store, with exclusive permission for in-bounds aligned
   cell (p,g,index), consumes that cell's previous initialization/value state
   and returns exactly one permission for the same cell containing the actual
   u8 operand. Every disjoint byte/resource remains unchanged by THIS store.
   No raw alias inventory, other thread's permission, allocation identity or
   handle is created. Existing initialization at the target is overwritten;
   a u8 has no destructor callback. Failure/UB cannot be used as a normal proof.

The first rule remains conditional on the actual runtime grant and its effect
frame. In particular the open __rust_alloc/__rust_alloc_zeroed and allocator
shim/runtime dependencies do NOT receive a blanket normal-return frame law.
The second rule is source-bound to the observed actual native payload store.
Both exact proposals need independent disposition before any adoption.

Arc header initialization, slice metadata, from_ptr wrapping, iterator count,
u8 clone identity, finite successful enumeration, layout checks and unwind
behavior are library/body obligations around these primitive rules. They are
NOT silently incorporated into a newly trusted Arc/iterator contract. Even
len=0 still needs the real nonzero Arc header allocation. No totality, eventual
success, latest loads, weak-CAS progress, panic rollback or finite hooks follow.

## Implemented conditional solver cut and its limits

The exact mathematical boundary is implemented in final-cut.rs:
normal_allocation, normal_byte_store and conditional_native_trace. It models
an allocation/generation descriptor, one handle identity, strong/weak counts,
an Option<u8> sequence (None means not initialized), and a disjoint ambient
byte map. These are mathematical values, NOT affine native authority tokens.
In particular equal descriptors do not prove absence of aliases or manufacture
permission to call Arc::get_mut. The raw grant/token correspondence remains OPEN.

The trace premise explicitly requires the unproved normal library result:
initial fresh descriptor/length/uninitialized payload/counts/frame; exact
repeat_n sequence length and actual extracted element; each exact indexed byte
store and frame; and Arc wrapping that returns the final descriptor unchanged.
The ambient-frame premise is conditional, not an assertion that an arbitrary
allocator/runtime/callback preserves it. No original caller invariant is used.

Ordinary VIR/WF/mode/SST/AIR/SMT verification proves three authored bodies:
initialized-prefix induction, the arbitrary-usize normal-result zero-byte/
length/descriptor/frame consequence, and a general witness showing these
premises have models for every length and fresh descriptor, including zero.
The theorem does not assume its final all-zero postcondition. Its repeat_n
element comes from the typed original operand. A real scratch source mutant
changes that operand to1; re-analysis/re-generation then fails precisely the
zero-byte postcondition, while induction and the witness still verify.

This is a source-parameterized CONDITIONAL downstream proof, not verification
of the original executable zero_filled_arc, original Arc collector loop, or
checkout. The state relations are not automatically derived for native MIR.
There is no installed native primitive semantics, native resource certificate,
trusted application helper, external_body helper, admission weakening, or147
marker API consumption. Current native verified-body/law counts remain0/0.

## Actual checkout frontier and next SMALL obligation

The original write MIR has the fresh call at bb86 with operand `copy _3`.
The actual LRUWriteCache::insert call at bb95 uses `copy _172`, `copy _2`,
`move _174`; take_value at bb97 uses `copy _176`, `copy _2`. The earlier
take_value at bb31 is a distinct occurrence, not the fresh result. Binding
these operands does not prove branch guards, moves through the native cache,
hasher behavior, reservations, the returned WritablePage, or unlock frames.
No checked native allocation result exists to connect to checkout or mem_mut.

The next small actual checked obligation is the ONE observed u8 store at
from_iter_exact bb6[6]: bind its base/index/item and a genuine P151 byte-cell
permission to an ordinary native VIR store rule, proving same generation,
one initialized byte, preserved length and disjoint frame. This needs exact
independent disposition of the typed-store rule; allocator grant and count/
iterator initialization remain explicit preceding OPEN dependencies. Do not
begin a full map/history engine or trust a cache summary to bypass them.

H1/H2 of149 remain unresolved and147 remains RETAIN UNADOPTED. All18 original
cells remain OPEN. Nothing here licenses source integration or native export.
