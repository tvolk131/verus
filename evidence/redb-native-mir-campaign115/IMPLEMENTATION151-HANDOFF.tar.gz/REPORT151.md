# Task151: sealed conditional allocation-entry solver cut

## Outcome

An actual ordinary Verus solver application now proves3 authored conditional
bodies for arbitrary usize lengths: initialized-prefix induction; the normal
zero-byte/length/identity/count/frame consequence; and a general consistency
witness for the premises. Fresh vstd support verifies2225 bodies,0 errors.
VIR, AIR, SMT2 and solver transcripts are retained. This is not another
false-debt AST compilation or diagnostic-only inventory.

Original executable bodies verified:0. New primitive laws adopted:0.
Actual native allocation/affine authority and checkout-to-mem_mut proof:OPEN.
All18 campaign cells:OPEN. Native export:REFUSED, metadata absent.
The exact proof conditionality and unadopted fixed primitive proposal are in
PROPOSAL151.md; final-cut.binding.json binds the actual typed operand and stores.
The proof has no admit/assume/external_body application helper. Standard vstd
primitive/specification trust is inherited, not an extra native law disposition.

## Source and solver evidence

- Original repeat_n::<u8> receives0 and the real len operand. Arc collect
  specialization and the actual typed u8 payload store/header stores are bound
  by compiler analysis. The bounded20-body graph has17 uncomposed dependencies.
- The exact fresh checkout operands are recorded, but map/hasher/reservation/
  caller frames and complete native control-flow semantics are not assumed.
- final-source-bound-solver:3 verified,0 errors. semantic-byte-mutant-solver:
  2 verified,1 error at the all-zero postcondition. The scratch crate changes
  actual executable source repeat_n(0u8,len) to repeat_n(1u8,len); neither runs.
- Correcting that scratch source restores exact original bytes, then fresh
  compiler binding/generation and restored-source-bound-solver again give
  3 verified,0 errors. final-cut.rs and restored-cut.rs are byte-identical.
- After those proofs, final-original-export-refusal freshly analyzes the actual
  original source:exit1 with explicit OPEN prerequisites and no native metadata.
- No147 marker API is used; no standard/cache/application summary is adopted.
  Parent143/148/150 and original source remain unchanged. Historical allowances
  stay exhausted/sealed;151 is separate and starts no followup/review.

## Failures retained, not reset or miscounted

Initial vstd setup lacked built builtin macro libraries; a diagnostic repair
attempt additionally used /usr/bin/env, which lost macOS DYLD loading. These
nonzero attempts are charged and retained. Building the needed --lib targets
and supplying VSTD_KIND directly corrected setup. The first native-binding
build exposed pinned rustc API differences; two charged repairs precede the
successful build. A first proof import lacked dependency search paths, and
the next frontend rejected while in proof mode; induction corrected it.
Neither pre-SMT failure is counted as a solver proof. The source-byte mutant's
postcondition failure is the intended semantic negative, not a setup failure.
Ordinary original native export refusals are also nonzero charged commands.
One seal-preparation source-history reconstruction initially mismatched a
runner hash; the exact-text repair matches all recorded hashes on rerun.
The read-only ps inspection was sandbox-denied; it is not process evidence.

## Custody and limits

The baseline SEAL.json matches
c1491e800f1980aa2d3ee14d51dd220e80606c7ae346e53d157208dbb98cc27f,
and the initial candidate equals150 source-final.json. Selected baseline,
original and Rust-library inputs authenticate before every charged command
and at exit. These are endpoint checks, not continuous custody, transitive
OS/runtime authentication, historical Git continuity or bootstrap proof.
The supplied library archive hash remains a local inherited selection only.

Receipts retain full argv/env/status/clocks/streams, source inventories,
executable/runner hashes and resource samples. Initial runner commands2-4 have
entry source inventories but no contemporaneous final-source inventory; this
instrumentation limitation is not retroactively relabeled as endpoint custody.
Later runners add final snapshots, and final proof/mutant/restoration/refusal
commands have explicit argument-file/solver endpoint hashes. Earlier runner
variants are reconstructed only when bytes match their already-recorded hash;
that is source availability, not attestation of historical interpreter loads.

All charged children are reaped; receipts observe their owned groups absent.
Signals target only an acquired unreaped child, never a reaped/recycled PGID.
No general hostile-descendant containment theorem is claimed. Final counts,
resource extrema, restoration inventories and explicit compiler-slot release
are in SUMMARY151.json/RELEASE151.json. The complete final candidate and raw
proof evidence are archived; target artifacts have endpoint hashes but are
not shipped as a replayed/bootstrap-attested compiler bundle.

Next SMALL actual checked obligation: the single typed native payload store
and real byte-cell permission/frame described in PROPOSAL151.md, after exact
independent law disposition. No native checkout/mem_mut/first-cell closure.
