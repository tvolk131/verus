# Cancellation118 revision2 — targeted source-review repair

This new scratch preserves original107, repair118, all their test logs and the
read-only review's three findings. No old failure or allowance is reset.

F1 is addressed by deferring standard main-thread SIGINT through ownership-handle
publication. Short guarded wait slices also protect OS-reap/status publication.
F2 is addressed by never signaling a reaped child's historical numeric group
identifier, including interruption inside that status-publication window.
F3 preserves the original caught interruption if
best-effort receipt persistence fails. The tests separately cover launch-time
SIGINT, OS-reap publication interruption, already-reaped refusal, unsupported
signal setup/thread/handler, and
ENOSPC-style persistence failure. Group signaling and direct-child reaping are
described separately; detached descendants remain outside the trusted-command
boundary. Arbitrary exceptions injected inside Popen are not containment claims.

The standard-SIGINT/main-thread launch restriction is explicit and fail-closed.
Source-only review is not runtime acceptance, and passing tests are not native
semantics, compiler-source attestation or proof. Fresh independent review of
this revision is still required. The helper is not integrated or adopted.

All18 redb cells remain OPEN. Native/resource/trust credit remains zero. This
repair supports safe diagnostic collection; it does not discharge native page
lifecycle correspondence or replace the original database goal.
