# Targeted cancellation repair118 revision2 — validation checkpoint

This candidate is scratch-only and not integrated/adopted. It preserves the
blocking107 review, the intermediate118 source and42/13 passing logs, and the
source review that found three remaining cancellation gaps.

## Changes

- Standard main-threadSIGINT is deferred until Popen publishes the direct-child
  handle and started status. Unsupported handlers/thread setup refuse spawning.
- At-most0.1-second guarded wait slices deferSIGINT through OS reap and Python
  return-code publication, avoiding an unowned numeric-group signaling window.
- Cleanup signals only while the direct child is unreaped. Cancellation refuses
  success even if the completed child's eventual status was zero.
- Receipt persistence failure preserves the original caughtKeyboardInterrupt or
  SystemExit, with the persistence failure chained. A complete receipt is not
  claimed when publication fails. Documentation distinguishes group signaling
  from direct-child reaping and retains the trusted-command/descendant boundary.

## Executed validation

Attempt001:47 author tests and13 adapted historical reviewer tests pass, both
exit0. Before extending the wait-publication protection, all five tested source
inputs were later reconstructed byte-exactly against their original pre-run
hashes. That directory is explicitly a post-run reconstruction, not an entry
snapshot. Its reviewer observations were renamed/preserved before another run.

Attempt002:48 author tests and13 historical reviewer tests pass, both exit0.
This version adds actualSIGINT injection between OS waitpid reap and return-code
publication, asserting cancellation refusal with no group signal. It also tests
actual OS launch before handle return, unsupported signal setup/thread/handler,
already-reaped refusal, and syntheticENOSPC preserving both exception kinds.
The exact five final source inputs were copied before execution; all selected
input and resolved interpreter hashes match after both commands. These are
authored-Python subprocess tests, not compiler, solver or redb application runs.

Each command has a separate argv/environment/status/timing record, actual
epoch-nanosecond boundaries, raw stdout/stderr and digest bindings. The final
interruption observation reports successfalse, child signal9 and no live direct
child after capture. Test fixtures using fake PIDs mock group signaling; they
never signal those numeric IDs on the host.

## Failures and limits retained

The first post-run reconstruction helper failed before writing any snapshot:
suffix classification matched test_capture_provenance_receipt.py as the capture
module, so a substring lookup raisedValueError. The corrected helper uses exact
filenames and authenticates all five recovered inputs. The original terminal
traceback is available in the parent tool transcript, not an independently
captured raw file. No test failure, compiler run or proof result is hidden by
that separate bookkeeping failure.

This helper still offers selected endpoint observations only. No transitive
stdlib/platform custody, compiler-source correspondence, detached-descendant
containment, native lifecycle semantics, trusted producer or proof acceptance
is established. Repeated interruption or process termination can prevent a
complete receipt. Arbitrary injected exceptions inside Popen are outside the
documented launch containment guarantee. Fresh independent review/rechecks of
this final revision remain required before considering even narrow retention.

All18 redb cells remainOPEN. Native/resource/trust/final-cell credit is zero.
