# Independent bounded review125 of completed validation122

## Disposition and objections

Diagnostic observations are independently corroborated, NOT adopted as a native
mapping or strict-oracle pass. All18 remain OPEN. Native/resource/trust/proof
credit is 0/0/0/0. No law, admission, import/export, trust policy or input changes.

**O1 — blocking for provenance adoption:** the DIRECT relation
`Scope.value == origin.expression` supplies no witness for the actual original
e78 -> _20 WritablePage temporary. There are ZERO corresponding edges, not an
unknown or incomplete arena. This defeats this direct join as the proposed
witness for this temporary, NOT every possible origin route and NOT the compiler.
TempLifetime(Node72), neighboring expressions, nearest/equal spans, wrapper
ancestry and cardinality supply no substitute HirId. No approved native mapping
exists. This objection is already accurately disclosed by validation122.

**O2 — controls remain incomplete:** genuine hook-before-retain INCOMPLETE,
full-arena COMPLETE_EMPTY, multi-edge ambiguity, actual KEY_MISMATCH, and equal
THIR expression spans are UNVALIDATED. A compiler type error is not an incomplete
helper capture. The empty function still has one Scope edge. Equal MIR local
declaration spans are not established equal THIR spans. These limitations are also
accurately disclosed by the author; the review grants no additional coverage.

**O3 — provider/source correspondence remains bounded:** this observer overrides
the custom MIR builder hook and elaborated-MIR provider, not `queries.thir_body`.
THIR comes from the installed sysroot default provider. Compiling custom expr.rs
does not establish that its lowering or scope_post executed here. The retained
build correspondence is not a compiler bootstrap proof, complete platform/SDK
custody, independent reproducible rebuild or source-to-native resource proof.

No additional material contradiction was found in the author's bounded diagnostic
claims. This is not semantic, mapping, native-proof or strict-oracle approval.

## Authentication and source/build correspondence

Entry authentication independently checks the supplied seal SHA256
`a27928a39bc5a6f08e5958f7520d5328c4e26a7167664fd30841964bc7ffc65f`,
all 455 actual `records` entries using their path/bytes/sha256 schema, and all
4,903 actual `ENTRY-AUTHENTICATION.json.records` input bindings. These are local
content bindings, not invented whole-platform custody. Original132 files are
included; c82ab865bb362bc4af067d332adc44978ff64813 is the supplied recovery
reference, not re-established Git continuity. EXIT-AUTHENTICATION.json records
the same checks again at sealing. No Git command is used.

BUILD-BINDING.json's helper, observer, libc, executables, build plan, receipt and
source-identity references all match current bytes. All 53 build source-identity
records match. All 49 selected frozen sources were compared with the actual
stage: ONLY checked_drop_origins.rs differs. It equals task120's supplied SHA256
1aa55b6d95997e1950cc548119ae6b9b83ff3c69af98c36f0790cff895c0ca79.
The actual observer equals the parent's supplied reporting source SHA256
2f5b92ba4be0f14a654034d5c943b407d7e0749697945de59c66bbbd9e70093a.
The staged manifest points at ../source/rustc_mir_build; the retained depfile
explicitly names that changed helper. The successful retained build log names
the same staged dependency. No build was repeated in this review.

Reviewed helper changes add the table/session/body capture and scan every raw
Scope edge at the existing retain site. Existing frozen/runtime statements,
normalization, Infer, full-scope and export semantics were not edited. Observer
matching uses exact ExprId equality, session generation/native flag, and body;
it preserves MISSING, KEY_MISMATCH, INCOMPLETE, COMPLETE_EMPTY and
COMPLETE_NONEMPTY. There is no first-match, span join or recursive-ancestry join.
Capture cardinality and flags do not establish reachability, unique occurrence,
ownership, resources or an approved HIR/VIR mapping.

Compared with the retained task120 observer, the parent's only additional diff
is truthful result classification for compiler failure and absent/nonunique
target. P3 discovery enumerates same-name body owners separately from queries:
126 elaboration-provider invocations, 2,428 owners enumerated, one explicit
selected request. It does not claim discovery establishes query history.

Publication review: observer rejects existing destinations and noncanonical
parents, reserves create_new staging, writes/flushes/syncs, then hard-links to
the destination without clobbering. A publication failure or compiler failure
exits70; absent/nonunique target exits65; successful raw observation exits2 with
explicit proof refusal. Helper uses create_new output, and its outer exit0 alone
does not establish internal success; all three session records were inspected.
No additional publication-race test was run or claimed.

## Fresh diagnostic evidence

Four sequential existing-executable commands ran in place. They use fresh report,
cwd and TMPDIR paths. No executable, target, artifact, cache or toolchain copying.
Each `records/CASE/launch.json` is written BEFORE Popen and records exact full
environment (not ambient inheritance), outer argv, expected inner compiler argv,
cwd, current source/binary/native/libc inputs, output absence observations and
registration epoch ns. The receipts retain real begin/end epoch ns, output
presence/hash/mtime observations, raw stdout/stderr, status and resource samples.
The observed inner compiler argv matches the preregistered values for all six
sessions. Absence/presence timestamps are observations, not invented creation
times or replacements for missing historical clocks.

- original-header: exit2; begin1794161062216920000, end1794161064002665000.
  Explicit stderr: native proof refused; raw MIR diagnostic retained.
- wrong-qualified: exit65; begin1794161081365200000, end1794161083050000000.
  Compiler completed and after_analysis reached, zero explicit selected requests,
  zero captures; TARGET_NOT_UNIQUELY_OBSERVED.
- compiler-failure: exit70; begin1794161083101043000, end1794161083208687000.
  Genuine fixture E0308 u32 versus &str; after_analysis not reached, zero captures;
  COMPILER_DID_NOT_COMPLETE_RAW_EVIDENCE_ONLY, not INCOMPLETE-helper validation.
- helper-controls: exit0; begin1794161083259649000, end1794161083367324000.
  Three internally sequential completed compiler sessions, not one compiler run.

The fresh original header's complete capture equals the author's raw capture
byte-for-byte as JSON values except observer process ID. Independent extraction
from the raw report, not SUMMARY.json, checks Runtime(PostCleanup), 109
expressions, 37 Scope edges, 30 temporary queries, 39 locals, two drops and
11 calls. All30 query edge lists were recomputed from the raw37 edges using
exact value-expression equality. Counts are 18 COMPLETE_NONEMPTY and 12
COMPLETE_EMPTY; all37 arena value keys are distinct.

e78 remains _20 WritablePage, scopeNone, lifetime Some(Node(72)); its matching
status is COMPLETE_EMPTY in a COMPLETE_NONEMPTY arena. Both bb16 normal and
bb19 cleanup drops reference _20, with zero matching edges and no recovered
Scope HirId. Normal targets are bb17/bb20; unwind is Cleanup(bb20) and
Terminate(InCleanup), respectively. No destructor/drop-glue identity or resource
effects were queried/proven. The strongest remaining semantic edge is the
unproved connection between this temporary/local, its lifecycle and both drops,
and approved native/HIR/VIR resource correspondence.

Fresh helper sessions reproduce the retained actual API observations. Disabled
fresh process has no session; both fixture bodies are MISSING before and after
forced queries. begin(false) creates generation1/nativefalse, and begin(true)
generation2/nativetrue. Prior real body keys are MISSING immediately after begin,
before the next compiler. Numeric body IDs recur without observed capture leakage.
In the enabled sessions, both bodies are ALREADY COMPLETE_NONEMPTY before the
explicit selected queries: eager construction occurred. Do not relabel those
pre-query observations MISSING. Empty is 2 expressions/1 edge; arithmetic is
10 expressions/5 edges. Separate API clones have equal debug representations;
this is not a mutation-isolation proof. nativefalse permits diagnostic capture;
it does not mean capture disabled, nor does nativetrue grant native proof credit.

## Retained failures, accounting and handoff

Read and authenticated PREPARATION-FAILURE-1.txt (Python tomllib unavailable),
retained v0/repaired collector sources, ANALYSIS-FAILURE-2.txt (read-only
KeyError('type')), and the retained AtomicU64::fetch_update deprecation warning.
They are not native application failures. No source repair, erasure or retrofit
of their unrecorded historical clocks occurred.

Author accounting is six OUTER diagnostic commands, conservatively eight when
the helper's three inner sessions replace its one outer charge; this includes
two pre-compiler flag refusals. Review125 omits those historical flag controls:
four OUTER commands = three single compiler sessions + three helper sessions =
SIX conservative compiler diagnostic invocations total. No other compiler,
build, Cargo, rustfmt, solver, verifier or native redb application was launched.
Each outer command is bounded at90 seconds, so each contained compiler session
is also bounded by90 seconds. Longest observed outer duration is1.787 seconds.

The collection guard enforces <=128MiB new logical scratch and strictly>16GiB
available space before/through/after diagnostics, sampling every0.1 seconds.
ACCOUNTING.json and the final collector output retain observed extrema. This is
sampled monitoring, not a filesystem quota or proof of continuous free-space
values between samples. Total review is bounded conservatively by18:13:00Z,
under12 minutes from its18:01:18Z first observation, including sealing.

EXIT-AUTHENTICATION.json, ACCOUNTING.json, COMPILER-SLOT-RELEASED.json and
SEALED-MANIFEST.json close this review. All owned process groups are reaped;
the sole compiler-diagnostic slot is explicitly RELEASED. No followup chain.
Worker116 remains interrupted at2026-11-08T17:02:52.937Z without final worker
handoff. Neither validation122 nor review125 completes it or resets its20 old
commands. Helper118 and synthetic oracle115 are not adopted as authority.
