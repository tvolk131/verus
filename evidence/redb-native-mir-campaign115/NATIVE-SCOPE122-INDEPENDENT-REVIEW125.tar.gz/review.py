import collections
import difflib
import json
from pathlib import Path
import time

from collect import AUTHOR, ROOT, digest, identity, save


def load(path):
    return json.loads(Path(path).read_text())


def header(report):
    assert report['classification'] == 'RAW_MIR_CAPTURE_NOT_NATIVE_PROOF'
    assert report['proof_acceptance'] is False
    assert report['native_resource_correspondence'] is False
    assert report['after_analysis_reached'] is True
    assert len(report['captures']) == 1
    capture = report['captures'][0]
    scopes = capture['thir_scope_capture']
    edges = scopes['all_raw_scope_edges']
    temporaries = capture['all_typed_builder_temporary_observations']
    assert scopes['status'] == 'COMPLETE_NONEMPTY'
    assert capture['mir_phase'] == 'Runtime(PostCleanup)'
    assert scopes['expression_count'] == 109
    assert len(edges) == scopes['edge_count'] == 37
    assert len(temporaries) == 30
    assert len(capture['drops']) == 2
    assert len(capture['calls']) == 11
    assert scopes['capture_body'] == scopes['expected_body']
    assert scopes['capture_session_generation'] == scopes['current_session_generation'] == 1
    assert scopes['capture_native_phase'] == scopes['current_session_native_phase'] is True
    for temporary in temporaries:
        query = temporary['exact_thir_scope_edges_with_value_equal_to_expression']
        expected = [edge for edge in edges if edge['value_expression'] == temporary['expression']]
        assert query['edges'] == expected
        assert query['temporary_expression'] == temporary['expression']
        assert query['matching_status'] == ('COMPLETE_NONEMPTY' if expected else 'COMPLETE_EMPTY')
        assert query['capture_status'] == 'COMPLETE_NONEMPTY'
        assert query['body'] == query['expected_body'] == scopes['expected_body']
        assert query['session_generation'] == query['expected_session_generation'] == 1
        assert query['native_capture_phase'] == query['expected_native_capture_phase'] is True
        assert query['hir_vir_mapping_approved'] is False
    interesting = [temporary for temporary in temporaries if temporary['expression'] == 'e78']
    assert len(interesting) == 1
    origin = interesting[0]
    assert origin['local'] == 20 and origin['type'].endswith('::WritablePage')
    assert 'scope: None' in origin['origin'] and 'Some(Node(72))' in origin['origin']
    assert not [edge for edge in edges if edge['value_expression'] == 'e78']
    assert [(drop['block'], drop['cleanup'], drop['local']) for drop in capture['drops']] == [(16, False, 20), (19, True, 20)]
    for drop in capture['drops']:
        assert drop['root_type'].endswith('::WritablePage')
        assert len(drop['matching_temporary_observations']) == 1
        observation = drop['matching_temporary_observations'][0]
        assert observation['expression'] == 'e78' and observation['scope'] is None
        assert observation['exact_thir_scope_edges_with_value_equal_to_expression']['edges'] == []
    counts = collections.Counter(item['exact_thir_scope_edges_with_value_equal_to_expression']['matching_status'] for item in temporaries)
    assert counts == {'COMPLETE_NONEMPTY': 18, 'COMPLETE_EMPTY': 12}
    assert len(set(edge['value_expression'] for edge in edges)) == 37
    return {'classification': report['classification'], 'mir_phase': capture['mir_phase'],
            'arena_expressions': scopes['expression_count'], 'scope_edges': len(edges), 'temporary_queries': len(temporaries),
            'matching_status_counts': dict(counts), 'distinct_arena_value_keys': 37,
            'drops': capture['drops'], 'calls_count': len(capture['calls']), 'e78': origin,
            'elaboration_provider_invocations_total': report['elaboration_provider_invocations_total'],
            'whole_crate_hir_body_owners_enumerated': report['whole_crate_hir_body_owners_enumerated'],
            'explicit_selected_query_requests': report['explicit_selected_query_requests']}


def controls(report):
    assert report['initial_session_none']
    assert report['proof_acceptance'] is False
    runs = report['runs']
    assert [run['mode'] for run in runs] == [None, False, True]
    observations = []
    for index, run in enumerate(runs):
        assert run['compiler_completed_without_panic']
        old_keys = run['old_body_keys_immediately_after_begin_before_new_compiler']
        assert len(old_keys) == (0 if index == 0 else 2)
        assert all(item['status'] == 'MISSING' and item['capture_present'] is False for item in old_keys)
        observed = []
        assert len(run['observations']) == 2
        for body in run['observations']:
            before = body['before_explicit_query']
            after = body['after_explicit_query']
            assert before['separate_api_clone_debug_equal'] and after['separate_api_clone_debug_equal']
            if index == 0:
                assert before['status'] == after['status'] == 'MISSING'
                assert before['session_generation'] is None and after['session_generation'] is None
            else:
                assert before['status'] == after['status'] == 'COMPLETE_NONEMPTY'
                assert after['session_generation'] == index
                assert after['session_native'] == (index == 2)
                assert after['native_api'] == (index == 2)
                expected_counts = (2, 1) if body['def_path'].endswith('::empty') else (10, 5)
                assert (after['expression_count'], after['edge_count']) == expected_counts
            observed.append({'def_path': body['def_path'], 'before_status': before['status'], 'after_status': after['status'],
                'generation': after['session_generation'], 'native': after['session_native'],
                'expressions': after['expression_count'], 'edges': after['edge_count']})
        observations.append({'mode': run['mode'], 'old_keys_before_compiler': old_keys, 'bodies': observed})
    return observations


def main():
    source_records = []
    changes = []
    baseline = AUTHOR / 'inputs/frozen-baseline'
    for original in sorted(baseline.rglob('*')):
        if original.is_file():
            actual = AUTHOR / 'stage' / original.relative_to(baseline)
            equal = digest(original) == digest(actual)
            source_records.append({'baseline': identity(original), 'staged': identity(actual), 'equal': equal})
            if not equal:
                changes.append(str(original.relative_to(baseline)))
    assert len(source_records) == 49
    assert changes == ['source/rustc_mir_build/src/builder/checked_drop_origins.rs']
    binding = load(AUTHOR / 'BUILD-BINDING.json')
    assert binding['helper']['sha256'] == '1aa55b6d95997e1950cc548119ae6b9b83ff3c69af98c36f0790cff895c0ca79'
    assert binding['observer']['sha256'] == '2f5b92ba4be0f14a654034d5c943b407d7e0749697945de59c66bbbd9e70093a'
    for key in ['helper', 'observer', 'libc', 'build_plan', 'build_receipt', 'source_identity']:
        assert identity(binding[key]['path']) == binding[key]
    for record in binding['binaries']:
        assert identity(record['path']) == record
    build_identity = load(binding['source_identity']['path'])
    for record in build_identity['records']:
        assert identity(record['path']) == record
    manifest = (AUTHOR / 'stage/observer/Cargo.toml').read_text()
    assert 'path = "../source/rustc_mir_build"' in manifest
    dependency_file = AUTHOR / 'target/debug/redb-native-mir-observer.d'
    assert binding['helper']['path'] in dependency_file.read_text()
    build_log = (AUTHOR / 'records/build1/stderr').read_text()
    assert 'Compiling rustc_mir_build v0.0.0 (' + str(AUTHOR / 'stage/source/rustc_mir_build') + ')' in build_log
    assert 'fetch_update' in build_log and 'deprecated' in build_log
    assert load(AUTHOR / 'records/build1/receipt.json')['returncode'] == 0
    helper_text = Path(binding['helper']['path']).read_text()
    observer_text = Path(binding['observer']['path']).read_text()
    assert '.filter(|edge| edge.value_expression == expression)' in observer_text
    assert 'Some(capture.session) != session || capture.body != body' in observer_text
    assert 'providers.queries.thir_body' not in observer_text
    assert 'builder.thir.exprs.iter_enumerated().filter_map' in helper_text
    old_observer = AUTHOR / 'inputs/task120/candidate/observer/src/main.rs'
    observer_diff = ''.join(difflib.unified_diff(old_observer.read_text().splitlines(True), observer_text.splitlines(True), fromfile=str(old_observer), tofile=binding['observer']['path']))
    save('SOURCE-BUILD-REVIEW.json', {'epoch_ns': time.time_ns(), 'frozen_sources_checked': source_records,
        'only_frozen_change': changes, 'build_binding': binding, 'source_identity_records_checked': len(build_identity['records']),
        'dependency_file': identity(dependency_file), 'observer_parent_reporting_diff_from_task120': observer_diff,
        'binding_scope': 'retained build receipt, depfile, exact current source/binary hashes; not independent rebuild, SDK custody or bootstrap proof',
        'normalization_infer_full_scope_runtime_import_export_changes': False,
        'provider_caveat': 'default installed sysroot THIR query; custom expr.rs/scope_post execution not established',
        'source_review': ['all raw Scope nodes retained, not first edge or recursive ancestry',
            'matching requires exact ExprId equality and session/native/body keys; preserves MISSING/KEY_MISMATCH/INCOMPLETE/COMPLETE_EMPTY/COMPLETE_NONEMPTY',
            'unique exact definition query forced once; same-name discovery does not prove query history',
            'observer destination checked absent, canonical parent; create_new staging, fsync, hard_link no-clobber publication',
            'observer exits 2/65/70 distinguish capture, absent target, compiler failure; never proof acceptance',
            'helper destination create_new; outer exit0 insufficient alone; inspect all three per-session compiler results']})
    prior_header = load(AUTHOR / 'reports/original-header.json')
    fresh_header = load(ROOT / 'reports/original-header.json')
    prior_facts = header(prior_header)
    fresh_facts = header(fresh_header)
    assert prior_facts == fresh_facts
    prior_capture = prior_header['captures'][0]
    fresh_capture = fresh_header['captures'][0]
    prior_capture['thir_scope_capture'].pop('observer_process_id')
    fresh_capture['thir_scope_capture'].pop('observer_process_id')
    assert prior_capture == fresh_capture
    fresh_controls = load(ROOT / 'reports/helper-controls.json')
    control_facts = controls(fresh_controls)
    assert controls(load(AUTHOR / 'reports/helper-controls.json')) == control_facts
    case_summaries = {}
    for name, expected_exit in [('original-header', 2), ('wrong-qualified', 65), ('compiler-failure', 70), ('helper-controls', 0)]:
        launch = load(ROOT / 'records' / name / 'launch.json')
        receipt = load(ROOT / 'records' / name / 'receipt.json')
        report = load(ROOT / 'reports' / (name + '.json'))
        assert receipt['returncode'] == expected_exit and receipt['termination_reason'] is None
        assert launch['registration_epoch_ns'] < receipt['begin_epoch_ns'] < receipt['end_epoch_ns']
        assert not launch['outputs_before'][0]['exists'] and receipt['outputs_after'][0]['exists']
        actual_inner = [run['compiler_argv'] for run in report['runs']] if name == 'helper-controls' else [report['compiler_argv']]
        assert actual_inner == launch['expected_inner_compiler_argv']
        if name == 'wrong-qualified':
            assert report['classification'] == 'TARGET_NOT_UNIQUELY_OBSERVED'
            assert report['after_analysis_reached'] and report['compiler_completed_without_panic']
            assert report['explicit_selected_query_requests'] == 0 and report['captures'] == []
        if name == 'compiler-failure':
            assert report['classification'] == 'COMPILER_DID_NOT_COMPLETE_RAW_EVIDENCE_ONLY'
            assert not report['after_analysis_reached'] and not report['compiler_completed_without_panic']
            assert report['captures'] == []
            stderr = (ROOT / 'records/compiler-failure/stderr').read_text()
            assert 'E0308' in stderr and 'mismatched types' in stderr
        assert report['proof_acceptance'] is False
        case_summaries[name] = {'returncode': receipt['returncode'], 'charged_sessions': receipt['conservative_sessions'],
            'begin_epoch_ns': receipt['begin_epoch_ns'], 'end_epoch_ns': receipt['end_epoch_ns'],
            'elapsed_seconds': receipt['elapsed_seconds'], 'classification': report.get('classification', report.get('scope'))}
    save('EVIDENCE-REVIEW.json', {'epoch_ns': time.time_ns(), 'header': fresh_facts,
         'fresh_vs_author_header_capture_equal_except_process_id': True, 'helper_controls': control_facts,
         'cases': case_summaries, 'all30_queries_recomputed_from_raw37_edges': True,
         'unvalidated': ['genuine incomplete capture', 'full-arena complete-empty capture', 'multiple Scope edges with same value',
                         'actual KEY_MISMATCH', 'equal THIR expression spans'],
         'no_native_mapping_approved': True, 'all18': 'OPEN', 'native_credit': 0, 'resource_credit': 0, 'trust_credit': 0, 'proof_credit': 0})
    print(json.dumps({'cases': case_summaries, 'header_counts': {key: value for key, value in fresh_facts.items() if key not in ['e78', 'drops']},
          'frozen_sources': len(source_records), 'changed_sources': changes}, indent=2))


if __name__ == '__main__':
    main()
