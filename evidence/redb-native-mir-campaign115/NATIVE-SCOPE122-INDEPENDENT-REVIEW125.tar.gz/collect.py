import datetime
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

ROOT = Path('/private/tmp/redb-scope-review125-20261108T180118Z')
AUTHOR = Path('/private/tmp/redb-scope-validation122-20261108T174715Z')
PIN = 'a27928a39bc5a6f08e5958f7520d5328c4e26a7167664fd30841964bc7ffc65f'
DEADLINE = int(datetime.datetime(2026, 11, 8, 18, 13, tzinfo=datetime.timezone.utc).timestamp()) * 10**9
LIMIT = 128 * 1024 * 1024
FLOOR = 16 * 1024**3
CASES = {'original-header': 1, 'wrong-qualified': 1, 'compiler-failure': 1, 'helper-controls': 3}


def digest(path):
    hasher = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            hasher.update(chunk)
    return hasher.hexdigest()


def identity(path):
    path = Path(path)
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': digest(path)}


def save(name, value):
    path = ROOT / name
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x') as stream:
        json.dump(value, stream, sort_keys=True, separators=(',', ':'))
        stream.write('\n')


def guard():
    scratch = sum(path.stat().st_size for path in ROOT.rglob('*') if path.is_file())
    stat = os.statvfs(ROOT)
    free = stat.f_bavail * stat.f_frsize
    observed = time.time_ns()
    assert scratch <= LIMIT, scratch
    assert free > FLOOR, free
    assert observed < DEADLINE, observed
    return {'observed_epoch_ns': observed, 'scratch_bytes': scratch, 'free_bytes': free}


def observe(path):
    path = Path(path)
    value = {'path': str(path), 'observed_epoch_ns': time.time_ns(), 'exists': path.exists()}
    if path.exists():
        value.update(identity(path))
        value['mtime_ns'] = path.stat().st_mtime_ns
    return value


def authenticate(phase):
    begin = time.time_ns()
    assert digest(AUTHOR / 'SEALED-MANIFEST.json') == PIN
    manifest = json.loads((AUTHOR / 'SEALED-MANIFEST.json').read_text())
    checks = []
    for record in manifest['records']:
        actual = identity(record['path'])
        assert actual['bytes'] == record['bytes'] and actual['sha256'] == record['sha256'], record
        checks.append(dict(actual, basis='validation122 sealed record', matches=True))
    original = json.loads((AUTHOR / 'ENTRY-AUTHENTICATION.json').read_text())
    assert len(original['records']) == 4903
    inputs = []
    for record in original['records']:
        actual = identity(record['path'])
        assert actual['bytes'] == record['bytes'] and actual['sha256'] == record['sha256'], record
        if record.get('expected_sha256') is not None:
            assert actual['sha256'] == record['expected_sha256'], record
        inputs.append(dict(actual, basis=record['basis'], matches=True))
    native = [record for record in inputs if record['path'].startswith('/private/tmp/redb-original-crate-preflight115/redb/')]
    assert len(native) == 132, len(native)
    save(phase + '-AUTHENTICATION.json', {
        'begin_epoch_ns': begin, 'end_epoch_ns': time.time_ns(), 'manifest_sha256': PIN,
        'selected_manifest_records': checks, 'immutable_input_records': inputs,
        'immutable_input_count': len(inputs), 'native_original_records': len(native),
        'scope': 'selected local content bindings only; no whole-platform custody, Git continuity or bootstrap correspondence',
        'resources': guard(),
    })
    print(phase, 'authenticated', len(checks), 'sealed records and', len(inputs), 'immutable inputs', flush=True)


def initialize():
    save('COMPILER-SLOT-ACQUIRED.json', {
        'epoch_ns': time.time_ns(), 'sole_owner': 'review125', 'max_outer_commands': 4,
        'max_conservatively_charged_compiler_sessions': 6, 'max_seconds_each_outer': 90,
        'deadline_epoch_ns': DEADLINE, 'scratch_limit_bytes': LIMIT, 'strict_free_floor_bytes': FLOOR,
        'builds_allowed': False, 'native_application_allowed': False, 'subdelegation': False,
        'all18': 'OPEN', 'native_credit': 0, 'resource_credit': 0, 'trust_credit': 0, 'proof_credit': 0,
        'worker116': 'interrupted 2026-11-08T17:02:52.937Z; no final handoff; old20 not reset',
    })
    authenticate('ENTRY')


def run(name):
    assert name in CASES
    assert (ROOT / 'ENTRY-AUTHENTICATION.json').is_file()
    prior = list((ROOT / 'records').glob('*/launch.json'))
    charged = sum(json.loads(path.read_text())['conservative_sessions'] for path in prior)
    assert charged + CASES[name] <= 6
    before = guard()
    assert time.time_ns() + 95 * 10**9 < DEADLINE
    plan_path = AUTHOR / 'plans' / (name + '.json')
    original = json.loads(plan_path.read_text())
    plan = dict(original)
    work = ROOT / 'cases' / name
    work.mkdir(parents=True)
    temporary = ROOT / 'tmp' / name
    temporary.mkdir(parents=True)
    report = ROOT / 'reports' / (name + '.json')
    report.parent.mkdir(exist_ok=True)
    argv = [str(report) if value in original['outputs'] else value for value in original['argv']]
    env = dict(original['environment'])
    env['TMPDIR'] = str(temporary)
    for key in ['CARGO_TARGET_DIR', 'CARGO_BUILD_BUILD_DIR']:
        env[key] = str(ROOT / 'unused-no-build-target')
    plan.update(argv=argv, cwd=str(work), environment=env, outputs=[str(report)], timeout_seconds=90)
    output_before = observe(report)
    assert not output_before['exists']
    binding = json.loads((AUTHOR / 'BUILD-BINDING.json').read_text())
    input_paths = set(original['inputs'])
    input_paths.update(record['path'] for record in binding['binaries'])
    input_paths.update(binding[key]['path'] for key in ['helper', 'observer', 'libc'])
    input_paths.update(str(path) for path in (AUTHOR / 'stage').rglob('*') if path.is_file())
    directory = ROOT / 'records' / name
    directory.mkdir(parents=True)
    launch = {'registration_epoch_ns': time.time_ns(), 'name': name, 'plan': plan,
              'author_plan': identity(plan_path), 'collector_source': identity(__file__),
              'inputs': [identity(path) for path in sorted(input_paths)],
              'outputs_before': [output_before], 'resource_before': before,
              'conservative_sessions': CASES[name], 'outer_command': len(prior) + 1,
              'inherited_environment': False, 'compiler_plan_is_diagnostic_only': True}
    previous_report = json.loads((AUTHOR / 'reports' / (name + '.json')).read_text())
    launch['expected_inner_compiler_argv'] = [item['compiler_argv'] for item in previous_report['runs']] if name == 'helper-controls' else [previous_report['compiler_argv']]
    launch['expected_inner_argv_basis'] = 'authenticated prior report cross-checked against unchanged executable source; fresh actual argv checked after launch'
    save(directory / 'launch.json', launch)
    reason = None
    process = None
    samples = [before]
    begin = time.time_ns()
    monotonic_begin = time.monotonic()
    with (directory / 'stdout').open('xb') as stdout, (directory / 'stderr').open('xb') as stderr:
        try:
            process = subprocess.Popen(argv, cwd=work, env=env, stdout=stdout, stderr=stderr, start_new_session=True)
            while True:
                status = process.poll()
                if status is not None:
                    break
                if time.monotonic() - monotonic_begin > 90:
                    raise TimeoutError('outer command exceeded 90 seconds')
                samples.append(guard())
                time.sleep(0.1)
        except BaseException as error:
            reason = repr(error)
        finally:
            if process is not None:
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                process.wait(timeout=5)
    end = time.time_ns()
    resources = guard()
    save(directory / 'receipt.json', {
        'begin_epoch_ns': begin, 'end_epoch_ns': end, 'elapsed_seconds': time.monotonic() - monotonic_begin,
        'pid': process.pid if process is not None else None, 'returncode': process.returncode if process is not None else None,
        'termination_reason': reason, 'owned_process_group_reaped': process is not None,
        'outputs_after': [observe(report)], 'resource_after': resources, 'resource_samples': samples,
        'raw_streams': [identity(directory / 'stdout'), identity(directory / 'stderr')],
        'conservative_sessions': CASES[name], 'proof_acceptance': False,
    })
    print(name, 'exit', process.returncode if process else None, 'charged sessions', CASES[name], flush=True)
    assert reason is None, reason


def seal():
    authenticate('EXIT')
    launches = [json.loads(path.read_text()) for path in (ROOT / 'records').glob('*/launch.json')]
    receipts = [json.loads(path.read_text()) for path in (ROOT / 'records').glob('*/receipt.json')]
    assert len(launches) == len(receipts)
    resources = guard()
    save('ACCOUNTING.json', {'outer_commands': len(launches), 'conservatively_charged_compiler_sessions': sum(item['conservative_sessions'] for item in launches),
         'helper_controls_inner_sessions': 3, 'builds': 0, 'native_application_runs': 0,
         'resource_samples': resources, 'deadline_epoch_ns': DEADLINE,
         'sampled_max_scratch_bytes': max([resources['scratch_bytes']] + [sample['scratch_bytes'] for receipt in receipts for sample in receipt['resource_samples']]),
         'sampled_min_free_bytes': min([resources['free_bytes']] + [sample['free_bytes'] for receipt in receipts for sample in receipt['resource_samples']]),
         'all18': 'OPEN', 'native_credit': 0, 'resource_credit': 0, 'trust_credit': 0, 'proof_credit': 0})
    save('COMPILER-SLOT-RELEASED.json', {'epoch_ns': time.time_ns(), 'explicitly_released': True,
         'no_followup_chain': True, 'all_owned_process_groups_reaped': all(item['owned_process_group_reaped'] for item in receipts),
         'worker116_unchanged': 'interrupted 2026-11-08T17:02:52.937Z, no final handoff; old20 not reset'})
    records = [identity(path) for path in sorted(ROOT.rglob('*')) if path.is_file()]
    save('SEALED-MANIFEST.json', {'epoch_ns': time.time_ns(), 'records': records, 'excludes_itself_only': True,
         'all18': 'OPEN', 'proof_acceptance': False, 'no_adoption': True, 'compiler_slot': 'RELEASED'})
    print('SEALED', identity(ROOT / 'SEALED-MANIFEST.json'), 'resources', guard(), flush=True)


if __name__ == '__main__':
    if sys.argv[1] == 'entry':
        initialize()
    elif sys.argv[1] == 'run':
        run(sys.argv[2])
    elif sys.argv[1] == 'seal':
        seal()
