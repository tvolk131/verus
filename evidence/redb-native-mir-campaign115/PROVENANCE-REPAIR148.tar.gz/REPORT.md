# Parent repair148: source-only response to review146

November 8, 2026. This is a small parent-authored, baseline143-relative repair,
not a reset of143's exhausted36/36 allowance or a new native proof attempt.
The sole compiler slot remains assigned to distinct implementation147.

## Scope and execution

Only two authenticated143 source files are staged here. Baseline143 and original
redb remain unchanged. No compiler/build/test/verifier/native application ran.
Eight targeted Rust unit tests are authored but UNEXECUTED; typechecking,
ordinary-source behavior, fault controls and independent closure are unestablished.
The patch is unapplied to parent production/native sources and to live147.

## R146-1: reference holders are not outstanding loans

The pending ledger now separates current reference-holder Places from immutable
loan identities. Exact moves transfer the live holder edge; destination writes,
consumed operands and storage reuse invalidate overlapping holder edges without
deleting outstanding loan obligations. Unknown statement effects clear holder
edges as well as pending value/slot maps, retaining an Unsupported requirement.

Each newly reserved borrow resolves and freezes its pending receiver root/chain
before overwriting its destination. Later root lookup follows only a live holder
edge and its frozen chain, rejecting missing/expired/cyclic ancestor identities.
It no longer reinterprets a historical loan.returned Place as the current value
at that Place. Calls select receiver loans through live holder edges. Actual NLL
end processing retires that loan's current holders, not an unrelated value that
subsequently occupies its original assignment Place. Endpoint facts still refer
to the original compiler loan, and unsupported moved chain validations may refuse.

This is syntactic pending provenance, NOT allocation/byte/alias authority. An
untracked incoming root still needs the original checked checkout capability;
no capability is issued here. Four unexecuted unit tests cover holder relocation,
overwrite after move, storage kill and self-move while preserving loan identity.
They do not exercise real MIR/NLL/native semantics or prove frame preservation.

## R146-2: injective binding and exactly-once bundle placement

The binding gate now rejects duplicate MIR locations, HIR origins or retained-VIR
Arc identities across all successfully bound occurrences within the owner. The
gate runs after binding and again before proof placement. This subset rejects
many-to-one lowering; it does not implement path-aware occurrence duplication.

Required before/after bundles must have an anchor. Every nonempty bundle is
marked consumed during actual expression rewriting and must be consumed exactly
once; the final set must equal the required set. Missing anchors now fail closed
rather than merely appending an OPEN message. Four unexecuted pure-key tests
cover unique keys and each duplicate dimension. They do not construct or verify
actual original VIR bodies. Global identity/coverage controls remain unexecuted.

## Evidence and disposition

Review146's sealed fourteen payloads were authenticated before substantive parent
report inspection. Earlier parent143 source/report reads precede current hashes;
historical custody is not retrofitted. The parent selected and authenticated both
baseline source files against143's pinned candidate-final manifest before staging.
The sealer retains endpoint hashes, exact baseline-relative patch and failures.
Terminal display truncations in parent discovery/inspection are disclosed; the
complete immutable review report is retained separately. No build allowance was
consumed and no historical failure or allowance was erased.

Both R146 findings remain independently UNVALIDATED after this source repair.
Baseline143 remains RETAIN UNADOPTED; candidate141 remains REJECTED/NOT ADOPTED.
Original native bodies proved0, laws adopted0, all18 OPEN. The actual checkout,
byte/loan/writeback semantics, original write Assert/for, full WF/modes/SST/AIR,
cleanup, cache/backend/history/recovery and provenance gates remain unchanged.
