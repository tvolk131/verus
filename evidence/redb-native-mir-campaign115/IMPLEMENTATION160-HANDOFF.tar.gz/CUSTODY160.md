# Custody160 and limits

The supplied158 HANDOFF158.json and HANDOFF158.tar.gz pins were independently
hashed at entry. All66 unique regular archive members were read and compared
byte-for-byte to current158 endpoints. No158 file or target was modified. Its
LAW158.md, BRIDGE158.md and source-relative158.patch were read; source selection
was reused only as compiler input, not resource authority.

The final source patch is relative to the authenticated158 candidate, NOT a Git
checkout or clean upstream revision. `baseline160.json` inventories that source
copy; final source inventories and the patch identify exact additions/edits.
The parent ABI correction is a separate immutable input, not a modification to158.
No live159 artifact was read before the parent's later explicit sealed159 steering.
Only the parent disposition/repair inputs were then used; no new review was run.

Compiler subprocesses receive the explicitly constructed nonsecret environment in
environment.json and each launch. No credential-valued inherited environment is
captured. The source snapshot environment label identifies the initial baseline
inventory, NOT current source or Git/bootstrap authenticity. Final source identity
is separately recorded by actual launch entry/exit inventories.

Selected tool binaries, library sources/sysroot libraries, libc and original
source endpoints are separately hashed. Added endpoint observations at sealing
are labelled exit-only: they are not fabricated entry observations, observations
of a never-spawned18 child, or proof of which transitive libraries were loaded.
Endpoint equality is not continuous custody, upstream signature, bootstrap proof,
source-to-binary theorem, final allocator/deallocator pairing or runtime attestation.
The final source archive deliberately excludes build targets and tool caches.
The existing compiler and early test executable endpoints are hashed, not claimed
to have reproducible/attested bootstrap provenance.

AGENTS: no AGENTS.md in cwd/ancestors, source/evidence descendants or the inherited
scratch candidate. Original redb/AGENTS.md was read. Its tree stays read-only; its
application test requirement does not authorize running original redb or apply to
this separate compiler scratch. No original application is executed.

The metadata-only seal records19 as the total charge, checks all owned launched
groups are absent and all launched children have retained reaped exit receipts,
archives regular unique files, and reads every member back against source bytes.
It retains the failed free-disk criterion regardless of its final sample. No
destructive cleanup, new build or issuer activation occurs during sealing.
