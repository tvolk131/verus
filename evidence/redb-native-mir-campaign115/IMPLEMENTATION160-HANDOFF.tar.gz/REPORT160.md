# Implementation160 outcome: compiled partial component, resource-gated validation

Start: 2026-11-09 00:01:25 UTC. Deadline: 00:41:25 UTC, including seal.
Fresh scratch and fresh target; no158 target or remaining15 commands reused.
One heavy command at a time, jobs1, --offline --locked, no solver or original
application execution, network, Git writes, parent integration or cleanup.

## Validation actually performed

- Launch13:20 early conditional structural/WF tests passed,0 failed. These test
  neither native semantics nor SMT admission. Their exact source entry was not
  inventoried before later edits; raw commands/streams/receipt and parent patch
  chronology are retained. They do NOT validate the final revised tests/source.
- Launch14: compiler build failed: same_operand160 required a shared named rustc
  lifetime. Retained. Source edits during this early build were not separately
  inventoried; no exact final-source compilation claim is based on14.
- Launch15: disabled compiler build succeeded, before159 ABI steering was applied.
- Launch16: ABI159 build failed: FieldDef::ty returns Unnormalized<Ty>, requiring
  `.skip_norm_wip()` for the selected pinned API. Retained, not hidden.
- Launch17: final disabled compiler build succeeded in3.07s; its entry/exit source
  inventories agree. The sealer compares current source bytes to that exit
  inventory. This compiles the real typed component/adapter but does not execute
  its original-MIR selector or validate cfg(test) code.
- Launch18: original compiler-analysis attempt REFUSED BEFORE SPAWN. Free disk was
  15,305,211,904 bytes at preflight and15,304,888,320 at final sample, below the
  required strict16GiB floor (17,179,869,184 bytes). No compiler child, rmeta,
  checks/*.pending.json, original-path negative test or native analysis output
  exists from this attempt. This is a160 RESOURCE FAILURE, not a proof failure,
  ABI observation, native event test or permission to reset the budget.

No further builds/tests are attempted after18. Updated source tests, default-off
driver controls, the watchdog self-test fixture and the original matching controls
are retained as UNRUN. In particular, zero-size/numeric-alignment/native wrong
normal-edge/result/coverage controls are not advertised as observed final tests.
No SMT queries, SAT counterexamples, unknown responses or theorem results exist.

## Resource accounting

Fresh scratch limit:5GiB logical AND allocated. Initial footprint estimate3.5GB
with about1.8GB margin. A fresh target with debug=0 in dev/test, incremental=0,
jobs1 was chosen instead of copying158's debug-heavy target. Source compilation
fit comfortably below5GiB. Launch18 failed the independent GLOBAL free-disk
condition. That failure remains even if a later endpoint has more free space.

The watchdog samples without throwing away a threshold-crossing observation.
It kills only its own still-unreaped process group, waits/reaps, writes a basic
failure/child-exit receipt BEFORE final resource checks, then writes final data.
Launch18 demonstrates the no-child preflight failure receipt; it does not test
the live-child threshold-kill branch. The separate lowered-limit watchdog fixture
is UNRUN. Selected source/endpoint snapshots are retained from15 onward. The
first two launches lack equivalent source endpoint inventories; no retroactive
observations are invented.

Numbering reserves12 conservative preflight/setup charges, including the initial
Python hashlib.file_digest setup failure. Six runner launches13..18 yield18/32
charged through the failure. Source-only documentation/custody/seal is charged19.
Unnumbered source inspections/patch commands are retained in the parent transcript,
not fabricated as additional launched build/test receipts. The <=32 bound applies
to charged build/diagnostic/test activity, not an invented count of shell tokens.

## Law and acceptance status after parent159 steering

Read ALLOCATOR-LAW-DISPOSITION159.md and ABI-REPAIR159.md. Authenticated the staged
repair and its retained patch pins. Exact immutable LAW158.md hash:
0e95e3c2a8182c12573c57d71d4b93162a1162de343580ff896b45f5bdf8443f.

Current conditionally adopted mathematical schemas1 (parent159), new160 schemas0,
operative laws installed0, actual issuance0, accepted original allocations0,
stores0, bodies0, solver runs0. Issuance gate PENDING_REVIEW of producer and all
actual runtime/ABI/event/pointer/ownership gates; native export REFUSED; all18 OPEN.
This is not complete REAL original resource-continuation semantics or G1/G2 closure.

Preserved historical endpoints:116 INTERRUPTED;14024/24;14336/36;15636/36;
15817/32 SEALED FAILED STRICT2GiB, allocated2,174,758,912 before its seal metadata.
No historical target, input, handoff, failure or exhausted allowance was mutated.
Independent exact-code producer review remains required before any original use.
