# Disabled native continuation component160

This is a NEW160 scratch implementation, not a158 restart. Its useful result is
a compiled typed compiler component. It is NOT the requested complete genuine
original-event resource continuation. G1/G2 are still OPEN. No resource has been
issued, and no original Rust body was analyzed by the160 binary: launch18 failed
the free-disk preflight before spawning it.

## Exact code boundary

`source/rust_verify/src/native_continuation160.rs` accepts the compiler-owned
selected `Instance`, exact MIR call block, actual two operands, full raw-pointer
result place and normal successor. `check_selected160` checks them against the
original typed body, not against JSON or address equality. All statements AND
terminators, including cleanup blocks, have unique typed `Location` entries.
The MIR visitor retains moves and mutating places at every occurrence, including
StorageLive/StorageDead. Missing or duplicate occurrence coverage refuses.

`source/vir/src/native_resource/continuation160.rs` adds a disabled native-return
opcode with actual VIR values and Proof-mode nominal `vstd::raw_ptr::PointsToRaw`
and `vstd::raw_ptr::Dealloc` OUTPUT binders. These are not descriptor integers or
incoming source-argument permissions. The native call is not replaced by vstd
allocate. No new allocator call, executable wrapper or allocator contract is
generated. The160 bin deliberately excludes the inherited154/156 replacement
program generators from its included source.

Those OUTPUT BINDERS ARE NOT INITIALIZED RESOURCE VALUES. Merely naming genuine
vstd nominal types does not establish native authority. The original rustc-only
analysis has no verifier-loaded vstd Krate, so type-definition resolution remains
OPEN. `ResourceTypes160::unresolved_native_ports` makes that incompleteness explicit;
the corresponding edge refuses SST admission with MissingVstdTypes. Even resolved
fixture types still refuse with PendingReview. There is no source-callable issuer.

The symbolic binder requests a fresh invocation within the enclosing native
activation on EACH dynamic traversal, not a static event number or heap counter.
It has NO native interpreter. `NativeSemanticWitness160` is uninhabited; no Rust
metadata object, serialization record, pointer equality or private move can
construct semantic authority. The conditional flow check uses static labels only
to check opcode wiring; it is NOT a native activation/heap ownership proof.

The checked-prefix component emits an ordinary VIR ASSERTION of positive actual
size, never an assumption. It does not remove any OPEN applicability obligation.
No assertions were sent to a solver in160. Real layout/non-null/spec-pointer/
dynamic-event/current-resource/runtime/header/metadata/iterator/index/prior-value/
cache/caller/frame/normal-cleanup proofs remain missing.

The conditional affine WF component checks witness replay, duplicate occurrence,
duplicate tracked binders, resource replay/clone/import, live destinations, root
and loan invalidation on full-place transfers/destruction, terminal obligations,
path joins and loop re-binding shape. Native global ownership correspondence is
NOT established by this host structural analysis. In particular the complete MIR
move/destruction inventory is not yet interpreted as genuine native capability
flow; a retained typed occurrence is not a proof of its resource effect.

## ABI159 consumed, not silently weakened

The selected raw allocator ABI is `(usize, core::mem::Alignment) -> *mut u8`.
`selection160.rs` implements the parent correction using the actual Layout
lang-item align-field type and the nominal core Alignment type. This pinned
rustc API additionally requires `.skip_norm_wip()` on FieldDef::ty; the uncompiled
parent patch alone did not typecheck. Failed build16 retains that diagnostic.

`alignment_as_usize160` resolves the actual inherent `Alignment::as_usize` Instance,
checks its actual Alignment input and usize result, and retains that Instance
alongside the ORIGINAL typed alignment operand. VIR's `AlignmentAsUsize160`
explicitly binds its numeric result; it accepts no independent usize/8/repr cast.
This is a suspended typed computation, NOT an equation asserting its result.
Evaluation/body correspondence for this native method is still OPEN. The method
lookup code compiled, but did not run on original MIR because18 did not spawn.

## Exact missing link (blocking)

Implement and independently review the native execution-to-proof interpreter for
this opcode: logical allocator API activation/dynamic call event (not a guaranteed
one-physical-allocation-per-MIR-call), actual numeric as_usize result, native
normal-return pointer to FULL vstd specification pointer/provenance, and an atomic
consumption of that event witness binding exactly one initialized tracked raw/
Dealloc pair into that same normal continuation. Thread a genuine global affine
resource environment, including stale generations/roots/loans and every normal/
cleanup effect, through the existing MIR-to-VIR/SST pipeline. The present opcode
cannot be substituted for that semantic component.

The conditional mathematical schema does NOT supply that interpreter, valid
layout/positive branch, event existence, ownership pre-state or a frame theorem.
Current owned user-memory, callback/cache/ambient state and prior initialized
contents cannot be transported by an unreviewed blanket frame. All application
dependencies and all18 database obligations stay OPEN.

Feature `native-resource-continuation160` is absent by default. The standalone
scratch binary additionally requires `--lower-continuation160` before constructing
its opcode; its disabled flag returns before selected-node construction. This
fixes the construction-versus-serialization distinction noted in F159-2 for160,
without modifying historical158. There is no adoption flag or export success.
