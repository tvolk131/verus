#!/usr/bin/env python3
"""Seal the separate audit artifacts; never modify frozen inputs."""

from datetime import datetime, timezone
from pathlib import Path
import sys
import time

import audit


def main():
    output = Path(__file__).resolve().parent
    started = time.monotonic()
    task_started = datetime(2026, 11, 7, 23, 56, 46, tzinfo=timezone.utc)
    audit.require(output.parent == Path('/private/tmp'), 'not a separate scratch')
    results = audit.read_json(output / 'results.json')
    tests = audit.read_json(output / 'test-results.json')
    audit.require(results['status'] == tests['status'] == 'PASS', 'validation not passing')
    audit.require(tests['test_count'] == 23, 'unit inventory mismatch')
    commands = audit.read_json(output / 'commands.json')
    audit.require(commands['wrapper_exit_code'] == 0, 'wrapper failed')
    for command in commands['commands']:
        audit.require(command['exit_code'] == 0, 'recorded command failed')
        audit.require(audit.digest((output / command['raw_log']).read_bytes()) == command['raw_log_sha256'],
                      'validation log changed')
    report = (output / 'REPORT.md').read_bytes()
    audit.require(len(report) <= 12 * 1024, 'report exceeds 12 KiB')
    receipt = audit.authenticate(audit.INPUT, audit.REVIEW, audit.ARCHIVE, 'final-handoff')
    entry = audit.read_json(output / 'audit-authentication-entry.json')
    audit.require(entry['files'] == receipt['files'] and entry['external_inputs'] == receipt['external_inputs']
                  and entry['manifest'] == receipt['manifest'], 'frozen input changed since entry')
    audit.write_json(output / 'authentication-handoff-final.json', receipt)
    results.update(metadata_unit_tests={'classification': 'AUDIT/METADATA', 'status': 'PASS', 'test_count': 23,
                                      'results_file': 'test-results.json', 'raw_log': 'unit-tests.log'},
                   final_handoff_authentication='PASS')
    audit.write_json(output / 'results.json', results)
    finished = datetime.now(timezone.utc)
    task_seconds = (finished - task_started).total_seconds()
    audit.require(0 <= task_seconds <= 720, 'complete task exceeded 12 minutes')
    audit.write_json(output / 'handoff.json', {
        'classification': 'AUDIT/METADATA', 'status': 'PASS',
        'task_started_utc': task_started.isoformat(), 'final_handoff_utc': finished.isoformat(),
        'task_wall_seconds': task_seconds, 'wall_limit_seconds': 720,
        'resource_observation_before_manifest': audit.budget(output, started),
        'report': {'path': 'REPORT.md', 'bytes': len(report), 'sha256': audit.digest(report)},
        'input_manifest_sha256': audit.MANIFEST_SHA256,
        'output_manifest': 'output-manifest.json', 'output_manifest_excludes_only_itself': True,
        'command': [sys.executable, '-B', 'finalize.py'], 'exit_code': 0,
        'strict_persisted_warm_cache_gate': 'UNMET', 'redb_tasks_open': 18,
        'trust_admission': 'UNCHANGED', 'parent_retention_or_integration_authorized': False,
    })
    files = audit.regular_files(output)
    manifest = {name: {'bytes': path.stat().st_size, 'sha256': audit.digest(path.read_bytes())}
                for name, path in sorted(files.items()) if name != 'output-manifest.json'}
    audit.write_json(output / 'output-manifest.json', manifest)
    for name, expected in manifest.items():
        content = (output / name).read_bytes()
        audit.require({'bytes': len(content), 'sha256': audit.digest(content)} == expected, 'output seal mismatch')
    print('AUDIT/METADATA FINAL HANDOFF PASS')
    print('task_wall_seconds=' + str(task_seconds))
    print('report_bytes=' + str(len(report)))
    print('output_manifest_sha256=' + audit.digest((output / 'output-manifest.json').read_bytes()))
    print('resources=' + str(audit.budget(output, started)))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
