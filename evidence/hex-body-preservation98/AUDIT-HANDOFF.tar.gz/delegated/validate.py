#!/usr/bin/env python3
"""Run only the newly authored Python audit and AUDIT/METADATA unit tests."""

import json
from pathlib import Path
import re
import subprocess
import sys
import time

import audit


def main():
    output = Path(__file__).resolve().parent
    started = time.monotonic()
    limits_entry = audit.budget(output, started)
    commands = []
    for arguments, logfile in [([sys.executable, '-B', 'audit.py'], 'audit-run.log'),
                               ([sys.executable, '-B', '-m', 'unittest', '-v', 'test_audit'], 'unit-tests.log')]:
        command_started = time.monotonic()
        utc = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
        completed = subprocess.run(arguments, cwd=output, stdout=subprocess.PIPE,
                                   stderr=subprocess.STDOUT, timeout=120, check=False)
        (output / logfile).write_bytes(completed.stdout)
        commands.append({'argv': arguments, 'cwd': str(output), 'started_utc': utc,
                         'exit_code': completed.returncode,
                         'seconds': time.monotonic() - command_started,
                         'raw_log': logfile, 'raw_log_sha256': audit.digest(completed.stdout)})
        print(json.dumps(commands[-1], sort_keys=True))
    raw_units = (output / 'unit-tests.log').read_text()
    tests = [{'test': name, 'classification': 'AUDIT/METADATA', 'status': status}
             for name, status in re.findall(r'^(test_\S+) \(test_audit\.MetadataTests\) \.\.\. (ok|FAIL|ERROR)$',
                                           raw_units, re.MULTILINE)]
    summary = re.search(r'^Ran (\d+) tests in ', raw_units, re.MULTILINE)
    successful = (all(command['exit_code'] == 0 for command in commands) and summary is not None
                  and int(summary.group(1)) == len(tests) == 23 and all(test['status'] == 'ok' for test in tests))
    audit.write_json(output / 'commands.json', {
        'classification': 'AUDIT/METADATA', 'python_version': sys.version, 'commands': commands,
        'wrapper_command': [sys.executable, '-B', 'validate.py'],
        'wrapper_exit_code': 0 if successful else 1,
        'limits_entry': limits_entry, 'limits_exit': audit.budget(output, started),
    })
    audit.write_json(output / 'test-results.json', {
        'classification': 'AUDIT/METADATA', 'status': 'PASS' if successful else 'FAIL',
        'test_count': len(tests), 'tests': tests,
        'native_semantic_negative_tests': False, 'supplied_harnesses_executed_or_imported': False,
    })
    return 0 if successful else 1


if __name__ == '__main__':
    raise SystemExit(main())
