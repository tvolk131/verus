import datetime
import hashlib
import json
from pathlib import Path
import shutil
import tarfile


PARENT = Path('/Users/tommyvolk/.t3/worktrees/verus/t3-60978068')
DESTINATION = PARENT / 'evidence/redb-storage-composition110'
CONTROLLERS = Path('/private/tmp/redb-composition110-20261108T043326Z')
ROOTS = {
    'composition': Path('/private/tmp/redb-storage110-laneA-LBwsoPMW'),
    'backend': Path('/private/tmp/redb-backend110-B-cCGFf2VR'),
    'parent_controllers_and_controls': CONTROLLERS,
    'retained_evidence': DESTINATION,
}


def digest(filename):
    return hashlib.sha256(filename.read_bytes()).hexdigest()


def payload_records(root):
    manifest = json.loads((root / 'MANIFEST.json').read_text())
    return manifest['files'] if 'files' in manifest else manifest['records']


def authenticate_payloads(root):
    records = payload_records(root)
    assert len(records) == len({record['path'] for record in records})
    for record in records:
        relative = Path(record['path'])
        assert not relative.is_absolute() and '..' not in relative.parts
        filename = root / relative
        assert filename.is_file() and not filename.is_symlink(), str(filename)
        assert filename.stat().st_size == record['bytes'], str(filename)
        assert digest(filename) == record['sha256'], str(filename)
    return len(records)


def file_bytes(root):
    return sum(filename.stat().st_size for filename in root.rglob('*') if filename.is_file())


assert not (DESTINATION / 'ROUND-RESULTS.json').exists()
authorization = json.loads((DESTINATION / 'AUTHORIZATION.json').read_text())
assert digest(DESTINATION / 'PLAN.md') == authorization['plan']['sha256']
assert digest(DESTINATION / 'INPUTS.json') == authorization['inputs']['sha256']
review = json.loads((DESTINATION / 'INDEPENDENT-REVIEW-RESULTS.json').read_text())
assert review['review_completed'] and review['review_exit_mismatches'] == 0
assert review['charged_attempts'] <= 6 and review['verifier_launches'] <= review['charged_attempts']
assert review['acceptance'] is False and review['redb_open_cells'] == 18
ROOTS['review'] = Path(review['source'])
snapshots = review['historical_documents_before_reconciliation']
assert len(snapshots) == 2
selected = json.loads((DESTINATION / 'INPUTS.json').read_text())
unchanged = []
expected_updates = []
for record in selected['records']:
    filename = Path(record['path'])
    observed = digest(filename)
    if str(filename) in snapshots:
        snapshot = snapshots[str(filename)]
        assert digest(DESTINATION / snapshot['snapshot']) == record['sha256'] == snapshot['sha256']
        assert observed != record['sha256']
        expected_updates.append({
            'path': str(filename),
            'frozen_sha256': record['sha256'],
            'reconciled_sha256': observed,
            'snapshot': snapshot['snapshot'],
            'reason': 'Parent documentation reconciliation after all implementation and review exits',
        })
    else:
        assert observed == record['sha256'], str(filename)
        unchanged.append(str(filename))
assert len(expected_updates) == 2 and len(unchanged) == 836
payloads = {label: authenticate_payloads(ROOTS[label]) for label in ('composition', 'backend', 'review')}
assert payloads['composition'] == payloads['backend'] == 104
payloads['parent_controls'] = authenticate_payloads(CONTROLLERS / 'controls')
assert payloads['parent_controls'] == 32
for receipt_name, archive_name in [
    ('COMPOSITION-RETENTION.json', 'COMPOSITION-CANDIDATE-HANDOFF.tar.gz'),
    ('BACKEND-RETENTION.json', 'BACKEND-CANDIDATE-HANDOFF.tar.gz'),
    ('PARENT-CONTROLS-RESULTS.json', 'PARENT-CONTROLS-HANDOFF.tar.gz'),
    ('INDEPENDENT-REVIEW-RESULTS.json', 'INDEPENDENT-REVIEW-HANDOFF.tar.gz'),
]:
    receipt = json.loads((DESTINATION / receipt_name).read_text())
    assert digest(DESTINATION / archive_name) == receipt['archive_sha256']
status = json.loads((PARENT / 'evidence/redb-crash-consistency94/STATUS.json').read_text())
assert status['whole_goal_acceptance'] is False
assert status['pending_independent_review_tasks'] == []
assert len(status['completion_properties']) == 6 and len(status['required_histories']) == 3
assert status['native_storage_composition110'].startswith('COMPLETE_CONDITIONAL_')
controller_archive = DESTINATION / 'PARENT-CONTROLLERS.tar.gz'
assert not controller_archive.exists()
with tarfile.open(controller_archive, 'w:gz') as archive:
    for filename in sorted(CONTROLLERS.glob('*.py')):
        archive.add(filename, arcname=filename.name, recursive=False)
now = datetime.datetime.now(datetime.timezone.utc)
start = datetime.datetime.fromisoformat(authorization['round_start_utc'].replace('Z', '+00:00'))
deadline = datetime.datetime.fromisoformat(authorization['hard_deadline_utc'].replace('Z', '+00:00'))
assert now < deadline
sizes = {label: file_bytes(root) for label, root in ROOTS.items()}
free_bytes = shutil.disk_usage('/private/tmp').free
assert sum(sizes.values()) < authorization['scratch_cap_bytes']
assert free_bytes > authorization['global_free_floor_bytes']
result = {
    'schema': 'redb-storage-composition110-completed-round-v1',
    'status': 'BOUNDED_ROUND_COMPLETE_DATABASE_GOAL_OPEN',
    'start_utc': start.isoformat(),
    'completed_utc': now.isoformat(),
    'hard_deadline_utc': deadline.isoformat(),
    'elapsed_seconds': (now - start).total_seconds(),
    'within_original_round_deadline': True,
    'composition_verified_obligations': 61,
    'composition_proof_bodies': 52,
    'composition_new_authored_proof_bodies': 11,
    'backend_verified_obligations': 15,
    'backend_proof_bodies': 13,
    'checked_original_native_executable_bodies': 0,
    'composition_charged_attempts': 8,
    'backend_charged_attempts': 10,
    'review_charged_attempts': review['charged_attempts'],
    'review_verifier_launches': review['verifier_launches'],
    'parent_additional_verifier_applications': 0,
    'total_charged_attempts': 18 + review['charged_attempts'],
    'single_independent_review_completed': True,
    'review_verdict': review['verdict'],
    'parent_controls_tests': 13,
    'parent_finite_histories': 17476,
    'parent_finite_control_steps': 51264,
    'selected_inputs': {
        'frozen_count': len(selected['records']),
        'unchanged_after_reconciliation': len(unchanged),
        'unexpected_mismatches': 0,
        'expected_post_review_document_updates': expected_updates,
        'inherited_historical_drifts': selected['historical_round109_drifts'],
        'inherited_document_reconciliations': selected['documented_authorization_and_reconciliation_updates'],
    },
    'authenticated_payloads': payloads,
    'sampled_file_bytes_by_root': sizes,
    'sampled_total_file_bytes': sum(sizes.values()),
    'resource_sampling_limit': 'Selected boundaries only; not a hard OS quota or continuous peak measurement.',
    'sampled_free_disk_bytes': free_bytes,
    'native_adapter_R': 'OPEN',
    'native_atomic_state_and_backend_callback_history_bindings': 'OPEN',
    'compiler_source_correspondence': 'UNESTABLISHED',
    'original_native_path_preservation': 'FAILED',
    'native_git_continuity': 'UNAVAILABLE',
    'goal_service_status_last_observed': 'ACTIVE',
    'routine_continuation_requires_recurring_user_approval': False,
    'task_allowances_reset': False,
    'new_trusted_assumptions_adopted': 0,
    'compiler_runtime_vstd_cargo_builds': 0,
    'native_application_executions': 0,
    'parent_source_integration': False,
    'admission_or_export_gate_changes': False,
    'final_cells_closed': 0,
    'redb_open_cells': 18,
    'acceptance': False,
    'integration': False,
}
(DESTINATION / 'ROUND-RESULTS.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
inventory = []
for filename in sorted(DESTINATION.iterdir()):
    assert filename.is_file() and not filename.is_symlink()
    inventory.append({'path': filename.name, 'bytes': filename.stat().st_size, 'sha256': digest(filename)})
assert not (DESTINATION / 'ROUND-MANIFEST.json').exists()
(DESTINATION / 'ROUND-MANIFEST.json').write_text(json.dumps({
    'schema': 'redb-composition110-retained-round-files-v1',
    'excludes_self': True,
    'files': inventory,
    'content_authentication_not_acceptance': True,
}, indent=2, sort_keys=True) + '\n')
print(json.dumps({
    'completed_utc': result['completed_utc'],
    'elapsed_seconds': result['elapsed_seconds'],
    'round_payloads': len(inventory),
    'unexpected_input_mismatches': 0,
    'expected_post_review_document_updates': len(expected_updates),
    'sampled_total_file_bytes': result['sampled_total_file_bytes'],
    'sampled_free_disk_bytes': free_bytes,
    'final_cells_closed': 0,
    'redb_open_cells': 18,
}, indent=2))
