import datetime
import hashlib
import json
from pathlib import Path
import sys


ROOT = Path('/private/tmp/redb-composition110-20261108T043326Z')
PARENT = Path('/Users/tommyvolk/.t3/worktrees/verus/t3-60978068')
DESTINATION = PARENT / 'evidence/redb-storage-composition110'
NATIVE = Path('/private/tmp/verus-crash-consistency94-20261105/native-leaf-lookup-007/recovered-native/redb/src')
sys.path.insert(0, str(ROOT / 'controls'))
import backend_controls


TARGETS = {
    'write_barrier': {
        'path': NATIVE / 'tree_store/page_store/cached_file.rs',
        'sha256': 'cb901d44531b23f87d1bd31f72a24f1dc69308b5417db2167b7508921ffda486',
        'marker': 'pub(super) fn write_barrier(&self)',
        'expected': 'if self.write_buffer_bytes.load(Ordering::Acquire) > 0 { self.committed_pages_buffered.store(true, Ordering::Release); }',
    },
    'non_durable_commit': {
        'path': NATIVE / 'tree_store/page_store/page_manager.rs',
        'sha256': 'b062608a527c3f53aa505af870f2b803da3fa7b095169194c681cc6441cb558a',
        'marker': 'pub(crate) fn non_durable_commit(',
        'expected': '''self.debug_assert_no_dirty_pages(); self.storage.check_io_errors()?;
            self.unpersisted.lock().unwrap().extend(newly_unpersisted);
            self.storage.write_barrier(); let mut state = self.state.lock().unwrap();
            state.header.write_secondary_slot(transaction_id, data_root, system_root);
            state.read_from_secondary = true; Ok(())''',
    },
}


def main():
    selected = json.loads((DESTINATION / 'INPUTS.json').read_text())['records']
    for record in selected:
        assert hashlib.sha256(Path(record['path']).read_bytes()).hexdigest() == record['sha256'], record['path']
    observations = []
    for name, target in TARGETS.items():
        content = target['path'].read_bytes()
        assert hashlib.sha256(content).hexdigest() == target['sha256']
        source = content.decode()
        body, start, end = backend_controls.fragment(source, target['marker'])
        assert backend_controls.tokens(body) == backend_controls.tokens(target['expected']), name
        observations.append({'target': name, 'path': str(target['path']), 'sha256': target['sha256'],
                             'start_line': source.count('\n', 0, start) + 1,
                             'end_line': source.count('\n', 0, end) + 1, 'body': body,
                             'selected_body_tokens_match': True})
    result = {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'selected_inputs_match': len(selected), 'observations': observations,
              'qualification': 'Exact selected-body lexical observation only; not Rust resolution, callee effect closure, atomic semantics or native proof',
              'all18': 'OPEN', 'native_proof_credit': 0}
    (DESTINATION / 'POST-PUBLICATION-SOURCE-OBSERVATIONS.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'selected_inputs_match': len(selected), 'selected_body_observations': len(observations), 'all18': 'OPEN'}, indent=2))


if __name__ == '__main__':
    main()
