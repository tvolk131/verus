import datetime
import hashlib
import json
from pathlib import Path
import shutil


PARENT = Path('/Users/tommyvolk/.t3/worktrees/verus/t3-60978068')
DESTINATION = PARENT / 'evidence/redb-storage-composition110'
PREVIOUS = PARENT / 'evidence/redb-storage-refinement109'


def identity(filename):
    content = filename.read_bytes()
    return {'path': str(filename), 'bytes': len(content), 'sha256': hashlib.sha256(content).hexdigest()}


records = {}
prior = json.loads((PREVIOUS / 'INPUTS.json').read_text())
round_results = json.loads((PREVIOUS / 'ROUND-RESULTS.json').read_text())
allowed_previous_updates = {record['path']: record['reconciled_sha256'] for record in round_results['selected_inputs']['expected_post_review_document_updates']}
new_document_updates = []
for record in prior['records']:
    filename = Path(record['path'])
    current = identity(filename)
    current['round109_frozen_sha256'] = record['sha256']
    if str(filename) in allowed_previous_updates:
        new_document_updates.append({'path': str(filename), 'round109_frozen_sha256': record['sha256'], 'round109_final_sha256': allowed_previous_updates[str(filename)], 'round110_current_sha256': current['sha256'], 'reason': 'Documented round109 reconciliation followed by fresh round110 authorization entry'})
    else:
        assert current['sha256'] == record['sha256'], str(filename)
    records[str(filename)] = current
for record in json.loads((PREVIOUS / 'ROUND-MANIFEST.json').read_text())['files']:
    filename = PREVIOUS / record['path']
    current = identity(filename)
    assert current['sha256'] == record['sha256']
    records[str(filename)] = current
roots = [
    Path('/private/tmp/redb-storage109-lane1-20261108T034224Z'),
    Path('/private/tmp/redb-storage109-lane2-wqh8Ege8'),
    Path('/private/tmp/redb-storage109-independent-controls-vKPHDj8s'),
    Path('/private/tmp/redb-storage109-review-QFf6FvBP'),
]
for root in roots:
    manifest = json.loads((root / 'MANIFEST.json').read_text())
    entries = manifest if isinstance(manifest, list) else manifest['files']
    for record in entries:
        filename = root / record['path']
        current = identity(filename)
        assert current['sha256'] == record['sha256'], str(filename)
        records[str(filename)] = current
    for filename in root.iterdir():
        if filename.name in {'MANIFEST.json', 'HANDOFF.json', 'SEAL.json', 'SEAL.sha256'}:
            records[str(filename)] = identity(filename)
for filename in [DESTINATION / 'PLAN.md', Path(__file__), PREVIOUS / 'ROUND-MANIFEST.json']:
    records[str(filename)] = identity(filename)
captured = datetime.datetime.now(datetime.timezone.utc).isoformat()
manifest = {
    'schema': 'redb-composition110-frozen-selected-inputs-v1',
    'captured_utc': captured,
    'first_read_or_atomic_snapshot_claim': False,
    'historical_round109_drifts': prior['historical_drift'],
    'documented_authorization_and_reconciliation_updates': new_document_updates,
    'compiler_source_correspondence': 'UNESTABLISHED',
    'original_native_path_preservation': 'FAILED',
    'native_git_continuity': 'UNAVAILABLE',
    'records': [records[name] for name in sorted(records)],
}
(DESTINATION / 'INPUTS.json').write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
authorization = {
    'user_approval': 'Approved',
    'scope': 'FRESH_60MIN_4GIB_SCRATCH_ONLY_PARALLEL_COMPOSITION_AND_SOURCE_CONNECTED_BACKEND_CALLBACK_PROOF_ATTEMPTS_ONE_COMBINED_REVIEW',
    'round_start_utc': '2026-11-08T04:33:26Z',
    'optional_work_stop_utc': '2026-11-08T05:21:26Z',
    'hard_deadline_utc': '2026-11-08T05:33:26Z',
    'scratch_cap_bytes': 4 * 1024 ** 3,
    'global_free_floor_bytes': 16 * 1024 ** 3,
    'global_free_bytes_at_freeze': shutil.disk_usage('/private/tmp').free,
    'plan': identity(DESTINATION / 'PLAN.md'),
    'inputs': identity(DESTINATION / 'INPUTS.json'),
    'compiler_runtime_builds_authorized': False,
    'new_trust_adoption_authorized': False,
    'integration_authorized': False,
    'excluded_work_authorized': False,
    'diagnostic107_D1_authorized': False,
    'all18': 'OPEN',
}
assert authorization['global_free_bytes_at_freeze'] > authorization['global_free_floor_bytes']
(DESTINATION / 'AUTHORIZATION.json').write_text(json.dumps(authorization, indent=2, sort_keys=True) + '\n')
print(json.dumps({'captured_utc': captured, 'selected_records': len(records), 'historical_round109_drifts': len(prior['historical_drift']), 'documented_live_document_updates': len(new_document_updates), 'plan_sha256': authorization['plan']['sha256'], 'inputs_sha256': authorization['inputs']['sha256'], 'free_bytes': authorization['global_free_bytes_at_freeze']}, indent=2))
