import datetime
import hashlib
import json
from pathlib import Path
import shutil
import tarfile


ROOT = Path('/private/tmp/redb-review110-LwF1feEi')
PARENT = Path('/Users/tommyvolk/.t3/worktrees/verus/t3-60978068')
DESTINATION = PARENT / 'evidence/redb-storage-composition110'


def digest(filename):
    return hashlib.sha256(filename.read_bytes()).hexdigest()


assert digest(ROOT / 'HANDOFF.json') == '356761383fe88ec1dc5019abcacb800e88799bfb59d79a0b4ac0597df8d86fa1'
handoff = json.loads((ROOT / 'HANDOFF.json').read_text())
assert digest(ROOT / 'handoff.tar.gz') == handoff['archive']['sha256'] == '2512cbd9a31dc0b783a9c1e685f788d556a90ac35a014f2c0dfdf5fd28c9f2cd'
assert digest(ROOT / 'MANIFEST.json') == handoff['manifest']['sha256']
assert digest(ROOT / 'SEAL.json') == handoff['seal']['sha256']
seal = json.loads((ROOT / 'SEAL.json').read_text())
assert digest(ROOT / 'REPORT.md') == handoff['report']['sha256'] == seal['report_sha256']
records = json.loads((ROOT / 'MANIFEST.json').read_text())['files']
assert len(records) == len({record['path'] for record in records}) == 207
for record in records:
    relative = Path(record['path'])
    assert not relative.is_absolute() and '..' not in relative.parts
    filename = ROOT / relative
    assert filename.is_file() and not filename.is_symlink()
    assert filename.stat().st_size == record['bytes']
    assert digest(filename) == record['sha256'], str(filename)
expected_members = {record['path'] for record in records} | {'MANIFEST.json', 'SEAL.json'}
with tarfile.open(ROOT / 'handoff.tar.gz', 'r:gz') as archive:
    members = archive.getmembers()
    assert len(members) == len(expected_members) == 209
    assert {member.name for member in members} == expected_members
    for member in members:
        assert member.isfile() and not Path(member.name).is_absolute()
        assert '..' not in Path(member.name).parts
        assert archive.extractfile(member).read() == (ROOT / member.name).read_bytes()
frozen = json.loads((DESTINATION / 'INPUTS.json').read_text())['records']
assert len(frozen) == 838
for record in frozen:
    assert digest(Path(record['path'])) == record['sha256'], record['path']
exit_authentication = json.loads((ROOT / 'authentication-final-exit.json').read_text())
assert exit_authentication['mismatches'] == exit_authentication['supplemental_drift'] == []
assert len(exit_authentication['records']) == 838
results = json.loads((ROOT / 'RESULTS.json').read_text())
checks = []
for check in results['checks']:
    number = check['result']['number']
    expected_success = number in {1, 3, 4, 6}
    process = check['result']
    assert process['launch_error'] is None and not process['timed_out']
    assert process['export_present'] == expected_success
    assert process['status'] == (0 if expected_success else 1)
    assert check['verification']['success'] == expected_success
    if expected_success:
        assert check['verification']['verified'] == (61 if number <= 3 else 15)
        assert check['verification']['errors'] == 0
        assert digest(Path(process['exact_export'])) == process['export']['sha256']
    else:
        assert check['verification']['errors'] > 0
        assert not Path(process['exact_export']).exists()
    checks.append({'number': number, 'label': process['label'], 'status': process['status'],
                   'export_present': process['export_present'], 'verification': check['verification'],
                   'source_sha256': check['invocation']['source']['sha256']})
assert len(checks) == 6
assert all(results['restoration_byte_identity'].values())
for source, destination in {
    'REPORT.md': 'INDEPENDENT-REVIEW.md',
    'handoff.tar.gz': 'INDEPENDENT-REVIEW-HANDOFF.tar.gz',
    'HANDOFF.json': 'INDEPENDENT-REVIEW-METADATA.json',
    'ACCOUNTING.json': 'INDEPENDENT-REVIEW-ACCOUNTING.json',
    'RESULTS.json': 'INDEPENDENT-REVIEW-RAW-RESULTS.json',
}.items():
    filename = DESTINATION / destination
    assert not filename.exists()
    shutil.copyfile(ROOT / source, filename)
    assert digest(filename) == digest(ROOT / source)
snapshots = {}
for name, destination in {'GOAL.md': 'HISTORICAL-GOAL.md', 'STATUS.json': 'HISTORICAL-STATUS.json'}.items():
    source = PARENT / 'evidence/redb-crash-consistency94' / name
    target = DESTINATION / destination
    assert not target.exists()
    shutil.copyfile(source, target)
    assert digest(source) == digest(target)
    snapshots[str(source)] = {'snapshot': destination, 'sha256': digest(source)}
result = {
    'schema': 'redb-composition110-combined-review-retention-v1',
    'retained_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'review_completed': True,
    'source': str(ROOT),
    'verdict': 'NO_NEW_BOUNDED_MODEL_DEFECT_IDENTIFIED_NATIVE_LINKAGE_INTEGRATION_NOT_READY',
    'authenticated_payloads': len(records),
    'archive_members_byte_compared': len(members),
    'archive_sha256': handoff['archive']['sha256'],
    'manifest_sha256': handoff['manifest']['sha256'],
    'report_sha256': seal['report_sha256'],
    'review_exit_authenticated_paths': len(exit_authentication['records']),
    'review_exit_supplemental_paths': len(exit_authentication['supplemental']),
    'review_exit_mismatches': 0,
    'current_frozen_input_matches_before_parent_reconciliation': len(frozen),
    'historical_documents_before_reconciliation': snapshots,
    'charged_attempts': 6,
    'verifier_launches': 6,
    'checks': checks,
    'controls_tests_replayed': 13,
    'finite_histories_reproduced': 17476,
    'native_executable_bodies_checked': 0,
    'atomic_frontier_independently_inspected': True,
    'header_artifact_preflight_independently_reviewed': False,
    'bootstrap_provenance': 'QUALIFIED_NO_EXHAUSTIVE_OR_ATOMIC_FIRST_USE_CLAIM',
    'native_adapter_R': 'OPEN',
    'acceptance': False,
    'integration': False,
    'trust_adoption': False,
    'redb_open_cells': 18,
}
destination = DESTINATION / 'INDEPENDENT-REVIEW-RESULTS.json'
assert not destination.exists()
destination.write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
print(json.dumps({key: result[key] for key in ('verdict', 'authenticated_payloads', 'archive_members_byte_compared', 'review_exit_authenticated_paths', 'review_exit_supplemental_paths', 'current_frozen_input_matches_before_parent_reconciliation', 'archive_sha256')}, indent=2))
