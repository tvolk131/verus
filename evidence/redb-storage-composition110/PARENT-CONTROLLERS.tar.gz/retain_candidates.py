import datetime
import hashlib
import json
from pathlib import Path
import shutil
import tarfile


DESTINATION = Path('/Users/tommyvolk/.t3/worktrees/verus/t3-60978068/evidence/redb-storage-composition110')
LANES = {
    'COMPOSITION': {
        'root': '/private/tmp/redb-storage110-laneA-LBwsoPMW',
        'manifest_sha256': 'd6e67e8e6d17d6b2bc90de1997c3c3cc022de226e81a700b812ab17c556e005b',
        'seal_sha256': None,
        'report_sha256': '51f873f24795fefe0dd2c6e6a6e22b9b65a95b87b68e71c19d63c97a507423a0',
        'source': 'composition110.rs',
        'source_sha256': '00289ba9a9189b9b24491ef68ae84fa74e75a04d1c19277db4e6bafa26456f5e',
        'copies': ['REPORT.md', 'HANDOFF.json', 'CUT-LEDGER.json', 'ACCOUNTING.json', 'composition110-additive.patch'],
        'charges': 8,
        'verified': 61,
        'proof_bodies': 52,
    },
    'BACKEND': {
        'root': '/private/tmp/redb-backend110-B-cCGFf2VR',
        'manifest_sha256': '39eae7981a7adfc7204f0d4cc9e6a25dc7b52d0603fef39a47c7e4534030f6c3',
        'seal_sha256': '2a3b1a4ccbb6a6d5ba550da5b02c58c41f9224c7f245a99fe6cff4f226c367c6',
        'report_sha256': '6710a59af0bb79717526cc4c00d490227084d635058dc44fbef26628c95933ce',
        'source': 'backend_control110.rs',
        'source_sha256': '149da8096fcbcc95a329c3cd01bca9007def9461145a5f31f0ed2e590feeae07',
        'copies': ['REPORT.md', 'HANDOFF.json', 'PROJECTION-AUDIT.md', 'native-preservation.json', 'RESULTS.json', 'backend_control110.rs.patch'],
        'charges': 10,
        'verified': 15,
        'proof_bodies': 13,
        'archive_sha256': '27ef39d84b7a5a2bfb1ab5bdf2eb31de14e75822538067bb3a98ee4aecbfb7d3',
    },
}


def digest(filename):
    return hashlib.sha256(filename.read_bytes()).hexdigest()


def selected_inputs():
    frozen_path = DESTINATION / 'INPUTS.json'
    assert digest(frozen_path) == '8efaf2981eeaee800cdab449fdfa394747675f171ceebbd90d96cafe439fa9c9'
    records = json.loads(frozen_path.read_text())['records']
    assert len(records) == 838
    for record in records:
        filename = Path(record['path'])
        assert filename.stat().st_size == record['bytes'], str(filename)
        assert digest(filename) == record['sha256'], str(filename)
    return len(records)


def authenticate(root, expected):
    assert digest(root / 'MANIFEST.json') == expected['manifest_sha256']
    if expected['seal_sha256'] is not None:
        assert digest(root / 'SEAL.json') == expected['seal_sha256']
    seal = json.loads((root / 'SEAL.json').read_text())
    assert seal['manifest_sha256'] == expected['manifest_sha256']
    assert seal['report_sha256'] == digest(root / 'REPORT.md') == expected['report_sha256']
    assert seal['source_sha256'] == digest(root / expected['source']) == expected['source_sha256']
    manifest = json.loads((root / 'MANIFEST.json').read_text())
    records = manifest['files'] if 'files' in manifest else manifest['records']
    assert len(records) == len({record['path'] for record in records}) == 104
    for record in records:
        relative = Path(record['path'])
        assert not relative.is_absolute() and '..' not in relative.parts
        filename = root / relative
        assert filename.is_file() and not filename.is_symlink(), str(filename)
        assert filename.stat().st_size == record['bytes'], str(filename)
        assert digest(filename) == record['sha256'], str(filename)
    return records


results = []
entry_matches = selected_inputs()
for label, expected in LANES.items():
    root = Path(expected['root'])
    records = authenticate(root, expected)
    names = {record['path'] for record in records} | {'MANIFEST.json', 'SEAL.json'}
    archive_path = DESTINATION / (label + '-CANDIDATE-HANDOFF.tar.gz')
    assert not archive_path.exists()
    if 'archive_sha256' in expected:
        original_archive = root / 'handoff.tar.gz'
        assert digest(original_archive) == expected['archive_sha256']
        shutil.copyfile(original_archive, archive_path)
        assert digest(archive_path) == expected['archive_sha256']
    else:
        with tarfile.open(archive_path, 'w:gz') as archive:
            for name in sorted(names):
                archive.add(root / name, arcname=name, recursive=False)
    with tarfile.open(archive_path, 'r:gz') as archive:
        members = archive.getmembers()
        assert len(members) == len(names) == 106
        assert {member.name for member in members} == names
        for member in members:
            assert member.isfile() and not Path(member.name).is_absolute()
            assert '..' not in Path(member.name).parts
            assert archive.extractfile(member).read() == (root / member.name).read_bytes()
    for name in expected['copies']:
        destination = DESTINATION / (label + '-CANDIDATE-' + name)
        assert not destination.exists()
        shutil.copyfile(root / name, destination)
        assert digest(destination) == digest(root / name)
    authenticate(root, expected)
    result = {
        'schema': 'redb-composition110-candidate-retention-v1',
        'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'lane': label,
        'root': str(root),
        'manifest_sha256': digest(root / 'MANIFEST.json'),
        'seal_sha256': digest(root / 'SEAL.json'),
        'handoff_sha256': digest(root / 'HANDOFF.json'),
        'archive_sha256': digest(archive_path),
        'source_sha256': expected['source_sha256'],
        'payload_matches': len(records),
        'archive_members_byte_compared': len(members),
        'selected_input_matches_entry': entry_matches,
        'applications_charged': expected['charges'],
        'verified_obligations': expected['verified'],
        'checked_proof_bodies': expected['proof_bodies'],
        'checked_native_executable_bodies': 0,
        'review': 'PENDING_SINGLE_COMBINED_REVIEW',
        'acceptance': False,
        'adoption': False,
        'integration': False,
        'all18': 'OPEN',
    }
    result['selected_input_matches_exit'] = selected_inputs()
    (DESTINATION / (label + '-RETENTION.json')).write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    results.append(result)
print(json.dumps(results, indent=2, sort_keys=True))
