import datetime
import hashlib
import json
from pathlib import Path


DESTINATION = Path('/Users/tommyvolk/.t3/worktrees/verus/t3-60978068/evidence/redb-storage-composition110')
HISTORICAL = Path('/private/tmp/verus-crash-consistency94-20261105/native-recovery-reencoding-021')
CURRENT_RUNTIME = Path('/private/tmp/verus-crash-consistency94-20261105/native-leaf-lookup-007/midpoint-runtime-proposal/runtime')
EXPECTED_MANIFEST = '474753727618543b4bcf102250557aa4ca302118c21968306c1245dc5f68ff35'


def digest(filename):
    return hashlib.sha256(filename.read_bytes()).hexdigest()


def authenticate_selected():
    records = json.loads((DESTINATION / 'INPUTS.json').read_text())['records']
    for record in records:
        assert digest(Path(record['path'])) == record['sha256'], record['path']
    return len(records)


entry = authenticate_selected()
assert digest(HISTORICAL / 'MANIFEST.json') == EXPECTED_MANIFEST
manifest = json.loads((HISTORICAL / 'MANIFEST.json').read_text())
assert len(manifest) == 315
for relative, record in manifest.items():
    name = Path(relative)
    assert not name.is_absolute() and '..' not in name.parts
    filename = HISTORICAL / name
    assert filename.is_file() and not filename.is_symlink(), str(filename)
    assert filename.stat().st_size == record['size_bytes'], str(filename)
    assert digest(filename) == record['sha256'], str(filename)
binding = json.loads((HISTORICAL / 'runtime-binding.json').read_text())
comparisons = []
for name, expected in sorted(binding['runtime'].items()):
    historical_path = HISTORICAL / 'runtime' / name
    current_path = CURRENT_RUNTIME / name
    historical_sha = digest(historical_path)
    assert historical_sha == expected, str(historical_path)
    current_sha = digest(current_path) if current_path.is_file() else None
    comparisons.append({
        'name': name,
        'historical_path': str(historical_path),
        'historical_sha256': historical_sha,
        'current_path': str(current_path),
        'current_sha256': current_sha,
        'byte_identical': current_sha == historical_sha,
    })
assert next(record for record in comparisons if record['name'] == 'rust_verify')['byte_identical']
assert not next(record for record in comparisons if record['name'] == 'libvstd.rlib')['byte_identical']
assert not next(record for record in comparisons if record['name'] == 'vstd.vir')['byte_identical']
pairs = []
for crate_name, attempt, source in [
    ('recovery_reencoding021', '001', 'reencoding-001.rs'),
    ('recovery_roundtrip021', '006', 'roundtrip-005.rs'),
]:
    original_input = HISTORICAL / ('runs/attempt-' + attempt) / 'input.rs'
    assert digest(original_input) == digest(HISTORICAL / source)
    artifacts = []
    for filename in [crate_name + '.vir', 'lib' + crate_name + '.rlib']:
        retained = HISTORICAL / 'artifacts' / filename
        attempt_artifact = HISTORICAL / ('runs/attempt-' + attempt) / filename
        assert digest(retained) == digest(attempt_artifact)
        artifacts.append({'path': str(retained), 'sha256': digest(retained)})
    pairs.append({'crate': crate_name, 'positive_attempt': attempt, 'source': str(HISTORICAL / source), 'source_sha256': digest(original_input), 'artifacts': artifacts})
result = {
    'schema': 'redb-composition110-existing-header-artifact-preflight-v1',
    'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'historical_root': str(HISTORICAL),
    'historical_manifest_sha256': EXPECTED_MANIFEST,
    'historical_payload_matches': len(manifest),
    'selected_inputs_entry_matches': entry,
    'runtime_comparisons': comparisons,
    'provider_pairs': pairs,
    'historical_trust_boundary': binding['boundary'],
    'historical_artifact_reused_now': False,
    'new_verifier_invocations': 0,
    'new_builds': 0,
    'compiler_source_correspondence': 'UNESTABLISHED',
    'decision': 'Do not mix the header artifact pairs with round110 midpoint vstd. A future scratch-only composition must use the exact historical matched runtime/vstd and reverify source-module copies of round110 libraries, or separately establish another complete matching binding. No execution or adoption occurs in this preflight.',
    'preserved_exclusions': ['mutation030', 'refused_padding95', 'Drop_lifecycle_pipeline'],
    'selected_inputs_exit_matches': authenticate_selected(),
    'all18': 'OPEN',
}
destination = DESTINATION / 'HEADER-ARTIFACT-PREFLIGHT.json'
assert not destination.exists()
destination.write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
print(json.dumps({'path': str(destination), 'sha256': digest(destination), 'historical_payload_matches': len(manifest), 'matching_runtime_components': [record['name'] for record in comparisons if record['byte_identical']], 'different_runtime_components': [record['name'] for record in comparisons if not record['byte_identical']], 'provider_pairs_authenticated': len(pairs), 'selected_input_matches': result['selected_inputs_exit_matches']}, indent=2))
