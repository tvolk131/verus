import datetime
import hashlib
import json
from pathlib import Path


ROOT = Path('/Users/tommyvolk/.t3/worktrees/verus/t3-60978068')
DESTINATION = ROOT / 'evidence/redb-storage-composition110'
FROZEN = json.loads((DESTINATION / 'INPUTS.json').read_text())['records']
ATOMIC = Path('/private/tmp/verus-crash-consistency94-20261105/native-leaf-lookup-007/midpoint-runtime-proposal/source/vstd/std_specs/atomic.rs')
BACKEND = Path('/private/tmp/redb-backend110-B-cCGFf2VR')


def digest(filename):
    return hashlib.sha256(filename.read_bytes()).hexdigest()


def authenticate():
    for record in FROZEN:
        assert digest(Path(record['path'])) == record['sha256'], record['path']
    return len(FROZEN)


def section(text, start, finish):
    assert text.count(start) == 1 and text.count(finish) == 1
    start_offset = text.index(start)
    end_offset = text.index(finish, start_offset)
    value = text[start_offset:end_offset]
    return {
        'start_line': text.count('\n', 0, start_offset) + 1,
        'end_line': text.count('\n', 0, end_offset),
        'text': value,
        'sha256': hashlib.sha256(value.encode()).hexdigest(),
    }


entry = authenticate()
atomic_record = next(record for record in FROZEN if record['path'] == str(ATOMIC))
assert digest(ATOMIC) == atomic_record['sha256']
text = ATOMIC.read_text()
load = section(text, '        pub assume_specification [ <$at>::load ]', '        pub assume_specification [ <$at>::store ]')
store = section(text, '        pub assume_specification [ <$at>::store ]', '        pub assume_specification [ <$at>::swap ]')
assert 'ensures' not in load['text'] and 'ensures' not in store['text']
diagnostics_path = BACKEND / 'attempt-01/stderr.txt'
manifest = json.loads((BACKEND / 'MANIFEST.json').read_text())['records']
diagnostics_record = next(record for record in manifest if record['path'] == 'attempt-01/stderr.txt')
assert digest(diagnostics_path) == diagnostics_record['sha256']
diagnostics = diagnostics_path.read_text()
assert '`core::io::error::Error` is not supported' in diagnostics
assert '`core::panic::location::Location` is not supported' in diagnostics
result = {
    'schema': 'redb-composition110-source-observed-native-frontier-v1',
    'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'qualification': 'Source observations only; no additional verifier invocation, library adoption, or instance-resolution claim.',
    'selected_inputs_entry_matches': entry,
    'atomic_source': atomic_record,
    'atomic_source_preamble': '\n'.join(text.splitlines()[:19]) + '\n',
    'atomic_load_declaration': load,
    'atomic_store_declaration': store,
    'native_probe_stderr': {'path': str(diagnostics_path), 'sha256': digest(diagnostics_path)},
    'executed_native_frontend_blockers': ['core::io::error::Error', 'core::panic::location::Location'],
    'unexecuted_source_observed_gap': 'The inspected std Atomic load/store declarations impose ordering/no-unwind conditions but provide no stored-value postcondition or history relation.',
    'not_established': ['actual frozen-engine instance resolution', 'native sequential atomic state correspondence', 'concurrency observation law', 'dynamic backend effects', 'native callback/history frame', 'compiler/source correspondence'],
    'next_action_change': 'Do not budget another type-only probe as a route to native error-history closure; opaque-type admission, atomic state correspondence, and backend/callback semantics are independent dependency cuts.',
    'selected_inputs_exit_matches': authenticate(),
    'new_verifier_applications': 0,
    'new_trust_adopted': 0,
    'all18': 'OPEN',
}
target = DESTINATION / 'NATIVE-BINDING-FRONTIER.json'
assert not target.exists()
target.write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
print(json.dumps({'path': str(target), 'sha256': digest(target), 'entry_matches': entry, 'exit_matches': result['selected_inputs_exit_matches'], 'additional_verifier_applications': 0}, indent=2))
