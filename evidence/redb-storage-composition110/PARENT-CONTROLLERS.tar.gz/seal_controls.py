import datetime
import hashlib
import json
from pathlib import Path
import shutil
import tarfile


ROOT = Path('/private/tmp/redb-composition110-20261108T043326Z/controls')
DESTINATION = Path('/Users/tommyvolk/.t3/worktrees/verus/t3-60978068/evidence/redb-storage-composition110')


def identity(filename):
    content = filename.read_bytes()
    return {'path': str(filename.relative_to(ROOT)), 'bytes': len(content), 'sha256': hashlib.sha256(content).hexdigest()}


selected = json.loads((DESTINATION / 'INPUTS.json').read_text())['records']
for record in selected:
    assert hashlib.sha256(Path(record['path']).read_bytes()).hexdigest() == record['sha256'], record['path']
attempt = ROOT / 'attempt-002'
assert json.loads((attempt / 'status.json').read_text())['returncode'] == 0
assert '\nRan 13 tests in ' in (attempt / 'stderr.txt').read_text()
semantic = json.loads((attempt / 'semantic-controls.json').read_text())
assert all(record['negative_violations'] and not record['corrected_violations'] for record in semantic)
source = json.loads((attempt / 'source-controls.json').read_text())
assert all(record['mutant']['status'] == 'MISMATCH' and record['corrected']['status'] == 'MATCH' for record in source)
records = [identity(filename) for filename in sorted(ROOT.rglob('*')) if filename.is_file()]
manifest = {'schema': 'redb-composition110-independent-parent-controls-v1', 'files': records,
            'qualification': 'Selected control evidence only; excludes self and seal/archive to avoid self-reference'}
(ROOT / 'MANIFEST.json').write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
manifest_hash = hashlib.sha256((ROOT / 'MANIFEST.json').read_bytes()).hexdigest()
seal = {'manifest_sha256': manifest_hash, 'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'payload_count': len(records), 'selected_inputs_match': len(selected), 'all18': 'OPEN',
        'free_bytes': shutil.disk_usage('/private/tmp').free, 'native_proof': False, 'acceptance': False}
assert seal['free_bytes'] > 16 * 1024 ** 3
(ROOT / 'SEAL.json').write_text(json.dumps(seal, indent=2, sort_keys=True) + '\n')
archive_path = DESTINATION / 'PARENT-CONTROLS-HANDOFF.tar.gz'
assert not archive_path.exists()
with tarfile.open(archive_path, 'w:gz') as archive:
    for relative in [record['path'] for record in records] + ['MANIFEST.json', 'SEAL.json']:
        archive.add(ROOT / relative, arcname=relative, recursive=False)
with tarfile.open(archive_path, 'r:gz') as archive:
    members = archive.getmembers()
    assert len(members) == len(records) + 2
    for member in members:
        assert member.isfile() and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
        assert archive.extractfile(member).read() == (ROOT / member.name).read_bytes()
for name, target in {'REPORT.md': 'PARENT-CONTROLS-REPORT.md', 'attempt-002/histories.json': 'PARENT-CONTROLS-HISTORIES.json', 'attempt-002/semantic-controls.json': 'PARENT-CONTROLS-SEMANTIC.json'}.items():
    assert not (DESTINATION / target).exists()
    shutil.copyfile(ROOT / name, DESTINATION / target)
result = {**seal, 'source': str(ROOT), 'archive_sha256': hashlib.sha256(archive_path.read_bytes()).hexdigest(),
          'archive_members_byte_compared': len(records) + 2, 'tests_pass': 13,
          'history_counts': json.loads((attempt / 'histories.json').read_text()),
          'semantic_pairs': 6, 'source_pairs': 6, 'independent_combined_review': 'PENDING_ACTUAL_PROOF_CANDIDATES'}
(DESTINATION / 'PARENT-CONTROLS-RESULTS.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
print(json.dumps(result, indent=2, sort_keys=True))
