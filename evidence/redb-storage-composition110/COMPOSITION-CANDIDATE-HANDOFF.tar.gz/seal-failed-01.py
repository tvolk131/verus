import datetime
import difflib
import json
from pathlib import Path
import re
import shutil

import controller

ROOT = controller.ROOT

def read_json(path):
    return json.loads(path.read_text())

def body_groups(data):
    groups = {'original_A': [], 'original_B': [], 'new_product': []}
    scope = data.get('verus-infer', {}).get('verification_scope', {})
    for item in scope.get('native_functions', []):
        if item['body_status'] == 'checked_proof_body':
            name = item['function']
            group = 'original_A' if name.startswith('storage::') else 'original_B' if name.startswith('acknowledgement::') else 'new_product'
            groups[group].append(name)
    return {group: sorted(names) for group, names in groups.items()}

def main():
    controller.authenticate('prepublication')
    controller.resources('prepublication')
    publication = ROOT / 'publication/laneA'
    publication.mkdir(parents=True)
    shutil.copyfile(ROOT / 'composition110.rs', publication / 'composition110.rs')
    for name, (original, expected) in controller.LIBRARIES.items():
        shutil.copyfile(original, publication / name)
        if controller.digest(publication / name) != expected:
            raise RuntimeError('publication original mismatch')
    patch_parts = []
    for name in ['composition110.rs', 'buffered_flush109.rs', 'ack_cfg.rs']:
        target = 'evidence/redb-storage-composition110/laneA/' + name
        patch_parts.append('diff --git a/' + target + ' b/' + target + '\nnew file mode 100644\n')
        patch_parts.extend(difflib.unified_diff([], (publication / name).read_text().splitlines(keepends=True),
                                               fromfile='/dev/null', tofile='b/' + target))
    (ROOT / 'composition110-additive.patch').write_text(''.join(patch_parts))
    attempts = []
    for check in sorted(ROOT.glob('check-*')):
        invocation = read_json(check / 'invocation.json')
        result = read_json(check / 'result.json')
        data = read_json(check / 'stdout.txt')
        groups = body_groups(data)
        if not invocation['fresh_export_absent']:
            raise RuntimeError('nonfresh export')
        export = Path(invocation['requested_export'])
        if export.is_file() != result['export_exists']:
            raise RuntimeError('exact export observation drift')
        if export.is_file() and controller.digest(export) != result['export_sha256']:
            raise RuntimeError('exact export hash drift')
        for name, (original, expected) in controller.LIBRARIES.items():
            if controller.digest(check / name) != expected:
                raise RuntimeError('attempt original mismatch')
        attempts.append({'number': invocation['number'], 'label': invocation['label'], 'charged': True,
                         'directory': str(check), 'invocation_path': str(check / 'invocation.json'),
                         'source_path': str(check / 'composition110.rs'),
                         'source_sha256': controller.digest(check / 'composition110.rs'),
                         'verification': data['verification-results'], 'process': result,
                         'checked_proof_body_groups': groups,
                         'checked_proof_body_counts': {group: len(names) for group, names in groups.items()},
                         'checked_exec_bodies': data.get('verus-infer', {}).get('verification_scope', {}).get('checked_exec_bodies'),
                         'failed_functions': data.get('verus-infer', {}).get('failed_functions', [])})
    for number in [4, 5, 7, 8]:
        attempt = attempts[number - 1]
        if not (attempt['process']['status'] == 0 and attempt['process']['export_exists']
                and attempt['verification']['success'] and attempt['verification']['verified'] == 61
                and attempt['verification']['errors'] == 0):
            raise RuntimeError('missing full positive')
    negative = attempts[5]
    expected_failures = ['composition110::error_keeps_actual_complete_flush', 'composition110::step_invariant']
    if not (negative['process']['status'] == 1 and not negative['process']['export_exists']
            and negative['verification']['errors'] == 2
            and sorted(negative['failed_functions']) == expected_failures):
        raise RuntimeError('negative did not fail at intended backend properties')
    source = (ROOT / 'composition110.rs').read_bytes()
    for number in [5, 7, 8]:
        if Path(attempts[number - 1]['source_path']).read_bytes() != source:
            raise RuntimeError('restoration not byte-identical')
    final_groups = attempts[7]['checked_proof_body_counts']
    if final_groups != {'original_A': 26, 'original_B': 15, 'new_product': 11}:
        raise RuntimeError('unexpected checked body partition')
    report_bytes = (ROOT / 'REPORT.md').stat().st_size
    if report_bytes > 24 * 1024:
        raise RuntimeError('report budget exceeded')
    controller.write_json(ROOT / 'ACCOUNTING.json', {
        'first_clock': controller.FIRST_CLOCK, 'own_deadline': controller.DEADLINE,
        'applications_charged': len(attempts), 'application_cap': 16, 'worker_count_this_lane': 1,
        'timeout_seconds_per_application': 90, 'scratch_cap_bytes': 768 * 1024 * 1024,
        'free_disk_floor_strictly_greater_than_bytes': 16 * 1024 ** 3,
        'attempts': attempts, 'final_checked_proof_bodies': final_groups,
        'final_verified_obligations': 61, 'original_reviewed_obligations': {'A': 31, 'B': 16},
        'additional_final_obligations_not_body_count': 14, 'checked_native_exec_bodies': 0,
        'repeated_checks_are_not_new_bodies': True, 'report_bytes': report_bytes,
        'positive_corrected_restored_sources_byte_identical': True,
        'final_source_sha256': controller.digest(ROOT / 'composition110.rs'),
        'publication_destination': str(publication),
        'proposed_additive_patch_destination': 'evidence/redb-storage-composition110/laneA',
        'patch_applied_to_parent': False,
    })
    controller.authenticate('exit')
    observations = {}
    frozen_counts = []
    for authentication in sorted(ROOT.glob('authentication-*.json')):
        data = read_json(authentication)
        frozen_counts.append({'path': str(authentication), 'selected_count': data['selected_count'],
                              'mismatch_count': len(data['mismatches']), 'utc': data['finished']})
        for item in data['supplemental']:
            observations.setdefault(item['path'], []).append({'stage': data['stage'], 'sha256': item['sha256'],
                                                              'realpath': item['realpath']})
    supplemental_drift = []
    for path, observed in observations.items():
        if not path.startswith(str(ROOT) + '/') and len({item['sha256'] for item in observed}) > 1:
            supplemental_drift.append({'path': path, 'observations': observed})
    if supplemental_drift:
        raise RuntimeError('supplemental immutable identity drift')
    controller.write_json(ROOT / 'PROVENANCE.json', {
        'frozen_observations': frozen_counts, 'supplemental_observations': observations,
        'immutable_supplemental_drift': supplemental_drift,
        'bootstrap_qualification': str(ROOT / 'BOOTSTRAP.md'),
        'atomic_snapshot': False, 'exhaustive_loader_provenance': False, 'first_use_bootstrap_claim': False,
        'compiler_source_correspondence': 'UNESTABLISHED',
    })
    snapshot = controller.resources('preseal')
    sealed_utc = controller.now()
    elapsed = (datetime.datetime.now(datetime.timezone.utc) - datetime.datetime.fromisoformat(controller.FIRST_CLOCK)).total_seconds()
    if datetime.datetime.now(datetime.timezone.utc) >= datetime.datetime.fromisoformat(controller.DEADLINE):
        raise RuntimeError('deadline exceeded before seal')
    controller.write_json(ROOT / 'HANDOFF.json', {
        'lane': 'A', 'round': 110, 'status': 'CHECKED_MODEL_PRODUCT_NATIVE_CUTS_OPEN',
        'sealed_utc': sealed_utc, 'elapsed_seconds_from_first_clock': elapsed,
        'root': str(ROOT), 'report': str(ROOT / 'REPORT.md'), 'source': str(ROOT / 'composition110.rs'),
        'additive_patch': str(ROOT / 'composition110-additive.patch'),
        'publication': str(publication), 'accounting': str(ROOT / 'ACCOUNTING.json'),
        'cut_ledger': str(ROOT / 'CUT-LEDGER.json'), 'manifest': str(ROOT / 'MANIFEST.json'),
        'seal': str(ROOT / 'SEAL.json'), 'applications_charged': len(attempts),
        'final_verified_obligations': 61, 'original_A_proof_bodies': 26, 'original_B_proof_bodies': 15,
        'new_authored_proof_bodies': 11, 'checked_native_exec_bodies': 0,
        'final_source_sha256': controller.digest(ROOT / 'composition110.rs'),
        'semantic_negative': 'backend postconditions step_invariant and error_keeps_actual_complete_flush',
        'corrected_and_restored_full_positives': True, 'report_bytes': report_bytes,
        'last_resource_sample': snapshot, 'parent_modified': False, 'integration_performed': False,
        'all18': 'OPEN', 'native_adapter_R': 'OPEN',
        'combined_independent_review': 'PARENT_RESPONSIBILITY_NOT_PERFORMED_BY_THIS_LANE',
    })
    files = []
    for path in sorted(ROOT.rglob('*')):
        if path.is_file() and path.name not in ['MANIFEST.json', 'SEAL.json']:
            files.append({'path': str(path.relative_to(ROOT)), 'bytes': path.stat().st_size,
                          'sha256': controller.digest(path)})
    manifest = {'root': str(ROOT), 'utc': sealed_utc, 'files': files,
                'total_manifested_bytes': sum(item['bytes'] for item in files),
                'exclusions': ['MANIFEST.json self-reference', 'SEAL.json root seal'],
                'authenticity_scope': 'sampled artifact integrity; not producer/source/compiler trust'}
    controller.write_json(ROOT / 'MANIFEST.json', manifest)
    controller.write_json(ROOT / 'SEAL.json', {
        'utc': sealed_utc, 'manifest': str(ROOT / 'MANIFEST.json'),
        'manifest_sha256': controller.digest(ROOT / 'MANIFEST.json'),
        'manifested_files': len(files), 'manifested_bytes': manifest['total_manifested_bytes'],
        'source_sha256': controller.digest(ROOT / 'composition110.rs'),
        'report_sha256': controller.digest(ROOT / 'REPORT.md'),
        'accounting_sha256': controller.digest(ROOT / 'ACCOUNTING.json'),
        'handoff_sha256': controller.digest(ROOT / 'HANDOFF.json'),
        'before_own_deadline': True, 'all18': 'OPEN',
    })
    print(json.dumps(read_json(ROOT / 'HANDOFF.json'), indent=2))
    print(json.dumps(read_json(ROOT / 'SEAL.json'), indent=2))

if __name__ == '__main__':
    main()
