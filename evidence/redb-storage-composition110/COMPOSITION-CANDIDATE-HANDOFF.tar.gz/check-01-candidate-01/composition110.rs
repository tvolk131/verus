use vstd::prelude::*;
#[path = "buffered_flush109.rs"]
pub mod storage;
#[path = "ack_cfg.rs"]
pub mod acknowledgement;

verus! {

pub const HEADER_BYTES: nat = 320;

pub struct Effect {
    pub image: storage::Image,
    pub pending: Seq<Seq<storage::Entry>>,
}

pub struct Action {
    pub signal: int,
    pub decisions: spec_fn(nat, nat) -> storage::Decision,
    pub sync_ok: bool,
    pub persisted: Set<int>,
    pub effect: spec_fn(storage::Image, Seq<Seq<storage::Entry>>) -> Effect,
}

pub struct FlushRecord {
    pub pc: int,
    pub before: storage::Image,
    pub pending: Seq<Seq<storage::Entry>>,
    pub decisions: spec_fn(nat, nat) -> storage::Decision,
    pub sync_ok: bool,
    pub persisted: Set<int>,
    pub result: storage::Run,
}

pub struct Product {
    pub control: acknowledgement::State,
    pub image: storage::Image,
    pub pending: Seq<Seq<storage::Entry>>,
    pub first_header: Seq<u8>,
    pub second_header: Seq<u8>,
    pub geometry: nat,
    pub history: Seq<FlushRecord>,
    pub first_index: int,
    pub second_index: int,
    pub blocked: bool,
    pub rejected: Option<Effect>,
}

pub open spec fn initial(config: acknowledgement::Config, image: storage::Image,
    pending: Seq<Seq<storage::Entry>>, first_header: Seq<u8>, second_header: Seq<u8>) -> Product {
    Product { control: acknowledgement::initial(config), geometry: image.visible.len(),
        image, pending, first_header, second_header, history: Seq::empty(),
        first_index: -1, second_index: -1, blocked: false, rejected: None }
}

pub open spec fn storage_valid(state: Product) -> bool {
    &&& storage::valid(state.image)
    &&& storage::pending_valid(state.pending, state.geometry)
    &&& state.image.visible.len() == state.geometry
    &&& HEADER_BYTES <= state.geometry
    &&& state.first_header.len() == HEADER_BYTES
    &&& state.second_header.len() == HEADER_BYTES
}

pub open spec fn is_flush(state: Product) -> bool {
    state.control.pc == 24 || state.control.pc == 28
}

pub open spec fn framed(state: Product, action: Action) -> bool {
    let proposed = (action.effect)(state.image, state.pending);
    proposed.image == state.image && proposed.pending == state.pending
}

pub open spec fn flushed(state: Product, action: Action) -> storage::Run {
    storage::model_flush(state.image, state.pending, action.decisions,
        action.sync_ok, action.persisted)
}

pub open spec fn generated_signal(state: Product, action: Action) -> int {
    if state.control.status != 0 { 0 }
    else if is_flush(state) { if flushed(state, action).ok { 0 } else { 1 } }
    else if !framed(state, action) { 5 }
    else { action.signal }
}

pub open spec fn header_pending(pending: Seq<Seq<storage::Entry>>, header: Seq<u8>) -> bool {
    pending.len() > 0 && pending.last() == seq![storage::Entry { offset: 0, bytes: header }]
}

pub open spec fn record(state: Product, action: Action) -> FlushRecord {
    FlushRecord { pc: state.control.pc, before: state.image, pending: state.pending,
        decisions: action.decisions, sync_ok: action.sync_ok, persisted: action.persisted,
        result: flushed(state, action) }
}

pub open spec fn step(state: Product, config: acknowledgement::Config, action: Action) -> Product {
    if state.control.status != 0 { state }
    else {
        let signal = generated_signal(state, action);
        let control = acknowledgement::step(state.control, config, signal);
        if is_flush(state) {
            let result = flushed(state, action);
            Product { control, image: result.image, pending: result.pending,
                history: state.history.push(record(state, action)),
                first_index: if state.control.pc == 24 { state.history.len() as int } else { state.first_index },
                second_index: if state.control.pc == 28 { state.history.len() as int } else { state.second_index },
                ..state }
        } else if !framed(state, action) {
            Product { control, blocked: true,
                rejected: Some((action.effect)(state.image, state.pending)), ..state }
        } else if signal == 0 && (state.control.pc == 23 || state.control.pc == 27) {
            let bytes = if state.control.pc == 23 { state.first_header } else { state.second_header };
            Product { control,
                pending: state.pending.push(seq![storage::Entry { offset: 0, bytes }]), ..state }
        } else { Product { control, ..state } }
    }
}

pub open spec fn run(start: Product, config: acknowledgement::Config, actions: Seq<Action>) -> Product
    decreases actions.len(),
{
    if actions.len() == 0 { start }
    else { step(run(start, config, actions.drop_last()), config, actions.last()) }
}

pub open spec fn signals(start: Product, config: acknowledgement::Config, actions: Seq<Action>) -> Seq<int>
    decreases actions.len(),
{
    if actions.len() == 0 { Seq::empty() }
    else {
        let prefix = actions.drop_last();
        signals(start, config, prefix).push(generated_signal(run(start, config, prefix), actions.last()))
    }
}

pub open spec fn drained(pending: Seq<Seq<storage::Entry>>) -> bool {
    forall|stripe: int| 0 <= stripe < pending.len() ==> (#[trigger] pending[stripe]).len() == 0
}

pub open spec fn exact_record(item: FlushRecord) -> bool {
    &&& item.pc == 24 || item.pc == 28
    &&& storage::valid(item.before)
    &&& storage::pending_valid(item.pending, item.before.visible.len())
    &&& item.result == storage::model_flush(item.before, item.pending, item.decisions,
        item.sync_ok, item.persisted)
    &&& storage::valid(item.result.image)
    &&& item.result.ok ==> item.result.image.durable == storage::visible_stripes(item.before.visible, item.pending)
    &&& item.result.ok ==> drained(item.result.pending)
    &&& item.result.ok ==> item.result.events.len() > 0
        && item.result.events.last().kind == 3 && item.result.events.last().ok
    &&& !storage::model_stripes(item.before, item.pending, 0, item.decisions).ok ==>
        storage::no_sync(item.result.events)
}

pub open spec fn certificate(state: Product, index: int, pc: int, header: Seq<u8>) -> bool {
    &&& 0 <= index < state.history.len()
    &&& state.history[index].pc == pc
    &&& exact_record(state.history[index])
    &&& state.history[index].result.ok
    &&& header_pending(state.history[index].pending, header)
    &&& state.history[index].result.image.durable.subrange(0, HEADER_BYTES as int) == header
}

pub open spec fn invariant(state: Product, config: acknowledgement::Config) -> bool {
    &&& storage_valid(state)
    &&& acknowledgement::cfg_invariant(state.control, config)
    &&& state.blocked ==> state.control.status == 9
    &&& state.rejected.is_some() == state.blocked
    &&& forall|position: int| 0 <= position < state.history.len() ==>
        exact_record(#[trigger] state.history[position])
    &&& (state.control.pc == 24 && state.control.status == 0) ==> header_pending(state.pending, state.first_header)
    &&& (state.control.pc == 28 && state.control.status == 0) ==> header_pending(state.pending, state.second_header)
    &&& state.control.first_barrier >= 0 ==> certificate(state, state.first_index, 24, state.first_header)
    &&& state.control.final_barrier >= 0 ==> certificate(state, state.second_index, 28, state.second_header)
    &&& state.control.final_barrier >= 0 ==> state.image == state.history[state.second_index].result.image
        && state.pending == state.history[state.second_index].result.pending
}

pub proof fn flush_checked(state: Product, action: Action)
    requires storage_valid(state), is_flush(state),
    ensures exact_record(record(state, action)),
        storage::pending_valid(flushed(state, action).pending, state.geometry),
        flushed(state, action).image.visible.len() == state.geometry,
{
    storage::check_stripes(state.image, state.pending, 0, action.decisions);
    storage::flush_refinement(state.image, state.pending, action.decisions, action.sync_ok, action.persisted);
    let result = flushed(state, action);
    let drain = storage::model_stripes(state.image, state.pending, 0, action.decisions);
    assert forall|stripe: int| 0 <= stripe < result.pending.len() implies
        storage::entries_valid(#[trigger] result.pending[stripe], state.geometry) by {
        if stripe < drain.completed {
            assert(result.pending[stripe] == Seq::<storage::Entry>::empty());
        } else {
            assert(result.pending[stripe] == state.pending[stripe]);
        }
    }
}

pub proof fn complete_header(state: Product, action: Action, header: Seq<u8>)
    requires storage_valid(state), is_flush(state), header.len() == HEADER_BYTES,
        header_pending(state.pending, header), flushed(state, action).ok,
    ensures flushed(state, action).image.durable.subrange(0, HEADER_BYTES as int) == header,
{
    flush_checked(state, action);
    storage::check_stripes(state.image, state.pending, 0, action.decisions);
    let final_bytes = flushed(state, action).image.durable;
    assert forall|address: int| 0 <= address < HEADER_BYTES implies
        final_bytes[address] == header[address] by {
        let selected = (state.pending.len() - 1) as nat;
        assert(state.pending[selected as int] == seq![storage::Entry { offset: 0, bytes: header }]);
        storage::stripes_reflect_last_cover(state.image.visible, state.pending, address, selected, 0);
    }
    assert(final_bytes.subrange(0, HEADER_BYTES as int) =~= header);
}

pub proof fn initial_invariant(config: acknowledgement::Config, image: storage::Image,
    pending: Seq<Seq<storage::Entry>>, first_header: Seq<u8>, second_header: Seq<u8>)
    requires storage::valid(image), storage::pending_valid(pending, image.visible.len()),
        HEADER_BYTES <= image.visible.len(), first_header.len() == HEADER_BYTES, second_header.len() == HEADER_BYTES,
    ensures invariant(initial(config, image, pending, first_header, second_header), config),
{
    acknowledgement::initial_invariant(config);
}

pub proof fn step_invariant(state: Product, config: acknowledgement::Config, action: Action)
    requires acknowledgement::local_mode(config), invariant(state, config),
    ensures invariant(step(state, config, action), config),
{
    let after = step(state, config, action);
    let signal = generated_signal(state, action);
    acknowledgement::step_preserves_invariant(state.control, config, signal);
    if state.control.status == 0 {
        if is_flush(state) {
            flush_checked(state, action);
            assert forall|position: int| 0 <= position < after.history.len() implies
                exact_record(#[trigger] after.history[position]) by {
                if position < state.history.len() {
                    assert(after.history[position] == state.history[position]);
                }
            }
            if flushed(state, action).ok {
                if state.control.pc == 24 { complete_header(state, action, state.first_header); }
                else { complete_header(state, action, state.second_header); }
            }
        } else if framed(state, action) && signal == 0
            && (state.control.pc == 23 || state.control.pc == 27) {
            assert forall|stripe: int| 0 <= stripe < after.pending.len() implies
                storage::entries_valid(#[trigger] after.pending[stripe], state.geometry) by {
                if stripe < state.pending.len() { assert(after.pending[stripe] == state.pending[stripe]); }
            }
        }
    }
}

pub proof fn checked_run(start: Product, config: acknowledgement::Config, actions: Seq<Action>)
    requires acknowledgement::local_mode(config), invariant(start, config),
        start.control == acknowledgement::initial(config),
    ensures invariant(run(start, config, actions), config),
        run(start, config, actions).control == acknowledgement::run(config, signals(start, config, actions)),
    decreases actions.len(),
{
    if actions.len() > 0 {
        checked_run(start, config, actions.drop_last());
        let before = run(start, config, actions.drop_last());
        step_invariant(before, config, actions.last());
        assert(signals(start, config, actions).drop_last() == signals(start, config, actions.drop_last()));
        assert(signals(start, config, actions).last() == generated_signal(before, actions.last()));
    }
}

pub proof fn public_ok_composes(start: Product, config: acknowledgement::Config, actions: Seq<Action>)
    requires acknowledgement::local_mode(config), invariant(start, config),
        start.control == acknowledgement::initial(config), run(start, config, actions).control.status == 1,
    ensures ({
        let final_state = run(start, config, actions);
        !final_state.blocked
            && certificate(final_state, final_state.first_index, 24, final_state.first_header)
            && certificate(final_state, final_state.second_index, 28, final_state.second_header)
            && final_state.first_index < final_state.second_index
            && final_state.image.durable.subrange(0, HEADER_BYTES as int) == final_state.second_header
            && drained(final_state.pending)
            && 0 <= final_state.control.first_write < final_state.control.first_barrier
                < final_state.control.second_write < final_state.control.final_barrier
                < final_state.control.publication < final_state.control.acknowledgement
    }),
{
    checked_run(start, config, actions);
    acknowledgement::public_ok_has_two_successful_barriers(config, signals(start, config, actions));
}

pub open spec fn success_action() -> Action {
    Action { signal: 0, decisions: storage::successful_decisions(), sync_ok: true,
        persisted: Set::empty(),
        effect: |image: storage::Image, pending: Seq<Seq<storage::Entry>>| Effect { image, pending } }
}

pub proof fn success_signals(start: Product, config: acknowledgement::Config, count: nat)
    requires acknowledgement::local_mode(config), invariant(start, config),
        start.control == acknowledgement::initial(config),
    ensures signals(start, config, Seq::new(count, |position: int| success_action()))
        == Seq::new(count, |position: int| 0int),
    decreases count,
{
    if count > 0 {
        let actions = Seq::new(count, |position: int| success_action());
        let prefix = actions.drop_last();
        assert(prefix =~= Seq::new((count - 1) as nat, |position: int| success_action()));
        success_signals(start, config, (count - 1) as nat);
        checked_run(start, config, prefix);
        let before = run(start, config, prefix);
        if before.control.status == 0 && is_flush(before) {
            storage::arbitrary_successful_flush(before.image, before.pending);
        }
        assert(generated_signal(before, success_action()) == 0);
        assert(signals(start, config, actions) =~= Seq::new(count, |position: int| 0int));
    }
}

pub proof fn nonvacuous_symbolic_success(image: storage::Image, pending: Seq<Seq<storage::Entry>>,
    first_header: Seq<u8>, second_header: Seq<u8>)
    requires storage::valid(image), storage::pending_valid(pending, image.visible.len()),
        HEADER_BYTES <= image.visible.len(), first_header.len() == HEADER_BYTES, second_header.len() == HEADER_BYTES,
    ensures ({
        let config = acknowledgement::witness_config();
        let start = initial(config, image, pending, first_header, second_header);
        let actions = Seq::new(46, |position: int| success_action());
        let result = run(start, config, actions);
        result.control.status == 1 && !result.blocked
            && result.image.durable.subrange(0, HEADER_BYTES as int) == second_header
            && config.old_secondary != config.new_slot
    }),
{
    let config = acknowledgement::witness_config();
    let start = initial(config, image, pending, first_header, second_header);
    let actions = Seq::new(46, |position: int| success_action());
    initial_invariant(config, image, pending, first_header, second_header);
    success_signals(start, config, 46);
    checked_run(start, config, actions);
    acknowledgement::reachable_public_ok_witness();
    public_ok_composes(start, config, actions);
}

pub proof fn nonvacuous_post_publication_error(image: storage::Image, pending: Seq<Seq<storage::Entry>>,
    first_header: Seq<u8>, second_header: Seq<u8>)
    requires storage::valid(image), storage::pending_valid(pending, image.visible.len()),
        HEADER_BYTES <= image.visible.len(), first_header.len() == HEADER_BYTES, second_header.len() == HEADER_BYTES,
    ensures ({
        let config = acknowledgement::witness_config();
        let start = initial(config, image, pending, first_header, second_header);
        let before = run(start, config, Seq::new(34, |position: int| success_action()));
        let failure = Action { signal: 1, ..success_action() };
        let after = step(before, config, failure);
        before.control.pc == 35 && before.control.publication >= 0
            && after.control.status == 2 && after.control.acknowledgement == -1
            && after.history == before.history && after.image == before.image
            && certificate(after, after.second_index, 28, second_header)
    }),
{
    let config = acknowledgement::witness_config();
    let start = initial(config, image, pending, first_header, second_header);
    let actions = Seq::new(34, |position: int| success_action());
    initial_invariant(config, image, pending, first_header, second_header);
    success_signals(start, config, 34);
    checked_run(start, config, actions);
    acknowledgement::successful_prefix_reaches_pc(34);
    acknowledgement::run_invariant(config, Seq::new(34, |position: int| 0int));
    let before = run(start, config, actions);
    let failure = Action { signal: 1, ..success_action() };
    acknowledgement::later_error_does_not_erase_publication(before.control, config);
    step_invariant(before, config, failure);
}

pub proof fn callback_mismatch_stops_open(state: Product, config: acknowledgement::Config, action: Action)
    requires state.control.status == 0, !is_flush(state), !framed(state, action),
    ensures step(state, config, action).control.status == 9,
        step(state, config, action).blocked,
        step(state, config, action).rejected == Some((action.effect)(state.image, state.pending)),
        step(state, config, action).history == state.history,
{}

pub proof fn error_keeps_actual_complete_flush(state: Product, config: acknowledgement::Config, action: Action)
    requires state.control.status == 0, is_flush(state), !flushed(state, action).ok,
    ensures step(state, config, action).control.status == 2,
        step(state, config, action).image == flushed(state, action).image,
        step(state, config, action).pending == flushed(state, action).pending,
        step(state, config, action).history.last() == record(state, action),
{}

}
