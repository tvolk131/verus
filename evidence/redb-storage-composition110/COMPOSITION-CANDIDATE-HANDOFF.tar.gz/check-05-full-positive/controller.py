import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time

ROOT = Path('/private/tmp/redb-storage110-laneA-LBwsoPMW')
PARENT = Path('/Users/tommyvolk/.t3/worktrees/verus/t3-60978068')
RUNTIME = Path('/private/tmp/verus-crash-consistency94-20261105/native-leaf-lookup-007/midpoint-runtime-proposal/runtime')
TOOLCHAIN = Path('/Users/tommyvolk/.rustup/toolchains/1.99.1-aarch64-apple-darwin')
INPUTS = PARENT / 'evidence/redb-storage-composition110/INPUTS.json'
FIRST_CLOCK = '2026-11-08T04:38:49+00:00'
DEADLINE = '2026-11-08T05:03:49+00:00'
LIBRARIES = {
    'buffered_flush109.rs': ('/private/tmp/redb-storage109-lane1-20261108T034224Z/buffered_flush109.rs', '29485224c99ba2f994012ff53b2ddc98c9cab79daaf7b3fc2a855b952d2fdc4f'),
    'ack_cfg.rs': ('/private/tmp/redb-storage109-lane2-wqh8Ege8/ack_cfg.rs', '447a7fcfa23fcdec6114be0ec4eb27274ed4133efbc7d81fdac896dffd9306a2'),
}

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def digest(path):
    hasher = hashlib.sha256()
    with open(path, 'rb') as stream:
        while True:
            block = stream.read(1024 * 1024)
            if not block:
                break
            hasher.update(block)
    return hasher.hexdigest()

def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

def resources(stage):
    scratch_bytes = sum(path.stat().st_size for path in ROOT.rglob('*') if path.is_file())
    free_bytes = shutil.disk_usage(ROOT).free
    observation = {'utc': now(), 'stage': stage, 'scratch_bytes': scratch_bytes, 'free_bytes': free_bytes}
    with (ROOT / 'resources.jsonl').open('a') as stream:
        stream.write(json.dumps(observation, sort_keys=True) + '\n')
    if scratch_bytes > 768 * 1024 * 1024 or free_bytes <= 16 * 1024 ** 3:
        raise RuntimeError('resource boundary reached')
    return observation

def authenticate(stage):
    started = now()
    frozen = json.loads(INPUTS.read_text())
    records = []
    mismatches = []
    scope_files = {
        'PLAN.md': '5ac77193513096bade9dc5cae35c8a4a7237ddbee6b1f527ec8c99c92edac377',
        'AUTHORIZATION.json': 'a6a8e4632a709b25cc33d852d8b963cdc4e322db542ad733225a198ba48407e2',
        'INPUTS.json': '8efaf2981eeaee800cdab449fdfa394747675f171ceebbd90d96cafe439fa9c9',
    }
    for name, expected in scope_files.items():
        path = INPUTS.parent / name
        actual = digest(path)
        if actual != expected:
            mismatches.append({'path': str(path), 'expected': expected, 'actual': actual})
    for expected in frozen['records']:
        path = Path(expected['path'])
        actual = digest(path) if path.is_file() else None
        record = {'path': str(path), 'expected': expected['sha256'], 'actual': actual,
                  'bytes': path.stat().st_size if path.is_file() else None}
        records.append(record)
        if actual != expected['sha256']:
            mismatches.append(record)
    supplemental_paths = {str(Path(__file__)), sys.executable,
        '/Library/Developer/CommandLineTools/Library/Frameworks/Python3.framework/Versions/3.9/Python3',
        '/bin/zsh', '/usr/bin/shasum', '/usr/bin/perl', '/bin/date', '/bin/df', '/bin/mkdir', '/bin/cp',
        '/Users/tommyvolk/.local/bin/codex',
        '/Users/tommyvolk/.t3/userdata/providers/codex/codex_095eca24-b4b7-4a15-8759-9d8964dbd03a/shadow/tmp/arg0-macos/codex-arg011pOCK/apply_patch'}
    perl_modules = ROOT / 'perl-loaded-modules.txt'
    if perl_modules.exists():
        supplemental_paths.update(perl_modules.read_text().splitlines())
    supplemental_paths.update(str(path) for path in Path('/System/Library/Perl/5.34/darwin-thread-multi-2level/auto').rglob('*.bundle'))
    supplemental_paths.update(str(path) for path in RUNTIME.iterdir() if path.is_file())
    supplemental_paths.update(str(path) for path in TOOLCHAIN.glob('lib/*.dylib'))
    supplemental_paths.update(str(path) for path in TOOLCHAIN.glob('bin/rust*') if path.is_file())
    for module in list(sys.modules.values()):
        module_path = getattr(module, '__file__', None)
        if module_path and Path(module_path).is_file():
            supplemental_paths.add(module_path)
    supplemental = [{'path': path, 'realpath': str(Path(path).resolve()), 'sha256': digest(path),
                     'bytes': Path(path).stat().st_size} for path in sorted(supplemental_paths)]
    result = {'stage': stage, 'started': started, 'finished': now(), 'records': records,
              'selected_count': len(records), 'mismatches': mismatches, 'supplemental': supplemental,
              'bootstrap_qualification': 'Shell/hash/controller/Python imports were observed before full loaded-module enumeration. This is not atomic, exhaustive, or first-use bootstrap provenance.',
              'inputs_sha256': digest(INPUTS), 'first_clock': FIRST_CLOCK, 'deadline': DEADLINE}
    write_json(ROOT / ('authentication-' + stage + '.json'), result)
    if mismatches:
        raise RuntimeError('frozen input drift: ' + str(len(mismatches)))
    for name, (original, expected) in LIBRARIES.items():
        if digest(original) != expected:
            raise RuntimeError('library drift: ' + name)
    return result

def run(label, source):
    attempts = sorted(ROOT.glob('check-*'))
    number = len(attempts) + 1
    if number > 16:
        raise RuntimeError('application allowance exhausted')
    if datetime.datetime.now(datetime.timezone.utc) >= datetime.datetime.fromisoformat(DEADLINE) - datetime.timedelta(seconds=100):
        raise RuntimeError('deadline reserve reached')
    check = ROOT / ('check-%02d-%s' % (number, label))
    check.mkdir()
    write_json(check / 'charged.json', {'charged': True, 'number': number, 'label': label, 'utc': now()})
    shutil.copyfile(__file__, check / 'controller.py')
    resources('preexecution-%02d' % number)
    authenticate('preexecution-%02d' % number)
    copied_source = check / 'composition110.rs'
    shutil.copyfile(source, copied_source)
    for name, (original, expected) in LIBRARIES.items():
        shutil.copyfile(original, check / name)
        if digest(check / name) != expected:
            raise RuntimeError('copy mismatch')
    environment = {
        'PATH': str(TOOLCHAIN / 'bin') + ':/usr/bin:/bin:/usr/sbin:/sbin',
        'RUSTC': str(TOOLCHAIN / 'bin/rustc'), 'RUSTDOC': str(TOOLCHAIN / 'bin/rustdoc'),
        'RUSTC_BOOTSTRAP': '1', 'RUSTUP_TOOLCHAIN': TOOLCHAIN.name,
        'RUSTUP_NO_UPDATE_CHECK': '1', 'VERUS_USE_RUSTUP': '0', 'VERUS_IN_VARGO': '1',
        'VERUS_Z3_PATH': str(RUNTIME / 'z3'),
        'VERUS_EXTRA_ARGS': '--sysroot ' + str(TOOLCHAIN),
        'DYLD_LIBRARY_PATH': str(TOOLCHAIN / 'lib') + ':' + str(TOOLCHAIN / 'lib/rustlib/aarch64-apple-darwin/lib'),
        'CARGO_NET_OFFLINE': 'true', 'GIT_CONFIG_GLOBAL': '/dev/null',
        'GIT_CONFIG_NOSYSTEM': '1', 'GIT_OPTIONAL_LOCKS': '0',
        'PYTHONDONTWRITEBYTECODE': '1', 'RUST_MIN_STACK': '20971520', 'PWD': str(check),
    }
    for variable in ['HOME', 'CARGO_HOME', 'CARGO_TARGET_DIR', 'RUSTUP_HOME', 'TMPDIR', 'TMP', 'TEMP',
                     'XDG_CACHE_HOME', 'XDG_CONFIG_HOME', 'XDG_DATA_HOME', 'XDG_STATE_HOME', 'VERUS_INFER_CACHE']:
        directory = check / variable.lower()
        directory.mkdir()
        environment[variable] = str(directory)
    export = check / 'composition110.vir'
    argv = [str(RUNTIME / 'verus'), '--sysroot', str(TOOLCHAIN), '--edition=2024', '--crate-type=lib',
            '--crate-name', 'composition110', '--no-cheating', '--output-json', '--num-threads', '1',
            '--triggers-mode', 'silent', '--multiple-errors', '8', '--rlimit', '20', '-C', 'debug-assertions=no',
            '--export', str(export), str(copied_source)]
    invocation = {'argv': argv, 'environment': environment, 'cwd': str(check), 'label': label,
                  'number': number, 'charged': True, 'timeout_seconds': 90, 'utc': now(),
                  'requested_export': str(export), 'fresh_export_absent': not export.exists(),
                  'source_sha256': digest(copied_source),
                  'direct_tools': {str(RUNTIME / name): digest(RUNTIME / name) for name in ['verus', 'rust_verify', 'z3', 'vstd.vir', 'libvstd.rlib']}}
    write_json(check / 'invocation.json', invocation)
    started = time.monotonic()
    with (check / 'stdout.txt').open('wb') as stdout, (check / 'stderr.txt').open('wb') as stderr:
        process = subprocess.Popen(argv, cwd=check, env=environment, stdout=stdout, stderr=stderr, start_new_session=True)
        timed_out = False
        try:
            status = process.wait(timeout=90)
        except subprocess.TimeoutExpired:
            timed_out = True
            os.killpg(process.pid, signal.SIGKILL)
            status = process.wait()
    result = {'utc': now(), 'status': status, 'timed_out': timed_out, 'elapsed_seconds': time.monotonic() - started,
              'exact_export': str(export), 'export_exists': export.is_file(),
              'export_bytes': export.stat().st_size if export.is_file() else None,
              'export_sha256': digest(export) if export.is_file() else None}
    write_json(check / 'result.json', result)
    resources('postexecution-%02d' % number)
    print(json.dumps({'check': str(check), **result}, indent=2))
    try:
        parsed = json.loads((check / 'stdout.txt').read_text())
        print(json.dumps(parsed.get('verification-results', parsed), indent=2))
    except ValueError:
        print((check / 'stdout.txt').read_text())
    print((check / 'stderr.txt').read_text())

if __name__ == '__main__':
    if sys.argv[1] == 'auth':
        result = authenticate(sys.argv[2])
        resources(sys.argv[2])
        print(json.dumps({'selected_count': result['selected_count'], 'mismatches': len(result['mismatches']), 'finished': result['finished']}))
    elif sys.argv[1] == 'run':
        run(sys.argv[2], Path(sys.argv[3]))
