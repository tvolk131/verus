# Retained publication-controller correction

The first seal.py invocation at approximately 04:52 UTC failed its own body
partition sanity check because names include the crate prefix composition110::.
It did not run any verifier application and produced no manifest or seal.
The initial script is preserved as seal-failed-01.py and its prepublication
authentication as authentication-prepublication-failed-01.json.

Transcribed tool diagnostic, not a claimed independently captured raw log:

```
Traceback (most recent call last):
  File "/private/tmp/redb-storage110-laneA-LBwsoPMW/seal.py", line 173, in <module>
    main()
  File "/private/tmp/redb-storage110-laneA-LBwsoPMW/seal.py", line 85, in main
    raise RuntimeError('unexpected checked body partition')
RuntimeError: unexpected checked body partition
```

Correction: classify checked proof bodies by the ::storage:: and
::acknowledgement:: module components rather than prefix-only matching; allow
the existing publication directory on this corrected publication attempt.
No Rust source, verifier environment, proof scope or library bytes changed.
