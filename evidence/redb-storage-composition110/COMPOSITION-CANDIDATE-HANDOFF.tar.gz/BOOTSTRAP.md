# Provenance qualification

First clock: 2026-11-08 04:38:49 UTC. Own hard cutoff: 05:03:49 UTC,
earlier than the requested 05:05:00 handoff. No clock pause or extension.

The entry shell inspected the authorization, scoped AGENTS candidates, original
libraries and invocation examples read-only. Shell shasum authenticated both
sealed libraries and all three authorization files before implementation.
The controller then checked all 838 selected frozen records; zero drift.
This sequence is not an atomic snapshot or a first-use bootstrap claim.

The controller uses the direct installed framework Python executable, never the
/usr/bin/python3 shim. Its executable/framework and loaded module identities are
enumerated at entry and before each verifier application. Python's initial
imports necessarily precede enumeration; no exhaustive loader/OS shared-cache
provenance is claimed. The direct verifier launcher, rust_verify, solver,
runtime libraries, vstd and selected toolchain files are authenticated, not
rebuilt or copied. No rustup launcher is used. The verifier's own source/compiler
correspondence remains UNESTABLISHED.

The apply_patch command is a symlink to the existing Codex Mach-O executable,
not a Python/shell shim. Its identity was discovered after initial authored
edits, authenticated at 04:46:42 UTC before subsequent edits, and added to later
preexecution/exit supplemental records. SHA256:
39acf979729dd290f9a24ee38b2914e036c91b65952872e28ae2a6b88a7db7c1.
An attempted textual launcher inspection accidentally read binary bytes to the
tool output. It did not execute that binary as an application, copy it into
scratch, or change parent inputs. Bootstrap date/df/hash/Perl module identities
are supplemental sampled observations, not comprehensive causal provenance.
Perl module discovery itself preceded their supplemental hashes. The shell
tool harness, platform loader and every transitive OS dependency are not fully
enumerated. These limitations do not establish native producer trust.
