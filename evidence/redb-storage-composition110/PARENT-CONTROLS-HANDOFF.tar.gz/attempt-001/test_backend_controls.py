import unittest

import backend_controls as controls


class BackendControls(unittest.TestCase):
    def test_original_selected_bodies_match(self):
        self.assertEqual(controls.characterize(controls.NATIVE.read_text())['status'], 'MATCH')

    def test_normal_error_latches_and_stops_later_write(self):
        failed = controls.step(controls.State(), 'write', controls.Outcome(False, 1))
        later = controls.step(failed.state, 'write', controls.Outcome(True, 0))
        self.assertTrue(failed.state.failed)
        self.assertEqual(failed.state.effect, 1)
        self.assertFalse(later.called)
        self.assertEqual(later.state, failed.state)
        self.assertEqual(later.error, 'PreviousIo')

    def test_best_effort_error_allows_following_write(self):
        failed = controls.step(controls.State(), 'best_effort', controls.Outcome(False, 1))
        later = controls.step(failed.state, 'write', controls.Outcome(True, 0))
        self.assertFalse(failed.state.failed)
        self.assertEqual(failed.state.effect, 1)
        self.assertTrue(later.called)

    def test_close_error_sets_flags_before_callback(self):
        returned = controls.step(controls.State(), 'close', controls.Outcome(False, 1))
        self.assertEqual(returned.callback_flags, (True, True))
        self.assertTrue(returned.state.closed)
        self.assertTrue(returned.state.failed)
        self.assertEqual(returned.error, 'BackendIo')

    def test_closed_precedence_requires_io_failed_observation(self):
        self.assertIsNone(controls.preflight(controls.State(closed=True)))
        self.assertEqual(controls.preflight(controls.State(failed=True)), 'PreviousIo')
        self.assertEqual(controls.preflight(controls.State(failed=True, closed=True)), 'DatabaseClosed')

    def test_explicit_close_has_no_preflight_reclose_guard(self):
        returned = controls.step(controls.State(failed=True, closed=True), 'close', controls.Outcome(True, 1))
        self.assertTrue(returned.called)

    def test_success_does_not_mean_opaque_callback_is_inert(self):
        returned = controls.step(controls.State(effect=0), 'sync', controls.Outcome(True, 1))
        self.assertEqual(returned.state.effect, 1)
        self.assertIsNone(returned.error)

    def test_all_semantic_mutants_have_corrected_counterparts(self):
        records = controls.semantic_controls()
        self.assertEqual(len(records), 6)
        for record in records:
            with self.subTest(mutation=record['mutation']):
                self.assertTrue(record['negative_violations'])
                self.assertEqual(record['corrected_violations'], [])

    def test_all_source_mutants_are_mismatches_not_parser_failures(self):
        records = controls.source_controls(controls.NATIVE.read_text())
        self.assertEqual(len(records), 6)
        for record in records:
            with self.subTest(target=record['target']):
                self.assertEqual(record['mutant']['status'], 'MISMATCH')
                self.assertEqual(record['corrected']['status'], 'MATCH')

    def test_source_refusal_is_distinct(self):
        self.assertEqual(controls.characterize(None)['status'], 'REFUSAL')
        self.assertEqual(controls.characterize('fn missing() {}', False)['status'], 'REFUSAL')

    def test_source_parse_failure_is_distinct(self):
        self.assertEqual(controls.characterize('impl CheckedBackend {', False)['status'], 'PARSE_FAILURE')

    def test_finite_history_inventory(self):
        result = controls.check_histories()
        self.assertEqual(result['histories'], 17476)
        self.assertGreater(result['preflight_refusals'], 0)
        self.assertGreater(result['backend_callbacks'], 0)

    def test_unsupported_operation_refuses(self):
        with self.assertRaises(ValueError):
            controls.step(controls.State(), 'unknown', controls.Outcome(True, 0))


if __name__ == '__main__':
    unittest.main()
