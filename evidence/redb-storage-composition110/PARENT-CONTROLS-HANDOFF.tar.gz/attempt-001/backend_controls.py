from dataclasses import asdict, dataclass, replace
import hashlib
from itertools import product
from pathlib import Path
import sys


PREVIOUS_CONTROLS = Path('/private/tmp/redb-storage109-independent-controls-vKPHDj8s')
sys.path.insert(0, str(PREVIOUS_CONTROLS))
from source_guards import ParseFailure, Refusal, fragment, tokens


NATIVE = Path('/private/tmp/verus-crash-consistency94-20261105/native-leaf-lookup-007/recovered-native/redb/src/tree_store/page_store/cached_file.rs')
NATIVE_SHA256 = 'cb901d44531b23f87d1bd31f72a24f1dc69308b5417db2167b7508921ffda486'
OPERATIONS = ('write', 'sync', 'best_effort', 'close')
RULES = {
    'check_failure': ('fn check_failure(&self)', '''
        if self.io_failed.load(Ordering::Acquire) {
            if self.closed.load(Ordering::Acquire) {
                Err(StorageError::DatabaseClosed)
            } else {
                Err(StorageError::PreviousIo)
            }
        } else {
            Ok(())
        }
    '''),
    'close': ('fn close(&self)', '''
        self.closed.store(true, Ordering::Release);
        self.io_failed.store(true, Ordering::Release);
        self.file.close()?;
        Ok(())
    '''),
    'write': ('fn write(&self, offset: u64, data:', '''
        self.check_failure()?;
        let result = self.file.write(offset, data);
        if result.is_err() {
            self.io_failed.store(true, Ordering::Release);
        }
        result.map_err(StorageError::from)
    '''),
    'sync': ('fn sync_data(&self)', '''
        self.check_failure()?;
        let result = self.file.sync_data();
        if result.is_err() {
            self.io_failed.store(true, Ordering::Release);
        }
        result.map_err(StorageError::from)
    '''),
    'best_effort': ('fn write_best_effort(&self, offset: u64, data:', '''
        self.check_failure()?;
        self.file.write(offset, data).map_err(StorageError::from)
    '''),
}


@dataclass(frozen=True)
class State:
    failed: bool = False
    closed: bool = False
    effect: int = 0
    calls: tuple = ()


@dataclass(frozen=True)
class Outcome:
    ok: bool
    effect: int


@dataclass(frozen=True)
class Returned:
    state: State
    error: object
    called: bool
    callback_flags: object


def preflight(state, mutation=None):
    if mutation == 'closed_first' and state.closed:
        return 'DatabaseClosed'
    if state.failed:
        return 'DatabaseClosed' if state.closed else 'PreviousIo'
    return None


def step(state, operation, outcome, mutation=None):
    if operation not in OPERATIONS:
        raise ValueError('unsupported operation')
    if operation != 'close' or mutation == 'refuse_reclose':
        error = preflight(state, mutation)
        if error is not None:
            return Returned(state, error, False, None)
    if operation == 'close':
        observed = replace(state, failed=True, closed=True)
        if mutation == 'close_flags_after_error' and not outcome.ok:
            observed = state
    else:
        observed = state
    failed = observed.failed
    if operation in ('write', 'sync') and not outcome.ok:
        failed = mutation != 'skip_normal_latch'
    if operation == 'best_effort' and not outcome.ok and mutation == 'latch_best_effort':
        failed = True
    effect = outcome.effect
    if mutation == 'rollback_error_effect' and not outcome.ok:
        effect = state.effect
    after = replace(observed, failed=failed, effect=effect, calls=state.calls + (operation,))
    return Returned(after, None if outcome.ok else 'BackendIo', True, (observed.failed, observed.closed))


def violations(before, operation, outcome, returned):
    failures = []
    table = {(False, False): None, (False, True): None,
             (True, False): 'PreviousIo', (True, True): 'DatabaseClosed'}
    expected_preflight = None if operation == 'close' else table[(before.failed, before.closed)]
    expected_called = expected_preflight is None
    if returned.called != expected_called:
        failures.append('call_admission')
    if not expected_called:
        if returned.state != before or returned.error != expected_preflight:
            failures.append('preflight_transport')
        return failures
    if returned.error != (None if outcome.ok else 'BackendIo'):
        failures.append('backend_result_transport')
    if returned.state.effect != outcome.effect:
        failures.append('opaque_effect_not_rollback')
    if returned.state.calls != before.calls + (operation,):
        failures.append('exact_callback_count')
    if before.failed and not returned.state.failed:
        failures.append('failed_flag_monotonic')
    if before.closed and not returned.state.closed:
        failures.append('closed_flag_monotonic')
    if operation == 'close':
        if not returned.state.failed or not returned.state.closed:
            failures.append('close_flags_even_on_error')
        if returned.callback_flags != (True, True):
            failures.append('close_flags_before_callback')
    else:
        expected_failed = before.failed or (operation in ('write', 'sync') and not outcome.ok)
        if returned.state.failed != expected_failed or returned.state.closed != before.closed:
            failures.append('selected_latch_rule')
    return failures


def characterize(source, enforce_identity=True):
    if not isinstance(source, str):
        return {'status': 'REFUSAL', 'reason': 'non-text input'}
    if enforce_identity and hashlib.sha256(source.encode()).hexdigest() != NATIVE_SHA256:
        return {'status': 'MISMATCH', 'reason': 'source identity'}
    try:
        implementation, start, end = fragment(source, 'impl CheckedBackend {')
        anchors = []
        for name, (marker, expected) in RULES.items():
            body, body_start, body_end = fragment(implementation, marker)
            if tokens(body) != tokens(expected):
                return {'status': 'MISMATCH', 'target': name}
            anchors.append({'target': name, 'body_tokens': len(tokens(body)),
                            'impl_relative_start': body_start, 'impl_relative_end': body_end})
        return {'status': 'MATCH', 'anchors': anchors,
                'qualification': 'exact selected-body token guard, not Rust parsing or native semantics'}
    except Refusal as error:
        return {'status': 'REFUSAL', 'reason': str(error)}
    except ParseFailure as error:
        return {'status': 'PARSE_FAILURE', 'reason': str(error)}


def mutate_body(source, target, original, replacement):
    implementation, start, end = fragment(source, 'impl CheckedBackend {')
    body, body_start, body_end = fragment(implementation, RULES[target][0])
    if body.count(original) != 1:
        raise AssertionError('mutation context must be unique within target')
    changed = body.replace(original, replacement, 1)
    if source.count(body) != 1:
        raise AssertionError('selected body must be unique in original source')
    return source.replace(body, changed, 1)


def semantic_controls():
    witnesses = {
        'skip_normal_latch': (State(), 'write', Outcome(False, 1)),
        'latch_best_effort': (State(), 'best_effort', Outcome(False, 1)),
        'closed_first': (State(closed=True), 'sync', Outcome(True, 1)),
        'close_flags_after_error': (State(), 'close', Outcome(False, 1)),
        'refuse_reclose': (State(failed=True, closed=True), 'close', Outcome(True, 1)),
        'rollback_error_effect': (State(), 'sync', Outcome(False, 1)),
    }
    result = []
    for mutation, (before, operation, outcome) in witnesses.items():
        negative = step(before, operation, outcome, mutation)
        corrected = step(before, operation, outcome)
        result.append({'mutation': mutation, 'before': asdict(before), 'operation': operation,
                       'outcome': asdict(outcome), 'negative_violations': violations(before, operation, outcome, negative),
                       'corrected_violations': violations(before, operation, outcome, corrected)})
    return result


def source_controls(source):
    changes = (
        ('write', 'result.is_err()', 'result.is_ok()'),
        ('sync', 'result.is_err()', 'result.is_ok()'),
        ('write', 'self.check_failure()?;', ''),
        ('close', 'self.io_failed.store(true, Ordering::Release);', ''),
        ('check_failure', 'Err(StorageError::PreviousIo)', 'Err(StorageError::DatabaseClosed)'),
        ('best_effort', 'self.file.write(offset, data).map_err(StorageError::from)',
         'let result = self.file.write(offset, data); if result.is_err() { self.io_failed.store(true, Ordering::Release); } result.map_err(StorageError::from)'),
    )
    result = []
    for target, original, replacement in changes:
        mutated = mutate_body(source, target, original, replacement)
        result.append({'target': target, 'original': original, 'replacement': replacement,
                       'mutant': characterize(mutated, False), 'corrected': characterize(source, False),
                       'mutant_sha256': hashlib.sha256(mutated.encode()).hexdigest(),
                       'corrected_sha256': hashlib.sha256(source.encode()).hexdigest()})
    return result


def check_histories(maximum_length=3):
    choices = tuple((operation, Outcome(ok, effect))
                    for operation, ok, effect in product(OPERATIONS, (False, True), (0, 1)))
    counts = {'histories': 0, 'steps': 0, 'backend_callbacks': 0, 'preflight_refusals': 0}
    for failed, closed in product((False, True), repeat=2):
        for length in range(maximum_length + 1):
            for history in product(choices, repeat=length):
                state = State(failed=failed, closed=closed)
                counts['histories'] += 1
                for operation, outcome in history:
                    returned = step(state, operation, outcome)
                    errors = violations(state, operation, outcome, returned)
                    if errors:
                        raise AssertionError(errors)
                    counts['steps'] += 1
                    counts['backend_callbacks' if returned.called else 'preflight_refusals'] += 1
                    state = returned.state
    return counts
