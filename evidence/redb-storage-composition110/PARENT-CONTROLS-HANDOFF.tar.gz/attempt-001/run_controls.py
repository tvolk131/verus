import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess


ROOT = Path(__file__).resolve().parent
PARENT = Path('/Users/tommyvolk/.t3/worktrees/verus/t3-60978068')
PYTHON = Path('/Library/Developer/CommandLineTools/Library/Frameworks/Python3.framework/Versions/3.9/bin/python3.9')
PINS = {
    PYTHON: 'bdea59019a38eb6600cc9e71e984a97fedadc406448431281e7657030f54987e',
    Path('/Library/Developer/CommandLineTools/Library/Frameworks/Python3.framework/Versions/3.9/Python3'): '26422f0b21cb1e07236384afa4043c7401d39d09358c91df8bf3f5496f14712f',
    Path('/private/tmp/redb-storage109-independent-controls-vKPHDj8s/source_guards.py'): 'dd998707cfcae813135b49573b2dee3e2c94e7c994303f01e28455e92fd6ee2b',
    Path('/private/tmp/redb-storage109-independent-controls-vKPHDj8s/authenticate.py'): 'ad1c72da4dcd1b1d965d94df3c95738c644f36cf6cd4928d2f34a963ffcd8b23',
}


def digest(filename):
    return hashlib.sha256(filename.read_bytes()).hexdigest()


def authenticate(destination, label):
    records = json.loads((PARENT / 'evidence/redb-storage-composition110/INPUTS.json').read_text())['records']
    result = []
    for record in records:
        filename = Path(record['path'])
        actual = digest(filename)
        assert actual == record['sha256'], str(filename)
        result.append({'path': str(filename), 'sha256': actual})
    for filename, expected in PINS.items():
        actual = digest(filename)
        assert actual == expected, str(filename)
        result.append({'path': str(filename), 'sha256': actual})
    for filename in sorted(ROOT.glob('*.py')):
        result.append({'path': str(filename), 'sha256': digest(filename)})
    free_bytes = shutil.disk_usage('/private/tmp').free
    assert free_bytes > 16 * 1024 ** 3
    snapshot = {'label': label, 'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                'records': result, 'selected_input_count': len(records), 'free_bytes': free_bytes,
                'qualification': 'Selected identities; not exhaustive stdlib/loader closure or atomic bootstrap authentication'}
    (destination / ('authentication-' + label + '.json')).write_text(json.dumps(snapshot, indent=2, sort_keys=True) + '\n')
    return snapshot


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--attempt', required=True)
    arguments = parser.parse_args()
    destination = ROOT / arguments.attempt
    destination.mkdir()
    authenticate(destination, 'entry')
    environment = {'PATH': '/usr/bin:/bin', 'HOME': str(destination / 'home'),
                   'TMPDIR': str(destination / 'tmp'), 'PYTHONDONTWRITEBYTECODE': '1',
                   'PYTHONHASHSEED': '0', 'LC_ALL': 'C'}
    for directory in ('home', 'tmp'):
        (destination / directory).mkdir()
    command = [str(PYTHON), '-B', '-m', 'unittest', '-v', 'test_backend_controls']
    invocation = {'argv': command, 'environment': environment, 'cwd': str(ROOT), 'timeout_seconds': 90}
    (destination / 'invocation.json').write_text(json.dumps(invocation, indent=2, sort_keys=True) + '\n')
    for filename in ROOT.glob('*.py'):
        shutil.copyfile(filename, destination / filename.name)
    with (destination / 'stdout.txt').open('wb') as stdout, (destination / 'stderr.txt').open('wb') as stderr:
        completed = subprocess.run(command, cwd=ROOT, env=environment, stdout=stdout, stderr=stderr, timeout=90)
    (destination / 'status.json').write_text(json.dumps({'returncode': completed.returncode}, indent=2) + '\n')
    authenticate(destination, 'after-tests')
    if completed.returncode != 0:
        raise SystemExit(completed.returncode)
    import backend_controls
    source = backend_controls.NATIVE.read_text()
    products = {'histories.json': backend_controls.check_histories(),
                'semantic-controls.json': backend_controls.semantic_controls(),
                'source-controls.json': backend_controls.source_controls(source),
                'source-anchors.json': backend_controls.characterize(source)}
    for name, value in products.items():
        (destination / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')
    authenticate(destination, 'exit')
    print(json.dumps({'attempt': arguments.attempt, 'tests_passed': 13, **products['histories.json'],
                      'semantic_mutant_corrected_pairs': len(products['semantic-controls.json']),
                      'source_mutant_corrected_pairs': len(products['source-controls.json']),
                      'native_proof': False, 'all18': 'OPEN'}, indent=2))


if __name__ == '__main__':
    main()
