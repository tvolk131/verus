use vstd::prelude::*;

verus! {

pub enum ProjectedError {
    Corrupted(Seq<u8>),
    ValueTooLarge(nat),
    Io(int),
    Unsupported,
    PreviousIo,
    DatabaseClosed,
    LockPoisoned(int),
}

pub enum Operation {
    Write,
    Sync,
    BestEffort,
    Close,
}

pub struct Flags {
    pub io_failed: bool,
    pub closed: bool,
}

pub struct Choice {
    pub operation: Operation,
    pub backend: Result<(), int>,
    pub effect: int,
}

pub struct Event {
    pub operation: Operation,
    pub before: Flags,
    pub after: Flags,
    pub called: bool,
    pub result: Result<(), ProjectedError>,
    pub backend_effect: Option<int>,
}

pub struct History {
    pub end: Flags,
    pub events: Seq<Event>,
}

pub open spec fn clean() -> Flags {
    Flags { io_failed: false, closed: false }
}

pub open spec fn sequential_reachable(flags: Flags) -> bool {
    flags.closed ==> flags.io_failed
}

pub open spec fn guarded(operation: Operation) -> bool {
    operation != Operation::Close
}

pub open spec fn normal(operation: Operation) -> bool {
    operation == Operation::Write || operation == Operation::Sync
}

pub open spec fn preflight(flags: Flags) -> Result<(), ProjectedError> {
    if flags.io_failed {
        if flags.closed { Err(ProjectedError::DatabaseClosed) }
        else { Err(ProjectedError::PreviousIo) }
    } else { Ok(()) }
}

pub open spec fn map_backend(reply: Result<(), int>) -> Result<(), ProjectedError> {
    match reply {
        Ok(()) => Ok(()),
        Err(payload) => Err(ProjectedError::Io(payload)),
    }
}

pub open spec fn step(before: Flags, choice: Choice) -> Event {
    if choice.operation == Operation::Close {
        Event {
            operation: choice.operation,
            before,
            after: Flags { io_failed: true, closed: true },
            called: true,
            result: map_backend(choice.backend),
            backend_effect: Some(choice.effect),
        }
    } else if preflight(before).is_err() {
        Event {
            operation: choice.operation,
            before,
            after: before,
            called: false,
            result: preflight(before),
            backend_effect: None,
        }
    } else {
        Event {
            operation: choice.operation,
            before,
            after: Flags {
                io_failed: before.io_failed || choice.backend.is_err(),
                closed: before.closed,
            },
            called: true,
            result: map_backend(choice.backend),
            backend_effect: Some(choice.effect),
        }
    }
}

pub open spec fn history(before: Flags, choices: Seq<Choice>) -> History
    decreases choices.len(),
{
    if choices.len() == 0 {
        History { end: before, events: Seq::empty() }
    } else {
        let head = step(before, choices[0]);
        let tail = history(head.after, choices.subrange(1, choices.len() as int));
        History { end: tail.end, events: seq![head] + tail.events }
    }
}

pub open spec fn event_law(event: Event) -> bool {
    &&& (event.before.io_failed ==> event.after.io_failed)
    &&& (event.before.closed ==> event.after.closed)
    &&& (sequential_reachable(event.before) ==> sequential_reachable(event.after))
    &&& (guarded(event.operation) && event.before.io_failed ==>
        !event.called && event.after == event.before && event.result == preflight(event.before))
    &&& (event.operation == Operation::Close ==> event.after.io_failed && event.after.closed && event.called)
    &&& (event.called <==> event.backend_effect.is_some())
}

pub proof fn exact_precedence(flags: Flags)
    ensures
        (!flags.io_failed ==> preflight(flags) == Ok::<(), ProjectedError>(())),
        (flags.io_failed && !flags.closed ==> preflight(flags) == Err::<(), ProjectedError>(ProjectedError::PreviousIo)),
        (flags.io_failed && flags.closed ==> preflight(flags) == Err::<(), ProjectedError>(ProjectedError::DatabaseClosed)),
        preflight(Flags { io_failed: false, closed: true }) == Ok::<(), ProjectedError>(()),
{
}

pub proof fn step_contract(before: Flags, choice: Choice)
    ensures
        event_law(step(before, choice)),
        (normal(choice.operation) && !before.io_failed && choice.backend.is_err() ==> step(before, choice).after.io_failed),
        (choice.operation == Operation::BestEffort && !before.io_failed ==> step(before, choice).after == before),
        (step(before, choice).called ==> step(before, choice).result == map_backend(choice.backend)),
        (!step(before, choice).called ==> step(before, choice).backend_effect == None::<int>),
{
}

pub proof fn history_contract(before: Flags, choices: Seq<Choice>)
    ensures
        history(before, choices).events.len() == choices.len(),
        (before.io_failed ==> history(before, choices).end.io_failed),
        (before.closed ==> history(before, choices).end.closed),
        (sequential_reachable(before) ==> sequential_reachable(history(before, choices).end)),
        forall|index: int| 0 <= index < history(before, choices).events.len() ==>
            event_law(#[trigger] history(before, choices).events[index]),
        forall|index: int| 0 <= index < history(before, choices).events.len() && before.io_failed ==>
            (#[trigger] history(before, choices).events[index]).before.io_failed
            && (guarded(history(before, choices).events[index].operation) ==> !history(before, choices).events[index].called),
        forall|index: int| 0 <= index < history(before, choices).events.len() && before.closed ==>
            (#[trigger] history(before, choices).events[index]).before.closed,
    decreases choices.len(),
{
    if choices.len() > 0 {
        let head = step(before, choices[0]);
        let remaining = choices.subrange(1, choices.len() as int);
        step_contract(before, choices[0]);
        history_contract(head.after, remaining);
        let result = history(before, choices);
        assert forall|index: int| 0 <= index < result.events.len() implies
            event_law(#[trigger] result.events[index]) by {
            if index > 0 {
                assert(result.events[index] == history(head.after, remaining).events[index - 1]);
            }
        }
        assert forall|index: int| 0 <= index < result.events.len() && before.io_failed implies
            (#[trigger] result.events[index]).before.io_failed
            && (guarded(result.events[index].operation) ==> !result.events[index].called) by {
            if index > 0 {
                assert(result.events[index] == history(head.after, remaining).events[index - 1]);
            }
        }
        assert forall|index: int| 0 <= index < result.events.len() && before.closed implies
            (#[trigger] result.events[index]).before.closed by {
            if index > 0 {
                assert(result.events[index] == history(head.after, remaining).events[index - 1]);
            }
        }
    }
}

pub proof fn failure_then_arbitrary_suffix(before: Flags, choice: Choice, suffix: Seq<Choice>)
    requires
        choice.operation == Operation::Close || (normal(choice.operation) && !before.io_failed && choice.backend.is_err()),
    ensures
        step(before, choice).after.io_failed,
        history(step(before, choice).after, suffix).end.io_failed,
        forall|index: int| 0 <= index < history(step(before, choice).after, suffix).events.len() ==>
            guarded((#[trigger] history(step(before, choice).after, suffix).events[index]).operation) ==>
                !history(step(before, choice).after, suffix).events[index].called,
{
    step_contract(before, choice);
    history_contract(step(before, choice).after, suffix);
}

pub proof fn error_payload_transport(before: Flags, operation: Operation, payload: int, effect: int)
    requires operation == Operation::Close || !before.io_failed,
    ensures
        step(before, Choice { operation, backend: Err(payload), effect }).result == Err::<(), ProjectedError>(ProjectedError::Io(payload)),
        step(before, Choice { operation, backend: Err(payload), effect }).backend_effect == Some(effect),
{
}

pub open spec fn close_stores(before: Flags) -> Seq<Flags> {
    seq![before, Flags { io_failed: before.io_failed, closed: true }, Flags { io_failed: true, closed: true }]
}

pub proof fn close_store_order(before: Flags, reply: Result<(), int>, effect: int)
    ensures
        close_stores(before).len() == 3,
        close_stores(before)[1].closed,
        close_stores(before)[1].io_failed == before.io_failed,
        close_stores(before)[2] == step(before, Choice { operation: Operation::Close, backend: reply, effect }).after,
        step(before, Choice { operation: Operation::Close, backend: reply, effect }).called,
        step(before, Choice { operation: Operation::Close, backend: reply, effect }).result == map_backend(reply),
{
}

pub proof fn successful_guarded_prefix(before: Flags, choices: Seq<Choice>)
    requires
        !before.io_failed,
        forall|index: int| 0 <= index < choices.len() ==>
            guarded((#[trigger] choices[index]).operation) && choices[index].backend.is_ok(),
    ensures
        history(before, choices).end == before,
        history(before, choices).events.len() == choices.len(),
        forall|index: int| 0 <= index < choices.len() ==>
            (#[trigger] history(before, choices).events[index]).called
            && history(before, choices).events[index].result.is_ok()
            && history(before, choices).events[index].backend_effect == Some(choices[index].effect),
    decreases choices.len(),
{
    if choices.len() > 0 {
        let remaining = choices.subrange(1, choices.len() as int);
        assert forall|index: int| 0 <= index < remaining.len() implies
            guarded((#[trigger] remaining[index]).operation) && remaining[index].backend.is_ok() by {
            assert(remaining[index] == choices[index + 1]);
        }
        successful_guarded_prefix(before, remaining);
        assert(step(before, choices[0]).after == before);
        assert forall|index: int| 0 <= index < choices.len() implies
            (#[trigger] history(before, choices).events[index]).called
            && history(before, choices).events[index].result.is_ok()
            && history(before, choices).events[index].backend_effect == Some(choices[index].effect) by {
            if index > 0 {
                assert(history(before, choices).events[index] == history(before, remaining).events[index - 1]);
            }
        }
    }
}

pub proof fn successful_prefix_error_progress(before: Flags, prefix: Seq<Choice>, failure: Choice, suffix: Seq<Choice>)
    requires
        !before.io_failed,
        forall|index: int| 0 <= index < prefix.len() ==>
            guarded((#[trigger] prefix[index]).operation) && prefix[index].backend.is_ok(),
        normal(failure.operation),
        failure.backend.is_err(),
    ensures
        history(before, prefix).events.len() == prefix.len(),
        history(before, prefix).end == before,
        step(history(before, prefix).end, failure).called,
        step(history(before, prefix).end, failure).backend_effect == Some(failure.effect),
        step(history(before, prefix).end, failure).result.is_err(),
        history(step(history(before, prefix).end, failure).after, suffix).end.io_failed,
        forall|index: int| 0 <= index < history(step(history(before, prefix).end, failure).after, suffix).events.len() ==>
            guarded((#[trigger] history(step(history(before, prefix).end, failure).after, suffix).events[index]).operation) ==>
                !history(step(history(before, prefix).end, failure).after, suffix).events[index].called,
{
    successful_guarded_prefix(before, prefix);
    failure_then_arbitrary_suffix(before, failure, suffix);
}

pub struct CallbackChoice {
    pub reply: Result<(), ProjectedError>,
    pub effect: int,
}

pub struct Continuation {
    pub published_marker: bool,
    pub result: Result<(), ProjectedError>,
    pub successful: nat,
    pub calls: nat,
    pub effects: Seq<int>,
}

pub open spec fn continuation(published_marker: bool, callbacks: Seq<CallbackChoice>) -> Continuation
    decreases callbacks.len(),
{
    if callbacks.len() == 0 {
        Continuation { published_marker, result: Ok(()), successful: 0, calls: 0, effects: Seq::empty() }
    } else if callbacks[0].reply.is_err() {
        Continuation { published_marker, result: callbacks[0].reply, successful: 0, calls: 1, effects: seq![callbacks[0].effect] }
    } else {
        let tail = continuation(published_marker, callbacks.subrange(1, callbacks.len() as int));
        Continuation {
            published_marker,
            result: tail.result,
            successful: 1 + tail.successful,
            calls: 1 + tail.calls,
            effects: seq![callbacks[0].effect] + tail.effects,
        }
    }
}

pub proof fn continuation_contract(published_marker: bool, callbacks: Seq<CallbackChoice>)
    ensures
        continuation(published_marker, callbacks).published_marker == published_marker,
        continuation(published_marker, callbacks).calls <= callbacks.len(),
        continuation(published_marker, callbacks).effects.len() == continuation(published_marker, callbacks).calls,
        continuation(published_marker, callbacks).result.is_ok() ==>
            continuation(published_marker, callbacks).successful == callbacks.len()
            && continuation(published_marker, callbacks).calls == callbacks.len(),
        continuation(published_marker, callbacks).result.is_err() ==>
            continuation(published_marker, callbacks).calls == continuation(published_marker, callbacks).successful + 1,
    decreases callbacks.len(),
{
    if callbacks.len() > 0 && callbacks[0].reply.is_ok() {
        continuation_contract(published_marker, callbacks.subrange(1, callbacks.len() as int));
    }
}

pub proof fn callback_error_transport(error: ProjectedError, effect: int, suffix: Seq<CallbackChoice>)
    ensures
        continuation(true, seq![CallbackChoice { reply: Err(error), effect }] + suffix).result == Err::<(), ProjectedError>(error),
        continuation(true, seq![CallbackChoice { reply: Err(error), effect }] + suffix).published_marker,
        continuation(true, seq![CallbackChoice { reply: Err(error), effect }] + suffix).calls == 1,
        continuation(true, seq![CallbackChoice { reply: Err(error), effect }] + suffix).successful == 0,
        continuation(true, seq![CallbackChoice { reply: Err(error), effect }] + suffix).effects == seq![effect],
{
}

pub proof fn first_error_order(published_marker: bool, callbacks: Seq<CallbackChoice>, index: int)
    requires
        0 <= index < callbacks.len(),
        callbacks[index].reply.is_err(),
        forall|earlier: int| 0 <= earlier < index ==> (#[trigger] callbacks[earlier]).reply.is_ok(),
    ensures
        continuation(published_marker, callbacks).result == callbacks[index].reply,
        continuation(published_marker, callbacks).successful == index,
        continuation(published_marker, callbacks).calls == index + 1,
        continuation(published_marker, callbacks).effects == callbacks.subrange(0, index + 1).map_values(|callback: CallbackChoice| callback.effect),
    decreases index,
{
    if index > 0 {
        let remaining = callbacks.subrange(1, callbacks.len() as int);
        assert forall|earlier: int| 0 <= earlier < index - 1 implies
            (#[trigger] remaining[earlier]).reply.is_ok() by {
            assert(remaining[earlier] == callbacks[earlier + 1]);
        }
        first_error_order(published_marker, remaining, index - 1);
        assert(callbacks.subrange(0, index + 1).map_values(|callback: CallbackChoice| callback.effect)
            =~= seq![callbacks[0].effect] + remaining.subrange(0, index).map_values(|callback: CallbackChoice| callback.effect));
    } else {
        assert(callbacks.subrange(0, 1).map_values(|callback: CallbackChoice| callback.effect) =~= seq![callbacks[0].effect]);
    }
}

pub proof fn nonvacuous_witnesses()
    ensures
        !step(clean(), Choice { operation: Operation::BestEffort, backend: Err(17), effect: 91 }).after.io_failed,
        step(clean(), Choice { operation: Operation::Write, backend: Err(17), effect: 91 }).after.io_failed,
        step(clean(), Choice { operation: Operation::Sync, backend: Err(18), effect: 92 }).after.io_failed,
        step(clean(), Choice { operation: Operation::Close, backend: Err(19), effect: 93 }).after.closed,
        history(clean(), seq![
            Choice { operation: Operation::Write, backend: Ok(()), effect: 1 },
            Choice { operation: Operation::Sync, backend: Ok(()), effect: 2 },
        ]).events.len() == 2,
        !history(clean(), seq![
            Choice { operation: Operation::Write, backend: Ok(()), effect: 1 },
            Choice { operation: Operation::Sync, backend: Ok(()), effect: 2 },
        ]).end.io_failed,
        continuation(true, seq![
            CallbackChoice { reply: Ok(()), effect: 37 },
            CallbackChoice { reply: Err(ProjectedError::Corrupted(seq![4u8])), effect: 88 },
            CallbackChoice { reply: Ok(()), effect: 99 },
        ]).successful == 1,
        continuation(true, seq![
            CallbackChoice { reply: Ok(()), effect: 37 },
            CallbackChoice { reply: Err(ProjectedError::Corrupted(seq![4u8])), effect: 88 },
            CallbackChoice { reply: Ok(()), effect: 99 },
        ]).effects == seq![37int, 88int],
{
    reveal_with_fuel(history, 4);
    reveal_with_fuel(continuation, 4);
    assert(seq![37int, 88int] =~= seq![37int] + seq![88int]);
}

pub open spec fn incorrect_closed_first(flags: Flags) -> Result<(), ProjectedError> {
    if flags.closed { Err(ProjectedError::DatabaseClosed) }
    else if flags.io_failed { Err(ProjectedError::PreviousIo) }
    else { Ok(()) }
}

pub proof fn source_negative_counterparts(payload: int, effect: int)
    ensures
        incorrect_closed_first(Flags { io_failed: false, closed: true })
            != preflight(Flags { io_failed: false, closed: true }),
        step(clean(), Choice { operation: Operation::BestEffort, backend: Err(payload), effect }).after
            != step(clean(), Choice { operation: Operation::Write, backend: Err(payload), effect }).after,
        !step(Flags { io_failed: true, closed: true }, Choice { operation: Operation::Write, backend: Ok(()), effect }).called,
        step(Flags { io_failed: true, closed: true }, Choice { operation: Operation::Close, backend: Ok(()), effect }).called,
{
}

}
