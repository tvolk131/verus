import importlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

import review

ROOT = review.ROOT
CONTROLS = Path('/private/tmp/redb-composition110-20261108T043326Z/controls')
HELPERS = Path('/private/tmp/redb-storage109-independent-controls-vKPHDj8s')

def original_attempts():
    summary = []
    raw_directory = ROOT / 'original-raw'
    raw_directory.mkdir(exist_ok=True)
    for lane, parent, pattern in [('A', review.LANEA, 'check-*'), ('B', review.LANEB, 'attempt-*')]:
        for directory in sorted(parent.glob(pattern)):
            if not directory.is_dir():
                continue
            destination = raw_directory / (lane + '-' + directory.name)
            destination.mkdir(exist_ok=True)
            selected = {}
            for filename in ['invocation.json', 'result.json', 'receipt.json', 'scope-summary.json', 'stdout.txt', 'stderr.txt', 'charged.json']:
                path = directory / filename
                if path.is_file():
                    shutil.copyfile(path, destination / filename)
                    selected[filename] = review.record(path)
            invocation = json.loads((directory / 'invocation.json').read_text())
            stdout = (directory / 'stdout.txt').read_text()
            stderr = (directory / 'stderr.txt').read_text()
            try:
                parsed = json.loads(stdout)
            except ValueError:
                parsed = {'raw_stdout': stdout}
            result_name = 'result.json' if (directory / 'result.json').is_file() else 'receipt.json'
            result = json.loads((directory / result_name).read_text())
            summary.append({'lane': lane, 'directory': str(directory), 'invocation': invocation, 'result': result, 'scope': parsed, 'stderr': stderr, 'raw_files': selected})
    review.write_json(ROOT / 'original-attempts-audit.json', summary)
    accounting = json.loads((review.LANEA / 'ACCOUNTING.json').read_text())
    results = json.loads((review.LANEB / 'RESULTS.json').read_text())
    review.write_json(ROOT / 'original-accounting-audit.json', {'A': accounting, 'B': results})
    for item in summary:
        print(json.dumps({'lane': item['lane'], 'attempt': Path(item['directory']).name, 'result': item['result'], 'verification': item['scope'].get('verification-results'), 'stderr': item['stderr']}), flush=True)

def helper_identity(stage):
    paths = set(review.supplemental_paths())
    paths.update(str(path) for path in (ROOT / 'controls').glob('*.py'))
    paths.update(str(HELPERS / filename) for filename in ['source_guards.py', 'authenticate.py'])
    paths.update(['/private/tmp/redb-review110-LwF1feEi/audit.py', '/bin/cat', '/bin/ls', '/usr/bin/find', '/usr/bin/mktemp', '/usr/bin/sed', '/usr/bin/git', '/Users/tommyvolk/.codex/packages/standalone/releases/0.166.0-aarch64-apple-darwin/codex-path/rg', '/Users/tommyvolk/.t3/userdata/providers/codex/codex_095eca24-b4b7-4a15-8759-9d8964dbd03a/shadow/tmp/arg0-macos/codex-arg011pOCK/apply_patch', '/Library/Developer/CommandLineTools/usr/bin/otool'])
    result = {'utc': review.utc(), 'stage': stage, 'records': [review.record(path) for path in sorted(paths) if Path(path).is_file()], 'qualification': 'Direct and discovered transitive Python/edit/read helpers; bootstrap reads precede this sample; not exhaustive OS shared-cache identity.'}
    review.write_json(ROOT / ('helpers-' + stage + '.json'), result)
    return result

def replay_controls():
    directory = ROOT / 'controls'
    directory.mkdir(exist_ok=True)
    for filename in ['backend_controls.py', 'test_backend_controls.py', 'run_controls.py']:
        shutil.copyfile(CONTROLS / filename, directory / filename)
    entry = helper_identity('entry')
    sys.path.insert(0, str(directory))
    controls = importlib.import_module('backend_controls')
    helper_identity('loaded-preexecution')
    argv = [sys.executable, '-B', str(directory / 'run_controls.py'), '--attempt', 'fresh-review']
    environment = {'PATH': '/usr/bin:/bin', 'HOME': str(directory / 'home'), 'TMPDIR': str(directory / 'tmp'), 'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONHASHSEED': '0', 'LC_ALL': 'C'}
    for name in ['home', 'tmp']:
        (directory / name).mkdir(exist_ok=True)
    review.write_json(directory / 'replay-invocation.json', {'argv': argv, 'environment': environment, 'cwd': str(directory), 'timeout_seconds': 90, 'utc': review.utc(), 'not_verifier_application': True})
    review.authenticate('controls-preexecution')
    with (directory / 'replay-stdout.txt').open('wb') as stdout, (directory / 'replay-stderr.txt').open('wb') as stderr:
        process = subprocess.run(argv, cwd=directory, env=environment, stdout=stdout, stderr=stderr, timeout=90)
    review.write_json(directory / 'replay-result.json', {'utc': review.utc(), 'returncode': process.returncode})
    review.authenticate('controls-exit')
    exit_identity = helper_identity('exit')
    baseline = {item['path']: item['sha256'] for item in entry['records']}
    drift = [item for item in exit_identity['records'] if item['path'] in baseline and item['sha256'] != baseline[item['path']]]
    review.write_json(directory / 'helper-comparison.json', {'drift': drift})
    print((directory / 'replay-stdout.txt').read_text(), flush=True)
    print((directory / 'replay-stderr.txt').read_text(), flush=True)
    if process.returncode or drift:
        raise RuntimeError('finite replay failed')
    print(json.dumps({'loaded_control_native': str(controls.NATIVE), 'helper_drift': len(drift)}), flush=True)

if __name__ == '__main__':
    if sys.argv[1] == 'originals':
        original_attempts()
    elif sys.argv[1] == 'controls':
        replay_controls()
    elif sys.argv[1] == 'helpers':
        helper_identity('final')
