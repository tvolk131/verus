import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import tarfile
import time

ROOT = Path('/private/tmp/redb-review110-LwF1feEi')
PARENT = Path('/Users/tommyvolk/.t3/worktrees/verus/t3-60978068')
EVIDENCE = PARENT / 'evidence/redb-storage-composition110'
LANEA = Path('/private/tmp/redb-storage110-laneA-LBwsoPMW')
LANEB = Path('/private/tmp/redb-backend110-B-cCGFf2VR')
FIRST = '2026-11-08T04:57:56+00:00'
DEADLINE = datetime.datetime.fromisoformat('2026-11-08T05:12:56+00:00')
FROZEN = json.loads((EVIDENCE / 'INPUTS.json').read_text())['records']
RUNTIME = Path('/private/tmp/verus-crash-consistency94-20261105/native-leaf-lookup-007/midpoint-runtime-proposal/runtime')
TOOLCHAIN = Path('/Users/tommyvolk/.rustup/toolchains/1.99.1-aarch64-apple-darwin')

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def digest(path):
    hasher = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            hasher.update(block)
    return hasher.hexdigest()

def record(path):
    path = Path(path)
    return {'path': str(path), 'realpath': str(path.resolve()), 'bytes': path.stat().st_size, 'sha256': digest(path)}

def write_json(path, value):
    Path(path).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

def resources(stage):
    observation = {'utc': utc(), 'stage': stage, 'scratch_bytes': sum(path.stat().st_size for path in ROOT.rglob('*') if path.is_file()), 'free_bytes': shutil.disk_usage(ROOT).free}
    with (ROOT / 'resources.jsonl').open('a') as stream:
        stream.write(json.dumps(observation, sort_keys=True) + '\n')
    if observation['scratch_bytes'] > 512 * 1024 ** 2 or observation['free_bytes'] <= 16 * 1024 ** 3:
        raise RuntimeError('resource limit')
    if datetime.datetime.now(datetime.timezone.utc) >= DEADLINE:
        raise RuntimeError('deadline')
    return observation

def supplemental_paths():
    paths = {str(Path(__file__)), sys.executable, '/Library/Developer/CommandLineTools/Library/Frameworks/Python3.framework/Versions/3.9/Python3', '/bin/zsh', '/bin/date', '/bin/df', '/usr/bin/otool', '/usr/bin/shasum', '/usr/bin/perl', '/Users/tommyvolk/.local/bin/codex'}
    paths.update(str(path) for path in RUNTIME.iterdir() if path.is_file())
    paths.update(str(path) for path in TOOLCHAIN.glob('lib/*.dylib'))
    paths.update(str(path) for path in TOOLCHAIN.glob('lib/rustlib/aarch64-apple-darwin/lib/*.dylib'))
    for module in list(sys.modules.values()):
        filename = getattr(module, '__file__', None)
        if filename and Path(filename).is_file():
            paths.add(filename)
    return sorted(path for path in paths if Path(path).is_file())

def authenticate(stage):
    started = utc()
    records = []
    mismatches = []
    for expected in FROZEN:
        actual = record(expected['path']) if Path(expected['path']).is_file() else {'path': expected['path'], 'sha256': None}
        actual['expected'] = expected['sha256']
        records.append(actual)
        if actual['sha256'] != expected['sha256']:
            mismatches.append(actual)
    supplement = [record(path) for path in supplemental_paths()]
    entry_path = ROOT / 'authentication-entry.json'
    drift = []
    if entry_path.exists():
        initial = {item['path']: item['sha256'] for item in json.loads(entry_path.read_text())['supplemental']}
        drift = [item for item in supplement if item['path'] in initial and item['sha256'] != initial[item['path']]]
    result = {'stage': stage, 'started': started, 'finished': utc(), 'frozen_count': len(records), 'records': records, 'mismatches': mismatches, 'supplemental': supplement, 'supplemental_drift': drift, 'bootstrap_qualification': 'Sampled integrity, not an atomic snapshot or compiler/source proof. Python imports and initial shell preceded closure enumeration. OS shared-cache dependencies may not be standalone hashable files.'}
    write_json(ROOT / ('authentication-' + stage + '.json'), result)
    if mismatches or drift:
        raise RuntimeError('authentication mismatch')
    return {'frozen_count': len(records), 'supplemental_count': len(supplement), 'mismatches': len(mismatches), 'drift': len(drift)}

def candidates():
    results = []
    checks = [(LANEA, 'files', 'd6e67e8e6d17d6b2bc90de1997c3c3cc022de226e81a700b812ab17c556e005b', '709f38fc792ba8c8bcca38b9bd02ed42ec978f5ce68300e5cb2a84d16dbb04fd'), (LANEB, 'records', '39eae7981a7adfc7204f0d4cc9e6a25dc7b52d0603fef39a47c7e4534030f6c3', '2a3b1a4ccbb6a6d5ba550da5b02c58c41f9224c7f245a99fe6cff4f226c367c6')]
    for directory, key, manifest_hash, seal_hash in checks:
        manifest = directory / 'MANIFEST.json'
        seal = directory / 'SEAL.json'
        failures = []
        payloads = []
        for expected in json.loads(manifest.read_text())[key]:
            actual = record(directory / expected['path'])
            actual['relative_path'] = expected['path']
            actual['expected'] = expected['sha256']
            payloads.append(actual)
            if actual['sha256'] != expected['sha256'] or actual['bytes'] != expected['bytes']:
                failures.append(actual)
        results.append({'root': str(directory), 'manifest': record(manifest), 'manifest_matches': digest(manifest) == manifest_hash, 'seal': record(seal), 'seal_matches': digest(seal) == seal_hash, 'payloads': payloads, 'failures': failures})
    archives = []
    expected_archives = [('COMPOSITION-CANDIDATE-HANDOFF.tar.gz', 'b81913bc7059a117e0ce3bc0b33ea435a547a157ec0cdb07707c0587ee7f3687', LANEA), ('BACKEND-CANDIDATE-HANDOFF.tar.gz', '27ef39d84b7a5a2bfb1ab5bdf2eb31de14e75822538067bb3a98ee4aecbfb7d3', LANEB), ('PARENT-CONTROLS-HANDOFF.tar.gz', 'c56004723f345e7aeddc49aad929a2a694f98836916ae027de671c17add5737b', None)]
    for name, expected_hash, directory in expected_archives:
        archive = EVIDENCE / name
        members = []
        with tarfile.open(archive, 'r:gz') as stream:
            for member in stream:
                if member.isfile():
                    payload = stream.extractfile(member).read()
                    member_record = {'name': member.name, 'bytes': len(payload), 'sha256': hashlib.sha256(payload).hexdigest()}
                    if directory:
                        equivalent = directory / member.name
                        member_record['candidate_match'] = equivalent.is_file() and digest(equivalent) == member_record['sha256']
                    members.append(member_record)
        archives.append({'archive': record(archive), 'matches': digest(archive) == expected_hash, 'members': members})
    write_json(ROOT / 'candidate-authentication.json', {'utc': utc(), 'candidates': results, 'archives': archives})
    for result in results:
        if result['failures'] or not result['manifest_matches'] or not result['seal_matches']:
            raise RuntimeError('candidate mismatch')
    if not all(item['matches'] for item in archives):
        raise RuntimeError('archive mismatch')

def run_check(number, label, template_directory, filename):
    resources('before-' + label)
    if number > 6 or (ROOT / ('charge-%02d.json' % number)).exists():
        raise RuntimeError('application accounting')
    write_json(ROOT / ('charge-%02d.json' % number), {'number': number, 'label': label, 'charged': True, 'utc': utc(), 'includes_setup_and_launch_failures': True})
    directory = ROOT / ('check-%02d-%s' % (number, label))
    directory.mkdir()
    template = json.loads((template_directory / 'invocation.json').read_text())
    source = directory / filename
    shutil.copyfile(template_directory / filename, source)
    if filename == 'composition110.rs':
        for library in ['buffered_flush109.rs', 'ack_cfg.rs']:
            shutil.copyfile(template_directory / library, directory / library)
    environment = {key: value.replace(str(template_directory), str(directory)) for key, value in template['environment'].items()}
    for value in environment.values():
        if value.startswith(str(directory)) and ':' not in value:
            Path(value).mkdir(parents=True, exist_ok=True)
    export = directory / filename.replace('.rs', '.vir')
    argv = [value.replace(str(template_directory), str(directory)) for value in template['argv']]
    invocation = {'number': number, 'label': label, 'argv': argv, 'environment': environment, 'cwd': str(directory), 'requested_export': str(export), 'fresh_export_absent': not export.exists(), 'source': record(source), 'libraries': [record(directory / library) for library in ['buffered_flush109.rs', 'ack_cfg.rs']] if filename == 'composition110.rs' else [], 'timeout_seconds': 90, 'utc': utc()}
    write_json(directory / 'invocation.json', invocation)
    authenticate('preexecution-%02d' % number)
    resources('preexecution-' + label)
    start = time.monotonic()
    status = None
    timed_out = False
    launch_error = None
    with (directory / 'stdout.txt').open('wb') as stdout, (directory / 'stderr.txt').open('wb') as stderr:
        try:
            process = subprocess.Popen(argv, cwd=directory, env=environment, stdout=stdout, stderr=stderr, start_new_session=True)
            remaining = max(0.1, (DEADLINE - datetime.datetime.now(datetime.timezone.utc)).total_seconds() - 20)
            try:
                status = process.wait(timeout=min(90, remaining))
            except subprocess.TimeoutExpired:
                timed_out = True
                os.killpg(process.pid, signal.SIGKILL)
                status = process.wait()
        except OSError as error:
            launch_error = repr(error)
    result = {'utc': utc(), 'number': number, 'label': label, 'status': status, 'timed_out': timed_out, 'launch_error': launch_error, 'elapsed_seconds': time.monotonic() - start, 'exact_export': str(export), 'export_present': export.is_file(), 'export': record(export) if export.is_file() else None}
    write_json(directory / 'result.json', result)
    try:
        parsed = json.loads((directory / 'stdout.txt').read_text())
    except ValueError:
        parsed = {'raw_stdout_not_json': True}
    write_json(directory / 'scope.json', parsed)
    authenticate('exit-%02d' % number)
    resources('after-' + label)
    print(json.dumps({'result': result, 'verification_results': parsed.get('verification-results', parsed)}), flush=True)

def main():
    if sys.argv[1] == 'entry':
        resources('entry')
        print(json.dumps(authenticate('entry')), flush=True)
        candidates()
        print('candidate authentication complete', flush=True)
    elif sys.argv[1] == 'checks':
        schedule = [(1, 'A-positive', LANEA / 'check-05-full-positive', 'composition110.rs'), (2, 'A-second-flush-bypass', LANEA / 'check-06-negative-bypass-second', 'composition110.rs'), (3, 'A-restored', LANEA / 'check-08-restored-full-positive', 'composition110.rs'), (4, 'B-extended-positive', LANEB / 'attempt-07', 'backend_control110.rs'), (5, 'B-best-effort-latch', LANEB / 'attempt-08', 'backend_control110.rs'), (6, 'B-restored', LANEB / 'attempt-10', 'backend_control110.rs')]
        for number, label, template_directory, filename in schedule:
            run_check(number, label, template_directory, filename)
    elif sys.argv[1] == 'exit':
        print(json.dumps(authenticate('final-exit')), flush=True)
        candidates()
        resources('final-exit')

if __name__ == '__main__':
    main()
