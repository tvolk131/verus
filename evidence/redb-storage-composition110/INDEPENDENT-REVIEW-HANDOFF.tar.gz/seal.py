import difflib
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tarfile

import review

ROOT = review.ROOT
EXCLUDED = {'MANIFEST.json', 'SEAL.json', 'HANDOFF.json', 'handoff.tar.gz'}

def prepare():
    records = json.loads((review.LANEB / 'native-preservation.json').read_text())['fragments']
    probe = (review.LANEB / 'native_probe.rs').read_bytes()
    corrected = []
    for expected in records:
        lines = Path(expected['native_path']).read_bytes().splitlines(keepends=True)
        whole_lines = b''.join(lines[expected['start_line'] - 1:expected['end_line']])
        fragment = whole_lines.rstrip(b'\n').lstrip(b' ')
        corrected.append({'path': expected['native_path'], 'start_line': expected['start_line'], 'end_line': expected['end_line'], 'expected_sha256': expected['exact_utf8_sha256'], 'fragment_sha256': hashlib.sha256(fragment).hexdigest(), 'hash_matches': hashlib.sha256(fragment).hexdigest() == expected['exact_utf8_sha256'], 'exact_fragment_in_probe': fragment in probe, 'qualification': 'Native contiguous substring: first marker begins after its indentation; trailing line ending is excluded. The earlier whole-line audit tested a different byte range.'})
    review.write_json(ROOT / 'native-exact-fragment-audit.json', corrected)
    assert all(item['hash_matches'] and item['exact_fragment_in_probe'] for item in corrected)
    documents = [(review.EVIDENCE / name) for name in ['PLAN.md', 'INPUTS.json', 'AUTHORIZATION.json', 'CONTINUATION-AUTHORIZATION.md', 'POST-PUBLICATION-CUTS.md', 'POST-PUBLICATION-SOURCE-OBSERVATIONS.json', 'NATIVE-BINDING-FRONTIER.md', 'NATIVE-BINDING-FRONTIER.json', 'PARENT-CONTROLS-REPORT.md', 'PARENT-CONTROLS-RESULTS.json', 'PARENT-CONTROLS-SEMANTIC.json', 'PARENT-CONTROLS-HISTORIES.json']]
    documents.extend(review.LANEA / name for name in ['REPORT.md', 'ACCOUNTING.json', 'CUT-LEDGER.json'])
    documents.extend(review.LANEB / name for name in ['REPORT.md', 'PROJECTION-AUDIT.md', 'native-preservation.json', 'BOOTSTRAP-LIMITS.md', 'RESULTS.json'])
    review.write_json(ROOT / 'reviewed-documents.json', [review.record(path) for path in documents])
    for name in ['NATIVE-BINDING-FRONTIER.md', 'NATIVE-BINDING-FRONTIER.json', 'POST-PUBLICATION-CUTS.md', 'POST-PUBLICATION-SOURCE-OBSERVATIONS.json']:
        shutil.copyfile(review.EVIDENCE / name, ROOT / name)
    assert review.digest(ROOT / 'NATIVE-BINDING-FRONTIER.json') == '001e55a60ed438c89112cc3e2e87b8029ba937a46e22170c4538032394b8397f'
    checks = []
    for directory in sorted(ROOT.glob('check-*')):
        invocation = json.loads((directory / 'invocation.json').read_text())
        result = json.loads((directory / 'result.json').read_text())
        scope = json.loads((directory / 'scope.json').read_text())
        checks.append({'directory': str(directory), 'invocation': invocation, 'result': result, 'verification': scope['verification-results'], 'raw_stdout': review.record(directory / 'stdout.txt'), 'raw_stderr': review.record(directory / 'stderr.txt')})
    assert len(checks) == 6
    assert all(item['invocation']['fresh_export_absent'] for item in checks)
    assert [item['result']['status'] for item in checks] == [0, 1, 0, 0, 1, 0]
    assert [item['result']['export_present'] for item in checks] == [True, False, True, True, False, True]
    restoration = {'A': checks[0]['invocation']['source']['sha256'] == checks[2]['invocation']['source']['sha256'], 'B': checks[3]['invocation']['source']['sha256'] == checks[5]['invocation']['source']['sha256']}
    assert all(restoration.values())
    differences = []
    for prefix, positive, negative, filename in [('A', checks[0], checks[1], 'composition110.rs'), ('B', checks[3], checks[4], 'backend_control110.rs')]:
        positive_path = Path(positive['directory']) / filename
        negative_path = Path(negative['directory']) / filename
        differences.extend(difflib.unified_diff(positive_path.read_text().splitlines(keepends=True), negative_path.read_text().splitlines(keepends=True), fromfile=prefix + '-positive/' + filename, tofile=prefix + '-semantic-mutant/' + filename))
    (ROOT / 'semantic-mutation-diffs.patch').write_text(''.join(differences))
    review.write_json(ROOT / 'RESULTS.json', {'utc': review.utc(), 'checks': checks, 'restoration_byte_identity': restoration, 'native_original_bodies_verified': 0, 'model_correctness_defects_identified': 0, 'all18': 'OPEN', 'acceptance': False, 'integration': False, 'native_adapter_R': 'OPEN', 'native_path': 'FAILED', 'git_continuity': 'UNAVAILABLE', 'compiler_source_correspondence': 'UNESTABLISHED'})
    tools = [review.RUNTIME / name for name in ['verus', 'rust_verify', 'z3']]
    tools.extend([Path(sys.executable), Path('/Library/Developer/CommandLineTools/Library/Frameworks/Python3.framework/Versions/3.9/Python3')])
    tools.extend(review.TOOLCHAIN.glob('lib/*.dylib'))
    argv = ['/usr/bin/otool', '-L'] + [str(path) for path in tools]
    environment = {'PATH': '/usr/bin:/bin', 'LC_ALL': 'C'}
    tool_entry = [review.record(path) for path in tools]
    with (ROOT / 'otool-stdout.txt').open('wb') as stdout, (ROOT / 'otool-stderr.txt').open('wb') as stderr:
        completed = subprocess.run(argv, cwd=ROOT, env=environment, stdout=stdout, stderr=stderr, timeout=20)
    tool_exit = [review.record(path) for path in tools]
    assert tool_entry == tool_exit
    review.write_json(ROOT / 'tool-closure.json', {'argv': argv, 'environment': environment, 'cwd': str(ROOT), 'status': completed.returncode, 'entry': tool_entry, 'exit': tool_exit, 'otool': review.record('/usr/bin/otool'), 'qualification': 'Read-only Mach-O dependency declarations, not an executed call-resolution trace; system shared-cache dependencies are not all standalone hashable files.'})
    review.resources('prepared-before-final-authentication')
    print(json.dumps({'checks': len(checks), 'restoration': restoration, 'native_fragments_matching': len(corrected), 'utc': review.utc()}), flush=True)

def seal():
    sample = review.resources('preseal-final-payload-sample')
    charges = sorted(ROOT.glob('charge-*.json'))
    assert len(charges) == 6
    from datetime import datetime, timezone
    elapsed = (datetime.now(timezone.utc) - datetime.fromisoformat(review.FIRST)).total_seconds()
    replay = json.loads((ROOT / 'controls/fresh-review/histories.json').read_text())
    accounting = {'utc': review.utc(), 'first_observation_utc': review.FIRST, 'own_deadline_utc': review.DEADLINE.isoformat(), 'absolute_handoff_cap_utc': '2026-11-08T05:14:00+00:00', 'elapsed_seconds_at_preseal': elapsed, 'applications_charged': 6, 'application_cap': 6, 'setup_launch_failures': 0, 'application_timeout_seconds': 90, 'worker_count': 1, 'subdelegates': 0, 'native_probe_reruns': 0, 'native_applications': 0, 'builds': 0, 'network': 0, 'git_writes': 0, 'parent_candidate_frozen_edits': 0, 'scratch_cap_bytes': 512 * 1024 ** 2, 'free_floor_strictly_greater_than_bytes': 16 * 1024 ** 3, 'preseal_sample': sample, 'finite_controls': replay, 'new_trust_adoptions': 0, 'all18': 'OPEN', 'acceptance': False, 'source_restoration_is_not_export_hash_equality': True, 'bootstrap_provenance_qualification': 'Sampled selected/discovered identities; not retroactive first-use or exhaustive dyld/shared-cache provenance.'}
    review.write_json(ROOT / 'ACCOUNTING.json', accounting)
    payloads = []
    for path in sorted(ROOT.rglob('*')):
        if path.is_file() and path.relative_to(ROOT).as_posix() not in EXCLUDED:
            item = review.record(path)
            item['path'] = path.relative_to(ROOT).as_posix()
            item.pop('realpath')
            payloads.append(item)
    review.write_json(ROOT / 'MANIFEST.json', {'utc': review.utc(), 'files': payloads, 'exclusions': sorted(EXCLUDED), 'qualification': 'Payload manifest excludes self, root seal, external handoff and compressed archive to avoid circular hashes.'})
    review.write_json(ROOT / 'SEAL.json', {'utc': review.utc(), 'report_sha256': review.digest(ROOT / 'REPORT.md'), 'manifest_sha256': review.digest(ROOT / 'MANIFEST.json'), 'accounting_sha256': review.digest(ROOT / 'ACCOUNTING.json'), 'final_authentication_sha256': review.digest(ROOT / 'authentication-final-exit.json'), 'all18': 'OPEN', 'acceptance': False})
    archive = ROOT / 'handoff.tar.gz'
    with tarfile.open(archive, 'w:gz') as stream:
        for item in payloads:
            stream.add(ROOT / item['path'], arcname=item['path'], recursive=False)
        stream.add(ROOT / 'MANIFEST.json', arcname='MANIFEST.json')
        stream.add(ROOT / 'SEAL.json', arcname='SEAL.json')
    expected = {item['path']: item['sha256'] for item in payloads}
    expected.update({name: review.digest(ROOT / name) for name in ['MANIFEST.json', 'SEAL.json']})
    observed = {}
    with tarfile.open(archive, 'r:gz') as stream:
        for member in stream:
            assert member.isfile()
            observed[member.name] = hashlib.sha256(stream.extractfile(member).read()).hexdigest()
    assert observed == expected
    scratch = sum(path.stat().st_size for path in ROOT.rglob('*') if path.is_file())
    free = shutil.disk_usage(ROOT).free
    assert scratch < 512 * 1024 ** 2 and free > 16 * 1024 ** 3
    assert datetime.now(timezone.utc) < review.DEADLINE
    handoff = {'utc': review.utc(), 'root': str(ROOT), 'report': review.record(ROOT / 'REPORT.md'), 'accounting': review.record(ROOT / 'ACCOUNTING.json'), 'manifest': review.record(ROOT / 'MANIFEST.json'), 'seal': review.record(ROOT / 'SEAL.json'), 'archive': review.record(archive), 'payload_count': len(payloads), 'archive_regular_members_byte_compared': len(observed), 'scratch_bytes_including_archive_before_handoff': scratch, 'free_bytes': free, 'elapsed_seconds': (datetime.now(timezone.utc) - datetime.fromisoformat(review.FIRST)).total_seconds(), 'own_hard_deadline': review.DEADLINE.isoformat(), 'applications_charged': 6, 'application_cap': 6, 'bounded_model_reproduced': True, 'native_linkage_integration_ready': False, 'native_adapter_R': 'OPEN', 'all18': 'OPEN', 'acceptance': False, 'no_further_delegate_requested': True}
    review.write_json(ROOT / 'HANDOFF.json', handoff)
    print(json.dumps(handoff, indent=2), flush=True)

if __name__ == '__main__':
    if sys.argv[1] == 'prepare':
        prepare()
    elif sys.argv[1] == 'seal':
        seal()
