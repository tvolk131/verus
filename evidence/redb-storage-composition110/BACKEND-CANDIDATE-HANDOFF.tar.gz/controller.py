import datetime
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

ROOT = Path('/private/tmp/redb-backend110-B-cCGFf2VR')
PARENT = Path('/Users/tommyvolk/.t3/worktrees/verus/t3-60978068')
NATIVE = Path('/private/tmp/verus-crash-consistency94-20261105/native-leaf-lookup-007/recovered-native/redb')
RUNTIME = Path('/private/tmp/verus-crash-consistency94-20261105/native-leaf-lookup-007/midpoint-runtime-proposal/runtime')
TOOLCHAIN = Path('/Users/tommyvolk/.rustup/toolchains/1.99.1-aarch64-apple-darwin')
INPUTS = PARENT / 'evidence/redb-storage-composition110/INPUTS.json'
START = datetime.datetime.fromisoformat('2026-11-08T04:38:56+00:00').timestamp()
DEADLINE = min(START + 1500, datetime.datetime.fromisoformat('2026-11-08T05:05:00+00:00').timestamp())
CAP = 768 * 1024 * 1024
FLOOR = 16 * 1024 * 1024 * 1024

def digest(path):
    value = hashlib.sha256()
    with open(path, 'rb') as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b''):
            value.update(chunk)
    return value.hexdigest()

def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

def resource():
    filesystem = os.statvfs(ROOT)
    result = dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  elapsed_seconds=time.time() - START,
                  scratch_bytes=sum(path.stat().st_size for path in ROOT.rglob('*') if path.is_file()),
                  free_bytes=filesystem.f_bavail * filesystem.f_frsize)
    if result['free_bytes'] <= FLOOR or result['scratch_bytes'] > CAP or time.time() >= DEADLINE:
        raise RuntimeError(('budget violation', result))
    return result

def supplemental_paths():
    paths = [Path(sys.executable), Path(__file__),
             Path('/Library/Developer/CommandLineTools/Library/Frameworks/Python3.framework/Versions/3.9/Python3'),
             Path('/bin/zsh'), Path('/bin/ls'), Path('/bin/cat'), Path('/bin/date'), Path('/bin/df'),
             Path('/usr/bin/shasum'), Path('/usr/bin/sed'), Path('/usr/bin/mktemp'),
             Path('/Users/tommyvolk/.codex/packages/standalone/releases/0.166.0-aarch64-apple-darwin/codex-path/rg'),
             Path('/Users/tommyvolk/.t3/userdata/providers/codex/codex_095eca24-b4b7-4a15-8759-9d8964dbd03a/shadow/tmp/arg0-macos/codex-arg011pOCK/apply_patch'),
             Path('/private/tmp/redb-storage109-review-QFf6FvBP/check-01/invocation.json'),
             Path('/private/tmp/redb-storage109-review-QFf6FvBP/check-01/buffered_flush109.rs')]
    paths += list(RUNTIME.glob('*'))
    paths += [NATIVE / relative for relative in ['AGENTS.md', 'src/db.rs', 'src/error.rs', 'src/lib.rs', 'src/io.rs', 'src/tree_store/page_store/cached_file.rs', 'src/transactions.rs']]
    paths += [PARENT / 'evidence/redb-storage-composition110' / name for name in ['PLAN.md', 'INPUTS.json', 'AUTHORIZATION.json']]
    paths += [PARENT / 'evidence/redb-storage-refinement109' / name for name in ['INDEPENDENT-REVIEW.md', 'INDEPENDENT-REVIEW-METADATA.json']]
    paths += [Path(module.__file__) for module in list(sys.modules.values()) if getattr(module, '__file__', None) and Path(module.__file__).is_file()]
    return sorted(set(path.resolve() for path in paths if path.is_file()), key=str)

def authenticate(label):
    selected = json.loads(INPUTS.read_text())['records']
    observed = []
    failures = []
    for record in selected:
        path = Path(record['path'])
        actual = digest(path) if path.is_file() else None
        observed.append(dict(path=str(path), expected=record['sha256'], actual=actual, matches=actual == record['sha256']))
        if actual != record['sha256']:
            failures.append(str(path))
    supplements = [dict(path=str(path), bytes=path.stat().st_size, sha256=digest(path)) for path in supplemental_paths()]
    entry_file = ROOT / 'authentication-entry.json'
    if entry_file.exists():
        baseline = {item['path']: item['sha256'] for item in json.loads(entry_file.read_text())['supplemental']}
        for item in supplements:
            item['entry_matches'] = baseline.get(item['path']) == item['sha256']
            if item['path'] in baseline and not item['entry_matches'] and item['path'] != str(Path(__file__).resolve()):
                failures.append(item['path'])
    result = dict(label=label, selected_count=len(selected), selected=observed, supplemental=supplements,
                  failures=failures, sample=resource(), first_use_exhaustive_provenance=False,
                  qualification='Entry follows read-only bootstrap/source display; no retroactive complete bootstrap or exhaustive loader provenance. Direct framework Python, no python/rustup shim execution. Selected records compared to current round110 hashes, not historical round109 frozen hashes.')
    write_json(ROOT / ('authentication-' + label + '.json'), result)
    if failures:
        raise RuntimeError(('authentication mismatch', failures))
    return result

def extract(text, marker):
    beginning = text.index(marker)
    opening = text.index('{', beginning)
    depth = 1
    position = opening + 1
    while depth:
        depth += (text[position] == '{') - (text[position] == '}')
        position += 1
    return text[beginning:position]

def probe():
    cached = (NATIVE / 'src/tree_store/page_store/cached_file.rs').read_text()
    database = (NATIVE / 'src/db.rs').read_text()
    errors = (NATIVE / 'src/error.rs').read_text()
    library = (NATIVE / 'src/lib.rs').read_text()
    fragments = [
        ('src/db.rs', extract(database, "pub trait StorageBackend: 'static + Debug + Send + Sync")),
        ('src/error.rs', extract(errors, 'pub enum BackendError')),
        ('src/error.rs', extract(errors, 'pub enum StorageError')),
        ('src/error.rs', extract(errors, 'impl From<io::Error> for StorageError')),
        ('src/lib.rs', next(line for line in library.splitlines() if line.startswith('pub type Result<'))),
        ('src/tree_store/page_store/cached_file.rs', extract(cached, 'struct CheckedBackend')),
    ]
    methods = [(name, extract(cached, 'fn ' + name + '(')) for name in ['check_failure', 'close', 'sync_data', 'write', 'write_best_effort']]
    prelude = 'extern crate alloc;\nuse vstd::prelude::*;\nuse alloc::boxed::Box;\nuse core::fmt::Debug;\nuse core::ops::Bound;\nuse core::panic;\nuse core::sync::atomic::{AtomicBool, Ordering};\nuse std::io;\nverus! {\n'
    source = prelude + '\n\n'.join(fragment for relative, fragment in fragments) + '\nimpl CheckedBackend {\n' + '\n\n'.join(fragment for name, fragment in methods) + '\n}\n}\n'
    (ROOT / 'native_probe.rs').write_text(source)
    audit = []
    for relative, fragment in fragments + [('src/tree_store/page_store/cached_file.rs', fragment) for name, fragment in methods]:
        original = (NATIVE / relative).read_text()
        start = original.index(fragment)
        audit.append(dict(native_path=str(NATIVE / relative), start_line=original[:start].count('\n') + 1,
                          end_line=original[:start + len(fragment)].count('\n') + 1,
                          exact_utf8_sha256=hashlib.sha256(fragment.encode()).hexdigest(), verbatim=fragment in source))
    write_json(ROOT / 'native-preservation.json', dict(fragments=audit,
        adaptations=['standalone proof crate imports and verus wrapper', 'native std io::Error alias retained through std::io import', 'unselected methods and native modules omitted', 'no native constructor/destructor/admission implementation selected', 'native derives/docs outside selected definitions omitted'],
        checked_native_bodies_claimed=False))

def run(source_name, kind):
    attempts = sorted(ROOT.glob('attempt-*/receipt.json'))
    number = len(attempts) + 1
    if number > 16:
        raise RuntimeError('application cap')
    resource()
    if time.time() + 95 >= DEADLINE:
        raise RuntimeError('insufficient retained time')
    directory = ROOT / ('attempt-%02d' % number)
    directory.mkdir()
    authenticate('preexec-%02d' % number)
    source = ROOT / source_name
    local = directory / source.name
    local.write_bytes(source.read_bytes())
    environment = json.loads(Path('/private/tmp/redb-storage109-review-QFf6FvBP/check-01/invocation.json').read_text())['environment']
    old = '/private/tmp/redb-storage109-review-QFf6FvBP/check-01'
    environment = {key: value.replace(old, str(directory)) for key, value in environment.items()}
    for key in ['CARGO_HOME', 'CARGO_TARGET_DIR', 'HOME', 'RUSTUP_HOME', 'TEMP', 'TMP', 'TMPDIR', 'VERUS_INFER_CACHE', 'XDG_CACHE_HOME', 'XDG_CONFIG_HOME', 'XDG_DATA_HOME', 'XDG_STATE_HOME']:
        Path(environment[key]).mkdir(parents=True, exist_ok=True)
    export = directory / (source.stem + '.vir')
    argv = [str(RUNTIME / 'verus'), '--sysroot', str(TOOLCHAIN), '--edition=2024', '--crate-type=lib', '--crate-name', source.stem, '--no-cheating', '--output-json', '--num-threads', '1', '--triggers-mode', 'silent', '--multiple-errors', '8', '--rlimit', '20', '-C', 'debug-assertions=no', '--export', str(export), str(local)]
    invocation = dict(argv=argv, environment=environment, cwd=str(directory), source_sha256=digest(local), charged=True, number=number, kind=kind, timeout_seconds=90, requested_export=str(export), fresh_export_absent=not export.exists(), sample=resource())
    write_json(directory / 'invocation.json', invocation)
    began = time.time()
    timed_out = False
    with (directory / 'stdout.txt').open('wb') as output, (directory / 'stderr.txt').open('wb') as errors:
        process = subprocess.Popen(argv, cwd=directory, env=environment, stdout=output, stderr=errors, start_new_session=True)
        try:
            status = process.wait(timeout=90)
        except subprocess.TimeoutExpired:
            timed_out = True
            os.killpg(process.pid, signal.SIGKILL)
            status = process.wait()
    receipt = dict(number=number, kind=kind, status=status, timed_out=timed_out, elapsed_seconds=time.time()-began,
                   export_exists=export.is_file(), export_path=str(export), export_sha256=digest(export) if export.is_file() else None,
                   source_sha256=digest(local), stdout_sha256=digest(directory/'stdout.txt'), stderr_sha256=digest(directory/'stderr.txt'), sample=resource())
    write_json(directory / 'receipt.json', receipt)
    print(json.dumps(receipt), flush=True)
    print((directory / 'stdout.txt').read_text()[-12000:])
    print((directory / 'stderr.txt').read_text()[-12000:])

if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'entry':
        authenticate('entry')
        probe()
        print('entry authenticated; native source generated')
    elif action == 'run':
        run(sys.argv[2], sys.argv[3])
    elif action == 'exit':
        authenticate('exit')
