import difflib
import gzip
import json
import os
from pathlib import Path
import sys
import tarfile
import time
import zlib

import controller

ROOT = controller.ROOT

def patch_text(before, after, old, new):
    return ''.join(difflib.unified_diff(before.splitlines(keepends=True), after.splitlines(keepends=True), fromfile=old, tofile=new))

def anchor(relative, marker=None, start=None, end=None):
    path = controller.NATIVE / relative
    original = path.read_text()
    if marker is not None:
        excerpt = controller.extract(original, marker)
        offset = original.index(excerpt)
        start = original[:offset].count('\n') + 1
        end = original[:offset + len(excerpt)].count('\n') + 1
    else:
        excerpt = ''.join(original.splitlines(keepends=True)[start - 1:end])
    return dict(path=str(path), start_line=start, end_line=end, file_sha256=controller.digest(path),
                excerpt_sha256=controller.hashlib.sha256(excerpt.encode()).hexdigest(), excerpt=excerpt)

def prepare():
    controller.authenticate('evidence-entry')
    anchors = []
    for name in ['check_failure', 'close', 'len', 'read', 'set_len', 'sync_data', 'write', 'write_best_effort', 'unlock_range']:
        anchors.append(anchor('src/tree_store/page_store/cached_file.rs', 'fn ' + name + '('))
    anchors += [anchor('src/tree_store/page_store/cached_file.rs', 'struct CheckedBackend'),
                anchor('src/db.rs', "pub trait StorageBackend: 'static + Debug + Send + Sync"),
                anchor('src/error.rs', 'pub enum StorageError'),
                anchor('src/error.rs', 'pub enum BackendError'),
                anchor('src/error.rs', 'impl From<io::Error> for StorageError'),
                anchor('src/error.rs', 'impl From<BackendError> for StorageError'),
                anchor('src/transactions.rs', 'fn apply_savepoint_state_on_commit('),
                anchor('src/transactions.rs', start=2140, end=2178),
                anchor('src/transactions.rs', start=2180, end=2246),
                anchor('src/io.rs', start=1, end=14),
                anchor('src/lib.rs', start=100, end=104)]
    controller.write_json(ROOT / 'SOURCE-ANCHORS.json', anchors)
    rows = []
    previous = None
    for directory in sorted(ROOT.glob('attempt-*')):
        receipt = json.loads((directory / 'receipt.json').read_text())
        output = json.loads((directory / 'stdout.txt').read_text())
        scope = output.get('verus-infer', {}).get('verification_scope', {})
        row = dict(receipt)
        row['verification_results'] = output.get('verification-results')
        row['scope'] = {key: value for key, value in scope.items() if key not in ['native_functions', 'limitations']}
        row['checked_functions'] = [item['function'] for item in scope.get('native_functions', []) if item['body_status'] == 'checked_proof_body']
        row['failed_functions'] = output.get('verus-infer', {}).get('failed_functions', [])
        row['diagnostic_kind'] = 'native_frontend_unsupported_type' if receipt['number'] == 1 else ('semantic_postcondition_failure' if receipt['status'] else 'full_crate_positive')
        row['solver_assertion_total'] = None
        row['solver_assertion_total_note'] = 'Not exposed by this existing verifier; verified is retained exactly, not relabeled as an SMT assertion count.'
        controller.write_json(directory / 'scope-summary.json', row)
        rows.append(row)
        source = next(directory.glob('*.rs'))
        if receipt['number'] >= 2:
            current = source.read_text()
            before = previous[1] if previous else ''
            old = previous[0] if previous else '/dev/null'
            (directory / 'source-change.patch').write_text(patch_text(before, current, old, str(source)))
            previous = (str(source), current)
    controller.write_json(ROOT / 'RESULTS.json', dict(
        schema='round110-lane-B-results-v1', lane='B', applications_charged=len(rows), application_cap=16,
        native_applications=1, native_cap=3, native_checked_original_bodies=0, all18='OPEN', acceptance=False,
        source_sha256=controller.digest(ROOT/'backend_control110.rs'), attempts=rows,
        restored_groups=[dict(initial=3, negative=4, corrected=5, restored=6,
                              byte_identical_sources=len(set(rows[index-1]['source_sha256'] for index in [3,5,6])) == 1),
                         dict(initial=7, negative=8, corrected=9, restored=10,
                              byte_identical_sources=len(set(rows[index-1]['source_sha256'] for index in [7,9,10])) == 1)],
        final_sample=controller.resource()))
    for name in ['backend_control110.rs', 'controller.py', 'build_evidence.py', 'native_probe.rs']:
        source = ROOT / name
        (ROOT / (name + '.patch')).write_text(patch_text('', source.read_text(), '/dev/null', name))
    samples = []
    for path in sorted(ROOT.glob('authentication-*.json')):
        record = json.loads(path.read_text())
        samples.append(dict(path=path.name, sample=record['sample'], selected_count=record['selected_count'], failures=record['failures']))
    for row in rows:
        samples.append(dict(attempt=row['number'], sample=row['sample']))
    controller.write_json(ROOT / 'RESOURCE-SAMPLES.json', samples)
    print(json.dumps(dict(applications=len(rows), final_sha256=controller.digest(ROOT/'backend_control110.rs'), final_scope=rows[-1]['scope'], sample=controller.resource()), indent=2))

def seal():
    if (ROOT / 'REPORT.md').stat().st_size > 24 * 1024:
        raise RuntimeError('report too large')
    exit_authentication = controller.authenticate('exit')
    packaging_entry = json.loads((ROOT/'authentication-evidence-entry.json').read_text())
    packaging_expected = {item['path']: item['sha256'] for item in packaging_entry['supplemental']}
    packaging_actual = {item['path']: item['sha256'] for item in exit_authentication['supplemental']}
    packaging_mismatches = [path for path, expected in packaging_expected.items() if packaging_actual.get(path) != expected]
    controller.write_json(ROOT/'packaging-identity-comparison.json', dict(
        compared_count=len(packaging_expected), mismatches=packaging_mismatches,
        qualification='Packaging module identities first captured at evidence-entry; no retroactive bootstrap first-use claim.'))
    if packaging_mismatches:
        raise RuntimeError(('packaging supplemental mismatch', packaging_mismatches))
    for name in ['backend_control110.rs', 'controller.py', 'build_evidence.py', 'native_probe.rs']:
        source = ROOT / name
        (ROOT / (name + '.patch')).write_text(patch_text('', source.read_text(), '/dev/null', name))
    manifest = []
    omitted = {'MANIFEST.json', 'SEAL.json', 'handoff.tar.gz', 'HANDOFF.json'}
    for path in sorted(ROOT.rglob('*')):
        if path.is_file() and path.name not in omitted:
            manifest.append(dict(path=str(path.relative_to(ROOT)), bytes=path.stat().st_size, sha256=controller.digest(path)))
    controller.write_json(ROOT / 'MANIFEST.json', dict(schema='round110-lane-B-manifest-v1', records=manifest,
                                                      no_atomic_snapshot_claim=True, sample=controller.resource()))
    controller.write_json(ROOT / 'SEAL.json', dict(schema='round110-lane-B-seal-v1',
        manifest_sha256=controller.digest(ROOT/'MANIFEST.json'), report_sha256=controller.digest(ROOT/'REPORT.md'),
        exit_authentication_sha256=controller.digest(ROOT/'authentication-exit.json'),
        source_sha256=controller.digest(ROOT/'backend_control110.rs'), sample=controller.resource(),
        status='SEALED_CANDIDATE_ONLY_NO_ADOPTION', all18='OPEN', native_original_bodies_checked=0,
        application_count=len(list(ROOT.glob('attempt-*/receipt.json')))))
    members = [path for path in sorted(ROOT.rglob('*')) if path.is_file() and path.name not in ['handoff.tar.gz', 'HANDOFF.json']]
    with tarfile.open(ROOT/'handoff.tar.gz', 'w:gz') as archive:
        for path in members:
            archive.add(path, arcname=str(path.relative_to(ROOT)), recursive=False)
    verified = []
    failures = []
    with tarfile.open(ROOT/'handoff.tar.gz', 'r:gz') as archive:
        for record in manifest:
            content = archive.extractfile(record['path']).read()
            actual = controller.hashlib.sha256(content).hexdigest()
            verified.append(record['path'])
            if actual != record['sha256']:
                failures.append(record['path'])
    if failures:
        raise RuntimeError(('archive mismatch', failures))
    metadata = dict(root=str(ROOT), archive=str(ROOT/'handoff.tar.gz'), archive_sha256=controller.digest(ROOT/'handoff.tar.gz'),
                    archive_bytes=(ROOT/'handoff.tar.gz').stat().st_size, archive_members=len(members),
                    manifest_sha256=controller.digest(ROOT/'MANIFEST.json'), seal_sha256=controller.digest(ROOT/'SEAL.json'),
                    report=str(ROOT/'REPORT.md'), source=str(ROOT/'backend_control110.rs'),
                    archive_manifest_records_verified=len(verified), archive_manifest_failures=failures,
                    sample=controller.resource(), ended_at_sealed_handoff=True, acceptance=False, all18='OPEN')
    controller.write_json(ROOT/'HANDOFF.json', metadata)
    print(json.dumps(metadata, indent=2))

if __name__ == '__main__':
    if sys.argv[1] == 'prepare':
        prepare()
    elif sys.argv[1] == 'seal':
        seal()
