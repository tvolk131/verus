# Bootstrap and operational observations

First shell observation: 2026-11-08T04:38:56Z. The lane's own 25-minute deadline
is therefore 05:03:56Z, earlier than the separate 05:05:00Z handoff cap. Optional
work cutoff is 05:00:56Z. Round deadline remains 05:33:26Z; none is extended.
Initial df available blocks: 51,962,500 KiB (53,209,600,000 bytes), strictly above
16 GiB. There was one verifier worker, no subdelegation, no network or Git writes.

Entry authentication follows read-only bootstrap displays. This does NOT claim
complete first-use or retroactively exhaustive bootstrap provenance. All actual
verifier applications have raw stdout/stderr, status, source, exact argv/full
environment, preexecution selected/supplemental authentication and resource samples.
The Python controller is launched directly from the installed framework at
`/Library/Developer/CommandLineTools/Library/Frameworks/Python3.framework/Versions/3.9/bin/python3.9`.
No `/usr/bin/python3` or rustup shim was intentionally executed; the former is
only a selected identity. Direct verifier/engine/z3/vstd runtime identities and
pinned toolchain files are covered by current selected records and supplementary
runtime hashes. Python executable/framework and loaded Python modules are also
hashed. Exhaustive dyld/process tracing or source/compiler correspondence is NOT
claimed. Later-loaded supplemental module identities are marked honestly by
their observation phase; they are not retroactively first-use authenticated.

The terminal transcript preserves these read-only bootstrap failures; this file
transcribes them rather than claiming a raw saved bootstrap stdout/stderr file:

```
zsh:1: no matches found: /Library/Frameworks/Python.framework/Versions/*/bin/python3*
ls: /opt/homebrew/bin/python3: No such file or directory
ls: /usr/local/bin/python3: No such file or directory
ls: /usr/local/Frameworks/Python.framework/Versions: No such file or directory
zsh:1: no matches found: /Applications/Xcode.app/Contents/Developer/Library/Frameworks/Python3.framework/Versions/*/bin/python3*
shasum: /usr/bin/rg: No such file or directory
```

Those were tool-path discovery/display attempts, not verifier setup or launches;
no dependency installation or tool build was attempted. `command -v rg` resolves
to the selected Codex standalone rg binary, recorded in supplemental identities.
An attempted `cat` of the apply_patch path unexpectedly displayed its Mach-O
binary (terminal output was truncated); no tool/cache copy or native application
execution resulted. The full binary display is not retained as a scratch file.
That incidental output is not complete raw bootstrap evidence. Subsequent edits
use the actual `apply_patch` command. No failed authored patch occurred; initial
proof witness failure and all source corrections are retained in per-attempt
source snapshots and generated exact source-change patches.

Scoped native AGENTS instructions were read. Native source was not edited, built
or executed; its test/build instructions do not authorize forbidden builds in
this scratch proof task. No native Drop/lifecycle implementation was investigated
or proved; explicit `CheckedBackend::close` alone is selected here.
