import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import tarfile
import time

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
CANDIDATE = Path('/private/tmp/fedimint-lnurl-implementation-20261107.bEAi6d')
PARENT = Path('/Users/tommyvolk/.t3/worktrees/verus/t3-60978068')
RUNTIME = Path('/private/tmp/verus-crash-consistency94-20261105/codec-runtime-005/runtime')
BINDING = RUNTIME.parent / 'runtime-binding.json'
START = datetime.datetime.fromisoformat('2026-11-08T02:56:43+00:00').timestamp()
EXPECTED = {
    'SHA256SUMS': 'e705e0c7fc3d1718404441c0ec16e2356a2241fab0810fefb854f9dfaa1b1037',
    'REPORT.md': '6f24d5eb3ed72892191a4dc2e6405b307deb919a3f8ff8081b10d3ecfdd9fd50',
    'SEAL.json': '01a176d8b62b0b40159179be7ef6d43f7b1d34452e48e33146231fd0e0ec4f9e',
}


def digest(filename):
    checksum = hashlib.sha256()
    with Path(filename).open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            checksum.update(block)
    return checksum.hexdigest()


def write_json(filename, value):
    (OUT / filename).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def storage():
    filesystem = os.statvfs('/private/tmp')
    free_bytes = filesystem.f_bavail * filesystem.f_frsize
    scratch_bytes = sum(filename.stat().st_size for filename in OUT.rglob('*') if filename.is_file())
    assert free_bytes > 16 * 1024 ** 3
    assert scratch_bytes <= 128 * 1024 ** 2
    return dict(free_bytes=free_bytes, scratch_bytes=scratch_bytes)


def authenticate():
    for filename, expected in EXPECTED.items():
        assert digest(CANDIDATE / filename) == expected, filename
    payloads = {}
    for line in (CANDIDATE / 'SHA256SUMS').read_text().splitlines():
        expected, filename = line.split(None, 1)
        filename = filename.lstrip('*')
        assert not Path(filename).is_absolute() and '..' not in Path(filename).parts
        actual = digest(CANDIDATE / filename)
        assert actual == expected, filename
        payloads[filename] = actual
    assert len(payloads) == 120
    binding = json.loads(BINDING.read_text())
    runtime = {filename: digest(RUNTIME / filename) for filename in binding['runtime']}
    assert runtime == binding['runtime']
    recorded = json.loads((CANDIDATE / 'entry-authentication-02.json').read_text())
    actual_inputs = {filename: digest(filename) for filename in recorded['inputs']}
    assert actual_inputs == recorded['inputs'], 'candidate consumed-input binding drift'
    differences = {filename: dict(recorded=expected, actual=digest(PARENT / filename) if (PARENT / filename).is_file() else None)
                   for filename, expected in binding['source'].items()
                   if not (PARENT / filename).is_file() or digest(PARENT / filename) != expected}
    assert differences == recorded['historical_source_mismatches']
    return dict(candidate_payloads=payloads, candidate_metadata=EXPECTED, runtime=runtime,
                used_immutable_inputs=actual_inputs, historical_source_mismatches=differences,
                sysroot=binding['sysroot'], independent_review=binding['independent_review'],
                storage=storage())


def initial():
    assert not (OUT / 'entry-authentication.json').exists()
    authentication = authenticate()
    write_json('entry-authentication.json', authentication)
    archive = PARENT / 'evidence/fedimint-lnurl-composition107/CANDIDATE-HANDOFF.tar.gz'
    expected_archive = '1525b3cc5b57345d4f868ae3c8ba388d475e6c705c4e0f99419553d9d4d7fdab'
    assert digest(archive) == expected_archive
    archive_members = {}
    with tarfile.open(archive, 'r:gz') as archive_stream:
        for member in archive_stream.getmembers():
            if member.isfile():
                assert member.name.startswith('fedimint-lnurl/')
                relative = member.name[len('fedimint-lnurl/'):]
                archived = archive_stream.extractfile(member).read()
                assert archived == (CANDIDATE / relative).read_bytes(), relative
                archive_members[member.name] = hashlib.sha256(archived).hexdigest()
    assert len(archive_members) == 122
    write_json('archive-comparison.json', dict(sha256=expected_archive, exact_members=archive_members,
               prefix='fedimint-lnurl/', parent_initial_metadata_error='omitted prefix; separate from candidate'))
    for directory in ('home', 'tmp', 'cache', 'cargo-home', 'target'):
        (OUT / directory).mkdir()
    print(json.dumps(dict(authentication='PASS', payloads=len(authentication['candidate_payloads']),
                         immutable_inputs=len(authentication['used_immutable_inputs']),
                         source_differences=len(authentication['historical_source_mismatches']),
                         archive_members=len(archive_members), storage=storage())))


def environment():
    return dict(PATH='/usr/bin:/bin:/Users/tommyvolk/.cargo/bin', HOME=str(OUT / 'home'),
                TMPDIR=str(OUT / 'tmp'), RUSTUP_HOME='/Users/tommyvolk/.rustup',
                RUSTUP_TOOLCHAIN='1.99.1', CARGO_HOME=str(OUT / 'cargo-home'),
                CARGO_TARGET_DIR=str(OUT / 'target'), CARGO_BUILD_JOBS='1',
                VERUS_Z3_PATH=str(RUNTIME / 'z3'), VERUS_INFER_CACHE=str(OUT / 'cache'),
                GIT_OPTIONAL_LOCKS='0', LC_ALL='C', TZ='UTC')


def run(label, filename, crate, provider=False):
    assert time.time() < START + 9 * 60, 'launch deadline'
    ledger = OUT / 'attempts.jsonl'
    attempts = ledger.read_text().splitlines() if ledger.exists() else []
    assert len(attempts) < 7
    assert not (OUT / (label + '.command.json')).exists()
    before = authenticate()
    entry = json.loads((OUT / 'entry-authentication.json').read_text())
    for field in ('candidate_payloads', 'runtime', 'used_immutable_inputs', 'historical_source_mismatches'):
        assert before[field] == entry[field]
    write_json(label + '.authentication.json', before)
    argv = [str(RUNTIME / 'verus'), str(CANDIDATE / filename), '--crate-type=lib', '--edition=2021',
            '--crate-name', crate, '--no-cheating', '--output-json', '--num-threads', '1']
    artifact = OUT / (label + '.vir')
    negative = label == 'wrong_value'
    if not negative:
        argv += ['--export', str(artifact)]
    imports = {}
    if provider:
        argv += ['--compile', '-o', str(OUT / ('lib' + crate + '.rlib'))]
    else:
        for provider_name, prefix in [('lnurl_fee_provider', 'fee'), ('lnurl_encoding_provider', 'encoding')]:
            for imported in [OUT / (prefix + '.vir'), OUT / ('lib' + provider_name + '.rlib')]:
                imports[str(imported)] = digest(imported)
            argv += ['--import', provider_name + '=' + str(OUT / (prefix + '.vir')),
                     '--extern', provider_name + '=' + str(OUT / ('lib' + provider_name + '.rlib'))]
    record = dict(attempt=len(attempts) + 1, charged_direct_applications=1, label=label,
                  argv=argv, environment=environment(), cwd=str(OUT),
                  source_sha256=digest(CANDIDATE / filename), imported_sha256=imports,
                  timeout_seconds=60, worker_count=1, export_requested=not negative,
                  started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), storage=storage())
    with ledger.open('a') as stream:
        stream.write(json.dumps(record, sort_keys=True) + '\n')
    write_json(label + '.command.json', record)
    started = time.monotonic()
    timeout = False
    with (OUT / (label + '.stdout')).open('wb') as stdout, (OUT / (label + '.stderr')).open('wb') as stderr:
        process = subprocess.Popen(argv, cwd=OUT, env=environment(), stdout=stdout, stderr=stderr, start_new_session=True)
        try:
            returncode = process.wait(timeout=60)
        except subprocess.TimeoutExpired:
            timeout = True
            os.killpg(process.pid, signal.SIGKILL)
            returncode = process.wait()
    elapsed = time.monotonic() - started
    after = authenticate()
    unchanged = all(before[field] == after[field] for field in
                    ('candidate_payloads', 'runtime', 'used_immutable_inputs', 'historical_source_mismatches'))
    unchanged = unchanged and all(digest(filename) == expected for filename, expected in imports.items())
    status = dict(returncode=returncode, timeout=timeout, elapsed_seconds=elapsed,
                  inputs_unchanged=unchanged, export_requested=not negative,
                  export_exists=artifact.exists(), storage=storage())
    try:
        data = json.loads((OUT / (label + '.stdout')).read_text())
        write_json(label + '.scope.json', data)
        status['verification_results'] = data.get('verification-results')
        status['scope'] = data.get('verus-infer', {}).get('verification_scope')
    except ValueError:
        status['json_parsed'] = False
    write_json(label + '.status.json', status)
    print(json.dumps(dict(label=label, **{field: status[field] for field in
                     ('returncode', 'timeout', 'elapsed_seconds', 'inputs_unchanged', 'export_exists')},
                     verification_results=status.get('verification_results')), sort_keys=True))
    assert unchanged


def historical():
    attempts = [json.loads(line) for line in (CANDIDATE / 'attempts.jsonl').read_text().splitlines()]
    records = []
    for attempt in attempts:
        label = attempt['label']
        status = json.loads((CANDIDATE / (label + '.status.json')).read_text())
        stdout = (CANDIDATE / (label + '.stdout')).read_text()
        stderr = (CANDIDATE / (label + '.stderr')).read_text()
        scope = json.loads((CANDIDATE / (label + '.scope.json')).read_text())
        command = json.loads((CANDIDATE / (label + '.command.json')).read_text())
        authentication = json.loads((CANDIDATE / (label + '.authentication.json')).read_text())
        assert command == attempt
        assert authentication['inputs'] == json.loads((CANDIDATE / 'entry-authentication-02.json').read_text())['inputs']
        assert json.loads(stdout) == scope
        source = CANDIDATE / 'composition-attempt03.rs' if label == 'composition' else Path(attempt['argv'][1])
        assert digest(source) == attempt['source_sha256']
        records.append(dict(label=label, result=status.get('verification_results'), returncode=status['returncode'],
                            timeout=status['timeout'], stderr=stderr, scope=status.get('scope'),
                            source=str(source), stdout_sha256=digest(CANDIDATE / (label + '.stdout'))))
    for filename in ('REPORT.md', 'composition.rs', 'accounting-sum-corollary.rs', 'fee-provider.rs',
                     'encoding-provider.rs', 'implementation.patch', 'SEAL.json', 'SHA256SUMS',
                     'attempts.jsonl', 'audit.json', 'audit.py', 'controls.json', 'controls-v2.json',
                     'controls.py', 'preparation-failures.md', 'semantic-mutation.patch', 'semantic-mutation-v2.patch'):
        (CANDIDATE / filename).read_bytes()
    write_json('historical-review.json', dict(applications=records, count=len(records)))
    print(json.dumps([dict(label=record['label'], returncode=record['returncode'], result=record['result']) for record in records]))


def finish():
    authentication = authenticate()
    entry = json.loads((OUT / 'entry-authentication.json').read_text())
    unchanged = all(authentication[field] == entry[field] for field in
                    ('candidate_payloads', 'runtime', 'used_immutable_inputs', 'historical_source_mismatches'))
    assert unchanged
    write_json('exit-authentication.json', authentication)
    write_json('exit-comparison.json', dict(unchanged=unchanged, storage=storage(), elapsed_seconds=time.time() - START))
    print(json.dumps(dict(exit_authentication='PASS', elapsed_seconds=time.time() - START, storage=storage())))


if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'initial':
        initial()
    elif action == 'historical':
        historical()
    elif action == 'finish':
        finish()
    else:
        run(*sys.argv[1:4], provider='--provider' in sys.argv)
