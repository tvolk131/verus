import datetime
import json
from pathlib import Path
import tarfile
import time

from review import START, OUT, digest, storage, write_json

assert time.time() < START + 12 * 60
attempts = [json.loads(line) for line in (OUT / 'attempts.jsonl').read_text().splitlines()]
assert len(attempts) == 7
exit_comparison = json.loads((OUT / 'exit-comparison.json').read_text())
assert exit_comparison['unchanged']
late_loader = json.loads((OUT / 'late-loader-observation.json').read_text())
assert digest(late_loader['executable']) == late_loader['observed_sha256']
write_json('loader-exit-comparison.json', dict(unchanged_since_late_observation=True,
    executable=late_loader['executable'], sha256=late_loader['observed_sha256'],
    entry_and_preexecution_identity='NOT ESTABLISHED'))
payloads = sorted(filename for filename in OUT.rglob('*') if filename.is_file()
                  and filename.name not in ('SHA256SUMS', 'SEAL.json', 'handoff.tar.gz', 'HANDOFF.sha256'))
(OUT / 'SHA256SUMS').write_text(''.join(digest(filename) + '  ' + str(filename.relative_to(OUT)) + '\n'
                                      for filename in payloads))
write_json('SEAL.json', dict(status='BOUNDED NUMERIC SLICE CHECKED; TRANSITIVE LOADER OBJECTION OPEN; NOT ADOPTED',
    charged_direct_applications=7, simultaneous_workers=1, timeout_seconds=60,
    manifest_files=len(payloads), manifest_sha256=digest(OUT / 'SHA256SUMS'),
    report_sha256=digest(OUT / 'REVIEW.md'), runtime_and_declared_inputs_unchanged=True,
    transitive_rustup_entry_preexecution_authentication=False,
    compiler_source_correspondence_repaired=False, independent_review='OPEN', redb_cells_open=18,
    launches_finished_before_nine_minutes=True, elapsed_seconds=time.time() - START,
    storage=storage(), sealed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()))
with tarfile.open(OUT / 'handoff.tar.gz', 'w:gz') as archive:
    for filename in [*payloads, OUT / 'SHA256SUMS', OUT / 'SEAL.json']:
        archive.add(filename, arcname='fedimint-lnurl-review107/' + str(filename.relative_to(OUT)), recursive=False)
(OUT / 'HANDOFF.sha256').write_text(digest(OUT / 'handoff.tar.gz') + '  handoff.tar.gz\n')
print(json.dumps(dict(archive=str(OUT / 'handoff.tar.gz'), sha256=digest(OUT / 'handoff.tar.gz'),
                     manifest_sha256=digest(OUT / 'SHA256SUMS'), seal_sha256=digest(OUT / 'SEAL.json'),
                     elapsed_seconds=time.time() - START, storage=storage()), sort_keys=True))
