import contextlib
import difflib
import hashlib
import io
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
CANDIDATE = Path('/private/tmp/fedimint-lnurl-implementation-20261107.bEAi6d')
PARENT = Path('/Users/tommyvolk/.t3/worktrees/verus/t3-60978068')
NATIVE = Path('/private/tmp/verus-crash-consistency94-20261105/native-leaf-lookup-007/recovered-native/fedimint')
sys.path.insert(0, str(PARENT / 'source/tools'))
import check_fedimint_validation81 as validation
import check_fedimint_fee_encoding as encoding
from infer_transfer_receipts import metadata
from review import START, digest, write_json, storage

entry = json.loads((OUT / 'entry-authentication.json').read_text())
rustup = Path('/Users/tommyvolk/.cargo/bin/rustup')
assert str(rustup) not in entry['used_immutable_inputs']
loader_objection = dict(
    status='OPEN: transitive-loader entry/preexecution coverage unavailable',
    executable=str(rustup), observed_sha256=digest(rustup),
    observed_after_all_seven_applications=True,
    reason='Hashed runtime/verus invokes rustup through the recorded PATH by default. Neither candidate receipts nor fresh entry/preexecution receipts hash this rustup executable.',
    consequence='Late observation cannot establish its earlier identity; no retroactive authentication or eighth verifier application is claimed.',
    bound_runtime_and_sysroot_still_authenticated=True,
)
write_json('late-loader-observation.json', loader_objection)

audit_source = (CANDIDATE / 'audit.py').read_text()
audit_replay = audit_source.replace("(OUT / 'audit.json').write_text", "(REVIEW_OUT / 'audit-replay.json').write_text")
audit_replay = audit_replay.replace("(OUT / 'implementation.patch').write_text", "(REVIEW_OUT / 'implementation-replay.patch').write_text")
assert audit_replay != audit_source
assert audit_replay.count('REVIEW_OUT') == 2
capture = io.StringIO()
with contextlib.redirect_stdout(capture):
    exec(compile(audit_replay, str(CANDIDATE / 'audit.py'), 'exec'),
         dict(__file__=str(CANDIDATE / 'audit.py'), REVIEW_OUT=OUT))
(OUT / 'audit-replay.stdout').write_text(capture.getvalue())
assert json.loads((OUT / 'audit-replay.json').read_text()) == json.loads((CANDIDATE / 'audit.json').read_text())
assert (OUT / 'implementation-replay.patch').read_bytes() == (CANDIDATE / 'implementation.patch').read_bytes()

selected, native_sources = validation.extract(NATIVE)
assert validation.provider_source(selected) == (CANDIDATE / 'fee-provider.rs').read_text()
helpers = encoding.extract_helpers((NATIVE / encoding.CONTRACTS).read_text())
assert encoding.proof_source(helpers) == (CANDIDATE / 'encoding-provider.rs').read_text()
encoding.check_call_paths((NATIVE / encoding.RECURRING).read_text(), (NATIVE / encoding.RECEIVE).read_text())
selected_hashes = {name: hashlib.sha256(source.encode()).hexdigest() for name, source in selected.items()}
assert selected_hashes == validation.ITEM_HASHES
assert len(set(validation.SOURCE_HASHES) | set(encoding.SOURCE_HASHES)) == 7

original = (CANDIDATE / 'composition.rs').read_text()
restored = (CANDIDATE / 'v2-composition-restored.rs').read_text()
mutant = (CANDIDATE / 'v2-composition-mutant.rs').read_text()
witness = (CANDIDATE / 'v2-mutant-99000-witness.rs').read_text()
assert original == restored
source_differences = list(difflib.ndiff(original.splitlines(), mutant.splitlines()))
removed = [line[2:] for line in source_differences if line.startswith('- ')]
added = [line[2:] for line in source_differences if line.startswith('+ ')]
assert removed == ['    let expiration = fee_encoded_expiration(fee.fee(amount).msats);',
                   '    let expiration = fee_encoded_expiration(fee.fee(100_000).msats);']
assert added == ['    let expiration = fee_encoded_expiration(contract_amount.msats);'] * 2
for source in (original, (CANDIDATE / 'accounting-sum-corollary.rs').read_text()):
    assert not re.search(r'\b(assume|admit|external_body|axiom|requires)\b', source)
assert 'reported.msats == 99_000' in witness
assert 'assert(accepted is Some);' in witness
assert 'assert(contract_amount.msats == 49_500);' in witness
assert 'assert(computed_fee.msats == 50_500);' in witness
control_sources = {filename.name: digest(filename) for filename in CANDIDATE.glob('*.rs') if filename.read_text()}

provider_reports = {}
expected_imports = []
crate_ids = []
for prefix, crate_name, verified in [('fee', 'lnurl_fee_provider', 55), ('encoding', 'lnurl_encoding_provider', 11)]:
    data = json.loads((OUT / (prefix + '.scope.json')).read_text())
    assert data['verification-results']['verified'] == verified
    inference = data['verus-infer']
    assert inference['verification_scope']['complete_selected_scope_verified']
    assert all(function['required_checks_passed'] for function in inference['functions'])
    assert all(function['metrics']['cache'] == 'miss' and function['metrics']['solver_micros'] > 0
               for function in inference['functions'])
    assert all(function['proofs'][proof]['status'] == 'proved' for function in inference['functions']
               for proof in ('soundness', 'maximality', 'exactness'))
    certificate, fingerprint = metadata((OUT / (prefix + '.vir')).read_bytes())
    assert certificate['schema'] == 38 and certificate['policy'] == 'candidate-bound-evidence-v76'
    assert all(certificate[field] is True for field in ('soundness', 'maximality', 'exactness'))
    assert all(proof[1][field] is True for proof in certificate['proofs']
               for field in ('soundness', 'maximality', 'exactness'))
    identities = {tuple(proof[0]['path']['krate']['Id']) for proof in certificate['proofs']}
    assert len(identities) == 1
    identity = next(iter(identities))
    assert identity[0] == crate_name
    crate_ids.append(identity[1])
    expected_imports.extend(encoding.certificate_import(certificate, fingerprint))
    original_certificate, original_fingerprint = metadata((CANDIDATE / (prefix + '.vir')).read_bytes())
    assert inference['trust'] == json.loads((CANDIDATE / (prefix + '.scope.json')).read_text())['verus-infer']['trust']
    assert inference['trusted_models'] == json.loads((CANDIDATE / (prefix + '.scope.json')).read_text())['verus-infer']['trusted_models']
    provider_reports[prefix] = dict(crate_name=crate_name, crate_id=identity[1],
        certificate_sha256=digest(OUT / (prefix + '.vir')), fingerprint=fingerprint,
        original_fingerprint=original_fingerprint, certificate_matches_candidate=certificate == original_certificate,
        rlib_sha256=digest(OUT / ('lib' + crate_name + '.rlib')),
        rlib_matches_candidate=digest(OUT / ('lib' + crate_name + '.rlib')) == digest(CANDIDATE / ('lib' + crate_name + '.rlib')),
        inferred_function_count=len(inference['functions']), verified_conditions=verified,
        all_required_checks_proved=True, all_cold_cache=True,
        trust=inference['trust'], trusted_models=inference['trusted_models'])
assert len(set(crate_ids)) == 2

expected_scope = {name.replace('fee_provider::', 'lnurl_fee_provider::'): fields
                  for name, fields in validation.expected_native_scope('fee_provider').items()}
actual_scope = json.loads((OUT / 'fee.scope.json').read_text())['verus-infer']['verification_scope']['native_functions']
assert {function['function'] for function in actual_scope} == set(expected_scope)
for function in actual_scope:
    assert all(function[field] == value for field, value in expected_scope[function['function']].items())

attempts = [json.loads(line) for line in (OUT / 'attempts.jsonl').read_text().splitlines()]
assert len(attempts) == 7 and [attempt['attempt'] for attempt in attempts] == list(range(1, 8))
checks = {}
for attempt in attempts:
    label = attempt['label']
    status = json.loads((OUT / (label + '.status.json')).read_text())
    assert status['inputs_unchanged'] and not status['timeout']
    assert attempt['worker_count'] == 1 and attempt['timeout_seconds'] == 60
    assert '--no-cheating' in attempt['argv']
    if label not in ('fee', 'encoding'):
        inference = json.loads((OUT / (label + '.scope.json')).read_text())['verus-infer']
        assert sorted(inference['imported_inference_dependencies'], key=lambda dependency: dependency['crate_id']) == sorted(expected_imports, key=lambda dependency: dependency['crate_id'])
    if label == 'wrong_value':
        stderr = (OUT / (label + '.stderr')).read_text()
        assert status['returncode'] == 1 and status['verification_results']['errors'] == 2
        assert not status['verification_results']['encountered-vir-error']
        assert stderr.count('error: postcondition not satisfied') == 2
        assert ':80:13' in stderr and ':96:13' in stderr
        assert not re.search(r'overflow|resource limit|cannot call|timed out', stderr, re.I)
        assert '--export' not in attempt['argv'] and not status['export_exists']
    else:
        assert status['returncode'] == 0 and status['verification_results']['errors'] == 0
        assert status['scope']['complete_selected_scope_verified']
        assert status['export_exists']
    checks[label] = dict(returncode=status['returncode'], results=status['verification_results'],
                         elapsed_seconds=status['elapsed_seconds'], export_requested=status['export_requested'])

loader_command = ['/usr/bin/otool', '-L', str(Path('/private/tmp/verus-crash-consistency94-20261105/codec-runtime-005/runtime/verus')),
                  str(Path('/private/tmp/verus-crash-consistency94-20261105/codec-runtime-005/runtime/rust_verify')),
                  str(Path(entry['sysroot']) / 'bin/rustc')]
loader_environment = dict(PATH='/usr/bin:/bin', LC_ALL='C', TZ='UTC')
loader_result = subprocess.run(loader_command, env=loader_environment, cwd=OUT, capture_output=True)
(OUT / 'loader.stdout').write_bytes(loader_result.stdout)
(OUT / 'loader.stderr').write_bytes(loader_result.stderr)
write_json('loader.command.json', dict(argv=loader_command, environment=loader_environment,
                                      cwd=str(OUT), returncode=loader_result.returncode,
                                      verifier_application=False))
assert loader_result.returncode == 0
write_json('independent-audit.json', dict(status='PASS FOR CHECKED NUMERIC SLICE; QUALIFIED LOADER BINDING',
    audit_replay_identical=True, implementation_patch_replay_identical=True,
    native_provider_source_regenerated_identically=True, encoder_provider_source_regenerated_identically=True,
    native_item_hashes=selected_hashes, all_control_source_hashes=control_sources,
    restored_byte_identical=True, mutation_only_two_encoder_arguments=True,
    provider_reports=provider_reports, expected_imports=expected_imports, checks=checks,
    historical_applications=11, fresh_charged_applications=7, workers=1, timeout_seconds=60,
    loader_objection=loader_objection,
    unavailable_recovered_native_skills=['linked-specs', 'multipart-review'],
    read_recovered_native_skills=['fedimint-codebase', 'fedimint-development', 'fedimint-coding-style'],
    no_subdelegation=True, no_git_writes=True, no_runtime_builds=True, no_native_app_executions=True,
    compiler_source_correspondence_repaired=False, independent_review='OPEN', redb_cells_open=18,
    acceptance=False, adoption=False, storage=storage(), elapsed_seconds=time.time() - START))
print(json.dumps(dict(independent_audit='PASS FOR NUMERIC SLICE', fresh_applications=7,
    provider_conditions=[55, 11], composition_conditions=10, explicit_sum_conditions=11,
    wrong_value_errors=2, loader_objection='OPEN', storage=storage()), sort_keys=True))
