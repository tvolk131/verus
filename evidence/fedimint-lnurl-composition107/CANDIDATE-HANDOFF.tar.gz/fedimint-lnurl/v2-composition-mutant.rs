use vstd::prelude::*;
use lnurl_fee_provider::{Amount, PaymentFee, fee_math, native_absolute_bound};
use lnurl_encoding_provider::{fee_encoded_expiration, fee_from_expiration};

verus! {

const MAX_SENDABLE_MSAT: u64 = 100_000_000_000;
const MIN_SENDABLE_MSAT: u64 = 100_000;

pub fn checked_event_projection(contract: Amount, expiration: u64)
    -> (result: Option<Amount>)
    ensures
        (result is Some) == (contract.msats <= expiration),
        match result {
            Some(value) => value.msats as int
                == contract.msats as int + (u64::MAX as int - expiration as int),
            None => true,
        },
{
    let decoded = Amount::from_msats(fee_from_expiration(expiration));
    contract.checked_add(decoded)
}

pub fn invoice_accounting(fee: &PaymentFee, amount: u64)
    -> (result: (Amount, u64, u64, Option<Amount>))
    ensures
        result.2 as int == fee_math(fee.base.msats, fee.parts_per_million, amount),
        result.1 as int + result.2 as int == u64::MAX as int,
        result.0.msats as int == if amount >= result.2 {
            amount as int - result.2 as int
        } else { 0 },
        result.0.msats <= result.1,
        match result.3 {
            Some(reported) =>
                reported.msats == if amount >= result.2 { amount } else { result.2 }
                && ((reported.msats == amount) == (result.2 <= amount)),
            None => false,
        },
{
    let contract_amount = fee.subtract_from(amount);
    let expiration = fee_encoded_expiration(fee.fee(amount).msats);
    let recovered = fee_from_expiration(expiration);
    let reported = checked_event_projection(contract_amount, expiration);
    (contract_amount, expiration, recovered, reported)
}

pub fn source_guarded_receipt(fee: &PaymentFee, amount: u64)
    -> (result: Option<(Amount, u64, u64, Amount)>)
    ensures
        (result is Some) == (
            100_000 <= amount && amount <= 100_000_000_000
            && fee.base.msats <= 50_000 && fee.parts_per_million <= 5_000
        ),
        match result {
            Some(receipt) => receipt.0.msats >= 49_500
                && receipt.2 as int == fee_math(fee.base.msats, fee.parts_per_million, amount)
                && receipt.1 as int + receipt.2 as int == u64::MAX as int
                && receipt.0.msats as int + receipt.2 as int == amount as int
                && receipt.3.msats == amount,
            None => true,
        },
{
    if amount < MIN_SENDABLE_MSAT || amount > MAX_SENDABLE_MSAT {
        return None;
    }
    if !fee.is_within(&PaymentFee::RECEIVE_FEE_LIMIT) {
        return None;
    }
    let bounds = native_absolute_bound(fee, &PaymentFee::RECEIVE_FEE_LIMIT, amount);
    assert(fee_math(50_000, 5_000, amount) <= amount as int - 49_500);
    let receipt = invoice_accounting(fee, amount);
    match receipt.3 {
        Some(reported) => Some((receipt.0, receipt.1, receipt.2, reported)),
        None => None,
    }
}

pub fn policy_accounting_probe(fee: &PaymentFee, amount: u64)
    -> (result: Option<Amount>)
    ensures match result { Some(reported) => reported.msats == amount, None => true },
{
    if amount < MIN_SENDABLE_MSAT || amount > MAX_SENDABLE_MSAT {
        return None;
    }
    if !fee.is_within(&PaymentFee::RECEIVE_FEE_LIMIT) {
        return None;
    }
    let bounds = native_absolute_bound(fee, &PaymentFee::RECEIVE_FEE_LIMIT, amount);
    assert(fee_math(50_000, 5_000, amount) <= amount as int - 49_500);
    let contract_amount = fee.subtract_from(amount);
    let expiration = fee_encoded_expiration(contract_amount.msats);
    checked_event_projection(contract_amount, expiration)
}

pub fn accepted_witness() -> (result: Option<Amount>)
    ensures match result { Some(reported) => reported.msats == 100_000, None => false },
{
    let fee = PaymentFee { base: Amount { msats: 50_000 }, parts_per_million: 5_000 };
    let accepted = source_guarded_receipt(&fee, 100_000);
    assert(accepted is Some);
    let contract_amount = fee.subtract_from(100_000);
    assert(contract_amount.msats == 49_500);
    let computed_fee = fee.fee(100_000);
    assert(computed_fee.msats == 50_500);
    let expiration = fee_encoded_expiration(contract_amount.msats);
    checked_event_projection(contract_amount, expiration)
}

pub fn receiver_boundaries() -> (result: (Option<Amount>, Option<Amount>, Option<Amount>))
    ensures result.0 is None,
        match result.1 { Some(value) => value.msats == u64::MAX, None => false },
        match result.2 { Some(value) => value.msats == u64::MAX, None => false },
{
    (checked_event_projection(Amount { msats: u64::MAX }, 0),
     checked_event_projection(Amount { msats: u64::MAX }, u64::MAX),
     checked_event_projection(Amount { msats: 0 }, 0))
}

pub fn fee_exceeds_invoice_witness() -> (result: Option<Amount>)
    ensures match result { Some(value) => value.msats == 1, None => false },
{
    let fee = PaymentFee { base: Amount { msats: 1 }, parts_per_million: 0 };
    invoice_accounting(&fee, 0).3
}

pub fn saturation_witnesses() -> (result: (Option<Amount>, Option<Amount>, Option<Amount>))
    ensures
        match result.0 { Some(value) => value.msats == u64::MAX, None => false },
        match result.1 { Some(value) => value.msats == u64::MAX, None => false },
        match result.2 { Some(value) => value.msats == 0, None => false },
{
    let maximal = PaymentFee { base: Amount { msats: u64::MAX }, parts_per_million: u64::MAX };
    let zero = PaymentFee { base: Amount { msats: 0 }, parts_per_million: 0 };
    (invoice_accounting(&maximal, u64::MAX).3,
     invoice_accounting(&maximal, 0).3,
     invoice_accounting(&zero, 0).3)
}

}
