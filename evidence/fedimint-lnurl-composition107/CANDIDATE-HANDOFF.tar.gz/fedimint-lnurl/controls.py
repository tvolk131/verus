import difflib
import hashlib
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
sys.path.insert(0, '/Users/tommyvolk/.t3/worktrees/verus/t3-60978068/source/tools')

def item(source, marker):
    start = source.index(marker)
    end = source.find('\npub fn ', start + len(marker))
    assert end >= 0, 'control target must precede another function'
    return source[start:end]

OUT = Path(__file__).resolve().parent
original = (OUT / 'composition.rs').read_text()
assert not (OUT / 'v2-composition-mutant.rs').exists(), 'controls are immutable'
mutant = original
for marker in ('pub fn policy_accounting_probe(', 'pub fn accepted_witness('):
    selected = item(mutant, marker)
    changed = selected.replace('fee_encoded_expiration(fee.fee(amount).msats)',
                               'fee_encoded_expiration(contract_amount.msats)')
    changed = changed.replace('fee_encoded_expiration(fee.fee(100_000).msats)',
                              'fee_encoded_expiration(contract_amount.msats)')
    assert selected != changed
    mutant = mutant.replace(selected, changed, 1)
(OUT / 'v2-composition-mutant.rs').write_text(mutant)
wrong_witness = mutant.replace('Some(reported) => reported.msats == amount, None => true',
                               'Some(reported) => true, None => true', 1)
wrong_witness = wrong_witness.replace('Some(reported) => reported.msats == 100_000, None => false',
                                     'Some(reported) => reported.msats == 99_000, None => false', 1)
(OUT / 'v2-mutant-99000-witness.rs').write_text(wrong_witness)
restored = mutant
for marker in ('pub fn policy_accounting_probe(', 'pub fn accepted_witness('):
    restored = restored.replace(item(restored, marker), item(original, marker), 1)
assert restored == original
(OUT / 'v2-composition-restored.rs').write_text(restored)
false_goal = '''
pub fn false_unconditional_conservation() -> (result: Option<Amount>)
    ensures match result { Some(value) => value.msats == 0, None => false },
{
    let fee = PaymentFee { base: Amount { msats: 1 }, parts_per_million: 0 };
    invoice_accounting(&fee, 0).3
}
'''
(OUT / 'v2-false-conservation.rs').write_text(original.rsplit('}', 1)[0] + false_goal + '}\n')
overflow_goal = '''
pub fn false_receiver_totality() -> (result: Option<Amount>)
    ensures result is Some,
{
    checked_event_projection(Amount { msats: u64::MAX }, 0)
}
'''
(OUT / 'v2-false-receiver-totality.rs').write_text(original.rsplit('}', 1)[0] + overflow_goal + '}\n')
local = original.replace('use lnurl_fee_provider::{Amount, PaymentFee, fee_math, native_absolute_bound};\n', '')
local = local.replace('use lnurl_encoding_provider::{fee_encoded_expiration, fee_from_expiration};\n', '')
(OUT / 'v2-composition-local.rs').write_text((OUT / 'fee-provider.rs').read_text()
    + (OUT / 'encoding-provider.rs').read_text().replace('use vstd::prelude::*;\n', '')
    + local.replace('use vstd::prelude::*;\n', ''))
record = dict(original_sha256=hashlib.sha256(original.encode()).hexdigest(),
              restored_sha256=hashlib.sha256(restored.encode()).hexdigest(),
              byte_identical=original == restored,
              negative_changes_only=['policy_accounting_probe expiration argument',
                                     'accepted_witness expiration argument'],
              unrestricted_core_unchanged=item(original, 'pub fn invoice_accounting(')
                  == item(mutant, 'pub fn invoice_accounting('),
              independent_receiver_unchanged=item(original, 'pub fn checked_event_projection(')
                  == item(mutant, 'pub fn checked_event_projection('))
(OUT / 'controls-v2.json').write_text(json.dumps(record, indent=2) + '\n')
(OUT / 'semantic-mutation-v2.patch').write_text(''.join(difflib.unified_diff(
    original.splitlines(keepends=True), mutant.splitlines(keepends=True),
    fromfile='composition.rs', tofile='composition-mutant.rs')))
print(json.dumps(record, sort_keys=True))
