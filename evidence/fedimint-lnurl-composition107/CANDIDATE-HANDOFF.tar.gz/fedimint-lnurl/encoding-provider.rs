use vstd::prelude::*;
verus! {
#[verifier::infer]
pub fn fee_encoded_expiration(fee_msats: u64) -> u64 {
    u64::MAX - fee_msats
}
#[verifier::infer]
pub fn fee_from_expiration(expiration: u64) -> u64 {
    u64::MAX - expiration
}

pub fn fee_roundtrip(fee: u64) -> (recovered: u64)
    ensures recovered == fee,
{ fee_from_expiration(fee_encoded_expiration(fee)) }

pub fn expiration_roundtrip(expiration: u64) -> (recovered: u64)
    ensures recovered == expiration,
{ fee_encoded_expiration(fee_from_expiration(expiration)) }

pub fn expiration_order(left: u64, right: u64) -> (encoded: (u64, u64))
    ensures (left <= right) == (encoded.0 >= encoded.1),
        (left == right) == (encoded.0 == encoded.1),
{ (fee_encoded_expiration(left), fee_encoded_expiration(right)) }

pub fn future_expiration(fee: u64, now: u64) -> (expiration: u64)
    ensures (expiration > now) == ((fee as int) + (now as int) < u64::MAX),
{ fee_encoded_expiration(fee) }

pub fn encoding_boundaries() -> (encoded: (u64, u64))
    ensures encoded.0 == u64::MAX, encoded.1 == 0,
{ (fee_encoded_expiration(0), fee_encoded_expiration(u64::MAX)) }
}
