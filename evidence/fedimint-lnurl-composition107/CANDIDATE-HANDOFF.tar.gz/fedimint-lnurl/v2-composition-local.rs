use vstd::prelude::*;
#[verus_verify(infer_derive(PartialEq,PartialOrd,Ord))]
#[derive(Clone,Copy,Eq,PartialEq,Ord,PartialOrd)]
pub struct Amount {
    // TODO: rename to `units`, with backward compat for the serialization?
    pub msats: u64,
}
#[verus_verify]
#[derive(Copy,Clone)]
pub struct PaymentFee {
    pub base: Amount,
    pub parts_per_million: u64,
}
#[verus_verify]
impl Amount {
#[verus_infer]
pub const fn from_msats(msats: u64) -> Self {
        Self { msats }
    }
#[verus_infer]
pub const fn from_sats(sats: u64) -> Self {
        Self::from_msats(sats * 1000)
    }
#[verus_infer]
pub fn checked_add(self, other: Self) -> Option<Self> {
        Some(Self {
            msats: self.msats.checked_add(other.msats)?,
        })
    }
}
#[verus_verify]
impl PaymentFee {
#[verus_spec(ensures Self::SEND_FEE_LIMIT.base.msats==100_000, Self::SEND_FEE_LIMIT.parts_per_million==15_000)]
pub const SEND_FEE_LIMIT: PaymentFee = PaymentFee {
        base: Amount::from_sats(100),
        parts_per_million: 15_000,
    };
#[verus_spec(ensures Self::RECEIVE_FEE_LIMIT.base.msats==50_000, Self::RECEIVE_FEE_LIMIT.parts_per_million==5_000)]
pub const RECEIVE_FEE_LIMIT: PaymentFee = PaymentFee {
        base: Amount::from_sats(50),
        parts_per_million: 5_000,
    };
#[verus_infer]
pub fn checked_add(self, rhs: Self) -> Option<PaymentFee> {
        Some(PaymentFee {
            base: self.base.checked_add(rhs.base)?,
            parts_per_million: self.parts_per_million.checked_add(rhs.parts_per_million)?,
        })
    }
#[verus_infer]
pub fn is_within(&self, limit: &PaymentFee) -> bool {
        self.base <= limit.base && self.parts_per_million <= limit.parts_per_million
    }
#[verus_infer]
fn absolute_fee(&self, msats: u64) -> u64 {
        // The base fee is bounded well below `u64::MAX` for any fee that passed
        // the limit checks, but a fee decoded from an older database has not
        // necessarily passed them, so saturate rather than panic.
        msats
            .saturating_mul(self.parts_per_million)
            .saturating_div(1_000_000)
            .saturating_add(self.base.msats)
    }
#[verus_infer]
pub fn fee(&self, msats: u64) -> Amount {
        Amount::from_msats(self.absolute_fee(msats))
    }
#[verus_infer]
pub fn add_to(&self, msats: u64) -> Amount {
        Amount::from_msats(msats.saturating_add(self.absolute_fee(msats)))
    }
#[verus_infer]
pub fn subtract_from(&self, msats: u64) -> Amount {
        Amount::from_msats(msats.saturating_sub(self.absolute_fee(msats)))
    }
}
verus! {

pub open spec fn cap(value:int)->int {
    if value > u64::MAX { u64::MAX as int } else { value }
}
pub open spec fn fee_math(base:u64, ppm:u64, amount:u64)->int {
    cap(cap((amount as int)*(ppm as int))/1_000_000 + (base as int))
}

pub fn exact_fee(fee:&PaymentFee, amount:u64)->(result:Amount)
    ensures result.msats as int == fee_math(fee.base.msats,fee.parts_per_million,amount),
{ fee.fee(amount) }

pub fn no_overflow(fee:&PaymentFee, amount:u64)->(result:Amount)
    requires (amount as int)*(fee.parts_per_million as int) <= u64::MAX,
        (amount as int)*(fee.parts_per_million as int)/1_000_000 + (fee.base.msats as int) <= u64::MAX,
    ensures result.msats as int == (amount as int)*(fee.parts_per_million as int)/1_000_000
        + (fee.base.msats as int),
{ fee.fee(amount) }

pub fn base_floor(fee:&PaymentFee, amount:u64)->(result:Amount)
    ensures result.msats >= fee.base.msats,
{ fee.fee(amount) }

pub fn add_bound(fee:&PaymentFee, amount:u64)->(result:Amount)
    ensures result.msats >= amount,
        result.msats as int == cap((amount as int)+fee_math(fee.base.msats,fee.parts_per_million,amount)),
{ fee.add_to(amount) }

pub fn subtract_bound(fee:&PaymentFee, amount:u64)->(result:Amount)
    ensures result.msats <= amount,
        result.msats as int == if (amount as int) < fee_math(fee.base.msats,fee.parts_per_million,amount)
            {0} else {(amount as int)-fee_math(fee.base.msats,fee.parts_per_million,amount)},
{ fee.subtract_from(amount) }

pub fn zero_fee(amount:u64)->(result:(Amount,Amount,Amount))
    ensures result.0.msats==0, result.1.msats==amount, result.2.msats==amount,
{
    let fee=PaymentFee {base:Amount {msats:0},parts_per_million:0};
    (fee.fee(amount),fee.add_to(amount),fee.subtract_from(amount))
}

pub fn saturation_endpoints()->(result:(Amount,Amount,Amount,Amount))
    ensures result.0.msats==u64::MAX/1_000_000,
        result.1.msats==u64::MAX, result.2.msats==u64::MAX, result.3.msats==0,
{
    let product=PaymentFee {base:Amount {msats:0},parts_per_million:u64::MAX};
    let base=PaymentFee {base:Amount {msats:u64::MAX},parts_per_million:1};
    (product.fee(u64::MAX),base.fee(u64::MAX),base.add_to(1),base.subtract_from(1))
}

#[verifier::nonlinear]
pub fn component_limit(lower:&PaymentFee, upper:&PaymentFee, amount:u64)->(result:(Amount,Amount))
    requires lower.base.msats<=upper.base.msats,
        lower.parts_per_million<=upper.parts_per_million,
    ensures result.0.msats<=result.1.msats,
result.0.msats as int==fee_math(lower.base.msats,lower.parts_per_million,amount),
result.1.msats as int==fee_math(upper.base.msats,upper.parts_per_million,amount),
{ (lower.fee(amount),upper.fee(amount)) }

#[verifier::nonlinear]
pub fn amount_monotone(fee:&PaymentFee, lower:u64, upper:u64)->(result:(Amount,Amount))
    requires lower<=upper,
    ensures result.0.msats<=result.1.msats,
{ (fee.fee(lower),fee.fee(upper)) }

pub fn add_unsaturated(fee:&PaymentFee,amount:u64)->(result:Amount)
    requires (amount as int)+fee_math(fee.base.msats,fee.parts_per_million,amount)<=u64::MAX,
    ensures result.msats as int==(amount as int)+fee_math(fee.base.msats,fee.parts_per_million,amount),
{fee.add_to(amount)}

pub fn subtract_recovery(fee:&PaymentFee,amount:u64)->(result:Amount)
    requires fee_math(fee.base.msats,fee.parts_per_million,amount)<=amount,
    ensures (result.msats as int)+fee_math(fee.base.msats,fee.parts_per_million,amount)==amount,
{fee.subtract_from(amount)}

pub open spec fn send_limit_math()->PaymentFee {
    PaymentFee {base:Amount {msats:100_000},parts_per_million:15_000}
}
pub open spec fn receive_limit_math()->PaymentFee {
    PaymentFee {base:Amount {msats:50_000},parts_per_million:5_000}
}
pub fn amount_sum_intent(left:Amount,right:Amount)->(result:Option<Amount>)
    ensures match result {
        None => (left.msats as int)+(right.msats as int)>u64::MAX,
        Some(sum) => sum.msats as int==(left.msats as int)+(right.msats as int),
    },
{ left.checked_add(right) }
pub open spec fn decision_math(lightning:PaymentFee,transaction:PaymentFee,
    send_limit:PaymentFee,receive_limit:PaymentFee)->u8 {
    if (lightning.base.msats as int)+(transaction.base.msats as int)>u64::MAX ||
        (lightning.parts_per_million as int)+(transaction.parts_per_million as int)>u64::MAX {0}
    else if (lightning.base.msats as int)+(transaction.base.msats as int)>send_limit.base.msats ||
        (lightning.parts_per_million as int)+(transaction.parts_per_million as int)>send_limit.parts_per_million {1}
    else if transaction.base.msats>receive_limit.base.msats ||
        transaction.parts_per_million>receive_limit.parts_per_million {2}
    else {3}
}

pub fn checked_sum_intent(left:PaymentFee,right:PaymentFee)->(result:Option<PaymentFee>)
    ensures match result {
        None => (left.base.msats as int)+(right.base.msats as int)>u64::MAX ||
            (left.parts_per_million as int)+(right.parts_per_million as int)>u64::MAX,
        Some(sum) => sum.base.msats as int==(left.base.msats as int)+(right.base.msats as int) &&
            sum.parts_per_million as int==(left.parts_per_million as int)+(right.parts_per_million as int),
    },
{ left.checked_add(right) }

pub fn native_limit_intent(value:&PaymentFee,limit:&PaymentFee)->(result:bool)
    ensures result==(value.base.msats<=limit.base.msats && value.parts_per_million<=limit.parts_per_million),
{ value.is_within(limit) }

pub fn native_limit_equality(value:&PaymentFee)->(result:bool)
    ensures result,
{ value.is_within(value) }

pub fn validate_fee_pair(lightning:PaymentFee,transaction:PaymentFee,
    send_limit:&PaymentFee,receive_limit:&PaymentFee)->(result:(u8,Option<PaymentFee>))
    ensures result.0==decision_math(lightning,transaction,*send_limit,*receive_limit),
        (result.0==3)==(result.1 is Some),
        match result.1 {
            None => true,
            Some(sum) => sum.base.msats as int==(lightning.base.msats as int)+(transaction.base.msats as int) &&
                sum.parts_per_million as int==(lightning.parts_per_million as int)+(transaction.parts_per_million as int) &&
                sum.base.msats<=send_limit.base.msats && sum.parts_per_million<=send_limit.parts_per_million &&
                transaction.base.msats<=receive_limit.base.msats && transaction.parts_per_million<=receive_limit.parts_per_million,
        },
{
    let send_fees=match lightning.checked_add(transaction) {
        None => return (0,None),
        Some(sum) => sum,
    };
    if !send_fees.is_within(send_limit) { return (1,None); }
    if !transaction.is_within(receive_limit) { return (2,None); }
    (3,Some(send_fees))
}

pub fn native_absolute_bound(lower:&PaymentFee,upper:&PaymentFee,amount:u64)->(result:(u64,u64))
    requires lower.base.msats<=upper.base.msats, lower.parts_per_million<=upper.parts_per_million,
    ensures result.0<=result.1,
        result.0 as int==fee_math(lower.base.msats,lower.parts_per_million,amount),
        result.1 as int==fee_math(upper.base.msats,upper.parts_per_million,amount),
{
    let semantic_bound=component_limit(lower,upper,amount);
    (lower.absolute_fee(amount),upper.absolute_fee(amount))
}

pub fn accepted_fee_bound(lightning:PaymentFee,transaction:PaymentFee,
    send_limit:&PaymentFee,receive_limit:&PaymentFee,amount:u64)->(result:Option<(u64,u64,u64,u64)>)
    ensures (result is Some)==(decision_math(lightning,transaction,*send_limit,*receive_limit)==3),
        match result {None => true,Some(fees) => fees.0<=fees.1 && fees.2<=fees.3},
{
    let decision=validate_fee_pair(lightning,transaction,send_limit,receive_limit);
    match decision.1 {
        None => None,
        Some(sum) => {
            let send=native_absolute_bound(&sum,send_limit,amount);
            let receive=native_absolute_bound(&transaction,receive_limit,amount);
            Some((send.0,send.1,receive.0,receive.1))
        },
    }
}

pub fn native_gateway_boundary(lightning:PaymentFee,transaction:PaymentFee,amount:u64)
    ->(result:Option<(u64,u64,u64,u64)>)
    ensures (result is Some)==(decision_math(lightning,transaction,
        send_limit_math(),receive_limit_math())==3),
        match result {None => true,Some(fees) => fees.0<=fees.1 && fees.2<=fees.3},
{ accepted_fee_bound(lightning,transaction,&PaymentFee::SEND_FEE_LIMIT,&PaymentFee::RECEIVE_FEE_LIMIT,amount) }

}
verus! {
#[verifier::infer]
pub fn fee_encoded_expiration(fee_msats: u64) -> u64 {
    u64::MAX - fee_msats
}
#[verifier::infer]
pub fn fee_from_expiration(expiration: u64) -> u64 {
    u64::MAX - expiration
}

pub fn fee_roundtrip(fee: u64) -> (recovered: u64)
    ensures recovered == fee,
{ fee_from_expiration(fee_encoded_expiration(fee)) }

pub fn expiration_roundtrip(expiration: u64) -> (recovered: u64)
    ensures recovered == expiration,
{ fee_encoded_expiration(fee_from_expiration(expiration)) }

pub fn expiration_order(left: u64, right: u64) -> (encoded: (u64, u64))
    ensures (left <= right) == (encoded.0 >= encoded.1),
        (left == right) == (encoded.0 == encoded.1),
{ (fee_encoded_expiration(left), fee_encoded_expiration(right)) }

pub fn future_expiration(fee: u64, now: u64) -> (expiration: u64)
    ensures (expiration > now) == ((fee as int) + (now as int) < u64::MAX),
{ fee_encoded_expiration(fee) }

pub fn encoding_boundaries() -> (encoded: (u64, u64))
    ensures encoded.0 == u64::MAX, encoded.1 == 0,
{ (fee_encoded_expiration(0), fee_encoded_expiration(u64::MAX)) }
}

verus! {

const MAX_SENDABLE_MSAT: u64 = 100_000_000_000;
const MIN_SENDABLE_MSAT: u64 = 100_000;

pub fn checked_event_projection(contract: Amount, expiration: u64)
    -> (result: Option<Amount>)
    ensures
        (result is Some) == (contract.msats <= expiration),
        match result {
            Some(value) => value.msats as int
                == contract.msats as int + (u64::MAX as int - expiration as int),
            None => true,
        },
{
    let decoded = Amount::from_msats(fee_from_expiration(expiration));
    contract.checked_add(decoded)
}

pub fn invoice_accounting(fee: &PaymentFee, amount: u64)
    -> (result: (Amount, u64, u64, Option<Amount>))
    ensures
        result.2 as int == fee_math(fee.base.msats, fee.parts_per_million, amount),
        result.1 as int + result.2 as int == u64::MAX as int,
        result.0.msats as int == if amount >= result.2 {
            amount as int - result.2 as int
        } else { 0 },
        result.0.msats <= result.1,
        match result.3 {
            Some(reported) =>
                reported.msats == if amount >= result.2 { amount } else { result.2 }
                && ((reported.msats == amount) == (result.2 <= amount)),
            None => false,
        },
{
    let contract_amount = fee.subtract_from(amount);
    let expiration = fee_encoded_expiration(fee.fee(amount).msats);
    let recovered = fee_from_expiration(expiration);
    let reported = checked_event_projection(contract_amount, expiration);
    (contract_amount, expiration, recovered, reported)
}

pub fn source_guarded_receipt(fee: &PaymentFee, amount: u64)
    -> (result: Option<(Amount, u64, u64, Amount)>)
    ensures
        (result is Some) == (
            100_000 <= amount && amount <= 100_000_000_000
            && fee.base.msats <= 50_000 && fee.parts_per_million <= 5_000
        ),
        match result {
            Some(receipt) => receipt.0.msats >= 49_500
                && receipt.2 as int == fee_math(fee.base.msats, fee.parts_per_million, amount)
                && receipt.1 as int + receipt.2 as int == u64::MAX as int
                && receipt.0.msats as int + receipt.2 as int == amount as int
                && receipt.3.msats == amount,
            None => true,
        },
{
    if amount < MIN_SENDABLE_MSAT || amount > MAX_SENDABLE_MSAT {
        return None;
    }
    if !fee.is_within(&PaymentFee::RECEIVE_FEE_LIMIT) {
        return None;
    }
    let bounds = native_absolute_bound(fee, &PaymentFee::RECEIVE_FEE_LIMIT, amount);
    assert(fee_math(50_000, 5_000, amount) <= amount as int - 49_500);
    let receipt = invoice_accounting(fee, amount);
    match receipt.3 {
        Some(reported) => Some((receipt.0, receipt.1, receipt.2, reported)),
        None => None,
    }
}

pub fn policy_accounting_probe(fee: &PaymentFee, amount: u64)
    -> (result: Option<Amount>)
    ensures match result { Some(reported) => reported.msats == amount, None => true },
{
    if amount < MIN_SENDABLE_MSAT || amount > MAX_SENDABLE_MSAT {
        return None;
    }
    if !fee.is_within(&PaymentFee::RECEIVE_FEE_LIMIT) {
        return None;
    }
    let bounds = native_absolute_bound(fee, &PaymentFee::RECEIVE_FEE_LIMIT, amount);
    assert(fee_math(50_000, 5_000, amount) <= amount as int - 49_500);
    let contract_amount = fee.subtract_from(amount);
    let expiration = fee_encoded_expiration(fee.fee(amount).msats);
    checked_event_projection(contract_amount, expiration)
}

pub fn accepted_witness() -> (result: Option<Amount>)
    ensures match result { Some(reported) => reported.msats == 100_000, None => false },
{
    let fee = PaymentFee { base: Amount { msats: 50_000 }, parts_per_million: 5_000 };
    let accepted = source_guarded_receipt(&fee, 100_000);
    assert(accepted is Some);
    let contract_amount = fee.subtract_from(100_000);
    assert(contract_amount.msats == 49_500);
    let computed_fee = fee.fee(100_000);
    assert(computed_fee.msats == 50_500);
    let expiration = fee_encoded_expiration(fee.fee(100_000).msats);
    checked_event_projection(contract_amount, expiration)
}

pub fn receiver_boundaries() -> (result: (Option<Amount>, Option<Amount>, Option<Amount>))
    ensures result.0 is None,
        match result.1 { Some(value) => value.msats == u64::MAX, None => false },
        match result.2 { Some(value) => value.msats == u64::MAX, None => false },
{
    (checked_event_projection(Amount { msats: u64::MAX }, 0),
     checked_event_projection(Amount { msats: u64::MAX }, u64::MAX),
     checked_event_projection(Amount { msats: 0 }, 0))
}

pub fn fee_exceeds_invoice_witness() -> (result: Option<Amount>)
    ensures match result { Some(value) => value.msats == 1, None => false },
{
    let fee = PaymentFee { base: Amount { msats: 1 }, parts_per_million: 0 };
    invoice_accounting(&fee, 0).3
}

pub fn saturation_witnesses() -> (result: (Option<Amount>, Option<Amount>, Option<Amount>))
    ensures
        match result.0 { Some(value) => value.msats == u64::MAX, None => false },
        match result.1 { Some(value) => value.msats == u64::MAX, None => false },
        match result.2 { Some(value) => value.msats == 0, None => false },
{
    let maximal = PaymentFee { base: Amount { msats: u64::MAX }, parts_per_million: u64::MAX };
    let zero = PaymentFee { base: Amount { msats: 0 }, parts_per_million: 0 };
    (invoice_accounting(&maximal, u64::MAX).3,
     invoice_accounting(&maximal, 0).3,
     invoice_accounting(&zero, 0).3)
}

}
