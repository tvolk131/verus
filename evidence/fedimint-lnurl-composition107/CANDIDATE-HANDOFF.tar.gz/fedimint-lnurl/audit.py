import difflib
import hashlib
import json
from pathlib import Path
import re
import sys

sys.dont_write_bytecode = True
sys.path.insert(0, '/Users/tommyvolk/.t3/worktrees/verus/t3-60978068/source/tools')
import check_fedimint_validation81 as validation
import check_fedimint_fee_encoding as encoding
from infer_transfer_receipts import metadata

OUT = Path(__file__).resolve().parent
NATIVE = Path('/private/tmp/verus-crash-consistency94-20261105/native-leaf-lookup-007/recovered-native/fedimint')


def load(filename):
    return json.loads((OUT / filename).read_text())


def digest(filename):
    return hashlib.sha256(Path(filename).read_bytes()).hexdigest()


positive = ('fee', 'encoding', 'composition02', 'local', 'mutant_witness', 'restored', 'explicit_sum')
negative = dict(mutant=2, false_conservation=1, false_receiver=1)
attempts = [json.loads(line) for line in (OUT / 'attempts.jsonl').read_text().splitlines()]
assert len(attempts) == 11
assert [attempt['attempt'] for attempt in attempts] == list(range(1, 12))
for attempt in attempts:
    label = attempt['label']
    status = load(label + '.status.json')
    assert status['inputs_unchanged'] and not status['timeout']
    actual_source = Path(attempt['argv'][1])
    if label == 'composition':
        actual_source = OUT / 'composition-attempt03.rs'
    assert digest(actual_source) == attempt['source_sha256']
    assert attempt['environment']['CARGO_BUILD_JOBS'] == '1'
    assert attempt['argv'][attempt['argv'].index('--num-threads') + 1] == '1'
    assert '--no-cheating' in attempt['argv']
    if label in positive:
        assert status['returncode'] == 0 and status['export_exists']
        results = status['verification_results']
        assert results['success'] and results['errors'] == 0 and results['is-verifying-entire-crate']
        assert status['scope']['complete_selected_scope_verified']
    elif label in negative:
        assert status['returncode'] == 1 and not status['export_exists']
        assert status['verification_results']['errors'] == negative[label]
        assert not status['verification_results']['encountered-vir-error']
        stderr = (OUT / (label + '.stderr')).read_text()
        assert stderr.count('error: postcondition not satisfied') == negative[label]
        assert 'overflow' not in stderr and 'resource limit' not in stderr
    else:
        assert label == 'composition' and status['returncode'] == 1 and not status['export_exists']
        assert 'cannot call function' in (OUT / (label + '.stderr')).read_text()

expected_scope = validation.expected_native_scope('fee_provider')
expected_scope = {name.replace('fee_provider::', 'lnurl_fee_provider::'): fields
                  for name, fields in expected_scope.items()}
fee_data = load('fee.scope.json')['verus-infer']
actual_scope = fee_data['verification_scope']['native_functions']
assert {entry['function'] for entry in actual_scope} == set(expected_scope)
for entry in actual_scope:
    assert all(entry[field] == value for field, value in expected_scope[entry['function']].items())
for prefix in ('fee', 'encoding'):
    inference = load(prefix + '.scope.json')['verus-infer']
    for function in inference['functions']:
        assert function['required_checks_passed']
        assert function['metrics']['solver_micros'] > 0
        assert all(function['proofs'][proof]['status'] == 'proved'
                   for proof in ('soundness', 'maximality', 'exactness'))

certificates = {}
expected_imports = []
for prefix, name in [('fee', 'lnurl_fee_provider'), ('encoding', 'lnurl_encoding_provider')]:
    certificate, fingerprint = metadata((OUT / (prefix + '.vir')).read_bytes())
    assert certificate['schema'] == 38 and certificate['policy'] == 'candidate-bound-evidence-v76'
    assert all(certificate[key] is True for key in ('soundness', 'maximality', 'exactness'))
    assert all(entry[1][key] is True for entry in certificate['proofs']
               for key in ('soundness', 'maximality', 'exactness'))
    identities = {tuple(entry[0]['path']['krate']['Id']) for entry in certificate['proofs']}
    assert len(identities) == 1
    identity = next(iter(identities))
    assert identity[0] == name
    expected_imports += encoding.certificate_import(certificate, fingerprint)
    certificates[prefix] = dict(crate_name=name, crate_id=identity[1], fingerprint=fingerprint,
                                certificate=certificate)
assert certificates['fee']['crate_id'] != certificates['encoding']['crate_id']
for label in ('composition02', 'mutant', 'mutant_witness', 'restored', 'explicit_sum',
              'false_conservation', 'false_receiver'):
    imports = load(label + '.scope.json')['verus-infer']['imported_inference_dependencies']
    assert sorted(imports, key=lambda entry: entry['crate_id']) == sorted(expected_imports, key=lambda entry: entry['crate_id'])

recovery = json.loads((NATIVE.parent.parent / 'recovery.json').read_text())
recorded = recovery['repositories']['fedimint']
assert recorded['pin'] == validation.PIN
native = {}
for relative in sorted(set(validation.SOURCE_HASHES) | set(encoding.SOURCE_HASHES)):
    data = (NATIVE / relative).read_bytes()
    actual = dict(size_bytes=len(data), sha256=hashlib.sha256(data).hexdigest(),
                  git_blob=hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest())
    assert actual == recorded['blobs'][relative]
    native[relative] = actual

controls = load('controls-v2.json')
assert controls['byte_identical'] and controls['unrestricted_core_unchanged'] and controls['independent_receiver_unchanged']
assert (OUT / 'composition.rs').read_bytes() == (OUT / 'v2-composition-restored.rs').read_bytes()
for filename in ('composition.rs', 'accounting-sum-corollary.rs'):
    source = (OUT / filename).read_text()
    assert not re.search(r'\b(assume|admit|external_body|axiom|requires)\b', source)

report = dict(direct_applications=len(attempts), positive=list(positive), semantic_negatives=negative,
              retained_frontend_failure='composition', native_scope_matches_existing_generator=True,
              certificates=certificates, authenticated_recovered_native=native, controls=controls,
              source_content_only=True, compiler_source_correspondence_repaired=False,
              redb_cells_open=18, acceptance=False, adoption=False)
(OUT / 'audit.json').write_text(json.dumps(report, sort_keys=True, indent=2) + '\n')
files = ('composition.rs', 'accounting-sum-corollary.rs', 'fee-provider.rs', 'encoding-provider.rs',
         'run.py', 'controls.py', 'audit.py')
patch = []
for filename in files:
    lines = (OUT / filename).read_text().splitlines(keepends=True)
    patch.extend(difflib.unified_diff([], lines, fromfile='/dev/null', tofile='candidate/' + filename))
(OUT / 'implementation.patch').write_text(''.join(patch))
print(json.dumps(dict(audit='PASS', applications=len(attempts), positives=len(positive),
                     semantic_negatives=len(negative), frontend_failures=1), sort_keys=True))
