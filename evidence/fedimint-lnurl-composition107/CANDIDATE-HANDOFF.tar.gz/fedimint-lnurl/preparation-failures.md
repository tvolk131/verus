# Retained preparation failures

No verifier applications occurred in these failures.

1. A read command used the zsh special variable `path` as a loop variable.
   This changed that shell's PATH, so sed/cat/ls returned command-not-found,
   overall status 127. A new shell repeated the read using `skill_file`.
2. Initial `python3 -B run.py prepare` returned 1 after recording
   `entry-authentication.json`: recovery.json was addressed one directory too
   shallow. The FileNotFoundError named recovered-native/recovery.json.
   That initial authentication file is retained unchanged. The corrected
   preparation uses the actual recovery path and a new, separately named
   entry-authentication-02.json. No attempt ledger was reset or discarded.
3. Initial `python3 -B controls.py` returned 1 at `assert selected != changed`.
   The reused native-item extractor ended at a brace inside an authored
   postcondition, before reaching its body. No control file had been written.
   The corrected control generator selects the whole authored function up to
   the following function, and retains unchanged original/provider extractors.
