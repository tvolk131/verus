include!("composition.rs");

verus! {

pub fn full_domain_sum(fee: &PaymentFee, amount: u64)
    -> (result: (u64, u64, u64))
    ensures
        result.1 as int == fee_math(fee.base.msats, fee.parts_per_million, amount),
        result.0 as int + result.1 as int == result.2 as int,
        result.2 == if amount >= result.1 { amount } else { result.1 },
        (result.2 == amount) == (result.1 <= amount),
{
    let receipt = invoice_accounting(fee, amount);
    let maximum = if amount >= receipt.2 { amount } else { receipt.2 };
    (receipt.0.msats, receipt.2, maximum)
}

}
