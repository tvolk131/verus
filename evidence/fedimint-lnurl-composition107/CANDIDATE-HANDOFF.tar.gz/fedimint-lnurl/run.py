import datetime
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

sys.dont_write_bytecode = True
ROOT = Path('/Users/tommyvolk/.t3/worktrees/verus/t3-60978068')
OUT = Path(__file__).resolve().parent
RUNTIME = Path('/private/tmp/verus-crash-consistency94-20261105/codec-runtime-005/runtime')
NATIVE = Path('/private/tmp/verus-crash-consistency94-20261105/native-leaf-lookup-007/recovered-native/fedimint')
BINDING = RUNTIME.parent / 'runtime-binding.json'
RECOVERY = NATIVE.parent.parent / 'recovery.json'
ENTRY = OUT / 'entry-authentication-02.json'
START = datetime.datetime.fromisoformat('2026-11-08T02:41:36+00:00').timestamp()
sys.path.insert(0, str(ROOT / 'source/tools'))
import check_fedimint_validation81 as validation
import check_fedimint_fee_encoding as encoding
from check_fedimint_native import item


def fingerprint(filename):
    result = hashlib.sha256()
    with Path(filename).open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            result.update(block)
    return result.hexdigest()


def write_json(filename, value):
    (OUT / filename).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def storage():
    available = os.statvfs('/private/tmp')
    free = available.f_bavail * available.f_frsize
    size = sum(filename.stat().st_size for filename in OUT.rglob('*') if filename.is_file())
    assert free > 16 * 1024 ** 3, ('global free space', free)
    assert size <= 128 * 1024 ** 2, ('scratch size', size)
    return dict(free_bytes=free, scratch_bytes=size)


def authenticate():
    binding = json.loads(BINDING.read_text())
    actual_runtime = {name: fingerprint(RUNTIME / name) for name in binding['runtime']}
    assert actual_runtime == binding['runtime'], 'frozen runtime mismatch'
    inputs = [BINDING, RECOVERY]
    inputs += list((ROOT / 'source/tools').glob('*.py'))
    inputs += [ROOT / relative for relative in binding['source'] if (ROOT / relative).is_file()]
    inputs += [NATIVE / relative for relative in set(validation.SOURCE_HASHES) | set(encoding.SOURCE_HASHES)]
    inputs += encoding.compiler_artifacts(Path(binding['sysroot']) / 'bin/rustc')
    inputs += [ROOT / 'evidence/parallel-advancement107/PLAN.md']
    inputs += list((ROOT / 'evidence/transfer-fedimint-full-request').glob('*'))
    inputs += list((ROOT / 'evidence/transfer-fedimint-fee-encoding').glob('*'))
    inputs += list(Path('/private/tmp/fedimint-proof-design-20261107.GtuCkC').glob('*'))
    digests = {str(filename): fingerprint(filename) for filename in sorted(set(inputs)) if filename.is_file()}
    missing = [relative for relative in binding['source'] if not (ROOT / relative).is_file()]
    mismatches = {relative: dict(recorded=expected, actual=digests.get(str(ROOT / relative)))
                  for relative, expected in binding['source'].items()
                  if digests.get(str(ROOT / relative)) != expected}
    return dict(runtime=actual_runtime, inputs=digests, historical_source_missing=missing,
                historical_source_mismatches=mismatches, sysroot=binding['sysroot'],
                independent_review=binding['independent_review'], storage=storage())


def prepare():
    assert not ENTRY.exists(), 'never reset evidence'
    authentication = authenticate()
    write_json(ENTRY.name, authentication)
    assert fingerprint(RECOVERY) == '68c5020788d8ed6c0121f8b203c27b27ea710e020c667f51444330fc27895877'
    selected, sources = validation.extract(NATIVE)
    assert {name: hashlib.sha256(value.encode()).hexdigest() for name, value in selected.items()} == validation.ITEM_HASHES
    for relative, expected in encoding.SOURCE_HASHES.items():
        assert fingerprint(NATIVE / relative) == expected
    helpers = encoding.extract_helpers((NATIVE / encoding.CONTRACTS).read_text())
    encoding.check_call_paths((NATIVE / encoding.RECURRING).read_text(), (NATIVE / encoding.RECEIVE).read_text())
    (OUT / 'fee-provider.rs').write_text(validation.provider_source(selected))
    (OUT / 'encoding-provider.rs').write_text(encoding.proof_source(helpers))
    for directory in ('home', 'tmp', 'cache', 'cargo-home', 'target'):
        (OUT / directory).mkdir(exist_ok=True)
    inventory = dict(native_items={name: hashlib.sha256(value.encode()).hexdigest() for name, value in selected.items()},
                     encoding_items=encoding.ITEM_HASHES, original_methods=validation.METHODS,
                     provider_names=['lnurl_fee_provider', 'lnurl_encoding_provider'],
                     qualifications=['recovered-native SOURCE-CONTENT-ONLY, not clean native continuity',
                                     'compiler/source correspondence NOT repaired',
                                     'cross-process origin and fallback branch assumptions remain conditional'])
    write_json('selected-inventory.json', inventory)
    print('PREPARED', len(authentication['historical_source_mismatches']), 'historical source mismatches')


def environment():
    return dict(PATH='/usr/bin:/bin:/Users/tommyvolk/.cargo/bin', HOME=str(OUT / 'home'),
                TMPDIR=str(OUT / 'tmp'), RUSTUP_HOME='/Users/tommyvolk/.rustup',
                RUSTUP_TOOLCHAIN='1.99.1', CARGO_HOME=str(OUT / 'cargo-home'),
                CARGO_TARGET_DIR=str(OUT / 'target'), CARGO_BUILD_JOBS='1',
                VERUS_Z3_PATH=str(RUNTIME / 'z3'), VERUS_INFER_CACHE=str(OUT / 'cache'),
                GIT_OPTIONAL_LOCKS='0', LC_ALL='C', TZ='UTC')


def run(label, filename, crate, provider=False, imported=True):
    assert time.time() < START + 12 * 60, 'launch deadline reached'
    ledger = OUT / 'attempts.jsonl'
    attempts = ledger.read_text().splitlines() if ledger.exists() else []
    assert len(attempts) < 16, 'direct application allowance exhausted'
    assert not (OUT / (label + '.status.json')).exists(), 'attempt labels are immutable'
    entry = json.loads(ENTRY.read_text())
    before = authenticate()
    assert before['runtime'] == entry['runtime'] and before['inputs'] == entry['inputs'], 'input drift'
    write_json(label + '.authentication.json', before)
    artifact = OUT / (label + '.vir')
    argv = [str(RUNTIME / 'verus'), str(OUT / filename), '--crate-type=lib', '--edition=2021',
            '--crate-name', crate, '--no-cheating', '--output-json', '--num-threads', '1',
            '--export', str(artifact)]
    imports = {}
    if imported:
        for name, prefix in [('lnurl_fee_provider', 'fee'), ('lnurl_encoding_provider', 'encoding')]:
            certificate = OUT / (prefix + '.vir')
            library = OUT / ('lib' + name + '.rlib')
            imports[str(certificate)] = fingerprint(certificate)
            imports[str(library)] = fingerprint(library)
            argv += ['--import', name + '=' + str(certificate), '--extern', name + '=' + str(library)]
    if provider:
        argv += ['--compile', '-o', str(OUT / ('lib' + crate + '.rlib'))]
    record = dict(attempt=len(attempts) + 1, label=label, argv=argv, environment=environment(),
                  cwd=str(OUT), source_sha256=fingerprint(OUT / filename), imported_sha256=imports,
                  timeout_seconds=60, worker_count=1, charged_direct_applications=1,
                  started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), storage=storage())
    with ledger.open('a') as stream:
        stream.write(json.dumps(record, sort_keys=True) + '\n')
    write_json(label + '.command.json', record)
    started = time.monotonic()
    timed_out = False
    with (OUT / (label + '.stdout')).open('wb') as stdout, (OUT / (label + '.stderr')).open('wb') as stderr:
        process = subprocess.Popen(argv, cwd=OUT, env=environment(), stdout=stdout, stderr=stderr, start_new_session=True)
        try:
            returncode = process.wait(timeout=60)
        except subprocess.TimeoutExpired:
            timed_out = True
            os.killpg(process.pid, signal.SIGKILL)
            returncode = process.wait()
    after = authenticate()
    unchanged = after['runtime'] == entry['runtime'] and after['inputs'] == entry['inputs']
    unchanged = unchanged and all(fingerprint(filename) == expected for filename, expected in imports.items())
    status = dict(returncode=returncode, timeout=timed_out, elapsed_seconds=time.monotonic() - started,
                  inputs_unchanged=unchanged, export_exists=artifact.exists(), storage=storage())
    if artifact.exists():
        status['export_sha256'] = fingerprint(artifact)
    try:
        data = json.loads((OUT / (label + '.stdout')).read_text())
        write_json(label + '.scope.json', data)
        status['verification_results'] = data.get('verification-results')
        status['scope'] = data.get('verus-infer', {}).get('verification_scope')
    except (ValueError, KeyError):
        status['json_parsed'] = False
    write_json(label + '.status.json', status)
    print(json.dumps(dict(label=label, returncode=returncode, timeout=timed_out,
                         elapsed_seconds=status['elapsed_seconds'],
                         verification_results=status.get('verification_results'),
                         inputs_unchanged=unchanged, export_exists=artifact.exists()), sort_keys=True))
    assert unchanged, 'inputs changed during execution'


def finish():
    exit_authentication = authenticate()
    write_json('exit-authentication.json', exit_authentication)
    entry = json.loads(ENTRY.read_text())
    write_json('exit-comparison.json', dict(runtime_unchanged=entry['runtime'] == exit_authentication['runtime'],
               inputs_unchanged=entry['inputs'] == exit_authentication['inputs'], storage=storage(),
               elapsed_seconds=time.time() - START))


if __name__ == '__main__':
    if sys.argv[1] == 'prepare':
        prepare()
    elif sys.argv[1] == 'finish':
        finish()
    else:
        label, filename, crate = sys.argv[1:4]
        run(label, filename, crate, provider='--provider' in sys.argv, imported='--local' not in sys.argv)
