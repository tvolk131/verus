import datetime
import hashlib
import json
import os
from pathlib import Path
import tarfile
import time

OUT = Path(__file__).resolve().parent
START = datetime.datetime.fromisoformat('2026-11-08T02:41:36+00:00').timestamp()
assert not (OUT / 'SEAL.json').exists(), 'sealed evidence cannot be reset'
audit = json.loads((OUT / 'audit.json').read_text())
comparison = json.loads((OUT / 'exit-comparison.json').read_text())
assert audit['direct_applications'] == 11
assert comparison['inputs_unchanged'] and comparison['runtime_unchanged']
assert time.time() - START < 900
files = sorted(filename for filename in OUT.rglob('*') if filename.is_file())
manifest = ''.join(hashlib.sha256(filename.read_bytes()).hexdigest() + '  '
                   + str(filename.relative_to(OUT)) + '\n' for filename in files)
(OUT / 'SHA256SUMS').write_text(manifest)
seal = dict(status='CHECKED SCRATCH CANDIDATE; NOT ACCEPTED OR ADOPTED',
            sealed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
            elapsed_seconds=time.time() - START, charged_direct_applications=11,
            direct_application_allowance=16, simultaneous_workers=1, timeout_seconds=60,
            verifier_launches_finished_before_12_minutes=True,
            manifest_sha256=hashlib.sha256(manifest.encode()).hexdigest(),
            manifest_files=len(files), redb_cells_open=18,
            exit_authentication=comparison, compiler_source_correspondence_repaired=False,
            recovered_native_qualification='SOURCE-CONTENT-ONLY; NOT CLEAN CONTINUITY')
(OUT / 'SEAL.json').write_text(json.dumps(seal, indent=2, sort_keys=True) + '\n')
with tarfile.open(OUT / 'handoff.tar.gz', 'w:gz') as archive:
    for filename in sorted(OUT.rglob('*')):
        if filename.is_file() and filename.name != 'handoff.tar.gz':
            archive.add(filename, arcname='fedimint-lnurl/' + str(filename.relative_to(OUT)), recursive=False)
archive_hash = hashlib.sha256((OUT / 'handoff.tar.gz').read_bytes()).hexdigest()
(OUT / 'HANDOFF.sha256').write_text(archive_hash + '  handoff.tar.gz\n')
with tarfile.open(OUT / 'handoff.tar.gz', 'r:gz') as archive:
    for line in manifest.splitlines():
        expected, relative = line.split('  ', 1)
        actual = hashlib.sha256(archive.extractfile('fedimint-lnurl/' + relative).read()).hexdigest()
        assert actual == expected
size = sum(filename.stat().st_size for filename in OUT.rglob('*') if filename.is_file())
space = os.statvfs('/private/tmp')
free = space.f_bavail * space.f_frsize
assert size <= 128 * 1024 ** 2 and free > 16 * 1024 ** 3
for filename in OUT.rglob('*'):
    filename.chmod(0o555 if filename.is_dir() else 0o444)
OUT.chmod(0o555)
print(json.dumps(dict(sealed=str(OUT), archive_sha256=archive_hash,
                      final_scratch_bytes=size, final_global_free_bytes=free,
                      elapsed_seconds=time.time() - START), sort_keys=True))
