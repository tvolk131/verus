from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
path = root / 'positive.rs'
source = path.read_text()
old = source[source.index('pub proof fn fixture_lawful'):source.index('pub fn fixed_witness')]
new = '''pub open spec fn fixture_key(child: int, index: int) -> Seq<u8> {
    if child == 0 { if index == 0 { seq![1u8, 0, 0, 0] } else { seq![0u8, 1, 0, 0] } }
    else if child == 1 { if index == 0 { seq![1u8, 1, 0, 0] } else { seq![0u8, 0, 1, 0] } }
    else { if index == 0 { seq![1u8, 0, 1, 0] } else { seq![255u8, 255, 255, 255] } }
}

pub proof fn fixture_leaf(page: Seq<u8>, child: int, variable: bool, first: u8, second: u8)
    requires 0 <= child < 3, page == leaf_image(child, variable, first, second),
    ensures
        lookup_client::ordered_leaf(page, if variable { None } else { Some(4usize) }, if variable { None } else { Some(1usize) }),
        leaf::pair_count(page) == 2,
        forall|index: int| 0 <= index < 2 ==> #[trigger] leaf::encoded_key(page, if variable { None } else { Some(4usize) }, if variable { None } else { Some(1usize) }, index) == fixture_key(child, index),
        forall|index: int| 0 <= index < 2 ==> #[trigger] leaf::encoded_value(page, if variable { None } else { Some(4usize) }, if variable { None } else { Some(1usize) }, index) == seq![if index == 0 { first } else { second }],
{
    let kw = if variable { None } else { Some(4usize) };
    let vw = if variable { None } else { Some(1usize) };
    leaf::concrete_le16(page, 2);
    if variable {
        leaf::concrete_le32(page, 4);
        leaf::concrete_le32(page, 8);
        leaf::concrete_le32(page, 12);
        leaf::concrete_le32(page, 16);
    }
    assert forall|boundary: int| 0 <= boundary <= 2 implies {
        &&& leaf::metadata_end(page, kw, vw) <= #[trigger] leaf::key_boundary(page, kw, vw, boundary) <= page.len()
        &&& leaf::key_boundary(page, kw, vw, boundary) <= u32::MAX
        &&& leaf::key_boundary(page, kw, vw, 2) <= #[trigger] leaf::value_boundary(page, kw, vw, boundary) <= page.len()
        &&& leaf::value_boundary(page, kw, vw, boundary) <= u32::MAX
    } by { assert(boundary == 0 || boundary == 1 || boundary == 2); }
    assert forall|left: int, right: int| 0 <= left <= right <= 2 implies {
        &&& #[trigger] leaf::key_boundary(page, kw, vw, left) <= #[trigger] leaf::key_boundary(page, kw, vw, right)
        &&& #[trigger] leaf::value_boundary(page, kw, vw, left) <= #[trigger] leaf::value_boundary(page, kw, vw, right)
    } by {
        assert(left == 0 || left == 1 || left == 2);
        assert(right == 0 || right == 1 || right == 2);
    }
    assert(leaf::leaf_bytes_wf(page, kw, vw));
    assert forall|index: int| 0 <= index < 2 implies #[trigger] leaf::encoded_key(page, kw, vw, index) == fixture_key(child, index) by {
        assert(index == 0 || index == 1);
        assert(child == 0 || child == 1 || child == 2);
        assert(leaf::encoded_key(page, kw, vw, index) =~= fixture_key(child, index));
    }
    assert forall|index: int| 0 <= index < 2 implies #[trigger] leaf::encoded_value(page, kw, vw, index) == seq![if index == 0 { first } else { second }] by {
        assert(index == 0 || index == 1);
        assert(leaf::encoded_value(page, kw, vw, index) =~= seq![if index == 0 { first } else { second }]);
    }
    leaf::concrete_le32(fixture_key(child, 0), 0);
    leaf::concrete_le32(fixture_key(child, 1), 0);
    assert(lookup_client::ordered_leaf(page, kw, vw));
}

pub proof fn fixture_lawful(bytes: Seq<u8>, leaves: Seq<&[u8]>, variable: bool,
    first: u8, second: u8, third: u8, fourth: u8, fifth: u8, sixth: u8)
    requires bytes == branch_image(variable), leaves.len() == 3,
        leaves[0]@ == leaf_image(0, variable, first, second),
        leaves[1]@ == leaf_image(1, variable, third, fourth),
        leaves[2]@ == leaf_image(2, variable, fifth, sixth),
    ensures supplied(bytes, leaves, if variable { None } else { Some(4usize) }, if variable { None } else { Some(1usize) }),
        branch::key_count(bytes) == 2,
        branch::encoded_key(bytes, if variable { None } else { Some(4usize) }, 0) == seq![0u8, 1, 0, 0],
        branch::encoded_key(bytes, if variable { None } else { Some(4usize) }, 1) == seq![0u8, 0, 1, 0],
        meaning(branch::encoded_key(bytes, if variable { None } else { Some(4usize) }, 0)) == 256,
        meaning(branch::encoded_key(bytes, if variable { None } else { Some(4usize) }, 1)) == 65536,
        forall|child: int| 0 <= child < 3 ==> leaf::pair_count(#[trigger] leaves[child]@) == 2,
        forall|child: int, index: int| 0 <= child < 3 && 0 <= index < 2 ==> #[trigger] leaf::encoded_key(leaves[child]@, if variable { None } else { Some(4usize) }, if variable { None } else { Some(1usize) }, index) == fixture_key(child, index),
        forall|child: int, index: int| 0 <= child < 3 && 0 <= index < 2 ==> #[trigger] leaf::encoded_value(leaves[child]@, if variable { None } else { Some(4usize) }, if variable { None } else { Some(1usize) }, index) == seq![if child == 0 { if index == 0 { first } else { second } } else if child == 1 { if index == 0 { third } else { fourth } } else { if index == 0 { fifth } else { sixth } }],
{
    let kw = if variable { None } else { Some(4usize) };
    let vw = if variable { None } else { Some(1usize) };
    leaf_lookup023::concrete_le16(bytes, 2);
    if variable {
        leaf_lookup023::concrete_le32(bytes, 80);
        leaf_lookup023::concrete_le32(bytes, 84);
    }
    assert forall|boundary: int| 0 <= boundary <= 2 implies branch::metadata(2, kw) <= #[trigger] branch::boundary(bytes, kw, boundary) <= bytes.len() by {
        assert(boundary == 0 || boundary == 1 || boundary == 2);
    }
    assert forall|index: int| 0 <= index < 2 implies #[trigger] branch::boundary(bytes, kw, index) <= branch::boundary(bytes, kw, index + 1) by { assert(index == 0 || index == 1); }
    assert(branch::branch_bytes_wf(bytes, kw));
    assert(branch::encoded_key(bytes, kw, 0) =~= seq![0u8, 1, 0, 0]);
    assert(branch::encoded_key(bytes, kw, 1) =~= seq![0u8, 0, 1, 0]);
    leaf::concrete_le32(branch::encoded_key(bytes, kw, 0), 0);
    leaf::concrete_le32(branch::encoded_key(bytes, kw, 1), 0);
    assert(meaning(branch::encoded_key(bytes, kw, 0)) == 256);
    assert(meaning(branch::encoded_key(bytes, kw, 1)) == 65536);
    assert(branch_clients023::ordered_bytes::<u32>(bytes, kw));
    fixture_leaf(leaves[0]@, 0, variable, first, second);
    fixture_leaf(leaves[1]@, 1, variable, third, fourth);
    fixture_leaf(leaves[2]@, 2, variable, fifth, sixth);
    assert forall|child: int| 0 <= child < 3 implies lookup_client::ordered_leaf(#[trigger] leaves[child]@, kw, vw) && leaf::pair_count(leaves[child]@) == 2 by {
        assert(child == 0 || child == 1 || child == 2);
    }
    assert forall|child: int, index: int| 0 <= child < 3 && 0 <= index < 2 implies interval(bytes, kw, child, #[trigger] leaf::encoded_key(leaves[child]@, kw, vw, index)) by {
        assert(child == 0 || child == 1 || child == 2);
        assert(index == 0 || index == 1);
        leaf::concrete_le32(fixture_key(child, index), 0);
    }
}

'''
source = source.replace(old, new)
source = source.replace('        reveal(vstd::bytes::spec_u16_from_le_bytes);\n', '').replace('        reveal(vstd::bytes::spec_u32_from_le_bytes);\n', '')
patch = '*** Begin Patch\n*** Update File: ' + str(path) + '\n@@\n-' + '\n-'.join(path.read_text().splitlines()) + '\n+' + '\n+'.join(source.splitlines()) + '\n*** End Patch\n'
subprocess.run(['apply_patch'], input=patch, text=True, check=True)
