import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
START = 1794100609
STOP = START + 720
DEADLINE = START + 900
PARENT = Path('/Users/tommyvolk/.t3/worktrees/verus/t3-60978068')
E = PARENT / 'evidence'
L = Path('/private/tmp/verus-crash-consistency94-20261105/native-leaf-lookup-007')
B = L.parent / 'native-branch-routing-023'
R = Path('/private/tmp/verus-routing023-independent-review-5nRzcqsG')
RUNTIME = L / 'midpoint-runtime-proposal/runtime'
SYSROOT = Path('/Users/tommyvolk/.rustup/toolchains/1.99.1-aarch64-apple-darwin')

def digest(path):
    result = hashlib.sha256()
    with open(path, 'rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            result.update(block)
    return result.hexdigest()

def save(path, data):
    path.write_text(json.dumps(data, indent=2, sort_keys=True) + '\n')

def usage():
    return sum(path.stat().st_size for path in ROOT.rglob('*') if path.is_file())

def authenticate(label):
    design = E / 'redb-branch-leaf-composition102'
    expected = {
        design / 'DESIGN-REPORT.md': 'b7d24e9cead3d50df0c7e5fc093b1acbb578dcfb59efdd59aff6b32413cd5d20',
        design / 'DESIGN-INPUTS.sha256': 'fdefe9d427ec097448a6773fed4dafa831e23faf965c86cc9b05cfedc1047fca',
    }
    for line in (design / 'DESIGN-INPUTS.sha256').read_text().splitlines():
        if not line.strip() or line.startswith('#'):
            continue
        checksum, name = line.split(None, 1)
        prefix, rest = name.split('/', 1)
        expected[{'E': E, 'L': L, 'B': B, 'R': R, 'N': L / 'recovered-native/redb/src'}[prefix] / rest] = checksum
    binding = json.loads((L / 'midpoint-runtime-proposal/runtime-binding.json').read_text())
    for name, checksum in binding['runtime'].items():
        expected[RUNTIME / name] = checksum
        expected[B / 'runtime' / name] = checksum
    for name, checksum in binding['private_vstd_sources'].items():
        expected[L / 'midpoint-runtime-proposal/source' / name] = checksum
    baseline = Path('/private/tmp/verus-review94-byte-step-20261105-UyVDNcAR/preservation-baseline.json')
    historical = json.loads(baseline.read_text())
    selected = {}
    for name, metadata in historical['sysroot_files'].items():
        if name.startswith('lib/rustlib/src/rust/library/') or name in ['bin/rustc', 'bin/rustdoc'] or ('/lib/' in name and ('libcore-' in name or 'libstd-' in name)):
            selected[name] = metadata['sha256']
            expected[SYSROOT / name] = metadata['sha256']
    rows = []
    for path, checksum in expected.items():
        actual = digest(path)
        rows.append({'path': str(path), 'expected': checksum, 'actual': actual, 'match': actual == checksum})
    record = {'time': time.time(), 'bindings': rows, 'all_match': all(row['match'] for row in rows),
              'sysroot_baseline_sha256': digest(baseline), 'selected_sysroot_count': len(selected),
              'scratch_bytes': usage(), 'free_bytes': os.statvfs(ROOT).f_bavail * os.statvfs(ROOT).f_frsize}
    save(ROOT / (label + '.json'), record)
    assert record['all_match'], 'immutable binding mismatch'
    assert record['free_bytes'] > 16 * 1024**3
    assert record['scratch_bytes'] <= 128 * 1024**2
    return record

def run(source):
    ledger_path = ROOT / 'ledger.json'
    ledger = json.loads(ledger_path.read_text()) if ledger_path.exists() else []
    assert len(ledger) < 16 and time.time() < STOP
    ordinal = len(ledger) + 1
    output = ROOT / ('attempt-%03d' % ordinal)
    output.mkdir()
    item = {'ordinal': ordinal, 'start': time.time(), 'source': str(source), 'status': 'setup'}
    ledger.append(item)
    save(ledger_path, ledger)
    authenticate('auth-pre-%03d' % ordinal)
    assert time.time() < STOP
    frozen = output / 'input.rs'
    frozen.write_bytes(source.read_bytes())
    previous = json.loads((L / 'runs/attempt-011/invocation.json').read_text())
    env = previous['environment'].copy()
    for variable in ['HOME', 'TMPDIR', 'TMP', 'TEMP', 'CARGO_HOME', 'RUSTUP_HOME', 'CARGO_TARGET_DIR', 'XDG_CACHE_HOME', 'XDG_CONFIG_HOME', 'XDG_DATA_HOME', 'XDG_STATE_HOME', 'VERUS_INFER_CACHE']:
        location = output / variable.lower()
        location.mkdir()
        env[variable] = str(location)
    env['PWD'] = str(output)
    argv = [str(RUNTIME / 'verus'), '--sysroot', str(SYSROOT), '--edition=2024', '--crate-type=lib', '--crate-name', 'branch_leaf_client', '--no-cheating', '--output-json', '--num-threads', '1', '--triggers-mode', 'silent', '--multiple-errors', '12', '--rlimit', '30', '-C', 'debug-assertions=no']
    pairs = [
        ('leaf_lookup023', B / 'runs/attempt-001/libleaf_lookup023.rlib', B / 'runs/attempt-001/leaf_lookup023.vir'),
        ('pagecodec023', B / 'runs/attempt-002/libpagecodec023.rlib', B / 'runs/attempt-002/pagecodec023.vir'),
        ('branch_routing023', B / 'runs/attempt-019/libbranch_routing023.rlib', B / 'runs/attempt-019/branch_routing023.vir'),
        ('branch_clients023', B / 'runs/attempt-020/libbranch_clients023.rlib', B / 'runs/attempt-020/branch_clients023.vir'),
        ('leaf_decoder', L / 'runs/attempt-009/libleaf_decoder.rlib', L / 'leaf-final.vir'),
        ('builder_step', L / 'runs/attempt-010/libbuilder_step.rlib', L / 'builder-final.vir'),
        ('lookup_client', L / 'runs/attempt-011/liblookup_client.rlib', L / 'client-final.vir'),
    ]
    for name, rlib, vir in pairs:
        argv += ['--extern', name + '=' + str(rlib), '--import', name + '=' + str(vir), '-L', 'dependency=' + str(rlib.parent)]
    argv += [str(frozen)]
    save(output / 'invocation.json', {'argv': argv, 'environment': env, 'cwd': str(output), 'source_sha256': digest(frozen), 'start': START, 'stop_launches': STOP, 'deadline': DEADLINE, 'timeout_seconds': 60})
    launched = time.monotonic()
    with open(output / 'stdout.txt', 'wb') as stdout, open(output / 'stderr.txt', 'wb') as stderr:
        process = subprocess.Popen(argv, cwd=output, env=env, stdout=stdout, stderr=stderr, start_new_session=True)
        try:
            code = process.wait(timeout=min(60, STOP - time.time()))
            item['status'] = 'completed'
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait()
            code = None
            item['status'] = 'timeout'
    item.update({'returncode': code, 'seconds': time.monotonic() - launched, 'end': time.time(), 'source_sha256': digest(frozen)})
    raw = (output / 'stdout.txt').read_text()
    try:
        result = json.loads(raw)
        save(output / 'actual-verification.json', result)
        item['verification'] = result.get('verification-results', result.get('verification', {}))
        save(output / 'actual-scope.json', result.get('verus-infer', {}).get('verification_scope', {}))
    except ValueError:
        item['json_unavailable'] = True
    save(ledger_path, ledger)
    authenticate('auth-post-%03d' % ordinal)
    print(json.dumps(item, indent=2))
    print((output / 'stderr.txt').read_text()[-12000:])
    print(raw[:3000])

if __name__ == '__main__':
    if sys.argv[1] == 'auth':
        record = authenticate(sys.argv[2])
        print('authenticated', len(record['bindings']), 'bindings; free', record['free_bytes'])
    else:
        run(Path(sys.argv[1]).resolve())
