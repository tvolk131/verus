use vstd::prelude::*;
extern crate branch_clients023;
extern crate branch_routing023;
extern crate pagecodec023;
extern crate leaf_decoder;
extern crate leaf_lookup023;
extern crate builder_step;
extern crate lookup_client;

verus! {
pub proof fn meaning_bridge(bytes: Seq<u8>)
    requires bytes.len() == 4,
    ensures <u32 as leaf_decoder::Value>::meaning(bytes)
        == <u32 as leaf_lookup023::Value>::meaning(bytes),
{
}
}
