from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent

def seq(items):
    return 'seq![' + ', '.join(str(item) for item in items) + ']'

def array(items):
    return '[' + ', '.join(str(item) for item in items) + ']'

def branch_image(variable):
    data = [0] * (96 if variable else 88)
    data[0] = 2
    data[2] = 2
    for offset, value in [(56, 1), (64, 2), (72, 3)]:
        data[offset] = value
    if variable:
        data[80] = 92
        data[84] = 96
    data[(88 if variable else 80):] = [0, 1, 0, 0, 0, 0, 1, 0]
    return data

def leaf_image(child, variable, first, second):
    keys = [[1, 256], [257, 65536], [65537, 4294967295]][child]
    data = [1, 0, 2, 0]
    if variable:
        data += [24, 0, 0, 0, 28, 0, 0, 0, 29, 0, 0, 0, 30, 0, 0, 0]
    for key in keys:
        data += list(key.to_bytes(4, 'little'))
    return data + [first, second]

text = '''
pub open spec fn branch_image(variable: bool) -> Seq<u8> {
    if variable { VAR_BRANCH } else { FIX_BRANCH }
}

pub open spec fn leaf_image(child: int, variable: bool, first: u8, second: u8) -> Seq<u8> {
    if variable {
        if child == 0 { VAR_LEFT } else if child == 1 { VAR_MIDDLE } else { VAR_RIGHT }
    } else {
        if child == 0 { FIX_LEFT } else if child == 1 { FIX_MIDDLE } else { FIX_RIGHT }
    }
}

pub proof fn fixture_lawful(bytes: Seq<u8>, leaves: Seq<&[u8]>, variable: bool,
    first: u8, second: u8, third: u8, fourth: u8, fifth: u8, sixth: u8)
    requires bytes == branch_image(variable), leaves.len() == 3,
        leaves[0]@ == leaf_image(0, variable, first, second),
        leaves[1]@ == leaf_image(1, variable, third, fourth),
        leaves[2]@ == leaf_image(2, variable, fifth, sixth),
    ensures supplied(bytes, leaves, if variable { None } else { Some(4usize) }, if variable { None } else { Some(1usize) }),
        branch::key_count(bytes) == 2,
        forall|child: int| 0 <= child < 3 ==> leaf::pair_count(#[trigger] leaves[child]@) == 2,
{
    let kw = if variable { None } else { Some(4usize) };
    let vw = if variable { None } else { Some(1usize) };
    leaf_lookup023::concrete_le16(bytes, 2);
    if variable {
        leaf_lookup023::concrete_le32(bytes, 80);
        leaf_lookup023::concrete_le32(bytes, 84);
    }
    assert forall|boundary: int| 0 <= boundary <= 2
        implies branch::metadata(2, kw) <= #[trigger] branch::boundary(bytes, kw, boundary) <= bytes.len() by {
        assert(boundary == 0 || boundary == 1 || boundary == 2);
    }
    assert forall|index: int| 0 <= index < 2
        implies #[trigger] branch::boundary(bytes, kw, index) <= branch::boundary(bytes, kw, index + 1) by {
        assert(index == 0 || index == 1);
    }
    assert(branch::branch_bytes_wf(bytes, kw));
    leaf::concrete_le32(branch::encoded_key(bytes, kw, 0), 0);
    leaf::concrete_le32(branch::encoded_key(bytes, kw, 1), 0);
    assert(meaning(branch::encoded_key(bytes, kw, 0)) == 256);
    assert(meaning(branch::encoded_key(bytes, kw, 1)) == 65536);
    assert(branch_clients023::ordered_bytes::<u32>(bytes, kw));
    assert forall|child: int| 0 <= child < 3 implies lookup_client::ordered_leaf(#[trigger] leaves[child]@, kw, vw)
        && leaf::pair_count(leaves[child]@) == 2 by {
        assert(child == 0 || child == 1 || child == 2);
        let page = leaves[child]@;
        leaf::concrete_le16(page, 2);
        if variable {
            leaf::concrete_le32(page, 4);
            leaf::concrete_le32(page, 8);
            leaf::concrete_le32(page, 12);
            leaf::concrete_le32(page, 16);
        }
        assert forall|boundary: int| 0 <= boundary <= 2 implies {
            &&& leaf::metadata_end(page, kw, vw) <= #[trigger] leaf::key_boundary(page, kw, vw, boundary) <= page.len()
            &&& leaf::key_boundary(page, kw, vw, boundary) <= u32::MAX
            &&& leaf::key_boundary(page, kw, vw, 2) <= #[trigger] leaf::value_boundary(page, kw, vw, boundary) <= page.len()
            &&& leaf::value_boundary(page, kw, vw, boundary) <= u32::MAX
        } by { assert(boundary == 0 || boundary == 1 || boundary == 2); }
        assert forall|left: int, right: int| 0 <= left <= right <= 2 implies {
            &&& #[trigger] leaf::key_boundary(page, kw, vw, left) <= #[trigger] leaf::key_boundary(page, kw, vw, right)
            &&& #[trigger] leaf::value_boundary(page, kw, vw, left) <= #[trigger] leaf::value_boundary(page, kw, vw, right)
        } by {
            assert(left == 0 || left == 1 || left == 2);
            assert(right == 0 || right == 1 || right == 2);
        }
        assert(leaf::leaf_bytes_wf(page, kw, vw));
        leaf::concrete_le32(leaf::encoded_key(page, kw, vw, 0), 0);
        leaf::concrete_le32(leaf::encoded_key(page, kw, vw, 1), 0);
        assert(lookup_client::ordered_leaf(page, kw, vw));
    }
    assert forall|child: int, index: int| 0 <= child < 3 && 0 <= index < leaf::pair_count(leaves[child]@)
        implies interval(bytes, kw, child, #[trigger] leaf::encoded_key(leaves[child]@, kw, vw, index)) by {
        assert(child == 0 || child == 1 || child == 2);
        assert(index == 0 || index == 1);
        leaf::concrete_le32(leaf::encoded_key(leaves[child]@, kw, vw, index), 0);
    }
}
'''
for variable, prefix in [(False, 'FIX'), (True, 'VAR')]:
    text = text.replace(prefix + '_BRANCH', seq(branch_image(variable)))
    for child, suffix in enumerate(['LEFT', 'MIDDLE', 'RIGHT']):
        text = text.replace(prefix + '_' + suffix, seq(leaf_image(child, variable, 'first', 'second')))

for variable, name in [(False, 'fixed_witness'), (True, 'variable_witness')]:
    text += '\npub fn ' + name + '(first: u8, second: u8, third: u8, fourth: u8, fifth: u8, sixth: u8) {\n'
    text += '    let bytes: [u8; %d] = %s;\n' % (len(branch_image(variable)), array(branch_image(variable)))
    for child, label, values in [(0, 'left', ('first', 'second')), (1, 'middle', ('third', 'fourth')), (2, 'right', ('fifth', 'sixth'))]:
        data = leaf_image(child, variable, *values)
        text += '    let %s: [u8; %d] = %s;\n' % (label, len(data), array(data))
    text += '    let leaves: [&[u8]; 3] = [&left, &middle, &right];\n'
    text += '    let kw = %s;\n    let vw = %s;\n' % ('None' if variable else 'Some(4usize)', 'None' if variable else 'Some(1usize)')
    text += '    proof { fixture_lawful(bytes@, leaves@, %s, first, second, third, fourth, fifth, sixth); }\n' % str(variable).lower()
    for key, child, value in [(1, 0, 'first'), (256, 0, 'second'), (257, 1, 'third'), (65536, 1, 'fourth'), (65537, 2, 'fifth'), (4294967295, 2, 'sixth')]:
        query = list(key.to_bytes(4, 'little'))
        text += '    let query: [u8; 4] = %s;\n' % array(query)
        text += '    proof { leaf::concrete_le32(query@, 0); }\n'
        text += '    let result = route_then_search(&bytes, &leaves, kw, vw, &query);\n'
        text += '    assert(result.0 == %d);\n' % child
        text += '    assert(result.2.is_some());\n'
        text += '    assert(result.2.unwrap().0@ == query@);\n'
        text += '    assert(result.2.unwrap().1@ == seq![%s]);\n' % value
    for key in [0, 2]:
        text += '    let query: [u8; 4] = %s;\n' % array(list(key.to_bytes(4, 'little')))
        text += '    proof { leaf::concrete_le32(query@, 0); }\n'
        text += '    let result = route_then_search(&bytes, &leaves, kw, vw, &query);\n'
        text += '    assert(result.2.is_none());\n'
    text += '}\n'

patch = '*** Begin Patch\n*** Update File: ' + str(root / 'positive.rs') + '\n@@\n     (selected, page, hit)\n }\n+' + '\n+'.join(text.splitlines()) + '\n }\n*** End Patch\n'
subprocess.run(['apply_patch'], input=patch, text=True, check=True)
