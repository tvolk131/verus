from pathlib import Path
import re
import subprocess
root = Path(__file__).resolve().parent
path = root / 'positive.rs'
old = path.read_text()
lemma = '''pub proof fn decoded_four(bytes: Seq<u8>)
    requires bytes.len() == 4,
    ensures meaning(bytes) == bytes[0] as int + 256 * bytes[1] as int + 65536 * bytes[2] as int + 16777216 * bytes[3] as int,
{
    leaf::concrete_le32(bytes, 0);
    assert(bytes.subrange(0, 4) =~= bytes);
}

'''
new = old.replace('pub open spec fn interval', lemma + 'pub open spec fn interval', 1)
new = re.sub(r'leaf::concrete_le32\((fixture_key\(child, [^\n]+?\)|branch::encoded_key\(bytes, kw, [01]\)|query@), 0\);', r'decoded_four(\1);', new)
new = new.replace('    assert(lookup_client::ordered_leaf(page, kw, vw));', '''    assert forall|left: int, right: int| 0 <= left < right < 2 implies meaning(#[trigger] leaf::encoded_key(page, kw, vw, left)) < meaning(#[trigger] leaf::encoded_key(page, kw, vw, right)) by {
        assert(left == 0 && right == 1);
    }
    assert(lookup_client::ordered_leaf(page, kw, vw));''')
patch = '*** Begin Patch\n*** Update File: ' + str(path) + '\n@@\n-' + '\n-'.join(old.splitlines()) + '\n+' + '\n+'.join(new.splitlines()) + '\n*** End Patch\n'
subprocess.run(['apply_patch'], input=patch, text=True, check=True)
