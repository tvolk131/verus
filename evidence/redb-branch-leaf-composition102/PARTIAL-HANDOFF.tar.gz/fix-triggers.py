from pathlib import Path
import subprocess
root = Path(__file__).resolve().parent
path = root / 'positive.rs'
old = path.read_text()
new = old.replace('if variable { None } else { Some(4usize) }', 'fixture_kw(variable)').replace('if variable { None } else { Some(1usize) }', 'fixture_vw(variable)')
new = new.replace('pub open spec fn fixture_key', 'pub open spec fn fixture_kw(variable: bool) -> Option<usize> { if variable { None } else { Some(4usize) } }\npub open spec fn fixture_vw(variable: bool) -> Option<usize> { if variable { None } else { Some(1usize) } }\n\npub open spec fn fixture_key', 1)
patch = '*** Begin Patch\n*** Update File: ' + str(path) + '\n@@\n-' + '\n-'.join(old.splitlines()) + '\n+' + '\n+'.join(new.splitlines()) + '\n*** End Patch\n'
subprocess.run(['apply_patch'], input=patch, text=True, check=True)
