import importlib.util
import json
from pathlib import Path
import time

root = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('local_runner', root / 'run.py')
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)
assert time.time() < runner.DEADLINE
entry = json.loads((root / 'auth-entry.json').read_text())
exit_record = runner.authenticate('auth-exit')
ledger = json.loads((root / 'ledger.json').read_text())
scope_inventory = []
for attempt in sorted(root.glob('attempt-*')):
    raw = attempt / 'actual-verification.json'
    if not raw.exists():
        continue
    data = json.loads(raw.read_text())
    scope = data.get('verus-infer', {}).get('verification_scope', {})
    runner.save(attempt / 'scope-derived.json', scope)
    scope_inventory.append({'attempt': attempt.name, 'result': data.get('verification-results'), 'scope': scope})
runner.save(root / 'SCOPE-INVENTORY.json', scope_inventory)
runner.save(root / 'SETUP-FAILURES.json', {
    'standalone_entry_auth': {'charged': 1, 'error': 'ValueError: not enough values to unpack (expected 2, got 1)', 'reason': 'Comment header parsed as a hash row; no verifier spawned; terminal transcript is the original output record'},
    'attempt-001': {'charged': 1, 'error': 'ValueError: not enough values to unpack (expected 2, got 1)', 'reason': 'Same parser bug in preexecution setup; no verifier spawned; no argv/env/stdout/stderr existed for a native process'},
    'correction': 'Skip empty/comment manifest rows; no input weakening or trust change',
})
launches = [item for item in ledger if 'returncode' in item]
auth_records = [json.loads(path.read_text()) for path in root.glob('auth-*.json')]
finished = time.time()
accounting = {
    'status': 'PARTIAL_NOT_ACCEPTED_ALL18CELLSOPEN',
    'start_epoch': runner.START, 'start_utc': '2026-11-08T01:16:49Z',
    'stop_new_applications_epoch': runner.STOP, 'absolute_deadline_epoch': runner.DEADLINE,
    'finalization_record_epoch': finished, 'elapsed_seconds_at_record': finished - runner.START,
    'actual_verifier_launches': len(launches), 'numbered_attempts': len(ledger),
    'additional_conservatively_charged_entry_setup_failure': 1,
    'total_charged_attempts': len(ledger) + 1, 'cap': 16,
    'max_actual_application_seconds': max(item['seconds'] for item in launches),
    'timeouts': sum(item['status'] == 'timeout' for item in ledger),
    'minimum_recorded_free_bytes': min(record['free_bytes'] for record in auth_records),
    'maximum_observed_scratch_bytes': max(record['scratch_bytes'] for record in auth_records),
    'scratch_limit_bytes': 128 * 1024**2, 'free_disk_floor_bytes': 16 * 1024**3,
    'entry_exit_all_match': entry['all_match'] and exit_record['all_match'],
    'all_pre_post_auth_match': all(record['all_match'] for record in auth_records),
    'bindings_per_authentication': len(exit_record['bindings']),
    'last_fully_verified_stage': 'attempt-003/input.rs',
    'last_fully_verified_sha256': runner.digest(root / 'attempt-003/input.rs'),
    'unverified_expanded_draft': 'positive.rs',
    'expanded_draft_sha256': runner.digest(root / 'positive.rs'),
    'expanded_draft_matches_final_attempt': (root / 'positive.rs').read_bytes() == (root / 'attempt-008/input.rs').read_bytes(),
    'semantic_negatives_launched': 0, 'full_positive_restoration_recheck': False,
    'fresh_independent_review_required': True, 'prior_assessment_wall_violation_retained': True,
}
runner.save(root / 'ACCOUNTING.json', accounting)
files = sorted(path for path in root.rglob('*') if path.is_file() and path.name not in ['MANIFEST.sha256', 'SEAL.json'])
manifest = ''.join(runner.digest(path) + '  ' + str(path.relative_to(root)) + '\n' for path in files)
(root / 'MANIFEST.sha256').write_text(manifest)
runner.save(root / 'SEAL.json', {'manifest_sha256': runner.digest(root / 'MANIFEST.sha256'),
    'file_count': len(files), 'sealed_epoch': time.time(), 'scope': 'content seal only; not certification or acceptance',
    'report_sha256': runner.digest(root / 'REPORT.md'), 'accounting_sha256': runner.digest(root / 'ACCOUNTING.json')})
assert runner.usage() < 128 * 1024**2
assert time.time() < runner.DEADLINE
print(json.dumps(accounting, indent=2))
print('SEAL', (root / 'SEAL.json').read_text())
