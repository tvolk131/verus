import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

REVIEW = Path(__file__).parent
CANDIDATE = Path('/private/tmp/redb-compiler-validation114-worker-20261108T151020Z')
REVISION = Path('/private/tmp/redb-lifecycle113-origin-revision2-20261108T145432Z')

def digest(path):
    hasher = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            hasher.update(chunk)
    return hasher.hexdigest()

def authenticate(root, name, expected, field):
    manifest = root / name
    observed = digest(manifest)
    records = json.loads(manifest.read_text())[field]
    failures = []
    total = 0
    for record in records:
        path = root / record['path']
        try:
            size = path.stat().st_size
            actual = digest(path)
            total += size
            if size != record['bytes'] or actual != record['sha256']:
                failures.append({'path': str(path), 'bytes': size, 'sha256': actual})
        except Exception as error:
            failures.append({'path': str(path), 'error': str(error)})
    return {'root': str(root), 'manifest': name, 'expected_sha256': expected,
            'actual_sha256': observed, 'manifest_matches': observed == expected,
            'payload_count': len(records), 'payload_bytes': total, 'failures': failures}

started = time.monotonic()
result = {'phase': sys.argv[1], 'utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
result['candidate'] = authenticate(CANDIDATE, 'SEALED-MANIFEST.json', 'c73d2fba54d4144d3705d78a6d5d6cf9d29bf5eaeeb80dce6d9736fd001d6dd9', 'records')
result['revision2'] = authenticate(REVISION, 'MANIFEST.json', 'a586fe4665ee832499ea233969eb2914b941093186596f849d8cfeea9321c342', 'files')
parent_manifest = CANDIDATE / 'ENTRY-PARENT-INPUTS.json'
parent_data = json.loads(parent_manifest.read_text())
parent_records = parent_data['records']
parent_failures = []
for record in parent_records:
    path = Path(record['path'])
    try:
        actual = digest(path)
        if actual != record['sha256'] or path.stat().st_size != record['bytes']:
            parent_failures.append({'path': str(path), 'sha256': actual, 'bytes': path.stat().st_size})
    except Exception as error:
        parent_failures.append({'path': str(path), 'error': str(error)})
result['parent_recorded_inputs'] = {'manifest_sha256': digest(parent_manifest), 'count': len(parent_records), 'failures': parent_failures}
result['disk_free_bytes'] = shutil.disk_usage('/private/tmp').free
result['scratch_logical_bytes_before_receipt'] = sum(path.stat().st_size for path in REVIEW.rglob('*') if path.is_file())
result['authentication_elapsed_seconds'] = time.monotonic() - started
text = json.dumps(result, indent=2, sort_keys=True) + '\n'
patch = '*** Begin Patch\n*** Add File: ' + str(REVIEW / (sys.argv[1] + '-authentication.json')) + '\n' + ''.join('+' + line + '\n' for line in text.splitlines()) + '*** End Patch\n'
subprocess.run(['apply_patch'], input=patch, text=True, check=True)
print(text)
