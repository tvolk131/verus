import collections
import difflib
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import subprocess

REVIEW = Path(__file__).parent
ROOT = Path('/private/tmp/redb-compiler-validation114-worker-20261108T151020Z')
FROZEN = Path('/private/tmp/verus-crash-consistency94-20261105/drop-effects-parent-002/staged')
REVISION = Path('/private/tmp/redb-lifecycle113-origin-revision2-20261108T145432Z')

def sha(path):
    hasher = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1048576), b''):
            hasher.update(chunk)
    return hasher.hexdigest()

def load(name):
    return json.loads((ROOT / name).read_text())

def inventory(root):
    records = []
    for base, directories, names in os.walk(root, followlinks=False):
        directories.sort()
        for name in sorted(names):
            path = Path(base) / name
            record = {'path': str(path.relative_to(root)), 'sha256': sha(path), 'bytes': path.stat().st_size}
            if path.is_symlink():
                record.update(symlink=os.readlink(path), resolved=str(path.resolve()))
            records.append(record)
    return sorted(records, key=lambda record: record['path'])

def fingerprint(records):
    return hashlib.sha256(json.dumps(records, sort_keys=True, separators=(',', ':')).encode()).hexdigest()

def emit(name, value):
    text = json.dumps(value, indent=2, sort_keys=True) + '\n'
    patch = '*** Begin Patch\n*** Add File: ' + str(REVIEW / name) + '\n' + ''.join('+' + line + '\n' for line in text.splitlines()) + '*** End Patch\n'
    subprocess.run(['apply_patch'], input=patch, text=True, check=True)

result = {}
frozen = inventory(FROZEN)
snapshot = inventory(ROOT / 'snapshot')
result['frozen_inventory_exact'] = frozen == load('frozen-source-inventory.json')['records']
result['frozen_count'] = len(frozen)
result['snapshot_fingerprint'] = fingerprint(snapshot)
result['snapshot_count'] = len(snapshot)
old = {record['path']: record for record in frozen}
new = {record['path']: record for record in snapshot}
changed = sorted(path for path in new if new[path] != old.get(path))
result['changed'] = changed
result['deleted'] = sorted(set(old) - set(new))
delta = ''.join(''.join(difflib.unified_diff((FROZEN / path).read_text().splitlines(True), (ROOT / 'snapshot' / path).read_text().splitlines(True), fromfile='historical/' + path, tofile='isolated/' + path)) for path in changed)
result['complete_patch_exact'] = delta == (ROOT / 'complete-source-delta.patch').read_text()
result['revision_overlay'] = []
for record in json.loads((REVISION / 'BASELINE.json').read_text())['records']:
    relative = record['relative_path']
    result['revision_overlay'].append({'path': relative, 'candidate_sha256': sha(ROOT / 'snapshot/source' / relative), 'revision_sha256': sha(REVISION / 'candidate' / relative), 'historical_sha256': sha(Path(record['path'])), 'frozen_sha256': sha(FROZEN / 'source' / relative)})
before_text = (FROZEN / 'source/rust_verify/src/checked_normal_drop.rs').read_bytes()
after_text = (ROOT / 'snapshot/source/rust_verify/src/checked_normal_drop.rs').read_bytes()
result['legacy_functions'] = []
for name in ['supported_type', 'drop_impl', 'normalize', 'account', 'rewrite_block', 'checked_reference_frames', 'prepare', 'check_native', 'elaborated']:
    pattern = rb'^(?:pub(?:\([^\n]*\))? )?fn ' + name.encode() + rb'\b[\s\S]*?^}\n'
    before_match = re.search(pattern, before_text, re.M)
    after_match = re.search(pattern, after_text, re.M)
    result['legacy_functions'].append({'name': name, 'both_found': bool(before_match and after_match), 'exact': bool(before_match and after_match and before_match[0] == after_match[0]), 'body_sha256': hashlib.sha256(after_match[0]).hexdigest() if after_match else None})
result['source_test_declarations'] = {str(path.relative_to(ROOT / 'snapshot/source')): len(re.findall(r'^\s*#\[test\]', path.read_text(), re.M)) for path in (ROOT / 'snapshot/source/rust_verify/src').rglob('*.rs') if re.search(r'^\s*#\[test\]', path.read_text(), re.M)}
result['commands'] = []
actual_scopes = load('actual-command-scopes.json')
ledger = load('COMMAND-LEDGER.json')['commands']
for number in [1, 2]:
    prefix = 'command-' + str(number)
    receipt = load(prefix + '.receipt.json')
    launch = load(prefix + '.launch.json')
    scope = load(prefix + '.scope.json')
    raw = (ROOT / (prefix + '.stderr')).read_text()
    stdout = (ROOT / (prefix + '.stdout')).read_text()
    direct = [line[len('     Running `'):-1] for line in raw.splitlines() if line.startswith('     Running `')]
    invocations = []
    for line_number, line in enumerate(raw.splitlines(), 1):
        if line.startswith('     Running `'):
            tokens = shlex.split(line[len('     Running `'):-1])
            if '--crate-name' in tokens:
                crate = tokens[tokens.index('--crate-name') + 1]
                invocations.append({'line': line_number, 'crate': crate, 'executable': tokens[0], 'source': [token for token in tokens if token.endswith('.rs')], 'emit': [token for token in tokens if token.startswith('--emit')], 'test': '--test' in tokens, 'out_dir': tokens[tokens.index('--out-dir') + 1], 'cfg': [tokens[index + 1] for index, token in enumerate(tokens) if token == '--cfg']})
    source_before = load(prefix + '.source-before.json')
    source_after = load(prefix + '.source-after.json')
    resources = [json.loads(line) for line in (ROOT / (prefix + '.resources.jsonl')).read_text().splitlines()]
    command = {'number': number, 'argv': receipt['argv'], 'status': receipt['status'], 'exit': receipt['child_exit_code'], 'elapsed_seconds': receipt['elapsed_seconds'], 'process_group_absent_receipt': receipt['owned_process_group_absent'], 'launch_scope_receipt_consistent': all(launch[key] == receipt[key] == scope['fixed_allowlisted_environment' if key == 'environment' else key] for key in ['argv', 'cwd', 'environment']), 'ledger_consistent': ledger[number - 1]['receipt'] == receipt and ledger[number - 1]['scope'] == scope, 'raw_bytes': {'stdout': len(stdout.encode()), 'stderr': len(raw.encode())}, 'raw_lines': {'stdout': len(stdout.splitlines()), 'stderr': len(raw.splitlines())}, 'raw_hashes_match_receipt': all(sha(ROOT / (prefix + '.' + stream)) == receipt[stream + '_sha256'] for stream in ['stdout', 'stderr']), 'direct_invocations_exact': direct == actual_scopes[number - 1]['observed_direct_cargo_verbose_invocations'], 'direct_count': len(direct), 'rustc_invocations': invocations, 'source_before_after_current_exact': source_before['records'] == source_after['records'] == snapshot, 'fingerprints_exact': source_before['fingerprint'] == source_after['fingerprint'] == scope['source_fingerprint'] == receipt['environment']['VERUS_SOURCE_SNAPSHOT_SHA256'] == fingerprint(snapshot), 'warnings': [{'line': index, 'text': line} for index, line in enumerate(raw.splitlines(), 1) if line.startswith('warning:')], 'non_invocation_diagnostics': '\n'.join(line for line in raw.splitlines() if not line.startswith('     Running `') and not re.match(r'^\s*(Compiling|Checking|Fresh) ', line)), 'all_resource_samples_safe': all(sample['safe'] for sample in resources), 'resource_samples': len(resources), 'artifact_records': len(load(prefix + '.artifacts.json')['records']), 'stdout': stdout, 'build_outputs': []}
    for output in sorted((ROOT / ('target-check' if number == 1 else 'target-tests') / 'debug/build').glob('rust_verify-*/output')):
        command['build_outputs'].append({'path': str(output.relative_to(ROOT)), 'sha256': sha(output), 'raw': output.read_text()})
    result['commands'].append(command)
result['selected_input_authentication'] = []
packages = load('dependency-source-inventory.json')['packages']
for package in packages:
    observed = inventory(Path(package['manifest_path']).parent)
    result['selected_input_authentication'].append({'id': package['id'], 'count': len(observed), 'exact': observed == package['records'], 'fingerprint_exact': fingerprint(observed) == package['fingerprint']})
tools = load('toolchain-inventory.json')
tool_observed = inventory(Path(tools['root']))
result['toolchain'] = {'count': len(tool_observed), 'exact': tool_observed == tools['records'], 'fingerprint_exact': fingerprint(tool_observed) == tools['fingerprint']}
result['platform_support'] = [{'path': record['path'], 'exact': sha(Path(record['path'])) == record['sha256'] and Path(record['path']).stat().st_size == record['bytes']} for record in load('platform-support-identities.json')['identities']]
result['all_managed_receipts'] = [{'file': path.name, 'status': json.loads(path.read_text())['status'], 'exit': json.loads(path.read_text()).get('child_exit_code')} for path in sorted(ROOT.glob('*.receipt.json'))]
emit('independent-crosscheck.json', result)
print(json.dumps({key: value for key, value in result.items() if key not in ['commands', 'selected_input_authentication', 'platform_support']}, indent=2))
print('commands', [{key: command[key] for key in ['number', 'status', 'exit', 'direct_count', 'source_before_after_current_exact', 'fingerprints_exact', 'launch_scope_receipt_consistent', 'ledger_consistent', 'raw_hashes_match_receipt', 'direct_invocations_exact']} for command in result['commands']])
print('dependency packages', len(packages), 'all exact', all(package['exact'] and package['fingerprint_exact'] for package in result['selected_input_authentication']))
