#!/usr/bin/env python3
"""Read-only input reconciliation and evidence sealing for validation114."""
import difflib
import json
from pathlib import Path
import re
import shutil
import sys
import worker as w

def reconcile(label):
    parent = json.loads((w.ROOT/'ENTRY-PARENT-INPUTS.json').read_text())
    result = {'utc':w.now(), 'parent':w.verify_records(parent['records']),
              'wrapper_sha256':w.sha(w.ROOT/'worker.py')}
    frozen_before = json.loads((w.ROOT/'frozen-source-inventory.json').read_text())
    frozen_now = w.inventory(w.FROZEN)
    result['frozen_source'] = {'before_fingerprint':frozen_before['fingerprint'],
        'current_fingerprint':w.digest(frozen_now), 'unchanged':frozen_now==frozen_before['records']}
    baseline = json.loads((w.REV/'BASELINE.json').read_text())
    result['original_historical_three'] = w.verify_records(baseline['records'])
    manifest = json.loads((w.REV/'MANIFEST.json').read_text())
    result['revision2_manifest_sha256'] = w.sha(w.REV/'MANIFEST.json')
    result['revision2_payloads'] = w.verify_records([dict(r,path=str(w.REV/r['path'])) for r in manifest['files']])
    dep = json.loads((w.ROOT/'dependency-source-inventory.json').read_text())
    result['dependency_sources'] = []
    for p in dep['packages']:
        observed = w.inventory(Path(p['manifest_path']).parent)
        result['dependency_sources'].append({'id':p['id'], 'manifest_path':p['manifest_path'],
             'before_fingerprint':p['fingerprint'], 'current_fingerprint':w.digest(observed),
             'unchanged':observed==p['records']})
    tool_before = json.loads((w.ROOT/'toolchain-inventory.json').read_text())
    tool_now = w.inventory(w.TC)
    result['toolchain'] = {'before_fingerprint':tool_before['fingerprint'],
            'current_fingerprint':w.digest(tool_now), 'unchanged':tool_now==tool_before['records']}
    support = json.loads((w.ROOT/'platform-support-identities.json').read_text())
    result['platform_support'] = w.verify_records(support['identities'])
    result['resource'] = w.resource()
    result['all_observed_inputs_unchanged'] = (
        result['parent']['ok'] and result['frozen_source']['unchanged'] and
        result['original_historical_three']['ok'] and result['revision2_payloads']['ok'] and
        result['revision2_manifest_sha256']=='a586fe4665ee832499ea233969eb2914b941093186596f849d8cfeea9321c342' and
        all(x['unchanged'] for x in result['dependency_sources']) and result['toolchain']['unchanged'] and
        result['platform_support']['ok'])
    w.write(label+'.input-reconciliation.json',result)
    print(json.dumps({'label':label,'unchanged':result['all_observed_inputs_unchanged'], 'resource':result['resource']}),flush=True)
    if not result['all_observed_inputs_unchanged']:
        raise RuntimeError('input authentication/reconciliation failed')

def deltas():
    shutil.copy2(w.FROZEN/'source/rust_verify/build.rs', w.ROOT/'baseline-metadata-build.rs')
    original = {r['path']:r for r in json.loads((w.ROOT/'frozen-source-inventory.json').read_text())['records']}
    final = w.inventory(w.STAGE)
    changed = []
    diff = []
    for record in final:
        rel = record['path']
        if original.get(rel)==record:
            continue
        changed.append({'relative_path':rel,'before':original.get(rel),'after':record})
        a = (w.FROZEN/rel).read_text().splitlines(True) if rel in original else []
        b = (w.STAGE/rel).read_text().splitlines(True)
        diff.extend(difflib.unified_diff(a,b,fromfile='historical/'+rel,tofile='isolated/'+rel))
    deleted = [x for x in original if not (w.STAGE/x).exists()]
    w.write('final-source-delta.json',{'changed':changed,'deleted':deleted,'fingerprint':w.digest(final),'records':final})
    (w.ROOT/'complete-source-delta.patch').write_text(''.join(diff))
    revisions = []
    for record in json.loads((w.REV/'BASELINE.json').read_text())['records']:
        rel = record['relative_path']
        a = (w.REV/'candidate'/rel).read_text().splitlines(True)
        b = (w.STAGE/'source'/rel).read_text().splitlines(True)
        revisions.extend(difflib.unified_diff(a,b,fromfile='revision2/candidate/'+rel,tofile='isolated/source/'+rel))
    (w.ROOT/'source-correction.patch').write_text(''.join(revisions))
    ledger=[]
    for n in (1,2):
        name='command-'+str(n)
        if (w.ROOT/(name+'.receipt.json')).exists():
            receipt=json.loads((w.ROOT/(name+'.receipt.json')).read_text())
            scope=json.loads((w.ROOT/(name+'.scope.json')).read_text())
            ledger.append({'number':n,'scope':scope,'receipt':receipt})
        else:
            ledger.append({'number':n,'status':'RESERVED_UNLAUNCHED','consumed_reservation':True})
    w.write('COMMAND-LEDGER.json',{'compiler_command_cap':2,'commands':ledger,
                                 'no_additional_compilation_authorized':True})
    observed=[]
    for n in (1,2):
        target=w.ROOT/('target-check' if n==1 else 'target-tests')
        raw=(w.ROOT/('command-'+str(n)+'.stderr')).read_text()
        metadata=[]
        for output in sorted((target/'debug/build').glob('rust_verify-*/output')):
            metadata.append({'path':str(output.relative_to(w.ROOT)), 'sha256':w.sha(output), 'raw':output.read_text()})
        direct=[]
        for line in raw.splitlines():
            if line.startswith('     Running `'):
                direct.append(line[len('     Running `'):-1])
        required={crate:any('--crate-name '+crate+' ' in x for x in direct) for crate in ('rustc_mir_build','rust_verify')}
        observed.append({'number':n,'observed_direct_cargo_verbose_invocations':direct,
             'required_crates_observed':required,'actual_build_script_outputs':metadata,
             'normal_check_emit_scope': 'dep-info,metadata' if n==1 else 'test harness and library dependencies',
             'notes':'Cargo verbose is not a complete OS execution trace. No working engine or source-to-binary/core proof claim.'})
    w.write('actual-command-scopes.json',observed)
    metadata=json.loads((w.ROOT/'preflight-cargo-metadata.stdout').read_text())
    roots={p['id'] for p in metadata['packages'] if p['name']=='rust_verify'}
    nodes={x['id']:x for x in metadata['resolve']['nodes']}
    visited=set()
    def visit(key):
        if key in visited:
            return
        visited.add(key)
        for dep in nodes[key]['dependencies']:
            visit(dep)
    for key in roots:
        visit(key)
    w.write('rust-verify-resolved-dependency-closure.json',{'root_ids':sorted(roots),
        'packages':[p for p in metadata['packages'] if p['id'] in visited],
        'scope':'Cargo metadata resolved package graph, including feature/target graph conservatism. Actual rustc invocations are separately retained.'})
    print('Deltas and ledger retained.',flush=True)

def seal():
    for excluded in ('SEALED-MANIFEST.json','SEALED-MANIFEST.sha256'):
        assert not (w.ROOT/excluded).exists(), 'seal already exists'
    records=w.inventory(w.ROOT)
    w.write('SEALED-MANIFEST.json',{'utc':w.now(),'root':str(w.ROOT),'records':records,
        'fingerprint':w.digest(records),'scope':'All retained payload files before this manifest; manifest checksum is separately recorded.',
        'all18':'OPEN','source_path':'FAILED','git_continuity':'UNAVAILABLE','compiler_source':'UNESTABLISHED',
        'output_adoption':False,'conditional_unadopted_tcb':True,'goal_service_last_observed':'BLOCKED'})
    (w.ROOT/'SEALED-MANIFEST.sha256').write_text(w.sha(w.ROOT/'SEALED-MANIFEST.json')+'  SEALED-MANIFEST.json\n')
    print('SEALED-MANIFEST.json SHA256 '+w.sha(w.ROOT/'SEALED-MANIFEST.json'),flush=True)

def finalize():
    receipts=[json.loads((w.ROOT/('command-'+str(n)+'.receipt.json')).read_text()) for n in (1,2)]
    scopes=[json.loads((w.ROOT/('command-'+str(n)+'.source-after.json')).read_text()) for n in (1,2)]
    tests=json.loads((w.ROOT/'selected-test-results.json').read_text())
    reconciled=json.loads((w.ROOT/'final.input-reconciliation.json').read_text())
    delta=json.loads((w.ROOT/'final-source-delta.json').read_text())
    assert all(r['status']=='EXITED_ZERO' and r['child_exit_code']==0 and r['owned_process_group_absent'] and r['elapsed_seconds']<=1200 for r in receipts)
    assert all(s['unchanged'] for s in scopes)
    assert tests['exact_five_pass'] and reconciled['all_observed_inputs_unchanged']
    assert len(delta['changed'])==4 and not delta['deleted']
    assert (w.ROOT/'source-correction.patch').stat().st_size==0
    samples=[]
    for path in w.ROOT.glob('*.resources.jsonl'):
        samples.extend(json.loads(line) for line in path.read_text().splitlines())
    final=w.resource()
    assert final['safe'] and all(s['safe'] for s in samples)
    resource={'utc':w.now(),'final_before_seal':final,'sample_count':len(samples),
        'minimum_sampled_free_bytes':min(s['disk_free_bytes'] for s in samples+[final]),
        'maximum_sampled_fresh_allocated_bytes':max(s['fresh_allocated_bytes'] for s in samples+[final]),
        'maximum_sampled_fresh_logical_bytes':max(s['fresh_logical_bytes'] for s in samples+[final]),
        'limits':{'fresh_bytes_strictly_below':8*1024**3,'free_bytes_strictly_above':16*1024**3},
        'samples_are_periodic_not_continuous':True}
    w.write('final-resource.json',resource)
    summary={'utc':w.now(),'classification':'ISOLATED_PINNED_CHECK_AND_FIVE_PURE_METADATA_TESTS_PASSED_UNADOPTED',
        'compiler_producing_commands':2,'command_limit':2,'check_passed':True,'filtered_exact_five_tests_passed':True,
        'working_engine_built':False,'vstd_built':False,'native_redb_run':False,'proof_replay':False,
        'source_corrections':False,'metadata_adaptation':True,'source_fingerprint':scopes[0]['fingerprint'],
        'source_same_for_both_commands':scopes[0]['fingerprint']==scopes[1]['fingerprint'],
        'inputs_reconciled':True,'parent_1478_unchanged':True,'source_git_continuity_claimed':False,
        'all18':'OPEN','source_path':'FAILED','git_continuity':'UNAVAILABLE','compiler_source':'UNESTABLISHED',
        'output_adoption':False,'conditional_unadopted_tcb':True,'goal_service_last_observed':'BLOCKED',
        'goal_service_altered':False,'resource':resource,
        'capture_limit':'Exploratory read-only shell failures have conversation tool outputs and a disclosure note; managed executable preflights and both compiler commands retain full raw stdout/stderr and receipts.',
        'no_additional_automatic_work':True}
    w.write('VALIDATION.json',summary)
    print(json.dumps(summary,sort_keys=True),flush=True)

if __name__=='__main__':
    if sys.argv[1]=='reconcile':
        reconcile(sys.argv[2])
    elif sys.argv[1]=='deltas':
        deltas()
    elif sys.argv[1]=='seal':
        seal()
    elif sys.argv[1]=='finalize':
        finalize()
