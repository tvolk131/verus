# Exploratory read failures retained

Before the logged setup harness, read-only inspection encountered these failures.
They were not compiler launches or hidden retries. All compiler-producing slots
were reserved in RESERVATIONS.json before staging/setup.

1. `pwd && rg --files -g 'AGENTS.md' -g 'AUTHORIZATION.md' -g 'PLAN.md' evidence/redb-lifecycle-compiler-validation114 .agents .codex`
   exited 2. stdout listed the workspace and AUTHORIZATION.md/PLAN.md; stderr:
   `rg: .agents: No such file or directory (os error 2)` and
   `rg: .codex: No such file or directory (os error 2)`.
   Reading AGENTS.md in all workspace ancestors subsequently found none.
2. An exploratory combined read of versions.rs, a checked_normal_drop.rs range,
   `/Users/tommyvolk/.cargo/config*`, and staged/tools exited 1 at the unmatched
   zsh config glob: `zsh:1: no matches found: /Users/tommyvolk/.cargo/config*`.
   No configuration or source mutation occurred. The actual Cargo metadata
   preflight was separately logged in full and succeeded offline/locked.
3. Reading the entire old runtime-binding.json produced tool-output truncation.
   The source file was not altered; setup read it directly, recorded its hash,
   and retained every selected source-path comparison in JSON. No runtime
   artifacts were adopted, copied, or executed.
4. A subsequent read of util.rs followed by an exploratory `ls -ld` of target
   paths exited 1 at an unmatched `snapshot/source/target*` glob. The listed
   stderr was `zsh:1: no matches found:` followed by that private scratch path.
   This confirmed no source-local target path matched; recorded Cargo verbose
   invocations independently show both fresh target directories outside source.

These exploratory tool outputs live in the parent conversation; they are not
presented as full raw machine stdout/stderr captures. Every executable version,
support, Cargo metadata, check, and test launch managed by worker.py has separate
full raw stdout/stderr, exact argv/environment, and receipt files. The wrapper
does not claim a complete OS process trace or shared-library/bootstrap closure.
