import datetime
import json
import pathlib
import shutil
import time

import audit_repair
import control

ROOT = control.ROOT


def main():
    control.guard()
    audit_repair.main()
    report_size = (ROOT / 'REPORT.md').stat().st_size
    assert report_size <= 24 * 1024
    result = json.loads((ROOT / 'RESULTS.json').read_text())
    result['positive_application_proof_credit_invocations'] = [3, 5, 6]
    result['failed_invocation_positive_proof_credit'] = 0
    result['same_existing_cache_directory_replay_passed'] = True
    result['persisted_warm_candidate_or_cache_hit_demonstrated'] = False
    result['strict_warmed_persisted_candidate_prerequisite_established'] = False
    result['acceptance_pending_independent_review_and_cache_interpretation'] = True
    result['final_source_sha256'] = {
        name: control.auth.digest(ROOT / 'native/src' / name)
        for name in ('lib.rs', 'encoding_spec.rs')
    }
    control.record('RESULTS.json', result)
    control.authenticate('handoff-final')
    elapsed = time.time() - control.START
    assert elapsed < 900
    control.record('handoff-finalization.json', dict(
        completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        scratch_root=str(ROOT), wall_seconds=elapsed, deadline_seconds=900,
        direct_verifier_applications=6, diagnostic_probes=0,
        verifier_seconds=result['summed_verifier_seconds'],
        report_bytes=report_size, allocated_bytes=control.allocation(),
        free_bytes=shutil.disk_usage(ROOT).free,
        final_native_acceptance=False, parent_integration=False, trust_adoption=False,
        original_failed95_output_manifest_entries_authenticated=92,
        no_additional_verifier_applications=True))
    manifest = {str(path.relative_to(ROOT)): dict(sha256=control.auth.digest(path), bytes=path.stat().st_size)
                for path in sorted(ROOT.rglob('*')) if path.is_file() and path.name != 'output-manifest.json'}
    control.record('output-manifest.json', manifest)
    assert control.allocation() < 256 * 1024**2
    print(json.dumps(dict(status='HANDOFF_READY_NO_FINAL_ACCEPTANCE',
        report=str(ROOT / 'REPORT.md'), patch=str(ROOT / 'final-source.patch'),
        proof=str(ROOT / 'native/src/encoding_spec.rs'), receipts=str(ROOT / 'validation-receipts.json'),
        report_bytes=report_size, wall_seconds=elapsed, direct_applications=6,
        allocated_bytes=control.allocation(), manifest_entries=len(manifest),
        manifest_sha256=control.auth.digest(ROOT / 'output-manifest.json'))))


if __name__ == '__main__':
    main()
