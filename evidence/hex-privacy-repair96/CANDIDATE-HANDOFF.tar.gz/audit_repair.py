import collections
import difflib
import hashlib
import json
import pathlib
import re
import tarfile
import time

import control

ROOT = control.ROOT
OLD = control.OLD
PARENT = control.PARENT


def sha(data):
    return hashlib.sha256(data).hexdigest()


def load(path):
    return json.loads(path.read_text())


def function(text, name):
    match = re.search(r'pub\(crate\) fn ' + name + r'\([^\n]+\{', text)
    assert match
    position = match.end()
    depth = 1
    while depth:
        depth += (text[position] == '{') - (text[position] == '}')
        position += 1
    return text[match.start():position]


def main():
    control.guard()
    native = ROOT / 'native'
    baseline = load(ROOT / 'native-authenticated-manifest.json')
    current = {str(path.relative_to(native)): control.auth.digest(path)
               for path in native.rglob('*') if path.is_file()}
    assert set(current) == set(baseline) | {'src/encoding_spec.rs'}
    assert [name for name in baseline if baseline[name] != current[name]] == ['src/lib.rs']
    with tarfile.open(control.auth.EVIDENCE / 'native-source.tar.gz', 'r:gz') as archive:
        original = archive.extractfile('src/lib.rs').read().decode()
    candidate = (native / 'src/lib.rs').read_text()
    policy = (native / 'src/encoding_spec.rs').read_text()
    additions = []
    matcher = difflib.SequenceMatcher(a=original.splitlines(True), b=candidate.splitlines(True), autojunk=False)
    for tag, before_start, before_end, after_start, after_end in matcher.get_opcodes():
        assert tag in ('equal', 'insert'), (tag, before_start, after_start)
        if tag == 'insert':
            additions.append(dict(original_line=before_start + 1, candidate_line=after_start + 1,
                                  text=''.join(candidate.splitlines(True)[after_start:after_end])))
    ghost = '            #[cfg(verus_keep_ghost)]\n            proof! { crate::encoding_spec::encoding_index_facts(byte); }\n'
    functions = {}
    for name in ('table', 'byte_to_hex_chars'):
        original_function = function(original, name)
        erased_function = function(candidate, name).replace(ghost, '')
        assert original_function == erased_function
        functions[name] = dict(original_sha256=sha(original_function.encode()),
                               erased_sha256=sha(erased_function.encode()))
    constants = {}
    for name in ('LOWER', 'UPPER'):
        pattern = r'pub\(crate\) const ' + name + r': Self = Table\(\[.*?\]\);'
        before = re.search(pattern, original, re.S).group()
        after = re.search(pattern, candidate, re.S).group()
        assert before == after
        constants[name] = dict(initializer_unchanged=True, sha256=sha(before.encode()),
                               selected_exec_constant_with_body_checked_postcondition=True)
    assert re.findall(r'#\[derive\([^\n]+', original) == re.findall(r'#\[derive\([^\n]+', candidate)
    assert candidate.count('pub(crate) struct Table([Char; 16]);') == 1
    inserted = ''.join(item['text'] for item in additions)
    assert not re.search(r'\b(assume|admit|axiom|external_body|assume_specification|requires)\b', inserted + policy)
    assert 'result@[0] == self@[(byte as int) / 16]' in inserted
    assert 'result@[1] == self@[(byte as int) % 16]' in inserted
    delta = ''.join(difflib.unified_diff(original.splitlines(True), candidate.splitlines(True),
        fromfile='authenticated-v3/src/lib.rs', tofile='candidate/src/lib.rs'))
    delta += ''.join(difflib.unified_diff([], policy.splitlines(True),
        fromfile='/dev/null', tofile='candidate/src/encoding_spec.rs'))
    (ROOT / 'final-source.patch').write_text(delta)
    failed = (OLD / 'native/src/lib.rs').read_text()
    (ROOT / 'repair-versus-failed-candidate.patch').write_text(''.join(difflib.unified_diff(
        failed.splitlines(True), candidate.splitlines(True),
        fromfile='preserved-failed95/src/lib.rs', tofile='candidate/src/lib.rs')))
    preservation = dict(native_files=53, native_manifest=current, additions=additions,
        all_original_lines_preserved=True, changes_only_insertions=True,
        all_other_archived_files_unchanged=True, original_signatures_and_erased_bodies=functions,
        constants=constants, original_derives_and_field_privacy_unchanged=True,
        retained_original_requirements_unchanged=True, no_new_preconditions=True,
        helper_domain='every legal Table([Char;16]); unconditional exact view selection equations',
        goal_domain='all 256 u8 inputs and both Case variants',
        no_new_trusted_specification_or_axiom=True)
    control.record('source-preservation-audit.json', preservation)
    historical = load(ROOT / 'historical-v3-baseline.json')['inference']
    old_checked = {item['function'] for item in historical['verification_scope']['native_functions']
                   if item['body_status'] == 'checked_exec_body'}
    summaries = []
    positive_sources = None
    model_inventory = None
    positive_assistance = None
    for directory in sorted(ROOT.glob('invocation-*')):
        invocation = load(directory / 'invocation.json')
        result = load(directory / 'result.json')
        data = load(directory / 'stdout')
        inference = data.get('verus-infer', {})
        verification = data.get('verification-results', {})
        scope = inference.get('verification_scope', {})
        assert not result['timeout']
        assert result['seconds'] < 90
        assert invocation['argv'].count('--infer-goals') == 1
        assert invocation['argv'].count('--no-cheating') == 1
        assert not set(invocation['argv']) & {'--no-verify', '--no-lifetime', '--verify-function', '--verify-module', '--compile'}
        summary = dict(invocation=invocation['invocation'], kind=invocation['kind'],
            seconds=result['seconds'], returncode=result['returncode'], verification=verification,
            inference_status=inference.get('status'), crate_success=inference.get('crate_success'),
            interface_written=inference.get('interface_written'), exported=result['exported'],
            scope={key:value for key,value in scope.items() if key != 'native_functions'},
            inference_functions=inference.get('functions'),
            cache_before=invocation['cache_before'], cache_after=result['cache_after'])
        if result['returncode'] == 0:
            assert invocation['invocation'] in (3, 5, 6)
            assert verification['success'] and verification['errors'] == 0 and verification['verified'] == 48
            assert verification['is-verifying-entire-crate']
            assert scope['native_collection_completed'] and scope['complete_selected_scope_verified']
            checked = {item['function'] for item in scope['native_functions'] if item['body_status'] == 'checked_exec_body'}
            assert old_checked <= checked
            assert scope['checked_exec_bodies'] == 36 and scope['checked_proof_bodies'] == 1
            assert inference['interface_written'] and inference['crate_success']
            assert inference['requested_functions'] == inference['generated_functions'] == 1
            generated = inference['functions'][0]
            assert generated['function'] == 'hex_conservative::iter::hex_chars_to_byte'
            assert generated['contract'] == historical['functions'][0]['contract']
            for proof in generated['proofs'].values():
                assert proof['required'] and proof['status'] == 'proved'
            assert generated['metrics']['solver_micros'] > 0
            assert inference['goal_assistance'] == []
            if positive_sources is None:
                positive_sources = invocation['source_hashes']
                model_inventory = inference['trusted_models']
                positive_assistance = {key:value for key,value in inference.items() if key.endswith('_assistance')}
            assert invocation['source_hashes'] == positive_sources
            assert inference['trusted_models'] == model_inventory
            summary['retained_32_exec_bodies_checked'] = True
            summary['new_exec_bodies'] = sorted(checked - old_checked)
        if invocation['kind'] == 'semantic-negative':
            assert verification['errors'] == 1 and not verification['success']
            assert not verification['encountered-vir-error'] and not inference['interface_written']
            assert not result['exported'] and not inference['crate_success']
            assert inference['status'] == 'caller_proof_failed'
            positive = (ROOT / 'invocation-03/source/lib.rs').read_text()
            negative = (directory / 'source/lib.rs').read_text()
            expected = positive.replace('Case::Lower => &Table::LOWER,', 'Case::Lower => &Table::UPPER,')
            assert negative == expected and negative != positive
            assert (directory / 'source/encoding_spec.rs').read_text() == policy
            stderr = (directory / 'stderr').read_text()
            assert 'error: postcondition not satisfied' in stderr
            assert 'canonical_table(result@, self)' in stderr
            (ROOT / 'semantic-negative.patch').write_text(''.join(difflib.unified_diff(
                positive.splitlines(True), negative.splitlines(True), fromfile='positive/src/lib.rs',
                tofile='negative/src/lib.rs')))
            summary['single_original_lower_branch_mutation_only'] = True
        summaries.append(summary)
    assert len(summaries) == 6
    assert current == positive_sources
    control.record('validation-receipts.json', summaries)
    control.record('imported-model-inventory.json', dict(models=model_inventory,
        qualification='existing matched frozen vstd imported model fingerprints; not new source axioms',
        historical_model_count=len(historical['trusted_models']), frozen_run_model_count=len(model_inventory)))
    control.record('assistance-inventory.json', positive_assistance)
    binding = load(ROOT / 'preserved-input-bindings.json')
    assert all(control.auth.digest(path) == value for path,value in binding.items())
    old_manifest = load(OLD / 'output-manifest.json')
    for name, value in old_manifest.items():
        assert control.auth.digest(OLD / name) == value['sha256']
    frozen = load(control.RUNTIME / 'compiler-source-manifest.json')
    research = {}
    names = ['source/builtin_macros/src/attr_rewrite.rs', 'source/builtin_macros/src/syntax.rs',
             'source/rust_verify/src/rust_to_vir_func.rs', 'source/rust_verify/src/attributes.rs',
             'source/rust_verify/src/infer_report.rs', 'source/vir/src/infer/registry.rs',
             'source/rust_verify_test/tests/adts_opaque.rs',
             'source/rust_verify_test/tests/infer_cases/visibility.rs',
             'source/rust_verify_test/tests/consts.rs']
    for name in names:
        digest = control.auth.digest(PARENT / name)
        research[name] = dict(sha256=digest, frozen_sha256=frozen.get(name),
                              matches_frozen_manifest=digest == frozen.get(name))
    control.record('source-investigation-bindings.json', research)
    control.authenticate('exit')
    control.record('RESULTS.json', dict(outcome='FROZEN_OPERATIONAL91_REPAIR_VERIFIED_WITH_CONTROLS',
        final_native_acceptance=False, trust_adoption=False, parent_integration=False,
        prior_failed95_result_unchanged=True, preserved_failed_manifest_entries=len(old_manifest),
        direct_verifier_applications=6, diagnostic_probes=0, passed_invocations=[3,5,6],
        semantic_negative=4, routine_failed_attempts=[1,2],
        summed_verifier_seconds=sum(item['seconds'] for item in summaries),
        wall_seconds=time.time() - control.START, allocated_bytes=control.allocation(),
        remaining_invocations_not_spent=10,
        warm_replay='same existing private cache directory reused; record/owned summary regenerated by policy, no cache hit or persisted candidate',
        required_inference_certificates_rechecked_in_warm_run=True,
        qualification='frozen operational91-engine only; not current parent/historical-v3 engine acceptance',
        redb_open=18, S0_unchanged=True, ordinary_infer_full_scope_import_export_barriers_unchanged=True))
    print(json.dumps(dict(audit='passed', original_native_files=53, preserved_failed_manifest_entries=len(old_manifest),
                         direct_invocations=6, positives=[3,5,6], semantic_negative=4,
                         wall_seconds=time.time() - control.START, allocated_bytes=control.allocation())))


if __name__ == '__main__':
    main()
