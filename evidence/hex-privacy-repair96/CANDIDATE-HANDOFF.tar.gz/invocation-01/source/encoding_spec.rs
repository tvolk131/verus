use vstd::prelude::*;

verus! {

pub(crate) open spec fn required_digit_ascii(nibble: int, case: crate::Case) -> int {
    if nibble < 10 {
        48 + nibble
    } else {
        match case {
            crate::Case::Lower => 87 + nibble,
            crate::Case::Upper => 55 + nibble,
        }
    }
}

pub(crate) open spec fn canonical_table(table: Seq<crate::Char>, case: crate::Case) -> bool {
    table.len() == 16 && forall|nibble: int| 0 <= nibble < 16 ==>
        (#[trigger] table[nibble] as u8) as int == required_digit_ascii(nibble, case)
}

pub(crate) open spec fn required_encoding(
    byte: u8,
    case: crate::Case,
    result: [crate::Char; 2],
) -> bool {
    (result@[0] as u8) as int == required_digit_ascii((byte as int) / 16, case)
        && (result@[1] as u8) as int == required_digit_ascii((byte as int) % 16, case)
}

pub(crate) proof fn encoding_index_facts(byte: u8)
    ensures
        (byte >> 4) < 16,
        (byte & 0x0f) < 16,
        (byte >> 4) == byte / 16,
        (byte & 0x0f) == byte % 16,
{
    assert((byte >> 4) < 16) by(bit_vector);
    assert((byte & 0x0f) < 16) by(bit_vector);
    assert((byte >> 4) == byte / 16) by(bit_vector);
    assert((byte & 0x0f) == byte % 16) by(bit_vector);
}

fn canonical_byte_encoding_goal(byte: u8, case: crate::Case) -> (result: [crate::Char; 2])
    ensures
        required_encoding(byte, case, result),
{
    case.table().byte_to_hex_chars(byte)
}

}
