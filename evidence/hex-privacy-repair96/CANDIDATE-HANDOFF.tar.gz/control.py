import datetime
import difflib
import hashlib
import importlib.util
import json
import os
import pathlib
import resource
import shutil
import signal
import subprocess
import sys
import time

sys.dont_write_bytecode = True
ROOT = pathlib.Path(__file__).resolve().parent
OLD = pathlib.Path('/private/tmp/verus-native-hex130-encoding-20261107-1VZM03')
PARENT = pathlib.Path('/Users/tommyvolk/.t3/worktrees/verus/t3-60978068')
spec = importlib.util.spec_from_file_location('preserved_authentication', OLD / 'prepare.py')
auth = importlib.util.module_from_spec(spec)
spec.loader.exec_module(auth)
auth.ROOT = ROOT
RUNTIME = auth.RUNTIME
START = ROOT.stat().st_birthtime


def record(name, value):
    auth.record(name, value)


def allocation():
    return sum(max(path.stat().st_size, path.stat().st_blocks * 512)
               for path in ROOT.rglob('*') if path.is_file())


def guard():
    assert shutil.disk_usage(ROOT).free > 16 * 1024**3
    assert allocation() < 256 * 1024**2
    assert time.time() - START < 900


def authenticate(label):
    guard()
    assert auth.digest(RUNTIME / 'runtime-manifest.json') == '1fa38f105d5b9fda9bda2ad3b0ee4518f083f917bc77dcbce6585ff152e476a3'
    return auth.authenticate(label)


def setup():
    authenticate('entry')
    auth.prepare()
    paths = [OLD / 'REPORT.md', OLD / 'invocation-1/stderr', OLD / 'invocation-1/stdout',
             OLD / 'invocation-1/invocation.json', OLD / 'invocation-1/result.json',
             OLD / 'prepare.py', OLD / 'audit.py']
    paths += list((PARENT / 'evidence/hex-canonical-encoding95').iterdir())
    bindings = {str(path): auth.digest(path) for path in paths if path.is_file()}
    record('preserved-input-bindings.json', bindings)
    for directory in ('home', 'tmp', 'xdg-cache'):
        (ROOT / directory).mkdir(exist_ok=True)
    record('authorization-and-budgets.json', dict(start_epoch=START, wall_seconds=900,
        direct_invocations=16, diagnostic_probes=4, reserved_controls=3,
        max_invocation_seconds=90, workers=1, max_scratch_bytes=256 * 1024**2,
        minimum_free_bytes=16 * 1024**3, old_failure_unchanged=True,
        qualification='frozen operational91-engine only; no current-parent or historical-v3 acceptance'))
    print(json.dumps(dict(root=str(ROOT), prepared=True, direct_invocations=0)))


def limits():
    resource.setrlimit(resource.RLIMIT_FSIZE, (12 * 1024**2, 12 * 1024**2))
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))


def invoke(kind, cache_name):
    guard()
    previous = sorted(ROOT.glob('invocation-*/invocation.json'))
    number = len(previous) + 1
    assert number <= 16
    probes = sum(json.loads(path.read_text())['kind'] == 'diagnostic-probe' for path in previous)
    assert kind != 'diagnostic-probe' or probes < 4
    if kind not in ('semantic-negative', 'restored-fresh', 'restored-warm'):
        assert number <= 13
    authenticate('pre-' + str(number))
    destination = ROOT / ('invocation-%02d' % number)
    destination.mkdir()
    cache = ROOT / cache_name
    cache.mkdir(exist_ok=kind == 'restored-warm')
    old_metadata = json.loads((OLD / 'invocation-1/invocation.json').read_text())
    environment = old_metadata['environment'].copy()
    for name in ('HOME', 'TMPDIR', 'XDG_CACHE_HOME', 'VERUS_INFER_CACHE'):
        environment[name] = environment[name].replace(str(OLD), str(ROOT))
    environment['VERUS_INFER_CACHE'] = str(cache)
    argv = [arg.replace(str(OLD / 'native'), str(ROOT / 'native')) for arg in old_metadata['argv']]
    for flag in ('--export', '--out-dir'):
        offset = argv.index(flag) + 1
        argv[offset] = str(destination / 'hex_conservative.vir') if flag == '--export' else str(destination)
    snapshot = destination / 'source'
    snapshot.mkdir()
    for name in ('lib.rs', 'encoding_spec.rs'):
        shutil.copyfile(ROOT / 'native/src' / name, snapshot / name)
    source_hashes = {str(path.relative_to(ROOT / 'native')): auth.digest(path)
                     for path in (ROOT / 'native').rglob('*') if path.is_file()}
    cache_before = {str(path.relative_to(cache)): auth.digest(path) for path in cache.rglob('*') if path.is_file()}
    timeout = min(90, int(900 - (time.time() - START) - 3))
    assert timeout > 0
    record(str(destination.relative_to(ROOT) / 'invocation.json'), dict(invocation=number,
        kind=kind, application_credit=kind != 'diagnostic-probe', argv=argv, environment=environment,
        cwd=str(ROOT / 'native'), timeout_seconds=timeout, source_hashes=source_hashes,
        cache_before=cache_before, allocated_bytes=allocation(), free_bytes=shutil.disk_usage(ROOT).free,
        started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()))
    started = time.monotonic()
    timed_out = False
    with (destination / 'stdout').open('wb') as stdout, (destination / 'stderr').open('wb') as stderr:
        process = subprocess.Popen(argv, cwd=ROOT / 'native', env=environment, stdin=subprocess.DEVNULL,
                                   stdout=stdout, stderr=stderr, start_new_session=True, preexec_fn=limits)
        try:
            process.wait(timeout=timeout - 0.5)
        except subprocess.TimeoutExpired:
            timed_out = True
            os.killpg(process.pid, signal.SIGKILL)
            process.wait()
    result = dict(invocation=number, kind=kind, returncode=process.returncode, timeout=timed_out,
        seconds=time.monotonic() - started, exported=(destination / 'hex_conservative.vir').exists(),
        stdout_sha256=auth.digest(destination / 'stdout'), stderr_sha256=auth.digest(destination / 'stderr'),
        source_hashes=source_hashes,
        cache_after={str(path.relative_to(cache)): auth.digest(path) for path in cache.rglob('*') if path.is_file()})
    record(str(destination.relative_to(ROOT) / 'result.json'), result)
    authenticate('post-' + str(number))
    print(json.dumps({key: value for key, value in result.items() if key not in ('source_hashes', 'cache_after')}))
    print((destination / 'stderr').read_text()[-11000:])


if __name__ == '__main__':
    if sys.argv[1] == 'setup':
        setup()
    else:
        invoke(sys.argv[1], sys.argv[2])
