#![feature(prelude_import)]
//! Utilities for node addressing and message signing.
extern crate std;
#[prelude_import]
use std::prelude::rust_2021::*;

mod node {

    use codec::{Decode, Encode, Error, Input, Output};
    use vstd::prelude::*;
    use derive_more::{Add, AddAssign, From, Into, Sub, SubAssign, Sum};
    use std::{
        collections::HashMap, fmt, hash::Hash,
        ops::{Div, Index as StdIndex, Mul},
        vec,
    };
    /// The index of a node
    pub struct NodeIndex(pub usize);
    #[automatically_derived]
    impl ::core::marker::Copy for NodeIndex { }
    #[automatically_derived]
    #[doc(hidden)]
    unsafe impl ::core::clone::TrivialClone for NodeIndex { }
    #[automatically_derived]
    impl ::core::clone::Clone for NodeIndex {
        #[inline]
        fn clone(&self) -> NodeIndex {
            let _: ::core::clone::AssertParamIsClone<usize>;
            *self
        }
    }
    #[automatically_derived]
    impl ::core::cmp::Eq for NodeIndex {
        #[inline]
        #[doc(hidden)]
        #[coverage(off)]
        fn assert_fields_are_eq(&self) {
            let _: ::core::cmp::AssertParamIsEq<usize>;
        }
    }
    #[automatically_derived]
    impl ::core::marker::StructuralPartialEq for NodeIndex { }
    #[automatically_derived]
    impl ::core::cmp::PartialEq for NodeIndex {
        #[inline]
        fn eq(&self, other: &NodeIndex) -> bool { self.0 == other.0 }
    }
    #[automatically_derived]
    impl ::core::cmp::Ord for NodeIndex {
        #[inline]
        fn cmp(&self, other: &NodeIndex) -> ::core::cmp::Ordering {
            ::core::cmp::Ord::cmp(&self.0, &other.0)
        }
    }
    #[automatically_derived]
    impl ::core::cmp::PartialOrd for NodeIndex {
        #[inline]
        fn partial_cmp(&self, other: &NodeIndex)
            -> ::core::option::Option<::core::cmp::Ordering> {
            ::core::option::Option::Some(::core::cmp::Ord::cmp(self, other))
        }
    }
    #[automatically_derived]
    impl ::core::hash::Hash for NodeIndex {
        #[inline]
        fn hash<__H: ::core::hash::Hasher>(&self, state: &mut __H) {
            ::core::hash::Hash::hash(&self.0, state)
        }
    }
    #[automatically_derived]
    impl ::core::fmt::Debug for NodeIndex {
        #[inline]
        fn fmt(&self, f: &mut ::core::fmt::Formatter) -> ::core::fmt::Result {
            ::core::fmt::Formatter::debug_tuple_field1_finish(f, "NodeIndex",
                &&self.0)
        }
    }
    #[automatically_derived]
    impl ::core::default::Default for NodeIndex {
        #[inline]
        fn default() -> NodeIndex {
            NodeIndex(::core::default::Default::default())
        }
    }
    #[automatically_derived]
    impl derive_more::From<(usize)> for NodeIndex {
        #[inline]
        fn from(value: (usize)) -> Self { NodeIndex(value) }
    }
    #[allow(clippy :: unused_unit)]
    #[automatically_derived]
    impl derive_more::core::convert::From<NodeIndex> for (usize) {
        #[inline]
        fn from(value: NodeIndex) -> Self {
            (<usize as derive_more::core::convert::From<_>>::from(value.0))
        }
    }
    impl Encode for NodeIndex {
        fn encode_to<T: Output + ?Sized>(&self, dest: &mut T) {
            let val = self.0 as u64;
            let bytes = val.to_le_bytes();
            dest.write(&bytes);
        }
    }
    impl Decode for NodeIndex {
        fn decode<I: Input>(value: &mut I) -> Result<Self, Error> {
            let mut arr = [0u8; 8];
            value.read(&mut arr)?;
            let val: u64 = u64::from_le_bytes(arr);
            Ok(NodeIndex(val as usize))
        }
    }
    /// Indicates that an implementor has been assigned some index.
    pub trait Index {
        fn index(&self)
        -> NodeIndex;
    }
    /// Node count. Right now it doubles as node weight in many places in the code, in the future we
    /// might need a new type for that.
    pub struct NodeCount(pub usize);
    #[automatically_derived]
    impl ::core::marker::Copy for NodeCount { }
    #[automatically_derived]
    #[doc(hidden)]
    unsafe impl ::core::clone::TrivialClone for NodeCount { }
    #[automatically_derived]
    impl ::core::clone::Clone for NodeCount {
        #[inline]
        fn clone(&self) -> NodeCount {
            let _: ::core::clone::AssertParamIsClone<usize>;
            *self
        }
    }
    #[automatically_derived]
    impl ::core::cmp::Eq for NodeCount {
        #[inline]
        #[doc(hidden)]
        #[coverage(off)]
        fn assert_fields_are_eq(&self) {
            let _: ::core::cmp::AssertParamIsEq<usize>;
        }
    }
    #[automatically_derived]
    impl ::core::marker::StructuralPartialEq for NodeCount { }
    #[automatically_derived]
    impl ::core::cmp::PartialEq for NodeCount {
        #[inline]
        fn eq(&self, other: &NodeCount) -> bool { self.0 == other.0 }
    }
    #[automatically_derived]
    impl ::core::cmp::Ord for NodeCount {
        #[inline]
        fn cmp(&self, other: &NodeCount) -> ::core::cmp::Ordering {
            ::core::cmp::Ord::cmp(&self.0, &other.0)
        }
    }
    #[automatically_derived]
    impl ::core::cmp::PartialOrd for NodeCount {
        #[inline]
        fn partial_cmp(&self, other: &NodeCount)
            -> ::core::option::Option<::core::cmp::Ordering> {
            ::core::option::Option::Some(::core::cmp::Ord::cmp(self, other))
        }
    }
    #[automatically_derived]
    impl ::core::hash::Hash for NodeCount {
        #[inline]
        fn hash<__H: ::core::hash::Hasher>(&self, state: &mut __H) {
            ::core::hash::Hash::hash(&self.0, state)
        }
    }
    #[automatically_derived]
    impl ::core::fmt::Debug for NodeCount {
        #[inline]
        fn fmt(&self, f: &mut ::core::fmt::Formatter) -> ::core::fmt::Result {
            ::core::fmt::Formatter::debug_tuple_field1_finish(f, "NodeCount",
                &&self.0)
        }
    }
    #[automatically_derived]
    impl ::core::default::Default for NodeCount {
        #[inline]
        fn default() -> NodeCount {
            NodeCount(::core::default::Default::default())
        }
    }
    #[automatically_derived]
    impl derive_more::Add for NodeCount {
        type Output = NodeCount;
        #[inline]
        #[track_caller]
        fn add(self, rhs: NodeCount) -> NodeCount {
            NodeCount(self.0.add(rhs.0))
        }
    }
    #[automatically_derived]
    impl derive_more::AddAssign for NodeCount {
        #[inline]
        #[track_caller]
        fn add_assign(&mut self, rhs: NodeCount) { self.0.add_assign(rhs.0); }
    }
    #[automatically_derived]
    impl derive_more::From<(usize)> for NodeCount {
        #[inline]
        fn from(value: (usize)) -> Self { NodeCount(value) }
    }
    #[allow(clippy :: unused_unit)]
    #[automatically_derived]
    impl derive_more::core::convert::From<NodeCount> for (usize) {
        #[inline]
        fn from(value: NodeCount) -> Self {
            (<usize as derive_more::core::convert::From<_>>::from(value.0))
        }
    }
    #[automatically_derived]
    impl derive_more::Sub for NodeCount {
        type Output = NodeCount;
        #[inline]
        #[track_caller]
        fn sub(self, rhs: NodeCount) -> NodeCount {
            NodeCount(self.0.sub(rhs.0))
        }
    }
    #[automatically_derived]
    impl derive_more::SubAssign for NodeCount {
        #[inline]
        #[track_caller]
        fn sub_assign(&mut self, rhs: NodeCount) { self.0.sub_assign(rhs.0); }
    }
    #[automatically_derived]
    impl derive_more::Sum for NodeCount {
        #[inline]
        fn sum<I: derive_more::core::iter::Iterator<Item = Self>>(iter: I)
            -> Self {
            iter.fold(NodeCount(derive_more::Sum::sum(derive_more::core::iter::empty::<usize>())),
                derive_more::core::ops::Add::add)
        }
    }
    impl Mul<usize> for NodeCount {
        type Output = Self;
        fn mul(self, rhs: usize) -> Self::Output { NodeCount(self.0 * rhs) }
    }
    impl Div<usize> for NodeCount {
        type Output = Self;
        fn div(self, rhs: usize) -> Self::Output { NodeCount(self.0 / rhs) }
    }
    impl NodeCount {
        pub fn into_range(self) -> core::ops::Range<NodeIndex> {
            core::ops::Range { start: 0.into(), end: self.0.into() }
        }
        pub fn into_iterator(self) -> impl Iterator<Item = NodeIndex> {
            (0..self.0).map(NodeIndex)
        }
        /// If this is the total node count, what number of nodes is required for secure consensus.
        pub fn consensus_threshold(&self) -> NodeCount {
            (*self * 2) / 3 + NodeCount(1)
        }
    }
    /// A container keeping items indexed by NodeIndex.
    pub struct NodeMap<T>(Vec<Option<T>>);
    #[automatically_derived]
    impl<T: ::core::clone::Clone> ::core::clone::Clone for NodeMap<T> {
        #[inline]
        fn clone(&self) -> NodeMap<T> {
            NodeMap(::core::clone::Clone::clone(&self.0))
        }
    }
    #[automatically_derived]
    impl<T: ::core::cmp::Eq> ::core::cmp::Eq for NodeMap<T> {
        #[inline]
        #[doc(hidden)]
        #[coverage(off)]
        fn assert_fields_are_eq(&self) {
            let _: ::core::cmp::AssertParamIsEq<Vec<Option<T>>>;
        }
    }
    #[automatically_derived]
    impl<T: ::core::cmp::PartialEq> ::core::marker::StructuralPartialEq for
        NodeMap<T> {
    }
    #[automatically_derived]
    impl<T: ::core::cmp::PartialEq> ::core::cmp::PartialEq for NodeMap<T> {
        #[inline]
        fn eq(&self, other: &NodeMap<T>) -> bool { self.0 == other.0 }
    }
    #[automatically_derived]
    impl<T: ::core::hash::Hash> ::core::hash::Hash for NodeMap<T> {
        #[inline]
        fn hash<__H: ::core::hash::Hasher>(&self, state: &mut __H) {
            ::core::hash::Hash::hash(&self.0, state)
        }
    }
    #[automatically_derived]
    impl<T: ::core::fmt::Debug> ::core::fmt::Debug for NodeMap<T> {
        #[inline]
        fn fmt(&self, f: &mut ::core::fmt::Formatter) -> ::core::fmt::Result {
            ::core::fmt::Formatter::debug_tuple_field1_finish(f, "NodeMap",
                &&self.0)
        }
    }
    #[automatically_derived]
    impl<T: ::core::default::Default> ::core::default::Default for NodeMap<T>
        {
        #[inline]
        fn default() -> NodeMap<T> {
            NodeMap(::core::default::Default::default())
        }
    }
    #[allow(deprecated)]
    const _: () =
        {
            #[automatically_derived]
            impl<T> ::codec::Decode for NodeMap<T> where
                Vec<Option<T>>: ::codec::Decode,
                Vec<Option<T>>: ::codec::Decode {
                fn decode<__CodecInputEdqy: ::codec::Input>(__codec_input_edqy:
                        &mut __CodecInputEdqy)
                    -> ::core::result::Result<Self, ::codec::Error> {
                    ::core::result::Result::Ok(NodeMap::<T>({
                                let __codec_res_edqy =
                                    <Vec<Option<T>> as
                                            ::codec::Decode>::decode(__codec_input_edqy);
                                match __codec_res_edqy {
                                    ::core::result::Result::Err(e) =>
                                        return ::core::result::Result::Err(e.chain("Could not decode `NodeMap.0`")),
                                    ::core::result::Result::Ok(__codec_res_edqy) =>
                                        __codec_res_edqy,
                                }
                            }))
                }
            }
        };
    #[allow(deprecated)]
    const _: () =
        {
            #[automatically_derived]
            impl<T> ::codec::Encode for NodeMap<T> where
                Vec<Option<T>>: ::codec::Encode,
                Vec<Option<T>>: ::codec::Encode {
                fn size_hint(&self) -> usize {
                    ::codec::Encode::size_hint(&&self.0)
                }
                fn encode_to<__CodecOutputEdqy: ::codec::Output +
                    ?::core::marker::Sized>(&self,
                    __codec_dest_edqy: &mut __CodecOutputEdqy) {
                    ::codec::Encode::encode_to(&&self.0, __codec_dest_edqy)
                }
                fn encode(&self)
                    -> ::codec::alloc::vec::Vec<::core::primitive::u8> {
                    ::codec::Encode::encode(&&self.0)
                }
                fn using_encoded<__CodecOutputReturn,
                    __CodecUsingEncodedCallback: ::core::ops::FnOnce(&[::core::primitive::u8])
                    ->
                        __CodecOutputReturn>(&self, f: __CodecUsingEncodedCallback)
                    -> __CodecOutputReturn {
                    ::codec::Encode::using_encoded(&&self.0, f)
                }
            }
            #[automatically_derived]
            impl<T> ::codec::EncodeLike for NodeMap<T> where
                Vec<Option<T>>: ::codec::Encode,
                Vec<Option<T>>: ::codec::Encode {
            }
        };
    #[automatically_derived]
    impl<T> derive_more::From<(Vec<Option<T>>)> for NodeMap<T> {
        #[inline]
        fn from(value: (Vec<Option<T>>)) -> Self { NodeMap(value) }
    }
    impl<T> View for NodeMap<T> {
        type V = Seq<Option<T>>;
    }
    impl<T> NodeMap<T> {}
    impl<T> NodeMap<T> {
        /// Constructs a new node map with a given length.
        pub fn with_size(len: NodeCount) -> Self where T: Clone {
            let v = ::alloc::vec::from_elem(None, len.into());
            NodeMap(v)
        }
        pub fn from_hashmap(len: NodeCount, hashmap: HashMap<NodeIndex, T>)
            -> Self where T: Clone {
            let v = ::alloc::vec::from_elem(None, len.into());
            let mut nm = NodeMap(v);
            for (id, item) in hashmap.into_iter() { nm.insert(id, item); }
            nm
        }
        pub fn size(&self) -> NodeCount { self.0.len().into() }
        pub fn iter(&self) -> impl Iterator<Item = (NodeIndex, &T)> {
            self.0.iter().enumerate().filter_map(|(idx, maybe_value)|
                    Some((NodeIndex(idx), maybe_value.as_ref()?)))
        }
        pub fn iter_mut(&mut self)
            -> impl Iterator<Item = (NodeIndex, &mut T)> {
            self.0.iter_mut().enumerate().filter_map(|(idx, maybe_value)|
                    Some((NodeIndex(idx), maybe_value.as_mut()?)))
        }
        fn into_iter(self) -> impl Iterator<Item = (NodeIndex, T)> where
            T: 'static {
            self.0.into_iter().enumerate().filter_map(|(idx, maybe_value)|
                    Some((NodeIndex(idx), maybe_value?)))
        }
        pub fn values(&self) -> impl Iterator<Item = &T> {
            self.iter().map(|(_, value)| value)
        }
        pub fn into_values(self) -> impl Iterator<Item = T> where T: 'static {
            self.into_iter().map(|(_, value)| value)
        }
        pub fn get(&self, node_id: NodeIndex) -> Option<&T> {
            self.0[node_id.0].as_ref()
        }
        pub fn get_mut(&mut self, node_id: NodeIndex) -> Option<&mut T> {
            self.0[node_id.0].as_mut()
        }
        pub fn insert(&mut self, node_id: NodeIndex, value: T) {
            self.0[node_id.0] = Some(value)
        }
        pub fn delete(&mut self, node_id: NodeIndex) {
            self.0[node_id.0] = None
        }
        pub fn to_subset(&self) -> NodeSubset {
            NodeSubset(self.0.iter().map(Option::is_some).collect())
        }
        pub fn item_count(&self) -> usize { self.iter().count() }
    }
    impl<T: Copy> NodeMap<T> {
        /// Replaces exactly the first `n` positions. Callers establish the bounds.
        pub fn fill_prefix(&mut self, n: usize, value: T) {
            let mut i = 0usize;
            while i < n { self.insert(NodeIndex(i), value); i += 1; }
        }
        /// Rejects an oversized prefix before changing any slot.
        pub fn try_fill_prefix(&mut self, n: usize, value: T)
            -> Result<(), usize> {
            if n > self.size().0 { return Err(n); }
            self.fill_prefix(n, value);
            Ok(())
        }
    }
    impl<T: 'static> IntoIterator for NodeMap<T> {
        type Item = (NodeIndex, T);
        type IntoIter = Box<dyn Iterator<Item = (NodeIndex, T)>>;
        fn into_iter(self) -> Self::IntoIter { Box::new(self.into_iter()) }
    }
    impl<'a, T> IntoIterator for &'a NodeMap<T> {
        type Item = (NodeIndex, &'a T);
        type IntoIter = Box<dyn Iterator<Item = (NodeIndex, &'a T)> + 'a>;
        fn into_iter(self) -> Self::IntoIter { Box::new(self.iter()) }
    }
    impl<'a, T> IntoIterator for &'a mut NodeMap<T> {
        type Item = (NodeIndex, &'a mut T);
        type IntoIter = Box<dyn Iterator<Item = (NodeIndex, &'a mut T)> + 'a>;
        fn into_iter(self) -> Self::IntoIter { Box::new(self.iter_mut()) }
    }
    impl<T: fmt::Display> fmt::Display for NodeMap<T> {
        fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
            f.write_fmt(format_args!("["))?;
            let mut it = self.iter().peekable();
            while let Some((id, item)) = it.next() {
                f.write_fmt(format_args!("({0}, {1})", id.0, item))?;
                if it.peek().is_some() { f.write_fmt(format_args!(", "))?; }
            }
            f.write_fmt(format_args!("]"))?;
            Ok(())
        }
    }
    pub struct NodeSubset(bit_vec::BitVec<u32>);
    #[automatically_derived]
    impl ::core::clone::Clone for NodeSubset {
        #[inline]
        fn clone(&self) -> NodeSubset {
            NodeSubset(::core::clone::Clone::clone(&self.0))
        }
    }
    #[automatically_derived]
    impl ::core::cmp::Eq for NodeSubset {
        #[inline]
        #[doc(hidden)]
        #[coverage(off)]
        fn assert_fields_are_eq(&self) {
            let _: ::core::cmp::AssertParamIsEq<bit_vec::BitVec<u32>>;
        }
    }
    #[automatically_derived]
    impl ::core::marker::StructuralPartialEq for NodeSubset { }
    #[automatically_derived]
    impl ::core::cmp::PartialEq for NodeSubset {
        #[inline]
        fn eq(&self, other: &NodeSubset) -> bool { self.0 == other.0 }
    }
    #[automatically_derived]
    impl ::core::hash::Hash for NodeSubset {
        #[inline]
        fn hash<__H: ::core::hash::Hasher>(&self, state: &mut __H) {
            ::core::hash::Hash::hash(&self.0, state)
        }
    }
    #[automatically_derived]
    impl ::core::fmt::Debug for NodeSubset {
        #[inline]
        fn fmt(&self, f: &mut ::core::fmt::Formatter) -> ::core::fmt::Result {
            ::core::fmt::Formatter::debug_tuple_field1_finish(f, "NodeSubset",
                &&self.0)
        }
    }
    #[automatically_derived]
    impl ::core::default::Default for NodeSubset {
        #[inline]
        fn default() -> NodeSubset {
            NodeSubset(::core::default::Default::default())
        }
    }
    impl NodeSubset {
        pub fn with_size(capacity: NodeCount) -> Self {
            NodeSubset(bit_vec::BitVec::from_elem(capacity.0, false))
        }
        pub fn insert(&mut self, i: NodeIndex) { self.0.set(i.0, true); }
        pub fn size(&self) -> usize { self.0.len() }
        pub fn elements(&self) -> impl Iterator<Item = NodeIndex> + '_ {
            self.0.iter().enumerate().filter_map(|(i, b)|
                    if b { Some(i.into()) } else { None })
        }
        pub fn complement(&self) -> NodeSubset {
            let mut result = self.0.clone();
            result.negate();
            NodeSubset(result)
        }
        pub fn len(&self) -> usize { self.elements().count() }
        pub fn is_empty(&self) -> bool { self.len() == 0 }
    }
    impl Encode for NodeSubset {
        fn encode_to<T: Output + ?Sized>(&self, dest: &mut T) {
            (self.0.len() as u32).encode_to(dest);
            self.0.to_bytes().encode_to(dest);
        }
    }
    impl Decode for NodeSubset {
        fn decode<I: Input>(input: &mut I) -> Result<Self, Error> {
            let capacity = u32::decode(input)? as usize;
            let bytes = Vec::decode(input)?;
            let mut bv = bit_vec::BitVec::from_bytes(&bytes);
            if bv.len() != 8 * ((capacity + 7) / 8) {
                return Err(Error::from("Length of bitvector inconsistent with encoded capacity."));
            }
            while bv.len() > capacity {
                if bv.pop() != Some(false) {
                    return Err(Error::from("Non-canonical encoding. Trailing bits should be all 0."));
                }
            }
            bv.truncate(capacity);
            Ok(NodeSubset(bv))
        }
    }
    impl StdIndex<NodeIndex> for NodeSubset {
        type Output = bool;
        fn index(&self, vidx: NodeIndex) -> &bool { &self.0[vidx.0] }
    }
    impl fmt::Display for NodeSubset {
        fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
            let mut v: Vec<usize> =
                self.elements().map(|n| n.into()).collect();
            v.sort();
            f.write_fmt(format_args!("{0:?}", v))
        }
    }
}
mod signature {
    use crate::{Index, NodeCount, NodeIndex, NodeMap};
    use codec::{Codec, Decode, Encode};
    use log::warn;
    use std::{fmt::Debug, hash::Hash};
    /// The type used as a signature.
    ///
    /// The Signature typically does not contain the index of the node who signed the data.
    pub trait Signature: Debug + Clone + Codec + Send + Sync + Eq + 'static {
    }
    impl<T: Debug + Clone + Codec + Send + Sync + Eq + 'static> Signature for
        T {}
    /// Abstraction of the signing data and verifying signatures.
    ///
    /// A typical implementation of Keychain would be a collection of `N` public keys,
    /// an index `i` and a single private key corresponding to the public key number `i`.
    /// The meaning of sign is then to produce a signature `s` using the given private key,
    /// and `verify(msg, s, j)` is to verify whether the signature s under the message msg is
    /// correct with respect to the public key of the jth node.
    pub trait Keychain: Index + Clone + Send + Sync + 'static {
        type Signature: Signature;
        /// Returns the total number of known public keys.
        fn node_count(&self)
        -> NodeCount;
        /// Signs a message `msg`.
        fn sign(&self, msg: &[u8])
        -> Self::Signature;
        /// Verifies whether a node with `index` correctly signed the message `msg`.
        /// Should always return false for indices outside the node range.
        fn verify(&self, msg: &[u8], sgn: &Self::Signature, index: NodeIndex)
        -> bool;
    }
    /// A type to which signatures can be aggregated.
    ///
    /// Any signature can be added to multisignature.
    /// After adding sufficiently many signatures, the partial multisignature becomes a "complete"
    /// multisignature.
    /// Whether a multisignature is complete, can be verified with [`MultiKeychain::is_complete`] method.
    /// The signature and the index passed to the `add_signature` method are required to be valid.
    pub trait PartialMultisignature: Signature {
        type Signature: Signature;
        /// Adds the signature.
        #[must_use =
        "consumes the original and returns the aggregated signature which should be used"]
        fn add_signature(self, signature: &Self::Signature, index: NodeIndex)
        -> Self;
    }
    /// Extends Keychain with multisigning functionalities.
    ///
    /// A single Signature can be raised to a Multisignature.
    /// Allows to verify whether a partial multisignature is complete (and valid).
    pub trait MultiKeychain: Keychain {
        type
            PartialMultisignature: PartialMultisignature<Signature =
            Self::Signature>;
        /// Transform a single signature to a multisignature consisting of the signature.
        fn bootstrap_multi(&self, signature: &Self::Signature,
        index: NodeIndex)
        -> Self::PartialMultisignature;
        /// Checks if enough signatures have beed added.
        fn is_complete(&self, msg: &[u8],
        partial: &Self::PartialMultisignature)
        -> bool;
    }
    /// A set of signatures of a subset of nodes serving as a (partial) multisignature
    pub type SignatureSet<S> = NodeMap<S>;
    impl<S: Signature> PartialMultisignature for SignatureSet<S> {
        type Signature = S;
        #[must_use =
        "consumes the original and returns the aggregated signature which should be used"]
        fn add_signature(mut self, signature: &Self::Signature,
            index: NodeIndex) -> Self {
            self.insert(index, signature.clone());
            self
        }
    }
    /// Data which can be signed.
    ///
    /// Signable data should provide a hash of type [`Self::Hash`] which is build from all parts of the
    /// data which should be signed. The type [`Self::Hash`] should implement [`AsRef<[u8]>`], and
    /// the bytes returned by `hash.as_ref()` are used by a [`MultiKeychain`] to sign the data.
    pub trait Signable {
        type Hash: AsRef<[u8]>;
        /// Return a hash for signing.
        fn hash(&self)
        -> Self::Hash;
    }
    impl<T: AsRef<[u8]> + Clone> Signable for T {
        type Hash = T;
        fn hash(&self) -> Self::Hash { self.clone() }
    }
    /// A pair consisting of an instance of the `Signable` trait and an (arbitrary) signature.
    ///
    /// The method `[UncheckedSigned::check]` can be used to upgrade this `struct` to
    /// `[Signed<T, K>]` which ensures that the signature matches the signed object.
    pub struct UncheckedSigned<T: Signable, S: Signature> {
        signable: T,
        signature: S,
    }
    #[automatically_derived]
    impl<T: ::core::clone::Clone + Signable, S: ::core::clone::Clone +
        Signature> ::core::clone::Clone for UncheckedSigned<T, S> {
        #[inline]
        fn clone(&self) -> UncheckedSigned<T, S> {
            UncheckedSigned {
                signable: ::core::clone::Clone::clone(&self.signable),
                signature: ::core::clone::Clone::clone(&self.signature),
            }
        }
    }
    #[automatically_derived]
    impl<T: ::core::cmp::Eq + Signable, S: ::core::cmp::Eq + Signature>
        ::core::cmp::Eq for UncheckedSigned<T, S> {
        #[inline]
        #[doc(hidden)]
        #[coverage(off)]
        fn assert_fields_are_eq(&self) {
            let _: ::core::cmp::AssertParamIsEq<T>;
            let _: ::core::cmp::AssertParamIsEq<S>;
        }
    }
    #[automatically_derived]
    impl<T: ::core::cmp::PartialEq + Signable, S: ::core::cmp::PartialEq +
        Signature> ::core::marker::StructuralPartialEq for
        UncheckedSigned<T, S> {
    }
    #[automatically_derived]
    impl<T: ::core::cmp::PartialEq + Signable, S: ::core::cmp::PartialEq +
        Signature> ::core::cmp::PartialEq for UncheckedSigned<T, S> {
        #[inline]
        fn eq(&self, other: &UncheckedSigned<T, S>) -> bool {
            self.signable == other.signable &&
                self.signature == other.signature
        }
    }
    #[automatically_derived]
    impl<T: ::core::hash::Hash + Signable, S: ::core::hash::Hash + Signature>
        ::core::hash::Hash for UncheckedSigned<T, S> {
        #[inline]
        fn hash<__H: ::core::hash::Hasher>(&self, state: &mut __H) {
            ::core::hash::Hash::hash(&self.signable, state);
            ::core::hash::Hash::hash(&self.signature, state)
        }
    }
    #[automatically_derived]
    impl<T: ::core::fmt::Debug + Signable, S: ::core::fmt::Debug + Signature>
        ::core::fmt::Debug for UncheckedSigned<T, S> {
        #[inline]
        fn fmt(&self, f: &mut ::core::fmt::Formatter) -> ::core::fmt::Result {
            ::core::fmt::Formatter::debug_struct_field2_finish(f,
                "UncheckedSigned", "signable", &self.signable, "signature",
                &&self.signature)
        }
    }
    #[allow(deprecated)]
    const _: () =
        {
            #[automatically_derived]
            impl<T: Signable, S: Signature> ::codec::Decode for
                UncheckedSigned<T, S> where T: ::codec::Decode,
                T: ::codec::Decode, S: ::codec::Decode, S: ::codec::Decode {
                fn decode<__CodecInputEdqy: ::codec::Input>(__codec_input_edqy:
                        &mut __CodecInputEdqy)
                    -> ::core::result::Result<Self, ::codec::Error> {
                    ::core::result::Result::Ok(UncheckedSigned::<T,
                            S> {
                            signable: {
                                let __codec_res_edqy =
                                    <T as ::codec::Decode>::decode(__codec_input_edqy);
                                match __codec_res_edqy {
                                    ::core::result::Result::Err(e) =>
                                        return ::core::result::Result::Err(e.chain("Could not decode `UncheckedSigned::signable`")),
                                    ::core::result::Result::Ok(__codec_res_edqy) =>
                                        __codec_res_edqy,
                                }
                            },
                            signature: {
                                let __codec_res_edqy =
                                    <S as ::codec::Decode>::decode(__codec_input_edqy);
                                match __codec_res_edqy {
                                    ::core::result::Result::Err(e) =>
                                        return ::core::result::Result::Err(e.chain("Could not decode `UncheckedSigned::signature`")),
                                    ::core::result::Result::Ok(__codec_res_edqy) =>
                                        __codec_res_edqy,
                                }
                            },
                        })
                }
            }
        };
    #[allow(deprecated)]
    const _: () =
        {
            #[automatically_derived]
            impl<T: Signable, S: Signature> ::codec::Encode for
                UncheckedSigned<T, S> where T: ::codec::Encode,
                T: ::codec::Encode, S: ::codec::Encode, S: ::codec::Encode {
                fn size_hint(&self) -> usize {
                    0_usize.saturating_add(::codec::Encode::size_hint(&self.signable)).saturating_add(::codec::Encode::size_hint(&self.signature))
                }
                fn encode_to<__CodecOutputEdqy: ::codec::Output +
                    ?::core::marker::Sized>(&self,
                    __codec_dest_edqy: &mut __CodecOutputEdqy) {
                    ::codec::Encode::encode_to(&self.signable,
                        __codec_dest_edqy);
                    ::codec::Encode::encode_to(&self.signature,
                        __codec_dest_edqy);
                }
            }
            #[automatically_derived]
            impl<T: Signable, S: Signature> ::codec::EncodeLike for
                UncheckedSigned<T, S> where T: ::codec::Encode,
                T: ::codec::Encode, S: ::codec::Encode, S: ::codec::Encode {
            }
        };
    impl<T: Signable, S: Signature> UncheckedSigned<T, S> {
        pub fn as_signable(&self) -> &T { &self.signable }
        pub fn into_signable(self) -> T { self.signable }
        pub fn signature(&self) -> S { self.signature.clone() }
    }
    impl<T: Signable, S: Signature> UncheckedSigned<Indexed<T>, S> {
        pub fn as_signable_strip_index(&self) -> &T {
            &self.signable.signable
        }
    }
    /// Error type returned when a verification of a signature fails.
    pub struct SignatureError<T: Signable, S: Signature> {
        pub unchecked: UncheckedSigned<T, S>,
    }
    #[automatically_derived]
    impl<T: ::core::clone::Clone + Signable, S: ::core::clone::Clone +
        Signature> ::core::clone::Clone for SignatureError<T, S> {
        #[inline]
        fn clone(&self) -> SignatureError<T, S> {
            SignatureError {
                unchecked: ::core::clone::Clone::clone(&self.unchecked),
            }
        }
    }
    #[automatically_derived]
    impl<T: ::core::cmp::Eq + Signable, S: ::core::cmp::Eq + Signature>
        ::core::cmp::Eq for SignatureError<T, S> {
        #[inline]
        #[doc(hidden)]
        #[coverage(off)]
        fn assert_fields_are_eq(&self) {
            let _: ::core::cmp::AssertParamIsEq<UncheckedSigned<T, S>>;
        }
    }
    #[automatically_derived]
    impl<T: ::core::cmp::PartialEq + Signable, S: ::core::cmp::PartialEq +
        Signature> ::core::marker::StructuralPartialEq for
        SignatureError<T, S> {
    }
    #[automatically_derived]
    impl<T: ::core::cmp::PartialEq + Signable, S: ::core::cmp::PartialEq +
        Signature> ::core::cmp::PartialEq for SignatureError<T, S> {
        #[inline]
        fn eq(&self, other: &SignatureError<T, S>) -> bool {
            self.unchecked == other.unchecked
        }
    }
    #[automatically_derived]
    impl<T: ::core::hash::Hash + Signable, S: ::core::hash::Hash + Signature>
        ::core::hash::Hash for SignatureError<T, S> {
        #[inline]
        fn hash<__H: ::core::hash::Hasher>(&self, state: &mut __H) {
            ::core::hash::Hash::hash(&self.unchecked, state)
        }
    }
    #[automatically_derived]
    impl<T: ::core::fmt::Debug + Signable, S: ::core::fmt::Debug + Signature>
        ::core::fmt::Debug for SignatureError<T, S> {
        #[inline]
        fn fmt(&self, f: &mut ::core::fmt::Formatter) -> ::core::fmt::Result {
            ::core::fmt::Formatter::debug_struct_field1_finish(f,
                "SignatureError", "unchecked", &&self.unchecked)
        }
    }
    #[allow(deprecated)]
    const _: () =
        {
            #[automatically_derived]
            impl<T: Signable, S: Signature> ::codec::Decode for
                SignatureError<T, S> where
                UncheckedSigned<T, S>: ::codec::Decode,
                UncheckedSigned<T, S>: ::codec::Decode {
                fn decode<__CodecInputEdqy: ::codec::Input>(__codec_input_edqy:
                        &mut __CodecInputEdqy)
                    -> ::core::result::Result<Self, ::codec::Error> {
                    ::core::result::Result::Ok(SignatureError::<T,
                            S> {
                            unchecked: {
                                let __codec_res_edqy =
                                    <UncheckedSigned<T, S> as
                                            ::codec::Decode>::decode(__codec_input_edqy);
                                match __codec_res_edqy {
                                    ::core::result::Result::Err(e) =>
                                        return ::core::result::Result::Err(e.chain("Could not decode `SignatureError::unchecked`")),
                                    ::core::result::Result::Ok(__codec_res_edqy) =>
                                        __codec_res_edqy,
                                }
                            },
                        })
                }
            }
        };
    #[allow(deprecated)]
    const _: () =
        {
            #[automatically_derived]
            impl<T: Signable, S: Signature> ::codec::Encode for
                SignatureError<T, S> where
                UncheckedSigned<T, S>: ::codec::Encode,
                UncheckedSigned<T, S>: ::codec::Encode {
                fn size_hint(&self) -> usize {
                    ::codec::Encode::size_hint(&&self.unchecked)
                }
                fn encode_to<__CodecOutputEdqy: ::codec::Output +
                    ?::core::marker::Sized>(&self,
                    __codec_dest_edqy: &mut __CodecOutputEdqy) {
                    ::codec::Encode::encode_to(&&self.unchecked,
                        __codec_dest_edqy)
                }
                fn encode(&self)
                    -> ::codec::alloc::vec::Vec<::core::primitive::u8> {
                    ::codec::Encode::encode(&&self.unchecked)
                }
                fn using_encoded<__CodecOutputReturn,
                    __CodecUsingEncodedCallback: ::core::ops::FnOnce(&[::core::primitive::u8])
                    ->
                        __CodecOutputReturn>(&self, f: __CodecUsingEncodedCallback)
                    -> __CodecOutputReturn {
                    ::codec::Encode::using_encoded(&&self.unchecked, f)
                }
            }
            #[automatically_derived]
            impl<T: Signable, S: Signature> ::codec::EncodeLike for
                SignatureError<T, S> where
                UncheckedSigned<T, S>: ::codec::Encode,
                UncheckedSigned<T, S>: ::codec::Encode {
            }
        };
    impl<T: Signable + Index, S: Signature> UncheckedSigned<T, S> {
        /// Verifies whether the signature matches the key with the index as in the signed data.
        pub fn check<K: Keychain<Signature = S>>(self, keychain: &K)
            -> Result<Signed<T, K>, SignatureError<T, S>> {
            let index = self.signable.index();
            if !keychain.verify(self.signable.hash().as_ref(),
                        &self.signature, index) {
                return Err(SignatureError { unchecked: self });
            }
            Ok(Signed { unchecked: self })
        }
    }
    impl<T: Signable + Index, S: Signature> Index for UncheckedSigned<T, S> {
        fn index(&self) -> NodeIndex { self.signable.index() }
    }
    impl<T: Signable, S: PartialMultisignature> UncheckedSigned<T, S> {
        /// Verifies whether the multisignature matches the signed data.
        pub fn check_multi<MK: MultiKeychain<PartialMultisignature =
            S>>(self, keychain: &MK)
            -> Result<Multisigned<T, MK>, SignatureError<T, S>> {
            if !(keychain.is_complete(self.signable.hash().as_ref(),
                            &self.signature)) {
                return Err(SignatureError { unchecked: self });
            }
            Ok(Multisigned { unchecked: self })
        }
    }
    impl<T: Signable, S: Signature> UncheckedSigned<Indexed<T>, S> {
        fn strip_index(self) -> UncheckedSigned<T, S> {
            UncheckedSigned {
                signable: self.signable.strip_index(),
                signature: self.signature,
            }
        }
    }
    impl<T: Signable, S: Signature> From<UncheckedSigned<Indexed<T>, S>> for
        UncheckedSigned<T, S> {
        fn from(us: UncheckedSigned<Indexed<T>, S>) -> Self {
            us.strip_index()
        }
    }
    /// A correctly signed object of type `T`.
    pub struct Signed<T: Signable + Index, K: Keychain> {
        unchecked: UncheckedSigned<T, K::Signature>,
    }
    #[automatically_derived]
    impl<T: ::core::cmp::Eq + Signable + Index, K: ::core::cmp::Eq + Keychain>
        ::core::cmp::Eq for Signed<T, K> where K::Signature: ::core::cmp::Eq {
        #[inline]
        #[doc(hidden)]
        #[coverage(off)]
        fn assert_fields_are_eq(&self) {
            let _:
                    ::core::cmp::AssertParamIsEq<UncheckedSigned<T,
                    K::Signature>>;
        }
    }
    #[automatically_derived]
    impl<T: ::core::cmp::PartialEq + Signable + Index,
        K: ::core::cmp::PartialEq + Keychain>
        ::core::marker::StructuralPartialEq for Signed<T, K> where
        K::Signature: ::core::cmp::PartialEq {
    }
    #[automatically_derived]
    impl<T: ::core::cmp::PartialEq + Signable + Index,
        K: ::core::cmp::PartialEq + Keychain> ::core::cmp::PartialEq for
        Signed<T, K> where K::Signature: ::core::cmp::PartialEq {
        #[inline]
        fn eq(&self, other: &Signed<T, K>) -> bool {
            self.unchecked == other.unchecked
        }
    }
    #[automatically_derived]
    impl<T: ::core::hash::Hash + Signable + Index, K: ::core::hash::Hash +
        Keychain> ::core::hash::Hash for Signed<T, K> where
        K::Signature: ::core::hash::Hash {
        #[inline]
        fn hash<__H: ::core::hash::Hasher>(&self, state: &mut __H) {
            ::core::hash::Hash::hash(&self.unchecked, state)
        }
    }
    #[automatically_derived]
    impl<T: ::core::fmt::Debug + Signable + Index, K: ::core::fmt::Debug +
        Keychain> ::core::fmt::Debug for Signed<T, K> where
        K::Signature: ::core::fmt::Debug {
        #[inline]
        fn fmt(&self, f: &mut ::core::fmt::Formatter) -> ::core::fmt::Result {
            ::core::fmt::Formatter::debug_struct_field1_finish(f, "Signed",
                "unchecked", &&self.unchecked)
        }
    }
    #[allow(deprecated)]
    const _: () =
        {
            #[automatically_derived]
            impl<T: Signable + Index, K: Keychain> ::codec::Decode for
                Signed<T, K> where
                UncheckedSigned<T, K::Signature>: ::codec::Decode,
                UncheckedSigned<T, K::Signature>: ::codec::Decode {
                fn decode<__CodecInputEdqy: ::codec::Input>(__codec_input_edqy:
                        &mut __CodecInputEdqy)
                    -> ::core::result::Result<Self, ::codec::Error> {
                    ::core::result::Result::Ok(Signed::<T,
                            K> {
                            unchecked: {
                                let __codec_res_edqy =
                                    <UncheckedSigned<T, K::Signature> as
                                            ::codec::Decode>::decode(__codec_input_edqy);
                                match __codec_res_edqy {
                                    ::core::result::Result::Err(e) =>
                                        return ::core::result::Result::Err(e.chain("Could not decode `Signed::unchecked`")),
                                    ::core::result::Result::Ok(__codec_res_edqy) =>
                                        __codec_res_edqy,
                                }
                            },
                        })
                }
            }
        };
    #[allow(deprecated)]
    const _: () =
        {
            #[automatically_derived]
            impl<T: Signable + Index, K: Keychain> ::codec::Encode for
                Signed<T, K> where
                UncheckedSigned<T, K::Signature>: ::codec::Encode,
                UncheckedSigned<T, K::Signature>: ::codec::Encode {
                fn size_hint(&self) -> usize {
                    ::codec::Encode::size_hint(&&self.unchecked)
                }
                fn encode_to<__CodecOutputEdqy: ::codec::Output +
                    ?::core::marker::Sized>(&self,
                    __codec_dest_edqy: &mut __CodecOutputEdqy) {
                    ::codec::Encode::encode_to(&&self.unchecked,
                        __codec_dest_edqy)
                }
                fn encode(&self)
                    -> ::codec::alloc::vec::Vec<::core::primitive::u8> {
                    ::codec::Encode::encode(&&self.unchecked)
                }
                fn using_encoded<__CodecOutputReturn,
                    __CodecUsingEncodedCallback: ::core::ops::FnOnce(&[::core::primitive::u8])
                    ->
                        __CodecOutputReturn>(&self, f: __CodecUsingEncodedCallback)
                    -> __CodecOutputReturn {
                    ::codec::Encode::using_encoded(&&self.unchecked, f)
                }
            }
            #[automatically_derived]
            impl<T: Signable + Index, K: Keychain> ::codec::EncodeLike for
                Signed<T, K> where
                UncheckedSigned<T, K::Signature>: ::codec::Encode,
                UncheckedSigned<T, K::Signature>: ::codec::Encode {
            }
        };
    impl<T: Signable + Clone + Index, K: Keychain> Clone for Signed<T, K> {
        fn clone(&self) -> Self {
            Signed { unchecked: self.unchecked.clone() }
        }
    }
    impl<T: Signable + Index, K: Keychain> Signed<T, K> {
        /// Create a signed object from a signable. The index of `signable` must match the index of the `keychain`.
        pub fn sign(signable: T, keychain: &K) -> Signed<T, K> {
            {
                match (&signable.index(), &keychain.index()) {
                    (left_val, right_val) => {
                        if !(*left_val == *right_val) {
                            let kind = ::core::panicking::AssertKind::Eq;
                            ::core::panicking::assert_failed(kind, &*left_val,
                                &*right_val, ::core::option::Option::None);
                        }
                    }
                }
            };
            let signature = keychain.sign(signable.hash().as_ref());
            Signed { unchecked: UncheckedSigned { signable, signature } }
        }
        /// Get a reference to the signed object.
        pub fn as_signable(&self) -> &T { &self.unchecked.signable }
        pub fn into_signable(self) -> T { self.unchecked.signable }
        pub fn into_unchecked(self) -> UncheckedSigned<T, K::Signature> {
            self.unchecked
        }
    }
    impl<T: Signable, K: Keychain> Signed<Indexed<T>, K> {
        /// Create a signed object from a signable. The index is added based on the index of the `keychain`.
        pub fn sign_with_index(signable: T, keychain: &K)
            -> Signed<Indexed<T>, K> {
            Signed::sign(Indexed::new(signable, keychain.index()), keychain)
        }
    }
    impl<T: Signable, MK: MultiKeychain> Signed<Indexed<T>, MK> {
        /// Transform a singly signed object into a partially multisigned consisting of just the signed object.
        /// Note that depending on the setup, it may yield a complete signature.
        pub fn into_partially_multisigned(self, keychain: &MK)
            -> PartiallyMultisigned<T, MK> {
            let multisignature =
                keychain.bootstrap_multi(&self.unchecked.signature,
                    self.unchecked.signable.index);
            let unchecked =
                UncheckedSigned {
                    signable: self.unchecked.signable.strip_index(),
                    signature: multisignature,
                };
            if keychain.is_complete(unchecked.signable.hash().as_ref(),
                    &unchecked.signature) {
                PartiallyMultisigned::Complete {
                    multisigned: Multisigned { unchecked },
                }
            } else { PartiallyMultisigned::Incomplete { unchecked } }
        }
    }
    impl<T: Signable + Index, K: Keychain> From<Signed<T, K>> for
        UncheckedSigned<T, K::Signature> {
        fn from(signed: Signed<T, K>) -> Self { signed.into_unchecked() }
    }
    /// A pair consistsing of signable data and a [`NodeIndex`].
    ///
    /// This is a wrapper used for signing data which does not implement the [`Index`] trait.
    /// If a node with an index `i` needs to sign some data `signable` which does not
    /// implement the [`Index`] trait, it should use the `Signed::sign_with_index` method which will
    /// use this wrapper transparently. Note that in the implementation of `Signable` for `Indexed<T>`,
    /// the hash is the hash of the underlying data `T`. Therefore, instances of the type
    /// [`Signed<Indexed<T>, MK>`] can be aggregated into `Multisigned<T, MK>`
    pub struct Indexed<T: Signable> {
        signable: T,
        index: NodeIndex,
    }
    #[automatically_derived]
    impl<T: ::core::clone::Clone + Signable> ::core::clone::Clone for
        Indexed<T> {
        #[inline]
        fn clone(&self) -> Indexed<T> {
            Indexed {
                signable: ::core::clone::Clone::clone(&self.signable),
                index: ::core::clone::Clone::clone(&self.index),
            }
        }
    }
    #[automatically_derived]
    impl<T: ::core::cmp::Eq + Signable> ::core::cmp::Eq for Indexed<T> {
        #[inline]
        #[doc(hidden)]
        #[coverage(off)]
        fn assert_fields_are_eq(&self) {
            let _: ::core::cmp::AssertParamIsEq<T>;
            let _: ::core::cmp::AssertParamIsEq<NodeIndex>;
        }
    }
    #[automatically_derived]
    impl<T: ::core::cmp::PartialEq + Signable>
        ::core::marker::StructuralPartialEq for Indexed<T> {
    }
    #[automatically_derived]
    impl<T: ::core::cmp::PartialEq + Signable> ::core::cmp::PartialEq for
        Indexed<T> {
        #[inline]
        fn eq(&self, other: &Indexed<T>) -> bool {
            self.signable == other.signable && self.index == other.index
        }
    }
    #[automatically_derived]
    impl<T: ::core::hash::Hash + Signable> ::core::hash::Hash for Indexed<T> {
        #[inline]
        fn hash<__H: ::core::hash::Hasher>(&self, state: &mut __H) {
            ::core::hash::Hash::hash(&self.signable, state);
            ::core::hash::Hash::hash(&self.index, state)
        }
    }
    #[automatically_derived]
    impl<T: ::core::fmt::Debug + Signable> ::core::fmt::Debug for Indexed<T> {
        #[inline]
        fn fmt(&self, f: &mut ::core::fmt::Formatter) -> ::core::fmt::Result {
            ::core::fmt::Formatter::debug_struct_field2_finish(f, "Indexed",
                "signable", &self.signable, "index", &&self.index)
        }
    }
    #[allow(deprecated)]
    const _: () =
        {
            #[automatically_derived]
            impl<T: Signable> ::codec::Decode for Indexed<T> where
                T: ::codec::Decode, T: ::codec::Decode {
                fn decode<__CodecInputEdqy: ::codec::Input>(__codec_input_edqy:
                        &mut __CodecInputEdqy)
                    -> ::core::result::Result<Self, ::codec::Error> {
                    ::core::result::Result::Ok(Indexed::<T> {
                            signable: {
                                let __codec_res_edqy =
                                    <T as ::codec::Decode>::decode(__codec_input_edqy);
                                match __codec_res_edqy {
                                    ::core::result::Result::Err(e) =>
                                        return ::core::result::Result::Err(e.chain("Could not decode `Indexed::signable`")),
                                    ::core::result::Result::Ok(__codec_res_edqy) =>
                                        __codec_res_edqy,
                                }
                            },
                            index: {
                                let __codec_res_edqy =
                                    <NodeIndex as ::codec::Decode>::decode(__codec_input_edqy);
                                match __codec_res_edqy {
                                    ::core::result::Result::Err(e) =>
                                        return ::core::result::Result::Err(e.chain("Could not decode `Indexed::index`")),
                                    ::core::result::Result::Ok(__codec_res_edqy) =>
                                        __codec_res_edqy,
                                }
                            },
                        })
                }
            }
        };
    #[allow(deprecated)]
    const _: () =
        {
            #[automatically_derived]
            impl<T: Signable> ::codec::Encode for Indexed<T> where
                T: ::codec::Encode, T: ::codec::Encode {
                fn size_hint(&self) -> usize {
                    0_usize.saturating_add(::codec::Encode::size_hint(&self.signable)).saturating_add(::codec::Encode::size_hint(&self.index))
                }
                fn encode_to<__CodecOutputEdqy: ::codec::Output +
                    ?::core::marker::Sized>(&self,
                    __codec_dest_edqy: &mut __CodecOutputEdqy) {
                    ::codec::Encode::encode_to(&self.signable,
                        __codec_dest_edqy);
                    ::codec::Encode::encode_to(&self.index, __codec_dest_edqy);
                }
            }
            #[automatically_derived]
            impl<T: Signable> ::codec::EncodeLike for Indexed<T> where
                T: ::codec::Encode, T: ::codec::Encode {
            }
        };
    impl<T: Signable> Indexed<T> {
        fn new(signable: T, index: NodeIndex) -> Self {
            Indexed { signable, index }
        }
        fn strip_index(self) -> T { self.signable }
        pub fn as_signable(&self) -> &T { &self.signable }
    }
    impl<T: Signable> Signable for Indexed<T> {
        type Hash = T::Hash;
        fn hash(&self) -> Self::Hash { self.signable.hash() }
    }
    impl<T: Signable> Index for Indexed<T> {
        fn index(&self) -> NodeIndex { self.index }
    }
    /// Signable data together with a complete multisignature.
    ///
    /// An instance of `Multisigned<T: Signable, MK: MultiKeychain>` consists of a data of type `T`
    /// together with a multisignature which is valid and complete according to a multikeychain
    /// reference `MK`.
    pub struct Multisigned<T: Signable, MK: MultiKeychain> {
        unchecked: UncheckedSigned<T, MK::PartialMultisignature>,
    }
    #[automatically_derived]
    impl<T: ::core::cmp::Eq + Signable, MK: ::core::cmp::Eq + MultiKeychain>
        ::core::cmp::Eq for Multisigned<T, MK> where
        MK::PartialMultisignature: ::core::cmp::Eq {
        #[inline]
        #[doc(hidden)]
        #[coverage(off)]
        fn assert_fields_are_eq(&self) {
            let _:
                    ::core::cmp::AssertParamIsEq<UncheckedSigned<T,
                    MK::PartialMultisignature>>;
        }
    }
    #[automatically_derived]
    impl<T: ::core::cmp::PartialEq + Signable, MK: ::core::cmp::PartialEq +
        MultiKeychain> ::core::marker::StructuralPartialEq for
        Multisigned<T, MK> where
        MK::PartialMultisignature: ::core::cmp::PartialEq {
    }
    #[automatically_derived]
    impl<T: ::core::cmp::PartialEq + Signable, MK: ::core::cmp::PartialEq +
        MultiKeychain> ::core::cmp::PartialEq for Multisigned<T, MK> where
        MK::PartialMultisignature: ::core::cmp::PartialEq {
        #[inline]
        fn eq(&self, other: &Multisigned<T, MK>) -> bool {
            self.unchecked == other.unchecked
        }
    }
    #[automatically_derived]
    impl<T: ::core::hash::Hash + Signable, MK: ::core::hash::Hash +
        MultiKeychain> ::core::hash::Hash for Multisigned<T, MK> where
        MK::PartialMultisignature: ::core::hash::Hash {
        #[inline]
        fn hash<__H: ::core::hash::Hasher>(&self, state: &mut __H) {
            ::core::hash::Hash::hash(&self.unchecked, state)
        }
    }
    #[automatically_derived]
    impl<T: ::core::fmt::Debug + Signable, MK: ::core::fmt::Debug +
        MultiKeychain> ::core::fmt::Debug for Multisigned<T, MK> where
        MK::PartialMultisignature: ::core::fmt::Debug {
        #[inline]
        fn fmt(&self, f: &mut ::core::fmt::Formatter) -> ::core::fmt::Result {
            ::core::fmt::Formatter::debug_struct_field1_finish(f,
                "Multisigned", "unchecked", &&self.unchecked)
        }
    }
    #[allow(deprecated)]
    const _: () =
        {
            #[automatically_derived]
            impl<T: Signable, MK: MultiKeychain> ::codec::Decode for
                Multisigned<T, MK> where
                UncheckedSigned<T,
                MK::PartialMultisignature>: ::codec::Decode,
                UncheckedSigned<T, MK::PartialMultisignature>: ::codec::Decode
                {
                fn decode<__CodecInputEdqy: ::codec::Input>(__codec_input_edqy:
                        &mut __CodecInputEdqy)
                    -> ::core::result::Result<Self, ::codec::Error> {
                    ::core::result::Result::Ok(Multisigned::<T,
                            MK> {
                            unchecked: {
                                let __codec_res_edqy =
                                    <UncheckedSigned<T, MK::PartialMultisignature> as
                                            ::codec::Decode>::decode(__codec_input_edqy);
                                match __codec_res_edqy {
                                    ::core::result::Result::Err(e) =>
                                        return ::core::result::Result::Err(e.chain("Could not decode `Multisigned::unchecked`")),
                                    ::core::result::Result::Ok(__codec_res_edqy) =>
                                        __codec_res_edqy,
                                }
                            },
                        })
                }
            }
        };
    #[allow(deprecated)]
    const _: () =
        {
            #[automatically_derived]
            impl<T: Signable, MK: MultiKeychain> ::codec::Encode for
                Multisigned<T, MK> where
                UncheckedSigned<T,
                MK::PartialMultisignature>: ::codec::Encode,
                UncheckedSigned<T, MK::PartialMultisignature>: ::codec::Encode
                {
                fn size_hint(&self) -> usize {
                    ::codec::Encode::size_hint(&&self.unchecked)
                }
                fn encode_to<__CodecOutputEdqy: ::codec::Output +
                    ?::core::marker::Sized>(&self,
                    __codec_dest_edqy: &mut __CodecOutputEdqy) {
                    ::codec::Encode::encode_to(&&self.unchecked,
                        __codec_dest_edqy)
                }
                fn encode(&self)
                    -> ::codec::alloc::vec::Vec<::core::primitive::u8> {
                    ::codec::Encode::encode(&&self.unchecked)
                }
                fn using_encoded<__CodecOutputReturn,
                    __CodecUsingEncodedCallback: ::core::ops::FnOnce(&[::core::primitive::u8])
                    ->
                        __CodecOutputReturn>(&self, f: __CodecUsingEncodedCallback)
                    -> __CodecOutputReturn {
                    ::codec::Encode::using_encoded(&&self.unchecked, f)
                }
            }
            #[automatically_derived]
            impl<T: Signable, MK: MultiKeychain> ::codec::EncodeLike for
                Multisigned<T, MK> where
                UncheckedSigned<T,
                MK::PartialMultisignature>: ::codec::Encode,
                UncheckedSigned<T, MK::PartialMultisignature>: ::codec::Encode
                {
            }
        };
    impl<T: Signable, MK: MultiKeychain> Multisigned<T, MK> {
        /// Get a reference to the multisigned object.
        pub fn as_signable(&self) -> &T { &self.unchecked.signable }
        pub fn into_unchecked(self)
            -> UncheckedSigned<T, MK::PartialMultisignature> {
            self.unchecked
        }
    }
    impl<T: Signable, MK: MultiKeychain> From<Multisigned<T, MK>> for
        UncheckedSigned<T, MK::PartialMultisignature> {
        fn from(signed: Multisigned<T, MK>) -> Self {
            signed.into_unchecked()
        }
    }
    impl<T: Signable + Clone, MK: MultiKeychain> Clone for Multisigned<T, MK>
        {
        fn clone(&self) -> Self {
            Multisigned { unchecked: self.unchecked.clone() }
        }
    }
    /// Error resulting from multisignature being incomplete.
    ///
    /// ### `Hash` derivation
    /// `PartiallyMultisigned` only conditionally implements `Hash`:
    /// ```rust
    /// # use std::hash::Hasher;
    /// # use aleph_bft_crypto::{MultiKeychain, PartiallyMultisigned, Signable};
    /// # trait Hash {};
    /// impl<'a, T: Hash + Signable, MK: Hash + MultiKeychain>
    ///    Hash for PartiallyMultisigned<T, MK>
    /// where MK::PartialMultisignature: Hash {}
    /// ```
    /// i.e. Rust automatically adds `where MK::PartialMultisignature: Hash`.
    ///
    /// This is a problem, since such `where` guard cannot be inferred for
    /// `IncompleteMultisignatureError` (because we do not use the associate type
    /// `MK::PartialMultisignature` of `MK` explicitly here).
    ///
    /// The alternative solution could be to make `Signature: Hash` or add a phantom marker using
    /// `MK::PartialMultisignature` type.
    pub struct IncompleteMultisignatureError<T: Signable, MK: MultiKeychain> {
        pub partial: PartiallyMultisigned<T, MK>,
    }
    #[automatically_derived]
    impl<T: ::core::clone::Clone + Signable, MK: ::core::clone::Clone +
        MultiKeychain> ::core::clone::Clone for
        IncompleteMultisignatureError<T, MK> {
        #[inline]
        fn clone(&self) -> IncompleteMultisignatureError<T, MK> {
            IncompleteMultisignatureError {
                partial: ::core::clone::Clone::clone(&self.partial),
            }
        }
    }
    #[automatically_derived]
    impl<T: ::core::cmp::Eq + Signable, MK: ::core::cmp::Eq + MultiKeychain>
        ::core::cmp::Eq for IncompleteMultisignatureError<T, MK> {
        #[inline]
        #[doc(hidden)]
        #[coverage(off)]
        fn assert_fields_are_eq(&self) {
            let _: ::core::cmp::AssertParamIsEq<PartiallyMultisigned<T, MK>>;
        }
    }
    #[automatically_derived]
    impl<T: ::core::cmp::PartialEq + Signable, MK: ::core::cmp::PartialEq +
        MultiKeychain> ::core::marker::StructuralPartialEq for
        IncompleteMultisignatureError<T, MK> {
    }
    #[automatically_derived]
    impl<T: ::core::cmp::PartialEq + Signable, MK: ::core::cmp::PartialEq +
        MultiKeychain> ::core::cmp::PartialEq for
        IncompleteMultisignatureError<T, MK> {
        #[inline]
        fn eq(&self, other: &IncompleteMultisignatureError<T, MK>) -> bool {
            self.partial == other.partial
        }
    }
    #[automatically_derived]
    impl<T: ::core::fmt::Debug + Signable, MK: ::core::fmt::Debug +
        MultiKeychain> ::core::fmt::Debug for
        IncompleteMultisignatureError<T, MK> {
        #[inline]
        fn fmt(&self, f: &mut ::core::fmt::Formatter) -> ::core::fmt::Result {
            ::core::fmt::Formatter::debug_struct_field1_finish(f,
                "IncompleteMultisignatureError", "partial", &&self.partial)
        }
    }
    #[allow(deprecated)]
    const _: () =
        {
            #[automatically_derived]
            impl<T: Signable, MK: MultiKeychain> ::codec::Decode for
                IncompleteMultisignatureError<T, MK> where
                PartiallyMultisigned<T, MK>: ::codec::Decode,
                PartiallyMultisigned<T, MK>: ::codec::Decode {
                fn decode<__CodecInputEdqy: ::codec::Input>(__codec_input_edqy:
                        &mut __CodecInputEdqy)
                    -> ::core::result::Result<Self, ::codec::Error> {
                    ::core::result::Result::Ok(IncompleteMultisignatureError::<T,
                            MK> {
                            partial: {
                                let __codec_res_edqy =
                                    <PartiallyMultisigned<T, MK> as
                                            ::codec::Decode>::decode(__codec_input_edqy);
                                match __codec_res_edqy {
                                    ::core::result::Result::Err(e) =>
                                        return ::core::result::Result::Err(e.chain("Could not decode `IncompleteMultisignatureError::partial`")),
                                    ::core::result::Result::Ok(__codec_res_edqy) =>
                                        __codec_res_edqy,
                                }
                            },
                        })
                }
            }
        };
    #[allow(deprecated)]
    const _: () =
        {
            #[automatically_derived]
            impl<T: Signable, MK: MultiKeychain> ::codec::Encode for
                IncompleteMultisignatureError<T, MK> where
                PartiallyMultisigned<T, MK>: ::codec::Encode,
                PartiallyMultisigned<T, MK>: ::codec::Encode {
                fn size_hint(&self) -> usize {
                    ::codec::Encode::size_hint(&&self.partial)
                }
                fn encode_to<__CodecOutputEdqy: ::codec::Output +
                    ?::core::marker::Sized>(&self,
                    __codec_dest_edqy: &mut __CodecOutputEdqy) {
                    ::codec::Encode::encode_to(&&self.partial,
                        __codec_dest_edqy)
                }
                fn encode(&self)
                    -> ::codec::alloc::vec::Vec<::core::primitive::u8> {
                    ::codec::Encode::encode(&&self.partial)
                }
                fn using_encoded<__CodecOutputReturn,
                    __CodecUsingEncodedCallback: ::core::ops::FnOnce(&[::core::primitive::u8])
                    ->
                        __CodecOutputReturn>(&self, f: __CodecUsingEncodedCallback)
                    -> __CodecOutputReturn {
                    ::codec::Encode::using_encoded(&&self.partial, f)
                }
            }
            #[automatically_derived]
            impl<T: Signable, MK: MultiKeychain> ::codec::EncodeLike for
                IncompleteMultisignatureError<T, MK> where
                PartiallyMultisigned<T, MK>: ::codec::Encode,
                PartiallyMultisigned<T, MK>: ::codec::Encode {
            }
        };
    /// Signable data together with a valid partial multisignature.
    ///
    /// Instances of this type keep track whether the partial multisignautre is complete or not.
    /// If the multisignature is complete, you can get [`Multisigned`] by pattern matching
    /// against the variant [`PartiallyMultisigned::Complete`].
    pub enum PartiallyMultisigned<T: Signable, MK: MultiKeychain> {
        Incomplete {
            unchecked: UncheckedSigned<T, MK::PartialMultisignature>,
        },
        Complete {
            multisigned: Multisigned<T, MK>,
        },
    }
    #[automatically_derived]
    impl<T: ::core::clone::Clone + Signable, MK: ::core::clone::Clone +
        MultiKeychain> ::core::clone::Clone for PartiallyMultisigned<T, MK>
        where MK::PartialMultisignature: ::core::clone::Clone {
        #[inline]
        fn clone(&self) -> PartiallyMultisigned<T, MK> {
            match self {
                PartiallyMultisigned::Incomplete { unchecked: __self_0 } =>
                    PartiallyMultisigned::Incomplete {
                        unchecked: ::core::clone::Clone::clone(__self_0),
                    },
                PartiallyMultisigned::Complete { multisigned: __self_0 } =>
                    PartiallyMultisigned::Complete {
                        multisigned: ::core::clone::Clone::clone(__self_0),
                    },
            }
        }
    }
    #[automatically_derived]
    impl<T: ::core::cmp::Eq + Signable, MK: ::core::cmp::Eq + MultiKeychain>
        ::core::cmp::Eq for PartiallyMultisigned<T, MK> where
        MK::PartialMultisignature: ::core::cmp::Eq {
        #[inline]
        #[doc(hidden)]
        #[coverage(off)]
        fn assert_fields_are_eq(&self) {
            let _:
                    ::core::cmp::AssertParamIsEq<UncheckedSigned<T,
                    MK::PartialMultisignature>>;
            let _: ::core::cmp::AssertParamIsEq<Multisigned<T, MK>>;
        }
    }
    #[automatically_derived]
    impl<T: ::core::cmp::PartialEq + Signable, MK: ::core::cmp::PartialEq +
        MultiKeychain> ::core::marker::StructuralPartialEq for
        PartiallyMultisigned<T, MK> where
        MK::PartialMultisignature: ::core::cmp::PartialEq {
    }
    #[automatically_derived]
    impl<T: ::core::cmp::PartialEq + Signable, MK: ::core::cmp::PartialEq +
        MultiKeychain> ::core::cmp::PartialEq for PartiallyMultisigned<T, MK>
        where MK::PartialMultisignature: ::core::cmp::PartialEq {
        #[inline]
        fn eq(&self, other: &PartiallyMultisigned<T, MK>) -> bool {
            let __self_discr = ::core::intrinsics::discriminant_value(self);
            let __arg1_discr = ::core::intrinsics::discriminant_value(other);
            __self_discr == __arg1_discr &&
                match (self, other) {
                    (PartiallyMultisigned::Incomplete { unchecked: __self_0 },
                        PartiallyMultisigned::Incomplete { unchecked: __arg1_0 }) =>
                        __self_0 == __arg1_0,
                    (PartiallyMultisigned::Complete { multisigned: __self_0 },
                        PartiallyMultisigned::Complete { multisigned: __arg1_0 }) =>
                        __self_0 == __arg1_0,
                    _ => unsafe { ::core::intrinsics::unreachable() }
                }
        }
    }
    #[automatically_derived]
    impl<T: ::core::hash::Hash + Signable, MK: ::core::hash::Hash +
        MultiKeychain> ::core::hash::Hash for PartiallyMultisigned<T, MK>
        where MK::PartialMultisignature: ::core::hash::Hash {
        #[inline]
        fn hash<__H: ::core::hash::Hasher>(&self, state: &mut __H) {
            let __self_discr = ::core::intrinsics::discriminant_value(self);
            ::core::hash::Hash::hash(&__self_discr, state);
            match self {
                PartiallyMultisigned::Incomplete { unchecked: __self_0 } =>
                    ::core::hash::Hash::hash(__self_0, state),
                PartiallyMultisigned::Complete { multisigned: __self_0 } =>
                    ::core::hash::Hash::hash(__self_0, state),
            }
        }
    }
    #[automatically_derived]
    impl<T: ::core::fmt::Debug + Signable, MK: ::core::fmt::Debug +
        MultiKeychain> ::core::fmt::Debug for PartiallyMultisigned<T, MK>
        where MK::PartialMultisignature: ::core::fmt::Debug {
        #[inline]
        fn fmt(&self, f: &mut ::core::fmt::Formatter) -> ::core::fmt::Result {
            match self {
                PartiallyMultisigned::Incomplete { unchecked: __self_0 } =>
                    ::core::fmt::Formatter::debug_struct_field1_finish(f,
                        "Incomplete", "unchecked", &__self_0),
                PartiallyMultisigned::Complete { multisigned: __self_0 } =>
                    ::core::fmt::Formatter::debug_struct_field1_finish(f,
                        "Complete", "multisigned", &__self_0),
            }
        }
    }
    #[allow(deprecated)]
    const _: () =
        {
            #[automatically_derived]
            impl<T: Signable, MK: MultiKeychain> ::codec::Decode for
                PartiallyMultisigned<T, MK> where
                UncheckedSigned<T,
                MK::PartialMultisignature>: ::codec::Decode,
                UncheckedSigned<T,
                MK::PartialMultisignature>: ::codec::Decode,
                Multisigned<T, MK>: ::codec::Decode,
                Multisigned<T, MK>: ::codec::Decode {
                fn decode<__CodecInputEdqy: ::codec::Input>(__codec_input_edqy:
                        &mut __CodecInputEdqy)
                    -> ::core::result::Result<Self, ::codec::Error> {
                    const _: () =
                        {
                            #[allow(clippy :: unnecessary_cast)]
                            const indices: [(u8, &'static str); 2usize] =
                                [((0usize) as ::core::primitive::u8, "Incomplete"),
                                        ((1usize) as ::core::primitive::u8, "Complete")];
                            const fn duplicate_info(array:
                                    &[(u8, &'static str); 2usize]) -> (bool, usize, usize) {
                                let len = 2usize;
                                let mut i = 0;
                                while i < len {
                                    let mut j = i + 1;
                                    while j < len {
                                        if array[i].0 == array[j].0 { return (true, i, j); }
                                        j += 1;
                                    }
                                    i += 1;
                                }
                                (false, 0, 0)
                            }
                            const DUP_INFO: (bool, usize, usize) =
                                duplicate_info(&indices);
                            if DUP_INFO.0 {
                                let msg =
                                    ::const_format::pmr::__AssertStr {
                                            x: {
                                                use ::const_format::__cf_osRcTFl4A;
                                                ({
                                                        #[doc(hidden)]
                                                        #[allow(unused_mut, non_snake_case)]
                                                        const CONCATP_NHPMWYD3NJA: &[__cf_osRcTFl4A::pmr::PArgument]
                                                            =
                                                            {
                                                                let fmt = __cf_osRcTFl4A::pmr::FormattingFlags::NEW;
                                                                &[__cf_osRcTFl4A::pmr::PConvWrapper("Found variants that have duplicate indexes. Both `").to_pargument_display(fmt),
                                                                            __cf_osRcTFl4A::pmr::PConvWrapper(indices[DUP_INFO.1].1).to_pargument_display(fmt),
                                                                            __cf_osRcTFl4A::pmr::PConvWrapper("` and `").to_pargument_display(fmt),
                                                                            __cf_osRcTFl4A::pmr::PConvWrapper(indices[DUP_INFO.2].1).to_pargument_display(fmt),
                                                                            __cf_osRcTFl4A::pmr::PConvWrapper("` have the index `").to_pargument_display(fmt),
                                                                            __cf_osRcTFl4A::pmr::PConvWrapper(indices[DUP_INFO.1].0).to_pargument_display(fmt),
                                                                            __cf_osRcTFl4A::pmr::PConvWrapper("`. Use different indexes for each variant.").to_pargument_display(fmt)]
                                                            };
                                                        {
                                                            #[doc(hidden)]
                                                            const ARR_LEN: usize =
                                                                ::const_format::pmr::PArgument::calc_len(CONCATP_NHPMWYD3NJA);
                                                            #[doc(hidden)]
                                                            const CONCAT_ARR:
                                                                &::const_format::pmr::LenAndArray<[u8; ARR_LEN]> =
                                                                &::const_format::pmr::__priv_concatenate(CONCATP_NHPMWYD3NJA);
                                                            #[doc(hidden)]
                                                            #[allow(clippy :: transmute_ptr_to_ptr)]
                                                            const CONCAT_STR: &str =
                                                                unsafe {
                                                                    let slice =
                                                                        ::const_format::pmr::transmute::<&[u8; ARR_LEN],
                                                                                &[u8; CONCAT_ARR.len]>(&CONCAT_ARR.array);
                                                                    {
                                                                        let bytes: &'static [::const_format::pmr::u8] = slice;
                                                                        let string: &'static ::const_format::pmr::str =
                                                                            {
                                                                                ::const_format::__hidden_utils::PtrToRef {
                                                                                        ptr: bytes as *const [::const_format::pmr::u8] as *const str,
                                                                                    }.reff
                                                                            };
                                                                        string
                                                                    }
                                                                };
                                                            CONCAT_STR
                                                        }
                                                    })
                                            },
                                        }.x;
                                { ::core::panicking::panic_display(&msg); };
                            }
                        };
                    match __codec_input_edqy.read_byte().map_err(|e|
                                    e.chain("Could not decode `PartiallyMultisigned`, failed to read variant byte"))?
                        {
                            #[allow(clippy :: unnecessary_cast)]
                            __codec_x_edqy if
                            __codec_x_edqy == (0usize) as ::core::primitive::u8 => {

                            #[allow(clippy :: redundant_closure_call)]
                            return (move ||
                                            {
                                                ::core::result::Result::Ok(PartiallyMultisigned::<T,
                                                        MK>::Incomplete {
                                                        unchecked: {
                                                            let __codec_res_edqy =
                                                                <UncheckedSigned<T, MK::PartialMultisignature> as
                                                                        ::codec::Decode>::decode(__codec_input_edqy);
                                                            match __codec_res_edqy {
                                                                ::core::result::Result::Err(e) =>
                                                                    return ::core::result::Result::Err(e.chain("Could not decode `PartiallyMultisigned::Incomplete::unchecked`")),
                                                                ::core::result::Result::Ok(__codec_res_edqy) =>
                                                                    __codec_res_edqy,
                                                            }
                                                        },
                                                    })
                                            })();
                        }
                            #[allow(clippy :: unnecessary_cast)]
                            __codec_x_edqy if
                            __codec_x_edqy == (1usize) as ::core::primitive::u8 => {

                            #[allow(clippy :: redundant_closure_call)]
                            return (move ||
                                            {
                                                ::core::result::Result::Ok(PartiallyMultisigned::<T,
                                                        MK>::Complete {
                                                        multisigned: {
                                                            let __codec_res_edqy =
                                                                <Multisigned<T, MK> as
                                                                        ::codec::Decode>::decode(__codec_input_edqy);
                                                            match __codec_res_edqy {
                                                                ::core::result::Result::Err(e) =>
                                                                    return ::core::result::Result::Err(e.chain("Could not decode `PartiallyMultisigned::Complete::multisigned`")),
                                                                ::core::result::Result::Ok(__codec_res_edqy) =>
                                                                    __codec_res_edqy,
                                                            }
                                                        },
                                                    })
                                            })();
                        }
                        _ => {

                            #[allow(clippy :: redundant_closure_call)]
                            return (move ||
                                            {
                                                ::core::result::Result::Err(<_ as
                                                            ::core::convert::Into<_>>::into("Could not decode `PartiallyMultisigned`, variant doesn't exist"))
                                            })();
                        }
                    }
                }
            }
        };
    #[allow(deprecated)]
    const _: () =
        {
            #[automatically_derived]
            impl<T: Signable, MK: MultiKeychain> ::codec::Encode for
                PartiallyMultisigned<T, MK> where
                UncheckedSigned<T,
                MK::PartialMultisignature>: ::codec::Encode,
                UncheckedSigned<T,
                MK::PartialMultisignature>: ::codec::Encode,
                Multisigned<T, MK>: ::codec::Encode,
                Multisigned<T, MK>: ::codec::Encode {
                fn size_hint(&self) -> usize {
                    1_usize +
                        match *self {
                            PartiallyMultisigned::Incomplete { ref unchecked } => {
                                0_usize.saturating_add(::codec::Encode::size_hint(unchecked))
                            }
                            PartiallyMultisigned::Complete { ref multisigned } => {
                                0_usize.saturating_add(::codec::Encode::size_hint(multisigned))
                            }
                            _ => 0_usize,
                        }
                }
                fn encode_to<__CodecOutputEdqy: ::codec::Output +
                    ?::core::marker::Sized>(&self,
                    __codec_dest_edqy: &mut __CodecOutputEdqy) {
                    const _: () =
                        {
                            #[allow(clippy :: unnecessary_cast)]
                            const indices: [(u8, &'static str); 2usize] =
                                [((0usize) as ::core::primitive::u8, "Incomplete"),
                                        ((1usize) as ::core::primitive::u8, "Complete")];
                            const fn duplicate_info(array:
                                    &[(u8, &'static str); 2usize]) -> (bool, usize, usize) {
                                let len = 2usize;
                                let mut i = 0;
                                while i < len {
                                    let mut j = i + 1;
                                    while j < len {
                                        if array[i].0 == array[j].0 { return (true, i, j); }
                                        j += 1;
                                    }
                                    i += 1;
                                }
                                (false, 0, 0)
                            }
                            const DUP_INFO: (bool, usize, usize) =
                                duplicate_info(&indices);
                            if DUP_INFO.0 {
                                let msg =
                                    ::const_format::pmr::__AssertStr {
                                            x: {
                                                use ::const_format::__cf_osRcTFl4A;
                                                ({
                                                        #[doc(hidden)]
                                                        #[allow(unused_mut, non_snake_case)]
                                                        const CONCATP_NHPMWYD3NJA: &[__cf_osRcTFl4A::pmr::PArgument]
                                                            =
                                                            {
                                                                let fmt = __cf_osRcTFl4A::pmr::FormattingFlags::NEW;
                                                                &[__cf_osRcTFl4A::pmr::PConvWrapper("Found variants that have duplicate indexes. Both `").to_pargument_display(fmt),
                                                                            __cf_osRcTFl4A::pmr::PConvWrapper(indices[DUP_INFO.1].1).to_pargument_display(fmt),
                                                                            __cf_osRcTFl4A::pmr::PConvWrapper("` and `").to_pargument_display(fmt),
                                                                            __cf_osRcTFl4A::pmr::PConvWrapper(indices[DUP_INFO.2].1).to_pargument_display(fmt),
                                                                            __cf_osRcTFl4A::pmr::PConvWrapper("` have the index `").to_pargument_display(fmt),
                                                                            __cf_osRcTFl4A::pmr::PConvWrapper(indices[DUP_INFO.1].0).to_pargument_display(fmt),
                                                                            __cf_osRcTFl4A::pmr::PConvWrapper("`. Use different indexes for each variant.").to_pargument_display(fmt)]
                                                            };
                                                        {
                                                            #[doc(hidden)]
                                                            const ARR_LEN: usize =
                                                                ::const_format::pmr::PArgument::calc_len(CONCATP_NHPMWYD3NJA);
                                                            #[doc(hidden)]
                                                            const CONCAT_ARR:
                                                                &::const_format::pmr::LenAndArray<[u8; ARR_LEN]> =
                                                                &::const_format::pmr::__priv_concatenate(CONCATP_NHPMWYD3NJA);
                                                            #[doc(hidden)]
                                                            #[allow(clippy :: transmute_ptr_to_ptr)]
                                                            const CONCAT_STR: &str =
                                                                unsafe {
                                                                    let slice =
                                                                        ::const_format::pmr::transmute::<&[u8; ARR_LEN],
                                                                                &[u8; CONCAT_ARR.len]>(&CONCAT_ARR.array);
                                                                    {
                                                                        let bytes: &'static [::const_format::pmr::u8] = slice;
                                                                        let string: &'static ::const_format::pmr::str =
                                                                            {
                                                                                ::const_format::__hidden_utils::PtrToRef {
                                                                                        ptr: bytes as *const [::const_format::pmr::u8] as *const str,
                                                                                    }.reff
                                                                            };
                                                                        string
                                                                    }
                                                                };
                                                            CONCAT_STR
                                                        }
                                                    })
                                            },
                                        }.x;
                                { ::core::panicking::panic_display(&msg); };
                            }
                        };
                    match *self {
                        PartiallyMultisigned::Incomplete { ref unchecked } => {

                            #[allow(clippy :: unnecessary_cast)]
                            __codec_dest_edqy.push_byte((0usize) as
                                    ::core::primitive::u8);
                            ::codec::Encode::encode_to(unchecked, __codec_dest_edqy);
                        }
                        PartiallyMultisigned::Complete { ref multisigned } => {

                            #[allow(clippy :: unnecessary_cast)]
                            __codec_dest_edqy.push_byte((1usize) as
                                    ::core::primitive::u8);
                            ::codec::Encode::encode_to(multisigned, __codec_dest_edqy);
                        }
                        _ => (),
                    }
                }
            }
            #[automatically_derived]
            impl<T: Signable, MK: MultiKeychain> ::codec::EncodeLike for
                PartiallyMultisigned<T, MK> where
                UncheckedSigned<T,
                MK::PartialMultisignature>: ::codec::Encode,
                UncheckedSigned<T,
                MK::PartialMultisignature>: ::codec::Encode,
                Multisigned<T, MK>: ::codec::Encode,
                Multisigned<T, MK>: ::codec::Encode {
            }
        };
    impl<T: Signable, MK: MultiKeychain> PartiallyMultisigned<T, MK> {
        /// Create a partially multisigned object.
        pub fn sign(signable: T, keychain: &MK)
            -> PartiallyMultisigned<T, MK> {
            Signed::sign_with_index(signable,
                    keychain).into_partially_multisigned(keychain)
        }
        /// Chceck if the partial multisignature is complete.
        pub fn is_complete(&self) -> bool {
            match self {
                PartiallyMultisigned::Incomplete { .. } => false,
                PartiallyMultisigned::Complete { .. } => true,
            }
        }
        /// Get a reference to the multisigned object.
        pub fn as_signable(&self) -> &T {
            match self {
                PartiallyMultisigned::Incomplete { unchecked } =>
                    unchecked.as_signable(),
                PartiallyMultisigned::Complete { multisigned } =>
                    multisigned.as_signable(),
            }
        }
        /// Return the object that is being signed.
        pub fn into_unchecked(self)
            -> UncheckedSigned<T, MK::PartialMultisignature> {
            match self {
                PartiallyMultisigned::Incomplete { unchecked } => unchecked,
                PartiallyMultisigned::Complete { multisigned } =>
                    multisigned.unchecked,
            }
        }
        /// Adds a signature and checks if multisignature is complete.
        #[must_use =
        "consumes the original and returns the aggregated signature which should be used"]
        pub fn add_signature(self, signed: Signed<Indexed<T>, MK>,
            keychain: &MK) -> Self {
            if self.as_signable().hash().as_ref() !=
                    signed.as_signable().hash().as_ref() {
                {
                    {
                        {
                            let lvl = ::log::Level::Warn;
                            if lvl <= ::log::STATIC_MAX_LEVEL &&
                                    lvl <= ::log::max_level() {
                                ::log::__private_api::log({
                                        ::log::__private_api::GlobalLogger
                                    },
                                    format_args!("Tried to add a signature of a different object"),
                                    lvl,
                                    &("AlephBFT-signed", "aleph_bft_crypto::signature",
                                            ::log::__private_api::loc()), ());
                            }
                        }
                    }
                };
                return self;
            }
            match self {
                PartiallyMultisigned::Incomplete { mut unchecked } => {
                    unchecked.signature =
                        unchecked.signature.add_signature(&signed.unchecked.signature,
                            signed.unchecked.signable.index);
                    if keychain.is_complete(unchecked.signable.hash().as_ref(),
                            &unchecked.signature) {
                        PartiallyMultisigned::Complete {
                            multisigned: Multisigned { unchecked },
                        }
                    } else { PartiallyMultisigned::Incomplete { unchecked } }
                }
                PartiallyMultisigned::Complete { .. } => self,
            }
        }
    }
}
pub use node::{Index, NodeCount, NodeIndex, NodeMap, NodeSubset};
pub use signature::{
    IncompleteMultisignatureError, Indexed, Keychain, MultiKeychain,
    Multisigned, PartialMultisignature, PartiallyMultisigned, Signable,
    Signature, SignatureError, SignatureSet, Signed, UncheckedSigned,
};
