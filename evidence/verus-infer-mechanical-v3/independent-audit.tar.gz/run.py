#!/usr/bin/env python3
import os,sys,json,subprocess,time,hashlib
from pathlib import Path
OUT=Path(__file__).resolve().parent
ROOT=Path('/private/tmp/verus-mechanical-v3/aleph')
ENGINE=Path('/private/tmp/verus-mechanical-v3/engine/verus/source')
mode=sys.argv[1]
assert mode in ['proof','native']
run=OUT/mode
run.mkdir(exist_ok=False)
env=dict(os.environ)
for key in ['RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','CARGO_BUILD_TARGET','VERUS_INFER_CACHE']:
 env.pop(key,None)
env.update(RUSTUP_TOOLCHAIN='1.99.1' if mode=='proof' else '1.85.1',CARGO_TARGET_DIR=str(OUT/(mode+'-target')),VERUS_Z3_PATH=str(ENGINE/'z3'),VERUS_INFER_CACHE=str(OUT/(mode+'-candidate-cache')))
env['PATH']=str(ENGINE/'target-verus/release')+os.pathsep+env.get('PATH','')
if mode=='native': env['CARGO_ENCODED_RUSTFLAGS']=''
patch='patch.crates-io.vstd.path='+json.dumps(str(ENGINE/'vstd'))
cmd=['cargo']+(['verus','verify'] if mode=='proof' else ['test'])+['--config',patch,'--offline','--locked','-p','aleph-bft-crypto','-p','aleph-bft-types','-p','aleph-bft']
if mode=='proof': cmd+=['--fwd-verus-args-to','roots','--','--infer-goals','--no-cheating','--output-json']
def fingerprint():
 files=subprocess.check_output(['git','ls-files','-z'],cwd=ROOT).decode().split('\0')
 return {str(f):hashlib.sha256((ROOT/f).read_bytes()).hexdigest() for f in files if f and (ROOT/f).is_file()}
receipt={'argv':cmd,'cwd':str(ROOT),'environment':{k:env.get(k) for k in ['RUSTUP_TOOLCHAIN','CARGO_TARGET_DIR','VERUS_Z3_PATH','VERUS_INFER_CACHE','RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER']},'before':fingerprint(),'runner_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
receipt['toolchain']=subprocess.check_output(['rustc','-vV'],env=env,text=True)
receipt['cargo']=subprocess.check_output(['cargo','-V'],env=env,text=True)
(run/'receipt-start.json').write_text(json.dumps(receipt,indent=2)+'\n')
start=time.monotonic()
with (run/'stdout').open('w') as stdout,(run/'stderr').open('w') as stderr:
 result=subprocess.run(cmd,cwd=ROOT,env=env,stdout=stdout,stderr=stderr)
receipt.update(exit_status=result.returncode,seconds=time.monotonic()-start,after=fingerprint())
receipt['sources_unchanged']=receipt['before']==receipt['after']
(run/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'mode':mode,'exit':result.returncode,'seconds':receipt['seconds'],'sources_unchanged':receipt['sources_unchanged']}))
sys.exit(result.returncode)
