use vstd::prelude::*;
#[verus_verify] pub struct Slots<T>(Vec<Option<T>>);
verus! {
impl<T> View for Slots<T> {type V=Seq<Option<T>>;
 closed spec fn view(&self)->Self::V {self.0@}}
impl<T> Slots<T> {
 pub open spec fn entries_value(&self)->Seq<(usize,&T)> {
  vstd::seq_update::sparse_entries(self@,|i:int|(i as usize,&self@[i].unwrap()))
 }
}
}
#[verus_verify] impl<T> Slots<T> {
 #[verus_infer] pub fn size(&self)->usize {self.0.len()}
 #[verus_infer] pub fn insert(&mut self,index:usize,value:T) {self.0[index]=Some(value);}
 #[verus_infer] pub fn with_size(n:usize)->Self where T:Clone {Slots(vec![None;n])}
 #[verus_verify(iterator_via_view(self.entries_value()))]
 pub fn iter(&self)->impl Iterator<Item=(usize,&T)> {
  self.0.iter().enumerate().filter_map(|(i,v)|Some((i,v.as_ref()?)))
 }
}
#[verus_verify] pub trait Stamp {fn stamp()->u64;}
#[verus_verify] pub struct Packet {slots:Slots<u16>,stamp:u64}
verus! {
impl View for Packet {type V=(Seq<Option<u16>>,u64);
 closed spec fn view(&self)->Self::V {(self.slots@,self.stamp)}}
pub fn pack<H:Stamp,T:Copy>(source:&Slots<(T,u16)>)->(result:Packet)
 ensures result@.0 == source@.map_values(|slot:Option<(T,u16)>|
  match slot {None=>None,Some((_,n))=>Some(n)}),
{
 let mut out=Slots::with_size(source.size());
 for (index,(_,value)) in source.iter() {out.insert(index,0);}
 Packet {slots:out,stamp:H::stamp()}
}
}
