use vstd::prelude::*;use assign_provider::Quantity;use assign_consumer::State;
verus! { pub fn policy(s:&mut State,delta:Quantity)
 requires (old(s).count.0 as int + delta.0 as int) < u8::MAX,
 ensures final(s).count.0 as int == old(s).count.0 as int + delta.0 as int + 1,
  final(s).epoch == old(s).epoch,
 {s.bump(delta);}
}
