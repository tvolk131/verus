use vstd::prelude::*;verus!{
pub struct Slot {pub number:u16,pub payload:u64}
pub struct History {pub slots:Vec<Slot>,pub tag:u8}
impl History {
 pub open spec fn valid(&self)->bool {
  0<self.slots@.len()<=u16::MAX && forall|j:int|0<=j<self.slots@.len()
   ==> self.slots@[j].number==j
 }
 pub fn select(&mut self,index:u16)->(slot:&mut Slot)
  requires old(self).valid(),index<u16::MAX,
  ensures slot.number==index,
 {
  while self.slots.len()<=index as usize {
   let number=self.slots.len() as u16;
   self.slots.push(Slot{number,payload:0});
  }
  &mut self.slots[index as usize]
 }
}

pub fn untouched(s:&mut History,index:u16)
 requires old(s).valid(),index<u16::MAX,
 ensures final(s).valid(),final(s).tag==old(s).tag,
  final(s).slots@.len()==if old(s).slots@.len()>index as int+1 {old(s).slots@.len() as int}else{index as int+1},
  final(s).slots@.take(old(s).slots@.len() as int)==old(s).slots@,
 {let _=s.select(index);}
pub fn caller(s:&mut History,index:u16)
 requires old(s).valid(),index<u16::MAX,
 ensures final(s).valid(),final(s).tag==old(s).tag,
  final(s).slots@.len()==if old(s).slots@.len()>index as int+1 {old(s).slots@.len() as int}else{index as int+1},
  forall|j:int|0<=j<old(s).slots@.len() && j!=index ==> final(s).slots@[j]==old(s).slots@[j],
{
 let slot=s.select(index);
 slot.number=0;
}
}