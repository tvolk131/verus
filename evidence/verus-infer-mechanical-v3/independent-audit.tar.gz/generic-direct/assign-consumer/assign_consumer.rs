use vstd::prelude::*;use assign_provider::Quantity;
#[verus_verify] pub struct State {pub count:Quantity,pub epoch:u64}
#[verus_verify] impl State {
 #[verus_infer] pub fn bump(&mut self,delta:Quantity) {
  self.count += delta;
  self.count += Quantity(1);
 }
}
