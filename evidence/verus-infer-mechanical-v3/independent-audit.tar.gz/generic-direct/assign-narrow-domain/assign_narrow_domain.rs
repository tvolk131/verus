use vstd::prelude::*;
#[verus_verify] #[derive(Copy,Clone)] pub struct Quantity(pub u8);
verus! {
 impl Quantity { pub open spec fn __verus_infer_derived_add_assign(&self)->bool {true} }
 impl vstd::std_specs::ops::AddAssignSpecImpl for Quantity {
  open spec fn obeys_add_assign_spec()->bool {true}
  open spec fn add_assign_req(&self,rhs:Self)->bool {
   self.0 as int + rhs.0 as int <= u8::MAX / 2
  }
  open spec fn add_assign_spec(&self,rhs:Self)->&Self {&Quantity((self.0+rhs.0) as u8)}
 }
}
#[automatically_derived]
impl core::ops::AddAssign for Quantity {
 fn add_assign(&mut self,rhs:Self) {self.0.add_assign(rhs.0);}
}
