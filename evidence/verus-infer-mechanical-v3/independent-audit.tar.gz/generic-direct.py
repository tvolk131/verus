#!/usr/bin/env python3
from pathlib import Path
import re,os,subprocess,json,time,hashlib
OUT=Path(__file__).resolve().parent/'generic-direct'
OUT.mkdir(exist_ok=False)
ENGINE=Path('/private/tmp/verus-mechanical-v3/engine/verus/source')
BIN=ENGINE/'target-verus/release'
env=dict(os.environ,RUSTUP_TOOLCHAIN='1.99.1',VERUS_Z3_PATH=str(ENGINE/'z3'),VERUS_INFER_CACHE=str(OUT/'cache'))
source_root=ENGINE/'rust_verify_test/tests'
def raw(path,name):
 return re.search(r'const '+name+r': &str = r#"(.*?)"#;',path.read_text(),re.S).group(1)
fold=raw(source_root/'infer_cases/local_folds.rs','SOURCE')
growth=raw(source_root/'infer_growth.rs','SELECTOR')
growth=growth.replace('pub struct Slot {pub number:u16}','pub struct Slot {pub number:u16,pub payload:u64}').replace('  self.grow(index);',"""  while self.slots.len()<=index as usize {
   let number=self.slots.len() as u16;
   self.slots.push(Slot{number,payload:0});
  }""")
a=growth.index(' pub fn grow');b=growth.index(' pub fn select');growth=growth[:a]+growth[b:]
growth=growth.replace('pub fn caller(s:',"""
pub fn untouched(s:&mut History,index:u16)
 requires old(s).valid(),index<u16::MAX,
 ensures final(s).valid(),final(s).tag==old(s).tag,
  final(s).slots@.len()==if old(s).slots@.len()>index as int+1 {old(s).slots@.len() as int}else{index as int+1},
  final(s).slots@.take(old(s).slots@.len() as int)==old(s).slots@,
 {let _=s.select(index);}
pub fn caller(s:""")
receipts=[]
def run(label,name,body,expected,dependencies=(),flags=('--infer-goals','--no-cheating','--output-json')):
 d=OUT/label;d.mkdir()
 p=d/(name+'.rs');p.write_text(body)
 cmd=[str(BIN/'verus'),'--crate-type=lib','--edition=2021','--crate-name',name,'--export',str(OUT/(name+'.vir')),'--compile','-o',str(OUT/('lib'+name+'.rlib')),'-L','dependency='+str(OUT)]
 for dep in dependencies:cmd+=['--extern',dep+'='+str(OUT/('lib'+dep+'.rlib')),'--import',dep+'='+str(OUT/(dep+'.vir'))]
 cmd += [*flags,str(p)]
 t=time.monotonic();r=subprocess.run(cmd,cwd=d,env=env,text=True,capture_output=True)
 (d/'stdout').write_text(r.stdout);(d/'stderr').write_text(r.stderr)
 entry={'label':label,'argv':cmd,'exit':r.returncode,'expected_success':expected,'seconds':time.monotonic()-t,'source_sha256':hashlib.sha256(body.encode()).hexdigest(),'interface_exists':(OUT/(name+'.vir')).exists()}
 receipts.append(entry);(OUT/'receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')
 assert (r.returncode==0)==expected,(label,r.stderr)
 if not expected:assert not entry['interface_exists'],label
for label,body,success,flags in [
 ('fold-positive',fold,True,('--infer-goals','--no-cheating','--output-json')),
 ('fold-wrong-value',fold.replace('out.insert(index,*value)','out.insert(index,0)'),False,('--infer-goals','--no-cheating','--output-json')),
 ('fold-wrong-index',fold.replace('out.insert(index,*value)','out.insert(index+1,*value)'),False,('--infer-goals','--no-cheating','--output-json')),
 ('fold-without-assistance',fold,False,('--no-cheating','--output-json')),
 ('growth-positive',growth,True,('--infer-goals','--no-cheating','--output-json')),
 ('growth-wrong-return',growth.replace('&mut self.slots[index as usize]','&mut self.slots[0]'),False,('--infer-goals','--no-cheating','--output-json')),
 ('growth-wrong-coordinate',growth.replace('let number=self.slots.len() as u16;','let number=0;'),False,('--infer-goals','--no-cheating','--output-json')),
 ('growth-wrong-frame',growth.replace('self.slots.push(Slot{number,payload:0});','self.tag=0;self.slots.push(Slot{number,payload:0});'),False,('--infer-goals','--no-cheating','--output-json')),
 ('growth-invalid-restoration',growth.replace('slot.number=index;','slot.number=0;'),False,('--infer-goals','--no-cheating','--output-json')),
 ('growth-terminal-domain',growth.replace('index<u16::MAX','index<=u16::MAX'),False,('--infer-goals','--no-cheating','--output-json')),
]:run(label,label.replace('-','_'),body,success,flags=flags)
# Unrelated three-crate wrapper assignment regression, with actual compiled bodies.
assign_path=source_root/'infer_cases/derive_assignments.rs'
assign=raw(assign_path,'ASSIGN')
text=assign_path.read_text();consumer=re.search(r'let consumer = r#"(.*?)"#;',text,re.S).group(1);client=re.search(r'let client = r#"(.*?)"#;',text,re.S).group(1)
run('assign-provider','assign_provider',assign,True)
run('assign-consumer','assign_consumer',consumer,True,('assign_provider',))
run('assign-client','assign_client',client,True,('assign_provider','assign_consumer'))
run('assign-wrong-goal','assign_client',client.replace('+ 1,','+ 2,'),False,('assign_provider','assign_consumer'))
for label,body in [
 ('assign-wrong-body',assign.replace('self.0.add_assign(rhs.0);','self.0 = rhs.0;')),
 ('assign-narrow-domain',assign.replace('<= u8::MAX','<= u8::MAX / 2')),
 ('assign-wide-domain',assign.replace('<= u8::MAX','<= 511')),
]:run(label,label.replace('-','_'),body,False)
print(json.dumps({'cases':len(receipts),'all_expectations_met':True}))
