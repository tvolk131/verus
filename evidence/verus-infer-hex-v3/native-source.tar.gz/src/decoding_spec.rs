// SPDX-License-Identifier: CC0-1.0
//! Authored required behavior, independent of the native lookup table.
use vstd::prelude::*;
verus! {
pub open spec fn table_value(i: int) -> u8 {
    if 48 <= i <= 57 { (i - 48) as u8 }
    else if 65 <= i <= 70 { (i - 65 + 10) as u8 }
    else if 97 <= i <= 102 { (i - 97 + 10) as u8 }
    else { 255 }
}
pub open spec fn digit(b: u8) -> Option<u8> {
    if 48 <= b <= 57 { Some((b - 48) as u8) }
    else if 65 <= b <= 70 { Some((b - 65 + 10) as u8) }
    else if 97 <= b <= 102 { Some((b - 97 + 10) as u8) }
    else { None }
}
pub open spec fn pair(hi: u8, lo: u8) -> Result<u8, (u8, bool)> {
    match digit(hi) {
        None => Err((hi, true)),
        Some(h) => match digit(lo) {
            None => Err((lo, false)),
            Some(l) => Ok((16 * h + l) as u8),
        },
    }
}
pub open spec fn byte_pairs(bytes:Seq<u8>)->Seq<[u8;2]> {
    Seq::new(bytes.len()/2,|i:int|[bytes[2*i],bytes[2*i+1]])
}

pub(crate) open spec fn located_pair(p:[u8;2],cursor:int)->Result<u8,crate::error::InvalidCharError> {
    match pair(p@[0],p@[1]) {
        Ok(v)=>Ok(v),
        Err((c,high))=>Err(crate::error::InvalidCharError {
            invalid:c,pos:if (2*cursor+if high {0int}else{1int})>usize::MAX {usize::MAX}
                else {(2*cursor+if high {0int}else{1int}) as usize},
        }),
    }
}
pub(crate) open spec fn pair_results(pairs:Seq<[u8;2]>,cursor:int)->Seq<Result<u8,crate::error::InvalidCharError>> {
    Seq::new(pairs.len(),|i:int|located_pair(pairs[i],cursor+i))
}
pub(crate) open spec fn byte_results(bytes:Seq<u8>)->Seq<Result<u8,crate::error::InvalidCharError>> {
    pair_results(byte_pairs(bytes),0)
}

}
