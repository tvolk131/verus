import json,subprocess,hashlib
from pathlib import Path
r=Path('/Users/tommyvolk/Documents/GitHub/verus');n=r.parent/'hex-conservative';w=Path('/private/tmp/verus-hex-v3');b=w/'required-baselines';binary='/private/tmp/verus-validation-v4/inventory-target/release/verus-adoption-source-inventory'
def entries(root,filename):return json.loads(subprocess.check_output([binary,str(root),filename],text=True))['entries']
checks=[]
for commit,filename,names in [('ae20db038c7807e0b2f851b40149265783f7a4b7','src/lib.rs',['required_vector_result']),('5ccfbad247d5a332408929173e4072fbf06d8bd1','src/decoding_spec.rs',['table_value','digit','pair'])]:
 root=b/commit;p=root/filename;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(subprocess.check_output(['git','show',commit+':'+filename],cwd=n))
 before={e['name']:e for e in entries(root,filename) if e['kind']=='function'};after={e['name']:e for e in entries(n,filename) if e['kind']=='function'}
 for name in names:
  assert before[name]['signature']==after[name]['signature'],name
  assert before[name]['body']==after[name]['body'],name
  checks.append(dict(function=name,baseline=commit,body_unchanged=True,signature_unchanged=True,body_sha256=hashlib.sha256(after[name]['body'].encode()).hexdigest()))
(r/'evidence/verus-infer-hex-v3/requirements-preservation.json').write_text(json.dumps(checks,indent=2)+'\n')
print('Public required predicate and all v1 numeric decoding policies are unchanged')
