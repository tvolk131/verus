import gzip,hashlib,io,json,re,subprocess,tarfile
from pathlib import Path
r=Path('/Users/tommyvolk/Documents/GitHub/verus');n=r.parent/'hex-conservative';w=Path('/private/tmp/verus-hex-v3');o=r/'evidence/verus-infer-hex-v3';b=r/'source/target-verus/release'
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def git(root,*args):return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
def dump(name,value):(o/name).write_text(json.dumps(value,indent=2)+'\n')
a=json.loads((w/'acceptance-committed/receipt.json').read_text());assert a['success'];last=a['cases'][-1];v=last['verification'];inf=last['inference']
assert v['verified']==37 and v['errors']==0 and inf['interface_written']
assert len(inf['functions'])==1 and all(inf['functions'][0]['proofs'][p]['status']=='proved' for p in ['soundness','maximality','exactness'])
for name,digest in a['artifacts'].items():assert h(b/name)==digest,name
assert git(n,'status','--porcelain')==''
assert a['native_commit']==git(n,'rev-parse','HEAD')
assert a['native_sources_before']==a['native_sources_after']
for label,count in [('committed-infer',294),('committed-new-raw',3)]:assert re.search(r'test result: ok\. '+str(count)+r' passed; 0 failed',(w/(label+'.stdout')).read_text())
assert '2219 verified, 0 errors' in (w/'committed-vstd.stdout').read_text()
for count in [57,43,17,90]:assert f'test result: ok. {count} passed; 0 failed' in (w/'committed-general.stdout').read_text()
assert all(x['exit']==0 for x in json.loads((w/'committed-replays.json').read_text()))
mutations=[c['label'] for c in a['cases'] if c['label'] not in ['fresh','restored','without_assistance','no_verify','filtered','no_lifetime']];assert len(mutations)==24
for c in a['cases']:
 assert c['expected_success']==c['inference']['interface_written']
 assert c['verification'].get('success',False)==c['expected_success']
checks=[]
for c in a['cases']:
 x=c['inference'];fs=x['functions'];checks.append(dict(label=c['label'],expected_success=c['expected_success'],verification=c['verification'],interface_written=x['interface_written'],exact_pair_checks_passed=(len(fs)==1 and fs[0]['required_checks_passed']),diagnostic_first_errors=[line for line in (w/'acceptance-committed'/(c['label']+'.stderr')).read_text().splitlines() if line.startswith('error:')]))
dump('controls-summary.json',dict(success=True,accepting_series='acceptance-committed',cases=checks,semantic_safety_mutations=mutations,resource_controls=json.loads((w/'lease-controls.json').read_text()),runtime_hint_controls=json.loads((w/'hint-controls.json').read_text()),additional_regression_controls=['sealed receipt after reserve','custom Drop unsupported','custom forward adapter unsupported','no-vacuity assert(false)','no-flag failed proof/no-verify publication','cross-crate no-lifetime rejection','fake resolved primitive identity','unsupported extra alias'],commands=a['commands']+json.loads((w/'committed-replays.json').read_text())))
# Preserve the exact native committed tree, including its pre-existing ignored lock.
native_tar=io.BytesIO(subprocess.check_output(['git','archive','--format=tar','HEAD'],cwd=n))
with tarfile.open(fileobj=native_tar,mode='a') as t:
 p=n/'Cargo.lock';info=tarfile.TarInfo('Cargo.lock');data=p.read_bytes();info.size=len(data);info.mode=0o644;t.addfile(info,io.BytesIO(data))
(o/'native-source.tar.gz').write_bytes(gzip.compress(native_tar.getvalue(),mtime=0))
for filename,root,base in [('native-source.patch.gz',n,'129db6ac54d25b08e0b927c225aefe4a8df05a57'),('engine-source.patch.gz',r,'5b8a980e9')]:
 data=subprocess.check_output(['git','diff','--binary',base,'HEAD','--',*([] if root==n else ['source'])],cwd=root);(o/filename).write_bytes(gzip.compress(data,mtime=0))
engine_files=[r/f for f in git(r,'ls-files').splitlines() if not f.startswith('evidence/') and (r/f).is_file()]
native_files=sorted(set([n/f for f in git(n,'ls-files').splitlines() if (n/f).is_file()]+[n/'Cargo.lock']))
artifacts={f:h(b/f) for f in ['verus','rust_verify','vstd.vir','libvstd.rlib','libverus_builtin.rlib','libverus_builtin_macros.dylib','libverus_state_machines_macros.dylib'] if (b/f).is_file()}
dump('engine-source-receipt.json',dict(engine_implementation_commit=git(r,'rev-parse','HEAD'),native_implementation_commit=git(n,'rev-parse','HEAD'),engine_baseline='5b8a980e9af19ba22a8774013dbdcae4e5e09137',native_baseline='ae20db038c7807e0b2f851b40149265783f7a4b7',metadata_schema=38,inference_policy=54,candidate_cache=60,binary_banner=subprocess.check_output([str(b/'verus'),'--version'],text=True),artifacts=artifacts,solver_sha256=h(r/'source/z3'),engine_source_sha256={str(p.relative_to(r)):h(p) for p in engine_files},native_source_sha256={str(p.relative_to(n)):h(p) for p in native_files},toolchains={v:subprocess.check_output(['rustc','+'+v,'--version','--verbose'],text=True) for v in ['1.99.1','1.74.0']},acceptance_artifacts_match_current=True,tracked_engine_source_clean=not git(r,'diff','--name-only','HEAD'),native_worktree_clean=True))
# The public required predicate and v1 policy equations have independent parser pins.
assert len(json.loads((o/'requirements-preservation.json').read_text()))==4
changed=git(n,'diff','--name-only','ae20db0','HEAD').splitlines();assert changed==['VERUS_INFER.md','src/decoding_spec.rs','src/error.rs','src/iter.rs','src/lib.rs']
locks=[]
with tarfile.open(r/'evidence/verus-infer-hex-v2/native-source.tar.gz','r:gz') as t:
 for m in t.getmembers():
  if Path(m.name).name=='Cargo.lock':locks.append(hashlib.sha256(t.extractfile(m).read()).hexdigest())
assert h(n/'Cargo.lock') in locks
configs=[p for p in native_files if p.name.startswith('Cargo') or '.cargo' in p.parts or p.name.startswith('rust-toolchain')]
dump('source-changes.json',dict(native_changes_this_phase=changed,production_algorithms_changed=0,original_upstream_functions_unchanged=218,source_config_only_inventory=['required semantic predicates/observations','explicit exact-hint capability opt-ins','equivalent canonical pair-sequence constructor requirements','reachable internal drain domain requirement','checked error-conversion trait requirements','byte-buffer and semantic-prefix proof-only annotations','two new application semantic goals','documentation'],native_config_changes_this_phase=[],native_configuration_sha256={str(p.relative_to(n)):h(p) for p in configs},ignored_lock_matches_accepted_v2_archive=True,tooling_instrumentation=['tracked allocation lease and initialized prefix invariants','ordinary checked write/seal/abandon','checked general two-byte prefix lemma','alternate sequence-index instantiation patterns','resolved native primitive type/identity guard','selected native runtime override/Drop/adapter inventory'],source_ghost_instrumentation_erases=True,proof_compiled_linked_native_smoke_passed=True))
# Prior archives/pins are read-only; verify native commit objects and ancestry too.
preservation=json.loads((o/'preservation.json').read_text());preservation['hex_source_pins']={}
for commit in ['5ccfbad247d5a332408929173e4072fbf06d8bd1','cc0bf36056a190bd7da4cbf226e778580e8bb472','ae20db038c7807e0b2f851b40149265783f7a4b7']:
 subprocess.run(['git','merge-base','--is-ancestor',commit,'HEAD'],cwd=n,check=True);preservation['hex_source_pins'][commit]=git(n,'rev-parse',commit+'^{tree}')
dump('preservation.json',preservation)
goals=sorted(x['function'] for x in inf['verification_scope']['native_functions'] if x['body_status']=='checked_exec_body' and x['function'].endswith('_goal'))
dump('closure-summary.json',dict(decision='accepted finite original native public byte-vector decoder milestone',engine_implementation_commit=git(r,'rev-parse','HEAD'),native_implementation_commit=git(n,'rev-parse','HEAD'),proof_run='acceptance-committed/restored',verification_results=37,errors=0,new_application_obligations=['iter::runtime_length_goal','iter::forward_drain_domain_goal','iter::HexToBytesIter::drain_to_vec','decode_to_vec'],retained_application_goal_functions=7,added_application_goal_functions=2,all_semantic_goal_functions=goals,native_named_checked_exec_bodies=32,real_static_initializer_checked=True,exact_inference_helpers=1,mandatory_certificates=3,inference_regressions=294,constant_static_regressions=57,constant_static_ignored=2,external_trait_regressions=43,unwind_regressions=17,type_invariant_regressions=90,vstd_verified_tooling_only=2219,semantic_safety_mutations_rejected=24,negative_publication_controls=['without_assistance','no_verify','filtered','no_lifetime','no-flag failed/no-verify providers','cross-crate no-lifetime'],native_feature_msrv_passed=True,proof_compiled_linked_hex_and_unrelated_native_smokes_passed=True,original_bodies_and_required_public_predicate_unchanged=True,metadata_schema=38,inference_policy=54,candidate_cache=60,restored_source_hashes_match=True,full_selected_scope_verified=inf['verification_scope']['complete_selected_scope_verified'],prior_acceptance_preserved=True,upstream_defects_found=0))
# Archive logs, source fixtures and controllers, never Cargo targets or caches.
paths=[]
for p in w.rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(w)
 if any('target' in part or part.endswith('-cache') or part in ['native-baseline','hint-log','hint-unselected-log','related-vir','required-baselines','upstream-source','example-native','example-msrv','example-final'] for part in rel.parts[:-1]):continue
 if p.suffix not in ['.stdout','.stderr','.rs','.py','.json','.vir']:continue
 if p.suffix=='.vir' and not (rel.parts[0]=='acceptance-committed' or p.name=='committed-compiled.vir'):continue
 paths.append(p)
paths.sort();index=[];buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w') as t:
 for p in paths:
  data=p.read_bytes();name=str(p.relative_to(w));info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;t.addfile(info,io.BytesIO(data));index.append(dict(path=name,size=len(data),sha256=hashlib.sha256(data).hexdigest()))
(o/'raw-evidence.tar.gz').write_bytes(gzip.compress(buf.getvalue(),mtime=0))
dump('raw-evidence-index.json',dict(accepting_series='acceptance-committed',committed_regression_replay_prefix='committed-',other_series='development only; no extra application acceptance claims',archive_sha256=h(o/'raw-evidence.tar.gz'),files=index))
print('Packaged',len(paths),'raw files;',len(goals),'semantic goals;',len(mutations),'mutations')
