import subprocess,json,os
from pathlib import Path
w=Path('/private/tmp/verus-hex-v3');r=Path('/Users/tommyvolk/Documents/GitHub/verus');env=dict(os.environ,VERUS_Z3_PATH=str(r/'source/z3'))
s=(w/'hints.rs').read_text()
cases={
'wrong_hint':s.replace('(self.left,Some(self.left))','(0,Some(0))'),
'wrong_len':s.replace('impl ExactSizeIterator for Counter {}','impl ExactSizeIterator for Counter {fn len(&self)->usize{0}}'),
'unselected_wrong_len':s.replace('#[verus_verify] impl ExactSizeIterator for Counter {}','impl ExactSizeIterator for Counter {fn len(&self)->usize{0}}'),
'unselected_hint':s.replace('#[verus_verify] impl Iterator for Counter {','impl Iterator for Counter {').replace(' fn next',' #[verus_verify] fn next'),
'no_capability':s.replace('has_exact_size_hint(&self)->bool{true}','has_exact_size_hint(&self)->bool{false}'),
'false_logical_len':s.replace('exact_len(&self)->usize{self.left}','exact_len(&self)->usize{0}'),
}
rows=[]
for label,src in cases.items():
 p=w/('hint-'+label+'.rs');p.write_text(src)
 with (w/('hint-'+label+'.stdout')).open('w') as out,(w/('hint-'+label+'.stderr')).open('w') as err:
  run=subprocess.run([str(r/'source/target-verus/release/verus'),str(p),'--crate-type','lib','--infer-goals','--no-cheating','--output-json'],cwd=r,env=env,stdout=out,stderr=err)
 success=label=='false_logical_len';assert (run.returncode==0)==success,(label,run.returncode)
 print(label,run.returncode,flush=True);rows.append(dict(label=label,expected_success=success,exit_code=run.returncode))
(w/'hint-controls.json').write_text(json.dumps(rows,indent=2)+'\n')
