use vstd::prelude::*;
use vstd::std_specs::iter::{IteratorSpec,IteratorSpecImpl,ExactSizeIteratorSpecImpl};
#[verus_verify] pub struct Counter {left:usize}
#[verus_verify] impl Iterator for Counter {
 type Item=u8;
 fn next(&mut self)->Option<u8>{if self.left==0 {None}else{self.left-=1;Some(1)}}
 fn size_hint(&self)->(usize,Option<usize>){(self.left,Some(self.left))}
}
#[verus_verify] impl ExactSizeIterator for Counter {fn len(&self)->usize{0}}
verus! {
impl IteratorSpecImpl for Counter {
 closed spec fn has_exact_size_hint(&self)->bool{true}
 closed spec fn obeys_prophetic_iter_laws(&self)->bool{true}
 closed spec fn remaining(&self)->Seq<u8>{Seq::new(self.left as nat,|i:int|1u8)}
 closed spec fn will_return_none(&self)->bool{true}
 closed spec fn decrease(&self)->Option<nat>{Some(self.left as nat)}
 closed spec fn peek(&self,i:int)->Option<u8>{if 0<=i<self.left{Some(1)}else{None}}
}
impl ExactSizeIteratorSpecImpl for Counter {closed spec fn exact_len(&self)->usize{self.left}}
pub fn length(n:usize)->(r:usize) ensures r==n, {let c=Counter{left:n};c.len()}
}
