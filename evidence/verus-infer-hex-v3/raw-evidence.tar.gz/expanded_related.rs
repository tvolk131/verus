#![feature(proc_macro_hygiene)]
use vstd::prelude::*;
use vstd::std_specs::iter::IteratorSpec;

verus! {
pub open spec fn result_policy(input:Seq<Result<u8,u8>>,r:Result<Vec<u8>,u8>)->bool {
 match r {
  Ok(v)=>v@.len()==input.len() && forall|i:int| 0<=i<input.len() ==> input[i]==Ok(v@[i]),
  Err(e)=>exists|i:int| 0<=i<input.len() && input[i]==Err(e) && (forall|j:int| 0<=j<i ==> input[j].is_ok()),
 }
}
}

#[verus_verify]
#[verus_spec(r => ensures result_policy(input@,r))]
pub fn fill(input:Vec<Result<u8,u8>>)->Result<Vec<u8>,u8> {
    use :: vstd :: std_specs :: iter :: IteratorSpec as _; let iter =
    input.into_iter(); let len = iter.len(); let mut output = :: vstd ::
    byte_vec :: native_allocate(Vec :: < u8 > :: with_capacity, len); let
    (mut ptr, VERUS_byte_lease) = :: vstd :: byte_vec ::
    native_acquire(Vec :: < u8 > :: as_mut_ptr, & mut output); proof_decl!
    { let tracked mut VERUS_byte_spare = VERUS_byte_lease.get(); } proof_decl!
    {
        let ghost VERUS_byte_input = iter; let ghost VERUS_byte_binding =
        VERUS_byte_spare;
    }
    #[verus_spec(VERUS_byte_iterator => invariant VERUS_byte_spare.wf(),
    forall | v : & Vec < u8 > | ! VERUS_byte_binding.matches(v) ||
    VERUS_byte_spare.matches(v), VERUS_byte_spare.contents().len() ==
    VERUS_byte_iterator.index @ ,
    VERUS_byte_spare.pointer(ptr, VERUS_byte_spare.contents().len() as int),
    ptr @ .addr as int == VERUS_byte_spare.base() @ .addr as int +
    VERUS_byte_spare.contents().len(), VERUS_byte_input.remaining().len() <=
    VERUS_byte_spare.capacity(), VERUS_byte_iterator.seq() ==
    VERUS_byte_input.remaining(), forall | i : int | !
    (0 <= i && i < VERUS_byte_spare.contents().len()) ||
    VERUS_byte_input.remaining() [i] == Ok(VERUS_byte_spare.contents() [i]),)]
    for byte in iter
    {
        :: vstd :: byte_vec ::
        native_write(core :: ptr :: write :: < u8 > , ptr, byte ? , :: vstd ::
        prelude :: verus_exec_expr! (Tracked(& mut VERUS_byte_spare))); ptr =
        :: vstd :: byte_vec ::
        native_advance(< * mut u8 > :: add, ptr, 1, :: vstd :: prelude ::
        verus_exec_expr! (Tracked(& VERUS_byte_spare)));
    } proof_decl!
    {
        let tracked VERUS_byte_receipt = :: vstd :: byte_vec ::
        seal(VERUS_byte_spare);
    } :: vstd :: byte_vec ::
    native_finish(Vec :: < u8 > :: set_len, & mut output, len, :: vstd ::
    prelude :: verus_exec_expr! (Tracked(VERUS_byte_receipt))); Ok(output)
}
