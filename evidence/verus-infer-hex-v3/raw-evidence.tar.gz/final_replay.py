import hashlib,json,os,subprocess,time
from pathlib import Path
engine=Path('/Users/tommyvolk/Documents/GitHub/verus');out=Path('/private/tmp/verus-hex-v3');release=engine/'source/target-verus/release';env=dict(os.environ,VERUS_Z3_PATH=str(engine/'source/z3'),RUSTUP_TOOLCHAIN='1.99.1')
rows=[]
def run(label,argv,cwd=engine,expected=0):
 t=time.monotonic()
 with (out/(label+'.stdout')).open('w') as a,(out/(label+'.stderr')).open('w') as b:
  r=subprocess.run(argv,cwd=cwd,env=env,stdout=a,stderr=b)
 rows.append(dict(label=label,command=[str(a) for a in argv],cwd=str(cwd),exit=r.returncode,seconds=time.monotonic()-t))
 assert r.returncode==expected,(label,r.returncode)
 (out/'committed-replays.json').write_text(json.dumps(rows,indent=2)+'\n')
run('committed-infer',['cargo','test','--release','--offline','--locked','-p','rust_verify_test','--test','infer'],engine/'source')
run('committed-general',['cargo','test','--release','--offline','--locked','-p','rust_verify_test','--test','consts','--test','unwind','--test','user_defined_type_invariants','--test','external_traits'],engine/'source')
run('committed-new-raw',['cargo','test','--release','--offline','--locked','-p','rust_verify_test','--test','infer','byte_spare','--','--nocapture'],engine/'source')
run('committed-hints',['python3',str(out/'hint_controls.py')])
run('committed-leases',['python3',str(out/'lease_controls.py')])
run('committed-example-native',['cargo','+1.99.1','test','--offline','--locked','--manifest-path',str(engine/'source/tools/native_byte_buffer/Cargo.toml'),'--target-dir',str(out/'committed-example-native-target')])
run('committed-example-msrv',['cargo','+1.74.0','test','--offline','--locked','--manifest-path',str(engine/'source/tools/native_byte_buffer/Cargo.toml'),'--target-dir',str(out/'committed-example-msrv-target')])
run('committed-compiled',[str(release/'verus'),'/Users/tommyvolk/Documents/GitHub/hex-conservative/src/lib.rs','--crate-type','lib','--crate-name','hex_conservative','--cfg','feature="std"','--cfg','feature="alloc"','--cfg','verus_hex_vec_phase3','--infer-goals','--no-cheating','--compile','--output-json','--export',str(out/'committed-compiled.vir'),'-o',str(out/'libhex_conservative.rlib')])
run('committed-linked-build',['rustc','+1.99.1','--edition=2021',str(out/'native_smoke.rs'),'--extern','hex_conservative='+str(out/'libhex_conservative.rlib'),'-L','dependency='+str(release),'-o',str(out/'native_smoke')])
run('committed-linked-run',[str(out/'native_smoke')])
print('committed replays passed')
