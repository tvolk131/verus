#![feature(proc_macro_hygiene)]
use vstd::prelude::*;
use vstd::std_specs::iter::IteratorSpec;

verus! {
pub open spec fn result_policy(input:Seq<Result<u8,u8>>,r:Result<Vec<u8>,u8>)->bool {
 match r {
  Ok(v)=>v@.len()==input.len() && forall|i:int| 0<=i<input.len() ==> input[i]==Ok(v@[i]),
  Err(e)=>exists|i:int| 0<=i<input.len() && input[i]==Err(e) && (forall|j:int| 0<=j<i ==> input[j].is_ok()),
 }
}
}

#[verus_verify(byte_buffer)]
#[verus_spec(r => ensures result_policy(input@,r))]
pub fn fill(input:Vec<Result<u8,u8>>)->Result<Vec<u8>,u8> {
 let iter=input.into_iter();
 let len=iter.len();
 let mut output=Vec::with_capacity(len);
 let mut ptr=output.as_mut_ptr();
 for byte in iter {
  unsafe {
   core::ptr::write(ptr,byte?);
   ptr=ptr.add(1);
  }
 }
 unsafe {output.set_len(len);}
 Ok(output)
}
