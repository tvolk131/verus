use vstd::prelude::*;
use vstd::byte_vec::*;
verus! {
fn single(value:u8)->(r:Vec<u8>) ensures r@==seq![value], {
 let mut v=allocate(1);
 let (p,Tracked(mut spare))=acquire(&mut v);
 write(p,value,Tracked(&mut spare));
 let _end=advance(p,1,Tracked(&spare));
 let tracked receipt=seal(spare);
 finish(&mut v,1,Tracked(receipt));
 v
}
}
