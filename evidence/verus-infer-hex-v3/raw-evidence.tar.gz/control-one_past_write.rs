use vstd::prelude::*;use vstd::byte_vec::*;verus!{fn test<'a>(p:*mut u8,Tracked(spare):Tracked<ByteSpare<'a>>)
 requires spare.wf(),spare.contents().len()==spare.capacity(),spare.pointer(p,spare.capacity() as int),
{let tracked mut spare=spare;write(p,7,Tracked(&mut spare));}}