import json,subprocess,hashlib
from pathlib import Path
r=Path('/Users/tommyvolk/Documents/GitHub/verus');n=r.parent/'hex-conservative';o=r/'evidence/verus-infer-hex-v3'
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
prior=['verus-infer-hex-v1','verus-infer-hex-v2','verus-infer-hex-vec-phase3','verus-infer-mechanical-v3','verus-infer-validation-v4']
d=dict(engine_baseline='5b8a980e9',native_baseline=subprocess.check_output(['git','rev-parse','HEAD'],cwd=n,text=True).strip(),toolchains={v:subprocess.check_output(['rustc','+'+v,'--version'],text=True).strip() for v in ['1.99.1','1.74.0']},features=['std+alloc proof','native default/all/no-default/alloc','MSRV default'],preserved_files={str(p.relative_to(r)):h(p) for name in prior for p in (r/'evidence'/name).rglob('*') if p.is_file()})
(o/'baseline.json').write_text(json.dumps(d,indent=2)+'\n')
