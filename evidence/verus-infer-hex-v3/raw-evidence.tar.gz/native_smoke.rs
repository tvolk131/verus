fn digit(b:u8)->Option<u8>{match b{48..=57=>Some(b-48),65..=70=>Some(b-55),97..=102=>Some(b-87),_=>None}}
fn main(){
    use hex_conservative::{decode_to_vec,DecodeVariableLengthBytesError as E};
    for s in ["","aB01fF","0","é","é0","01é","😀","0z11z0","g?","\0f00","a😀b"] {
        let actual=decode_to_vec(s);
        if s.len()%2==1 {match actual{Err(E::OddLengthString(e))=>assert_eq!(e.length(),s.len()),_=>panic!("odd precedence")};continue;}
        if let Some((pos,&b))=s.as_bytes().iter().enumerate().find(|(_,b)|digit(**b).is_none()) {
            match actual {Err(E::InvalidChar(e))=>{assert_eq!(e.pos(),pos);#[allow(deprecated)]{assert_eq!(e.invalid_char(),b);}},_=>panic!("first invalid byte")}
        } else {
            let expected:Vec<u8>=s.as_bytes().chunks_exact(2).map(|p|16*digit(p[0]).unwrap()+digit(p[1]).unwrap()).collect();
            assert_eq!(actual.unwrap(),expected);
        }
    }
}
