import subprocess,json,os
from pathlib import Path
w=Path('/private/tmp/verus-hex-v3');r=Path('/Users/tommyvolk/Documents/GitHub/verus');env=dict(os.environ,VERUS_Z3_PATH=str(r/'source/z3'))
header='use vstd::prelude::*;use vstd::byte_vec::*;verus!{'
cases={
'one_past_write':'''fn test<'a>(p:*mut u8,Tracked(spare):Tracked<ByteSpare<'a>>)
 requires spare.wf(),spare.contents().len()==spare.capacity(),spare.pointer(p,spare.capacity() as int),
{let tracked mut spare=spare;write(p,7,Tracked(&mut spare));}''',
'uninitialized':'fn test(){let mut v=allocate(1);let (_,Tracked(spare))=acquire(&mut v);let tracked r=seal(spare);finish(&mut v,1,Tracked(r));}',
'invalid_length':'fn test(){let mut v=allocate(1);let (p,Tracked(mut s))=acquire(&mut v);write(p,7,Tracked(&mut s));let tracked r=seal(s);finish(&mut v,2,Tracked(r));}',
'duplicated_permission':'fn test(){let mut v=allocate(1);let(p,Tracked(mut s))=acquire(&mut v);let tracked duplicate=s;write(p,7,Tracked(&mut s));}',
'dropped_vector':'fn test(){let(p,Tracked(mut s))={let mut v=allocate(1);acquire(&mut v)};write(p,7,Tracked(&mut s));}',
'reborrow_vector':'fn test(){let mut v=allocate(1);let(p,Tracked(mut s))=acquire(&mut v);v.reserve(2);write(p,7,Tracked(&mut s));}',
'post_transfer':'fn test(){let mut v=allocate(1);let(p,Tracked(mut s))=acquire(&mut v);write(p,7,Tracked(&mut s));let tracked r=seal(s);finish(&mut v,1,Tracked(r));write(p,8,Tracked(&mut s));}',
'stale_receipt':'fn test(){let mut v=allocate(1);let(p,Tracked(mut s))=acquire(&mut v);write(p,7,Tracked(&mut s));let tracked old=seal(s);let(q,Tracked(mut s))=acquire(&mut v);write(q,8,Tracked(&mut s));let tracked current=seal(s);finish(&mut v,1,Tracked(old));}',
'wrong_allocation':'fn test(){let mut a=allocate(1);let mut b=allocate(1);let(p,Tracked(mut s))=acquire(&mut a);let(q,Tracked(mut t))=acquire(&mut b);write(p,7,Tracked(&mut t));}',
'empty':'fn test(){let mut v=allocate(0);let(p,Tracked(s))=acquire(&mut v);let _=advance(p,0,Tracked(&s));let tracked r=seal(s);finish(&mut v,0,Tracked(r));}',
}
receipts=[]
for label,body in cases.items():
 p=w/('control-'+label+'.rs');p.write_text(header+body+'}')
 cmd=[str(r/'source/target-verus/release/verus'),str(p),'--crate-type','lib','--infer-goals','--no-cheating','--output-json']
 with (w/('control-'+label+'.stdout')).open('w') as out,(w/('control-'+label+'.stderr')).open('w') as err:
  run=subprocess.run(cmd,cwd=r,env=env,stdout=out,stderr=err)
 expect=label=='empty';assert (run.returncode==0)==expect,(label,run.returncode)
 errors=(w/('control-'+label+'.stderr')).read_text();assert 'E0463' not in errors and 'ill-formed' not in errors and 'not supported' not in errors,(label,errors);print(label,run.returncode,flush=True)
 receipts.append(dict(label=label,expected_success=expect,exit_code=run.returncode,diagnostic='tracked Rust lifetime/ownership rejection' if 'error[E' in errors else 'ordinary precondition/body checking'))
(w/'lease-controls.json').write_text(json.dumps(receipts,indent=2)+'\n')
