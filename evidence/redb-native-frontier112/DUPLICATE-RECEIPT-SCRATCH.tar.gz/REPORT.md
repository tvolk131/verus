# Receipt112: old-baseline cancellation reproduction, not a new parent repair

## Disposition

Retain as duplicate scratch-only dependency evidence. **Do not integrate this
patch or claim that the current parent cancellation bug was unfixed.** Discovery
at finalization found that receipt107 had already repaired and integrated this
behavior. Its recorded three source hashes match the current parent files.
The existing parent repair and its historical red/green evidence remain intact.

This task incorrectly selected the older107 candidate as its baseline without
first reconciling the current parent repair. The extra work adds a prelaunch
interruption regression on a distinct scratch candidate, not a production fix,
native proof, compiler provenance, or independently reviewed integration.

## Retained tests

- `attempt-01-baseline-red`: the reused reviewer suite reports 13 tests,
  12 passing and one expected cancellation regression failure; suite exit1.
  Real SIGINT records success=true, exit=null, and a still-live child. The
  reviewer fixture cleans up that child; the failing observation is retained.
- `attempt-02-fixed-author`: 41 unit tests pass, suite exit0, on the new scratch
  candidate. Three added tests cover KeyboardInterrupt, SystemExit propagation,
  and prelaunch interruption.
- `attempt-03-fixed-reviewer`: all13 unchanged reviewer checks pass, suite
  exit0. The real-signal observation records failure, a reaped child and
  KeyboardInterrupt rather than success.

The controller itself exits0 even when its suite fails. Only each
`result.json.exit_code` and raw test logs establish the suite outcome. Reviewer
test source was reused; this was **not** a new independent review.

The delta kills/reaps the owned process group, records cancellation before
endpoint observations, requires completed zero exit for success and preserves
the original BaseException. Endpoint log hashing is not protection against
trusted-command replacement by another regular file. `candidate.patch` is
against the old scratch baseline, not against the current parent.

## Scope and accounting

The first source clock was 2026-11-08T06:09:52Z; the self-imposed dependency
handoff cutoff is 06:24:52Z, with 256MiB scratch and free disk strictly >16GiB.
Three direct-Python test applications ran. No compiler/library/Cargo/application
build, verifier/solver/native application execution, network, Git write,
assumption adoption or parent source integration was performed. Source discovery
preceded identity capture; snapshots are sequential, not atomic or first-read
authentication. Existing failures remain retained.

`FINALIZATION.json` records current parent hash reconciliation, raw-suite
outcomes, immutable-input reauthentication and final resource samples.
`MANIFEST.json` and `SEAL.json` are content-integrity inventories only.
All18 redb cells remain OPEN. No warm-cache, native acceptance or trust credit.
