import datetime
import difflib
import hashlib
import json
from pathlib import Path
import re
import shutil
import tarfile
import time


ROOT = Path(__file__).resolve().parent
REPOSITORY = Path('/Users/tommyvolk/.t3/worktrees/verus/t3-60978068')
DESTINATION = REPOSITORY / 'evidence/redb-native-frontier112'
DECISION = Path('/private/tmp/campaign94-native-next-20261108T060655-Yh353x/REPORT.md')
FILENAMES = ['capture_provenance_receipt.py', 'test_capture_provenance_receipt.py',
             'PROVENANCE_RECEIPTS.md']


def identity(filename):
    payload = filename.read_bytes()
    return {'path': str(filename), 'bytes': len(payload),
            'sha256': hashlib.sha256(payload).hexdigest()}


def write_json(filename, value):
    with filename.open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')


def main():
    initial_free = shutil.disk_usage(ROOT).free
    assert initial_free > 16 * 1024 ** 3
    DESTINATION.mkdir()
    report_identity = identity(DECISION)
    prefixes = {
        'E110': REPOSITORY / 'evidence/redb-storage-composition110',
        'E111': REPOSITORY / 'evidence/redb-header-recovery111',
        'N': Path('/private/tmp/verus-crash-consistency94-20261105/native-leaf-lookup-007/recovered-native/redb/src/tree_store/page_store'),
        'R': Path('/private/tmp/verus-crash-consistency94-20261105/native-recovery-reencoding-021'),
        'S': Path('/private/tmp/redb-header-recovery111-20261108T051418Z/shared'),
    }
    authenticated = []
    for line in DECISION.read_text().splitlines():
        matched = re.fullmatch(r'\| (I\d+) \| (.*?) \| (\d+) \| ([0-9a-f]{64}) \|', line)
        if matched is None:
            continue
        identifier, name, size, expected = matched.groups()
        components = name.split('/', 1)
        filename = prefixes[components[0]] / components[1] if components[0] in prefixes else Path(name)
        actual = identity(filename)
        assert actual['sha256'] == expected and actual['bytes'] == int(size), identifier
        authenticated.append({'id': identifier, 'expected_sha256': expected, **actual})
    assert len(authenticated) == 23
    shutil.copyfile(DECISION, DESTINATION / 'DECISION-REPORT.md')
    assert identity(DECISION) == report_identity
    assert (DESTINATION / 'DECISION-REPORT.md').read_bytes() == DECISION.read_bytes()
    write_json(DESTINATION / 'DECISION-AUTHENTICATION.json', {
        'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'report': report_identity, 'inputs': authenticated, 'mismatches': 0,
        'atomic_or_first_read_snapshot': False, 'native_proof': False,
    })
    for filename in ['GOAL.md', 'STATUS.json']:
        source = REPOSITORY / 'evidence/redb-crash-consistency94' / filename
        shutil.copyfile(source, DESTINATION / ('PRE112-' + filename))
    existing_results = REPOSITORY / 'evidence/provenance-receipts107/RESULTS.json'
    parent_bindings = json.loads(existing_results.read_text())['integrated_source_sha256']
    parent_authentication = []
    for name, expected in parent_bindings.items():
        actual = identity(REPOSITORY / name)
        assert actual['sha256'] == expected, name
        parent_authentication.append(actual)
    comparisons = []
    delta = []
    for name in FILENAMES:
        baseline = ROOT / 'baseline/source/tools' / name
        candidate = ROOT / 'reconstructed/source/tools' / name
        parent = REPOSITORY / 'source/tools' / name
        comparisons.append({'baseline': identity(baseline), 'scratch': identity(candidate),
                            'parent': identity(parent),
                            'scratch_equals_parent': candidate.read_bytes() == parent.read_bytes()})
        delta.extend(difflib.unified_diff(baseline.read_text().splitlines(keepends=True),
                                         candidate.read_text().splitlines(keepends=True),
                                         fromfile='a/source/tools/' + name,
                                         tofile='b/source/tools/' + name))
    (ROOT / 'candidate.patch').write_text(''.join(delta))
    attempts = []
    for folder in sorted(ROOT.glob('attempt-*')):
        invocation = json.loads((folder / 'invocation.json').read_text())
        result = json.loads((folder / 'result.json').read_text())
        assert invocation['immutable_before'] == result['immutable_after']
        for recorded in result['immutable_after']:
            assert identity(Path(recorded['path'])) == recorded
        assert result['exit_code'] == (1 if folder.name == 'attempt-01-baseline-red' else 0)
        for channel in ['stdout', 'stderr']:
            assert identity(folder / channel) == result[channel]
        attempts.append({'folder': folder.name, 'exit_code': result['exit_code'],
                         'utc': result['utc'], 'result': identity(folder / 'result.json')})
    assert len(attempts) == 3
    assert time.time() < datetime.datetime(2026, 11, 8, 6, 24, 52, tzinfo=datetime.timezone.utc).timestamp()
    finalization = {
        'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'disposition': 'DUPLICATE_OLD_BASELINE_REPAIR_NOT_INTEGRATED_PARENT_ALREADY_FIXED',
        'existing_parent_results': identity(existing_results),
        'existing_parent_integrated_hashes_match': parent_authentication,
        'comparisons': comparisons, 'attempts': attempts,
        'native_proof': False, 'parent_source_edits': False, 'new_independent_review': False,
        'redb_cells': 'ALL18_OPEN', 'free_bytes': shutil.disk_usage(ROOT).free,
        'first_read_or_atomic_authentication': False,
    }
    write_json(ROOT / 'FINALIZATION.json', finalization)
    payloads = {str(filename.relative_to(ROOT)): identity(filename)
                for filename in sorted(ROOT.rglob('*')) if filename.is_file()}
    total_bytes = sum(record['bytes'] for record in payloads.values())
    assert total_bytes < 256 * 1024 ** 2
    write_json(ROOT / 'MANIFEST.json', {'payloads': payloads, 'payload_bytes': total_bytes,
                                       'scope': 'OLD_BASELINE_SCRATCH_ONLY'})
    write_json(ROOT / 'SEAL.json', {'manifest': identity(ROOT / 'MANIFEST.json'),
                                   'native_acceptance': False})
    archive = DESTINATION / 'DUPLICATE-RECEIPT-SCRATCH.tar.gz'
    with tarfile.open(archive, 'w:gz') as bundle:
        for filename in sorted(ROOT.rglob('*')):
            if filename.is_file():
                bundle.add(filename, arcname=str(filename.relative_to(ROOT)), recursive=False)
    archive_members = 0
    with tarfile.open(archive, 'r:gz') as bundle:
        for member in bundle.getmembers():
            assert member.isfile()
            assert bundle.extractfile(member).read() == (ROOT / member.name).read_bytes()
            archive_members += 1
    for record in parent_authentication:
        assert identity(Path(record['path'])) == record
    for record in authenticated:
        actual = identity(Path(record['path']))
        assert actual['sha256'] == record['sha256'] and actual['bytes'] == record['bytes']
    write_json(DESTINATION / 'RECEIPT-RETENTION.json', {
        'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'scratch_payload_bytes': total_bytes, 'archive': identity(archive),
        'archive_members_byte_compared': archive_members,
        'parent_receipt_hashes_unchanged': parent_authentication,
        'decision_inputs_unchanged': 23, 'free_bytes': shutil.disk_usage(ROOT).free,
        'parent_source_integration': False, 'new_native_proof': False,
        'scope_reversal_authorized': False, 'all18': 'OPEN',
    })
    print(json.dumps({'decision_inputs': len(authenticated), 'archive_members': archive_members,
                      'scratch_payload_bytes': total_bytes, 'archive': str(archive),
                      'all18': 'OPEN'}, sort_keys=True))


if __name__ == '__main__':
    main()
