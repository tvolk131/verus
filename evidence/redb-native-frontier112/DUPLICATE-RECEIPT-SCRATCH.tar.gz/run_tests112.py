import datetime
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys


ROOT = Path(__file__).resolve().parent
PYTHON = Path('/Library/Developer/CommandLineTools/Library/Frameworks/Python3.framework/Versions/3.9/bin/python3.9')
IMMUTABLE = [
    Path('/private/tmp/provenance-receipt107.Puwj4s/candidate/source/tools') / name
    for name in ['capture_provenance_receipt.py', 'test_capture_provenance_receipt.py', 'PROVENANCE_RECEIPTS.md']
] + [Path('/private/tmp/provenance-receipt107-review.NzBvWb/REVIEW.md'),
     Path('/private/tmp/provenance-receipt107-review.NzBvWb/reviewer_tests.py'), PYTHON]


def identity(filename):
    return {'path': str(filename), 'bytes': filename.stat().st_size,
            'sha256': hashlib.sha256(filename.read_bytes()).hexdigest()}


def main():
    label, suite = sys.argv[1:]
    folder = ROOT / label
    folder.mkdir()
    immutable = [identity(filename) for filename in IMMUTABLE]
    candidate = [identity(filename) for filename in sorted((ROOT / 'reconstructed/source/tools').iterdir()) if filename.is_file()]
    if suite == 'reviewer':
        argv = [str(PYTHON), '-I', '-B', str(ROOT / 'reviewer_tests.py')]
    elif suite == 'author':
        argv = [str(PYTHON), '-I', '-B', '-m', 'unittest', 'discover', '-s',
                str(ROOT / 'reconstructed/source/tools'), '-p', 'test_capture_provenance_receipt.py', '-v']
    else:
        raise ValueError(suite)
    invocation = {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  'argv': argv, 'cwd': str(ROOT), 'environment': {'LANG': 'C', 'LC_ALL': 'C', 'TZ': 'UTC'},
                  'immutable_before': immutable, 'candidate_before': candidate,
                  'free_bytes': shutil.disk_usage('/private/tmp').free,
                  'source_discovery_preceded_capture': True,
                  'first_read_or_atomic_snapshot_claim': False,
                  'suite': suite, 'timeout_seconds': 60}
    assert invocation['free_bytes'] > 16 * 1024 ** 3
    (folder / 'invocation.json').write_text(json.dumps(invocation, indent=2, sort_keys=True) + '\n')
    with (folder / 'stdout').open('wb') as stdout, (folder / 'stderr').open('wb') as stderr:
        process = subprocess.run(argv, cwd=ROOT, env=invocation['environment'],
                                 stdout=stdout, stderr=stderr, timeout=60)
    assert immutable == [identity(filename) for filename in IMMUTABLE]
    assert candidate == [identity(filename) for filename in sorted((ROOT / 'reconstructed/source/tools').iterdir()) if filename.is_file()]
    observation = ROOT / 'INTERRUPT-OBSERVATION.json'
    if observation.exists():
        shutil.copyfile(observation, folder / observation.name)
    result = {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'exit_code': process.returncode, 'immutable_after': immutable,
              'candidate_after': candidate, 'stdout': identity(folder / 'stdout'),
              'stderr': identity(folder / 'stderr'), 'native_proof': False,
              'all18': 'OPEN', 'compiler_builds': 0}
    (folder / 'result.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'label': label, 'exit_code': process.returncode,
                      'raw_log': str(folder / 'stderr')}, sort_keys=True))
    print((folder / 'stderr').read_text())


if __name__ == '__main__':
    main()
