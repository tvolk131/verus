"""Reviewer-only trusted-command edge cases; no candidate modifications."""

import copy
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import threading
import unittest
from unittest import mock


ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'reconstructed/source/tools'))
import capture_provenance_receipt as provenance
from test_capture_provenance_receipt import ProvenanceReceiptTests, digest


class ReviewerTests(ProvenanceReceiptTests):
    def retain(self):
        destination = ROOT / 'reviewer-observations' / self._testMethodName
        destination.mkdir(parents=True, exist_ok=True)
        for name in ('receipt.json', 'command.log'):
            source = self.output / name
            if source.is_file() and not source.is_symlink():
                (destination / name).write_bytes(source.read_bytes())

    def run_capture(self, code=None):
        try:
            return super().run_capture(code)
        finally:
            self.retain()

    def test_final_inventory_scan_error_fails_closed(self):
        inventory = provenance.selected_inventory(self.plan['inventory'])
        with mock.patch.object(provenance, 'selected_inventory',
                               side_effect=[inventory, PermissionError('reviewer final scan denied')]):
            receipt = self.run_capture()
        self.assert_refused(receipt, 'input rescan failed', started=True)

    def test_expected_extra_unselected_key_refuses_launch(self):
        self.plan['inventory']['expected_sha256']['outside.rs'] = '0' * 64
        self.assert_refused(self.run_capture(), 'initial selected-input mismatch')

    def test_nonregular_selected_input_refuses_launch(self):
        fifo = self.sources / 'pipe'
        os.mkfifo(fifo)
        self.assert_refused(self.run_capture(), 'not a regular file')

    def test_nonregular_fifo_output_fails_without_blocking(self):
        receipt = self.run_capture(f'import os; os.mkfifo({str(self.artifact)!r})')
        self.assert_refused(receipt, 'not a regular file', started=True)

    def test_symlinked_output_parent_refuses_launch(self):
        alias = self.root / 'alias'
        alias.symlink_to(self.sources, target_is_directory=True)
        self.plan['outputs'] = [str(alias / 'artifact.bin')]
        self.assert_refused(self.run_capture(), 'output parent is not canonical')

    def test_symlinked_cwd_refuses_launch(self):
        alias = self.root / 'alias'
        alias.symlink_to(self.sources, target_is_directory=True)
        self.plan['cwd'] = str(alias)
        self.assert_refused(self.run_capture(), 'cwd must be a canonical directory')

    def test_executable_drift_refuses_success(self):
        executable = self.root / 'harmless-python-fixture'
        executable.write_text(f'#!{self.executable}\nfrom pathlib import Path\n'
                              f'Path({str(self.artifact)!r}).write_bytes(b"fake artifact")\n'
                              f'Path({str(executable)!r}).write_text("changed fixture")\n')
        executable.chmod(0o700)
        self.plan['argv'] = [str(executable)]
        self.plan['executable_sha256'] = digest(executable)
        self.assert_refused(self.run_capture(), 'executable identity drift', started=True)

    def test_caller_declared_direct_compiler_identity_is_only_a_label(self):
        self.plan['compiler'] = {'path': str(self.executable), 'sha256': digest(self.executable)}
        receipt = self.run_capture()
        self.assertTrue(receipt['success'], receipt['errors'])
        self.assertTrue(receipt['compiler_directly_named_as_executable'])
        self.assertFalse(receipt['establishes']['binary_source_correspondence'])

    def test_fixed_child_environment_excludes_multiple_inherited_canaries(self):
        code = self.plan['argv'][-1] + '; import os; assert not any(name in os.environ for name in '
        code += "('HOME', 'PATH', 'RUSTFLAGS', 'REVIEWER_TOKEN'))"
        with mock.patch.dict(os.environ, {name: 'synthetic-canary' for name in
                                          ('HOME', 'PATH', 'RUSTFLAGS', 'REVIEWER_TOKEN')}):
            receipt = self.run_capture(code)
        self.assertTrue(receipt['success'], receipt['errors'])
        self.assertEqual(receipt['environment'], {'LANG': 'C', 'LC_ALL': 'C', 'TZ': 'UTC'})
        self.assertNotIn('synthetic-canary', json.dumps(receipt))

    def test_more_malformed_types_refuse_before_evidence(self):
        mutations = [lambda plan: plan.update(timeout_seconds=-1),
                     lambda plan: plan.update(timeout_seconds='5'),
                     lambda plan: plan.update(outputs=True),
                     lambda plan: plan.update(compiler=[]),
                     lambda plan: plan.update(inventory=[]),
                     lambda plan: plan.update(executable_sha256=True),
                     lambda plan: plan.update(cwd=True),
                     lambda plan: plan['inventory'].update(files=True),
                     lambda plan: plan['inventory'].update(trees=['inputs/../inputs']),
                     lambda plan: plan['inventory'].update(expected_sha256={'inputs/engine.rs': True})]
        for mutation in mutations:
            plan = copy.deepcopy(self.plan)
            mutation(plan)
            with self.subTest(plan=plan):
                with self.assertRaises(ValueError):
                    provenance.capture(plan, self.output)
                self.assertFalse(self.output.exists())

    def test_vstd_flag_precedence_over_all_recognized_package_forms(self):
        for selector in (['-p', 'rust_verify'], ['--package', 'rust_verify'],
                         ['--package=rust_verify']):
            self.assertEqual(provenance.invocation_kind(['/fake/cargo', 'build', *selector, '--is-vstd']),
                             'vstd-only-command-shape')

    def test_regular_log_replacement_is_endpoint_observation_not_authentication(self):
        log = self.output / 'command.log'
        code = self.plan['argv'][-1] + "; print('original harmless output', flush=True)"
        code += f'; Path({str(log)!r}).unlink(); Path({str(log)!r}).write_text("replacement log")'
        receipt = self.run_capture(code)
        self.assertTrue(receipt['success'], receipt['errors'])
        self.assertEqual(log.read_text(), 'replacement log')
        self.assertEqual(receipt['command']['log']['sha256'],
                         hashlib.sha256(b'replacement log').hexdigest())

    def test_keyboard_interrupt_must_not_seal_success_or_leave_child_running(self):
        original_popen = subprocess.Popen
        processes = []

        def tracked_popen(*arguments, **keywords):
            process = original_popen(*arguments, **keywords)
            processes.append(process)
            return process

        timer = threading.Timer(0.4, lambda: os.kill(os.getpid(), signal.SIGINT))
        timer.daemon = True
        self.plan['argv'][-1] += '; import time; time.sleep(10)'
        timer.start()
        try:
            with mock.patch.object(provenance.subprocess, 'Popen', side_effect=tracked_popen):
                with self.assertRaises(KeyboardInterrupt):
                    self.run_capture()
            receipt = json.loads((self.output / 'receipt.json').read_text())
            observation = {'receipt_success': receipt['success'],
                           'exit_code': receipt['command']['exit_code'],
                           'timed_out': receipt['command']['timed_out'],
                           'errors': receipt['errors'],
                           'child_alive_after_capture': processes[0].poll() is None}
            (ROOT / 'INTERRUPT-OBSERVATION.json').write_text(json.dumps(observation, indent=2) + '\n')
            self.assertFalse(receipt['success'], observation)
            self.assertIsNotNone(processes[0].poll(), observation)
        finally:
            timer.cancel()
            timer.join(timeout=2)
            for process in processes:
                if process.poll() is None:
                    os.killpg(process.pid, signal.SIGKILL)
                process.wait(timeout=2)


if __name__ == '__main__':
    names = sorted(name for name in ReviewerTests.__dict__ if name.startswith('test_'))
    suite = unittest.TestSuite(ReviewerTests(name) for name in names)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    raise SystemExit(not result.wasSuccessful())
