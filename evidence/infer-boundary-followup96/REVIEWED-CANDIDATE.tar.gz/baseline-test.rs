use super::*;
use crate::config::ArgsX;
use std::path::Path;
use std::process::Command;
use vir::ast::*;
use vir::ast_util::unit_typ;
use vir::def::Spanned;

const MARKER: &str = "experimental-native-resource-ir:v1:boundary-test";
const MODES: [&str; 8] = [
    "ordinary",
    "no-verify",
    "no-lifetime",
    "verify-root",
    "verify-function",
    "verify-module",
    "verify-only-module",
    "build-sst",
];

fn fixture(marked: bool, private: bool, bodyless: bool) -> Krate {
    let span = vir::messages::Span {
        raw_span: Arc::new(()),
        id: 0,
        data: vec![],
        as_string: "serialized resource boundary fixture".into(),
    };
    let path = Arc::new(PathX {
        krate: CrateId::Id(Arc::new("boundary_fixture".into()), 1),
        segments: Arc::new(vec![]),
    });
    let ret = Spanned::new(
        span.clone(),
        ParamX {
            name: VarIdent(Arc::new("result".into()), VarIdentDisambiguate::RustcId(0)),
            typ: unit_typ(),
            mode: Mode::Exec,
            user_mut: false,
            unwrapped_info: None,
        },
    );
    let function = Spanned::new(
        span.clone(),
        FunctionX {
            name: Arc::new(FunX {
                path: Arc::new(PathX {
                    krate: path.krate.clone(),
                    segments: Arc::new(vec![Arc::new("resource_fixture".into())]),
                }),
            }),
            proxy: None,
            kind: FunctionKind::Static,
            visibility: Visibility { restricted_to: private.then(|| path.clone()) },
            body_visibility: BodyVisibility::Uninterpreted,
            opaqueness: Opaqueness::Opaque,
            owning_module: Some(path.clone()),
            mode: Mode::Exec,
            typ_params: Arc::new(vec![]),
            typ_bounds: Arc::new(vec![]),
            params: Arc::new(vec![]),
            outer_ret: ret.clone(),
            inner_ret: ret,
            require: Arc::new(vec![]),
            ensure: (Arc::new(vec![]), Arc::new(vec![])),
            returns: None,
            decrease: Arc::new(vec![]),
            decrease_when: None,
            decrease_by: None,
            fndef_axioms: None,
            mask_spec: None,
            atomic_update: None,
            unwind_spec: None,
            item_kind: ItemKind::Function,
            attrs: Arc::new(FunctionAttrsX {
                infer_candidate_id: marked.then(|| MARKER.into()),
                ..FunctionAttrsX::default()
            }),
            body: (!bodyless).then(|| {
                SpannedTyped::new(&span, &unit_typ(), ExprX::Block(Arc::new(vec![]), None))
            }),
            return_opaque_type_eqs: Arc::new(vec![]),
            extra_dependencies: vec![],
            hidden: Arc::new(vec![]),
        },
    );
    Arc::new(KrateX {
        functions: vec![function],
        reveal_groups: vec![],
        datatypes: vec![],
        traits: vec![],
        trait_impls: vec![],
        assoc_type_impls: vec![],
        modules: vec![Spanned::new(span, ModuleX { path, reveals: None })],
        external_fns: vec![],
        external_types: vec![],
        path_as_rust_names: vec![],
        opaque_types: vec![],
        arch: Arch { word_bits: ArchWordBits::Exactly(64) },
    })
}

fn metadata() -> CrateMetadata {
    CrateMetadata { crate_id: 1, original_files: HashMap::new(), inference_aware: false }
}

fn args(mode: &str) -> ArgsX {
    let mut args = ArgsX::new();
    match mode {
        "ordinary" => {}
        "no-verify" => args.no_verify = true,
        "no-lifetime" => args.no_lifetime = true,
        "verify-root" => args.verify_root = true,
        "verify-function" => {
            args.verify_function = Some("body".into());
            args.verify_only_module = vec!["selected".into()];
        }
        "verify-module" => args.verify_module = vec!["selected".into()],
        "verify-only-module" => args.verify_only_module = vec!["selected".into()],
        "build-sst" => {
            args.no_verify = true;
            args.build_sst = true;
        }
        _ => panic!("unknown boundary test mode"),
    }
    args
}

fn import_args(path: &Path, via_cargo: bool, mode: &str) -> (Args, Vec<(String, String)>) {
    let mut args = args(mode);
    let import = ("boundary_fixture".into(), path.to_str().unwrap().into());
    let cargo = if via_cargo {
        vec![import]
    } else {
        args.import.push(import);
        vec![]
    };
    (Arc::new(args), cargo)
}

fn assert_import_rejected(args: &Args, cargo: Vec<(String, String)>) {
    let error = match import_crates(args, cargo) {
        Ok(_) => panic!("marked resource artifact was imported"),
        Err(error) => error,
    };
    assert!(error.note.contains("experimental native-resource IR: import is unavailable"));
    assert!(error.spans.is_empty(), "import driver requires span-free errors");
}

#[test]
fn ordinary_exports_roundtrip_through_explicit_and_cargo_imports() {
    let directory = tempfile::tempdir().unwrap();
    for via_cargo in [false, true] {
        let path = directory.path().join(format!("ordinary-{via_cargo}.vir"));
        let mut args = ArgsX::new();
        if !via_cargo {
            args.export = Some(path.to_str().unwrap().into());
        }
        export_crate(
            &Arc::new(args),
            &via_cargo.then(|| path.clone()),
            metadata(),
            fixture(false, false, false),
            None,
        )
        .unwrap();
        for mode in MODES {
            let (args, cargo) = import_args(&path, via_cargo, mode);
            let imported = import_crates(&args, cargo).unwrap();
            assert_eq!(imported.vir_crates.len(), 1);
            assert_eq!(imported.vir_crates[0].functions.len(), 1);
            assert!(imported.vir_crates[0].functions[0].x.body.is_none());
            assert!(imported.inference_dependencies.is_empty());
        }
    }
}

#[test]
fn serialized_markers_are_rejected_before_import_filters_and_metadata() {
    let directory = tempfile::tempdir().unwrap();
    for private in [false, true] {
        for bodyless in [false, true] {
            let path = directory.path().join(format!("marked-{private}-{bodyless}.vir"));
            atomic_export(
                &path,
                &CrateWithMetadata {
                    krate: fixture(true, private, bodyless),
                    metadata: metadata(),
                },
                None,
            )
            .unwrap();
            std::fs::OpenOptions::new()
                .append(true)
                .open(&path)
                .unwrap()
                .write_all(b"not valid inference metadata")
                .unwrap();
            for via_cargo in [false, true] {
                for mode in MODES {
                    let (args, cargo) = import_args(&path, via_cargo, mode);
                    assert_import_rejected(&args, cargo);
                }
            }
        }
    }
}

#[test]
fn marked_exports_are_rejected_before_private_pruning_and_verified_metadata() {
    let directory = tempfile::tempdir().unwrap();
    let proofs = vir::infer_proof::Proofs::default();
    for private in [false, true] {
        for bodyless in [false, true] {
            for via_cargo in [false, true] {
                for verified in [false, true] {
                    let path = directory.path().join("refused.vir");
                    let mut args = ArgsX::new();
                    if !via_cargo {
                        args.export = Some(path.to_str().unwrap().into());
                    }
                    let error = export_crate(
                        &Arc::new(args),
                        &via_cargo.then(|| path.clone()),
                        metadata(),
                        fixture(true, private, bodyless),
                        verified.then_some((&[], &proofs, &[])),
                    )
                    .unwrap_err();
                    assert!(
                        error
                            .note
                            .contains("experimental native-resource IR: export is unavailable")
                    );
                    assert!(!path.exists());
                    assert_eq!(std::fs::read_dir(directory.path()).unwrap().count(), 0);
                }
            }
        }
    }
}

#[test]
fn stale_export_invalidation_covers_direct_and_cargo_paths() {
    let directory = tempfile::tempdir().unwrap();
    for via_cargo in [false, true] {
        let path = directory.path().join("stale.vir");
        std::fs::write(&path, b"stale certified interface").unwrap();
        let mut args = ArgsX::new();
        if !via_cargo {
            args.export = Some(path.to_str().unwrap().into());
        }
        let args = Arc::new(args);
        let cargo = via_cargo.then(|| path.clone());
        invalidate_export(&args, &cargo).unwrap();
        assert!(!path.exists());
        assert!(export_crate(&args, &cargo, metadata(), fixture(true, true, true), None).is_err());
        assert!(!path.exists());
    }
}

#[test]
#[ignore = "requires matching VERUS_NATIVE_RESOURCE_TEST_DRIVER and VERUS_NATIVE_RESOURCE_TEST_BUILTIN"]
fn actual_driver_rejects_marked_imports_without_panicking_or_leaving_stale_exports() {
    let driver = std::env::var_os("VERUS_NATIVE_RESOURCE_TEST_DRIVER")
        .expect("set VERUS_NATIVE_RESOURCE_TEST_DRIVER to the matching rust_verify binary");
    let builtin = std::env::var_os("VERUS_NATIVE_RESOURCE_TEST_BUILTIN")
        .expect("set VERUS_NATIVE_RESOURCE_TEST_BUILTIN to the matching verus_builtin library");
    let directory = tempfile::tempdir().unwrap();
    let source = directory.path().join("consumer.rs");
    std::fs::write(&source, "extern crate verus_builtin; pub mod selected { pub fn body() {} }\n")
        .unwrap();
    let imported = directory.path().join("dependency.vir");
    let exported = directory.path().join("consumer.vir");
    for marked in [false, true] {
        let krate = if marked {
            fixture(true, true, true)
        } else {
            let mut krate = (*fixture(false, false, true)).clone();
            krate.functions.clear();
            krate.modules.clear();
            Arc::new(krate)
        };
        atomic_export(&imported, &CrateWithMetadata { krate, metadata: metadata() }, None).unwrap();
        for mode in if marked { MODES.as_slice() } else { &["no-verify"] } {
            std::fs::write(&exported, b"stale certified interface").unwrap();
            let mut command = Command::new(&driver);
            command
                .current_dir(directory.path())
                .arg("--internal-test-mode")
                .arg(&source)
                .args(["--crate-type=lib", "--no-vstd", "--output-json"])
                .args(["--extern", &format!("verus_builtin={}", Path::new(&builtin).display())])
                .args(["--import", &format!("boundary_fixture={}", imported.display())])
                .arg("--export")
                .arg(&exported);
            match *mode {
                "ordinary" => {}
                "no-verify" => {
                    command.arg("--no-verify");
                }
                "no-lifetime" => {
                    command.arg("--no-lifetime");
                }
                "verify-root" => {
                    command.arg("--verify-root");
                }
                "verify-function" => {
                    command.args(["--verify-only-module", "selected", "--verify-function", "body"]);
                }
                "verify-module" => {
                    command.args(["--verify-module", "selected"]);
                }
                "verify-only-module" => {
                    command.args(["--verify-only-module", "selected"]);
                }
                "build-sst" => {
                    command.args(["--no-verify", "--build-sst"]);
                }
                _ => panic!("unknown driver test mode"),
            }
            println!("driver marked={marked} mode={mode}: {command:?}");
            let output = command.output().unwrap();
            let stdout = String::from_utf8_lossy(&output.stdout);
            let stderr = String::from_utf8_lossy(&output.stderr);
            println!("status={}\nstdout:\n{stdout}\nstderr:\n{stderr}", output.status);
            assert!(!stderr.contains("panicked at"));
            assert!(!stdout.contains("panicked at"));
            if marked {
                assert_eq!(output.status.code(), Some(1));
                assert!(stderr.contains("experimental native-resource IR: import is unavailable"));
                assert!(!exported.exists());
            } else {
                assert!(output.status.success());
                assert!(exported.exists());
            }
        }
    }
}
