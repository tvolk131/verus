# Infer integration status — November 7, 2026

This is a working integration map, not an acceptance certificate. Consolidation
started at HEAD `b32846b61dcf724618f7345e219e5007a0c79643` with substantial inherited,
uncommitted implementation, tests and evidence. This summary does not imply that
those changes are committed, merged, reproduced on hosted CI or accepted as a whole.

## Capabilities and limits

- Infer supports documented bounded scalar, collection and record profiles,
  checked cross-crate composition and selected proof assistance. Exact inference
  checks soundness, safe-domain maximality and output exactness; authors still
  choose application intent, domains and abstractions. See the
  [adoption guide](source/docs/guide/src/infer_adoption.md).
- Aleph and hex have separate finite native milestones. Pinned redb and Fedimint
  transfers retain selected original functions or disclosed contiguous blocks.
  Their individual scope/source/trust ledgers determine the claims, not helper
  counts. The [common frontdoor](source/tools/INFER_TRANSFERS.md) has six scenarios;
  later standalone pilots are not silently additional hosted-CI acceptance.
- The default-OFF [resource experiment](source/vir/NATIVE_RESOURCE_IR.md) checks
  hypothetical capability transport through VIR/SST/AIR. It proves neither
  original Rust ownership correspondence nor an exportable native resource
  theorem. Its recorded 204 feature-enabled VIR tests are compiler regressions,
  not application proof coverage.
- All eighteen final [redb property/history cells](evidence/redb-crash-consistency94/GOAL.md)
  remain OPEN. Bounded recovery, encoding and helper proofs do not close native
  ownership, I/O, persistence, errors or logical key/value refinement.

## Current hardening

The newly authorized [consolidation ledger](evidence/infer-consolidation95/README.md)
separates this work from exhausted historical cycles. No refused task is
restarted, primitive axiom installed or certification policy activated.

New regressions exercise actual bincode artifact import/export, private/bodyless
markers, and the actual compiler's marked-import rejection under ordinary,
filtered, no-verify, no-lifetime and build-SST options. The driver checks require
an intended diagnostic rather than a panic and removal of a seeded stale direct
export. The ordinary-import positive control is plumbing evidence, not a native
application proof. These tests do not inject a marked local Rust body, test every
Cargo driver path, or establish universal internal-VIR exclusion.

Reproduce both feature profiles with a new output directory:

```sh
python3 -B source/tools/check_native_resource_boundaries.py \
  --output /private/tmp/new-native-resource-boundary-replay
```

The runner builds a matching driver and builtin library offline with a locked
dependency graph, then runs the named tests including the normally ignored
driver test. It uses a private build directory, two Cargo jobs, raw logs and
selected-input hashes; another command is refused below 16 GiB free. Dependencies
and the pinned Rust components must already be installed. The receipt is not
complete compiler/runtime provenance or an application proof certificate. This
matrix is not yet a hosted-CI acceptance gate.

Two fresh-target replays each passed all five boundary tests in both profiles,
including the actual driver matrix. The broader Python tooling suite ran
622 tests: 621 passed and one was skipped, after replacing a vanished-checkout unit dependency
with a clearly synthetic extraction fixture. Production Fedimint source guards
remain strict. Fresh [independent implementation review](evidence/infer-consolidation95/INDEPENDENT-REVIEW.md)
gives qualified support with no blocking defect in the narrow patch; it does not
accept the inherited dirty tree wholesale. The sealed reviewed inputs and raw
logs are retained with the consolidation ledger.

A later [test-only boundary follow-up](evidence/infer-boundary-followup96/README.md)
strengthens matched driver positives, leading ordinary siblings and real
malformed-metadata precedence controls. All five tests pass in both feature
profiles; fresh independent review is pending. The original hardening95 review
does not cover this later test-only delta.

## Next gates

1. Retain the reviewed narrow patch and its failed runs, remaining
   local/lowerer/Cargo-driver gaps and historical reports. Strengthen those seams
   when an application-led need justifies another bounded implementation slice.
2. Use parallel Fedimint/hex assessments to select source-connected goals, freeze
   a current-engine baseline and remove one reusable blocker with matched
   semantic negatives. Do not shrink requested input coverage to obtain success.
   The [frozen-runtime hex encoding experiment](evidence/hex-canonical-encoding95/README.md)
   stopped at an opaque-Table visibility error before any body proof. The user
   subsequently authorized iterative visibility-respecting specification repair,
   now delegated as a separate cycle without assuming a table equation or
   changing executable privacy. The original failure remains unchanged.
   Fedimint clean-source recovery remains a separate prerequisite.
3. For redb, target actual native correspondence/caller premises, not merely more
   abstract helpers. New primitive-law adoption, certification-policy activation
   and changes to the final proof scope require separate explicit decisions.
   The newly provider-blocked padding-boundary task is stopped without retry or
   rerouting; no usable result or new proof credit is claimed.

No permission grant, model theorem, generated obligation or test count closes a
final database cell without the required proof and review evidence.
