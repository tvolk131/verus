pub use air::messages::MessageLevel;
use air::messages::{ArcDynMessage, ArcDynMessageLabel};
use serde::{Deserialize, Serialize};
use std::{any::Any, sync::Arc};
use vir_macros::ToDebugSNode;

fn empty_raw_span() -> RawSpan {
    Arc::new(())
}

pub type RawSpan =
    Arc<dyn std::any::Any + std::marker::Sync + std::marker::Send + std::panic::RefUnwindSafe>;
pub type AstId = u64;
#[derive(Clone, Serialize, Deserialize)] // for Debug, see ast_util
pub struct Span {
    #[serde(skip)]
    #[serde(default = "crate::messages::empty_raw_span")]
    pub raw_span: RawSpan,
    pub id: AstId, // arbitrary integer identifier that may be set and used in any way (e.g. as unique id, or just left as 0)
    pub data: Vec<u64>, // arbitrary integers (e.g. for serialization/deserialization)
    pub as_string: String, // if we can't print (description, raw_span), print as_string instead
}

impl std::fmt::Debug for Span {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("Span")
            .field("raw_span", &"ANY")
            .field("id", &self.id)
            .field("data", &self.data)
            .field("as_string", &self.as_string)
            .finish()
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum WarningAllow {
    UndeclaredExternalTrait,
    AssertForallImplication,
    DecreasesWhenExecAllowsNoDecreasesClause,
    BroadcastWithoutTrigger,
    TriggerOnSpecFn,
    DeadReveal,
    AssertComputeUnsimplified,
    OldStyleAcceptRejectRecursiveTypes,
    UnknownAutomaticDerive,
    AutoderiveCloneWithoutSpec,
    NonExecGhostTrackedWrappers,
}

impl WarningAllow {
    pub fn to_str(&self) -> &'static str {
        match self {
            WarningAllow::UndeclaredExternalTrait => "undeclared_external_trait",
            WarningAllow::AssertForallImplication => "assert_forall_implication",
            WarningAllow::DecreasesWhenExecAllowsNoDecreasesClause => {
                "decreases_when_exec_allows_no_decreases_clause"
            }
            WarningAllow::BroadcastWithoutTrigger => "broadcast_without_trigger",
            WarningAllow::TriggerOnSpecFn => "trigger_on_spec_fn",
            WarningAllow::DeadReveal => "dead_reveal",
            WarningAllow::AssertComputeUnsimplified => "assert_compute_unsimplified",
            WarningAllow::OldStyleAcceptRejectRecursiveTypes => {
                "old_style_accept_reject_recursive_types"
            }
            WarningAllow::UnknownAutomaticDerive => "unknown_automatic_derive",
            WarningAllow::AutoderiveCloneWithoutSpec => "autoderive_clone_without_spec",
            WarningAllow::NonExecGhostTrackedWrappers => "non_exec_ghost_tracked_wrappers",
        }
    }

    pub fn from_str(s: &str) -> Option<WarningAllow> {
        match s {
            "undeclared_external_trait" => Some(WarningAllow::UndeclaredExternalTrait),
            "assert_forall_implication" => Some(WarningAllow::AssertForallImplication),
            "decreases_when_exec_allows_no_decreases_clause" => {
                Some(WarningAllow::DecreasesWhenExecAllowsNoDecreasesClause)
            }
            "broadcast_without_trigger" => Some(WarningAllow::BroadcastWithoutTrigger),
            "trigger_on_spec_fn" => Some(WarningAllow::TriggerOnSpecFn),
            "dead_reveal" => Some(WarningAllow::DeadReveal),
            "assert_compute_unsimplified" => Some(WarningAllow::AssertComputeUnsimplified),
            "old_style_accept_reject_recursive_types" => {
                Some(WarningAllow::OldStyleAcceptRejectRecursiveTypes)
            }
            "unknown_automatic_derive" => Some(WarningAllow::UnknownAutomaticDerive),
            "autoderive_clone_without_spec" => Some(WarningAllow::AutoderiveCloneWithoutSpec),
            "non_exec_ghost_tracked_wrappers" => Some(WarningAllow::NonExecGhostTrackedWrappers),
            _ => None,
        }
    }
}

pub trait CheckAllowForWarning {
    fn allowed(&self, allow: &WarningAllow) -> bool;
}

#[derive(Debug, Serialize, Deserialize, Clone, ToDebugSNode)]
pub struct MessageLabel {
    pub span: Span,
    pub note: String,
    pub is_proof_note: bool,
    pub is_custom_err: bool,
}

/// If you just want to build a simple message, see the builders below.
///
/// Our Message type is designed to resemble Rust's MultiSpan,
/// with an additional 'note' String to provide a top-level description.
/// A Message should typically have at least one 'span' which represents
/// the primary point described. It is possible to have more
/// than one span, and it is possible to have additional label information.
///
/// Here's an example message:
///
/// error: precondition not satisfied                 // note (String)
///   --> filename.rs:18:5
///    |
/// 14 |     requires(b);
///    |              - failed precondition           // label (Span, String)
/// ...
/// 18 |     has_expectations(false);
///    |     ^^^^^^^^^^^^^^^^^^^^^^^                  // primary span (Span)
///
/// Note that if you want to get a message that is rendered with ^^^^ AND has a label
/// it needs to BOTH be in the primary spans list AND in the labels.

#[derive(Debug, Clone, Serialize, Deserialize, ToDebugSNode)] // for Debug, see ast_util
pub struct MessageX {
    pub level: MessageLevel,
    pub note: String,
    pub spans: Vec<Span>,          // "primary" spans
    pub labels: Vec<MessageLabel>, // additional spans, with string annotations
    pub help: Vec<String>,
    pub fancy_note: Option<String>, // allows terminal-colored output
}

pub type Message = Arc<MessageX>;

pub trait ToAny {
    fn to_any(self) -> Arc<dyn Any + Send + Sync>;
}

impl ToAny for Message {
    fn to_any(self) -> Arc<dyn Any + Send + Sync> {
        self
    }
}

impl ToAny for MessageLabel {
    fn to_any(self) -> Arc<dyn Any + Send + Sync> {
        Arc::new(self)
    }
}

pub struct VirMessageInterface {}

impl air::messages::MessageInterface for VirMessageInterface {
    fn empty(&self) -> ArcDynMessage {
        Arc::new(MessageX {
            level: MessageLevel::Error,
            note: "".to_owned(),
            spans: Vec::new(),
            labels: Vec::new(),
            help: Vec::new(),
            fancy_note: None,
        })
    }

    fn all_msgs(&self, message: &ArcDynMessage) -> Vec<String> {
        let message: &MessageX =
            message.downcast_ref().expect("unexpected value in Any -> Message conversion");
        Some(message.note.clone())
            .into_iter()
            .chain(message.labels.iter().map(|l| l.note.clone()))
            .collect()
    }

    fn bare(&self, level: MessageLevel, note: &str) -> ArcDynMessage {
        Arc::new(MessageX {
            level,
            note: note.to_owned(),
            spans: Vec::new(),
            labels: Vec::new(),
            help: Vec::new(),
            fancy_note: None,
        })
    }

    fn unexpected_solver_version(
        &self,
        solver: &str,
        expected: &str,
        found: &str,
    ) -> ArcDynMessage {
        Arc::new(MessageX {
            level: MessageLevel::Error,
            note: format!("expected {solver} version {expected}, found {found}"),
            labels: Vec::new(),
            spans: Vec::new(),
            help: Vec::new(),
            fancy_note: None,
        })
    }

    fn get_note<'b>(&self, message: &'b ArcDynMessage) -> &'b str {
        let message: &MessageX =
            message.downcast_ref().expect("unexpected value in Any -> Message conversion");
        &message.note
    }

    fn get_message_label_note<'b>(&self, message_label: &'b ArcDynMessageLabel) -> &'b str {
        let message_label: &MessageLabel =
            message_label.downcast_ref().expect("unexpected value in Any -> Message conversion");
        &message_label.note
    }

    fn append_labels(
        &self,
        message: &ArcDynMessage,
        labels: &Vec<ArcDynMessageLabel>,
    ) -> ArcDynMessage {
        let message: &MessageX =
            message.downcast_ref().expect("unexpected value in Any -> Message conversion");
        let mut s = message.clone();
        s.labels.extend(
            labels
                .iter()
                .map(|l| l.downcast_ref().expect("unexpected value in Any -> Message conversion"))
                .cloned(),
        );
        Arc::new(s)
    }

    fn message_label_from_air_span(&self, air_span: &str, note: &str) -> ArcDynMessageLabel {
        Arc::new(MessageLabel {
            span: Span {
                raw_span: Arc::new(()),
                id: 0,
                data: Vec::new(),
                as_string: air_span.to_owned(),
            },
            note: note.to_owned(),
            is_proof_note: false,
            is_custom_err: false,
        })
    }

    fn from_labels(&self, labels: &Vec<ArcDynMessageLabel>) -> ArcDynMessage {
        if labels.len() == 0 {
            self.empty()
        } else {
            let MessageLabel { span, note, .. } =
                labels[0].downcast_ref::<MessageLabel>().unwrap().clone();
            Arc::new(MessageX {
                level: MessageLevel::Error,
                note,
                spans: vec![span],
                labels: labels[1..]
                    .iter()
                    .map(|l| {
                        l.downcast_ref().expect("unexpected value in Any -> Message conversion")
                    })
                    .cloned()
                    .collect(),
                help: Vec::new(),
                fancy_note: None,
            })
        }
    }
}

// Basic Message constructors

/// Basic message, with a note and a single span to be highlighted with ^^^^^^
pub fn message<S: Into<String>>(level: MessageLevel, note: S, span: &Span) -> Message {
    Arc::new(MessageX {
        level,
        note: note.into(),
        spans: vec![span.clone()],
        labels: Vec::new(),
        help: Vec::new(),
        fancy_note: None,
    })
}

/// Bare message without any span
pub fn message_bare<S: Into<String>>(level: MessageLevel, note: S) -> Message {
    Arc::new(MessageX {
        level,
        note: note.into(),
        spans: vec![],
        labels: Vec::new(),
        help: Vec::new(),
        fancy_note: None,
    })
}

/// Message with a span to be highlighted with ^^^^^^, and a label for that span
pub fn message_with_label<S: Into<String>, T: Into<String>>(
    level: MessageLevel,
    note: S,
    span: &Span,
    label: T,
) -> Message {
    Arc::new(MessageX {
        level,
        note: note.into(),
        spans: vec![span.clone()],
        labels: vec![MessageLabel {
            span: span.clone(),
            note: label.into(),
            is_proof_note: false,
            is_custom_err: false,
        }],
        help: Vec::new(),
        fancy_note: None,
    })
}

pub fn message_with_secondary_label<S: Into<String>, T: Into<String>>(
    level: MessageLevel,
    note: S,
    span: &Span,
    label: T,
) -> Message {
    Arc::new(MessageX {
        level,
        note: note.into(),
        spans: vec![],
        labels: vec![MessageLabel {
            span: span.clone(),
            note: label.into(),
            is_proof_note: false,
            is_custom_err: false,
        }],
        help: Vec::new(),
        fancy_note: None,
    })
}

/// Multiple basic message, each with a note and a single span to be highlighted with ^^^^^^
pub fn multiple_message<'a, S: Into<String>>(
    level: MessageLevel,
    note: S,
    spans: impl Iterator<Item = &'a Span>,
) -> Message {
    Arc::new(MessageX {
        level,
        note: note.into(),
        spans: spans.cloned().collect(),
        labels: Vec::new(),
        help: Vec::new(),
        fancy_note: None,
    })
}

// Convenience functions

/// Bare note without any spans
pub fn note_bare<S: Into<String>>(note: S) -> Message {
    message_bare(MessageLevel::Note, note)
}

/// Basic note, with a message and a single span to be highlighted with ^^^^^^
pub fn note<S: Into<String>>(span: &Span, note: S) -> Message {
    message(MessageLevel::Note, note, span)
}

/// Bare warning without any spans
pub fn warning_bare<S: Into<String>>(note: S) -> Message {
    message_bare(MessageLevel::Warning, note)
}

/// Basic warning, with a message and a single span to be highlighted with ^^^^^^
pub fn warning<S: Into<String>>(span: &Span, note: S) -> Message {
    message(MessageLevel::Warning, note, span)
}

/// Basic warning, possibly suppressed by verifier::allow
pub fn warning_maybe<S: Into<String>>(
    check_allow: &(impl CheckAllowForWarning + ?Sized),
    span: &Span,
    allow: &WarningAllow,
    note: impl FnOnce() -> S,
    emit: impl FnOnce(Message) -> (),
) {
    if !check_allow.allowed(allow) {
        let s = allow.to_str();
        let msg = warning(span, note());
        let msg = msg.help(
            format!(
                "to suppress this warning, use `#[verifier::allow({s})]` on the surrounding function, datatype, or module or `#![verifier::allow({s})]` in the module or crate"
            ));
        emit(msg);
    }
}

/// Basic warning, possibly suppressed by verifier::allow,
/// and possibly also suppressed by check_allow = None (which means a check for another crate's item)
/// REVIEW: at some point, we should probably just stop checking imported items
pub fn warning_maybe_if_in_local_crate<S: Into<String>>(
    check_allow: &Option<crate::context::WarningConfig>,
    span: &Span,
    allow: &WarningAllow,
    note: impl FnOnce() -> S,
    emit: impl FnOnce(Message) -> (),
) {
    if let Some(check_allow) = check_allow {
        // The item being checked is local to our crate, so continue with warning:
        warning_maybe(check_allow, span, allow, note, emit);
    }
    // Otherwise, don't warn (it's an item from another crate,
    // and the warning was already displayed when that crate was checked)
}

/// Bare error without any spans; use the builders below to add spans and labels
pub fn error_bare<S: Into<String>>(note: S) -> Message {
    message_bare(MessageLevel::Error, note)
}

/// Basic error, with a message and a single span to be highlighted with ^^^^^^
pub fn error<S: Into<String>>(span: &Span, note: S) -> Message {
    message(MessageLevel::Error, note, span)
}

/// Multiple basic errors, each with a message and a single span to be highlighted with ^^^^^^
pub fn multiple_errors<'a, S: Into<String>>(
    spans: impl Iterator<Item = &'a Span>,
    note: S,
) -> Message {
    multiple_message(MessageLevel::Error, note, spans)
}

/// Prepend the error with "Verus Internal Error"
/// Helpful for distinguishing user errors from Verus bugs.
pub fn internal_error<S: Into<String>>(span: &Span, note: S) -> Message {
    let msg = format!("Verus Internal Error: {:}", note.into());
    message(MessageLevel::Error, msg, span)
}

/// Error message with a span to be highlighted with ^^^^^^, and a label for that span
pub fn error_with_label<S: Into<String>, T: Into<String>>(
    span: &Span,
    note: S,
    label: T,
) -> Message {
    message_with_label(MessageLevel::Error, note, span, label)
}

pub fn error_with_secondary_label<S: Into<String>, T: Into<String>>(
    span: &Span,
    note: S,
    label: T,
) -> Message {
    message_with_secondary_label(MessageLevel::Error, note, span, label)
}

// Add additional stuff with the "builders" below.

impl MessageX {
    /// Add a new primary span (rendered with ^^^^^^)
    pub fn primary_span(&self, span: &Span) -> Message {
        let mut e = self.clone();
        e.spans.push(span.clone());
        Arc::new(e)
    }

    /// Add a new primary span with a label (rendered with ^^^^^^)
    pub fn primary_label<S: Into<String>>(&self, span: &Span, label: S) -> Message {
        let mut e = self.clone();
        e.spans.push(span.clone());
        e.labels.push(MessageLabel {
            span: span.clone(),
            note: label.into(),
            is_proof_note: false,
            is_custom_err: false,
        });
        Arc::new(e)
    }

    /// Add a secondary_span to be highlighted, with no label (rendered with ------)
    pub fn secondary_span(&self, span: &Span) -> Message {
        let mut e = self.clone();
        e.labels.push(MessageLabel {
            span: span.clone(),
            note: "".to_string(),
            is_proof_note: false,
            is_custom_err: false,
        });
        Arc::new(e)
    }

    /// Add a secondary_span to be highlighted, with a label (rendered with ------)
    pub fn secondary_label<S: Into<String>>(&self, span: &Span, label: S) -> Message {
        let mut e = self.clone();
        e.labels.push(MessageLabel {
            span: span.clone(),
            note: label.into(),
            is_proof_note: false,
            is_custom_err: false,
        });
        Arc::new(e)
    }

    /// Add a `proof_note` label
    pub fn proof_note_label<S: Into<String>>(
        &self,
        span: &Span,
        label: S,
        is_custom_err: bool,
    ) -> Message {
        let mut e = self.clone();
        e.labels.push(MessageLabel {
            span: span.clone(),
            note: label.into(),
            is_proof_note: true,
            is_custom_err,
        });
        Arc::new(e)
    }

    pub fn ensure_primary_label(&self) -> Message {
        let mut e = self.clone();
        if e.spans.len() == 0 && e.labels.len() > 0 {
            e.spans.push(e.labels[0].span.clone());
        }
        Arc::new(e)
    }

    /// Add a help message, keeping any help messages already present
    pub fn help(&self, help: impl Into<String>) -> Message {
        let mut e = self.clone();
        e.help.push(help.into());
        Arc::new(e)
    }

    pub fn fancy_note(&self, fancy_note: impl Into<String>) -> Message {
        let MessageX { level, note, spans, labels, help, fancy_note: _ } = &self;
        Arc::new(MessageX {
            level: *level,
            note: note.clone(),
            spans: spans.clone(),
            labels: labels.clone(),
            help: help.clone(),
            fancy_note: Some(fancy_note.into()),
        })
    }
}

pub enum MessageAs {
    Warning(Message),
    Note(Message),
}

impl MessageX {
    /// Given a primary error message and an additional error message,
    /// fold the spans of the additional message into a new message copied from the original.
    pub fn merge(self: &Arc<Self>, added_msg: &Message) -> Message {
        added_msg.spans.iter().fold(self.clone(), |acc, v| acc.secondary_span(v))
    }
}
