use crate::ast::{
    ClosureKind, CrateId, Dt, Fun, FunX, InvAtomicity, Path, PathX, UninterpretedFloatBinaryOp,
    VarIdent,
};
use crate::ast_util::air_unique_var;
use crate::messages::Span;
use crate::util::vec_map;
use crate::{fun, path};
use air::ast::{Commands, Ident};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::fmt::Debug;
use std::sync::Arc;

/*
In SMT-LIB format (used by Z3), symbols are built of letters, digits, and:
  ~ ! @ $ % ^ & * _ - + = < > . ? /
(although some words, like "pop" and "declare-fun", are reserved words.)
Symbols starting with . or @ are supposed to be reserved for the solver internals.
Z3 seems to like to introduce symbols with !
$ and % and & and ? are probably safe for prefixes and suffixes.
. and @ are safe for suffixes.
AIR uses @ as a suffix for versions of mutable variables (x@0, x@1, ...).

For VIR -> AIR, we use these suffixes:
- types
    - x.
    - x.y.z.
- globals
    - x.?
    - x.y.z.?
- locals inside functions
    - x@ (works well with AIR's mutable variable convention)
- shadowed (or otherwise repeatedly declared) locals inside functions
    - x@, x$1@, x$2@, ...
- bindings inside expressions (e.g. let, forall)
    - x$
*/

// List of prefixes, suffixes, and separators that can appear in generated AIR code
const SUFFIX_GLOBAL: &str = "?";
pub const SUFFIX_PARAM: &str = "!";
const SUFFIX_LOCAL_STMT: &str = "@";
const SUFFIX_LOCAL_EXPR: &str = "$";
const SUFFIX_TYPE_PARAM: &str = "&";
const SUFFIX_RUSTC_ID: &str = "~";
const SUFFIX_DECORATE_TYPE_PARAM: &str = "&.";
const SUFFIX_REC_PARAM: &str = "!$";
const SUFFIX_PATH: &str = ".";
const PREFIX_ESCAPE: &str = "$~";
const PREFIX_FUEL_ID: &str = "fuel%";
const PREFIX_FUEL_NAT: &str = "fuel_nat%";
const PREFIX_REQUIRES: &str = "req%";
const PREFIX_ENSURES: &str = "ens%";
const PREFIX_OPEN_INV: &str = "openinv%";
const PREFIX_NO_UNWIND_WHEN: &str = "no_unwind_when%";
const PREFIX_RECURSIVE: &str = "rec%";
const PREFIX_SIMPLIFY_TEMP_VAR: &str = "tmp%%";
const PREFIX_TEMP_VAR: &str = "tmp%";
pub const PREFIX_EXPAND_ERRORS_TEMP_VAR: &str = "expand%";
const PREFIX_PRE_VAR: &str = "pre%";
const PREFIX_BOX: &str = "Poly%";
const PREFIX_UNBOX: &str = "%Poly%";
const PREFIX_TYPE_ID: &str = "TYPE%";
const PREFIX_DYN_ID: &str = "DYN%";
const PREFIX_DCR_ID: &str = "DCR%";
const PREFIX_FNDEF_TYPE_ID: &str = "FNDEF%";
const PREFIX_TUPLE_TYPE: &str = "tuple%";
const PREFIX_CLOSURE_TYPE: &str = "anonymous_closure%";
const PREFIX_TUPLE_PARAM: &str = "T%";
const PREFIX_SPEC_FN_TYPE: &str = "fun%";
const PREFIX_IMPL_IDENT: &str = "impl&%";
pub(crate) const PREFIX_IMPL_TUPLE: &str = "impl_tuple&%";
pub(crate) const PREFIX_IMPL_CLOSURE: &str = "impl_closure&%";
pub(crate) const PREFIX_IMPL_FNDEF: &str = "impl_fndef&%";
const PREFIX_PROJECT: &str = "proj%";
const PREFIX_PROJECT_DECORATION: &str = "proj%%";
pub(crate) const PREFIX_DEFAULT_TYP_PARAM: &str = "def_typ_param%";
pub(crate) const PROJECT_POINTEE_METADATA: &str = "pointee_metadata%";
pub(crate) const PROJECT_POINTEE_METADATA_DECORATION: &str = "pointee_metadata%%";
const PREFIX_PROJECT_PARAM: &str = "Proj%";
const PREFIX_TRAIT_BOUND: &str = "tr_bound%";
const PREFIX_TO_DYN: &str = "to_dyn%";
pub(crate) const SIZED_BOUND: &str = "sized";
const PREFIX_STATIC: &str = "static%";
const PREFIX_BREAK_LABEL: &str = "break_label%";
const SLICE_TYPE: &str = "slice%";
const STRSLICE_TYPE: &str = "strslice%";
const ARRAY_TYPE: &str = "array%";
const PTR_TYPE: &str = "ptr_mut%";
const GLOBAL_TYPE: &str = "allocator_global%";
const PREFIX_SNAPSHOT: &str = "snap%";
const SUBST_RENAME_SEPARATOR: &str = "$$";
const EXPAND_ERRORS_DECL_SEPARATOR: &str = "$$$";
const RES_INF_TEMP_SEPARATOR: &str = "$$$$tempplace";
const BITVEC_TMP_DECL_SEPARATOR: &str = "$$$$bitvectmp";
const KRATE_SEPARATOR: &str = "!";
const KRATE_RENAME_SEPARATOR: &str = "!!";
const PATH_SEPARATOR: &str = ".";
const PATHS_SEPARATOR: &str = "/";
const VARIANT_SEPARATOR: &str = "/";
const VARIANT_FIELD_SEPARATOR: &str = "/";
const VARIANT_FIELD_INTERNAL_SEPARATOR: &str = "/?";
const PROJECT_SEPARATOR: &str = "/";
const MONOTYPE_APP_BEGIN: &str = "<";
const MONOTYPE_APP_END: &str = ">";
const MONOTYPE_DECORATE: &str = "$%";
const TRAIT_DEFAULT_SEPARATOR: &str = "%default%";
const DECREASE_AT_ENTRY: &str = "decrease%init";
const TRAIT_SELF_TYPE_PARAM: &str = "Self%";
const DUMMY_PARAM: &str = "no%param";

pub const MUT_REF_UPDATE_CURRENT: &str = "mut_ref_update_current%";
pub const MUT_REF_CURRENT: &str = "mut_ref_current%";
pub const MUT_REF_FUTURE: &str = "mut_ref_future%";

pub const PREFIX_IMPL_TYPE_PARAM: &str = "impl%";
pub const SUFFIX_SNAP_MUT: &str = "_mutation";
pub const SUFFIX_SNAP_JOIN: &str = "_join";
pub const SUFFIX_SNAP_WHILE_BEGIN: &str = "_while_begin";
pub const SUFFIX_SNAP_WHILE_END: &str = "_while_end";

pub const CLOSURE_RETURN_VALUE_PREFIX: &str = "%closure_return";

pub const AUTOSPEC_FUNC_SUFFIX: &str = "%returns_clause_autospec";

pub const FNDEF_TYPE: &str = "fndef";
pub const FNDEF_SINGLETON: &str = "fndef_singleton";

// List of constant strings that can appear in generated AIR code
pub const FUEL_ID: &str = "FuelId";
pub const FUEL_TYPE: &str = "Fuel";
pub const ZERO: &str = "zero";
pub const SUCC: &str = "succ";
pub const FUEL_PARAM: &str = "fuel%";
pub const FUEL_BOOL: &str = "fuel_bool";
pub const FUEL_BOOL_DEFAULT: &str = "fuel_bool_default";
pub const FUEL_DEFAULTS: &str = "fuel_defaults";
pub const RETURN_VALUE: &str = "%return";
pub const RETURN_VALUE_ASYNC_FUTURE: &str = "%return_async_future";
pub const DEFAULT_ENSURES: &str = "default_ensures";
pub const U_HI: &str = "uHi";
pub const I_LO: &str = "iLo";
pub const I_HI: &str = "iHi";
pub const U_CLIP: &str = "uClip";
pub const I_CLIP: &str = "iClip";
pub const NAT_CLIP: &str = "nClip";
pub const CHAR_CLIP: &str = "charClip";
pub const U_INV: &str = "uInv";
pub const I_INV: &str = "iInv";
pub const CHAR_INV: &str = "charInv";
pub const ARCH_SIZE: &str = "SZ";
pub const ADD: &str = "Add";
pub const SUB: &str = "Sub";
pub const MUL: &str = "Mul";
pub const EUC_DIV: &str = "EucDiv";
pub const EUC_MOD: &str = "EucMod";
pub const RADD: &str = "RAdd";
pub const RSUB: &str = "RSub";
pub const RMUL: &str = "RMul";
pub const RDIV: &str = "RDiv";
pub const SNAPSHOT_CALL: &str = "CALL";
pub const SNAPSHOT_PRE: &str = "PRE";
pub const SNAPSHOT_ASSIGN: &str = "ASSIGN";
pub const SNAPSHOT_LOOP: &str = "LOOP";
pub const SNAPSHOT_BOUNDARY: &str = "BOUNDARY";
pub const T_HEIGHT: &str = "Height";
pub const POLY: &str = "Poly";
pub const BOX_INT: &str = "I";
pub const BOX_BOOL: &str = "B";
pub const BOX_REAL: &str = "R";
pub const BOX_FNDEF: &str = "F";
pub const UNBOX_INT: &str = "%I";
pub const UNBOX_BOOL: &str = "%B";
pub const UNBOX_REAL: &str = "%R";
pub const UNBOX_FNDEF: &str = "%F";
pub const TYPE: &str = "Type";
pub const TYPE_ID_BOOL: &str = "BOOL";
pub const TYPE_ID_REAL: &str = "REAL";
pub const TYPE_ID_INT: &str = "INT";
pub const TYPE_ID_NAT: &str = "NAT";
pub const TYPE_ID_CHAR: &str = "CHAR";
pub const TYPE_ID_USIZE: &str = "USIZE";
pub const TYPE_ID_ISIZE: &str = "ISIZE";
pub const TYPE_ID_UINT: &str = "UINT";
pub const TYPE_ID_SINT: &str = "SINT";
pub const TYPE_ID_FLOAT: &str = "FLOAT";
pub const TYPE_ID_CONST_INT: &str = "CONST_INT";
pub const TYPE_ID_CONST_BOOL: &str = "CONST_BOOL";
pub const DECORATION: &str = "Dcr";
pub const DECORATE_NIL_SIZED: &str = "$";
pub const DECORATE_NIL_SLICE: &str = "$slice"; // for 'str' and '[T]' types
pub const DECORATE_NIL_DYN: &str = "$dyn"; // for 'dyn' types
pub const DECORATE_DST_INHERIT: &str = "DST";
pub const DECORATE_REF: &str = "REF";
pub const DECORATE_BOX: &str = "BOX";
pub const DECORATE_RC: &str = "RC";
pub const DECORATE_ARC: &str = "ARC";
pub const DECORATE_GHOST: &str = "GHOST";
pub const DECORATE_TRACKED: &str = "TRACKED";
pub const DECORATE_NEVER: &str = "NEVER";
pub const DECORATE_CONST_PTR: &str = "CONST_PTR";
pub const TYPE_ID_ARRAY: &str = "ARRAY";
pub const TYPE_ID_SLICE: &str = "SLICE";
pub const TYPE_ID_STRSLICE: &str = "STRSLICE";
pub const TYPE_ID_PTR: &str = "PTR";
pub const TYPE_ID_GLOBAL: &str = "ALLOCATOR_GLOBAL";
pub const TYPE_ID_MUT_REF: &str = "MUTREF";
pub const HAS_TYPE: &str = "has_type";
pub const AS_TYPE: &str = "as_type";
pub const MK_FUN: &str = "mk_fun";
pub const CONST_INT: &str = "const_int";
pub const CONST_BOOL: &str = "const_bool";
pub const CHECK_DECREASE_HEIGHT: &str = "check_decrease_height";
pub const HEIGHT: &str = "height";
pub const HEIGHT_LT: &str = "height_lt";
pub const HEIGHT_REC_FUN: &str = "fun_from_recursive_field";
pub const HAS_RESOLVED: &str = "has_resolved";
pub const CLOSURE_REQ: &str = "closure_req";
pub const CLOSURE_ENS: &str = "closure_ens";
pub const DEFAULT_ENS: &str = "default_ens";
const CLOSURE_PARAM: &str = "closure%";
pub const EXT_EQ: &str = "ext_eq";

pub const BIT_XOR: &str = "bitxor";
pub const BIT_AND: &str = "bitand";
pub const BIT_OR: &str = "bitor";
pub const BIT_SHR: &str = "bitshr";
pub const BIT_SHL: &str = "bitshl";
pub const BIT_NOT: &str = "bitnot";
pub const SINGULAR_MOD: &str = "singular_mod";

pub const ARRAY_NEW: &str = "array_new";
pub const ARRAY_INDEX: &str = "array_index";

// List of QID suffixes we add to internally generated quantifiers
pub const QID_BOX_AXIOM: &str = "box_axiom";
pub const QID_UNBOX_AXIOM: &str = "unbox_axiom";
pub const QID_CONSTRUCTOR_INNER: &str = "constructor_inner";
pub const QID_CONSTRUCTOR: &str = "constructor";
pub const QID_EXT_EQUAL: &str = "ext_equal";
pub const QID_APPLY: &str = "apply";
pub const QID_HEIGHT_APPLY: &str = "height_apply";
pub const QID_ACCESSOR: &str = "accessor";
pub const QID_INVARIANT: &str = "invariant";
pub const QID_HAS_TYPE_ALWAYS: &str = "has_type_always";
pub const QID_TRAIT_IMPL: &str = "trait_impl";
pub const QID_TRAIT_TYPE_BOUNDS: &str = "trait_type_bounds";
pub const QID_ASSOC_TYPE_BOUND: &str = "assoc_type_bound";
pub const QID_ASSOC_TYPE_IMPL: &str = "assoc_type_impl";
pub const QID_OPAQUE_TYPE_BOUND: &str = "opaque_type_bound";

pub const VERUS_SPEC: &str = "VERUS_SPEC__";

pub const STRSLICE_LEN: &str = "str%strslice_len";
pub const STRSLICE_GET_CHAR: &str = "str%strslice_get_char";
pub const STRSLICE_NEW_STRLIT: &str = "str%new_strlit";
// only used to prove that new_strlit is injective
pub const STRSLICE_FROM_STRLIT: &str = "str%from_strlit";

pub const BYTESTR_NEW_BYTELIT: &str = "bytes%new_bytelit";
pub const BYTESTR_FROM_BYTELIT_HASH: &str = "bytes%from_bytelit_hash";

pub const IEEE_FLOAT_CAST: &str = "ieee_float_cast";
pub const IEEE_FLOAT_NEG: &str = "ieee_float_neg";
pub const IEEE_FLOAT_FLOOR: &str = "ieee_float_floor";
pub const IEEE_FLOAT_CEIL: &str = "ieee_float_ceil";
pub const IEEE_FLOAT_ROUND: &str = "ieee_float_round";
pub const IEEE_FLOAT_ROUND_TIES_EVEN: &str = "ieee_float_round_ties_even";
pub const IEEE_FLOAT_TRUNC: &str = "ieee_float_trunc";
pub const IEEE_FLOAT_IS_NORMAL: &str = "ieee_float_is_normal";
pub const IEEE_FLOAT_IS_SUBNORMAL: &str = "ieee_float_is_subnormal";
pub const IEEE_FLOAT_IS_ZERO: &str = "ieee_float_is_zero";
pub const IEEE_FLOAT_IS_INFINITE: &str = "ieee_float_is_infinite";
pub const IEEE_FLOAT_IS_NAN: &str = "ieee_float_is_nan";
pub const IEEE_FLOAT_IS_NEGATIVE: &str = "ieee_float_is_negative";
pub const IEEE_FLOAT_IS_POSITIVE: &str = "ieee_float_is_positive";
pub const IEEE_FLOAT_ADD: &str = "ieee_float_add";
pub const IEEE_FLOAT_SUB: &str = "ieee_float_sub";
pub const IEEE_FLOAT_MUL: &str = "ieee_float_mul";
pub const IEEE_FLOAT_DIV: &str = "ieee_float_div";
pub const IEEE_FLOAT_EQ: &str = "ieee_float_eq";
pub const IEEE_FLOAT_LE: &str = "ieee_float_le";
pub const IEEE_FLOAT_GE: &str = "ieee_float_ge";
pub const IEEE_FLOAT_LT: &str = "ieee_float_lt";
pub const IEEE_FLOAT_GT: &str = "ieee_float_gt";

pub const VERUSLIB_PREFIX: &str = "vstd::";
pub const PERVASIVE_PREFIX: &str = "pervasive::";

pub const RUST_DEF_CTOR: &str = "ctor%";
pub const RUST_DEF_CLOSURE: &str = "closure%";
pub const RUST_DEF_ANON_CONST: &str = "anon_const%";

pub const RUST_OPAQUE_TYPE: &str = "opaque";

// used by axiom-usage-info to identify axioms from the prelude
pub const AXIOM_NAME_PRELUDE: &str = "prelude_axiom_";

// List of pre-defined error messages
pub const ASSERTION_FAILURE: &str = "assertion failure";
pub const PRECONDITION_FAILURE: &str = "precondition not satisfied";
pub const POSTCONDITION_FAILURE: &str = "postcondition not satisfied";
pub const THIS_POST_FAILED: &str = "failed this postcondition";
pub const THIS_PRE_FAILED: &str = "failed precondition";
pub const INV_FAIL_LOOP_END: &str = "invariant not satisfied at end of loop body";
pub const INV_FAIL_LOOP_FRONT: &str = "invariant not satisfied before loop";
pub const DEC_FAIL_LOOP_END: &str = "decreases not satisfied at end of loop";
pub const DEC_FAIL_LOOP_CONTINUE: &str = "decreases not satisfied at continue";
pub const SPLIT_ASSERT_FAILURE: &str = "split assertion failure";
pub const SPLIT_PRE_FAILURE: &str = "split precondition failure";
pub const SPLIT_POST_FAILURE: &str = "split postcondition failure";

pub const PERVASIVE_ASSERT: &[&str] = &["pervasive", "assert"];

fn krate_ident_to_string(krate: &str) -> String {
    // rustc allows crate names to begin with digits and to contain unicode
    // TODO: Rust identifiers can in general contain unicode; we should handle this in general
    let krate = krate.escape_default().to_string();
    let krate = krate.replace('\\', PREFIX_ESCAPE);
    let krate = krate.replace('{', PREFIX_ESCAPE);
    let krate = krate.replace('}', PREFIX_ESCAPE);
    if krate.len() > 0 && krate.bytes().next().unwrap().is_ascii_digit() {
        PREFIX_ESCAPE.to_string() + &krate
    } else {
        krate
    }
}

// Context for generating names in a single AIR file:
// - names do not have to be consistent between different AIR files
// - we omit the u64 id to keep the names in the AIR file stable across verifier runs,
//   but if two crates have the same name, we have to disambiguate them
// - for simplicity, we handle this disambiguation on demand so that we don't
//   do any more renaming than necessary in each AIR file
struct NameCtxtImpl {
    duplicate_name_counter: HashMap<String, u32>,
    stable_id_map: HashMap<u64, String>,
}

impl NameCtxtImpl {
    fn new() -> Self {
        Self { duplicate_name_counter: HashMap::new(), stable_id_map: HashMap::new() }
    }

    fn krate_id_to_string(&mut self, id: u64, name: &str) -> String {
        let stable = self.stable_id_map.entry(id).or_insert_with(|| {
            let count = self.duplicate_name_counter.entry(name.to_string()).or_insert(0);
            *count += 1;
            let name = krate_ident_to_string(name);
            if *count == 1 { name } else { format!("{}{}{}", name, KRATE_RENAME_SEPARATOR, count) }
        });
        stable.clone()
    }
}

pub struct NameCtxt {
    imp: std::rc::Rc<std::cell::RefCell<NameCtxtImpl>>,
}

impl NameCtxt {
    // Warning: NameCtxt is meant to capture shared decisions about naming that should be
    // consistent across an entire AIR file.
    // Therefore, code generating AIR should use the existing NameCtxt from the Ctx struct
    // for that AIR file, rather than allocating additional NameCtxt values.
    pub(crate) fn new() -> Self {
        Self { imp: std::rc::Rc::new(std::cell::RefCell::new(NameCtxtImpl::new())) }
    }

    fn krate_id_to_string(&self, id: u64, name: &str) -> String {
        self.imp.borrow_mut().krate_id_to_string(id, name)
    }
}

// Only use this for printing diagnostics
// Do not use this to generate AIR -- it is unsound to ignore the id
// (However, it's always ok to use this when the krate is not CrateId::Id)
pub fn krate_to_string_ignore_stable_id(krate: &CrateId) -> String {
    match krate {
        CrateId::Internal => "crate".to_string(),
        CrateId::Core => "core".to_string(),
        CrateId::Alloc => "alloc".to_string(),
        CrateId::Vstd => "vstd".to_string(),
        CrateId::Id(ident, _) => krate_ident_to_string(ident),
    }
}

impl NameCtxt {
    pub fn krate_to_string(&self, krate: &CrateId) -> String {
        match krate {
            CrateId::Internal | CrateId::Core | CrateId::Alloc | CrateId::Vstd => {
                krate_to_string_ignore_stable_id(krate)
            }
            CrateId::Id(ident, id) => self.krate_id_to_string(*id, ident),
        }
    }

    pub fn path_to_string(&self, path: &Path) -> String {
        let s = vec_map(&path.segments, |s| s.to_string()).join(PATH_SEPARATOR) + SUFFIX_PATH;
        match &path.krate {
            CrateId::Internal => s,
            krate => self.krate_to_string(krate) + KRATE_SEPARATOR + &s,
        }
    }

    pub fn fun_to_string(&self, fun: &Fun) -> String {
        let FunX { path } = &(**fun);
        self.path_to_string(path)
    }
}

pub fn decrease_at_entry(loop_id: Option<u64>, n: usize) -> VarIdent {
    let loop_id = loop_id.map_or("".to_string(), |s| format!("{s}%"));
    air_unique_var(&format!("{}{}{}", DECREASE_AT_ENTRY, loop_id, n))
}

pub fn trait_self_type_param() -> Ident {
    Arc::new(TRAIT_SELF_TYPE_PARAM.to_string())
}

pub(crate) fn trait_default_name(default_fun: &Fun) -> Fun {
    let path = (**default_fun).path.clone();
    let mut segments = (*path.segments).clone();
    let x = segments.last().expect("segment").to_string() + TRAIT_DEFAULT_SEPARATOR;
    *segments.last_mut().unwrap() = Arc::new(x);
    Arc::new(crate::ast::FunX {
        path: Arc::new(crate::ast::PathX {
            krate: path.krate.clone(),
            segments: Arc::new(segments),
        }),
    })
}

pub fn trait_inherit_default_name(default_fun: &Fun, impl_path: &Path) -> Fun {
    let path = (**impl_path).clone();
    let mut segments = (*path.segments).clone();
    let x = segments.last().expect("segment").to_string()
        + TRAIT_DEFAULT_SEPARATOR
        + default_fun.path.segments.last().unwrap();
    *segments.last_mut().unwrap() = Arc::new(x);
    Arc::new(crate::ast::FunX {
        path: Arc::new(crate::ast::PathX {
            krate: path.krate.clone(),
            segments: Arc::new(segments),
        }),
    })
}

pub fn suffix_global_id(ident: &Ident) -> Ident {
    Arc::new(ident.to_string() + SUFFIX_GLOBAL)
}

// TODO: this is currently only used by debugger.rs; consider replacing this
pub fn suffix_local_stmt_id(ident: &Ident) -> Ident {
    Arc::new(ident.to_string() + SUFFIX_LOCAL_STMT)
}

// TODO: get rid of this
pub(crate) fn unique_bound(id: &VarIdent) -> VarIdent {
    id.clone()
}

// TODO: get rid of this
pub(crate) fn unique_local(id: &VarIdent) -> VarIdent {
    id.clone()
}

// TODO: get rid of this
pub fn suffix_local_unique_id(ident: &VarIdent) -> Ident {
    use crate::ast_util::LowerUniqueVar;
    ident.lower()
}

pub fn subst_rename_ident(x: &VarIdent, n: u64) -> VarIdent {
    let dis = crate::ast::VarIdentDisambiguate::VirSubst(n);
    crate::ast::VarIdent(x.0.clone(), dis)
}

pub(crate) fn suffix_typ_param_var(x: &VarIdent) -> VarIdent {
    assert!(x.1 == crate::ast::VarIdentDisambiguate::TypParamBare);
    let dis = crate::ast::VarIdentDisambiguate::TypParamSuffixed;
    crate::ast::VarIdent(x.0.clone(), dis)
}

pub(crate) fn suffix_decorate_typ_param_var(x: &VarIdent) -> VarIdent {
    assert!(x.1 == crate::ast::VarIdentDisambiguate::TypParamBare);
    let dis = crate::ast::VarIdentDisambiguate::TypParamDecorated;
    crate::ast::VarIdent(x.0.clone(), dis)
}

pub(crate) fn suffix_typ_param_vars(unique_var: &VarIdent) -> Vec<VarIdent> {
    if crate::context::DECORATE {
        vec![suffix_decorate_typ_param_var(unique_var), suffix_typ_param_var(unique_var)]
    } else {
        vec![suffix_typ_param_var(unique_var)]
    }
}

pub(crate) fn suffix_typ_param_vars_types(unique_var: &VarIdent) -> Vec<(VarIdent, &'static str)> {
    if crate::context::DECORATE {
        vec![
            (suffix_decorate_typ_param_var(unique_var), DECORATION),
            (suffix_typ_param_var(unique_var), TYPE),
        ]
    } else {
        vec![(suffix_typ_param_var(unique_var), TYPE)]
    }
}

pub(crate) fn suffix_typ_param_id(ident: &Ident) -> VarIdent {
    suffix_typ_param_var(&crate::ast_util::typ_unique_var(ident))
}

pub(crate) fn suffix_typ_param_ids(ident: &Ident) -> Vec<VarIdent> {
    suffix_typ_param_vars(&crate::ast_util::typ_unique_var(ident))
}

pub(crate) fn suffix_typ_param_ids_types(ident: &Ident) -> Vec<(VarIdent, &'static str)> {
    suffix_typ_param_vars_types(&crate::ast_util::typ_unique_var(ident))
}

pub(crate) fn types() -> Vec<&'static str> {
    if crate::context::DECORATE { vec![DECORATION, TYPE] } else { vec![TYPE] }
}

pub fn rename_rec_param(ident: &VarIdent, n: usize) -> VarIdent {
    let dis = crate::ast::VarIdentDisambiguate::VirParamRecursion(n);
    crate::ast::VarIdent(ident.0.clone(), dis)
}

pub fn slice_type() -> Path {
    let ident = Arc::new(SLICE_TYPE.to_string());
    Arc::new(PathX { krate: CrateId::Internal, segments: Arc::new(vec![ident]) })
}

pub fn strslice_type() -> Path {
    let ident = Arc::new(STRSLICE_TYPE.to_string());
    Arc::new(PathX { krate: CrateId::Internal, segments: Arc::new(vec![ident]) })
}

pub fn fn_slice_len() -> Fun {
    Arc::new(FunX {
        path: Arc::new(PathX {
            krate: CrateId::Vstd,
            segments: Arc::new(vec![
                Arc::new("slice".to_string()),
                Arc::new("spec_slice_len".to_string()),
            ]),
        }),
    })
}

pub fn fn_slice_index() -> Fun {
    Arc::new(FunX {
        path: Arc::new(PathX {
            krate: CrateId::Vstd,
            segments: Arc::new(vec![
                Arc::new("slice".to_string()),
                Arc::new("spec_slice_index".to_string()),
            ]),
        }),
    })
}

pub fn fn_slice_update() -> Fun {
    Arc::new(FunX {
        path: Arc::new(PathX {
            krate: CrateId::Vstd,
            segments: Arc::new(vec![
                Arc::new("slice".to_string()),
                Arc::new("spec_slice_update".to_string()),
            ]),
        }),
    })
}

pub fn fn_array_update() -> Fun {
    Arc::new(FunX {
        path: Arc::new(PathX {
            krate: CrateId::Vstd,
            segments: Arc::new(vec![
                Arc::new("array".to_string()),
                Arc::new("spec_array_update".to_string()),
            ]),
        }),
    })
}

pub fn fn_truncating_div() -> Fun {
    Arc::new(FunX {
        path: Arc::new(PathX {
            krate: CrateId::Vstd,
            segments: Arc::new(vec![
                Arc::new("arithmetic".to_string()),
                Arc::new("div_mod".to_string()),
                Arc::new("rust_div".to_string()),
            ]),
        }),
    })
}

pub fn fn_truncating_mod() -> Fun {
    Arc::new(FunX {
        path: Arc::new(PathX {
            krate: CrateId::Vstd,
            segments: Arc::new(vec![
                Arc::new("arithmetic".to_string()),
                Arc::new("div_mod".to_string()),
                Arc::new("rust_rem".to_string()),
            ]),
        }),
    })
}

pub fn array_type() -> Path {
    let ident = Arc::new(ARRAY_TYPE.to_string());
    Arc::new(PathX { krate: CrateId::Internal, segments: Arc::new(vec![ident]) })
}

pub fn ptr_type() -> Path {
    let ident = Arc::new(PTR_TYPE.to_string());
    Arc::new(PathX { krate: CrateId::Internal, segments: Arc::new(vec![ident]) })
}

pub fn global_type() -> Path {
    let ident = Arc::new(GLOBAL_TYPE.to_string());
    Arc::new(PathX { krate: CrateId::Internal, segments: Arc::new(vec![ident]) })
}

impl NameCtxt {
    pub fn prefix_dcr_id(&self, ident: &Path) -> Ident {
        Arc::new(PREFIX_DCR_ID.to_string() + &self.path_to_string(ident))
    }

    pub fn prefix_type_id(&self, ident: &Path) -> Ident {
        Arc::new(PREFIX_TYPE_ID.to_string() + &self.path_to_string(ident))
    }

    pub fn prefix_dyn_id(&self, ident: &Path) -> Ident {
        Arc::new(PREFIX_DYN_ID.to_string() + &self.path_to_string(ident))
    }

    pub fn prefix_fndef_type_id(&self, fun: &Fun) -> Ident {
        Arc::new(PREFIX_FNDEF_TYPE_ID.to_string() + &self.fun_to_string(fun))
    }
}

pub fn prefix_tuple_type(i: usize) -> Path {
    let ident = Arc::new(format!("{}{}", PREFIX_TUPLE_TYPE, i));
    Arc::new(PathX { krate: CrateId::Internal, segments: Arc::new(vec![ident]) })
}

pub fn prefix_closure_type(i: usize) -> Path {
    let ident = Arc::new(format!("{}{}", PREFIX_CLOSURE_TYPE, i));
    Arc::new(PathX { krate: CrateId::Internal, segments: Arc::new(vec![ident]) })
}

pub fn prefix_tuple_variant(i: usize) -> Ident {
    Arc::new(format!("{}{}", PREFIX_TUPLE_TYPE, i))
}

pub fn prefix_tuple_param(i: usize) -> Ident {
    Arc::new(format!("{}{}", PREFIX_TUPLE_PARAM, i))
}

pub fn prefix_spec_fn_type(i: usize) -> Path {
    let ident = Arc::new(format!("{}{}", PREFIX_SPEC_FN_TYPE, i));
    Arc::new(PathX { krate: CrateId::Internal, segments: Arc::new(vec![ident]) })
}

pub fn impl_ident(disambiguator: u32) -> Ident {
    Arc::new(format!("{}{}", PREFIX_IMPL_IDENT, disambiguator))
}

pub(crate) fn impl_tuple(trait_suffix: &str, arity: usize) -> Ident {
    Arc::new(format!("{}{}{}", PREFIX_IMPL_TUPLE, trait_suffix, arity))
}

pub(crate) fn impl_closure(kind: ClosureKind, id: usize) -> Ident {
    Arc::new(format!("{}{}{}", PREFIX_IMPL_CLOSURE, kind, id))
}

pub(crate) fn impl_fndef_path(fun: &Fun, kind: ClosureKind) -> Path {
    fun.path.push_segment(Arc::new(format!("{}{}", PREFIX_IMPL_FNDEF, kind)))
}

impl NameCtxt {
    pub fn projection(&self, decoration: bool, trait_path: &Path, name: &Ident) -> Ident {
        let proj = if decoration { PREFIX_PROJECT_DECORATION } else { PREFIX_PROJECT };
        Arc::new(format!(
            "{}{}{}{}",
            proj,
            self.path_to_string(trait_path),
            PROJECT_SEPARATOR,
            name,
        ))
    }
}

pub fn projection_pointee_metadata(decoration: bool) -> Ident {
    if decoration {
        Arc::new(PROJECT_POINTEE_METADATA_DECORATION.to_string())
    } else {
        Arc::new(PROJECT_POINTEE_METADATA.to_string())
    }
}

pub fn proj_param(i: usize) -> Ident {
    Arc::new(format!("{}{}", PREFIX_PROJECT_PARAM, i))
}

impl NameCtxt {
    pub fn trait_bound(&self, trait_path: &Path) -> Ident {
        Arc::new(format!("{}{}", PREFIX_TRAIT_BOUND, self.path_to_string(trait_path)))
    }

    pub fn to_dyn(&self, trait_path: &Path) -> Ident {
        Arc::new(format!("{}{}", PREFIX_TO_DYN, self.path_to_string(trait_path)))
    }
}

pub fn sized_bound() -> Ident {
    Arc::new(SIZED_BOUND.to_string())
}

impl NameCtxt {
    pub fn prefix_type_id_fun(&self, i: usize) -> Ident {
        self.prefix_type_id(&prefix_spec_fn_type(i))
    }

    pub fn prefix_box(&self, ident: &Path) -> Ident {
        Arc::new(PREFIX_BOX.to_string() + &self.path_to_string(ident))
    }

    pub fn prefix_unbox(&self, ident: &Path) -> Ident {
        Arc::new(PREFIX_UNBOX.to_string() + &self.path_to_string(ident))
    }
}

pub fn prefix_fuel_id(ident: &Ident) -> Ident {
    Arc::new(PREFIX_FUEL_ID.to_string() + ident)
}

pub fn prefix_fuel_nat(ident: &Ident) -> Ident {
    Arc::new(PREFIX_FUEL_NAT.to_string() + ident)
}

pub fn prefix_requires(ident: &Ident) -> Ident {
    Arc::new(PREFIX_REQUIRES.to_string() + ident)
}

pub fn prefix_ensures(ident: &Ident) -> Ident {
    Arc::new(PREFIX_ENSURES.to_string() + ident)
}

pub fn prefix_open_inv(ident: &Ident, i: usize) -> Ident {
    Arc::new(format!("{}{}%{}", PREFIX_OPEN_INV, i, ident))
}

pub fn prefix_no_unwind_when(ident: &Ident) -> Ident {
    Arc::new(PREFIX_NO_UNWIND_WHEN.to_string() + ident)
}

fn prefix_path(prefix: String, path: &Path) -> Path {
    let mut segments: Vec<Ident> = (*path.segments).clone();
    let last: &mut Ident = segments.last_mut().expect("path last segment");
    *last = Arc::new(prefix + &**last);
    let pathx = PathX { krate: path.krate.clone(), segments: Arc::new(segments) };
    Arc::new(pathx)
}

fn prefix_recursive(path: &Path) -> Path {
    prefix_path(PREFIX_RECURSIVE.to_string(), path)
}

pub fn prefix_recursive_fun(fun: &Fun) -> Fun {
    let FunX { path } = &(**fun);
    let path = prefix_recursive(path);
    Arc::new(FunX { path })
}

pub fn new_temp_var(n: u64) -> VarIdent {
    crate::ast_util::str_unique_var(PREFIX_TEMP_VAR, crate::ast::VarIdentDisambiguate::VirTemp(n))
}

// ast_simplify introduces its own temporary variables; we don't want these to conflict with prefix_temp_var
pub fn simplify_temp_var(n: u64) -> VarIdent {
    crate::ast_util::str_unique_var(
        PREFIX_SIMPLIFY_TEMP_VAR,
        crate::ast::VarIdentDisambiguate::VirTemp(n),
    )
}

pub fn closure_param_var() -> VarIdent {
    crate::ast_util::str_unique_var(CLOSURE_PARAM, crate::ast::VarIdentDisambiguate::AirLocal)
}

pub fn prefix_pre_var(name: &Ident) -> Ident {
    Arc::new(PREFIX_PRE_VAR.to_string() + name)
}

pub fn encode_dt_as_path(dt: &Dt) -> Path {
    match dt {
        Dt::Path(path) => path.clone(),
        Dt::Tuple(arity) => prefix_tuple_type(*arity),
    }
}

impl NameCtxt {
    pub fn variant_ident(&self, dt: &Dt, variant: &str) -> Ident {
        let path = encode_dt_as_path(dt);
        Arc::new(format!("{}{}{}", self.path_to_string(&path), VARIANT_SEPARATOR, variant))
    }

    pub fn is_variant_ident(&self, datatype: &Dt, variant: &str) -> Ident {
        Arc::new(format!("is-{}", self.variant_ident(datatype, variant)))
    }

    pub fn variant_field_ident_internal(
        &self,
        path: &Path,
        variant: &Ident,
        field: &Ident,
        internal: bool,
    ) -> Ident {
        Arc::new(format!(
            "{}{}{}{}{}",
            self.path_to_string(path),
            VARIANT_SEPARATOR,
            variant.as_str(),
            if internal { VARIANT_FIELD_INTERNAL_SEPARATOR } else { VARIANT_FIELD_SEPARATOR },
            field.as_str()
        ))
    }

    pub fn variant_field_ident(&self, datatype: &Path, variant: &Ident, field: &Ident) -> Ident {
        self.variant_field_ident_internal(datatype, variant, field, false)
    }
}

pub fn positional_field_ident(idx: usize) -> Ident {
    Arc::new(format!("{}", idx))
}

pub fn field_ident_from_rust(s: &str) -> Ident {
    Arc::new(format!("{}", s))
}

impl NameCtxt {
    pub fn monotyp_apply(&self, datatype: &Path, args: &Vec<Path>) -> Path {
        if args.len() == 0 {
            datatype.clone()
        } else {
            let mut segments = (*datatype.segments).clone();
            let last = segments.last_mut().expect("last path segment");
            let ident = Arc::new(format!(
                "{}{}{}{}",
                last,
                MONOTYPE_APP_BEGIN,
                vec_map(args, |x| self.path_to_string(x)).join(PATHS_SEPARATOR),
                MONOTYPE_APP_END,
            ));
            *last = ident;
            Arc::new(PathX { krate: datatype.krate.clone(), segments: Arc::new(segments) })
        }
    }

    pub fn monotyp_decorate(&self, dec: crate::ast::TypDecoration, path: &Path) -> Path {
        let id = Arc::new(format!(
            "{}{}{}{}{}",
            MONOTYPE_DECORATE,
            dec as u32,
            MONOTYPE_APP_BEGIN,
            self.path_to_string(path),
            MONOTYPE_APP_END
        ));
        Arc::new(PathX { krate: CrateId::Internal, segments: Arc::new(vec![id]) })
    }

    pub fn monotyp_decorate2(&self, dec: crate::ast::TypDecoration, args: &Vec<Path>) -> Path {
        let id = Arc::new(format!(
            "{}{}{}{}{}",
            MONOTYPE_DECORATE,
            dec as u32,
            MONOTYPE_APP_BEGIN,
            vec_map(args, |x| self.path_to_string(x)).join(PATHS_SEPARATOR),
            MONOTYPE_APP_END
        ));
        Arc::new(PathX { krate: CrateId::Internal, segments: Arc::new(vec![id]) })
    }
}

pub fn name_as_vstd_name(name: &String) -> Option<String> {
    let name = if let Some(x) = name.strip_prefix(crate::def::VERUSLIB_PREFIX) {
        if let Some(x) = x.strip_prefix(crate::def::PERVASIVE_PREFIX) {
            return Some(x.to_string());
        }
        return Some(x.to_string());
    } else if let Some(x) = name.strip_prefix("crate::") {
        x.to_string()
    } else {
        return None;
    };
    if let Some(x) = name.strip_prefix(crate::def::PERVASIVE_PREFIX) {
        Some(x.to_string())
    } else {
        None
    }
}

// Generate a unique quantifier name
pub fn new_user_qid_name(fun_name: &str, q_count: u64) -> String {
    // In SMTLIB, unquoted attribute values cannot contain colons,
    // and sise cannot handle quoting with vertical bars
    let fun_name = str::replace(&fun_name, ":", "_");
    let qid = format!("{}{}_{}", air::profiler::USER_QUANT_PREFIX, fun_name, q_count);
    qid
}

// Generate a unique internal quantifier ID
pub fn new_internal_qid(ctx: &crate::context::Ctx, name: String) -> Option<Ident> {
    // In SMTLIB, unquoted attribute values cannot contain colons,
    // and sise cannot handle quoting with vertical bars
    let name = str::replace(&name, ":", "_");
    let name = str::replace(&name, "%", "__");
    let qid = format!("{}{}_definition", air::profiler::INTERNAL_QUANT_PREFIX, name);

    if let Some(fun) = ctx.fun.as_ref() {
        let bnd_info = crate::sst::BndInfo { fun: fun.current_fun.clone(), user: None };
        ctx.global.qid_map.borrow_mut().insert(qid.clone(), bnd_info);
    }

    Some(Arc::new(qid))
}

pub fn snapshot_ident(name: &str) -> Ident {
    Arc::new(format!("{}{}", PREFIX_SNAPSHOT, name))
}

// only used by axiom-usage-info to identify prelude axioms
pub fn prelude_axiom_name(name: &str) -> String {
    format!("{AXIOM_NAME_PRELUDE}{name}")
}

/// For a given snapshot, does it represent the state
/// at the start of the corresponding span, the end, or the full span?
#[derive(Debug)]
pub enum SpanKind {
    Start,
    Full,
    End,
}

#[derive(Debug)]
pub struct SnapPos {
    pub snapshot_id: Ident,
    pub kind: SpanKind,
}

#[derive(Serialize, Deserialize, Clone)]
pub struct Spanned<X> {
    pub span: Span,
    pub x: X,
}

impl<X> Spanned<X> {
    pub fn new(span: Span, x: X) -> Arc<Spanned<X>> {
        Arc::new(Spanned { span: span, x: x })
    }

    pub fn new_x<X2>(&self, x: X2) -> Arc<Spanned<X2>> {
        Arc::new(Spanned { span: self.span.clone(), x })
    }

    pub fn map_x<Y>(&self, f: impl FnOnce(&X) -> Y) -> Arc<Spanned<Y>> {
        Arc::new(Spanned { span: self.span.clone(), x: f(&self.x) })
    }
}

impl<X: Debug> Debug for Spanned<X> {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> Result<(), std::fmt::Error> {
        f.debug_tuple("Spanned").field(&self.span.as_string).field(&self.x).finish()
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub enum ProverChoice {
    DefaultProver,
    Nonlinear,
    BitVector,
    Singular,
}

#[derive(Clone, Debug)]
pub struct CommandContext {
    pub fun: Fun,
    pub span: crate::messages::Span,
    pub desc: String,
}

impl CommandContext {
    pub fn with_desc_prefix(&self, prefix: Option<&str>) -> Self {
        let CommandContext { fun, span, desc } = self;
        CommandContext {
            fun: fun.clone(),
            span: span.clone(),
            desc: prefix.unwrap_or("").to_string() + desc,
        }
    }
}

#[derive(Debug, Clone)]
pub struct CommandsWithContextX {
    pub context: CommandContext,
    pub commands: Commands,
    pub prover_choice: ProverChoice,
    pub skip_recommends: bool,
}

impl CommandsWithContextX {
    pub fn new(
        fun: Fun,
        span: Span,
        desc: String,
        commands: Commands,
        prover_choice: ProverChoice,
        skip_recommends: bool,
    ) -> CommandsWithContext {
        Arc::new(CommandsWithContextX {
            context: CommandContext { fun, span, desc },
            commands,
            prover_choice,
            skip_recommends,
        })
    }
}

pub type CommandsWithContext = Arc<CommandsWithContextX>;

fn atomicity_type_name(atomicity: InvAtomicity) -> Ident {
    match atomicity {
        InvAtomicity::Atomic => Arc::new("AtomicInvariant".to_string()),
        InvAtomicity::NonAtomic => Arc::new("LocalInvariant".to_string()),
    }
}

pub fn fn_inv_name(atomicity: InvAtomicity) -> Fun {
    Arc::new(FunX {
        path: Arc::new(PathX {
            krate: CrateId::Vstd,
            segments: Arc::new(vec![
                Arc::new("invariant".to_string()),
                atomicity_type_name(atomicity),
                Arc::new("inv".to_string()),
            ]),
        }),
    })
}

pub fn create_open_invariant_credit_path() -> Path {
    Arc::new(PathX {
        krate: CrateId::Vstd,
        segments: Arc::new(vec![
            Arc::new("invariant".to_string()),
            Arc::new("create_open_invariant_credit".to_string()),
        ]),
    })
}

pub fn spend_open_invariant_credit_path() -> Path {
    Arc::new(PathX {
        krate: CrateId::Vstd,
        segments: Arc::new(vec![
            Arc::new("invariant".to_string()),
            Arc::new("spend_open_invariant_credit".to_string()),
        ]),
    })
}

pub fn fn_namespace_name(atomicity: InvAtomicity) -> Fun {
    Arc::new(FunX {
        path: Arc::new(PathX {
            krate: CrateId::Vstd,
            segments: Arc::new(vec![
                Arc::new("invariant".to_string()),
                atomicity_type_name(atomicity),
                Arc::new("namespace".to_string()),
            ]),
        }),
    })
}

pub fn iset_type_path() -> Path {
    Arc::new(PathX {
        krate: CrateId::Vstd,
        segments: Arc::new(vec![Arc::new("iset".to_string()), Arc::new("ISet".to_string())]),
    })
}

pub fn fn_iset_empty_name() -> Fun {
    Arc::new(FunX {
        path: Arc::new(PathX {
            krate: CrateId::Vstd,
            segments: Arc::new(vec![
                Arc::new("iset".to_string()),
                Arc::new("ISet".to_string()),
                Arc::new("empty".to_string()),
            ]),
        }),
    })
}

pub fn fn_iset_full_name() -> Fun {
    Arc::new(FunX {
        path: Arc::new(PathX {
            krate: CrateId::Vstd,
            segments: Arc::new(vec![
                Arc::new("iset".to_string()),
                Arc::new("ISet".to_string()),
                Arc::new("full".to_string()),
            ]),
        }),
    })
}

pub fn fn_iset_subset_of_name() -> Fun {
    Arc::new(FunX {
        path: Arc::new(PathX {
            krate: CrateId::Vstd,
            segments: Arc::new(vec![
                Arc::new("iset".to_string()),
                Arc::new("ISet".to_string()),
                Arc::new("subset_of".to_string()),
            ]),
        }),
    })
}

pub fn fn_iset_insert_name() -> Fun {
    Arc::new(FunX {
        path: Arc::new(PathX {
            krate: CrateId::Vstd,
            segments: Arc::new(vec![
                Arc::new("iset".to_string()),
                Arc::new("ISet".to_string()),
                Arc::new("insert".to_string()),
            ]),
        }),
    })
}

pub fn fn_iset_remove_name() -> Fun {
    Arc::new(FunX {
        path: Arc::new(PathX {
            krate: CrateId::Vstd,
            segments: Arc::new(vec![
                Arc::new("iset".to_string()),
                Arc::new("ISet".to_string()),
                Arc::new("remove".to_string()),
            ]),
        }),
    })
}

pub fn fn_iset_contains_name() -> Fun {
    Arc::new(FunX {
        path: Arc::new(PathX {
            krate: CrateId::Vstd,
            segments: Arc::new(vec![
                Arc::new("iset".to_string()),
                Arc::new("ISet".to_string()),
                Arc::new("contains".to_string()),
            ]),
        }),
    })
}

pub fn au_type_path() -> Path {
    path!(CrateId::Vstd => "atomic", "AtomicUpdate")
}

pub fn fn_au_pred() -> Fun {
    fun!(CrateId::Vstd => "atomic", "AtomicUpdate", "pred")
}

pub fn fn_au_resolves() -> Fun {
    fun!(CrateId::Vstd => "atomic", "AtomicUpdate", "resolves")
}

pub fn fn_au_input() -> Fun {
    fun!(CrateId::Vstd => "atomic", "AtomicUpdate", "input")
}

pub fn fn_au_output() -> Fun {
    fun!(CrateId::Vstd => "atomic", "AtomicUpdate", "output")
}

pub fn fn_au_req() -> Fun {
    fun!(CrateId::Vstd => "atomic", "AtomicUpdate", "req")
}

pub fn fn_au_ens() -> Fun {
    fun!(CrateId::Vstd => "atomic", "AtomicUpdate", "ens")
}

pub fn fn_au_outer_mask() -> Fun {
    fun!(CrateId::Vstd => "atomic", "AtomicUpdate", "outer_mask")
}

pub fn fn_au_inner_mask() -> Fun {
    fun!(CrateId::Vstd => "atomic", "AtomicUpdate", "inner_mask")
}

pub fn fn_pred_args() -> Fun {
    fun!(CrateId::Vstd => "atomic", "pred_args")
}

pub fn fn_branch_bool() -> Fun {
    fun!(CrateId::Vstd => "atomic", "branch_bool")
}

pub fn result_type_path() -> Path {
    path!(CrateId::Core => "result", "Result")
}

pub fn strslice_module_path() -> Path {
    Arc::new(PathX {
        krate: CrateId::Vstd,
        segments: Arc::new(vec![Arc::new("string".to_string())]),
    })
}

/// Inverse of unique_local_name: extracts the user_given_name from
/// a unique name (e.g., given "a~2", returns "a"
pub fn user_local_name<'a>(s: &'a VarIdent) -> &'a str {
    &s.0
}

pub fn unique_var_name(
    user_given_name: String,
    uniq_id: crate::ast::VarIdentDisambiguate,
) -> String {
    use {crate::ast::VarIdentDisambiguate, std::fmt::Write};
    let mut out = user_given_name;
    match uniq_id {
        VarIdentDisambiguate::AirLocal => {}
        VarIdentDisambiguate::NoBodyParam => {
            out.push_str(SUFFIX_PARAM);
        }
        VarIdentDisambiguate::Field => {
            out.push_str(SUFFIX_PARAM);
        }
        VarIdentDisambiguate::TypParamBare => {}
        VarIdentDisambiguate::TypParamSuffixed => {
            out.push_str(SUFFIX_TYPE_PARAM);
        }
        VarIdentDisambiguate::TypParamDecorated => {
            out.push_str(SUFFIX_DECORATE_TYPE_PARAM);
        }
        VarIdentDisambiguate::RustcId(id) => {
            out.push_str(SUFFIX_RUSTC_ID);
            write!(&mut out, "{}", id).unwrap();
        }
        VarIdentDisambiguate::VirRenumbered { is_stmt, id, .. } => {
            if is_stmt {
                if id != 0 {
                    out.push_str(SUFFIX_LOCAL_EXPR);
                    write!(&mut out, "{}", id).unwrap();
                }
                out.push_str(SUFFIX_LOCAL_STMT);
            } else {
                out.push_str(SUFFIX_LOCAL_EXPR);
                write!(&mut out, "{}", id).unwrap();
            }
        }
        VarIdentDisambiguate::VirExprNoNumber => {
            out.push_str(SUFFIX_LOCAL_EXPR);
        }
        VarIdentDisambiguate::VirParam => {
            out.push_str(SUFFIX_PARAM);
        }
        VarIdentDisambiguate::VirParamRecursion(n) => {
            out.push_str(SUFFIX_REC_PARAM);
            write!(&mut out, "{}", n).unwrap();
        }
        VarIdentDisambiguate::VirSubst(n) => {
            out.push_str(SUBST_RENAME_SEPARATOR);
            write!(&mut out, "{}", n).unwrap();
        }
        VarIdentDisambiguate::VirTemp(id) => {
            write!(&mut out, "{}", id).unwrap();
        }
        VarIdentDisambiguate::ExpandErrorsDecl(id) => {
            out.push_str(EXPAND_ERRORS_DECL_SEPARATOR);
            write!(&mut out, "{}", id).unwrap();
        }
        VarIdentDisambiguate::BitVectorToAirDecl(id) => {
            out.push_str(BITVEC_TMP_DECL_SEPARATOR);
            write!(&mut out, "{}", id).unwrap();
        }
        VarIdentDisambiguate::ResInfTemp(id) => {
            out.push_str(RES_INF_TEMP_SEPARATOR);
            write!(&mut out, "{}", id).unwrap();
        }
        VarIdentDisambiguate::NativeResource(id) => {
            write!(&mut out, "$native_resource${}", id).unwrap();
        }
    }
    out
}

pub fn exec_await_path() -> Path {
    Arc::new(PathX {
        krate: CrateId::Vstd,
        segments: Arc::new(vec![
            Arc::new("future".to_string()),
            Arc::new("exec_await".to_string()),
        ]),
    })
}

pub fn nonstatic_call_fun(is_proof: bool) -> Fun {
    Arc::new(FunX { path: nonstatic_call_path(is_proof) })
}

pub fn nonstatic_call_path(is_proof: bool) -> Path {
    let name = if is_proof { "proof_nonstatic_call" } else { "exec_nonstatic_call" };
    Arc::new(PathX {
        krate: CrateId::Vstd,
        segments: Arc::new(vec![Arc::new("pervasive".to_string()), Arc::new(name.to_string())]),
    })
}

impl NameCtxt {
    pub fn static_name(&self, fun: &Fun) -> Ident {
        Arc::new(PREFIX_STATIC.to_string() + &self.fun_to_string(fun))
    }
}

pub fn break_label(i: u64) -> Ident {
    Arc::new(format!("{}{}", PREFIX_BREAK_LABEL, i))
}

pub fn array_new_path() -> Path {
    Arc::new(PathX {
        krate: CrateId::Vstd,
        segments: Arc::new(vec![Arc::new("array".to_string()), Arc::new("array_new".to_string())]),
    })
}

pub(crate) fn dummy_param_name() -> VarIdent {
    air_unique_var(DUMMY_PARAM)
}

pub(crate) fn is_dummy_param_name(v: &VarIdent) -> bool {
    v.0.to_string() == DUMMY_PARAM
}

pub fn autospec_return_clause_spec_fn_name(path: &Path) -> Fun {
    let name = path.last_segment();
    let p = path.pop_segment().push_segment(Arc::new(format!("{}{}", name, AUTOSPEC_FUNC_SUFFIX)));
    Arc::new(FunX { path: p })
}

pub fn fn_fp_postcondition_name(op: UninterpretedFloatBinaryOp) -> Fun {
    match op {
        UninterpretedFloatBinaryOp::Add => {
            crate::fun!(CrateId::Vstd => "std_specs", "ops",  "add_ensures")
        }
        UninterpretedFloatBinaryOp::Sub => {
            crate::fun!(CrateId::Vstd => "std_specs", "ops",  "sub_ensures")
        }
        UninterpretedFloatBinaryOp::Mul => {
            crate::fun!(CrateId::Vstd => "std_specs", "ops",  "mul_ensures")
        }
        UninterpretedFloatBinaryOp::Div => {
            crate::fun!(CrateId::Vstd => "std_specs", "ops",  "div_ensures")
        }
        UninterpretedFloatBinaryOp::Eq => {
            crate::fun!(CrateId::Vstd => "std_specs", "cmp",  "eq_ensures")
        }
        UninterpretedFloatBinaryOp::Ne => {
            crate::fun!(CrateId::Vstd => "std_specs", "cmp",  "ne_ensures")
        }
        UninterpretedFloatBinaryOp::Lt => {
            crate::fun!(CrateId::Vstd => "std_specs", "cmp",  "lt_ensures")
        }
        UninterpretedFloatBinaryOp::Gt => {
            crate::fun!(CrateId::Vstd => "std_specs", "cmp",  "gt_ensures")
        }
        UninterpretedFloatBinaryOp::Le => {
            crate::fun!(CrateId::Vstd => "std_specs", "cmp",  "le_ensures")
        }
        UninterpretedFloatBinaryOp::Ge => {
            crate::fun!(CrateId::Vstd => "std_specs", "cmp",  "ge_ensures")
        }
    }
}

pub fn is_anon_const(f: &Fun) -> bool {
    f.path.segments.last().is_some_and(|s| s.starts_with(RUST_DEF_ANON_CONST))
}
