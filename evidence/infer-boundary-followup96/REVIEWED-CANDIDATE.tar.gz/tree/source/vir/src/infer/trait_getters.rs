//! Bounded composition of ordinary exact trait and value query contracts.
//!
//! No name-based model or new axiom: a precondition-free method must ensure
//! result == one matching pure observation with the same arguments. Trait
//! queries use shared receivers/scalar arguments; static value queries also
//! accept an owned receiver and shared context.
//! Normal Verus checks every implementation/default body. Marked declarations
//! are published only after full verification and bound to inference metadata.
use super::*;

#[derive(PartialEq, Eq)]
enum Owner {
    Trait(Path),
    Static,
}

pub(super) fn shared(t: &Typ) -> Option<&Typ> {
    match &**t {
        TypX::Decorate(TypDecoration::Ref, None, t) => Some(t),
        _ => None,
    }
}

fn header(f: &Function, mode: Mode) -> Option<Owner> {
    let x = &f.x;
    let owner = match &x.kind {
        FunctionKind::TraitMethodDecl { trait_path, .. }
            if x.typ_params.len() == 1
                && matches!(x.params.first().and_then(|p|shared(&p.x.typ)).map(|t|&**t),Some(TypX::TypParam(n)) if n==&x.typ_params[0]) =>
        {
            Owner::Trait(trait_path.clone())
        }
        FunctionKind::Static
            if x.typ_params.len() <= 4
                && x.typ_bounds.len() <= 24
                && matches!(
                    x.params.first().map(|p| &**shared(&p.x.typ).unwrap_or(&p.x.typ)),
                    Some(TypX::Datatype(..))
                ) =>
        {
            Owner::Static
        }
        FunctionKind::Static
            if x.typ_params.is_empty()
                && x.typ_bounds.is_empty()
                && x.params.iter().all(|p| eligibility::scalar(&p.x.typ))
                && enums::supported(&x.inner_ret.x.typ) =>
        {
            Owner::Static
        }
        _ => return None,
    };
    if x.mode != mode
        || x.attrs.infer
        || x.attrs.is_external_body
        || x.attrs.is_unsafe
        || x.attrs.is_async
        || x.attrs.prophecy_dependent
        || x.proxy.is_some()
        || !(1..=3).contains(&x.params.len())
        || x.params.iter().any(|p| p.x.mode != mode || p.x.user_mut)
        || x.params.iter().skip(1).any(|p| {
            !eligibility::scalar(&p.x.typ)
                && !(owner == Owner::Static
                    && shared(&p.x.typ)
                        .is_some_and(|t| matches!(&**t, TypX::Datatype(..) | TypX::TypParam(_))))
        })
        || x.inner_ret.x.mode != mode
        || x.outer_ret.x.mode != mode
        || !matches!(x.item_kind, ItemKind::Function)
        || x.attrs.exec_assume_termination
        || x.attrs.exec_allows_no_decreases_clause
        || !x.visibility.is_public()
            && !(owner == Owner::Static
                && x.typ_params.is_empty()
                && x.typ_bounds.is_empty()
                && x.params.iter().all(|p| eligibility::scalar(&p.x.typ))
                && enums::supported(&x.inner_ret.x.typ))
        || !x.require.is_empty()
        || !x.ensure.1.is_empty()
        || x.returns.is_some()
        || !crate::ast_util::types_equal(&x.inner_ret.x.typ, &x.outer_ret.x.typ)
    {
        return None;
    }
    Some(owner)
}

fn local(e: &Expr, name: &VarIdent) -> bool {
    match &e.x {
        ExprX::Var(n) => n == name,
        ExprX::ReadPlace(p, _) => matches!(&p.x,PlaceX::Local(n) if n==name),
        _ => false,
    }
}

pub(super) fn observation(f: &Function) -> bool {
    header(f, Mode::Spec).is_some()
        && f.x.ensure.0.is_empty()
        && !enums::unit(&f.x.inner_ret.x.typ)
        && crate::ast_visitor::typ_visitor_check(&f.x.inner_ret.x.typ, &mut |t| {
            if matches!(&**t, TypX::MutRef(_) | TypX::Decorate(TypDecoration::Ref, ..)) {
                Err(())
            } else {
                Ok(())
            }
        })
        .is_ok()
}

pub(super) fn relation(f: &Function, all: &HashMap<Fun, Function>) -> Option<Function> {
    let owner = header(f, Mode::Exec)?;
    if f.x.ensure.0.len() != 1 {
        return None;
    }
    let ExprX::Binary(BinaryOp::Eq(Mode::Spec), lhs, rhs) = &f.x.ensure.0[0].x else { return None };
    if !local(lhs, &f.x.inner_ret.x.name) {
        return None;
    }
    let ExprX::Call {
        target: CallTarget::Fun(kind, name, types, impls, _),
        args,
        post_args: None,
        body: None,
    } = &rhs.x
    else {
        return None;
    };
    let spec = all.get(name)?;
    if header(spec, Mode::Spec)? != owner
        || !observation(spec)
        || args.len() != f.x.params.len()
        || spec.x.params.len() != f.x.params.len()
        || types.len() != f.x.typ_params.len()
        || spec.x.typ_params != f.x.typ_params
        || !types
            .iter()
            .zip(f.x.typ_params.iter())
            .all(|(t, p)| matches!(&**t,TypX::TypParam(n) if n==p))
        || !impls.is_empty()
        || !args.iter().zip(f.x.params.iter()).all(|(a, p)| local(a, &p.x.name))
        || !spec
            .x
            .params
            .iter()
            .zip(f.x.params.iter())
            .all(|(a, b)| crate::ast_util::types_equal(&a.x.typ, &b.x.typ))
        || !(match owner {
            Owner::Trait(_) => {
                matches!(kind, CallTargetKind::Dynamic)
                    && matches!(&*types[0],TypX::TypParam(n) if n==&f.x.typ_params[0])
            }
            Owner::Static => matches!(kind, CallTargetKind::Static),
        })
        || !crate::ast_util::types_equal(&f.x.inner_ret.x.typ, &rhs.typ)
    {
        return None;
    }
    Some(spec.clone())
}

pub(super) fn prepare(functions: &[Function], imported: &[Function]) -> Vec<Function> {
    let all = crate::infer::pipeline::function_map(functions, imported);
    let mut getters = std::collections::HashSet::new();
    let mut observations = std::collections::HashSet::new();
    for f in functions {
        if let Some(spec) = relation(f, &all) {
            getters.insert(f.x.name.clone());
            observations.insert(spec.x.name.clone());
        }
    }
    functions
        .iter()
        .map(|f| {
            let mut x = f.x.clone();
            let attrs = Arc::make_mut(&mut x.attrs);
            attrs.infer_trait_getter = getters.contains(&x.name);
            attrs.infer_trait_observation = observations.contains(&x.name);
            f.new_x(x)
        })
        .collect()
}

pub(super) fn validate(functions: &[Function]) -> Result<(), VirErr> {
    let all = functions.iter().map(|f| (f.x.name.clone(), f.clone())).collect();
    for f in functions {
        if f.x.attrs.infer_trait_observation && !observation(f)
            || f.x.attrs.infer_trait_getter
                && !relation(f, &all).is_some_and(|s| s.x.attrs.infer_trait_observation)
        {
            return Err(unsupported(&f.span, "invalid certified trait getter contract"));
        }
    }
    Ok(())
}

pub(super) fn source_call(
    e: &Expr,
    all: &HashMap<Fun, Function>,
) -> Option<(Function, Function, Typs, Exprs)> {
    let ExprX::Call {
        target: CallTarget::Fun(kind, name, types, impls, _),
        args,
        post_args: None,
        body: None,
    } = &e.x
    else {
        return None;
    };
    let f = all.get(name)?;
    if !f.x.attrs.infer_trait_getter
        || types.len() != f.x.typ_params.len()
        || args.len() != f.x.params.len()
    {
        return None;
    }
    if !(match header(f, Mode::Exec)? {
        Owner::Trait(_) => {
            matches!(kind, CallTargetKind::Dynamic) && impls.is_empty()
                || matches!(kind, CallTargetKind::DynamicResolved { .. })
        }
        Owner::Static => matches!(kind, CallTargetKind::Static) && impls.is_empty(),
    }) {
        return None;
    }
    let spec = relation(f, all)?;
    if !spec.x.attrs.infer_trait_observation {
        return None;
    }
    Some((f.clone(), spec, types.clone(), args.clone()))
}

pub(super) fn instantiate_source(
    spec: &Function,
    types: &Typs,
    arguments: Vec<Term>,
    bounds: &GenericBounds,
    source: &Expr,
) -> Result<Term, VirErr> {
    let mut value = instantiate(spec, types, arguments, bounds)?;
    if let ExprX::Call {
        target: CallTarget::Fun(CallTargetKind::DynamicResolved { .. }, _, _, impls, _),
        ..
    } = &source.x
    {
        let ExprX::Call {
            target: CallTarget::Fun(kind, name, types, _, attrs),
            args,
            post_args,
            body,
        } = &value.expr.x
        else {
            unreachable!()
        };
        value.expr = value.expr.new_x(ExprX::Call {
            target: CallTarget::Fun(
                kind.clone(),
                name.clone(),
                types.clone(),
                impls.clone(),
                attrs.clone(),
            ),
            args: args.clone(),
            post_args: post_args.clone(),
            body: body.clone(),
        });
    }
    Ok(value)
}

/// Preserve associated types as opaque values. Only explicit associated-type
/// equality bounds are rewritten, with a bounded recursive normalization.
pub(super) fn normalize(t: &Typ, bounds: &GenericBounds) -> Result<Typ, VirErr> {
    fn go(t: &Typ, bounds: &GenericBounds, depth: usize) -> Option<Typ> {
        if depth == 0 {
            return None;
        }
        let t = crate::ast_visitor::map_typ_visitor(t, &|t| {
            if let TypX::Projection { trait_path, trait_typ_args, name } = &**t {
                for b in bounds.iter() {
                    if let GenericBoundX::TypEquality(p, args, n, value) = &**b {
                        if p == trait_path
                            && n == name
                            && args.len() == trait_typ_args.len()
                            && args
                                .iter()
                                .zip(trait_typ_args.iter())
                                .all(|(a, b)| crate::ast_util::types_equal(a, b))
                        {
                            return go(value, bounds, depth - 1).ok_or_else(|| {
                                crate::messages::error_bare(
                                    "Verus Infer incomplete: cyclic associated-type equality",
                                )
                            });
                        }
                    }
                }
            }
            Ok(t.clone())
        })
        .ok()?;
        Some(t)
    }
    go(t, bounds, 8).ok_or_else(|| {
        crate::messages::error_bare(
            "Verus Infer incomplete: associated-type normalization budget exceeded",
        )
    })
}

pub(super) fn instantiate(
    spec: &Function,
    types: &Typs,
    arguments: Vec<Term>,
    bounds: &GenericBounds,
) -> Result<Term, VirErr> {
    let Some(receiver) = arguments.first() else {
        return Err(unsupported(&spec.span, "missing query receiver"));
    };
    let span = receiver.expr.span.clone();
    let ts = spec.x.typ_params.iter().cloned().zip(types.iter().cloned()).collect();
    let ret = normalize(&crate::sst_util::subst_typ(&ts, &spec.x.inner_ret.x.typ), bounds)?;
    if arguments.len() != spec.x.params.len() {
        return Err(unsupported(&span, "trait query arity"));
    }
    let args = arguments
        .into_iter()
        .zip(spec.x.params.iter())
        .map(|(arg, param)| {
            let typ = normalize(&crate::sst_util::subst_typ(&ts, &param.x.typ), bounds)?;
            Ok(records::coerce(&span, arg, &typ)?.expr)
        })
        .collect::<Result<Vec<_>, VirErr>>()?;
    records::atom(SpannedTyped::new(
        &span,
        &ret,
        ExprX::Call {
            target: CallTarget::Fun(
                if matches!(spec.x.kind, FunctionKind::Static) {
                    CallTargetKind::Static
                } else {
                    CallTargetKind::Dynamic
                },
                spec.x.name.clone(),
                types.clone(),
                Arc::new(vec![]),
                CallTargetAttrs {
                    autospec: AutospecUsage::Final,
                    const_var: false,
                    assume_external_allowed: false,
                },
            ),
            args: Arc::new(args),
            post_args: None,
            body: None,
        },
    ))
}

/// Specialize a checked static query whose observation uses its receiver only
/// through a certified direct sequence view. The observation body supplies the
/// meaning; no runtime implementation is inlined or rewritten.
pub(super) fn specialize_view(
    spec: &Function,
    types: &Typs,
    sequence: Term,
    all: &HashMap<Fun, Function>,
    caller: &Function,
) -> Result<Term, VirErr> {
    if !matches!(header(spec, Mode::Spec), Some(Owner::Static)) || spec.x.params.len() != 1 {
        return Err(unsupported(
            &spec.span,
            "constructed receivers require a static unary view observation",
        ));
    }
    if !caller
        .x
        .owning_module
        .as_ref()
        .is_some_and(|m| crate::ast_util::is_body_visible_to(&spec.x.body_visibility, m))
    {
        return Err(unsupported(
            &spec.span,
            "constructed receiver needs a visible observation body",
        ));
    }
    let body = spec.x.body.as_ref().ok_or_else(|| {
        unsupported(&spec.span, "constructed receiver needs a visible observation body")
    })?;
    let ts: HashMap<_, _> = spec.x.typ_params.iter().cloned().zip(types.iter().cloned()).collect();
    let receiver = &spec.x.params[0].x.name;
    let value = crate::ast_visitor::map_expr_visitor_env(
        body,
        &mut crate::ast_visitor::VisitorScopeMap::new(),
        &mut (),
        &|_, _, e| {
            if let ExprX::Call {
                target: CallTarget::Fun(kind, n, ..),
                args,
                post_args: None,
                body: None,
            } = &e.x
            {
                let name = match kind {
                    CallTargetKind::DynamicResolved { resolved, .. } => resolved,
                    _ => n,
                };
                if args.len() == 1
                    && local(&args[0], receiver)
                    && (models::path_is(&n.path, CrateId::Vstd, &["view", "View", "view"])
                        || all.get(name).is_some_and(|f| {
                            f.x.attrs.infer_sequence_view
                                || collections::model(f) == Some(collections::Model::View)
                        }))
                {
                    return Ok(sequence.expr.clone());
                }
            }
            Ok(e.clone())
        },
        &|_, _, s| Ok(vec![s.clone()]),
        &|_, t| Ok(crate::sst_util::subst_typ(&ts, t)),
        &|_, _, p| Ok(p.clone()),
        &|_, _, p| Ok(p.clone()),
    )?;
    crate::ast_visitor::expr_visitor_check(&value, &mut |_, e| {
        if local(e, receiver) {
            return Err(unsupported(
                &e.span,
                "query observation inspects a constructed receiver beyond its view",
            ));
        }
        if let ExprX::Call { target: CallTarget::Fun(kind, n, ..), .. } = &e.x {
            let name = match kind {
                CallTargetKind::DynamicResolved { resolved, .. } => resolved,
                _ => n,
            };
            if !all.get(name).is_some_and(is_pure_observation)
                && !models::path_is(&n.path, CrateId::Vstd, &["view", "View", "view"])
            {
                return Err(unsupported(
                    &e.span,
                    &format!(
                        "view observation needs pure nonprophetic specification vocabulary: {n:?}"
                    ),
                ));
            }
        }
        Ok(())
    })?;
    // Empty spec blocks are syntax, not an additional logical operation.
    let mut value = value;
    while let ExprX::Block(ss, Some(tail)) = &value.x {
        if !ss.is_empty() {
            break;
        }
        value = tail.clone();
    }
    records::atom(value)
}

#[cfg(test)]
mod tests {
    use super::*;
    fn path(name: &str) -> Path {
        Arc::new(PathX {
            krate: CrateId::Id(Arc::new("test".into()), 1),
            segments: Arc::new(vec![Arc::new(name.into())]),
        })
    }
    fn parameter(name: &str) -> Typ {
        Arc::new(TypX::TypParam(Arc::new(name.into())))
    }
    fn projection(trait_name: &str, self_type: Typ, name: &str) -> Typ {
        Arc::new(TypX::Projection {
            trait_path: path(trait_name),
            trait_typ_args: Arc::new(vec![self_type]),
            name: Arc::new(name.into()),
        })
    }
    fn equality(trait_name: &str, self_type: Typ, name: &str, value: Typ) -> GenericBound {
        Arc::new(GenericBoundX::TypEquality(
            path(trait_name),
            Arc::new(vec![self_type]),
            Arc::new(name.into()),
            value,
        ))
    }
    #[test]
    fn nested_associated_equalities_preserve_the_opaque_payload_type() {
        let u = parameter("U");
        let family = parameter("Family");
        let nested = projection("FamilyTrait", projection("Event", u.clone(), "Family"), "Payload");
        let bounds = Arc::new(vec![equality("Event", u, "Family", family.clone())]);
        let result = normalize(&nested, &bounds).unwrap();
        assert!(crate::ast_util::types_equal(
            &result,
            &projection("FamilyTrait", family, "Payload")
        ));
    }
    #[test]
    fn equal_associated_names_from_different_traits_are_not_interchanged() {
        let u = parameter("U");
        let t = projection("A", u.clone(), "Item");
        let bounds = Arc::new(vec![equality("B", u, "Item", parameter("Other"))]);
        assert!(crate::ast_util::types_equal(&normalize(&t, &bounds).unwrap(), &t));
    }
    #[test]
    fn cyclic_associated_equalities_fail_with_a_bounded_diagnostic() {
        let u = parameter("U");
        let t = projection("Event", u.clone(), "Item");
        let bounds = Arc::new(vec![equality("Event", u, "Item", t.clone())]);
        assert!(normalize(&t, &bounds).is_err());
    }
}
