//! Bounded type/visibility inspection; no candidate behavior is assumed here.
use super::*;

pub(in crate::infer) fn root_type(f: &Function) -> Option<&Typ> {
    match &*f.x.params.first()?.x.typ {
        TypX::MutRef(t) | TypX::Decorate(TypDecoration::Ref, None, t) => Some(t),
        TypX::Datatype(..) if value_array_receiver(f) => Some(&f.x.params[0].x.typ),
        _ => None,
    }
}
pub(in crate::infer) fn value_array_receiver(function: &Function) -> bool {
    arrays::shape(&function.x.inner_ret.x.typ).is_some()
        && function.x.params.first().is_some_and(|parameter| {
            matches!(&*parameter.x.typ, TypX::Datatype(Dt::Path(path), ..)
                    if matches!(path.krate, CrateId::Id(..)))
        })
}
pub(in crate::infer) fn readonly_integer_bitwise_receiver(function: &Function) -> bool {
    if bitwise::shape(&function.x.inner_ret.x.typ).is_none()
        || !function.x.params.first().is_some_and(|parameter| {
            matches!(&*parameter.x.typ, TypX::Decorate(TypDecoration::Ref, None, _))
        })
    {
        return false;
    }
    let mut found = false;
    if let Some(body) = &function.x.body {
        crate::ast_visitor::expr_visitor_walk(body, &mut |expression| {
            found |= matches!(&expression.x, ExprX::Binary(BinaryOp::Bitwise(..), ..));
            crate::ast_visitor::VisitorControlFlow::<()>::Recurse
        });
    }
    found
}
pub(super) fn candidate(f: &Function) -> bool {
    root_type(f).is_some_and(|t|matches!(&**t,TypX::Datatype(Dt::Path(p),..)
        if !models::path_is(p,CrateId::Alloc,&["vec","Vec"]) && !models::path_is(p,CrateId::Core,&["option","Option"])))
        && (!mutable(f) || enums::unit(&f.x.inner_ret.x.typ))
}
pub(in crate::infer) fn fields(typ: &Typ, datatypes: &[Datatype]) -> Option<Vec<(FieldOpr, Typ)>> {
    let TypX::Datatype(dt, args, _) = &**typ else { return None };
    let d = datatypes.iter().find(|d| &d.x.name == dt)?;
    if d.x.mode != Mode::Exec
        || d.x.proxy.is_some() && !canonical_range(typ, d)
        || d.x.destructor
        || d.x.user_defined_invariant_fn.is_some()
        || d.x.variants.len() != 1
        || d.x.variants[0].fields.is_empty()
        || d.x.variants[0].fields.len() > 8
        || d.x.typ_params.len() != args.len()
    {
        return None;
    }
    let ts =
        d.x.typ_params.iter().zip(args.iter()).map(|(p, t)| (p.0.clone(), t.clone())).collect();
    d.x.variants[0]
        .fields
        .iter()
        .map(|field| {
            (field.a.1 == Mode::Exec).then(|| {
                (
                    FieldOpr {
                        datatype: dt.clone(),
                        variant: d.x.variants[0].name.clone(),
                        field: field.name.clone(),
                        get_variant: false,
                        check: VariantCheck::None,
                    },
                    crate::sst_util::subst_typ(&ts, &field.a.0),
                )
            })
        })
        .collect()
}

fn canonical_range(typ: &Typ, datatype: &Datatype) -> bool {
    let TypX::Datatype(Dt::Path(path), arguments, _) = &**typ else { return false };
    let definition = &datatype.x;
    models::path_is(path, CrateId::Core, &["ops", "range", "Range"])
        && arguments.len() == 1
        && (matches!(&*arguments[0], TypX::Int(IntRange::U(64)))
            || byte_range_endpoint(&arguments[0]))
        && definition.proxy.as_ref().is_some_and(|proxy| {
            models::path_is(&proxy.x, CrateId::Vstd, &["std_specs", "range", "ExRange"])
        })
        && definition.typ_params.len() == 1
        && definition.sized_constraint.is_none()
        && definition.typ_bounds.len() == 1
        && matches!(&*definition.typ_bounds[0], GenericBoundX::Trait(
            TraitId::Sizedness(Sizedness::Sized), types)
            if types.len() == 1 && matches!(&*types[0], TypX::TypParam(parameter)
                if parameter == &definition.typ_params[0].0))
        && definition.visibility.restricted_to.is_none()
        && matches!(&definition.transparency, DatatypeTransparency::WhenVisible(visibility)
            if visibility.restricted_to.is_none())
        && definition.variants.len() == 1
        && definition.variants[0].name.as_str() == "Range"
        && definition.variants[0].fields.len() == 2
        && ["start", "end"].iter().all(|name| {
            definition.variants[0].fields.iter().any(|field| {
                field.name.as_str() == *name
                    && field.a.1 == Mode::Exec
                    && field.a.2.restricted_to.is_none()
                    && matches!(&*field.a.0, TypX::TypParam(parameter)
                        if parameter == &definition.typ_params[0].0)
            })
        })
}

fn byte_range_endpoint(typ: &Typ) -> bool {
    let byte = |typ: &Typ| matches!(&**typ, TypX::Int(IntRange::U(8)));
    if let Some(arguments) = collections::vec_args(typ) {
        return byte(&arguments[0]) && matches!(&*arguments[1], TypX::Datatype(Dt::Path(path), types, impls)
            if models::path_is(path, CrateId::Alloc, &["alloc", "Global"]) && types.is_empty() && impls.is_empty());
    }
    matches!(&**typ, TypX::Decorate(TypDecoration::Ref, None, inner)
        if matches!(&**inner, TypX::Primitive(Primitive::Slice, types) if types.len() == 1 && byte(&types[0])))
}
/// A bounded value enum. Payload eligibility is checked recursively by value_type,
/// so this descriptor never grants a heap/reference abstraction by itself.
pub(in crate::infer) fn variants(
    typ: &Typ,
    datatypes: &[Datatype],
) -> Option<Vec<(Ident, Vec<(Ident, Typ)>)>> {
    let TypX::Datatype(dt, args, _) = &**typ else {
        return None;
    };
    // Core Option/Result retain their dedicated layouts. In particular, do not
    // admit compiler-internal ControlFlow/Infallible through this value profile.
    if !matches!(dt,Dt::Path(p) if matches!(p.krate,CrateId::Id(..))) {
        return None;
    }
    let d = datatypes.iter().find(|d| &d.x.name == dt)?;
    if d.x.mode != Mode::Exec
        || d.x.proxy.is_some()
        || d.x.destructor
        || d.x.user_defined_invariant_fn.is_some()
        || !(2..=8).contains(&d.x.variants.len())
        || d.x.typ_params.len() > 4
        || d.x.typ_params.len() != args.len()
        || d.x
            .variants
            .iter()
            .any(|v| v.fields.len() > 4 || v.fields.iter().any(|f| f.a.1 != Mode::Exec))
    {
        return None;
    }
    let ts =
        d.x.typ_params.iter().zip(args.iter()).map(|(p, t)| (p.0.clone(), t.clone())).collect();
    Some(
        d.x.variants
            .iter()
            .map(|v| {
                (
                    v.name.clone(),
                    v.fields
                        .iter()
                        .map(|f| (f.name.clone(), crate::sst_util::subst_typ(&ts, &f.a.0)))
                        .collect(),
                )
            })
            .collect(),
    )
}
fn associated_type(t: &Typ, params: &[Ident], depth: usize) -> bool {
    if depth == 0 {
        return false;
    }
    match &**t {
        TypX::TypParam(p) => params.contains(p),
        TypX::Projection { trait_typ_args, .. } => {
            !trait_typ_args.is_empty()
                && trait_typ_args.len() <= 4
                && trait_typ_args.iter().all(|t| associated_type(t, params, depth - 1))
        }
        TypX::Datatype(_, args, _) => {
            args.len() <= 4 && args.iter().all(|t| associated_type(t, params, depth - 1))
        }
        _ => scalar(t),
    }
}

pub(in crate::infer) fn value_type(
    t: &Typ,
    params: &[Ident],
    datatypes: &[Datatype],
    depth: usize,
) -> bool {
    if depth == 0 {
        return false;
    }
    if scalar(t) || arrays::shape(t).is_some() {
        return true;
    }
    match &**t {
        TypX::TypParam(p) => params.contains(p),
        // Associated-type syntax is bounded separately from runtime payload
        // nesting: Option<&(H::Hash,u16)> has the same value shape as (T,u16).
        TypX::Projection { .. } => associated_type(t, params, 4),
        TypX::Datatype(Dt::Tuple(n), ts, _) if *n <= 4 && ts.len() == *n => {
            ts.iter().all(|t| value_type(t, params, datatypes, depth - 1))
        }
        TypX::Datatype(Dt::Path(p), ts, _)
            if models::path_is(p, CrateId::Core, &["option", "Option"]) && ts.len() == 1 =>
        {
            value_type(&ts[0], params, datatypes, depth - 1)
        }
        TypX::Decorate(TypDecoration::Ref, None, t) => value_type(t, params, datatypes, depth - 1),
        _ => {
            fields(t, datatypes).is_some_and(|fs| {
                fs.iter().all(|(_, t)| value_type(t, params, datatypes, depth - 1))
            }) || variants(t, datatypes).is_some_and(|vs| {
                vs.iter().all(|(_, fs)| {
                    fs.iter().all(|(_, t)| value_type(t, params, datatypes, depth - 1))
                })
            })
        }
    }
}
pub(in crate::infer) fn bounds(bounds: &GenericBounds, params: &[Ident]) -> bool {
    let mut recognized = 0;
    for p in params {
        let t = Arc::new(TypX::TypParam(p.clone()));
        let (mut sized, mut copy) = (0, 0);
        for b in bounds.iter() {
            match &**b {
                GenericBoundX::Trait(TraitId::Sizedness(Sizedness::Sized), ts)
                    if ts.len() == 1 && same(&ts[0], &t) =>
                {
                    sized += 1
                }
                GenericBoundX::Trait(TraitId::Path(path), ts)
                    if ts.len() == 1
                        && same(&ts[0], &t)
                        && models::path_is(path, CrateId::Core, &["marker", "Copy"]) =>
                {
                    copy += 1
                }
                _ => {}
            }
        }
        if sized != 1 || copy > 1 {
            return false;
        }
        recognized += sized + copy;
    }
    recognized == bounds.len()
}

fn record_bounds(bounds: &GenericBounds, params: &[Ident]) -> bool {
    bounds.len()<=24 && params.iter().all(|p|bounds.iter().filter(|b|
        matches!(&***b,GenericBoundX::Trait(TraitId::Sizedness(Sizedness::Sized),ts) if ts.len()==1 && matches!(&*ts[0],TypX::TypParam(n) if n==p))).count()==1)
        && bounds.iter().all(|b|match &**b {
            GenericBoundX::Trait(_,ts)=>!ts.is_empty() && ts.len()<=4 && ts.iter().all(|t|associated_type(t,params,4)),
            GenericBoundX::TypEquality(_,ts,_,t)=>!ts.is_empty() && ts.len()<=4 && ts.iter().all(|t|associated_type(t,params,4)) && associated_type(t,params,4),
            _=>false,
        })
}
#[derive(Clone)]
pub(in crate::infer) struct Projection {
    pub op: FieldOpr,
    pub typ: Typ,
}
#[derive(Clone)]
pub(in crate::infer) struct Field {
    pub path: Vec<Projection>,
    pub typ: Typ,
    pub element: Option<Typ>,
    pub view: Option<sequence_views::SequenceView>,
}
#[derive(Clone)]
pub(in crate::infer) struct Shape {
    pub typ: Typ,
    pub fields: Vec<Field>,
}
pub(in crate::infer) fn same_path(a: &[FieldOpr], b: &[FieldOpr]) -> bool {
    a.len() == b.len()
        && a.iter().zip(b).all(|(a, b)| {
            a.datatype == b.datatype
                && a.variant == b.variant
                && a.field == b.field
                && a.check == b.check
                && a.get_variant == b.get_variant
        })
}
/// An unexpanded first-party value can be preserved as a whole. This grants no
/// field equation, collection view, destructor behavior or method contract.
pub(in crate::infer) fn opaque_value(t: &Typ, ds: &[Datatype], owner: &Option<Path>) -> bool {
    let TypX::Datatype(dt, args, _) = &**t else {
        return false;
    };
    ds.iter().any(|d| {
        d.x.name == *dt
            && d.x.mode == Mode::Exec
            && d.x.proxy.is_none()
            && !d.x.destructor
            && args.len() == d.x.typ_params.len()
            && args.len() <= 4
            && !matches!(&d.x.transparency,DatatypeTransparency::WhenVisible(vis)
            if crate::ast_util::is_visible_to_opt(vis,owner))
    })
}

/// An explicit external_type_specification + external_body correspondence may
/// retain a monomorphic opaque identity in an unused readonly record field.
/// This is not a representation model: neither value_type nor opaque_value is
/// extended, and the interpreter rejects executable observations of this leaf.
/// The frontend checks the proxy's actual Rust type and records its destructor;
/// the declaration and complete datatype remain certificate/cache dependencies.
pub(in crate::infer) fn unused_external_value(t: &Typ, ds: &[Datatype]) -> bool {
    let TypX::Datatype(Dt::Path(path), args, _) = &**t else { return false };
    ds.iter().any(|d| {
        d.x.name == Dt::Path(path.clone())
            && args.is_empty()
            && d.x.typ_params.is_empty()
            && d.x.typ_bounds.is_empty()
            && d.x.mode == Mode::Exec
            && matches!(d.x.transparency, DatatypeTransparency::Never)
            && !d.x.destructor
            && !d.x.ext_equal
            && d.x.user_defined_invariant_fn.is_none()
            && d.x.sized_constraint.is_none()
            && d.x.visibility.restricted_to.is_none()
            && d.x.variants.len() == 1
            && d.x.variants[0].fields.is_empty()
            && d.x.proxy.as_ref().is_some_and(|proxy| {
                proxy.x != *path
                    && matches!(proxy.x.krate, CrateId::Id(..))
                    && d.x.owning_module.as_ref().is_some_and(|owner| owner.krate == proxy.x.krate)
            })
    })
}
pub(super) fn shape(
    f: &Function,
    datatypes: &[Datatype],
    all: &HashMap<Fun, Function>,
) -> Result<Shape, VirErr> {
    let bad = || {
        unsupported(
            &f.span,
            "record state requires one transparent record, bounded scalar/Vec fields, value parameters and a supported return",
        )
    };
    let typ = root_type(f).filter(|_| candidate(f)).ok_or_else(bad)?;
    if !mutable(f) && enums::unit(&f.x.inner_ret.x.typ) {
        return Err(unsupported(&f.span, "read-only record queries require a value return"));
    }
    if f.x.params.len() > 8
        || f.x.typ_params.len() > 2
        || !record_bounds(&f.x.typ_bounds, &f.x.typ_params)
        || f.x.params.iter().skip(1).any(|p| {
            matches!(&*p.x.typ, TypX::MutRef(_))
                || trait_getters::shared(&p.x.typ)
                    .is_some_and(|t| !matches!(&**t, TypX::TypParam(_) | TypX::Projection { .. }))
                || !value_type(&p.x.typ, &f.x.typ_params, datatypes, 4)
        })
        || !value_type(&f.x.inner_ret.x.typ, &f.x.typ_params, datatypes, 4)
    {
        return Err(bad());
    }
    fn walk(
        f: &Function,
        t: &Typ,
        ds: &[Datatype],
        path: Vec<Projection>,
        out: &mut Vec<Field>,
        depth: usize,
        all: &HashMap<Fun, Function>,
    ) -> Result<(), VirErr> {
        let bad = || {
            unsupported(
                &f.span,
                "record state requires visible transparent record fields or a certified direct sequence view, bounded depth and at most sixteen leaves",
            )
        };
        if depth == 0 || out.len() >= 16 {
            return Err(bad());
        }
        if unused_external_value(t, ds) {
            if !matches!(&*f.x.params[0].x.typ, TypX::Decorate(TypDecoration::Ref, None, _))
                || path.is_empty()
                || f.x.attrs.infer_allow_approx
            {
                return Err(unsupported(
                    &f.span,
                    "opaque external fields require an exact borrowed readonly record and must remain unused",
                ));
            }
            out.push(Field { path, typ: t.clone(), element: None, view: None });
            return Ok(());
        }
        if let Some(ts) = collections::vec_args(t) {
            // Readonly queries can retain a hidden first-party element as a
            // whole logical value, including its private collection fields.
            // This grants no mutable-element profile or representation law.
            if ts.len() != 2
                || !matches!(&*ts[1],TypX::Datatype(Dt::Path(p),xs,_) if xs.is_empty() && models::path_is(p,CrateId::Alloc,&["alloc","Global"]))
                || !(value_type(&ts[0], &f.x.typ_params, ds, 4)
                    || !mutable(f) && opaque_value(&ts[0], ds, &f.x.owning_module))
            {
                return Err(bad());
            }
            out.push(Field { path, typ: t.clone(), element: Some(ts[0].clone()), view: None });
            return Ok(());
        }
        if let Some(view) = sequence_views::find(t, all, ds) {
            out.push(Field {
                path,
                typ: t.clone(),
                element: Some(view.element.clone()),
                view: Some(view),
            });
            return Ok(());
        }
        if opaque_value(t, ds, &f.x.owning_module) {
            // Whole opaque values can be framed inside a visible record.
            // Mutating an opaque root needs a supported state interface.
            if path.is_empty() && mutable(f) {
                return Err(bad());
            }
            out.push(Field { path, typ: t.clone(), element: None, view: None });
            return Ok(());
        }
        // Ordinary scalar/Option/tuple payloads remain leaves; transparent
        // application records are traversed, including scalar newtype fields.
        if scalar(t)
            || matches!(
                &**t,
                TypX::TypParam(_) | TypX::Projection { .. } | TypX::Datatype(Dt::Tuple(_), ..)
            )
            || matches!(&**t,TypX::Datatype(Dt::Path(p),.. ) if models::path_is(p,CrateId::Core,&["option","Option"]))
        {
            if !value_type(t, &f.x.typ_params, ds, 4) {
                return Err(bad());
            }
            out.push(Field { path, typ: t.clone(), element: None, view: None });
            return Ok(());
        }
        let TypX::Datatype(dt, ..) = &**t else { return Err(bad()) };
        let d = ds.iter().find(|d| &d.x.name == dt).ok_or_else(bad)?;
        if !matches!(&d.x.transparency,DatatypeTransparency::WhenVisible(vis) if crate::ast_util::is_visible_to_opt(vis,&f.x.owning_module))
        {
            return Err(bad());
        }
        for (op, typ) in fields(t, ds).ok_or_else(bad)? {
            let mut path = path.clone();
            path.push(Projection { op, typ: typ.clone() });
            walk(f, &typ, ds, path, out, depth - 1, all)?;
        }
        Ok(())
    }
    let mut leaves = vec![];
    walk(f, typ, datatypes, vec![], &mut leaves, 5, all)?;
    Ok(Shape { typ: typ.clone(), fields: leaves })
}
