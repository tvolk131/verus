use crate::ast::{
    ArithOp, AssertQueryMode, AtomicallyKind, AutospecUsage, BinaryOp, BitshiftBehavior, BitwiseOp,
    BoundsCheck, ByRef, CallTarget, ComputeMode, Constant, Div0Behavior, Dt, Expr, ExprX, FieldOpr,
    Fun, Function, Ident, IntRange, IntegerTypeBoundKind, InvAtomicity, Label, LogicalOp,
    LoopInvariantKind, MaskSpec, Mode, OverflowBehavior, PatternBinding, PatternX, Place, PlaceX,
    SignedDivEdgeCaseBehavior, SpannedTyped, Stmt, StmtX, Typ, TypX, Typs, UnaryOp, UnaryOpr,
    UninterpretedFloatBinaryOp, VarAt, VarBinder, VarBinderX, VarBinders, VarIdent,
    VarIdentDisambiguate, VariantCheck, VirErr,
};
use crate::ast::{BuiltinSpecFun, CrateId, Exprs};
use crate::ast_util::{
    QUANT_FORALL, bitwidth_to_signed_type_string, bool_typ, int_typ, is_unit, types_equal,
    undecorate_typ, unit_typ,
};
use crate::context::Ctx;
use crate::def::{self, Spanned};
use crate::fun;
use crate::inv_masks::{MaskQueryKind, MaskSet};
use crate::messages::{
    Message, Span, ToAny, WarningAllow, error, error_with_label, error_with_secondary_label,
    internal_error,
};
use crate::sst;
use crate::sst::{
    AssertByProvenance, Bnd, BndX, CallFun, Dest, Exp, ExpX, Exps, InternalFun, LocalDecl,
    LocalDeclKind, LocalDeclX, Pars, Stm, StmX, Stms, UniqueIdent,
};
use crate::sst_util::{
    exp_with_vars_at_pre_state, sst_bitwidth, sst_conjoin, sst_disjoin, sst_equal,
    sst_exp_get_proof_note, sst_int_literal, sst_le, sst_lt, sst_mut_ref_current,
    sst_mut_ref_future, sst_unit_value, stm_with_vars_at_pre_state, subst_exp,
    subst_pre_local_decl, subst_stm, subst_typ,
};
use crate::sst_visitor::{map_exp_visitor, map_stm_exp_visitor, stm_visitor_check};
use crate::util::vec_map_result;
use crate::visitor::VisitorControlFlow;
use air::ast::{Binder, BinderX};
use air::messages::Diagnostics;
use air::scope_map::ScopeMap;
use indexmap::IndexSet;
use num_bigint::BigInt;
use num_traits::identities::Zero;
use std::collections::{HashMap, HashSet};
use std::sync::Arc;

#[derive(Clone)]
pub(crate) struct ClosureState {
    ensures: Exps,
    // recommends to check the well-formedness of the ensures clauses themselves
    ensures_checks: crate::sst::Stms,
    dest: UniqueIdent,
}

#[derive(Clone, Copy)]
pub(crate) struct Immutable(pub LocalDeclKind);

#[derive(Clone, Copy)]
pub(crate) enum PreLocalDeclKind {
    /// Any 'immutable' kind
    Immutable(Immutable),
    /// Param (mutability to be inferred)
    Param,
    /// ExecClosureParam (mutability to be inferred)
    ExecClosureParam,
    /// StmtLet (mutability to be inferred)
    StmtLet,
}

#[derive(Clone)]
pub(crate) struct PreLocalDecl {
    pub ident: VarIdent,
    pub typ: Typ,
    pub kind: PreLocalDeclKind,
}

pub(crate) struct State<'a> {
    // View exec/proof code as spec
    // (used for is_const functions, which are viewable both as spec and exec)
    pub(crate) view_as_spec: bool,
    // If Some((f, scc_rep)), translate recursive calls in f's SCC into StmX::Call
    pub(crate) check_spec_decreases: Option<(Fun, crate::recursion::Node)>,
    // Counter to generate temporary variables
    next_var: u64,
    // Collect all local variable declarations
    pre_local_decls: Vec<PreLocalDecl>,
    // Populated by finalize_stm
    mutated_var_idents: HashMap<VarIdent, Span>,
    // Rename variables when needed, using unique integers, to avoid collisions.
    rename_map: ScopeMap<VarIdent, VarIdent>,
    // Track which variable Ident have potentially been used in this scope as Exp-bound
    // (used to remove the numeric id from an Exp-bound variable when it can't
    // shadow another Exp-bound variable)
    rename_exp_idents: ScopeMap<Ident, ()>,
    // Next integer to use for renaming each variable
    rename_counters: HashMap<Ident, u64>,
    // Decide final name in a second pass, when a decision has been made on whether the
    // variable is Exp-bound or Stm-bound.  (We start with Stm-bound, and replace with
    // Exp-bound if possible.)
    rename_delayed: HashMap<VarIdent, VarIdent>,
    // If > 0, we're making a second pass over AST to generate just a pure Exp, with no Stms.
    // Rationale: in the first pass, when checking preconditions of spec functions
    // (e.g. recommends), we may have to generate Stms for the precondition checking,
    // and we may have to generate LocalDecl to support the Stms rather than Exp::Bind.
    // In some situations (e.g. inside a quantifier), we need a pure Exp with Exp::Bind
    // and no Stms instead, so we make a second pass to generate this.
    only_generate_pure_exp: u64,
    // If > 0, disable checking recommends
    pub(crate) disable_recommends: u64,
    // Diagnostic output
    pub diagnostics: &'a (dyn Diagnostics + 'a),
    // If inside a closure
    containing_closure: Option<ClosureState>,
    // Statics that are referenced (not counting statics in loops)
    statics: IndexSet<Fun>,
    pub assert_id_counter: u64,
    loop_id_counter: u64,
    loop_result_dests: HashMap<Label, VarIdent>,

    pub mask: Option<MaskSet>,

    /// Function arguments to be used in the construction of the update
    /// predicate for the atomic update by the atomic function call.
    pub au_pred_args: Vec<crate::sst::Exp>,
    /// This variable is bound by the `atomically |update| { ... }` block
    /// and read by the corresponding `update` function.
    pub au_var_exp: Option<crate::sst::Exp>,
    /// This boolean corresponds to the update control flow of the update
    /// function in the current atomic call, where:
    /// - `Commit` (i.e. `true`) forces the loop to `break`, and
    /// - `Abort` (i.e. `false`) forces the loop to `continue`.
    pub branch_bool_var: Option<(VarIdent, crate::sst::Exp)>,

    /// This is the atomic update bound in the atomic spec,
    /// we must assert `au.resolves()` at the end of the function.
    pub au_var_exp_to_resolve: Option<crate::sst::Exp>,
}

pub(crate) struct FinalState {
    pub local_decls: Vec<LocalDecl>,
    pub statics: IndexSet<Fun>,
}

/// Used to represent the result of a computation that might not terminate
#[derive(Clone, Debug)]
pub(crate) enum Maybe<T> {
    Some(T),
    Never,
}

/// An Exp that remembers if it comes from an "implicit unit"
#[derive(Clone, Debug)]
pub(crate) enum Value {
    Exp(Exp),
    ImplicitUnit(Span),
}

impl Value {
    /// Turn this into a normal Exp
    pub(crate) fn to_exp(self) -> Exp {
        match self {
            Value::Exp(e) => e,
            Value::ImplicitUnit(span) => sst_unit_value(&span),
        }
    }
}

impl<T> Maybe<T> {
    pub(crate) fn is_never(&self) -> bool {
        matches!(self, Maybe::Never)
    }
}

impl Maybe<Value> {
    /// Map `to_exp` over the Some case
    pub(crate) fn to_maybe_exp(self) -> Maybe<Exp> {
        match self {
            Maybe::Some(val) => Maybe::Some(val.to_exp()),
            Maybe::Never => Maybe::Never,
        }
    }

    /// Expect the Some case and return the Exp; panic on the Never case
    pub(crate) fn expect_exp(self) -> Exp {
        match self {
            Maybe::Some(val) => val.to_exp(),
            Maybe::Never => panic!("Maybe::Never unexpected here"),
        }
    }
}

/// Unwraps a Maybe while possibly returning Never. This is sort of like `?`
/// but also deals with the fact that we need to return Stms.
///
/// Specifically: `unwrap_or_return_never!(e, stms)` either unwraps `e` or return
/// `(stms, Maybe::Never)`
macro_rules! unwrap_or_return_never {
    ($e:expr, $stms:expr) => {
        match $e {
            Maybe::Some(e) => e,
            Maybe::Never => {
                return Ok(($stms, Maybe::Never));
            }
        }
    };
    ($e:expr, $stms:expr, $stms2:expr) => {
        match $e {
            Maybe::Some(e) => e,
            Maybe::Never => {
                let mut all_stms = $stms;
                all_stms.extend($stms2);
                return Ok((all_stms, Maybe::Never));
            }
        }
    };
}

/// Like unwrap_or_return_never, but also converts the Value to an Exp
macro_rules! to_exp_or_return_never {
    ($e:expr, $stms:expr) => {
        match $e.to_maybe_exp() {
            Maybe::Some(e) => e,
            Maybe::Never => {
                return Ok(($stms, Maybe::Never));
            }
        }
    };
}

/// Checks the output of Sequencer::push and returns Never if necessary
macro_rules! push_or_return_never {
    ($e:expr) => {
        match $e {
            Some(stms) => {
                return Ok((stms, Maybe::Never));
            }
            None => {}
        }
    };
}

impl<'a> State<'a> {
    pub fn new(diagnostics: &'a dyn Diagnostics) -> Self {
        let mut rename_map = ScopeMap::new();
        let mut rename_exp_idents = ScopeMap::new();
        rename_map.push_scope(true);
        rename_exp_idents.push_scope(true);
        State {
            view_as_spec: false,
            check_spec_decreases: None,
            next_var: 0,
            pre_local_decls: Vec::new(),
            mutated_var_idents: HashMap::new(),
            rename_map,
            rename_exp_idents,
            rename_counters: HashMap::new(),
            rename_delayed: HashMap::new(),
            only_generate_pure_exp: 0,
            disable_recommends: 0,
            diagnostics,
            containing_closure: None,
            statics: IndexSet::new(),
            assert_id_counter: 0,
            loop_id_counter: 0,
            loop_result_dests: HashMap::new(),
            mask: None,
            au_pred_args: Vec::new(),
            au_var_exp_to_resolve: None,
            au_var_exp: None,
            branch_bool_var: None,
        }
    }

    fn next_temp(&mut self, span: &Span, typ: &Typ) -> (VarIdent, Exp) {
        self.next_var += 1;
        let x = def::new_temp_var(self.next_var);
        (x.clone(), SpannedTyped::new(span, typ, ExpX::Var(x.clone())))
    }

    pub(crate) fn push_scope(&mut self) {
        self.rename_map.push_scope(true);
        self.rename_exp_idents.push_scope(true);
    }

    pub(crate) fn pop_scope(&mut self) {
        self.rename_map.pop_scope();
        self.rename_exp_idents.pop_scope();
    }

    pub(crate) fn get_var_unique_id(&self, x: &VarIdent) -> VarIdent {
        match self.rename_map.get(x) {
            None => x.clone(),
            Some(x2) => x2.clone(),
        }
    }

    pub(crate) fn rename_var_general(
        &mut self,
        x: &VarIdent,
        is_stm: bool,
        maybe_exp: bool,
    ) -> VarIdent {
        let does_shadow = self.rename_exp_idents.contains_key(&x.0);
        let id = match self.rename_counters.get(&x.0).copied() {
            None => 0,
            Some(id) => id + 1,
        };
        if maybe_exp {
            let add = if self.rename_exp_idents.contains_key(&x.0) {
                let (scope, _) =
                    self.rename_exp_idents.scope_and_index_of_key(&x.0).expect("scope");
                scope != self.rename_exp_idents.num_scopes() - 1
            } else {
                true
            };
            if add {
                self.rename_exp_idents.insert(x.0.clone(), ()).expect("rename_var");
            }
        }
        let crate::ast::VarIdent(name, d) = x.clone();
        assert!(!matches!(d, VarIdentDisambiguate::VirRenumbered { .. }));
        let d = if is_stm || does_shadow {
            self.rename_counters.insert(x.0.clone(), id);
            // Note that if maybe_exp, we might end up delayed-renaming this later:
            VarIdentDisambiguate::VirRenumbered { is_stmt: is_stm, does_shadow, id }
        } else {
            VarIdentDisambiguate::VirExprNoNumber
        };
        let x2 = crate::ast::VarIdent(name, d);
        if !(is_stm && maybe_exp) {
            self.rename_map.insert(x.clone(), x2.clone()).expect("rename_map");
        }
        x2
    }

    pub(crate) fn rename_var_stm(&mut self, x: &VarIdent) -> VarIdent {
        self.rename_var_general(x, true, false)
    }

    pub(crate) fn rename_var_exp(&mut self, x: &VarIdent) -> VarIdent {
        self.rename_var_general(x, false, true)
    }

    // Note: this does not insert into rename_map; this is done at a later step
    // (see insert_var_maybe_exp) so that it can be inserted into the correct scope
    // (after a push_scope).
    pub(crate) fn rename_var_maybe_exp(&mut self, x: &VarIdent) -> VarIdent {
        self.rename_var_general(x, true, true)
    }

    pub(crate) fn insert_var_maybe_exp(&mut self, x: &VarIdent, x2: &VarIdent) {
        self.rename_map.insert(x.clone(), x2.clone()).expect("rename_map");
    }

    pub(crate) fn rename_delayed_to_exp(&mut self, x: &VarIdent) -> VarIdent {
        let crate::ast::VarIdent(name, d) = x.clone();
        let (does_shadow, id) = match d {
            VarIdentDisambiguate::VirRenumbered { is_stmt: true, does_shadow, id } => {
                (does_shadow, id)
            }
            _ => panic!("rename_delayed called on non-maybe_exp variable"),
        };
        let d = if does_shadow {
            VarIdentDisambiguate::VirRenumbered { is_stmt: false, does_shadow, id }
        } else {
            VarIdentDisambiguate::VirExprNoNumber
        };
        let x2 = crate::ast::VarIdent(name, d);
        self.rename_delayed.insert(x.clone(), x2.clone()).map(|_| panic!("rename_delayed"));
        x2
    }

    pub(crate) fn rename_binders_exp<A: Clone>(
        &mut self,
        binders: &VarBinders<A>,
    ) -> VarBinders<A> {
        let mut bs: Vec<VarBinder<A>> = Vec::new();
        for binder in binders.iter() {
            bs.push(binder.rename(self.rename_var_exp(&binder.name)));
        }
        Arc::new(bs)
    }

    pub(crate) fn rename_delayed_to_exp_binders<A: Clone>(
        &mut self,
        binders: &VarBinders<A>,
    ) -> VarBinders<A> {
        let mut bs: Vec<VarBinder<A>> = Vec::new();
        for binder in binders.iter() {
            bs.push(binder.rename(self.rename_delayed_to_exp(&binder.name)));
        }
        Arc::new(bs)
    }

    pub(crate) fn declare_var_stm(
        &mut self,
        ident: &VarIdent,
        typ: &Typ,
        kind: PreLocalDeclKind,
        may_need_rename: bool,
    ) -> VarIdent {
        let unique_ident = if may_need_rename { self.rename_var_stm(ident) } else { ident.clone() };
        let decl = PreLocalDecl { ident: unique_ident.clone(), typ: typ.clone(), kind };
        self.pre_local_decls.push(decl);
        unique_ident
    }

    pub(crate) fn declare_imm_var_stm(
        &mut self,
        ident: &VarIdent,
        typ: &Typ,
        kind: LocalDeclKind,
        may_need_rename: bool,
    ) -> VarIdent {
        let kind = PreLocalDeclKind::Immutable(Immutable(kind));
        self.declare_var_stm(ident, typ, kind, may_need_rename)
    }

    fn declare_temp_var_stm(
        &mut self,
        span: &Span,
        typ: &Typ,
        kind: PreLocalDeclKind,
    ) -> (VarIdent, Exp) {
        let (temp, temp_var) = self.next_temp(span, typ);
        let temp_id = self.declare_var_stm(&temp, typ, kind, false);
        (temp_id, temp_var)
    }

    fn declare_temp_assign(&mut self, span: &Span, typ: &Typ) -> (VarIdent, Exp) {
        let kind = PreLocalDeclKind::Immutable(Immutable(LocalDeclKind::TempViaAssign));
        self.declare_temp_var_stm(span, typ, kind)
    }

    pub(crate) fn declare_params(&mut self, params: &Pars) {
        for param in params.iter() {
            let name = &param.x.name;
            self.rename_counters.insert(name.0.clone(), 0).map(|_| panic!("rename_counters"));
            self.rename_map.insert(name.clone(), name.clone()).expect("rename_map");
            self.declare_imm_var_stm(
                name,
                &param.x.typ,
                LocalDeclKind::Param { mutable: false },
                false,
            );
        }
    }

    pub(crate) fn finalize_exp(&self, _ctx: &Ctx, exp: &Exp) -> Result<Exp, VirErr> {
        let exp = map_exp_visitor(exp, &mut |exp| match &exp.x {
            ExpX::Var(x) if self.rename_delayed.contains_key(x) => {
                SpannedTyped::new(&exp.span, &exp.typ, ExpX::Var(self.rename_delayed[x].clone()))
            }
            ExpX::Unary(UnaryOp::MustBeFinalized, e1) => e1.clone(),
            _ => exp.clone(),
        });
        Ok(exp)
    }

    pub(crate) fn finalize_stm(&mut self, ctx: &Ctx, stm: &Stm) -> Result<Stm, VirErr> {
        let stm = map_stm_exp_visitor(stm, &|exp| self.finalize_exp(ctx, exp))?;
        stm_visitor_check::<(), _>(&stm, &mut |stm| {
            crate::sst_vars::stm_get_mutations_shallow(stm, &mut self.mutated_var_idents);
            Ok(())
        })
        .unwrap();
        Ok(stm)
    }

    pub(crate) fn finalize(mut self) -> Result<FinalState, VirErr> {
        self.pop_scope();
        assert_eq!(self.rename_map.num_scopes(), 0);
        let mut local_decls = vec![];
        for pre_local_decl in self.pre_local_decls.into_iter() {
            let mutbl = self.mutated_var_idents.get(&pre_local_decl.ident);
            local_decls.push(pre_local_decl.into_local_decl(mutbl)?);
        }
        Ok(FinalState { local_decls, statics: self.statics })
    }

    fn checking_spec_preconditions(&self, ctx: &Ctx) -> bool {
        ctx.checking_spec_preconditions() && self.only_generate_pure_exp == 0
    }

    // For either checking_spec_preconditions or checking_spec_decreases,
    // we have to flatten expressions into statements so the statements can be checked
    // for preconditions or termination
    fn checking_spec_general(&self, ctx: &Ctx) -> bool {
        ctx.checking_spec_general() && self.only_generate_pure_exp == 0
    }

    fn checking_recommends(&self, ctx: &Ctx) -> bool {
        self.checking_spec_preconditions(ctx) && self.disable_recommends == 0
    }

    fn checking_spec_decreases(
        &self,
        ctx: &Ctx,
        target: &Fun,
        resolved_method: &Option<(Fun, Typs)>,
    ) -> bool {
        if ctx.checking_spec_decreases() && self.only_generate_pure_exp == 0 {
            if let Some((recursive_function_name, scc_rep)) = &self.check_spec_decreases {
                if let Some(callee) = crate::recursion::get_callee(ctx, target, resolved_method) {
                    return &callee == recursive_function_name
                        || &ctx
                            .global
                            .func_call_graph
                            .get_scc_rep(&crate::recursion::Node::Fun(callee.clone()))
                            == scc_rep;
                }
            }
        }
        false
    }

    pub fn next_assert_id(&mut self) -> Option<air::ast::AssertId> {
        let aid = vec![self.assert_id_counter];
        self.assert_id_counter += 1;
        Some(Arc::new(aid))
    }

    /// Creates a new tmp var and adds a Stm to the stms vec asserting the new
    /// temp var is equal to the given exp. Returns an exp for the temp var.
    pub fn make_tmp_var_for_exp(&mut self, stms: &mut Vec<Stm>, exp: Exp) -> Exp {
        let (temp_id, temp_var) = self.declare_temp_assign(&exp.span, &exp.typ);
        stms.push(init_var(&exp.span, &temp_id, &exp));
        temp_var
    }
}

impl PreLocalDecl {
    fn into_local_decl(self, mutbl: Option<&Span>) -> Result<LocalDecl, VirErr> {
        Ok(Arc::new(LocalDeclX {
            ident: self.ident,
            typ: self.typ,
            kind: self.kind.into_local_decl_kind(mutbl)?,
        }))
    }
}

impl PreLocalDeclKind {
    fn into_local_decl_kind(self, mutbl: Option<&Span>) -> Result<LocalDeclKind, VirErr> {
        match self {
            PreLocalDeclKind::Immutable(Immutable(imm)) => {
                if let Some(span) = mutbl {
                    Err(error(
                        span,
                        format!(
                            "Verus Internal Error: assignment for immutable decl kind {:?}",
                            imm
                        ),
                    ))
                } else {
                    Ok(imm)
                }
            }
            PreLocalDeclKind::Param => Ok(LocalDeclKind::Param { mutable: mutbl.is_some() }),
            PreLocalDeclKind::ExecClosureParam => {
                Ok(LocalDeclKind::ExecClosureParam { mutable: mutbl.is_some() })
            }
            PreLocalDeclKind::StmtLet => Ok(LocalDeclKind::StmtLet { mutable: mutbl.is_some() }),
        }
    }
}

pub(crate) fn var_loc_exp(span: &Span, typ: &Typ, lhs: UniqueIdent) -> Exp {
    SpannedTyped::new(span, typ, ExpX::VarLoc(lhs))
}

pub(crate) fn init_var(span: &Span, x: &UniqueIdent, exp: &Exp) -> Stm {
    Spanned::new(
        span.clone(),
        StmX::Assign {
            lhs: Dest { dest: var_loc_exp(&exp.span, &exp.typ, x.clone()), is_init: true },
            rhs: exp.clone(),
        },
    )
}

pub(crate) fn get_function(ctx: &Ctx, span: &Span, name: &Fun) -> Result<Function, VirErr> {
    match ctx.func_map.get(name) {
        None => Err(error(span, format!("could not find function {:?}", name))),
        Some(func) => Ok(func.clone()),
    }
}

pub(crate) fn get_function_sst(
    ctx: &Ctx,
    span: &Span,
    name: &Fun,
) -> Result<crate::sst::FunctionSst, VirErr> {
    match ctx.func_sst_map.get(name) {
        None => Err(error(span, format!("could not find function {:?}", name))),
        Some(func) => Ok(func.clone()),
    }
}

pub(crate) fn ens_has_return(ctx: &Ctx, function: &Function) -> bool {
    match &function.x.kind {
        crate::ast::FunctionKind::TraitMethodImpl { method, .. } => {
            let method = &ctx.func_map[method];
            !is_unit(&undecorate_typ(&method.x.outer_ret.x.typ))
        }
        _ => !is_unit(&undecorate_typ(&function.x.outer_ret.x.typ)),
    }
}

fn function_can_be_exp(
    ctx: &Ctx,
    state: &State,
    expr: &Expr,
    path: &Fun,
    resolved_method: &Option<(Fun, Typs)>,
) -> Result<bool, VirErr> {
    let fun = get_function(ctx, &expr.span, path)?;
    match fun.x.mode {
        Mode::Spec if state.checking_spec_decreases(ctx, path, resolved_method) => Ok(false),
        Mode::Spec => Ok(!state.checking_recommends(ctx) || fun.x.require.len() == 0),
        Mode::Proof | Mode::Exec => Ok(false),
    }
}

pub fn assume_false(span: &Span) -> Stm {
    let expx = ExpX::Const(Constant::Bool(false));
    let exp = SpannedTyped::new(&span, &Arc::new(TypX::Bool), expx);
    Spanned::new(span.clone(), StmX::Assume(exp))
}

pub(crate) fn assume_has_typ(x: &UniqueIdent, typ: &Typ, span: &Span) -> Stm {
    let xvarx = ExpX::Var(x.clone());
    let xvar = SpannedTyped::new(span, typ, xvarx);
    let has_typx = ExpX::UnaryOpr(UnaryOpr::HasType(typ.clone()), xvar);
    let has_typ = SpannedTyped::new(span, &Arc::new(TypX::Bool), has_typx);
    Spanned::new(span.clone(), StmX::Assume(has_typ))
}

fn loop_body_find_breaks(
    loop_label: &Label,
    num_breaks: &mut usize,
    num_isolated_breaks: &mut usize,
    in_isolated: bool,
    body: &Expr,
) {
    let mut f = |expr: &Expr| match &expr.x {
        ExprX::Loop { loop_isolation: true, .. } if !in_isolated => {
            loop_body_find_breaks(loop_label, num_breaks, num_isolated_breaks, true, expr);
            VisitorControlFlow::Return
        }
        ExprX::BreakOrContinue { label: break_label, is_break: true, .. } => {
            if break_label == loop_label {
                *num_breaks += 1;
                if in_isolated {
                    *num_isolated_breaks += 1;
                }
            }
            VisitorControlFlow::Recurse
        }
        _ => VisitorControlFlow::Recurse,
    };
    crate::ast_visitor::expr_visitor_walk(body, &mut f);
}

/// Returns (num_breaks, num_isolated_breaks):
///  * `num_breaks` = Total # of break statements of the given label
///  * `num_isolated_breaks` = # of break statements of the given label
///    that are within a loop_isolation=true loop
fn loop_has_breaks(loop_label: &Label, expr: &Expr) -> (usize, usize) {
    let mut num_breaks = 0;
    let mut num_isolated_breaks = 0;
    loop_body_find_breaks(loop_label, &mut num_breaks, &mut num_isolated_breaks, false, expr);
    (num_breaks, num_isolated_breaks)
}

/// Determine if it's possible for control flow to reach the statement after the loop exit.
/// To be conservative, we need to answer 'yes' (true) if we can't tell.
pub fn can_control_flow_reach_after_loop(expr: &Expr) -> bool {
    match &expr.x {
        ExprX::Loop { label, cond: None, body, .. } => loop_has_breaks(label, body).0 > 0,
        ExprX::Loop { cond: Some(_), .. } => true,
        _ => {
            panic!("expected while loop");
        }
    }
}

/// The `Sequencer` struct should be used for most nodes that have multiple Exprs as input
/// in order to make sure the resulting Stms and Exps have the right ordering.
///
/// Given a bunch of Exprs, e.g., Expr[0], Expr[1], ..., then upon immediate lowering,
/// each Expr becomes a (Vec<Stm>, Exp), which together make sense when evaluated in the
/// following order:
///
///    stms[0], exps[0], stms[1], exps[1], ...
///
/// However, what we _need_ is to put all the Stms together at the beginning and the Exps at
/// the end, so we can input the Exps to the computation of interest (e.g., function call,
/// binary op, etc.). However, later Stms might change the meaning of earlier Exps (which
/// can happen if the Stms contain assignments to variables which are read by the Exps).
///
/// The purpose of the `Sequencer` object is to safely commute all the Exps to the end.
struct Sequencer {
    stms: Vec<Vec<Stm>>,
    exps: Vec<(Exp, Immutable, Option<Exp>)>,
}

impl Sequencer {
    fn new() -> Self {
        Sequencer { stms: vec![], exps: vec![] }
    }

    /// Append the given Stms and Maybe<Value>.
    /// In the event that the Maybe<Value> is a Never, this will return all the Stms pushed
    /// up this point (including the Stms from the present call).
    ///
    /// The `kind` argument is the LocalDeclKind that should be used in the event that a
    /// temporary is created.
    #[must_use]
    fn push(&mut self, stms: Vec<Stm>, rv: Maybe<Value>, kind: Immutable) -> Option<Vec<Stm>> {
        self.stms.push(stms);
        match rv.to_maybe_exp() {
            Maybe::Some(e) => {
                self.exps.push((e, kind, None));
                None
            }
            Maybe::Never => {
                let all_stms = std::mem::take(&mut self.stms).into_iter().flatten().collect();
                Some(all_stms)
            }
        }
    }

    /// Append the given Stms and the borrow for the two-phase borrow.
    /// This enables extra validation checks.
    #[must_use]
    fn push_2phase<T>(
        &mut self,
        stms: Vec<Stm>,
        rv: &Maybe<(BorrowMutSst, T)>,
        kind: Immutable,
    ) -> Option<Vec<Stm>> {
        self.stms.push(stms);
        match rv {
            Maybe::Some((borrow_mut_sst, _)) => {
                let e = borrow_mut_sst.mut_ref_exp.clone();
                let loc = borrow_mut_sst.loc.clone();
                self.exps.push((e, kind, Some(loc)));
                None
            }
            Maybe::Never => {
                let all_stms = std::mem::take(&mut self.stms).into_iter().flatten().collect();
                Some(all_stms)
            }
        }
    }

    /// Upon completion, turn all the inputted data into (Stms, Exps) that can be evaluated
    /// in that order.
    fn into_stms_exps(self, state: &mut State) -> Result<(Vec<Stm>, Vec<Exp>), VirErr> {
        assert!(self.stms.len() == self.exps.len() || self.stms.len() == self.exps.len() + 1);

        self.validate_2phase()?;

        let mut largest_idx_with_stm = None;
        for i in (0..self.stms.len()).rev() {
            if self.stms[i].len() > 0 {
                largest_idx_with_stm = Some(i);
                break;
            }
        }

        let mut final_stms = self.stms;
        let mut final_exps = vec![];

        for i in 0..self.exps.len() {
            let (arg, kind, _) = &self.exps[i];

            // Create a temporary for any exp that comes before a stm
            if largest_idx_with_stm.is_some()
                && i < largest_idx_with_stm.unwrap()
                && !matches!(&arg.x, ExpX::Loc(_))
            {
                let (temp_id, temp_var) = state.declare_temp_var_stm(
                    &arg.span,
                    &arg.typ,
                    PreLocalDeclKind::Immutable(*kind),
                );
                final_exps.push(temp_var);
                final_stms[i].push(init_var(&arg.span, &temp_id, arg));
            } else {
                final_exps.push(arg.clone());
            }
        }

        let final_stms = final_stms.into_iter().flatten().collect::<Vec<_>>();
        Ok((final_stms, final_exps))
    }

    /// Helper for the special case of binary ops
    fn into_stms_exps_expect_2(self, state: &mut State) -> Result<(Vec<Stm>, Exp, Exp), VirErr> {
        let (stms, exps) = self.into_stms_exps(state)?;
        assert!(exps.len() == 2);
        Ok((stms, exps[0].clone(), exps[1].clone()))
    }

    /// Use this when there are extra Stms at the end that don't go with any of the
    /// expressions
    /// i.e. if we have
    ///    stms[0], exps[0], stms[1], exps[1], ... stms[n], exps[n], stms[n+1]
    /// Then pass stms[n+1] as the argument to this function
    fn into_stms_exps_with_extra(
        self,
        state: &mut State,
        stms: Vec<Stm>,
    ) -> Result<(Vec<Stm>, Vec<Exp>), VirErr> {
        let mut s = self;
        s.stms.push(stms);
        s.into_stms_exps(state)
    }

    /// Check that there are no assignments that interfere with 2-phase borrows,
    /// i.e., for each two-phase borrow, check there are no assignments from that point until
    /// the end that interfere with the borrow.
    ///
    /// Such a case is *usually* caught by borrow-checking, but there are some cases
    /// that rustc accepts which our encoding doesn't handle properly, e.g.,
    ///
    /// Two-phase borrow notation below is compiler pseudocode, not Rust syntax:
    ///
    /// ```text
    /// let mut r: &mut T = ...;
    /// f(&mut[two_phase] *r, { r = something; true });
    /// ```
    ///
    /// This is allowed by `r = something` overwrites the pointer itself, so it doesn't
    /// interfere with the borrowed-from location, but our encoding always treats `*r`
    /// as the "same place". Fortunately, such a case ought to be exceedingly rare,
    /// so we don't need to support it, just check for it.
    fn validate_2phase(&self) -> Result<(), VirErr> {
        for i in 0..self.exps.len() {
            if let Some(loc) = &self.exps[i].2 {
                // Skip the last entry in stms, so only iterate up to self.exps.len()
                for j in i + 1..self.exps.len() {
                    for stm in self.stms[j].iter() {
                        if let Some(span) = crate::sst_vars::find_overlapping_assignment(stm, loc) {
                            return Err(error_with_label(
                                &loc.span,
                                "Verus doesn't support assigning during mutable borrow like this",
                                "this borrow",
                            )
                            .secondary_label(&span, "followed by this assignment"));
                        }
                    }
                }
            }
        }
        Ok(())
    }
}

#[derive(Debug)]
struct ReturnedCall {
    fun: Fun,
    resolved_method: Option<(Fun, Typs)>,
    is_trait_default: Option<bool>,
    typs: Typs,
    has_return: bool,
    args: Exps,
    obligations: Vec<Obligation>,
    may_unwind: bool,
    body: Option<Stm>,
}

fn get_call_args(
    ctx: &Ctx,
    state: &mut State,
    args: &Exprs,
    post_args: &Option<Expr>,
    body: &Option<Expr>,
    function_kind: &crate::ast::FunctionKind,
    function_mode: Mode,
    function_typ_params: &[Ident],
    function_typ_args: &[Typ],
    function_params: &crate::ast::Params,
) -> Result<(Vec<Stm>, Vec<Obligation>, Option<Vec<Exp>>, Option<Stm>), VirErr> {
    let mut sequr = Sequencer::new();

    // Suppose have as arguments:
    //   TwoPhaseBorrowMut(p1)
    //   TwoPhaseBorrowMut(p2)
    //
    // Then the "second phase" of these arguments goes after the argument evaluation.
    // So the result would look like:
    //
    //  eval p1
    //  eval p2
    //  Phase2 mutation for p1
    //  Phase2 mutation for p2
    //  post_args
    //  execute the "call"
    //
    // Note that the "post_args" may contain AssumeResolved statements inserted
    // by the resolution inference; these are supposed to go after the phase2
    // mutations.

    // delayed "phase2" Stms
    let mut second_phase: Vec<Stm> = Vec::new();
    let mut all_obligations: Vec<Obligation> = Vec::new();
    let mut atomically: Option<&Expr> = None;

    for (k, arg) in args.iter().enumerate() {
        let poly = crate::poly::arg_is_poly(ctx, &function_kind, function_mode, &arg.typ);
        let kind = Immutable(LocalDeclKind::StmCallArg { native: !poly });

        match &arg.x {
            ExprX::AtomicUpdateInitDummy => {
                assert_eq!(k + 1, args.len());
                atomically = Some(arg);
                break;
            }
            ExprX::TwoPhaseBorrowMut(_) => {
                let (phase1_stms, bor_sst) = borrow_mut_to_sst(ctx, state, arg)?;

                let early_return = sequr.push_2phase(phase1_stms, &bor_sst, kind);
                if let Some(stms) = early_return {
                    return Ok((stms, all_obligations, None, None));
                }

                let Maybe::Some((bor_sst, obligations)) = bor_sst else { unreachable!() };
                second_phase.push(bor_sst.phase2_stm);
                all_obligations.extend(obligations);
            }
            _ => {
                let (stms0, e0) = expr_to_stm_opt_with_delayed_obligations(ctx, state, &arg)?;

                let exp0 = match &e0 {
                    Maybe::Never => Maybe::Never,
                    Maybe::Some((exp0, _obligations)) => Maybe::Some(exp0.clone()),
                };

                let early_return = sequr.push(stms0, exp0, kind);
                if let Some(stms) = early_return {
                    return Ok((stms, all_obligations, None, None));
                }

                let Maybe::Some((_exp0, obligations)) = e0 else { unreachable!() };
                all_obligations.extend(obligations);
            }
        };
    }

    if let Some(post_args) = post_args {
        let (mut stms0, e0) = expr_to_stm_opt(ctx, state, post_args)?;
        assert!(matches!(e0, Maybe::Some(Value::ImplicitUnit(_))));
        second_phase.append(&mut stms0);
    }

    let (mut stms, mut exps) = sequr.into_stms_exps_with_extra(state, second_phase)?;

    if let Some(expr) = atomically {
        assert_eq!(function_typ_params.len(), function_typ_args.len());
        let typ_substs: HashMap<Ident, Typ> =
            function_typ_params.iter().cloned().zip(function_typ_args.iter().cloned()).collect();

        for (exp, param) in std::iter::zip(&mut exps, function_params.iter()) {
            let tmp = state.make_tmp_var_for_exp(&mut stms, exp.clone());
            let param_typ = subst_typ(&typ_substs, &param.x.typ);
            *exp = SpannedTyped::new(&tmp.span, &param_typ, tmp.x.clone());
        }

        state.au_pred_args = exps.clone();
        let (au_stms, value) = expr_to_stm_opt(ctx, state, expr)?;
        let au_exp = value.expect_exp();

        stms.extend(au_stms);
        exps.push(au_exp);
    }

    let body = match body {
        Some(expr) => {
            let (stms, _) = expr_to_stm_opt(ctx, state, expr)?;
            stms_to_one_stm_opt(&expr.span, stms)
        }
        None => None,
    };

    Ok((stms, all_obligations, Some(exps), body))
}

fn expr_get_call(
    ctx: &Ctx,
    state: &mut State,
    disallow_poly_ret: Option<&Typ>,
    expr: &Expr,
) -> Result<Option<(Vec<Stm>, Maybe<ReturnedCall>)>, VirErr> {
    match &expr.x {
        ExprX::Call { target, args, post_args, body } => match target {
            CallTarget::FnSpec(..) => {
                panic!("internal error: CallTarget::FnSpec");
            }
            CallTarget::Fun(kind, x, typs, _impl_paths, attrs) => {
                if attrs.autospec != AutospecUsage::Final {
                    return Err(internal_error(&expr.span, "autospec not discharged"));
                }
                let function = get_function(ctx, &expr.span, x)?;
                let has_ret = ens_has_return(ctx, &function);
                if disallow_poly_ret.is_some()
                    && has_ret
                    && crate::poly::ret_needs_native(
                        ctx,
                        &function.x.kind,
                        &function.x.outer_ret.x.typ,
                        disallow_poly_ret.unwrap(),
                    )
                {
                    // Anticipate that poly.rs will need to coerce the result from poly to native,
                    // so we return None to force the creation of a temp variable for the coercion.
                    // TODO: in the long run, this would make more sense to handle entirely
                    // in poly.rs, but for now, we continue to handle this here to avoid
                    // disrupting the old behavior.
                    return Ok(None);
                }

                let (stms, all_obligations, exps, body) = get_call_args(
                    ctx,
                    state,
                    args,
                    post_args,
                    body,
                    &function.x.kind,
                    function.x.mode,
                    &function.x.typ_params,
                    typs,
                    &function.x.params,
                )?;
                let Some(exps) = exps else {
                    return Ok(Some((stms, Maybe::Never)));
                };

                use crate::ast::{CallTargetKind, FunctionKind};
                let is_trait_default =
                    if let FunctionKind::TraitMethodDecl { has_default: true, .. } =
                        &function.x.kind
                    {
                        match kind {
                            CallTargetKind::Static => None,
                            CallTargetKind::ProofFn(..) => None,
                            CallTargetKind::Dynamic => Some(false),
                            CallTargetKind::DynamicResolved { is_trait_default, .. } => {
                                Some(*is_trait_default)
                            }
                            CallTargetKind::ExternalTraitDefault => Some(true),
                        }
                    } else {
                        None
                    };
                Ok(Some((
                    stms,
                    Maybe::Some(ReturnedCall {
                        fun: x.clone(),
                        resolved_method: kind.resolved(),
                        is_trait_default,
                        typs: typs.clone(),
                        has_return: has_ret,
                        args: Arc::new(exps),
                        obligations: all_obligations,
                        may_unwind: !crate::ast_util::call_no_unwind(target, &ctx.func_map),
                        body,
                    }),
                )))
            }
            CallTarget::BuiltinSpecFun(_, _, _) => {
                panic!("internal error: CallTarget::BuiltinSpecFn");
            }
            CallTarget::AssumeExternal => {
                panic!("internal error: CallTarget::AssumeExternal");
            }
        },
        _ => Ok(None),
    }
}

// If the Expr is a call that must be a Stm (not an Exp), return it
fn expr_must_be_call_stm(
    ctx: &Ctx,
    state: &mut State,
    disallow_poly_ret: Option<&Typ>,
    expr: &Expr,
) -> Result<Option<(Vec<Stm>, Maybe<ReturnedCall>)>, VirErr> {
    match &expr.x {
        ExprX::Call {
            target: CallTarget::Fun(kind, x, _, _, _),
            args: _,
            post_args: _,
            body: _,
        } if !function_can_be_exp(ctx, state, expr, x, &kind.resolved())? => {
            expr_get_call(ctx, state, disallow_poly_ret, expr)
        }
        _ => Ok(None),
    }
}

fn place_must_be_call_stm(
    ctx: &Ctx,
    state: &mut State,
    disallow_poly_ret: Option<&Typ>,
    place: &Place,
) -> Result<Option<(Vec<Stm>, Maybe<ReturnedCall>)>, VirErr> {
    match &place.x {
        PlaceX::Temporary(t) => expr_must_be_call_stm(ctx, state, disallow_poly_ret, t),
        _ => Ok(None),
    }
}

// Check spec preconditions in expr, but don't generate an Exp for Expr
pub(crate) fn check_pure_expr(
    ctx: &Ctx,
    state: &mut State,
    expr: &Expr,
) -> Result<Vec<Stm>, VirErr> {
    if state.checking_spec_general(ctx) {
        let (stms, _exp) = expr_to_stm_or_error(ctx, state, expr)?;
        Ok(stms)
    } else {
        Ok(vec![])
    }
}

// Check spec preconditions in expr, but don't generate an Exp for Expr
// Declare variables from binders as locals for checking
fn check_pure_expr_bind(
    ctx: &Ctx,
    state: &mut State,
    binders: &VarBinders<Typ>,
    kind: PreLocalDeclKind,
    expr: &Expr,
) -> Result<Vec<Stm>, VirErr> {
    if state.checking_spec_general(ctx) {
        state.push_scope();
        let mut stms: Vec<Stm> = Vec::new();
        for binder in binders.iter() {
            let x = state.declare_var_stm(&binder.name, &binder.a, kind, true);
            stms.push(assume_has_typ(&x, &binder.a, &expr.span));
        }
        let (stms1, _exp) = expr_to_stm_or_error(ctx, state, expr)?;
        stms.extend(stms1);
        state.pop_scope();
        Ok(stms)
    } else {
        Ok(vec![])
    }
}

// This skips the spec precondition checks (e.g. recommends),
// so only use this if there's some justification (i.e. checks happen elsewhere).
// Otherwise, call expr_to_pure_exp_check.
pub(crate) fn expr_to_pure_exp_skip_checks(
    ctx: &Ctx,
    state: &mut State,
    expr: &Expr,
) -> Result<Exp, VirErr> {
    state.only_generate_pure_exp += 1;
    let (stms, exp) = expr_to_stm_or_error(ctx, state, expr)?;
    let result = if stms.len() == 0 {
        Ok(exp)
    } else {
        Err(error(&expr.span, "expected pure mathematical expression"))
    };
    state.only_generate_pure_exp -= 1;
    result
}

// For handling recommends, we need to generate both a recommends check of a pure expression
// and the pure expression itself.
pub(crate) fn expr_to_pure_exp_check(
    ctx: &Ctx,
    state: &mut State,
    expr: &Expr,
) -> Result<(Vec<Stm>, Exp), VirErr> {
    if state.checking_spec_general(ctx) {
        let (stms, exp) = expr_to_stm_or_error(ctx, state, expr)?;
        if stms.len() == 0 {
            return Ok((vec![], exp));
        } else {
            // Discard exp here, but keep stms.
            // exp may depend on stms, so we can't use it as a self-contained pure Exp,
            // so we need to call expr_to_pure_exp_skip_checks to generate a second Exp.
            // It's inefficient to generate exp and throw it away, but
            // it's hard to see what else to do, since the structure of exp
            // may differ substantially from expr_to_pure_exp_skip_checks(ctx, state, expr)?.
            Ok((stms, expr_to_pure_exp_skip_checks(ctx, state, expr)?))
        }
    } else {
        Ok((vec![], expr_to_pure_exp_skip_checks(ctx, state, expr)?))
    }
}

pub(crate) fn expr_to_pure_exp_check_with_typ_substs(
    ctx: &Ctx,
    state: &mut State,
    expr: &Expr,
    typ_substs: &HashMap<Ident, Typ>,
) -> Result<(Vec<Stm>, Exp), VirErr> {
    let local_decls_init_len = state.pre_local_decls.len();

    let (stms, exp) = expr_to_pure_exp_check(ctx, state, expr)?;

    let exp = subst_exp(typ_substs, &HashMap::new(), &exp);
    let stms: Vec<_> =
        stms.iter().map(|stm| subst_stm(typ_substs, &HashMap::new(), &stm)).collect();

    let local_decls_new_len = state.pre_local_decls.len();
    for i in local_decls_init_len..local_decls_new_len {
        state.pre_local_decls[i] = subst_pre_local_decl(typ_substs, &state.pre_local_decls[i]);
    }

    Ok((stms, exp))
}

pub(crate) fn expr_to_decls_exp_skip_checks(
    ctx: &Ctx,
    diagnostics: &dyn Diagnostics,
    view_as_spec: bool,
    params: &Pars,
    expr: &Expr,
) -> Result<(Vec<LocalDecl>, Exp), VirErr> {
    let mut state = State::new(diagnostics);
    state.view_as_spec = view_as_spec;
    state.declare_params(params);
    let exp = expr_to_pure_exp_skip_checks(ctx, &mut state, expr)?;
    let exp = state.finalize_exp(ctx, &exp)?;
    let FinalState { local_decls, statics: _ } = state.finalize()?;
    Ok((local_decls, exp))
}

pub(crate) fn expr_to_bind_decls_exp_skip_checks(
    ctx: &Ctx,
    diagnostics: &impl Diagnostics,
    params: &Pars,
    expr: &Expr,
) -> Result<Exp, VirErr> {
    let mut state = State::new(diagnostics);
    state.declare_params(params);
    let exp = expr_to_pure_exp_skip_checks(ctx, &mut state, expr)?;
    let exp = state.finalize_exp(ctx, &exp)?;
    state.finalize()?;
    Ok(exp)
}

pub(crate) fn expr_to_exp_skip_checks(
    ctx: &Ctx,
    diagnostics: &dyn Diagnostics,
    params: &Pars,
    expr: &Expr,
) -> Result<Exp, VirErr> {
    Ok(expr_to_decls_exp_skip_checks(ctx, diagnostics, false, params, expr)?.1)
}

/// Convert an expr to (Vec<Stm>, Exp).
/// Errors if the given expression is one that never returns a value.
/// (This should only be used in contexts where that should never happen, like spec
/// contexts. Otherwise, call `expr_to_stm_opt` and handle the Never case).
pub(crate) fn expr_to_stm_or_error(
    ctx: &Ctx,
    state: &mut State,
    expr: &Expr,
) -> Result<(Vec<Stm>, Exp), VirErr> {
    let (stms, exp_opt) = expr_to_stm_opt(ctx, state, expr)?;
    match exp_opt.to_maybe_exp() {
        Maybe::Some(e) => Ok((stms, e)),
        Maybe::Never => Err(error(&expr.span, "expression must produce a value")),
    }
}

pub(crate) fn stms_to_one_stm(span: &Span, stms: Vec<Stm>) -> Stm {
    if stms.len() == 1 {
        stms[0].clone()
    } else {
        Spanned::new(span.clone(), StmX::Block(Arc::new(stms)))
    }
}

pub(crate) fn stms_to_one_stm_opt(span: &Span, stms: Vec<Stm>) -> Option<Stm> {
    if stms.len() == 0 { None } else { Some(stms_to_one_stm(span, stms)) }
}

fn assert_atomic_update_resolves(
    ctx: &Ctx,
    state: &mut State,
    stms: &mut Vec<Stm>,
    error: impl FnOnce(Message) -> Message,
) {
    if state.checking_recommends(ctx) {
        return;
    }

    let Some(au_exp) = &state.au_var_exp_to_resolve else { return };

    let au_span = &au_exp.span;
    let TypX::Datatype(_, typ_args, _) = au_exp.typ.as_ref() else {
        panic!("atomic update type should be a datatype")
    };

    let call_resolves = ExpX::Call(
        CallFun::Fun(def::fn_au_resolves(), None),
        typ_args.clone(),
        Arc::new(vec![au_exp.clone()]),
    );

    let call_resolves = SpannedTyped::new(au_span, &Arc::new(TypX::Bool), call_resolves);
    let base_error = error_with_label(
        &au_span,
        "cannot show atomic update resolves at end of function",
        "unresolved atomic update",
    );

    let error = error(base_error);

    stms.push(Spanned::new(
        au_span.clone(),
        StmX::Assert(state.next_assert_id(), Some(error), call_resolves),
    ));
}

/// Convert the expression to a Stm, and assert the post-conditions for
/// the final returned expression.
pub(crate) fn expr_to_one_stm_with_post(
    ctx: &Ctx,
    state: &mut State,
    expr: &Expr,
    func_span: &Span,
) -> Result<Stm, VirErr> {
    let (mut stms, exp) = expr_to_stm_opt(ctx, state, expr)?;

    match exp.to_maybe_exp() {
        Maybe::Some(exp) => {
            // Emit the postcondition for the common case where the function body
            // terminates with an expression to be returned (or an implicit
            // return value of 'unit').

            let end_of_fn = find_last_span_in_expr(&expr, func_span);
            assert_atomic_update_resolves(ctx, state, &mut stms, |base| {
                base.secondary_label(end_of_fn, "at the end of the function body")
            });

            // secondary label (indicating which post-condition failed) is added later
            // in ast_to_sst when the post condition is expanded
            let base_error = error_with_secondary_label(
                end_of_fn,
                def::POSTCONDITION_FAILURE.to_string(),
                "at the end of the function body".to_string(),
            );

            stms.push(Spanned::new(
                expr.span.clone(),
                StmX::Return {
                    base_error,
                    ret_exp: Some(exp),
                    inside_body: false,
                    assert_id: state.next_assert_id(),
                },
            ));
        }
        Maybe::Never => {
            // Program execution never gets to this point, so we don't need to check
            // any postconditions.
            // This might happen, for example, if the user writes their code in this style:
            //
            //    fn foo() {
            //        ...
            //        return x;
            //    }
            //
            // Here, we will always process the post-conditions when we get to the `return`
            // statement, but technically, the return statement is still an "early return"
            // and we never actually get to "the end" of the function.
            // Anyway, the point is, we don't need to check the postconditions again
            // in that case, or in any other case where we never reach the end of the
            // function.
        }
    };

    Ok(stms_to_one_stm(&expr.span, stms))
}

fn find_last_span_in_expr<'x>(expr: &'x Expr, fn_span: &'x Span) -> &'x Span {
    match &expr.x {
        ExprX::Block(_vec, block_expr) => block_expr.as_ref().map(|x| &x.span).unwrap_or(&fn_span),
        _ => &expr.span,
    }
}

fn is_small_exp(exp: &Exp) -> bool {
    match &exp.x {
        ExpX::Const(_) => true,
        ExpX::Var(..) | ExpX::VarAt(..) => true,
        ExpX::Old(..) => true,
        ExpX::Unary(UnaryOp::Not | UnaryOp::Clip { .. } | UnaryOp::MustBeFinalized, e) => {
            is_small_exp_or_loc(e)
        }
        ExpX::UnaryOpr(UnaryOpr::Box(_) | UnaryOpr::Unbox(_), _) => panic!("unexpected box"),
        _ => false,
    }
}

fn is_small_exp_or_loc(exp: &Exp) -> bool {
    match &exp.x {
        ExpX::Loc(..) => true,
        _ => is_small_exp(exp),
    }
}

fn mask_set_for_call(fun: &Function, typs: &Typs, args: Arc<Vec<Exp>>) -> MaskSet {
    let mask_spec = fun.x.mask_spec_or_default(&fun.span);
    match &mask_spec {
        MaskSpec::InvariantOpens(span, es) | MaskSpec::InvariantOpensExcept(span, es) => {
            let mut inv_exps = vec![];
            for (i, e) in es.iter().enumerate() {
                let expx = ExpX::Call(
                    CallFun::InternalFun(InternalFun::OpenInvariantMask(fun.x.name.clone(), i)),
                    typs.clone(),
                    args.clone(),
                );
                let exp = SpannedTyped::new(&e.span, &e.typ, expx);
                inv_exps.push(exp);
            }
            match &mask_spec {
                MaskSpec::InvariantOpens(..) => MaskSet::from_list(&inv_exps, span),
                MaskSpec::InvariantOpensExcept(..) => {
                    MaskSet::from_list_complement(&inv_exps, span)
                }
                MaskSpec::InvariantOpensSet(..) => panic!(),
            }
        }
        MaskSpec::InvariantOpensSet(e) => {
            let expx = ExpX::Call(
                CallFun::InternalFun(InternalFun::OpenInvariantMask(fun.x.name.clone(), 0)),
                typs.clone(),
                args.clone(),
            );
            let exp = SpannedTyped::new(&e.span, &e.typ, expx);
            MaskSet::arbitrary(&exp)
        }
    }
}

fn stm_call(
    ctx: &Ctx,
    state: &mut State,
    span: &Span,
    name: Fun,
    resolved_method: Option<(Fun, Typs)>,
    is_trait_default: Option<bool>,
    typs: Typs,
    args: Exps,
    dest: Option<Dest>,
    body: Option<Stm>,
) -> Result<Stm, VirErr> {
    let fun = get_function(ctx, span, &name)?;
    let mut stms: Vec<Stm> = Vec::new();

    let mut small_args: Vec<Exp> = Vec::new();
    for arg in args.iter() {
        if is_small_exp_or_loc(arg) {
            small_args.push(arg.clone());
        } else {
            // To avoid copying arg in preconditions and postconditions,
            // put arg into a temporary variable
            let poly = crate::poly::arg_is_poly(ctx, &fun.x.kind, fun.x.mode, &arg.typ);
            let kind =
                PreLocalDeclKind::Immutable(Immutable(LocalDeclKind::StmCallArg { native: !poly }));
            let (temp_id, temp_var) = state.declare_temp_var_stm(&arg.span, &arg.typ, kind);
            small_args.push(temp_var);
            stms.push(init_var(&arg.span, &temp_id, arg));
        }
    }

    let small_args = Arc::new(small_args);
    if !state.checking_recommends(ctx) {
        match &state.mask {
            Some(caller_mask) => {
                let callee_mask = mask_set_for_call(&fun, &typs, small_args.clone());
                for assertion in
                    callee_mask.subset_of(ctx, caller_mask, span, MaskQueryKind::FunctionCall)
                {
                    stms.push(Spanned::new(
                        span.clone(),
                        StmX::Assert(state.next_assert_id(), Some(assertion.err), assertion.cond),
                    ))
                }
            }
            None => (),
        }
    }

    let call = StmX::Call {
        fun: crate::sst::CallTarget::Fun(name.clone()),
        resolved_method,
        mode: fun.x.mode,
        is_trait_default,
        typ_args: typs,
        args: small_args.clone(),
        split: None,
        dest,
        assert_id: state.next_assert_id(),
        body,
    };

    stms.push(Spanned::new(span.clone(), call));
    if (name == def::nonstatic_call_fun(false) || name == def::nonstatic_call_fun(true))
        && matches!(&*small_args[0].typ, TypX::MutRef(_))
    {
        // Supported closures cannot mutate their captures, so a FnMut call preserves
        // the callable during its call reborrow. This does not constrain the final
        // value of a longer-lived reference passed through a generic FnOnce argument.
        let f = &small_args[0];
        let current = sst_mut_ref_current(span, f);
        let future = sst_mut_ref_future(span, f);
        let equal = sst_equal(span, &current, &future);
        stms.push(Spanned::new(span.clone(), StmX::Assume(equal)));
    }
    Ok(stms_to_one_stm(span, stms))
}

fn if_to_stm(
    state: &mut State,
    expr: &Expr,
    mut stms0: Vec<Stm>,
    e0: &Maybe<Value>,
    mut stms1: Vec<Stm>,
    e1: &Maybe<Value>,
    mut stms2: Vec<Stm>,
    e2: &Maybe<Value>,
) -> (Vec<Stm>, Maybe<Value>) {
    let e0 = match e0.clone().to_maybe_exp() {
        Maybe::Some(e) => e,
        Maybe::Never => {
            return (stms0, Maybe::Never);
        }
    };

    match (e1, e2) {
        (Maybe::Some(Value::ImplicitUnit(_)), _) | (_, Maybe::Some(Value::ImplicitUnit(_))) => {
            // If one branch returned an implicit unit, then the other branch
            // must also return a unit (either implicit or explicit).
            // If this sanity check fails, then it's likely we screwed up and
            // the alleged implicit unit branch was actually a never-return.
            assert!(types_equal(&undecorate_typ(&expr.typ), &unit_typ()));

            let stm1 = stms_to_one_stm(&expr.span, stms1);
            let stm2 = stms_to_one_stm_opt(&expr.span, stms2);
            let if_stmt = StmX::If(e0, stm1, stm2);
            stms0.push(Spanned::new(expr.span.clone(), if_stmt));
            (stms0, Maybe::Some(Value::ImplicitUnit(expr.span.clone())))
        }
        (Maybe::Never, other) | (other, Maybe::Never) => {
            // Suppose one side never returns; the return value of the conditional
            // (assuming it DOES return) will always be the one from the other branch.
            // (Of course, the other branch might be 'Never' too, in which case the
            // return value of the whole expression is Never.)
            //
            // For example, if we have:
            //    let t = if cond { 5 } else { return; };
            // Then we get Some(5) from the left branch, and Never from the right branch.
            // Furthermore, for the purposes of assigning to `t`, we can assume the return
            // value of the branch is _always_ 5.

            let stm1 = stms_to_one_stm(&expr.span, stms1);
            let stm2 = stms_to_one_stm_opt(&expr.span, stms2);
            let if_stmt = StmX::If(e0, stm1, stm2);
            stms0.push(Spanned::new(expr.span.clone(), if_stmt));
            (stms0, other.clone())
        }
        (Maybe::Some(Value::Exp(e1)), Maybe::Some(Value::Exp(e2))) => {
            if stms1.len() == 0 && stms2.len() == 0 {
                // In this case, we can construct a pure expression.
                let expx = ExpX::If(e0.clone(), e1.clone(), e2.clone());
                let exp = SpannedTyped::new(&expr.span, &expr.typ, expx);
                (stms0, Maybe::Some(Value::Exp(exp)))
            } else {
                // We have `if ( stms0; e0 ) { stms1; e1 } else { stms2; e2 }`.
                // We turn this into:
                //  stms0;
                //  if e0 { stms1; temp = e1; } else { stms2; temp = e2; };
                //  temp

                let (temp_id, temp_var) = state.declare_temp_assign(&expr.span, &expr.typ);
                stms1.push(init_var(&expr.span, &temp_id, &e1));
                stms2.push(init_var(&expr.span, &temp_id, &e2));
                let stm1 = stms_to_one_stm(&expr.span, stms1);
                let stm2 = stms_to_one_stm_opt(&expr.span, stms2);
                let if_stmt = StmX::If(e0, stm1, stm2);
                stms0.push(Spanned::new(expr.span.clone(), if_stmt));
                // temp
                (stms0, Maybe::Some(Value::Exp(temp_var)))
            }
        }
    }
}

/// Emits the Stms for a field-access check: `is_hard_requirement` (e.g. union access)
/// asserts except while checking recommends, plus an assume for both passes; otherwise
/// (e.g. get_variant access) it only asserts while checking recommends, with no assume,
/// since it's not a soundness fact.
fn field_check_stms(
    state: &mut State,
    ctx: &Ctx,
    span: &Span,
    condition: Exp,
    msg: Message,
    is_hard_requirement: bool,
) -> Vec<Stm> {
    let mut stms = vec![];
    if is_hard_requirement {
        if !state.checking_recommends(ctx) {
            let assert = StmX::Assert(state.next_assert_id(), Some(msg), condition.clone());
            stms.push(Spanned::new(span.clone(), assert));
        }
        stms.push(Spanned::new(span.clone(), StmX::Assume(condition)));
    } else if state.checking_recommends(ctx) {
        let assert = StmX::Assert(state.next_assert_id(), Some(msg), condition);
        stms.push(Spanned::new(span.clone(), assert));
    }
    stms
}

/// Convert a VIR Expr to a SST (Vec<Stm>, Maybe<Value>), i.e., instructions of the form,
/// "run these statements, then return this side-effect-free expression".
///
/// Note the 'Maybe<Value>' can be one of three things:
///  * Maybe::Some(Value::Exp(e)) - means the expression e was returned
///  * Maybe::Some(ImplicitUnit(_)) - for the implicit unit case
///  * Maybe::Never - the expression can never return (e.g., after a return value or break)
pub(crate) fn expr_to_stm_opt(
    ctx: &Ctx,
    state: &mut State,
    expr: &Expr,
) -> Result<(Vec<Stm>, Maybe<Value>), VirErr> {
    let mk_exp = |expx: ExpX| SpannedTyped::new(&expr.span, &expr.typ, expx);
    match &expr.x {
        ExprX::Const(c) => Ok((vec![], Maybe::Some(Value::Exp(mk_exp(ExpX::Const(c.clone())))))),
        ExprX::Var(x) => {
            let unique_id = state.get_var_unique_id(&x);
            let e = mk_exp(ExpX::Var(unique_id));
            let e = mk_exp(ExpX::Unary(UnaryOp::MustBeFinalized, e));
            Ok((vec![], Maybe::Some(Value::Exp(e))))
        }
        ExprX::StaticVar(x) => {
            state.statics.insert(x.clone());
            let e = mk_exp(ExpX::StaticVar(x.clone()));
            Ok((vec![], Maybe::Some(Value::Exp(e))))
        }
        ExprX::VarAt(x, VarAt::Pre) => {
            if let Some((scope, _)) = state.rename_map.scope_and_index_of_key(x) {
                if scope != 0 {
                    Err(error(&expr.span, "the parameter is shadowed here"))?;
                }
            }
            Ok((
                vec![],
                Maybe::Some(Value::Exp(mk_exp(ExpX::VarAt(
                    state.get_var_unique_id(&x),
                    VarAt::Pre,
                )))),
            ))
        }
        ExprX::ConstVar(..) => panic!("ConstVar should already be removed"),
        ExprX::Assign { place, rhs, op: Some(binary_op), resolve, typ: _ } => {
            assert!(!resolve);

            let (stms_r, e_r) = expr_to_stm_opt(ctx, state, rhs)?;
            let e_r = to_exp_or_return_never!(e_r, stms_r);

            let (stms_l, exps) = place_to_exp_pair(ctx, state, place)?;
            let (lhs_exp, e_l, obligations) = unwrap_or_return_never!(exps, stms_r, stms_l);

            let mut sequr = Sequencer::new();
            push_or_return_never!(sequr.push(
                stms_r,
                Maybe::Some(Value::Exp(e_r)),
                Immutable(LocalDeclKind::TempViaAssign)
            ));
            push_or_return_never!(sequr.push(
                stms_l,
                Maybe::Some(Value::Exp(e_l)),
                Immutable(LocalDeclKind::TempViaAssign)
            ));

            let (mut stms, e_r, e_l) = sequr.into_stms_exps_expect_2(state)?;
            let (mut stms3, bin) =
                binary_op_exp(ctx, state, &expr.span, &place.typ, *binary_op, &e_l, &e_r);
            stms.append(&mut stms3);

            let assign = StmX::Assign { lhs: Dest { dest: lhs_exp, is_init: false }, rhs: bin };
            stms.push(Spanned::new(expr.span.clone(), assign));

            typ_inv_obligations(ctx, state, &mut stms, obligations, TypInv::Assign)?;

            Ok((stms, Maybe::Some(Value::ImplicitUnit(expr.span.clone()))))
        }
        ExprX::Assign { place, rhs, op: None, resolve, typ } => {
            let (stms_r, e_r) = expr_to_stm_opt(ctx, state, rhs)?;
            let e_r = to_exp_or_return_never!(e_r, stms_r);

            let (stms_l, exps) = place_to_exp_pair(ctx, state, place)?;
            let (lhs_exp, e_l, obligations) = unwrap_or_return_never!(exps, stms_r, stms_l);

            let mut sequr = Sequencer::new();
            push_or_return_never!(sequr.push(
                stms_r,
                Maybe::Some(Value::Exp(e_r)),
                Immutable(LocalDeclKind::TempViaAssign)
            ));
            push_or_return_never!(sequr.push(
                stms_l,
                Maybe::Some(Value::Exp(e_l)),
                Immutable(LocalDeclKind::TempViaAssign)
            ));

            let (mut stms, e_r, e_l) = sequr.into_stms_exps_expect_2(state)?;

            if *resolve {
                let resx = ExpX::UnaryOpr(UnaryOpr::HasResolved(typ.clone()), e_l.clone());
                let res = SpannedTyped::new(&expr.span, &bool_typ(), resx);
                let assume_stm = Spanned::new(expr.span.clone(), StmX::Assume(res));
                stms.push(assume_stm);
            }

            let assign = StmX::Assign { lhs: Dest { dest: lhs_exp, is_init: false }, rhs: e_r };
            stms.push(Spanned::new(expr.span.clone(), assign));

            typ_inv_obligations(ctx, state, &mut stms, obligations, TypInv::Assign)?;

            Ok((stms, Maybe::Some(Value::ImplicitUnit(expr.span.clone()))))
        }
        ExprX::Call { target: CallTarget::FnSpec(e0), args, post_args, body } => {
            assert!(post_args.is_none());
            assert!(body.is_none());
            let (mut check_stms, e0) = expr_to_pure_exp_check(ctx, state, e0)?;
            let mut arg_exps: Vec<Exp> = Vec::new();
            for arg in args.iter() {
                let (stms, e) = expr_to_pure_exp_check(ctx, state, arg)?;
                check_stms.extend(stms);
                arg_exps.push(e);
            }
            let call = ExpX::CallLambda(e0, Arc::new(arg_exps));
            Ok((check_stms, Maybe::Some(Value::Exp(mk_exp(call)))))
        }
        ExprX::Call {
            target: CallTarget::BuiltinSpecFun(bsf, ts, _impl_paths),
            args,
            post_args,
            body,
        } => {
            assert!(post_args.is_none());
            assert!(body.is_none());
            let mut check_stms: Vec<Stm> = Vec::new();
            let mut arg_exps: Vec<Exp> = Vec::new();
            for arg in args.iter() {
                let (stms, e) = expr_to_pure_exp_check(ctx, state, arg)?;
                check_stms.extend(stms);
                arg_exps.push(e);
            }
            let f = match bsf {
                BuiltinSpecFun::ClosureReq => InternalFun::ClosureReq,
                BuiltinSpecFun::ClosureEns => InternalFun::ClosureEns,
                BuiltinSpecFun::DefaultEns => InternalFun::DefaultEns,
            };
            Ok((
                check_stms,
                Maybe::Some(Value::Exp(mk_exp(ExpX::Call(
                    CallFun::InternalFun(f),
                    ts.clone(),
                    Arc::new(arg_exps),
                )))),
            ))
        }
        ExprX::Call { target: CallTarget::Fun(..), args: _, post_args: _, body: _ } => {
            match expr_get_call(ctx, state, None, expr)?.expect("Call") {
                (stms, Maybe::Never) => Ok((stms, Maybe::Never)),
                (
                    mut stms,
                    Maybe::Some(ReturnedCall {
                        fun: x,
                        resolved_method,
                        is_trait_default,
                        typs,
                        has_return: ret,
                        args,
                        obligations,
                        may_unwind,
                        body,
                    }),
                ) => {
                    if function_can_be_exp(ctx, state, expr, &x, &resolved_method)? {
                        // ExpX::Call
                        let call = ExpX::Call(
                            CallFun::Fun(x.clone(), resolved_method.clone()),
                            typs.clone(),
                            args,
                        );
                        Ok((stms, Maybe::Some(Value::Exp(mk_exp(call)))))
                    } else if ret {
                        let (temp_ident, temp_var) =
                            state.declare_temp_assign(&expr.span, &expr.typ);
                        // tmp = StmX::Call;
                        let dest = Dest {
                            dest: var_loc_exp(&expr.span, &expr.typ, temp_ident.clone()),
                            is_init: true,
                        };
                        stms.push(stm_call(
                            ctx,
                            state,
                            &expr.span,
                            x.clone(),
                            resolved_method.clone(),
                            is_trait_default,
                            typs.clone(),
                            args.clone(),
                            Some(dest),
                            body,
                        )?);
                        // REVIEW: this emits a StmX::Assign to set the value of the destination when,
                        // in recommends checking, the StmX::Call is used to check its recommends, however
                        // we only do this here, and not in the similar cases in for `ExprX::Assign` and
                        // `StmtX::Decl` where the right-hand-side is an `ExprX::Call`.
                        // That may cause recommends incompleteness. We should either use this case for all
                        // calls, or add this special case to `ExprX::Assign` and `StmtX::Decl`.
                        if state.checking_recommends(ctx)
                            || state.checking_spec_decreases(ctx, &x, &resolved_method)
                        {
                            let fun = get_function(ctx, &expr.span, &x)?;
                            if fun.x.mode == Mode::Spec {
                                // for recommends, we need a StmX::Call for the recommends
                                // and an ExpX::Call for the value.
                                let call = ExpX::Call(
                                    CallFun::Fun(x.clone(), resolved_method.clone()),
                                    typs.clone(),
                                    args,
                                );
                                let call = SpannedTyped::new(&expr.span, &expr.typ, call);
                                stms.push(init_var(&expr.span, &temp_ident, &call));
                            }
                        }
                        let ti = if may_unwind { TypInv::UnwindError } else { TypInv::Call(x) };
                        typ_inv_obligations(ctx, state, &mut stms, obligations, ti)?;
                        // tmp
                        Ok((stms, Maybe::Some(Value::Exp(temp_var))))
                    } else {
                        // StmX::Call
                        stms.push(stm_call(
                            ctx,
                            state,
                            &expr.span,
                            x.clone(),
                            resolved_method,
                            is_trait_default,
                            typs.clone(),
                            args,
                            None,
                            body,
                        )?);
                        let ti = if may_unwind { TypInv::UnwindError } else { TypInv::Call(x) };
                        typ_inv_obligations(ctx, state, &mut stms, obligations, ti)?;
                        Ok((stms, Maybe::Some(Value::ImplicitUnit(expr.span.clone()))))
                    }
                }
            }
        }
        ExprX::Call { target: CallTarget::AssumeExternal, args, post_args, body } => {
            let (mut stms, all_obligations, exps, body) = get_call_args(
                ctx,
                state,
                args,
                post_args,
                body,
                &crate::ast::FunctionKind::Static,
                Mode::Exec,
                &[],
                &[],
                &Default::default(),
            )?;
            let Some(exps) = exps else {
                return Ok((stms, Maybe::Never));
            };

            let (temp_ident, temp_var) = state.declare_temp_assign(&expr.span, &expr.typ);
            let dest = Dest {
                dest: var_loc_exp(&expr.span, &expr.typ, temp_ident.clone()),
                is_init: true,
            };
            let call = StmX::Call {
                fun: crate::sst::CallTarget::AssumeExternal,
                resolved_method: None,
                mode: Mode::Exec,
                is_trait_default: None,
                typ_args: Arc::new(vec![]),
                args: Arc::new(exps),
                split: None,
                dest: Some(dest),
                assert_id: None,
                body,
            };
            stms.push(Spanned::new(expr.span.clone(), call));
            let ti = TypInv::UnwindError; // exec functions are may_unwind = true by default
            typ_inv_obligations(ctx, state, &mut stms, all_obligations, ti)?;
            Ok((stms, Maybe::Some(Value::Exp(temp_var))))
        }
        ExprX::Ctor(p, i, binders, update) => {
            assert!(update.is_none()); // should be simplified by ast_simplify

            // Handle two-phase borrow; see the explanation in expr_get_call
            let mut second_phase: Vec<Stm> = Vec::new();
            let mut all_obligations: Vec<Obligation> = Vec::new();

            let mut sequr = Sequencer::new();
            for binder in binders.iter() {
                let arg = &binder.a;
                let kind = Immutable(LocalDeclKind::TempViaAssign);
                match &arg.x {
                    ExprX::TwoPhaseBorrowMut(_) => {
                        let (phase1_stms, bor_sst) = borrow_mut_to_sst(ctx, state, arg)?;
                        push_or_return_never!(sequr.push_2phase(phase1_stms, &bor_sst, kind));
                        let Maybe::Some((bor_sst, obligations)) = bor_sst else { unreachable!() };
                        second_phase.push(bor_sst.phase2_stm);
                        all_obligations.extend(obligations);
                    }
                    _ => {
                        let (stms0, e0) = expr_to_stm_opt(ctx, state, &binder.a)?;
                        push_or_return_never!(sequr.push(stms0, e0, kind));
                    }
                }
            }
            let (mut stms, exps) = sequr.into_stms_exps_with_extra(state, second_phase)?;

            let mut args: Vec<Binder<Exp>> = Vec::new();
            for (binder, e1) in binders.iter().zip(exps.into_iter()) {
                let arg = BinderX { name: binder.name.clone(), a: e1 };
                args.push(Arc::new(arg));
            }
            let ctor = ExpX::Ctor(p.clone(), i.clone(), Arc::new(args));

            typ_inv_obligations(ctx, state, &mut stms, all_obligations, TypInv::BareMutRefError)?;

            Ok((stms, Maybe::Some(Value::Exp(mk_exp(ctor)))))
        }
        ExprX::NullaryOpr(op) => {
            Ok((vec![], Maybe::Some(Value::Exp(mk_exp(ExpX::NullaryOpr(op.clone()))))))
        }
        ExprX::UnaryOpr(UnaryOpr::LoopIsolationBoundary(label), e) => {
            let (stms, exp) = expr_to_stm_opt(ctx, state, e)?;
            match find_loop_in_stms(&stms, label) {
                Some((prefix, the_loop, suffix)) => {
                    let mut stm = loop_set_pre_stms(the_loop, Arc::new(prefix));
                    if suffix.len() > 0 {
                        let mut v = vec![stm];
                        v.extend(suffix);
                        stm = Spanned::new(expr.span.clone(), StmX::Block(Arc::new(v)))
                    }
                    Ok((vec![stm], exp))
                }
                None => {
                    // Unusual case; loop would have to be cut out by Never
                    assert!(matches!(exp, Maybe::Never));
                    return Ok((stms, exp));
                }
            }
        }
        ExprX::Unary(op, exprr) => {
            let (mut stms, exp) = expr_to_stm_opt(ctx, state, exprr)?;
            let exp = to_exp_or_return_never!(exp, stms);
            if let (true, UnaryOp::Clip { truncate: false, .. }) =
                (state.checking_recommends(ctx), op)
            {
                let unary = UnaryOpr::HasType(expr.typ.clone());
                let has_type = ExpX::UnaryOpr(unary, exp.clone());
                let has_type = SpannedTyped::new(&expr.span, &Arc::new(TypX::Bool), has_type);
                let error = crate::messages::error(
                    &expr.span,
                    "recommendation not met: value may be out of range of the target type (use `#[verifier::truncate]` on the cast to silence this warning)",
                );
                let assert = StmX::Assert(state.next_assert_id(), Some(error), has_type);
                let assert = Spanned::new(expr.span.clone(), assert);
                stms.push(assert);
            }
            Ok((stms, Maybe::Some(Value::Exp(mk_exp(ExpX::Unary(*op, exp))))))
        }
        ExprX::UnaryOpr(UnaryOpr::ToDyn(..), _)
            if matches!(&*undecorate_typ(&expr.typ), TypX::MutRef(_)) =>
        {
            let (mut stms, e) = expr_to_stm_opt_with_delayed_obligations(ctx, state, expr)?;
            let (e, obligations) = unwrap_or_return_never!(e, stms);
            typ_inv_obligations(ctx, state, &mut stms, obligations, TypInv::BareMutRefError)?;
            Ok((stms, Maybe::Some(e)))
        }
        ExprX::UnaryOpr(op, arg) => {
            let (mut stms, exp) = expr_to_stm_opt(ctx, state, arg)?;
            let exp = to_exp_or_return_never!(exp, stms);
            let (check, op) = match op {
                UnaryOpr::Field(field_opr) => match field_opr.check {
                    VariantCheck::Union => {
                        let (condition, msg) = crate::place_preconditions::sst_field_check(
                            &expr.span, &exp, field_opr,
                        );
                        let field_opr = FieldOpr { check: VariantCheck::None, ..field_opr.clone() };
                        (Some((condition, msg, true)), UnaryOpr::Field(field_opr))
                    }
                    // `get_variant` accessors are total - just give a recommends-only hint.
                    VariantCheck::Recommends => {
                        let (condition, msg) =
                            crate::place_preconditions::sst_field_recommends_check(
                                &expr.span, &exp, field_opr,
                            );
                        let field_opr = FieldOpr { check: VariantCheck::None, ..field_opr.clone() };
                        (Some((condition, msg, false)), UnaryOpr::Field(field_opr))
                    }
                    VariantCheck::None => (None, op.clone()),
                },
                _ => (None, op.clone()),
            };
            if let Some((condition, msg, is_hard_requirement)) = check {
                stms.extend(field_check_stms(
                    state,
                    ctx,
                    &expr.span,
                    condition,
                    msg,
                    is_hard_requirement,
                ));
            }
            Ok((stms, Maybe::Some(Value::Exp(mk_exp(ExpX::UnaryOpr(op, exp))))))
        }
        ExprX::Logical(op, e1, e2) => {
            let (stms1, e1) = expr_to_stm_opt(ctx, state, e1)?;
            let exp1 = to_exp_or_return_never!(e1.clone(), stms1);

            let (stms2, e2) = expr_to_stm_opt(ctx, state, e2)?;

            if stms2.len() == 0
                && let Maybe::Some(exp2) = e2.clone().to_maybe_exp()
            {
                // If e2 is pure, we can lower the logical op to an ordinary, pure Exp
                let sst_op = match op {
                    LogicalOp::And => sst::BinaryOp::And,
                    LogicalOp::Implies => sst::BinaryOp::Implies,
                    LogicalOp::Or => sst::BinaryOp::Or,
                };
                let binx = ExpX::Binary(sst_op, exp1.clone(), exp2.clone());
                let bin = SpannedTyped::new(&expr.span, &bool_typ(), binx);
                Ok((stms1, Maybe::Some(Value::Exp(bin))))
            } else {
                // Handle short-circuiting.
                // The pair (proceed_on, other) means:
                // If e1 evaluates to `proceed_on`, then evaluate and
                // return e2; otherwise, return the value `other`
                // (without evaluating `e2`).
                let (proceed_on, other) = match op {
                    LogicalOp::And => (true, false),
                    LogicalOp::Implies => (true, true),
                    LogicalOp::Or => (false, true),
                };

                // and:
                //   if e1 { stmts2; e2 } else { false }
                // implies:
                //   if e1 { stmts2; e2 } else { true }
                // or:
                //   if e1 { true } else { stmts2; e2 }
                let bx = ExpX::Const(Constant::Bool(other));
                let b = SpannedTyped::new(&expr.span, &Arc::new(TypX::Bool), bx);
                let b = Maybe::Some(Value::Exp(b));
                if proceed_on {
                    Ok(if_to_stm(state, expr, stms1, &e1, stms2, &e2, vec![], &b))
                } else {
                    Ok(if_to_stm(state, expr, stms1, &e1, vec![], &b, stms2, &e2))
                }
            }
        }
        ExprX::Binary(op, e1, e2) => {
            let mut sequr = Sequencer::new();

            let (stms1, e1) = expr_to_stm_opt(ctx, state, e1)?;
            push_or_return_never!(sequr.push(stms1, e1, Immutable(LocalDeclKind::TempViaAssign)));

            let (stms2, e2) = expr_to_stm_opt(ctx, state, e2)?;
            push_or_return_never!(sequr.push(stms2, e2, Immutable(LocalDeclKind::TempViaAssign)));
            let (mut stms, e1, e2) = sequr.into_stms_exps_expect_2(state)?;

            let (mut stms3, bin) = binary_op_exp(ctx, state, &expr.span, &expr.typ, *op, &e1, &e2);
            stms.append(&mut stms3);

            Ok((stms, Maybe::Some(Value::Exp(bin))))
        }
        ExprX::BinaryOpr(op, e1, e2) => {
            let (stms1, e1) = expr_to_stm_opt(ctx, state, e1)?;
            let (stms2, e2) = expr_to_stm_opt(ctx, state, e2)?;

            let mut sequr = Sequencer::new();
            push_or_return_never!(sequr.push(stms1, e1, Immutable(LocalDeclKind::TempViaAssign)));
            push_or_return_never!(sequr.push(stms2, e2, Immutable(LocalDeclKind::TempViaAssign)));
            let (stms, e1, e2) = sequr.into_stms_exps_expect_2(state)?;

            let bin = mk_exp(ExpX::BinaryOpr(op.clone(), e1, e2));
            Ok((stms, Maybe::Some(Value::Exp(bin))))
        }
        ExprX::Multi(..) => {
            panic!("internal error: Multi should have been simplified by ast_simplify")
        }
        ExprX::Quant(quant, binders, body) => {
            let kind = PreLocalDeclKind::Immutable(Immutable(LocalDeclKind::QuantBinder));
            let check_stms = check_pure_expr_bind(ctx, state, binders, kind, body)?;
            state.push_scope();
            let binders = state.rename_binders_exp(binders);
            // Use expr_to_pure_exp_skip_checks,
            // because we checked spec preconditions with check_pure_expr_bind
            let exp = expr_to_pure_exp_skip_checks(ctx, state, body)?;
            state.pop_scope();
            let trigs = Arc::new(vec![]); // real triggers will be set by finalize_exp
            let bnd =
                Spanned::new(body.span.clone(), BndX::Quant(*quant, binders.clone(), trigs, None));
            let e = mk_exp(ExpX::Bind(bnd, exp));
            let e = mk_exp(ExpX::Unary(UnaryOp::MustBeElaborated, e));
            Ok((check_stms, Maybe::Some(Value::Exp(e))))
        }
        ExprX::Closure(params, body) => {
            state.disable_recommends += 1;
            let kind = PreLocalDeclKind::Immutable(Immutable(LocalDeclKind::ClosureBinder));
            let check_stms = check_pure_expr_bind(ctx, state, params, kind, body)?;
            // Note: to avoid false alarms, we don't check recommends inside closures
            // (since there's no precondition on the closure parameters)
            state.push_scope();
            let params = state.rename_binders_exp(params);
            // Use expr_to_pure_exp_skip_checks,
            // because we checked spec preconditions with check_pure_expr_bind
            let exp = expr_to_pure_exp_skip_checks(ctx, state, body)?;
            state.pop_scope();

            let trigs = Arc::new(vec![]); // real triggers will be set by finalize_exp
            let bnd = Spanned::new(body.span.clone(), BndX::Lambda(params.clone(), trigs));
            state.disable_recommends -= 1;
            Ok((check_stms, Maybe::Some(Value::Exp(mk_exp(ExpX::Bind(bnd, exp))))))
        }
        ExprX::NonSpecClosure {
            params,
            proof_fn_modes: _,
            body,
            requires,
            ensures,
            ret,
            external_spec,
        } => {
            let mut all_stms = Vec::new();

            // Emit the internals of the closure (ClosureInner behaves like a dead-end)
            // This includes assuming the requires, asserting the ensures, everything else

            let (inner_stms, typ_inv_vars, precision_body) =
                exec_closure_body_stms(ctx, state, params, ret, body, requires, ensures)?;
            let block = Spanned::new(expr.span.clone(), StmX::Block(Arc::new(inner_stms)));
            let clos = Spanned::new(
                expr.span.clone(),
                StmX::ClosureInner { body: block, typ_inv_vars, precision_body },
            );
            all_stms.push(clos);

            // Create the closure object and assume all the information given in its
            // specification that the world external to the closure gets to assume.

            let (cid, cexpr) = external_spec
                .as_ref()
                .expect("external_spec should have been added in ast_simplify");
            state.push_scope();
            let uid =
                state.declare_imm_var_stm(&cid, &expr.typ, LocalDeclKind::ExecClosureId, false);
            // Use expr_to_pure_exp_skip_checks,
            // because we checked spec preconditions in exec_closure_body_stms
            let cexp = expr_to_pure_exp_skip_checks(ctx, state, &cexpr)?;
            state.pop_scope();

            all_stms.push(Spanned::new(expr.span.clone(), StmX::Assume(cexp)));

            // Generic closure datatypes use Poly rather than a native SMT sort,
            // so their constructed value needs its Rust type-validity fact.
            all_stms.push(assume_has_typ(&uid, &expr.typ, &expr.span));
            let v = mk_exp(ExpX::Var(uid));

            Ok((all_stms, Maybe::Some(Value::Exp(v))))
        }
        ExprX::ArrayLiteral(elems) => {
            let mut sequr = Sequencer::new();
            for elem in elems.iter() {
                let (stms0, e0) = expr_to_stm_opt(ctx, state, elem)?;
                push_or_return_never!(sequr.push(
                    stms0,
                    e0,
                    Immutable(LocalDeclKind::TempViaAssign)
                ));
            }
            let (stms, exps) = sequr.into_stms_exps(state)?;
            let array_lit = mk_exp(ExpX::ArrayLiteral(Arc::new(exps)));
            Ok((stms, Maybe::Some(Value::Exp(array_lit))))
        }
        ExprX::ExecFnByName(fun) => {
            let v = mk_exp(ExpX::ExecFnByName(fun.clone()));
            Ok((vec![], Maybe::Some(Value::Exp(v))))
        }
        ExprX::Choose { params, cond, body } => {
            let kind = PreLocalDeclKind::Immutable(Immutable(LocalDeclKind::ChooseBinder));
            let mut check_stms = check_pure_expr_bind(ctx, state, params, kind, cond)?;
            check_stms.extend(check_pure_expr_bind(ctx, state, params, kind, body)?);
            state.push_scope();
            let params = state.rename_binders_exp(&params);
            // Use expr_to_pure_exp_skip_checks,
            // because we checked spec preconditions with check_pure_expr_bind
            let cond_exp = expr_to_pure_exp_skip_checks(ctx, state, cond)?;
            let body_exp = expr_to_pure_exp_skip_checks(ctx, state, body)?;
            state.pop_scope();
            let trigs = Arc::new(vec![]); // real triggers will be set by finalize_exp
            let bnd_choosex = BndX::Choose(params.clone(), trigs.clone(), cond_exp.clone());
            let bnd_choose = Spanned::new(body.span.clone(), bnd_choosex);
            let e_choose = mk_exp(ExpX::Bind(bnd_choose, body_exp));
            let e_choose = mk_exp(ExpX::Unary(UnaryOp::MustBeElaborated, e_choose));
            if state.checking_recommends(ctx) {
                let quant = crate::ast::Quant { quant: air::ast::Quant::Exists };
                let bnd_exists = Spanned::new(
                    body.span.clone(),
                    BndX::Quant(quant, params.clone(), trigs, None),
                );
                let e_exists = mk_exp(ExpX::Bind(bnd_exists, cond_exp.clone()));
                let e_exists = mk_exp(ExpX::Unary(UnaryOp::MustBeElaborated, e_exists));
                let error = error(
                    &cond_exp.span,
                    "recommendation not met: cannot prove that there exists values that satisfy the condition of the choose expression",
                );
                let assertx = StmX::Assert(state.next_assert_id(), Some(error), e_exists);
                check_stms.push(Spanned::new(cond_exp.span.clone(), assertx));
            }
            Ok((check_stms, Maybe::Some(Value::Exp(e_choose))))
        }
        ExprX::WithTriggers { triggers, body } => {
            let mut trigs: Vec<crate::sst::Trig> = Vec::new();
            for trigger in triggers.iter() {
                // Use expr_to_pure_exp_skip_checks,
                // because spec preconditions are not checked in triggers
                // because they are just hints for quantifier instantiation
                let t =
                    vec_map_result(&**trigger, |e| expr_to_pure_exp_skip_checks(ctx, state, e))?;
                trigs.push(Arc::new(t));
            }
            let trigs = Arc::new(trigs);
            let (check_stms, body_exp) = expr_to_pure_exp_check(ctx, state, body)?;
            Ok((check_stms, Maybe::Some(Value::Exp(mk_exp(ExpX::WithTriggers(trigs, body_exp))))))
        }
        ExprX::Fuel(x, fuel, is_broadcast_use) => {
            // It's possible that the function may have pruned out of the crate
            // because there are no transitive dependencies.
            // If so, just skip the fuel/reveal statement entirely
            // (it can't possibly have any effect)
            let skip = !ctx.reveal_group_set.contains(x) && !ctx.func_map.contains_key(x);

            if skip {
                ctx.warning_maybe_if_in_local_crate(
                    &expr.span,
                    &WarningAllow::DeadReveal,
                    || "this reveal/fuel statement has no effect because no verification condition in this module depends on this function",
                    |msg| state.diagnostics.report(&msg.to_any()),
                );
            }

            let stms = if skip {
                vec![]
            } else {
                if !is_broadcast_use {
                    let function = get_function(ctx, &expr.span, x)?;
                    if *fuel >= 2 && !crate::recursion::fun_is_recursive(ctx, &function) {
                        return Err(error(
                            &expr.span,
                            "this function is not recursive (nor mutually recursive), so fuel cannot be set to more than 1",
                        ));
                    }
                }

                let stm = Spanned::new(expr.span.clone(), StmX::Fuel(x.clone(), *fuel));
                vec![stm]
            };
            Ok((stms, Maybe::Some(Value::ImplicitUnit(expr.span.clone()))))
        }
        ExprX::RevealString(path) => {
            let stm = Spanned::new(expr.span.clone(), StmX::RevealString(path.clone()));
            Ok((vec![stm], Maybe::Some(Value::ImplicitUnit(expr.span.clone()))))
        }
        ExprX::RevealByteString(bytes) => {
            let stm = Spanned::new(expr.span.clone(), StmX::RevealByteString(bytes.clone()));
            Ok((vec![stm], Maybe::Some(Value::ImplicitUnit(expr.span.clone()))))
        }
        ExprX::Header(_) => {
            return Err(error(&expr.span, "header expression not allowed here"));
        }
        ExprX::AssertAssume { is_assume: false, expr: e, msg } => {
            if state.checking_recommends(ctx) {
                let (mut stms, exp) = expr_to_stm_or_error(ctx, state, e)?;
                let stm = Spanned::new(expr.span.clone(), StmX::Assume(exp));
                stms.push(stm);
                Ok((stms, Maybe::Some(Value::ImplicitUnit(expr.span.clone()))))
            } else {
                let mut stms: Vec<Stm> = Vec::new();
                // Use expr_to_pure_exp_skip_checks,
                // because we checked spec preconditions above with expr_to_stm_or_error
                let exp = expr_to_pure_exp_skip_checks(ctx, state, e)?;
                let exp = crate::heuristics::maybe_insert_auto_ext_equal(ctx, &exp, |x| x.assert);
                let small = is_small_exp_or_loc(&exp);
                let exp = if small {
                    exp.clone()
                } else {
                    // To avoid copying exp in Assert and Assume,
                    // put exp into a temporary variable
                    let kind = PreLocalDeclKind::Immutable(Immutable(LocalDeclKind::Assert));
                    let (temp_id, temp_var) = state.declare_temp_var_stm(&exp.span, &exp.typ, kind);
                    stms.push(init_var(&exp.span, &temp_id, &exp));
                    // Carry any proof note from `exp` to `temp_var`.
                    if let Some(label) = sst_exp_get_proof_note(&exp) {
                        SpannedTyped::new(
                            &exp.span,
                            &exp.typ,
                            ExpX::UnaryOpr(UnaryOpr::ProofNote(label), temp_var),
                        )
                    } else {
                        temp_var
                    }
                };
                stms.push(Spanned::new(
                    e.span.clone(),
                    StmX::Assert(state.next_assert_id(), msg.clone(), exp.clone()),
                ));
                stms.push(Spanned::new(e.span.clone(), StmX::Assume(exp)));
                Ok((stms, Maybe::Some(Value::ImplicitUnit(expr.span.clone()))))
            }
        }
        ExprX::AssertAssume { is_assume: true, expr: e, msg: _ } => {
            // Use expr_to_pure_exp_skip_checks,
            // because the goal of assume is to add an assumption, not to perform checks
            let exp = expr_to_pure_exp_skip_checks(ctx, state, e)?;
            let stm = Spanned::new(expr.span.clone(), StmX::Assume(exp));
            Ok((vec![stm], Maybe::Some(Value::ImplicitUnit(expr.span.clone()))))
        }
        ExprX::AssertAssumeUserDefinedTypeInvariant { is_assume, expr, fun } => {
            let (mut stms, exp) = expr_to_stm_opt(ctx, state, expr)?;

            if state.view_as_spec {
                return Ok((stms, exp));
            }

            let exp = to_exp_or_return_never!(exp, stms);

            let tmp = state.make_tmp_var_for_exp(&mut stms, exp);
            let ti = if *is_assume { TypInv::Assume } else { TypInv::Constructed };
            assert_assume_satisfies_user_defined_type_invariant(
                ctx, state, &tmp, &mut stms, fun, ti,
            )?;
            Ok((stms, Maybe::Some(Value::Exp(tmp))))
        }
        ExprX::AssertBy { vars, require, ensure, proof } => {
            // deadend {
            //   assume(require)
            //   proof
            //   assert(ensure);
            // }
            // assume(forall vars. require ==> ensure)
            let mut stms: Vec<Stm> = Vec::new();

            // Translate proof into a dead-end ending with an assert
            state.push_scope();
            let mut body: Vec<Stm> = Vec::new();
            let mut locals: Vec<LocalDecl> = Vec::new();
            for var in vars.iter() {
                let x = state.declare_imm_var_stm(
                    &var.name,
                    &var.a,
                    LocalDeclKind::AssertByVar { native: false },
                    true,
                );
                body.push(assume_has_typ(&x, &var.a, &require.span));
                locals.push(Arc::new(LocalDeclX {
                    ident: x,
                    typ: var.a.clone(),
                    kind: LocalDeclKind::AssertByVar { native: false },
                }));
            }
            let (mut proof_stms, e) = expr_to_stm_opt(ctx, state, proof)?;
            if let Maybe::Some(Value::Exp(_)) = e {
                return Err(error(
                    &expr.span,
                    "'assert ... by' block cannot end with an expression",
                ));
            }
            let (require_checks, require_exp) = expr_to_pure_exp_check(ctx, state, &require)?;
            body.extend(require_checks);
            let assume = Spanned::new(require.span.clone(), StmX::Assume(require_exp));
            body.push(assume);
            body.append(&mut proof_stms);
            let mut assert_id = None;
            if state.checking_spec_preconditions(ctx) {
                body.extend(check_pure_expr(ctx, state, &ensure)?);
            } else {
                // Use expr_to_pure_exp_skip_checks,
                // because we checked spec preconditions above with check_pure_expr
                let ensure_exp = expr_to_pure_exp_skip_checks(ctx, state, &ensure)?;
                let ensure_exp =
                    crate::heuristics::maybe_insert_auto_ext_equal(ctx, &ensure_exp, |x| {
                        x.assert_by
                    });
                assert_id = state.next_assert_id();
                let assert = Spanned::new(
                    ensure.span.clone(),
                    StmX::Assert(assert_id.clone(), None, ensure_exp),
                );
                body.push(assert);
            }
            let block = Spanned::new(expr.span.clone(), StmX::Block(Arc::new(body)));
            let deadend = Spanned::new(expr.span.clone(), StmX::DeadEnd(block));
            stms.push(deadend);
            state.pop_scope();

            // Translate ensure into an assume
            let implyx = ExprX::Logical(LogicalOp::Implies, require.clone(), ensure.clone());
            let imply = SpannedTyped::new(&ensure.span, &Arc::new(TypX::Bool), implyx);
            state.push_scope();
            let vars = state.rename_binders_exp(vars);
            // Use expr_to_pure_exp_skip_checks,
            // because we already checked spec preconditions for require and ensure above
            let imply_exp = expr_to_pure_exp_skip_checks(ctx, state, &imply)?;
            state.pop_scope();
            let trigs = Arc::new(vec![]); // real triggers will be set by finalize_exp
            let provenance =
                AssertByProvenance { locals: Arc::new(locals), binders: vars.clone(), assert_id };
            let bndx = BndX::Quant(QUANT_FORALL, vars.clone(), trigs, Some(Arc::new(provenance)));
            let bnd = Spanned::new(ensure.span.clone(), bndx);
            let forall_exp = mk_exp(ExpX::Bind(bnd, imply_exp));
            let forall_exp = mk_exp(ExpX::Unary(UnaryOp::MustBeElaborated, forall_exp));
            let assume = Spanned::new(ensure.span.clone(), StmX::Assume(forall_exp));
            stms.push(assume);
            Ok((stms, Maybe::Some(Value::ImplicitUnit(expr.span.clone()))))
        }
        ExprX::AssertQuery { requires, ensures, proof, mode } => {
            // Note that `ExprX::AssertQuery` makes a separate query for AssertQueryMode::NonLinear and AssertQueryMode::BitVector.
            // Only `requires` and type invariants will be provided to prove `ensures`.
            match mode {
                AssertQueryMode::NonLinear => {
                    let mut inner_body: Vec<Stm> = Vec::new();
                    let mut exps: Vec<Exp> = Vec::new();

                    // Translate body as separate query
                    state.push_scope();
                    for r in requires.iter() {
                        let (require_check_recommends, require_exp) =
                            expr_to_pure_exp_check(ctx, state, &r)?;
                        inner_body.extend(require_check_recommends);
                        let assume = Spanned::new(r.span.clone(), StmX::Assume(require_exp));
                        inner_body.push(assume);
                    }

                    let (proof_stms, e) = expr_to_stm_opt(ctx, state, proof)?;
                    if let Maybe::Some(Value::Exp(_)) = e {
                        return Err(error(
                            &expr.span,
                            "'assert ... by' block cannot end with an expression",
                        ));
                    }
                    inner_body.extend(proof_stms);

                    for e in ensures.iter() {
                        // Use expr_to_pure_exp_skip_checks,
                        // because we check spec preconditions below with check_pure_expr
                        let ensure_exp = expr_to_pure_exp_skip_checks(ctx, state, &e)?;
                        exps.push(ensure_exp.clone());
                        if state.checking_spec_preconditions(ctx) {
                            let check_stms = check_pure_expr(ctx, state, &e)?;
                            inner_body.extend(check_stms);
                        } else {
                            let assert = Spanned::new(
                                e.span.clone(),
                                StmX::Assert(state.next_assert_id(), None, ensure_exp),
                            );
                            inner_body.push(assert);
                        }
                    }

                    let inner_body =
                        Spanned::new(expr.span.clone(), StmX::Block(Arc::new(inner_body)));
                    state.pop_scope();

                    let mut outer: Vec<Stm> = Vec::new();

                    // Translate as assert, assume in outer query
                    for r in requires.iter() {
                        // Use expr_to_pure_exp_skip_checks,
                        // because we check spec preconditions below with check_pure_expr
                        let require_exp = expr_to_pure_exp_skip_checks(ctx, state, &r)?;
                        exps.push(require_exp.clone());
                        if state.checking_spec_preconditions(ctx) {
                            outer.extend(check_pure_expr(ctx, state, &r)?);
                        } else {
                            let assert = Spanned::new(
                                r.span.clone(),
                                StmX::Assert(
                                    state.next_assert_id(),
                                    Some(crate::messages::error(
                                        &r.span.clone(),
                                        "requires not satisfied".to_string(),
                                    )),
                                    require_exp,
                                ),
                            );
                            outer.push(assert);
                        }
                    }
                    for e in ensures.iter() {
                        // Use expr_to_pure_exp_skip_checks,
                        // because we already checked spec preconditions above with check_pure_expr
                        let ensure_exp = expr_to_pure_exp_skip_checks(ctx, state, &e)?;
                        let assume = Spanned::new(e.span.clone(), StmX::Assume(ensure_exp));
                        outer.push(assume);
                    }

                    let outer_block = Spanned::new(expr.span.clone(), StmX::Block(Arc::new(outer)));

                    let nonlinear = Spanned::new(
                        expr.span.clone(),
                        StmX::AssertQuery {
                            body: inner_body,
                            typ_inv_exps: Arc::new(exps),
                            typ_inv_vars: Arc::new(vec![]),
                            mode: *mode,
                        },
                    );
                    Ok((
                        vec![outer_block, nonlinear],
                        Maybe::Some(Value::ImplicitUnit(expr.span.clone())),
                    ))
                }

                AssertQueryMode::BitVector => {
                    // check if assertion block consists only of requires/ensures
                    let (proof_stms, e) = expr_to_stm_opt(ctx, state, proof)?;
                    let proof_block_err =
                        Err(error(&expr.span, "assert_bitvector_by cannot contain a proof block"));
                    if let Maybe::Some(Value::Exp(_)) = e {
                        return Err(error(
                            &expr.span,
                            "assert_bitvector_by cannot contain a return value",
                        ));
                    }
                    if proof_stms.len() > 1 {
                        return proof_block_err;
                    }
                    if let StmX::Block(st) = &proof_stms[0].x {
                        if st.len() > 0 {
                            return proof_block_err;
                        }
                    } else {
                        return proof_block_err;
                    }

                    // translate requires/ensures expression
                    let mut requires_in = vec![];
                    let mut ensures_in = vec![];
                    let mut outer: Vec<Stm> = Vec::new();
                    state.push_scope();
                    // We won't have the context to check recommends, so skip them
                    state.disable_recommends += 1;
                    for r in requires.iter() {
                        let (check_stms, require_exp) = expr_to_pure_exp_check(ctx, state, &r)?;
                        outer.extend(check_stms);
                        requires_in.push(require_exp.clone());
                    }
                    for e in ensures.iter() {
                        let (check_stms, ensure_exp) = expr_to_pure_exp_check(ctx, state, &e)?;
                        outer.extend(check_stms);
                        ensures_in.push(ensure_exp.clone());
                    }
                    state.disable_recommends -= 1;
                    state.pop_scope();

                    // Translate as assert, assume in outer query
                    if !state.checking_recommends(&ctx) {
                        for r in requires.iter() {
                            // Use expr_to_pure_exp_skip_checks,
                            // because we checked spec preconditions above with expr_to_pure_exp_check
                            let require_exp = expr_to_pure_exp_skip_checks(ctx, state, &r)?;
                            let assert = Spanned::new(
                                r.span.clone(),
                                StmX::Assert(
                                    state.next_assert_id(),
                                    Some(error(
                                        &r.span.clone(),
                                        "requires not satisfied".to_string(),
                                    )),
                                    require_exp,
                                ),
                            );
                            outer.push(assert);
                        }
                    }
                    for e in ensures.iter() {
                        // Use expr_to_pure_exp_skip_checks,
                        // because we checked spec preconditions above with expr_to_pure_exp_check
                        let ensure_exp = expr_to_pure_exp_skip_checks(ctx, state, &e)?;
                        let assume = Spanned::new(e.span.clone(), StmX::Assume(ensure_exp));
                        outer.push(assume);
                    }
                    let outer_block = Spanned::new(expr.span.clone(), StmX::Block(Arc::new(outer)));

                    let bitvector = Spanned::new(
                        expr.span.clone(),
                        StmX::AssertBitVector {
                            requires: Arc::new(requires_in),
                            ensures: Arc::new(ensures_in),
                        },
                    );
                    Ok((
                        vec![outer_block, bitvector],
                        Maybe::Some(Value::ImplicitUnit(expr.span.clone())),
                    ))
                }
            }
        }
        ExprX::AssertCompute(e, compute) => {
            // We won't have the context to check recommends, so skip them
            state.disable_recommends += 1;
            let (mut stms, exp) = expr_to_pure_exp_check(ctx, state, &e)?;
            state.disable_recommends -= 1;
            let ret = Maybe::Some(Value::ImplicitUnit(exp.span.clone()));
            // We assert the (hopefully simplified) result of calling the interpreter
            // but assume the original expression, so we get the benefits
            // of any ensures, triggers, etc., that it might provide
            if !ctx.checking_spec_preconditions_for_non_spec() {
                let id = match compute {
                    ComputeMode::Z3 => state.next_assert_id(),
                    ComputeMode::ComputeOnly => None,
                };
                let assert =
                    Spanned::new(exp.span.clone(), StmX::AssertCompute(id, exp.clone(), *compute));
                stms.push(assert);
            }
            let assume = Spanned::new(exp.span.clone(), StmX::Assume(exp));
            stms.push(assume);
            Ok((stms, ret))
        }
        ExprX::If(expr0, expr1, None) => {
            let (stms0, e0) = expr_to_stm_opt(ctx, state, expr0)?;
            let (stms1, e1) = expr_to_stm_opt(ctx, state, expr1)?;
            let stms2 = vec![];
            let e2 = Maybe::Some(Value::ImplicitUnit(expr.span.clone()));
            Ok(if_to_stm(state, expr, stms0, &e0, stms1, &e1, stms2, &e2))
        }
        ExprX::If(expr0, expr1, Some(expr2)) => {
            let (stms0, e0) = expr_to_stm_opt(ctx, state, expr0)?;
            let (stms1, e1) = expr_to_stm_opt(ctx, state, expr1)?;
            let (stms2, e2) = expr_to_stm_opt(ctx, state, expr2)?;
            Ok(if_to_stm(state, expr, stms0, &e0, stms1, &e1, stms2, &e2))
        }
        ExprX::Match(..) => {
            panic!("internal error: Match should have been simplified by ast_simplify")
        }
        ExprX::Loop {
            loop_isolation,
            allow_complex_invariants,
            is_for_loop,
            assume_termination,
            label,
            cond,
            body,
            invs,
            decrease,
            atomic_call,
        } => {
            let is_for_loop = *is_for_loop;
            let produces_value =
                !crate::ast_util::is_unit(&expr.typ) && !crate::ast_util::is_never(&expr.typ);
            let loop_isolation = *loop_isolation;
            if produces_value && loop_isolation {
                return Err(error(
                    &expr.span,
                    "loops with value-bearing 'break' do not yet support loop isolation",
                )
                .help("add #[verifier::loop_isolation(false)] to this loop"));
            }
            let allow_complex_invariants = *allow_complex_invariants;
            let id = state.loop_id_counter;
            state.loop_id_counter += 1;
            let invs = if is_for_loop && !loop_isolation {
                // The syntax macro doesn't have enough context to know whether ensures is needed,
                // so we have to fix up the invariants here.
                let invs = invs
                    .iter()
                    .filter(|inv| match inv.kind {
                        LoopInvariantKind::InvariantExceptBreak => true,
                        LoopInvariantKind::InvariantAndEnsures => true,
                        LoopInvariantKind::Ensures => false,
                    })
                    .cloned()
                    .collect();

                Arc::new(invs)
            } else {
                invs.clone()
            };
            let (num_breaks, num_iso_breaks) = loop_has_breaks(label, expr);
            if !loop_isolation && num_iso_breaks > 0 {
                // our encoding for loop_isolation=false requires all 'break' statements to be
                // in the same query
                return Err(error(
                    &expr.span,
                    "loop with loop_isolation=false contains 'break' statement inside a nested loop with loop_isolation=true",
                ));
            }
            let has_user_break = num_breaks > if is_for_loop { 1 } else { 0 };
            let invs = if is_for_loop && has_user_break {
                // If the user added a break statement, then we need to remove the auto-generated ensures
                // clauses (since they typically don't apply any more)
                Arc::new(
                    invs.iter()
                        .filter_map(|inv| match inv.kind {
                            LoopInvariantKind::InvariantExceptBreak => Some(inv.clone()),
                            LoopInvariantKind::InvariantAndEnsures => Some(inv.clone()),
                            LoopInvariantKind::Ensures => {
                                if matches!(
                                    inv.inv.x,
                                    ExprX::UnaryOpr(UnaryOpr::AutoLoopEnsures, _)
                                ) {
                                    None
                                } else {
                                    Some(inv.clone())
                                }
                            }
                        })
                        .collect(),
                )
            } else {
                invs.clone()
            };
            let simple_invs =
                invs.iter().all(|inv| inv.kind == LoopInvariantKind::InvariantAndEnsures);
            let simple_while = !has_user_break && simple_invs && cond.is_some() && loop_isolation;

            if allow_complex_invariants && loop_isolation && !is_for_loop {
                return Err(error(
                    &expr.span,
                    "attribute 'allow_complex_invariants' can only be used with 'loop_isolation(false)'",
                ));
            }

            if !loop_isolation && !simple_invs && !allow_complex_invariants {
                return Err(error(
                    &expr.span,
                    "loop invariants with 'loop_isolation(false)' cannot be invariant_except_break \
                        or ensures, unless #[verifier::allow_complex_invariants] is used",
                ));
            }
            let mut cnd = if let Some(cond) = cond {
                let (stms0, e0) = expr_to_stm_opt(ctx, state, cond)?;
                let e0 = match e0 {
                    Maybe::Some(Value::Exp(e0)) => e0,
                    Maybe::Some(Value::ImplicitUnit(_)) => {
                        panic!("while loop condition doesn't return a bool expression");
                    }
                    Maybe::Never => {
                        // If the condition never returns (which would be odd, but it
                        // could happen) then the body of the while loop never gets to go at all.
                        return Ok((stms0, Maybe::Never));
                    }
                };
                let block0 = Spanned::new(expr.span.clone(), StmX::Block(Arc::new(stms0)));
                Some((block0, e0))
            } else {
                None
            };
            if decrease.is_empty()
                && !assume_termination
                && ctx.fun.as_ref().is_none_or(|fun_ctx| {
                    let function = &ctx.func_map[&fun_ctx.current_fun];
                    !function.x.attrs.exec_assume_termination
                        && !function.x.attrs.exec_allows_no_decreases_clause
                })
            {
                return Err(error(&expr.span, "loop must have a decreases clause")
                            .help("to disable this check, use #[verifier::exec_allows_no_decreases_clause] on the function"));
            }

            let mut body_prefix = Vec::new();
            let mut au_branch_bool = None;
            if *atomic_call {
                let bool_typ = Arc::new(TypX::Bool);
                let (var_id, var_exp) = state.declare_temp_var_stm(
                    &expr.span,
                    &bool_typ,
                    PreLocalDeclKind::Immutable(Immutable(LocalDeclKind::Nondeterministic)),
                );
                body_prefix.push(assume_has_typ(&var_id, &bool_typ, &expr.span));
                au_branch_bool = Some(var_exp.clone());
                state.branch_bool_var = Some((var_id, var_exp));
            }

            let loop_result = if !produces_value {
                None
            } else {
                let (dest, result) = state.declare_temp_var_stm(
                    &expr.span,
                    &expr.typ,
                    PreLocalDeclKind::Immutable(Immutable(LocalDeclKind::LoopBreakValue)),
                );
                let previous = state.loop_result_dests.insert(label.clone(), dest);
                assert!(previous.is_none());
                Some(result)
            };

            let (mut body_stms, _val) = expr_to_stm_opt(ctx, state, body)?;
            if loop_result.is_some() {
                let removed = state.loop_result_dests.remove(label);
                assert!(removed.is_some());
            }
            state.branch_bool_var = None;

            let mut check_recommends: Vec<Stm> = Vec::new();
            let mut invs1: Vec<crate::sst::LoopInv> = Vec::new();
            for inv in invs.iter() {
                // Ensures clauses are unnecessary if loop_isolation is false,
                // since the weakest precondition already tracks all the paths through the breaks into the code after the loop
                if !loop_isolation
                    && allow_complex_invariants
                    && inv.kind == LoopInvariantKind::Ensures
                {
                    continue;
                }

                let (rec, exp) = expr_to_pure_exp_check(ctx, state, &inv.inv)?;
                let exp =
                    crate::heuristics::maybe_insert_auto_ext_equal(ctx, &exp, |x| x.invariant);
                check_recommends.extend(rec);

                let (at_entry, at_exit) = if !loop_isolation
                    && allow_complex_invariants
                    && inv.kind == LoopInvariantKind::InvariantExceptBreak
                {
                    // With loop_isolation disabled, an invariant_except_break simply becomes an invariant
                    (true, true)
                } else {
                    match inv.kind {
                        LoopInvariantKind::InvariantExceptBreak => (true, false),
                        LoopInvariantKind::InvariantAndEnsures => (true, true),
                        LoopInvariantKind::Ensures => (false, true),
                    }
                };

                let inv1 = crate::sst::LoopInv { inv: exp, at_entry, at_exit };
                invs1.push(inv1);
            }
            let mut decrease1: Vec<Exp> = Vec::new();
            for dec in decrease.iter() {
                let (rec, exp) = expr_to_pure_exp_check(ctx, state, dec)?;
                check_recommends.extend(rec);
                decrease1.push(exp);
            }
            if ctx.checking_spec_preconditions() {
                body_stms.splice(0..0, check_recommends);
            }
            if !simple_while {
                // must be "loop", not "while"
                if let Some((c_stm, c_exp)) = cnd {
                    // convert while into loop
                    let not_c = c_exp.new_x(ExpX::Unary(UnaryOp::Not, c_exp.clone()));
                    let break_stmx = StmX::BreakOrContinue { label: label.clone(), is_break: true };
                    let break_stm = Spanned::new(c_exp.span.clone(), break_stmx);
                    let if_stm = Spanned::new(c_exp.span.clone(), StmX::If(not_c, break_stm, None));
                    body_stms.insert(0, c_stm);
                    body_stms.insert(1, if_stm);
                    cnd = None;
                }
            }
            if !loop_isolation {
                // !loop_isolation handling expects a "loop", not a "while"
                assert!(cnd.is_none());
            }
            body_stms.splice(0..0, body_prefix);
            let pre_local_decls =
                crate::recursion::mk_decreases_at_entry_pre(ctx, Some(id), &decrease1)?;
            state.pre_local_decls.extend(pre_local_decls);
            let while_stm = Spanned::new(
                expr.span.clone(),
                StmX::Loop {
                    pre_stms: Arc::new(vec![]),
                    loop_isolation,
                    is_for_loop,
                    id,
                    label: label.clone(),
                    cond: cnd,
                    body: stms_to_one_stm(&body.span, body_stms),
                    invs: Arc::new(invs1),
                    decrease: Arc::new(decrease1),
                    au_branch_bool,
                    // These are filled in later, in sst_vars
                    typ_inv_vars: Arc::new(vec![]),
                    modified_vars: None,
                    pre_modified_params_incl: None,
                    pre_modified_params_excl: None,
                },
            );

            if can_control_flow_reach_after_loop(expr) {
                let ret = Maybe::Some(match loop_result {
                    Some(result) => Value::Exp(result),
                    None => Value::ImplicitUnit(expr.span.clone()),
                });
                Ok((vec![while_stm], ret))
            } else {
                // If it's an infinite loop, add 'assume(false)' and return Never.
                // Note: this is usually redundant with the NeverToAny node, which usually
                // exists outside the loop. However, the NeverToAny node is not always
                // in the optimal place. In the following:
                //
                // {
                //     loop { };     // semi-colon is necessary for this example
                //     assert(false)
                // }
                //
                // the NeverToAny node goes outside the outer block, thus it would be applied
                // after the assert. We prefer to return Never early, immediately after the loop.
                let stms = vec![while_stm, assume_false(&expr.span)];
                Ok((stms, Maybe::Never))
            }
        }
        ExprX::OpenInvariant(inv, binder, body, atomicity) => {
            // let inv_tmp = inv;
            // OpenInvariantBlock(inv_tmp.namespace(), {
            //   let mut inner = inner_tmp;
            //   assume(inv_tmp.inv(inner));
            //
            //   ...
            //
            //   assert(inv_tmp.inv(inner));
            // });

            // Evaluate `inv`
            let (mut stms0, big_inv_exp) = expr_to_stm_opt(ctx, state, inv)?;
            let big_inv_exp = to_exp_or_return_never!(big_inv_exp, stms0);

            // Assign it to a constant tmp variable to ensure it is constant
            // across the entire block. sst_to_air also relies on this.
            let (inv_tmp_id, inv_tmp_var) = state.declare_temp_assign(&big_inv_exp.span, &inv.typ);
            stms0.push(init_var(&big_inv_exp.span, &inv_tmp_id, &big_inv_exp));

            // Declare the inner_tmp variable
            let mut stms1 = vec![];
            let inner_typ = &binder.a;
            let (arb_id, arb_exp) = state.declare_temp_var_stm(
                &big_inv_exp.span,
                &inner_typ,
                PreLocalDeclKind::Immutable(Immutable(LocalDeclKind::OpenInvariantInnerTemp)),
            );
            stms1.push(assume_has_typ(&arb_id, &inner_typ, &expr.span));

            // Assign to the bound variable
            let ident = state.get_var_unique_id(&binder.name);
            state.pre_local_decls.push(PreLocalDecl {
                ident: ident.clone(),
                typ: inner_typ.clone(),
                kind: PreLocalDeclKind::StmtLet,
            });
            stms1.push(init_var(&expr.span, &ident, &arb_exp));
            let inner_var = SpannedTyped::new(&expr.span, &inner_typ, ExpX::Var(ident));

            // Check that the invariant namespace is not already opened
            let typ_args = get_inv_typ_args(&big_inv_exp.typ);
            let ns_exp = call_namespace(ctx, &inv_tmp_var, &typ_args, *atomicity);

            if !state.checking_recommends(ctx) {
                for assertion in state.mask.as_ref().unwrap().contains(
                    ctx,
                    &ns_exp,
                    &expr.span,
                    MaskQueryKind::OpenInvariant,
                ) {
                    stms1.push(Spanned::new(
                        expr.span.clone(),
                        StmX::Assert(state.next_assert_id(), Some(assertion.err), assertion.cond),
                    ))
                }
            }

            let mut inner_mask = Some(state.mask.as_ref().unwrap().remove(&ns_exp));

            // Assume the invariant
            let main_inv = call_inv(ctx, &inv_tmp_var, &inner_var, &typ_args, *atomicity);
            stms1.push(Spanned::new(expr.span.clone(), StmX::Assume(main_inv.clone())));

            // Process the body
            state.push_scope();
            std::mem::swap(&mut state.mask, &mut inner_mask);
            let (body_stms, body_e) = expr_to_stm_opt(ctx, state, body)?;
            std::mem::swap(&mut state.mask, &mut inner_mask);
            state.pop_scope();

            let body_stm = stms_to_one_stm(&expr.span, body_stms);
            stms1.push(body_stm);

            // Assert the invariant at the end
            match body_e.to_maybe_exp() {
                Maybe::Some(_e) => {
                    if !ctx.checking_spec_preconditions() {
                        let error =
                            error(&expr.span, "Cannot show invariant holds at end of block");
                        // Note, we re-use the `main_inv` exp here, but it contains a mutable
                        stms1.push(Spanned::new(
                            expr.span.clone(),
                            StmX::Assert(state.next_assert_id(), Some(error), main_inv),
                        ));
                    }
                }
                Maybe::Never => {
                    // It might be impossible to reach the end of the block
                    stms1.push(assume_false(&expr.span));
                }
            }

            let block_stm = stms_to_one_stm(&expr.span, stms1);
            stms0.push(Spanned::new(expr.span.clone(), StmX::OpenInvariant(block_stm)));
            return Ok((stms0, Maybe::Some(Value::ImplicitUnit(expr.span.clone()))));
        }
        ExprX::TryOpenAtomicUpdate(au_expr, x_bind, body) => {
            // This is roughtly what the generated SST looks like:
            //
            // ```
            // let au = $au_expr;
            // let x = new existential;
            //
            // assume(req(au, x));
            // assert(outer_mask(au) ⊆ state.mask);
            //
            // let y;
            // with state.mask = inner_mask(au) {
            //     let $mut $x = x;
            //     y = $body;
            // }
            //
            // assert(ens(au, x, y));
            //
            // if branch_bool(y) {
            //     assume(input(au, x));
            //     assume(output(au, y));
            //     assume(resolves(au));
            //
            //     Ok(())
            // } else {
            //     Err(au)
            // }
            // ```

            let (mut stms, au_raw_exp) = expr_to_stm_opt(ctx, state, au_expr)?;
            let au_raw_val = unwrap_or_return_never!(au_raw_exp, stms);
            let au_typ = undecorate_typ(&au_expr.typ);
            let au_var_exp = state.make_tmp_var_for_exp(&mut stms, au_raw_val.to_exp());

            let TypX::Datatype(_, typ_args, _) = au_typ.as_ref() else {
                return crate::util::err_span(
                    expr.span.clone(),
                    "malformed atomic update block; atomic update should be a datatype",
                );
            };

            let [x_typ, y_typ, _pred_typ] = typ_args.as_slice() else {
                return crate::util::err_span(
                    expr.span.clone(),
                    "malformed atomic update block; atomic update should have four type params",
                );
            };

            let (x_var_id, x_var_exp) = state.declare_temp_var_stm(
                &expr.span,
                x_typ,
                PreLocalDeclKind::Immutable(Immutable(LocalDeclKind::Nondeterministic)),
            );
            stms.push(assume_has_typ(&x_var_id, x_typ, &expr.span));

            // assume atomic requires

            let call_req = ExpX::Call(
                CallFun::Fun(def::fn_au_req(), None),
                typ_args.clone(),
                Arc::new(vec![au_var_exp.clone(), x_var_exp.clone()]),
            );
            let call_req = SpannedTyped::new(&expr.span, &Arc::new(TypX::Bool), call_req);
            stms.push(Spanned::new(expr.span.clone(), StmX::Assume(call_req.clone())));

            // check invariant mask

            let int_typ = Arc::new(TypX::Int(IntRange::Int));
            let int_set_typ = Arc::new(TypX::Datatype(
                crate::ast::Dt::Path(def::iset_type_path()),
                Arc::new(vec![int_typ]),
                Default::default(),
            ));

            let outer_mask = MaskSet::arbitrary(&SpannedTyped::new(
                &expr.span,
                &int_set_typ,
                ExpX::Call(
                    CallFun::Fun(def::fn_au_outer_mask(), None),
                    typ_args.clone(),
                    Arc::new(vec![au_var_exp.clone()]),
                ),
            ));

            let inner_mask = MaskSet::arbitrary(&SpannedTyped::new(
                &expr.span,
                &int_set_typ,
                ExpX::Call(
                    CallFun::Fun(def::fn_au_inner_mask(), None),
                    typ_args.clone(),
                    Arc::new(vec![au_var_exp.clone()]),
                ),
            ));

            if !state.checking_recommends(ctx) {
                let state_mask = state.mask.as_ref().unwrap();
                for assertion in outer_mask.subset_of(
                    ctx,
                    state_mask,
                    &expr.span,
                    MaskQueryKind::OpenAtomicUpdate,
                ) {
                    stms.push(Spanned::new(
                        expr.span.clone(),
                        StmX::Assert(state.next_assert_id(), Some(assertion.err), assertion.cond),
                    ))
                }
            }

            // generate binder for x

            let x_bind_var_id = state.get_var_unique_id(&x_bind.name);
            state.pre_local_decls.push(PreLocalDecl {
                ident: x_bind_var_id.clone(),
                typ: x_typ.clone(),
                kind: PreLocalDeclKind::StmtLet,
            });

            stms.push(init_var(&expr.span, &x_bind_var_id, &x_var_exp));

            // generate body

            state.push_scope();
            let backup_mask = std::mem::replace(&mut state.mask, Some(inner_mask));

            let (body_stms, body_exp) = expr_to_stm_opt(ctx, state, body)?;
            stms.extend(body_stms);

            let body_exp = to_exp_or_return_never!(body_exp, stms);
            let y_var_exp = state.make_tmp_var_for_exp(&mut stms, body_exp);

            state.mask = backup_mask;
            state.pop_scope();

            // assert atomic ensures

            if !state.checking_recommends(ctx) {
                let call_ens = ExpX::Call(
                    CallFun::Fun(def::fn_au_ens(), None),
                    typ_args.clone(),
                    Arc::new(vec![au_var_exp.clone(), x_var_exp.clone(), y_var_exp.clone()]),
                );

                let call_ens = SpannedTyped::new(&expr.span, &Arc::new(TypX::Bool), call_ens);
                let error =
                    error(&expr.span, "cannot show atomic postcondition hold at end of block");

                stms.push(Spanned::new(
                    expr.span.clone(),
                    StmX::Assert(state.next_assert_id(), Some(error), call_ens),
                ));
            }

            // generate condition

            let res_dt = Dt::Path(def::result_type_path());
            let ok_variant = Arc::new("Ok".to_owned());
            let err_variant = Arc::new("Err".to_owned());
            let variant_field = Arc::new("0".to_owned());

            let branch_bool = SpannedTyped::new(
                &expr.span,
                &Arc::new(TypX::Bool),
                ExpX::Call(
                    CallFun::Fun(def::fn_branch_bool(), None),
                    Arc::new(vec![y_typ.clone()]),
                    Arc::new(vec![y_var_exp.clone()]),
                ),
            );

            let cond = Maybe::Some(Value::Exp(branch_bool));

            let (ok_arm_stms, ok_arm_ret_val) = {
                let mut stms = Vec::new();

                atomic_update_bind_and_resolve(
                    expr,
                    typ_args,
                    &au_var_exp,
                    &x_var_exp,
                    &y_var_exp,
                    &mut stms,
                );

                let unit_typ = crate::ast_util::mk_tuple_typ(&Default::default());
                let (unit_var_id, unit_var_exp) = state.declare_temp_var_stm(
                    &expr.span,
                    &unit_typ,
                    PreLocalDeclKind::Immutable(Immutable(LocalDeclKind::Nondeterministic)),
                );

                stms.push(assume_has_typ(&unit_var_id, &unit_typ, &expr.span));

                let out_exp = SpannedTyped::new(
                    &expr.span,
                    &expr.typ,
                    ExpX::Ctor(
                        res_dt.clone(),
                        ok_variant.clone(),
                        Arc::new(vec![Arc::new(BinderX {
                            name: variant_field.clone(),
                            a: unit_var_exp,
                        })]),
                    ),
                );

                (stms, Maybe::Some(Value::Exp(out_exp)))
            };

            let (err_arm_stms, err_arm_ret_val) = {
                let stms = Vec::new();

                let out_exp = SpannedTyped::new(
                    &expr.span,
                    &expr.typ,
                    ExpX::Ctor(
                        res_dt.clone(),
                        err_variant.clone(),
                        Arc::new(vec![Arc::new(BinderX {
                            name: variant_field.clone(),
                            a: au_var_exp,
                        })]),
                    ),
                );

                (stms, Maybe::Some(Value::Exp(out_exp)))
            };

            return Ok(if_to_stm(
                state,
                expr,
                stms,
                &cond,
                ok_arm_stms,
                &ok_arm_ret_val,
                err_arm_stms,
                &err_arm_ret_val,
            ));
        }
        ExprX::AtomicUpdateInitDummy => {
            let mut stms = Vec::<Stm>::new();

            let au_typ = undecorate_typ(&expr.typ);
            let TypX::Datatype(_, au_typ_args, _) = au_typ.as_ref() else {
                panic!("atomic update type should have type arguments")
            };

            let [_x_typ, _y_typ, pred_typ] = au_typ_args.as_slice() else {
                panic!("atomic update type should have exactly three type arguments")
            };

            let au_pred_args = std::mem::take(&mut state.au_pred_args);
            let args_exp = match <[_; 1]>::try_from(au_pred_args) {
                Ok([single]) => single.clone(),
                Err(exps) => crate::sst_util::sst_tuple(&expr.span, &Arc::new(exps)),
            };

            // construct predicate type
            let (pred_var_id, pred_var_exp) = state.declare_temp_var_stm(
                &expr.span,
                pred_typ,
                PreLocalDeclKind::Immutable(Immutable(LocalDeclKind::Nondeterministic)),
            );
            stms.push(assume_has_typ(&pred_var_id, pred_typ, &expr.span));

            let call_pred_args = SpannedTyped::new(
                &expr.span,
                &args_exp.typ,
                ExpX::Call(
                    CallFun::Fun(def::fn_pred_args(), None),
                    Arc::new(vec![pred_typ.clone(), args_exp.typ.clone()]),
                    Arc::new(vec![pred_var_exp.clone()]),
                ),
            );

            stms.push(Spanned::new(
                expr.span.clone(),
                StmX::Assume(sst_equal(&expr.span, &call_pred_args, &args_exp)),
            ));

            // construct atomic update
            let (au_var_id, au_var_exp) =
                state.declare_temp_var_stm(&expr.span, &au_typ, PreLocalDeclKind::Param);
            stms.push(assume_has_typ(&au_var_id, &au_typ, &expr.span));

            let call_au_pred = SpannedTyped::new(
                &expr.span,
                pred_typ,
                ExpX::Call(
                    CallFun::Fun(def::fn_au_pred(), None),
                    au_typ_args.clone(),
                    Arc::new(vec![au_var_exp.clone()]),
                ),
            );

            stms.push(Spanned::new(
                expr.span.clone(),
                StmX::Assume(sst_equal(&expr.span, &call_au_pred, &pred_var_exp)),
            ));

            state.au_var_exp = Some(au_var_exp.clone());

            Ok((stms, Maybe::Some(Value::Exp(au_var_exp))))
        }
        ExprX::Atomically(kind, ghost_au_var_id, body_expr) => {
            // ```
            // let pred = $pred_expr;
            // let au = new existential;
            // assume(pred(au) == pred);
            //
            // with state.mask = outer_mask(au) {
            //     () = $body;
            // }
            //
            // au
            // ```

            let au_typ = undecorate_typ(&expr.typ);
            let TypX::Datatype(_, au_typ_args, _) = au_typ.as_ref() else {
                panic!("atomic update should be a datatype")
            };

            let mut stms = Vec::<Stm>::new();

            // rebind atomic update
            state.pre_local_decls.push(PreLocalDecl {
                ident: ghost_au_var_id.clone(),
                typ: au_typ.clone(),
                kind: PreLocalDeclKind::Param,
            });

            let Some(temp_au_var_exp) = &state.au_var_exp else {
                panic!("atomic update should have been created by ExprX::AtomicUpdateInitDummy")
            };

            stms.push(init_var(&expr.span, &ghost_au_var_id, temp_au_var_exp));
            let au_var_exp =
                SpannedTyped::new(&expr.span, &au_typ, ExpX::Var(ghost_au_var_id.clone()));
            state.au_var_exp = Some(au_var_exp.clone());

            // check invariant mask
            let int_typ = Arc::new(TypX::Int(IntRange::Int));
            let int_set_typ = Arc::new(TypX::Datatype(
                Dt::Path(def::iset_type_path()),
                Arc::new(vec![int_typ]),
                Default::default(),
            ));

            let outer_mask = MaskSet::arbitrary(&SpannedTyped::new(
                &expr.span,
                &int_set_typ,
                ExpX::Call(
                    CallFun::Fun(def::fn_au_outer_mask(), None),
                    au_typ_args.clone(),
                    Arc::new(vec![au_var_exp.clone()]),
                ),
            ));

            // generate branch bool
            let mut branch_bool_exp = None;
            if let AtomicallyKind::Simple = kind {
                let bool_typ = Arc::new(TypX::Bool);
                let (var_id, var_exp) = state.declare_temp_var_stm(
                    &expr.span,
                    &bool_typ,
                    PreLocalDeclKind::Immutable(Immutable(LocalDeclKind::Nondeterministic)),
                );
                stms.push(assume_has_typ(&var_id, &bool_typ, &expr.span));
                branch_bool_exp = Some(var_exp.clone());
                state.branch_bool_var = Some((var_id, var_exp));
            }

            // generate body
            let backup_mask = std::mem::replace(&mut state.mask, Some(outer_mask));
            let (body_stms, exp) = expr_to_stm_opt(ctx, state, body_expr)?;
            stms.extend(body_stms);
            state.mask = backup_mask;

            let value = exp.expect_exp();
            let TypX::Datatype(Dt::Tuple(0), ..) = value.typ.as_ref() else {
                panic!("malformed atomic function call; body does not return unit");
            };

            // check branch bool
            if !state.checking_recommends(ctx)
                && let Some(exp) = branch_bool_exp
            {
                let msg = error(&expr.span, "cannot show atomic update was committed").help(
                    "if the atomic update has an abort case, please use `atomically loop` instead",
                );
                stms.push(Spanned::new(
                    expr.span.clone(),
                    StmX::Assert(state.next_assert_id(), Some(msg), exp),
                ));
            }

            // return atomic update
            Ok((stms, Maybe::Some(Value::Exp(au_var_exp))))
        }
        ExprX::Update(x_expr) => {
            // ```
            // let x = $x_expr;
            // let y = new existential;
            //
            // recommend(inner_mask(au) ⊆ outer_mask(au));
            // assert(inner_mask(au) ⊆ state.mask);
            //
            // assert(req(au, x));
            // assume(ens(au, x, y));
            //
            // if branch_bool(y) {
            //     assume(input(au, x));
            //     assume(output(au, y));
            //     assume(resolves(au));
            // }
            //
            // y
            // ```

            let Some(au_var_exp) = state.au_var_exp.clone() else {
                panic!("update function outside of atomically block");
            };

            let TypX::Datatype(_, au_typ_args, _) = au_var_exp.typ.as_ref() else {
                panic!("atomic update should be a datatype")
            };

            let [x_typ, y_typ, _pred_typ] = au_typ_args.as_slice() else {
                panic!("atomic update type should have exactly three type arguments")
            };

            let (mut stms, x_raw_exp) = expr_to_stm_opt(ctx, state, x_expr)?;
            let x_raw_exp = unwrap_or_return_never!(x_raw_exp, stms).to_exp();
            let (x_var_id, x_var_exp) = state.declare_temp_assign(&x_expr.span, x_typ);
            stms.push(init_var(&x_expr.span, &x_var_id, &x_raw_exp));

            let (y_var_id, y_var_exp) = state.declare_temp_var_stm(
                &expr.span,
                y_typ,
                PreLocalDeclKind::Immutable(Immutable(LocalDeclKind::Nondeterministic)),
            );
            stms.push(assume_has_typ(&y_var_id, y_typ, &expr.span));

            // check invariant mask

            let int_typ = Arc::new(TypX::Int(IntRange::Int));
            let int_set_typ = Arc::new(TypX::Datatype(
                Dt::Path(def::iset_type_path()),
                Arc::new(vec![int_typ]),
                Default::default(),
            ));

            let inner_mask = MaskSet::arbitrary(&SpannedTyped::new(
                &expr.span,
                &int_set_typ,
                ExpX::Call(
                    CallFun::Fun(def::fn_au_inner_mask(), None),
                    au_typ_args.clone(),
                    Arc::new(vec![au_var_exp.clone()]),
                ),
            ));

            if state.checking_recommends(ctx) {
                let outer_mask = MaskSet::arbitrary(&SpannedTyped::new(
                    &expr.span,
                    &int_set_typ,
                    ExpX::Call(
                        CallFun::Fun(def::fn_au_outer_mask(), None),
                        au_typ_args.clone(),
                        Arc::new(vec![au_var_exp.clone()]),
                    ),
                ));

                for assertion in inner_mask.subset_of(
                    ctx,
                    &outer_mask,
                    &au_var_exp.span,
                    MaskQueryKind::AtomicUpdateWellFormed,
                ) {
                    stms.push(Spanned::new(
                        expr.span.clone(),
                        StmX::Assert(state.next_assert_id(), Some(assertion.err), assertion.cond),
                    ))
                }
            } else {
                let state_mask = state.mask.as_ref().unwrap();
                for assertion in inner_mask.subset_of(
                    ctx,
                    state_mask,
                    &expr.span,
                    MaskQueryKind::UpdateFunctionCall,
                ) {
                    stms.push(Spanned::new(
                        expr.span.clone(),
                        StmX::Assert(state.next_assert_id(), Some(assertion.err), assertion.cond),
                    ))
                }
            }

            // assert atomic requires

            let call_req = ExpX::Call(
                CallFun::Fun(def::fn_au_req(), None),
                au_typ_args.clone(),
                Arc::new(vec![au_var_exp.clone(), x_var_exp.clone()]),
            );

            let call_req = SpannedTyped::new(&expr.span, &Arc::new(TypX::Bool), call_req);
            if !state.checking_recommends(ctx) {
                stms.push(Spanned::new(
                    expr.span.clone(),
                    StmX::Assert(
                        state.next_assert_id(),
                        Some(error(
                            &expr.span,
                            "cannot show atomic precondition holds before update function",
                        )),
                        call_req,
                    ),
                ));
            }

            // assume atomic ensures

            let call_ens = SpannedTyped::new(
                &expr.span,
                &Arc::new(TypX::Bool),
                ExpX::Call(
                    CallFun::Fun(def::fn_au_ens(), None),
                    au_typ_args.clone(),
                    Arc::new(vec![au_var_exp.clone(), x_var_exp.clone(), y_var_exp.clone()]),
                ),
            );

            stms.push(Spanned::new(expr.span.clone(), StmX::Assume(call_ens)));

            // generate conditional

            let branch_bool_exp = SpannedTyped::new(
                &expr.span,
                &Arc::new(TypX::Bool),
                ExpX::Call(
                    CallFun::Fun(def::fn_branch_bool(), None),
                    Arc::new(vec![y_typ.clone()]),
                    Arc::new(vec![y_var_exp.clone()]),
                ),
            );

            let Some((branch_bool_var_id, branch_bool_var_exp)) = &state.branch_bool_var else {
                panic!("must be inside atomic function call loop")
            };

            stms.push(init_var(&expr.span, branch_bool_var_id, &branch_bool_exp));
            let cond = branch_bool_var_exp.clone();

            let if_body_stm = {
                let mut stms = Vec::new();
                atomic_update_bind_and_resolve(
                    expr,
                    au_typ_args,
                    &au_var_exp,
                    &x_var_exp,
                    &y_var_exp,
                    &mut stms,
                );

                stms_to_one_stm(&expr.span, stms)
            };

            stms.push(Spanned::new(expr.span.clone(), StmX::If(cond, if_body_stm, None)));

            let ret_val = Maybe::Some(Value::Exp(y_var_exp.clone()));
            return Ok((stms, ret_val));
        }
        ExprX::InvMask(mask_spec) => {
            let (span, exprs, compl) = match mask_spec {
                MaskSpec::InvariantOpens(span, exprs) => (span, exprs, false),
                MaskSpec::InvariantOpensExcept(span, exprs) => (span, exprs, true),
                MaskSpec::InvariantOpensSet(expr) => return expr_to_stm_opt(ctx, state, expr),
            };

            let mut sequr = Sequencer::new();
            for expr in exprs.as_ref() {
                let (exp_stms, ret_val) = expr_to_stm_opt(ctx, state, expr)?;
                push_or_return_never!(sequr.push(
                    exp_stms,
                    ret_val,
                    Immutable(LocalDeclKind::TempViaAssign)
                ));
            }

            let (stms, exps) = sequr.into_stms_exps(state)?;
            let mask = match compl {
                false => MaskSet::from_list(&exps, span),
                true => MaskSet::from_list_complement(&exps, span),
            };

            let exp = mask.to_exp(ctx);
            Ok((stms, Maybe::Some(Value::Exp(exp))))
        }
        ExprX::Return(e1) => {
            let (mut stms, ret_exp) = match e1 {
                None => (vec![], sst_unit_value(&expr.span)),
                Some(e) => {
                    let (ret_stms, exp) = expr_to_stm_opt(ctx, state, e)?;
                    let exp = to_exp_or_return_never!(exp, ret_stms);

                    (ret_stms, exp)
                }
            };

            let containing_closure = state.containing_closure.clone();
            match &containing_closure {
                None => {
                    let base_error = error_with_secondary_label(
                        &expr.span,
                        def::POSTCONDITION_FAILURE.to_string(),
                        "at this exit".to_string(),
                    );

                    assert_atomic_update_resolves(ctx, state, &mut stms, |base| {
                        base.secondary_label(&expr.span, "at this exit")
                    });

                    stms.push(Spanned::new(
                        expr.span.clone(),
                        StmX::Return {
                            base_error,
                            ret_exp: Some(ret_exp),
                            inside_body: true,
                            assert_id: state.next_assert_id(),
                        },
                    ));
                }
                Some(closure_state) => {
                    closure_emit_postconditions(ctx, state, closure_state, &ret_exp, &mut stms);
                }
            }
            stms.push(assume_false(&expr.span));
            Ok((stms, Maybe::Never))
        }
        ExprX::BreakOrContinue { label, is_break, value } => {
            let mut stms = Vec::new();
            if let Some(value) = value {
                assert!(*is_break);
                let (mut value_stms, value) = expr_to_stm_opt(ctx, state, value)?;
                stms.append(&mut value_stms);
                let value = match value {
                    Maybe::Some(value) => value.to_exp(),
                    Maybe::Never => return Ok((stms, Maybe::Never)),
                };
                // Unit-typed loops do not have a result destination.
                if let Some(dest) = state.loop_result_dests.get(label) {
                    stms.push(init_var(&expr.span, dest, &value));
                }
            }
            let stmx = StmX::BreakOrContinue { label: label.clone(), is_break: *is_break };
            let stm = Spanned::new(expr.span.clone(), stmx);
            stms.push(stm);
            Ok((stms, Maybe::Some(Value::ImplicitUnit(expr.span.clone()))))
        }
        ExprX::NeverToAny(e) => {
            let (mut stms, _e) = expr_to_stm_opt(ctx, state, e)?;
            stms.push(assume_false(&expr.span));
            Ok((stms, Maybe::Never))
        }
        ExprX::Ghost { .. } => {
            panic!("internal error: ExprX::Ghost should have been simplified by ast_simplify")
        }
        ExprX::ProofInSpec(e) => {
            let stms = if state.checking_spec_general(ctx) {
                let (stms, exp_opt) = expr_to_stm_opt(ctx, state, e)?;
                assert!(crate::ast_util::is_unit(&exp_opt.expect_exp().typ));
                stms
            } else {
                vec![]
            };
            Ok((stms, Maybe::Some(Value::ImplicitUnit(expr.span.clone()))))
        }
        ExprX::Block(stmts, body_opt) => {
            let mut stms: Vec<Stm> = Vec::new();
            let mut pre_local_decls: Vec<PreLocalDecl> = Vec::new();
            let mut binds: Vec<Bnd> = Vec::new();
            let mut is_pure_exp = true;
            let mut never_return = false;
            state.push_scope();
            for stmt in stmts.iter() {
                let (mut stms0, e0, decl_bnd_opt) = stmt_to_stm(ctx, state, stmt)?;
                match decl_bnd_opt {
                    Some((name, decl, bnd)) => {
                        state.push_scope();
                        pre_local_decls.push(decl.clone());
                        state.insert_var_maybe_exp(&name, &decl.ident);
                        match bnd {
                            None => {
                                is_pure_exp = false;
                            }
                            Some(bnd) => {
                                binds.push(bnd);
                            }
                        }
                    }
                    None => {
                        // the statement wasn't a Decl; it could have been anything
                        if stms0.len() > 0 {
                            is_pure_exp = false;
                        }
                    }
                }
                stms.append(&mut stms0);
                match e0 {
                    Maybe::Never => {
                        is_pure_exp = false;
                        never_return = true;
                        // Don't process any of the later statements: they are unreachable.
                        break;
                    }
                    _ => {}
                }
            }
            let exp = if never_return {
                Maybe::Never
            } else if let Some(expr) = body_opt {
                let (mut stms1, exp) = expr_to_stm_opt(ctx, state, expr)?;
                if stms1.len() > 0 {
                    is_pure_exp = false;
                }
                stms.append(&mut stms1);
                exp
            } else {
                Maybe::Some(Value::ImplicitUnit(expr.span.clone()))
            };
            for _ in pre_local_decls.iter() {
                state.pop_scope();
            }
            state.pop_scope();
            match exp {
                Maybe::Some(Value::Exp(mut exp)) if is_pure_exp => {
                    // Pure expression: fold decls into Let bindings and return a single expression
                    for bnd in binds.iter().rev() {
                        let bnd = match &bnd.x {
                            BndX::Let(binders) => {
                                let binders = state.rename_delayed_to_exp_binders(binders);
                                bnd.new_x(BndX::Let(binders))
                            }
                            _ => panic!("expected BndX::Let for statement decl"),
                        };
                        exp = SpannedTyped::new(&expr.span, &exp.typ, ExpX::Bind(bnd, exp.clone()));
                    }
                    assert!(!never_return);
                    return Ok((vec![], Maybe::Some(Value::Exp(exp))));
                }
                _ => {
                    // Not pure: return statements + an expression
                    state.pre_local_decls.extend(pre_local_decls);
                    let block = Spanned::new(expr.span.clone(), StmX::Block(Arc::new(stms)));
                    Ok((vec![block], exp))
                }
            }
        }
        ExprX::AirStmt(s) => {
            let stmt = Spanned::new(expr.span.clone(), StmX::Air(s.clone()));
            return Ok((vec![stmt], Maybe::Some(Value::ImplicitUnit(expr.span.clone()))));
        }
        ExprX::Nondeterministic => {
            let kind = PreLocalDeclKind::Immutable(Immutable(LocalDeclKind::Nondeterministic));
            let (var_ident, exp) = state.declare_temp_var_stm(&expr.span, &expr.typ, kind);
            let stm = assume_has_typ(&var_ident, &expr.typ, &expr.span);
            Ok((vec![stm], Maybe::Some(Value::Exp(exp))))
        }
        ExprX::Await(e) => {
            let attrs = crate::ast::CallTargetAttrs {
                autospec: AutospecUsage::Final,
                const_var: false,
                assume_external_allowed: false,
            };
            let call_expr = SpannedTyped::new(
                &expr.span,
                &expr.typ,
                ExprX::Call {
                    target: CallTarget::Fun(
                        crate::ast::CallTargetKind::Static,
                        fun!(CrateId::Vstd => "future", "exec_await"),
                        Arc::new(vec![e.typ.clone()]),
                        Arc::new(vec![]),
                        attrs,
                    ),
                    args: Arc::new(vec![e.clone()]),
                    post_args: None,
                    body: None,
                },
            );
            let rewritten = expr_to_stm_opt(ctx, state, &call_expr)?;
            Ok(rewritten)
        }
        ExprX::BorrowMut(_place) | ExprX::BorrowMutTracked(_place) => {
            let (mut stms, bor_sst) = borrow_mut_to_sst(ctx, state, expr)?;
            match bor_sst {
                Maybe::Never => Ok((stms, Maybe::Never)),
                Maybe::Some((bor_sst, obligations)) => {
                    let BorrowMutSst { phase2_stm, mut_ref_exp, loc: _ } = bor_sst;
                    stms.push(phase2_stm);
                    typ_inv_obligations(
                        ctx,
                        state,
                        &mut stms,
                        obligations,
                        TypInv::BareMutRefError,
                    )?;
                    Ok((stms, Maybe::Some(Value::Exp(mut_ref_exp))))
                }
            }
        }
        ExprX::TwoPhaseBorrowMut(_place) => {
            panic!("TwoPhaseBorrowMut should have been handled by the parent node");
        }
        ExprX::ShrRefStructWrap(..) => {
            panic!("ShrRefStructWrap should have been simplified out");
        }
        ExprX::ReadPlace(place, _) | ExprX::ImplicitReborrowOrSpecRead(place, _, _) => {
            let (stms, e) = place_to_exp_for_read(ctx, state, place)?;
            let e = unwrap_or_return_never!(e, stms);
            Ok((stms, Maybe::Some(Value::Exp(e))))
        }
        ExprX::EvalAndResolve(e1, e2) => {
            let (mut stms, exp1) = expr_to_stm_opt(ctx, state, e1)?;
            let exp1 = to_exp_or_return_never!(exp1, stms);

            let (mut stms2, exp2) = expr_to_stm_opt(ctx, state, e2)?;
            let _exp2 = to_exp_or_return_never!(exp2, stms);

            stms.append(&mut stms2);
            Ok((stms, Maybe::Some(Value::Exp(exp1))))
        }
        ExprX::Old(e) => expr_to_stm_opt(ctx, state, e),
        ExprX::MatchGuardFreeze(scrutinee, body) => {
            let (stms, e) = expr_to_stm_opt(ctx, state, body)?;
            let (stms0, scrutinee) = place_to_exp_pair(ctx, state, scrutinee)?;
            assert!(stms0.len() == 0);
            let loc = match scrutinee {
                Maybe::Some((s, _, _)) => s,
                Maybe::Never => panic!("Verus Internal Error: MatchGuardFreeze failed"),
            };
            for stm in stms.iter() {
                if let Some(span) = crate::sst_vars::find_overlapping_assignment(stm, &loc) {
                    return Err(error(
                        &span,
                        "Verus doesn't support assigning to scrutinee during match guard",
                    ));
                }
            }

            Ok((stms, e))
        }
    }
}

/// expr_to_stm, but with extra type-invariant obligations that need to be resolved
/// This is needed to handle the case that looks like
/// call((
///     EvalAndResolve(
///         &mut x,
///         Assume(HasResolved(...))
/// ))
/// which can result from resolution-analysis
fn expr_to_stm_opt_with_delayed_obligations(
    ctx: &Ctx,
    state: &mut State,
    expr: &Expr,
) -> Result<(Vec<Stm>, Maybe<(Value, Vec<Obligation>)>), VirErr> {
    match &expr.x {
        ExprX::BorrowMut(_place) | ExprX::BorrowMutTracked(_place) => {
            let (mut stms, bor_sst) = borrow_mut_to_sst(ctx, state, expr)?;
            match bor_sst {
                Maybe::Never => Ok((stms, Maybe::Never)),
                Maybe::Some((bor_sst, obligations)) => {
                    let BorrowMutSst { phase2_stm, mut_ref_exp, loc: _ } = bor_sst;
                    stms.push(phase2_stm);
                    Ok((stms, Maybe::Some((Value::Exp(mut_ref_exp), obligations))))
                }
            }
        }
        ExprX::EvalAndResolve(e1, e2) => {
            let (mut stms, exp1) = expr_to_stm_opt_with_delayed_obligations(ctx, state, e1)?;
            let (exp1, obligations) = unwrap_or_return_never!(exp1, stms);

            let (mut stms2, exp2) = expr_to_stm_opt(ctx, state, e2)?;
            let _exp2 = unwrap_or_return_never!(exp2, stms);

            stms.append(&mut stms2);
            Ok((stms, Maybe::Some((exp1, obligations))))
        }
        ExprX::UnaryOpr(op @ UnaryOpr::ToDyn(..), e1)
            if matches!(&*undecorate_typ(&expr.typ), TypX::MutRef(_)) =>
        {
            let (mut stms, exp1) = expr_to_stm_opt_with_delayed_obligations(ctx, state, e1)?;
            let (exp1, obligations) = unwrap_or_return_never!(exp1, stms);
            let exp1 = exp1.to_exp();
            let out = mut_ref_to_dyn_sst(state, &expr.span, &mut stms, &exp1, op, &expr.typ);
            Ok((stms, Maybe::Some((Value::Exp(out), obligations))))
        }
        _ => {
            let (stms, e) = expr_to_stm_opt(ctx, state, expr)?;
            match e {
                Maybe::Never => Ok((stms, Maybe::Never)),
                Maybe::Some(e) => Ok((stms, Maybe::Some((e, vec![])))),
            }
        }
    }
}

fn atomic_update_bind_and_resolve(
    expr: &Expr,
    typ_args: &Typs,
    au_exp: &Exp,
    x_exp: &Exp,
    y_exp: &Exp,
    stms: &mut Vec<Stm>,
) {
    for (fun, var_exp) in [(def::fn_au_input(), x_exp), (def::fn_au_output(), y_exp)] {
        let call_exp = SpannedTyped::new(
            &expr.span,
            &var_exp.typ,
            ExpX::Call(CallFun::Fun(fun, None), typ_args.clone(), Arc::new(vec![au_exp.clone()])),
        );

        stms.push(Spanned::new(
            expr.span.clone(),
            StmX::Assume(sst_equal(&expr.span, &call_exp, var_exp)),
        ));
    }

    let call_resolves = SpannedTyped::new(
        &expr.span,
        &Arc::new(TypX::Bool),
        ExpX::Call(
            CallFun::Fun(def::fn_au_resolves(), None),
            typ_args.clone(),
            Arc::new(vec![au_exp.clone()]),
        ),
    );

    stms.push(Spanned::new(expr.span.clone(), StmX::Assume(call_resolves)));
}

/// Translate the given binary op given its two arguments as Exps.
/// This handles overflow-checking semantics, but it does NOT handle short-circuiting,
/// that must be handled by the caller.
fn binary_op_exp(
    ctx: &Ctx,
    state: &mut State,
    span: &Span,
    typ: &Typ,
    op: BinaryOp,
    e1: &Exp,
    e2: &Exp,
) -> (Vec<Stm>, Exp) {
    let bin = if matches!(
        op,
        BinaryOp::Arith(ArithOp::TruncatingDiv(_, _))
            | BinaryOp::Arith(ArithOp::TruncatingMod(_, _))
    ) {
        let f = match op {
            BinaryOp::Arith(ArithOp::TruncatingDiv(_, _)) => crate::def::fn_truncating_div(),
            BinaryOp::Arith(ArithOp::TruncatingMod(_, _)) => crate::def::fn_truncating_mod(),
            _ => unreachable!(),
        };
        let call_fun = CallFun::Fun(f, None);
        let expx = ExpX::Call(call_fun, Arc::new(vec![]), Arc::new(vec![e1.clone(), e2.clone()]));
        SpannedTyped::new(span, typ, expx)
    } else if let BinaryOp::UninterpretedFloat(op) = op {
        let kind = PreLocalDeclKind::Immutable(Immutable(LocalDeclKind::Nondeterministic));
        let (var_ident, exp) = state.declare_temp_var_stm(span, typ, kind);
        let stms = vec![
            assume_has_typ(&var_ident, typ, span),
            assume_fp_postcondition(&var_ident, e1, e2, op, &e1.typ, typ, span),
        ];
        return (stms, exp);
    } else {
        let pure_op = match op {
            // Ops with side-effects are turned into sst ops without side-effects
            BinaryOp::Arith(ArithOp::Add(_)) => sst::BinaryOp::Arith(sst::ArithOp::Add),
            BinaryOp::Arith(ArithOp::Sub(_)) => sst::BinaryOp::Arith(sst::ArithOp::Sub),
            BinaryOp::Arith(ArithOp::Mul(_)) => sst::BinaryOp::Arith(sst::ArithOp::Mul),
            BinaryOp::Arith(ArithOp::EuclideanDiv(_)) => {
                sst::BinaryOp::Arith(sst::ArithOp::EuclideanDiv)
            }
            BinaryOp::Arith(ArithOp::EuclideanMod(_)) => {
                sst::BinaryOp::Arith(sst::ArithOp::EuclideanMod)
            }
            BinaryOp::Bitwise(op, _) => sst::BinaryOp::Bitwise(op),
            BinaryOp::Index(kind, _) => sst::BinaryOp::Index(kind),

            // Handled in earlier case
            BinaryOp::Arith(ArithOp::TruncatingMod(_, _)) => unreachable!(),
            BinaryOp::Arith(ArithOp::TruncatingDiv(_, _)) => unreachable!(),
            BinaryOp::UninterpretedFloat(..) => unreachable!(),

            // Pure ops
            BinaryOp::BoolOrNoSC => sst::BinaryOp::Or,
            BinaryOp::BoolAndNoSC => sst::BinaryOp::And,
            BinaryOp::BoolXor => sst::BinaryOp::Xor,
            BinaryOp::HeightCompare { strictly_lt, recursive_function_field } => {
                sst::BinaryOp::HeightCompare { strictly_lt, recursive_function_field }
            }
            BinaryOp::Eq(_) => sst::BinaryOp::Eq,
            BinaryOp::Ne => sst::BinaryOp::Ne,
            BinaryOp::Inequality(op) => sst::BinaryOp::Inequality(op),
            BinaryOp::RealArith(op) => sst::BinaryOp::RealArith(op),
            BinaryOp::IeeeFloat(op) => sst::BinaryOp::IeeeFloat(op),
            BinaryOp::StrGetChar => sst::BinaryOp::StrGetChar,
        };
        SpannedTyped::new(span, typ, ExpX::Binary(pure_op, e1.clone(), e2.clone()))
    };

    // Insert bounds check
    let checks = match op {
        _ if state.view_as_spec => [None, None],
        BinaryOp::Arith(arith) => {
            let c1 = match arith {
                ArithOp::Add(ob) | ArithOp::Sub(ob) | ArithOp::Mul(ob) => match ob {
                    OverflowBehavior::Allow => None,
                    OverflowBehavior::Truncate(_) => None,
                    OverflowBehavior::Error(range) => {
                        let unary = UnaryOpr::HasType(Arc::new(TypX::Int(range)));
                        let has_type = ExpX::UnaryOpr(unary, bin.clone());
                        let has_type = SpannedTyped::new(span, &Arc::new(TypX::Bool), has_type);
                        Some((has_type, error(span, "possible arithmetic underflow/overflow")))
                    }
                },
                ArithOp::TruncatingDiv(_, sb) | ArithOp::TruncatingMod(_, sb) => match sb {
                    SignedDivEdgeCaseBehavior::Allow => None,
                    SignedDivEdgeCaseBehavior::Error(bitwidth) => {
                        let signed_type_min_x = ExpX::UnaryOpr(
                            UnaryOpr::IntegerTypeBound(IntegerTypeBoundKind::SignedMin),
                            sst_bitwidth(span, &bitwidth, &ctx.global.arch),
                        );
                        let signed_type_min =
                            SpannedTyped::new(span, &int_typ(), signed_type_min_x);
                        let ne1x = ExpX::Binary(sst::BinaryOp::Ne, e1.clone(), signed_type_min);
                        let ne1 = SpannedTyped::new(span, &bool_typ(), ne1x);

                        let negative1_const = crate::ast_util::const_int_from_i128(-1);
                        let negative1_x = ExpX::Const(negative1_const);
                        let negative1 = SpannedTyped::new(span, &int_typ(), negative1_x);
                        let ne2x = ExpX::Binary(sst::BinaryOp::Ne, e2.clone(), negative1);
                        let ne2 = SpannedTyped::new(span, &bool_typ(), ne2x);

                        let cond = sst_disjoin(span, &[ne1, ne2]);
                        Some((
                            cond,
                            error(
                                span,
                                format!(
                                    "possible overflow case for signed {:}: cannot prove that (lhs, rhs) != ({:}::MIN, -1)",
                                    match arith {
                                        ArithOp::TruncatingDiv(..) => "division",
                                        ArithOp::TruncatingMod(..) => "remainder",
                                        _ => unreachable!(),
                                    },
                                    bitwidth_to_signed_type_string(&bitwidth)
                                ),
                            ),
                        ))
                    }
                },
                _ => None,
            };
            let c2 = match arith {
                ArithOp::EuclideanDiv(d0b)
                | ArithOp::EuclideanMod(d0b)
                | ArithOp::TruncatingDiv(d0b, _)
                | ArithOp::TruncatingMod(d0b, _) => match d0b {
                    Div0Behavior::Allow => None,
                    Div0Behavior::Error => {
                        let zero = ExpX::Const(Constant::Int(BigInt::zero()));
                        let ne = ExpX::Binary(sst::BinaryOp::Ne, e2.clone(), e2.new_x(zero));
                        let ne = SpannedTyped::new(span, &Arc::new(TypX::Bool), ne);
                        Some((ne, error(span, "possible division by zero")))
                    }
                },
                _ => None,
            };
            [c1, c2]
        }
        BinaryOp::Bitwise(bitwise, mode) => {
            match (mode, bitwise) {
                (BitshiftBehavior::Error(w), BitwiseOp::Shr | BitwiseOp::Shl(_, _)) => {
                    // Add overflow checks for bit shifts
                    // For a shift `a << b` or `a >> b`, Rust requires that
                    //    0 <= b < (bitsize of a)
                    // However, for spec code, this is extended in the obvious way to
                    // integers outside the range (at least, for b >= 0).
                    // So we don't need to do a check for here spec code.

                    let zero = sst_int_literal(span, 0);
                    let bitwidth = sst_bitwidth(span, &w, &ctx.global.arch);

                    let assert_exp = sst_conjoin(
                        span,
                        &vec![sst_le(span, &zero, &e2), sst_lt(span, &e2, &bitwidth)],
                    );

                    let msg = "possible bit shift underflow/overflow";
                    [Some((assert_exp, error(span, msg))), None]
                }
                (BitshiftBehavior::Allow, BitwiseOp::Shr | BitwiseOp::Shl(..)) => [None, None],
                (_, BitwiseOp::BitXor | BitwiseOp::BitAnd | BitwiseOp::BitOr) => {
                    // no overflow check needed
                    [None, None]
                }
            }
        }
        BinaryOp::Index(kind, bounds_check) => match bounds_check {
            BoundsCheck::Allow => [None, None],
            BoundsCheck::Error => {
                [Some(crate::place_preconditions::sst_index_bound(span, e1, e2, kind)), None]
            }
        },
        _ => [None, None],
    };

    let mut stms = vec![];

    for (assert_exp, msg) in checks.into_iter().flatten() {
        if !state.checking_spec_preconditions(ctx) {
            let assert = StmX::Assert(state.next_assert_id(), Some(msg), assert_exp.clone());
            let assert = Spanned::new(span.clone(), assert);
            stms.push(assert);
        }

        let assume = StmX::Assume(assert_exp);
        let assume = Spanned::new(span.clone(), assume);
        stms.push(assume);
    }

    // Add truncation if necessary

    let trunc = if let BinaryOp::Arith(arith) = op {
        match arith {
            ArithOp::Add(ob) | ArithOp::Sub(ob) | ArithOp::Mul(ob) => match ob {
                OverflowBehavior::Allow => None,
                OverflowBehavior::Truncate(range) => Some(range),
                OverflowBehavior::Error(range) => Some(range),
            },
            _ => None,
        }
    } else {
        None
    };

    let bin = match trunc {
        Some(IntRange::Int) => bin,
        Some(range) => {
            let unary_op = UnaryOp::Clip { truncate: true, range };
            SpannedTyped::new(span, typ, ExpX::Unary(unary_op, bin))
        }
        None => bin,
    };

    (stms, bin)
}

/// assume(add_ensures(e1, e2, x)); (specific function depends on the op)
pub(crate) fn assume_fp_postcondition(
    x: &UniqueIdent,
    e1: &Exp,
    e2: &Exp,
    op: UninterpretedFloatBinaryOp,
    float_typ: &Typ,
    out_typ: &Typ,
    span: &Span,
) -> Stm {
    let float_typ = undecorate_typ(float_typ);
    assert!(matches!(*float_typ, TypX::Float(..)));

    let xvarx = ExpX::Var(x.clone());
    let xvar = SpannedTyped::new(span, out_typ, xvarx);
    let name = def::fn_fp_postcondition_name(op);
    let call_fun = CallFun::Fun(name, None);
    let typ_args = Arc::new(vec![float_typ.clone()]);
    let expx = ExpX::Call(call_fun, typ_args, Arc::new(vec![e1.clone(), e2.clone(), xvar.clone()]));
    let exp = SpannedTyped::new(span, &Arc::new(TypX::Bool), expx);
    Spanned::new(span.clone(), StmX::Assume(exp))
}

/// Stms and Exps needed to execute a 2-phase borrow.
///
/// There's no phase1_stms field because it goes on the outside:
///  `(Vec<Stm>, Maybe<BorrowMutSst>)`
struct BorrowMutSst {
    /// Stm to execute "phase 2". It needs to be safe to delay this.
    phase2_stm: Stm,
    /// Exp representing the mutable borrow.
    /// This will always be a (non-mutable) temp variable.
    mut_ref_exp: Exp,
    /// Location being modified
    loc: Exp,
}

/// Given a mutable borrow expr (either BorrowMut or TwoPhaseBorrowMut), lowers it to the
/// SST semantics. The SST semantics include two phases:
///
///  - Phase 1: Evaluate the "place" and construct a mutable borrow such that
///    (mut_ref_current == the current value of the place) and mut_ref_future is arbitrary.
///
///  - Phase 2: Update the value of the "place" to be the mut_ref_future value.
///
/// For a "normal" borrow, these phases are executed together, and for a "two phase borrow",
/// they are executed apart. So for example, if we have a two-phase borrow in:
///
/// ```rust
/// struct Value { x: u64 }
/// impl Value {
///     fn foo(&mut self, old_x: u64) { self.x = old_x + 1; }
/// }
/// let mut a = Value { x: 7 };
/// a.foo(a.x);
/// assert_eq!(a.x, 8);
/// ```
///
/// The method call is conceptually `foo(&mut[two_phase] a, a.x)` in compiler
/// notation; an explicit `foo(&mut a, a.x)` is not valid Rust borrowing.
///
/// The first phase would be the evaluation of `&mut a`, while the second phase (updating
/// the value of local variable `a`) would take place *after* the evaluation of `a.x`.
/// Thus, when `a.x` is executed, we correctly read the pre-borrow value of `a`.
fn borrow_mut_to_sst(
    ctx: &Ctx,
    state: &mut State,
    expr: &Expr,
) -> Result<(Vec<Stm>, Maybe<(BorrowMutSst, Vec<Obligation>)>), VirErr> {
    let place = match &expr.x {
        ExprX::BorrowMut(p) => p,
        ExprX::BorrowMutTracked(p) => p,
        ExprX::TwoPhaseBorrowMut(p) => p,
        _ => panic!("borrow_mut_to_sst must be called for BorrowMut or TwoPhaseBorrowMut"),
    };

    let (stms, exps) = place_to_exp_pair(ctx, state, place)?;
    let (lhs_exp, normal_exp, obligations) = unwrap_or_return_never!(exps, stms);

    // phase 1
    let (var_ident, mut_ref_exp) = state.declare_temp_var_stm(
        &expr.span,
        &expr.typ,
        PreLocalDeclKind::Immutable(Immutable(LocalDeclKind::BorrowMut)),
    );
    // expr.typ might be &mut T or &mut Tracked<T>
    // the latter if this is from mut_ref_tracked
    let has_typ_stm = assume_has_typ(&var_ident, &expr.typ, &expr.span);

    let cur_exp = sst_mut_ref_current(&expr.span, &mut_ref_exp);
    let equal = sst_equal(&expr.span, &cur_exp, &normal_exp);
    let assume_stm = Spanned::new(expr.span.clone(), StmX::Assume(equal));

    let mut phase1_stms = stms;
    phase1_stms.push(has_typ_stm);
    phase1_stms.push(assume_stm);

    // phase 2

    let sn = crate::ast::MutRefFutureSourceName::MutRefFuture;
    let future_expx = ExpX::Unary(UnaryOp::MutRefFuture(sn), mut_ref_exp.clone());
    let t = match &*expr.typ {
        TypX::MutRef(t) => t,
        _ => panic!("sst_mut_ref_future expected MutRef type"),
    };
    let future_exp = SpannedTyped::new(&expr.span, &t, future_expx);

    let assignx =
        StmX::Assign { lhs: Dest { dest: lhs_exp.clone(), is_init: false }, rhs: future_exp };
    let assign = Spanned::new(expr.span.clone(), assignx);

    Ok((
        phase1_stms,
        Maybe::Some((BorrowMutSst { phase2_stm: assign, mut_ref_exp, loc: lhs_exp }, obligations)),
    ))
}

/// Lowers the coercion of `src: &mut T` to `&mut dyn Trait` to a new reference `out` with
///   mut_ref_current(out) == to_dyn(mut_ref_current(src))
///   mut_ref_future(out) == to_dyn(mut_ref_future(src))
fn mut_ref_to_dyn_sst(
    state: &mut State,
    span: &Span,
    stms: &mut Vec<Stm>,
    src: &Exp,
    to_dyn_op: &UnaryOpr,
    out_typ: &Typ,
) -> Exp {
    let TypX::MutRef(dyn_typ) = &*undecorate_typ(out_typ) else {
        panic!("mut_ref_to_dyn_sst expected MutRef type");
    };
    let (var_ident, out) = state.declare_temp_var_stm(
        span,
        out_typ,
        PreLocalDeclKind::Immutable(Immutable(LocalDeclKind::BorrowMut)),
    );
    stms.push(assume_has_typ(&var_ident, out_typ, span));
    let to_dyn = |e: Exp| SpannedTyped::new(span, dyn_typ, ExpX::UnaryOpr(to_dyn_op.clone(), e));
    let cur =
        sst_equal(span, &sst_mut_ref_current(span, &out), &to_dyn(sst_mut_ref_current(span, src)));
    let fut =
        sst_equal(span, &sst_mut_ref_future(span, &out), &to_dyn(sst_mut_ref_future(span, src)));
    stms.push(Spanned::new(span.clone(), StmX::Assume(cur)));
    stms.push(Spanned::new(span.clone(), StmX::Assume(fut)));
    out
}

#[derive(Clone, Debug)]
struct Obligation {
    fun: Fun,
    exp: Exp,
}

/// Compute the place expression and read from the place
fn place_to_exp_for_read(
    ctx: &Ctx,
    state: &mut State,
    place: &Place,
) -> Result<(Vec<Stm>, Maybe<Exp>), VirErr> {
    // Try to lower without creating unnecessary temporaries if we can.
    // As always, we need to generate a pure Exp with no Stms if it's possible.
    if place_is_simple(place) {
        return place_to_exp_simple(ctx, state, place);
    }
    let (stms, res) = place_to_exp_pair(ctx, state, place)?;
    let (_lhs, rhs, obligations) = unwrap_or_return_never!(res, stms);
    if obligations.len() > 0 {
        // Shouldn't have these for reads
        return Err(error(
            &place.span,
            "Verus internal error: place_to_expr_for_read does not expect any UserDefinedTypInvariantObligation",
        ));
    }
    Ok((stms, Maybe::Some(rhs)))
}

fn place_is_simple(place: &Place) -> bool {
    match &place.x {
        PlaceX::Local(_) => true,
        PlaceX::Temporary(_) => true,
        PlaceX::DerefMut(p) | PlaceX::ModeUnwrap(p, _) => place_is_simple(p),
        PlaceX::Field(field_opr, p) => {
            matches!(field_opr.check, VariantCheck::None) && place_is_simple(p)
        }
        PlaceX::WithExpr(..) => false,
        PlaceX::Index(p, i, _k, bounds_check) => {
            // An Index with no bounds check could show up from an Assert added
            // by ast_simplify, so we need to allow this in order to generate a pure Exp
            let index_is_simple = match &i.x {
                ExprX::Const(_) => true,
                ExprX::Var(_) => true,
                ExprX::ReadPlace(place, _) => match &place.x {
                    PlaceX::Local(_) => true,
                    _ => false,
                },
                _ => false,
            };
            matches!(bounds_check, BoundsCheck::Allow) && index_is_simple && place_is_simple(p)
        }
        PlaceX::UserDefinedTypInvariantObligation(..) => false,
    }
}

/// Precondition: place_is_simple
fn place_to_exp_simple(
    ctx: &Ctx,
    state: &mut State,
    place: &Place,
) -> Result<(Vec<Stm>, Maybe<Exp>), VirErr> {
    let mk_exp = |expx: ExpX| SpannedTyped::new(&place.span, &place.typ, expx);
    match &place.x {
        PlaceX::Local(x) => {
            let unique_id = state.get_var_unique_id(&x);
            let e_r = mk_exp(ExpX::Var(unique_id));
            let e_r = mk_exp(ExpX::Unary(UnaryOp::MustBeFinalized, e_r));
            Ok((vec![], Maybe::Some(e_r)))
        }
        PlaceX::Temporary(e) => {
            let (stms, v) = expr_to_stm_opt(ctx, state, e)?;
            let exp = to_exp_or_return_never!(v, stms);
            Ok((stms, Maybe::Some(exp)))
        }
        PlaceX::ModeUnwrap(p, _) => place_to_exp_simple(ctx, state, p),
        PlaceX::DerefMut(p) => {
            let (stms, e) = place_to_exp_simple(ctx, state, p)?;
            let e = unwrap_or_return_never!(e, stms);
            let e = mk_exp(ExpX::Unary(UnaryOp::MutRefCurrent, e));
            Ok((stms, Maybe::Some(e)))
        }
        PlaceX::Field(field_opr, p) => {
            assert!(matches!(field_opr.check, VariantCheck::None));
            let (stms, e) = place_to_exp_simple(ctx, state, p)?;
            let e = unwrap_or_return_never!(e, stms);
            let e = mk_exp(ExpX::UnaryOpr(UnaryOpr::Field(field_opr.clone()), e));
            Ok((stms, Maybe::Some(e)))
        }
        PlaceX::WithExpr(..) => unreachable!(),
        PlaceX::Index(p, i, kind, bounds_check) => {
            assert!(matches!(bounds_check, BoundsCheck::Allow));
            let (stms, e) = place_to_exp_simple(ctx, state, p)?;
            let e = unwrap_or_return_never!(e, stms);
            let i = expr_to_pure_exp_skip_checks(ctx, state, i)?;
            let op = sst::BinaryOp::Index(*kind);
            let e = mk_exp(ExpX::Binary(op, e, i));
            Ok((stms, Maybe::Some(e)))
        }
        PlaceX::UserDefinedTypInvariantObligation(..) => unreachable!(),
    }
}

/// Use this when you need to both read and write to a given place
///
/// Returns:
/// (i) the place as sst "loc" (l-value) which MUST NOT depend on any mutable vars.
/// (ii) the evaluation of the place (by definition, this is dependent
/// on the mutable var in question, but it must not depend on any other mutable vars)
/// (iii) a vector of expressions that need to have their type invariants re-asserted after
/// after the mutation is complete.
fn place_to_exp_pair(
    ctx: &Ctx,
    state: &mut State,
    place: &Place,
) -> Result<(Vec<Stm>, Maybe<(Exp, Exp, Vec<Obligation>)>), VirErr> {
    let mk_exp = |expx: ExpX| SpannedTyped::new(&place.span, &place.typ, expx);
    let (mut stms, exps) = place_to_exp_pair_rec(ctx, state, place)?;
    let exps = match exps {
        Maybe::Never => Maybe::Never,
        Maybe::Some((e1, e2, obligations, wf)) => {
            stms.extend(wf);
            let e1 = mk_exp(ExpX::Loc(e1));
            Maybe::Some((e1, e2, obligations))
        }
    };
    Ok((stms, exps))
}

/// Returns:
/// (1) place as an l-value (sst loc)
/// (2) place as an r-value (normal Exp)
/// (3) type invariant obligations that must be satisfied after the loc is written to
/// (4) assertions to check well-formedness of the place
///     (those that aren't already discharged in the Stms).
///     See place_preconditions.rs for more information on handling these.
fn place_to_exp_pair_rec(
    ctx: &Ctx,
    state: &mut State,
    place: &Place,
) -> Result<(Vec<Stm>, Maybe<(Exp, Exp, Vec<Obligation>, Vec<Stm>)>), VirErr> {
    let mk_exp = |expx: ExpX| SpannedTyped::new(&place.span, &place.typ, expx);
    match &place.x {
        PlaceX::Field(field_opr, p) => {
            let (stms, exps) = place_to_exp_pair_rec(ctx, state, p)?;
            let (e1, e2, obligations, mut wf) = unwrap_or_return_never!(exps, stms);

            let check = match field_opr.check {
                VariantCheck::Union => {
                    let (condition, msg) =
                        crate::place_preconditions::sst_field_check(&place.span, &e2, field_opr);
                    Some((condition, msg, true))
                }
                // `get_variant` accessors are total - just give a recommends-only hint.
                VariantCheck::Recommends => {
                    let (condition, msg) = crate::place_preconditions::sst_field_recommends_check(
                        &place.span,
                        &e2,
                        field_opr,
                    );
                    Some((condition, msg, false))
                }
                VariantCheck::None => None,
            };
            if let Some((condition, msg, is_hard_requirement)) = check {
                wf.extend(field_check_stms(
                    state,
                    ctx,
                    &place.span,
                    condition,
                    msg,
                    is_hard_requirement,
                ));
            }

            let field_opr = FieldOpr { check: VariantCheck::None, ..field_opr.clone() };

            let e1 = mk_exp(ExpX::UnaryOpr(UnaryOpr::Field(field_opr.clone()), e1));
            let e2 = mk_exp(ExpX::UnaryOpr(UnaryOpr::Field(field_opr), e2));
            Ok((stms, Maybe::Some((e1, e2, obligations, wf))))
        }
        PlaceX::DerefMut(p) => {
            let (stms, exps) = place_to_exp_pair_rec(ctx, state, p)?;
            let (e1, e2, obligations, wf) = unwrap_or_return_never!(exps, stms);
            let e1 = mk_exp(ExpX::Unary(UnaryOp::MutRefCurrent, e1));
            let e2 = mk_exp(ExpX::Unary(UnaryOp::MutRefCurrent, e2));
            Ok((stms, Maybe::Some((e1, e2, obligations, wf))))
        }
        PlaceX::Local(x) => {
            let unique_id = state.get_var_unique_id(&x);
            let e_l = mk_exp(ExpX::VarLoc(unique_id.clone()));
            let e_r = mk_exp(ExpX::Var(unique_id));
            let e_r = mk_exp(ExpX::Unary(UnaryOp::MustBeFinalized, e_r));
            Ok((vec![], Maybe::Some((e_l, e_r, vec![], vec![]))))
        }
        PlaceX::Temporary(e) => {
            let (mut stms, v) = expr_to_stm_opt(ctx, state, e)?;
            let exp = to_exp_or_return_never!(v, stms);

            let (temp_id, temp_var) =
                state.declare_temp_var_stm(&exp.span, &exp.typ, PreLocalDeclKind::StmtLet);
            stms.push(init_var(&exp.span, &temp_id, &exp));

            let e_l = mk_exp(ExpX::VarLoc(temp_id.clone()));

            Ok((stms, Maybe::Some((e_l, temp_var, vec![], vec![]))))
        }
        PlaceX::WithExpr(e, p) => {
            let (mut stms, v) = expr_to_stm_opt(ctx, state, e)?;
            let _e = unwrap_or_return_never!(v, stms);

            let (mut stms2, exps) = place_to_exp_pair_rec(ctx, state, p)?;
            stms.append(&mut stms2);

            Ok((stms, exps))
        }
        PlaceX::ModeUnwrap(p, _mode) => place_to_exp_pair_rec(ctx, state, p),
        PlaceX::Index(p, idx, kind, bounds_check) => {
            let (mut stms, exps) = place_to_exp_pair_rec(ctx, state, p)?;
            let (e1, e2, obligations, mut wf) = unwrap_or_return_never!(exps, stms);

            let (mut stms2, idx_v) = expr_to_stm_opt(ctx, state, idx)?;
            stms.append(&mut stms2);
            let idx_exp = to_exp_or_return_never!(idx_v, stms);

            let idx_exp = state.make_tmp_var_for_exp(&mut stms, idx_exp);

            match bounds_check {
                BoundsCheck::Allow => {}
                BoundsCheck::Error => {
                    if kind.getting_len_requires_read() {
                        stms.extend(wf);
                        wf = vec![];
                    }
                    let (condition, msg) = crate::place_preconditions::sst_index_bound(
                        &place.span,
                        &e2,
                        &idx_exp,
                        *kind,
                    );
                    if !state.checking_recommends(ctx) {
                        let stm = Spanned::new(
                            place.span.clone(),
                            StmX::Assert(state.next_assert_id(), Some(msg), condition.clone()),
                        );
                        stms.push(stm);
                    }
                    let stm = Spanned::new(place.span.clone(), StmX::Assume(condition));
                    stms.push(stm);
                }
            }

            let op = sst::BinaryOp::Index(*kind);
            let e_l = mk_exp(ExpX::Binary(op, e1, idx_exp.clone()));
            let e_r = mk_exp(ExpX::Binary(op, e2, idx_exp));

            Ok((stms, Maybe::Some((e_l, e_r, obligations, wf))))
        }
        PlaceX::UserDefinedTypInvariantObligation(p, fun) => {
            let (stms, mut exps) = place_to_exp_pair_rec(ctx, state, p)?;
            if let Maybe::Some((_e1, e2, obligations, _wf)) = &mut exps {
                obligations.push(Obligation { fun: fun.clone(), exp: e2.clone() });
            }
            Ok((stms, exps))
        }
    }
}

/// In the case that this stmt is a Decl, we also return the following information:
///
///    * An SST LocalDecl for the declaration
///    * Optionally, An SST Bnd for the declaration (only if the right-hand side is pure)
///
/// Thus, when the Bnd is available, the caller of this fn has the option of whether
/// to use the LocalDecl or the Bnd; they can use the Bnds in order to construct a pure
/// expression or LocalDecls to construct an impure one.
/// (Note: a declaration by itself being marked 'mutable' doesn't matter for determining
/// purity; it only matters if there are assignments later.)
fn stmt_to_stm(
    ctx: &Ctx,
    state: &mut State,
    stmt: &Stmt,
) -> Result<(Vec<Stm>, Maybe<Value>, Option<(VarIdent, PreLocalDecl, Option<Bnd>)>), VirErr> {
    match &stmt.x {
        StmtX::Expr(expr) => {
            let (stms, exp) = expr_to_stm_opt(ctx, state, expr)?;
            Ok((stms, exp, None))
        }
        StmtX::Decl { pattern, mode: _, init, els, assert_irrefutable: _ } => {
            if els.is_some() {
                panic!("let-else should be simplified in ast_simpllify {:?}.", stmt)
            }
            let (name, typ) = match &pattern.x {
                PatternX::Var(PatternBinding {
                    name,
                    user_mut: _,
                    by_ref: ByRef::No,
                    typ,
                    copy: _,
                }) => (name, typ),
                _ => panic!("internal error: Decl should have been simplified by ast_simplify"),
            };

            let rename = state.rename_var_maybe_exp(&name);
            let ident = rename.clone();
            let decl = PreLocalDecl { ident, typ: typ.clone(), kind: PreLocalDeclKind::StmtLet };

            // First check if the initializer needs to be translate to a Call instead
            // of an Exp. If so, translate it that way.
            if let Some(init) = &init {
                match place_must_be_call_stm(ctx, state, Some(&typ), init)? {
                    Some((stms, Maybe::Never)) => {
                        return Ok((stms, Maybe::Never, None));
                    }
                    Some((
                        mut stms,
                        Maybe::Some(ReturnedCall {
                            fun,
                            resolved_method,
                            is_trait_default,
                            typs,
                            has_return: _,
                            args,
                            obligations,
                            may_unwind,
                            body,
                        }),
                    )) => {
                        // Special case: convert to a Call
                        // It can't be pure in this case, so don't return a Bnd.
                        let dest = Dest {
                            dest: var_loc_exp(&pattern.span, &typ, decl.ident.clone()),
                            is_init: true,
                        };
                        stms.push(stm_call(
                            ctx,
                            state,
                            &init.span,
                            fun.clone(),
                            resolved_method,
                            is_trait_default,
                            typs,
                            args,
                            Some(dest),
                            body,
                        )?);
                        // REVIEW: for a similar case in `ExprX::Call` we emit a StmX::Assign to set the
                        // value of the destination when, in recommends checking, the StmX::Call is used
                        // to check its recommends, however we do not do this here.
                        // That may cause recommends incompleteness. We should either use the `ExprX::Call`
                        // special-case for recommends here, or replace this logic with a recursive call
                        // to handle the right-hand-side, if possible.
                        let ret = Maybe::Some(Value::ImplicitUnit(stmt.span.clone()));

                        let ti = if may_unwind { TypInv::UnwindError } else { TypInv::Call(fun) };
                        typ_inv_obligations(ctx, state, &mut stms, obligations, ti)?;

                        return Ok((stms, ret, Some((name.clone(), decl, None))));
                    }
                    None => {}
                }
            }

            // Otherwise, translate the initializer to an Exp.
            let (mut stms, exp) = match &init {
                None => (vec![], None),
                Some(init) => {
                    let (stms, exp) = place_to_exp_for_read(ctx, state, init)?;
                    let exp = match exp {
                        Maybe::Some(exp) => exp,
                        Maybe::Never => {
                            return Ok((stms, Maybe::Never, None));
                        }
                    };
                    (stms, Some(exp))
                }
            };

            // For a pure expression (i.e., one with no SST statements), return a binder
            let bnd = match &exp {
                Some(exp) if stms.len() == 0 => {
                    let binder = VarBinderX { name: rename.clone(), a: exp.clone() };
                    let bnd = BndX::Let(Arc::new(vec![Arc::new(binder)]));
                    Some(Spanned::new(stmt.span.clone(), bnd))
                }
                _ => None,
            };

            match &exp {
                None => {}
                Some(exp) => {
                    stms.push(init_var(&stmt.span, &decl.ident, exp));
                }
            }

            let ret = Maybe::Some(Value::ImplicitUnit(stmt.span.clone()));
            Ok((stms, ret, Some((name.clone(), decl, bnd))))
        }
    }
}

/// Handle the internal of a closure
fn exec_closure_body_stms(
    ctx: &Ctx,
    state: &mut State,
    params: &VarBinders<Typ>,
    ret: &VarBinder<Typ>,
    body: &Expr,
    requires: &Exprs,
    ensures: &Exprs,
) -> Result<(Vec<Stm>, Arc<Vec<(UniqueIdent, Typ)>>, Option<Stm>), VirErr> {
    let mut typ_inv_vars = vec![];

    state.push_scope();

    // Right now there is no way to specify an invariant mask on a closure function
    // All closure funcs are assumed to have mask set 'full'
    let mut mask = Some(MaskSet::full(&body.span));
    std::mem::swap(&mut state.mask, &mut mask);

    let mut param_set = HashSet::<VarIdent>::new();

    for param in params.iter() {
        let kind = PreLocalDeclKind::ExecClosureParam;
        let uid = state.declare_var_stm(&param.name, &param.a, kind, false);
        typ_inv_vars.push((uid.clone(), param.a.clone()));
        param_set.insert(uid);
    }

    // Assert all the requires

    let infer_callback = ctx.fun.as_ref().is_some_and(|function| {
        crate::infer::checks_exact_callbacks(&ctx.func_map[&function.current_fun])
    }) && !state.checking_spec_preconditions(ctx);
    let mut callback_pre = vec![];
    let mut precision_body = None;
    let mut stms = Vec::new();
    for req in requires.iter() {
        let (check_stms, exp) = expr_to_pure_exp_check(ctx, state, req)?;
        if infer_callback && !check_stms.is_empty() {
            return Err(error(
                &req.span,
                "Verus Infer incomplete: callback contracts require pure scalar conditions",
            ));
        }
        callback_pre.push(exp.clone());
        stms.extend(check_stms);
        let stm = Spanned::new(req.span.clone(), StmX::Assume(exp));
        stms.push(stm);
    }

    let kind = PreLocalDeclKind::Immutable(Immutable(LocalDeclKind::ExecClosureRet));
    state.declare_var_stm(&ret.name, &ret.a, kind, false);
    let dest = def::unique_local(&ret.name);

    let mut ens_exps = Vec::new();
    let mut ens_checks = Vec::new();
    for ens in ensures.iter() {
        let (check_stms, exp) = expr_to_pure_exp_check(ctx, state, ens)?;
        ens_checks.extend(check_stms);
        ens_exps.push(exp);
    }
    if infer_callback && !ens_checks.is_empty() {
        return Err(error(
            &body.span,
            "Verus Infer incomplete: callback equations require pure scalar conditions",
        ));
    }

    let ens_exps = ens_exps.iter().map(|e| exp_with_vars_at_pre_state(e, &param_set)).collect();
    let ens_checks = ens_checks.iter().map(|s| stm_with_vars_at_pre_state(s, &param_set)).collect();

    // Set up the ClosureState so any 'return' statements inside know what to do

    let mut containing_closure = Some(ClosureState {
        ensures: Arc::new(ens_exps),
        dest: dest,
        ensures_checks: Arc::new(ens_checks),
    });
    std::mem::swap(&mut state.containing_closure, &mut containing_closure);

    let (mut body_stms, exp) = expr_to_stm_opt(ctx, state, body)?;
    let original_body_stms = body_stms.clone();
    stms.append(&mut body_stms);

    std::mem::swap(&mut state.containing_closure, &mut containing_closure);

    match exp.to_maybe_exp() {
        Maybe::Some(e) => {
            // Post condition for the return-value expression

            let closure_state = containing_closure.as_ref().unwrap();
            if infer_callback {
                if callback_pre.len() != 1 || closure_state.ensures.len() != 1 {
                    return Err(error(
                        &body.span,
                        "Verus Infer incomplete: independent callbacks require one complete result relation",
                    ));
                }
                let relation = &closure_state.ensures[0];
                let replace = |value: &Exp| {
                    map_exp_visitor(relation, &mut |term| {
                        if matches!(&term.x,ExpX::Var(n) if n==&closure_state.dest) {
                            value.clone()
                        } else {
                            term.clone()
                        }
                    })
                };
                let actual = replace(&e);
                // An arbitrary complete result, independent of the candidate
                // and its precondition. Derive equality observations from the
                // datatype rather than from the proposed relation.
                let (name, other) = state.next_temp(&e.span, &e.typ);
                state.declare_imm_var_stm(&name, &e.typ, LocalDeclKind::Assert, false);
                typ_inv_vars.push((name, e.typ.clone()));
                let equals = crate::infer_checks::output_equivalence(
                    ctx,
                    &e.span,
                    &e.typ,
                    other.clone(),
                    e.clone(),
                )?;
                let alternative = SpannedTyped::new(
                    &e.span,
                    &bool_typ(),
                    ExpX::Binary(sst::BinaryOp::Eq, replace(&other), equals),
                );
                let mut checks = original_body_stms.clone();
                // Placeholders survive ordinary SST renaming/coercion. The
                // independent transformer converts these final three entries
                // to assertions after converting ORIGINAL safety checks to assumptions.
                for goal in [callback_pre[0].clone(), actual, alternative] {
                    checks.push(Spanned::new(body.span.clone(), StmX::Assume(goal)));
                }
                precision_body =
                    Some(Spanned::new(body.span.clone(), StmX::Block(Arc::new(checks))));
            }
            closure_emit_postconditions(ctx, state, closure_state, &e, &mut stms);
        }
        Maybe::Never => { /* never-return case */ }
    }

    std::mem::swap(&mut state.mask, &mut mask);
    state.pop_scope();

    Ok((stms, Arc::new(typ_inv_vars), precision_body))
}

fn closure_emit_postconditions(
    ctx: &Ctx,
    state: &mut State,
    containing_closure: &ClosureState,
    ret_value: &Exp,
    stms: &mut Vec<Stm>,
) {
    let ClosureState { dest, ensures, ensures_checks } = containing_closure;
    stms.extend(ensures_checks.iter().cloned());
    if ensures.len() > 0 && !state.checking_spec_preconditions(ctx) {
        stms.push(init_var(&ret_value.span, dest, &ret_value));
        for ens in ensures.iter() {
            let er = error_with_secondary_label(
                &ret_value.span,
                "unable to prove post-condition of closure",
                "returning this expression",
            )
            .primary_label(&ens.span, def::THIS_POST_FAILED);
            let stm = Spanned::new(
                ens.span.clone(),
                StmX::Assert(state.next_assert_id(), Some(er), ens.clone()),
            );
            stms.push(stm);
        }
    }
}

fn get_inv_typ_args(typ: &Typ) -> Typs {
    match &**typ {
        TypX::Datatype(_, typs, _) => typs.clone(),
        TypX::Decorate(_, _, typ) | TypX::Boxed(typ) => get_inv_typ_args(typ),
        _ => {
            panic!("get_inv_typ_args failed, expected some Invariant type");
        }
    }
}

fn call_inv(_ctx: &Ctx, outer: &Exp, inner: &Exp, typ_args: &Typs, atomicity: InvAtomicity) -> Exp {
    let call_fun = CallFun::Fun(def::fn_inv_name(atomicity), None);
    let expx = ExpX::Call(call_fun, typ_args.clone(), Arc::new(vec![outer.clone(), inner.clone()]));
    SpannedTyped::new(&outer.span, &Arc::new(TypX::Bool), expx)
}

fn call_namespace(_ctx: &Ctx, arg: &Exp, typ_args: &Typs, atomicity: InvAtomicity) -> Exp {
    let call_fun = CallFun::Fun(def::fn_namespace_name(atomicity), None);
    let expx = ExpX::Call(call_fun, typ_args.clone(), Arc::new(vec![arg.clone()]));
    SpannedTyped::new(&arg.span, &Arc::new(TypX::Int(IntRange::Int)), expx)
}

#[derive(PartialEq, Eq, Clone)]
enum TypInv {
    UnwindError,
    BareMutRefError,
    Assign,
    Call(Fun),
    Constructed,
    Assume,
}

fn typ_inv_obligations(
    ctx: &Ctx,
    state: &mut State,
    stms: &mut Vec<Stm>,
    obligations: Vec<Obligation>,
    typ_inv: TypInv,
) -> Result<(), VirErr> {
    for obligation in obligations.into_iter().rev() {
        let Obligation { fun, exp } = obligation;
        assert_assume_satisfies_user_defined_type_invariant(
            ctx,
            state,
            &exp,
            stms,
            &fun,
            typ_inv.clone(),
        )?;
    }
    Ok(())
}

fn assert_assume_satisfies_user_defined_type_invariant(
    ctx: &Ctx,
    state: &mut State,
    exp: &Exp,
    stms: &mut Vec<Stm>,
    fun: &Fun,
    typ_inv: TypInv,
) -> Result<(), VirErr> {
    let typs = match &*undecorate_typ(&exp.typ) {
        TypX::Datatype(_path, typs, ..) => typs.clone(),
        _ => panic!("assert_assume_satisfies_user_defined_type_invariant: expected datatype"),
    };
    let call_fun = CallFun::Fun(fun.clone(), None);
    let expx = ExpX::Call(call_fun, typs, Arc::new(vec![exp.clone()]));
    let exp = SpannedTyped::new(&exp.span, &Arc::new(TypX::Bool), expx);

    let function = ctx.func_map.get(fun).unwrap();

    if typ_inv == TypInv::UnwindError {
        return Err(crate::messages::error_with_label(
            &exp.span,
            "this function call takes a &mut ref of a field of a datatype with a user-defined type invariant; thus, this function should be marked no_unwind (note: this check is currently implemented overly-conservatively and requires the function to be marked no_unwind in its signature)",
            "mutable reference to this place",
        ).secondary_label(&function.span, "type invariant declared here"));
    }
    if typ_inv == TypInv::BareMutRefError {
        return Err(crate::messages::error_with_label(
            &exp.span,
            "not supported: taking a mutable reference to a field of a datatype with a user-defined type invariant (except as an argument of a function call)",
            "mutable reference to this place",
        ).secondary_label(&function.span, "type invariant declared here"));
    }

    if state.checking_recommends(ctx) {
        stms.push(Spanned::new(exp.span.clone(), StmX::Assume(exp)));
    } else {
        let exp = state.make_tmp_var_for_exp(stms, exp);
        if typ_inv != TypInv::Assume {
            let error = crate::messages::error(
                &exp.span,
                match &typ_inv {
                    TypInv::Constructed =>
                        "constructed value may fail to meet its declared type invariant".to_string(),
                    TypInv::Call(fun) =>
                        format!("value may fail to meet its declared type invariant after mutation (type invariant is checked at end of call to `{:}`)", crate::ast_util::fun_as_friendly_rust_name(fun)),
                    TypInv::Assign =>
                        "value may fail to meet its declared type invariant after assignment".to_string(),
                    TypInv::Assume | TypInv::UnwindError | TypInv::BareMutRefError => unreachable!(),
                }
            )
            .secondary_label(&function.span, "type invariant declared here");
            stms.push(Spanned::new(
                exp.span.clone(),
                StmX::Assert(state.next_assert_id(), Some(error), exp.clone()),
            ));
        }
        stms.push(Spanned::new(exp.span.clone(), StmX::Assume(exp)));
    }
    Ok(())
}

fn find_loop_in_stms(stms: &[Stm], label: &Label) -> Option<(Vec<Stm>, Stm, Vec<Stm>)> {
    for i in 0..stms.len() {
        if let Some((prefix, the_loop, suffix)) = find_loop_in_stm(&stms[i], label) {
            let mut new_prefix = stms[..i].to_vec();
            new_prefix.extend(prefix);
            let mut new_suffix = suffix;
            new_suffix.extend(stms[i + 1..].to_vec());
            return Some((new_prefix, the_loop, new_suffix));
        }
    }
    None
}

fn find_loop_in_stm(stm: &Stm, label: &Label) -> Option<(Vec<Stm>, Stm, Vec<Stm>)> {
    match &stm.x {
        StmX::Block(stms) => find_loop_in_stms(stms, label),
        StmX::Loop { label: l, .. } if l == label => Some((vec![], stm.clone(), vec![])),
        _ => None,
    }
}

fn loop_set_pre_stms(the_loop: Stm, new_pre_stms: Stms) -> Stm {
    let mut the_loop = the_loop;
    match Arc::make_mut(&mut the_loop).x {
        StmX::Loop { ref mut pre_stms, .. } => {
            assert!(pre_stms.len() == 0);
            *pre_stms = new_pre_stms;
        }
        _ => panic!("loop_set_pre_stms expects Loop"),
    }
    the_loop
}
