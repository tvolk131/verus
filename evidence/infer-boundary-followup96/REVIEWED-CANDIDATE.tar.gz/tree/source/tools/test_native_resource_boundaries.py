import unittest

import check_native_resource_boundaries as boundaries


class BoundaryReplayTests(unittest.TestCase):
    def test_profiles_build_before_tests_with_explicit_offline_locked_commands(self):
        plan = boundaries.command_plan(boundaries.PROFILES)
        self.assertEqual([label for label, _ in plan], [
            "default-off-build", "default-off-tests", "feature-on-build", "feature-on-tests",
        ])
        for _, command in plan:
            self.assertEqual(command[0], "cargo")
            self.assertIn("--offline", command)
            self.assertIn("--locked", command)
        for _, command in plan[:2]:
            self.assertNotIn("--features", command)
        for _, command in plan[2:]:
            self.assertIn("vir/experimental-native-resource", command)
        for _, command in plan[1::2]:
            self.assertIn("--include-ignored", command)
            self.assertIn("--test-threads=1", command)

    def test_acceptance_requires_every_named_test_and_no_ignored_tests(self):
        text = "\n".join(f"test import_export::native_resource_boundary_tests::{name} ... ok"
                         for name in boundaries.TESTS)
        passing = text + "\ntest result: ok. 5 passed; 0 failed; 0 ignored; 1 filtered out;\n"
        self.assertTrue(boundaries.checked_test_log(passing))
        self.assertFalse(boundaries.checked_test_log(passing.replace(boundaries.TESTS[-1], "missing")))
        self.assertFalse(boundaries.checked_test_log(passing.replace("5 passed", "0 passed")))
        self.assertFalse(boundaries.checked_test_log(passing.replace("0 ignored", "1 ignored")))
        self.assertFalse(boundaries.checked_test_log(passing.replace("0 failed", "1 failed")))

    def test_identity_includes_production_guard_tests_and_configuration(self):
        identity = boundaries.source_identity()
        for name in (
            "rust-toolchain.toml", "source/Cargo.lock", "source/.cargo/config.toml",
            "source/rust_verify/src/import_export.rs", "source/rust_verify/src/verifier.rs",
            "source/vir/src/native_resource.rs",
            "source/rust_verify/src/import_export/native_resource_boundary_tests.rs",
        ):
            self.assertIn(name, identity)
            self.assertEqual(len(identity[name]), 64)


if __name__ == "__main__":
    unittest.main()
