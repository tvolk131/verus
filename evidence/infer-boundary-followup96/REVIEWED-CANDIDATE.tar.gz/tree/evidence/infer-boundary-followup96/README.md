# Boundary follow-up96 — validated; independent review pending

On November 7, 2026 the user explicitly authorized continued work through
ordinary engineering blockers and useful bounded side quests. This test-only
follow-up addresses nonblocking precision gaps from the independent hardening95
review; it is not a reset of cycle1 or any refused/exhausted proof allowance.
No new trust, theorem scope, certification policy or admission rule is adopted.

## Candidate changes

- Every marked artifact fixture has a distinct unmarked leading function, so
  rejection must find the later marker rather than merely inspect the first item.
- The metadata-precedence matrix supplies an inference-aware header and invalid
  JSON ending with the actual inference trailer marker. Matched unmarked inputs
  must reach the metadata diagnostic; marked inputs must instead produce the
  earlier, span-free resource refusal across both API routes and eight modes.
- The actual compiler-driver matrix has matched unmarked and marked inputs for
  all eight tested modes, with verified bodies in both root and selected modules.
  It checks structured success/error bookkeeping, an expanded panic/ICE oracle,
  nonpublication/stale-output removal for marked imports, and positive verifier
  counts in modes requesting verification. Filtered runs intentionally omit
  whole-crate success and keep full-scope body-certification counts at zero;
  these conservative report barriers are explicitly asserted. No-verify/build-SST
  controls require zero checked bodies and are not proof credit.

Only `source/rust_verify/src/import_export/native_resource_boundary_tests.rs`
changes implementation/test behavior. The production span-free rejection fix
and all native admission/export barriers remain unchanged. This does not add a
marked local-source producer, actual lowerer matrix or full Cargo-driver run,
and it does not close full F1, E1/E2–E6 or any final database obligation.

## Baseline and execution

Fresh scratch: `/private/tmp/verus-boundary-followup96-20261107`.
`BASELINE.json` records HEAD/status and 2,382 file hashes before this follow-up.
The original reviewed hardening95 archive, review and results are preserved as
historical milestone evidence; their recorded unchanged-source statements are
as of that closeout, not blanket review of this later test-only delta.

- `replay/receipt.json`: failed after successful build and four artifact tests.
  The newly expanded unmarked driver controls reached a filter panic in the
  fixture's root configuration: it contained a selected child body but no
  selected root body. This is a failed run, not a successful rejection control.
- The fixture now includes verified root and child bodies. This corrects the
  intended matched positive without weakening the failure oracle or changing
  production filtering behavior. The observed absent-root assertion path is
  not claimed repaired or universally covered by this follow-up.
- `replay2/receipt.json`: failed after a successful fresh build. The corrected
  root fixture worked, but the new test expected a whole-crate success field
  under filters. The production report deliberately omits that field and
  withholds full-scope body certification. Test expectations were corrected to
  require that conservative behavior, not relax it in production.
- `focused3/receipt.json`: the corrected five-test default-OFF matrix passed,
  with no ignored tests and no selected-input drift. This short test run reused
  replay2's target/unchanged production driver; it is not another cold build.
- `replay3/receipt.json`: final fresh-target locked/offline replay passed all
  five named tests in both default-OFF and feature-ON profiles, with no ignored
  tests and no selected-input drift. Both modes of the actual driver test ran
  all eight option configurations; filtered/no-verify controls do not acquire
  full-scope proof certification. One Cargo builder used two build jobs. No
  historical artifact or runtime is modified.
- `python-unit.log`: the three replay-tool unit tests passed. No broad Python
  suite rerun is claimed for this Rust-test-only behavioral change.

The frozen candidate includes the exact test-only delta against the previous
reviewed test bytes, current selected production inputs, all failed/successful
raw logs and the entry baseline. Fresh independent review remains pending.

The separately delegated native hex visibility repair is independent of this
current-parent test build and uses its coherent frozen operational91 runtime.
Its newly authorized iteration does not replace the first failed hex record.
All eighteen final redb obligations remain OPEN.
