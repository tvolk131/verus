import hashlib
import json
from pathlib import Path
import shutil
import subprocess


ROOT = Path('/Users/tommyvolk/.t3/worktrees/verus/t3-60978068')
WORK = Path('/private/tmp/verus-boundary-followup96-20261107')
TEST = 'source/rust_verify/src/import_export/native_resource_boundary_tests.rs'
DOCUMENTS = (
    'VERUS_INFER_STATUS.md',
    'evidence/infer-consolidation95/README.md',
    'source/vir/NATIVE_RESOURCE_IR.md',
    'evidence/redb-crash-consistency94/STATUS.json',
    'evidence/infer-boundary-followup96/README.md',
)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    baseline = json.loads((WORK / 'BASELINE.json').read_text())
    receipt = json.loads((WORK / 'replay3/receipt.json').read_text())
    if not receipt['success'] or receipt['input_drift']:
        raise RuntimeError('successful full replay required before sealing')
    drift = [name for name, expected in receipt['inputs'].items() if digest(ROOT / name) != expected]
    if drift:
        raise RuntimeError(f'tested input drift: {drift}')
    changed = {}
    for name, expected in baseline['files'].items():
        path = ROOT / name
        actual = digest(path) if path.is_file() else None
        if actual != expected:
            changed[name] = {'baseline_sha256': expected, 'candidate_sha256': actual}
    if set(changed) - {TEST, *DOCUMENTS}:
        raise RuntimeError(f'unexpected baseline changes: {sorted(set(changed) - {TEST, *DOCUMENTS})}')
    original_test = Path('/private/tmp/verus-consolidation-hardening-20261107-3uq41d0f/candidate1/tree') / TEST
    if digest(original_test) != baseline['files'][TEST]:
        raise RuntimeError('previous reviewed test bytes do not match followup entry')
    destination = WORK / 'candidate1'
    destination.mkdir(exist_ok=False)
    copied = {}
    support = (
        'evidence/infer-consolidation95/INDEPENDENT-REVIEW.md',
        'source/tools/test_native_resource_boundaries.py',
    )
    for name in sorted(set(receipt['inputs']) | set(DOCUMENTS) | set(support)):
        target = destination / 'tree' / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(ROOT / name, target)
        copied[str(target.relative_to(destination))] = digest(target)
    previous = destination / 'baseline-test.rs'
    shutil.copyfile(original_test, previous)
    copied[previous.name] = digest(previous)
    patch = subprocess.run(['diff', '-u', '--label', 'before/' + TEST, str(previous),
                            '--label', 'after/' + TEST, str(ROOT / TEST)], capture_output=True)
    if patch.returncode != 1:
        raise RuntimeError(f'expected focused test delta, diff returned {patch.returncode}')
    patch_path = destination / 'TEST-ONLY.patch'
    patch_path.write_bytes(patch.stdout)
    copied[patch_path.name] = digest(patch_path)
    artifacts = [WORK / 'BASELINE.json', WORK / 'seal.py', *WORK.glob('*.log')]
    for replay in ('replay', 'replay2', 'focused3', 'replay3'):
        artifacts.extend((WORK / replay).glob('*.log'))
        artifacts.extend((WORK / replay).glob('*.json'))
    for source in artifacts:
        target = destination / 'evidence' / source.relative_to(WORK)
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
        copied[str(target.relative_to(destination))] = digest(target)
    manifest = {
        'schema': 'boundary-followup96-candidate-v1',
        'classification': 'test-only engineering follow-up, no production semantics or native proof change',
        'baseline_head': baseline['head'],
        'baseline_file_count': len(baseline['files']),
        'changed_baseline_files': changed,
        'unrelated_baseline_files_unchanged': len(baseline['files']) - len(changed),
        'source_test_delta': 'TEST-ONLY.patch',
        'selected_replay_inputs_match': True,
        'copied_files': copied,
        'scope': {'native_resource_local_producer': False, 'actual_lowerer_matrix': False,
                  'full_cargo_driver': False, 'final_redb_obligations_open': 18},
    }
    output = destination / 'MANIFEST.json'
    output.write_text(json.dumps(manifest, indent=2) + '\n')
    print(json.dumps({'candidate': str(destination), 'manifest_sha256': digest(output),
                      'copied_file_count': len(copied),
                      'changed_baseline_files': len(changed),
                      'unrelated_baseline_files_unchanged': manifest['unrelated_baseline_files_unchanged']}, indent=2))


if __name__ == '__main__':
    main()
