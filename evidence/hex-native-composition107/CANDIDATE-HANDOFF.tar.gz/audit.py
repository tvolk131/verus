import collections
import difflib
import importlib.util
import json
import pathlib
import re
import sys
import tarfile

sys.dont_write_bytecode = True
import control

ROOT = control.ROOT
oracle_spec = importlib.util.spec_from_file_location('identity_span_oracle', control.ORACLE / 'audit.py')
oracle = importlib.util.module_from_spec(oracle_spec)
oracle_spec.loader.exec_module(oracle)


def load(path):
    return json.loads(path.read_text())


def manifest(root):
    return {str(path.relative_to(root)): control.auth.digest(path) for path in root.rglob('*') if path.is_file()}


def main():
    control.usage()
    assert control.auth.digest(control.FROZEN / 'output-manifest.json') == oracle.MANIFEST_SHA256
    authenticated = []
    for name, binding in load(control.FROZEN / 'output-manifest.json').items():
        path = control.FROZEN / name
        assert path.stat().st_size == binding['bytes']
        assert control.auth.digest(path) == binding['sha256']
        authenticated.append(dict(path=str(path), **binding))
    for name, checksum in oracle.REVIEW_PINS.items():
        assert control.auth.digest(control.REVIEW / name) == checksum
    assert control.auth.digest(control.ORACLE / 'audit.py') == '56dba3a0baa1c0ef869d96e4cb17a4dc4c2c3bb4942ec9efdc224e4b4d666ca6'
    control.write('frozen-manifest-authentication.json', authenticated)
    with tarfile.open(oracle.ARCHIVE, 'r:gz') as archive:
        original = {member.name: archive.extractfile(member).read() for member in archive.getmembers() if member.isfile()}
    final = {str(path.relative_to(ROOT / 'native')): path.read_bytes() for path in (ROOT / 'native').rglob('*') if path.is_file()}
    frozen = {str(path.relative_to(control.FROZEN / 'native')): path.read_bytes() for path in (control.FROZEN / 'native').rglob('*') if path.is_file()}
    assert set(final) == set(frozen) == set(original) | {'src/encoding_spec.rs'}
    changed = [name for name in frozen if final[name] != frozen[name]]
    assert set(changed) == {'src/iter.rs', 'src/encoding_spec.rs'}
    source_maps = {}
    insertion_blocks = {}
    for name in changed:
        before = frozen[name].splitlines(keepends=True)
        after = final[name].splitlines(keepends=True)
        matcher = difflib.SequenceMatcher(a=before, b=after, autojunk=False)
        blocks = []
        for tag, before_start, before_end, after_start, after_end in matcher.get_opcodes():
            assert tag in ('equal', 'insert')
            if tag == 'insert':
                blocks.append(dict(original_line=before_start + 1, candidate_line=after_start + 1, text=b''.join(after[after_start:after_end]).decode()))
        assert blocks
        insertion_blocks[name] = blocks
    for name in original:
        if original[name] != final[name]:
            source_maps[name] = oracle.LineMap(original[name], final[name])
    assert set(source_maps) == {'src/lib.rs', 'src/iter.rs'}
    historical = load(control.FROZEN / 'historical-v3-baseline.json')['inference']['verification_scope']
    historical_rows = oracle.checked_rows(historical, 32, 31, 0)
    matched_runs = []
    expected_extras = oracle.ADDED_IMPLEMENTATIONS | {'iter::native_single_byte_roundtrip', 'iter::native_nibble_swap_control'}
    for number in (1, 3):
        attempt = ROOT / ('attempt-%02d' % number)
        output = load(attempt / 'stdout')
        scope = output['verus-infer']['verification_scope']
        assert output['verification-results']['success'] and scope['complete_selected_scope_verified']
        current_rows = oracle.checked_rows(scope, 38, 37, 2)
        current, current_counts = oracle.identities(current_rows, str(ROOT / 'native'), final)
        historical_identities = []
        for index, row in historical_rows:
            filename, span = oracle.parse_source(row['source'], oracle.HISTORICAL_ROOT, original)
            normalized = source_maps[filename].map_span(span) if filename in source_maps else span
            historical_identities.append(((row['rust_function'], filename, normalized), index, row, span))
        old_counts = collections.Counter(item[0] for item in historical_identities)
        assert len(old_counts) == 32 and all(value == 1 for value in old_counts.values())
        assert not old_counts - current_counts
        extras = current_counts - old_counts
        assert sum(extras.values()) == 6 and {key[0] for key in extras} == expected_extras
        indexed = {item[0]: item for item in current}
        matches = []
        for key, old_index, old_row, old_span in historical_identities:
            current_key, current_index, current_row, current_span = indexed[key]
            assert old_row['function'] == current_row['function']
            matches.append(dict(rust_function=key[0], file=key[1], original_span=old_span, normalized_span=key[2], actual_span=current_span, historical_index=old_index, current_index=current_index, multiplicity=1))
        overloads = [item for item in matches if item['rust_function'] in oracle.OVERLOADS]
        assert len(overloads) == 2
        for item in overloads:
            assert tuple(item['original_span']) == oracle.OVERLOADS[item['rust_function']]
        matched_runs.append(dict(attempt=number, matched_original_implementations=32, matches=matches, both_from_overloads=overloads, added_implementations=sorted(key[0] for key in extras)))
    native_manifest = manifest(ROOT / 'native')
    assert native_manifest == load(ROOT / 'attempt-01/invocation.json')['source_hashes']
    assert native_manifest == load(ROOT / 'attempt-03/invocation.json')['source_hashes']
    negative_source = (ROOT / 'attempt-02/source/iter.rs').read_bytes()
    positive_source = final['src/iter.rs']
    assert negative_source == positive_source.replace(b'assert(decoded == Ok(0xbau8));', b'assert(decoded == Ok(0xabu8));')
    assert positive_source.count(b'assert(decoded == Ok(0xbau8));') == 1
    negative_output = load(ROOT / 'attempt-02/stdout')
    negative = negative_output['verification-results']
    assert negative['errors'] == 1 and negative['encountered-error'] and not negative['encountered-vir-error']
    stderr = (ROOT / 'attempt-02/stderr').read_text()
    assert stderr.count('error: assertion failed') == 1
    assert 'iter.rs:376:12' in stderr
    assert negative_output['verus-infer']['verification_scope']['checked_exec_bodies'] == 0
    additions = ''.join(block['text'] for blocks in insertion_blocks.values() for block in blocks)
    assert not re.search(r'\b(assume|admit|axiom|external_body|assume_specification|unsafe|MaybeUninit|ArrayString|BufEncoder)\b', additions)
    assert '//' not in additions and '/*' not in additions
    assert 'fn native_single_byte_roundtrip(byte: u8, case: Case)' in additions
    assert 'hex_chars_to_byte(encoded[0] as u8, encoded[1] as u8)' in additions
    for name in original:
        if name not in ('src/lib.rs', 'src/iter.rs'):
            assert original[name] == final[name]
    lib_original = original['src/lib.rs'].decode()
    lib_final = final['src/lib.rs'].decode()
    for constant in ('LOWER', 'UPPER'):
        expression = r'pub\(crate\) const ' + constant + r': Self = Table\(\[.*?\]\);'
        assert re.search(expression, lib_original, re.S).group() == re.search(expression, lib_final, re.S).group()
    assert re.findall(r'#\[derive\([^\n]+', lib_original) == re.findall(r'#\[derive\([^\n]+', lib_final)
    assert 'pub(crate) struct Table([Char; 16]);' in lib_final
    baseline_output = load(control.FROZEN / 'invocation-06/stdout')
    final_output = load(ROOT / 'attempt-03/stdout')
    models = lambda output: {(item['function'], item['fingerprint']) for item in output['verus-infer']['trusted_models']}
    baseline_models = models(baseline_output)
    final_models = models(final_output)
    control.write('implementation-identity-audit.json', dict(method='authenticated identity/span oracle with separate insertion mappings for lib.rs and iter.rs; implementation-key multisets, never function-name sets', runs=matched_runs, original_exec_count=32, positive_exec_count=38, positive_proof_count=2, insertion_blocks=insertion_blocks, all_existing_bodies_signatures_privacy_derives_and_initializers_retained=True, frozen_lib_and_decoding_spec_byte_identical=True, restored_native_tree_byte_identical=True, native_manifest=native_manifest))
    control.write('line-mappings.json', {name: mapping.receipt() for name, mapping in source_maps.items()})
    control.write('trust-and-inference-inventory.json', dict(qualification=final_output['verus-infer']['trust'], baseline_model_count=len(baseline_models), final_model_count=len(final_models), added_models=sorted(final_models - baseline_models), removed_models=sorted(baseline_models - final_models), functions=final_output['verus-infer']['functions'], assistance={name: value for name, value in final_output['verus-infer'].items() if 'assistance' in name or name in ('arithmetic', 'imported_inference_dependencies', 'trusted_models')}))
    for destination, before in (('final-source.patch', frozen), ('complete-versus-archive.patch', original)):
        patch = ''
        for name in sorted(final):
            if before.get(name) != final[name]:
                patch += ''.join(difflib.unified_diff(before.get(name, b'').decode().splitlines(True), final[name].decode().splitlines(True), fromfile=('a/' + name if name in before else '/dev/null'), tofile='b/' + name))
        (ROOT / destination).write_text(patch)
    (ROOT / 'semantic-negative.patch').write_text(''.join(difflib.unified_diff(positive_source.decode().splitlines(True), negative_source.decode().splitlines(True), fromfile='a/src/iter.rs', tofile='b/src/iter.rs')))
    receipts = []
    for attempt in sorted(ROOT.glob('attempt-*')):
        invocation = load(attempt / 'invocation.json')
        result = load(attempt / 'result.json')
        output = load(attempt / 'stdout')
        receipts.append(dict(invocation=invocation, result=result, verification=output['verification-results'], scope=output['verus-infer']['verification_scope'], inference=output['verus-infer']['functions'], positive_proof_credit=invocation['number'] in (1, 3)))
    control.write('validation-receipts.json', receipts)
    control.write('audit-results.json', dict(success=True, positive_attempts=[1, 3], semantic_negative_attempt=2, negative_error='only backend assertion at iter.rs:376:12', negative_positive_proof_credit=0, corrected_counterpart='swapped 0xab decodes to 0xba, both cases', byte_identical_restoration=True, identity_span_match_count=32, direct_applications=3, summed_verifier_seconds=sum(item['result']['elapsed_seconds'] for item in receipts), **control.usage()))
    print(json.dumps(load(ROOT / 'audit-results.json')))


if __name__ == '__main__':
    main()
