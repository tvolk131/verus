import datetime
import difflib
import hashlib
import importlib.util
import json
import os
import pathlib
import resource
import shutil
import signal
import subprocess
import sys
import time

sys.dont_write_bytecode = True
ROOT = pathlib.Path(__file__).resolve().parent
FROZEN = pathlib.Path('/private/tmp/verus-hex130-privacy-repair-20261107-zm5hKz')
REVIEW = pathlib.Path('/private/tmp/verus-hex130-independent-review-20261107-7xnzpY')
ORACLE = pathlib.Path('/private/tmp/verus-hex130-preservation-audit-20261107-4h70icof')
PARENT = pathlib.Path('/Users/tommyvolk/.t3/worktrees/verus/t3-60978068')
START = datetime.datetime.fromisoformat('2026-11-08T02:41:37+00:00').timestamp()
module_spec = importlib.util.spec_from_file_location('authentication', '/private/tmp/verus-native-hex130-encoding-20261107-1VZM03/prepare.py')
auth = importlib.util.module_from_spec(module_spec)
module_spec.loader.exec_module(auth)
auth.ROOT = ROOT


def write(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def usage():
    allocated = sum(max(path.stat().st_size, path.stat().st_blocks * 512) for path in ROOT.rglob('*') if path.is_file())
    free = shutil.disk_usage(ROOT).free
    assert allocated < 128 * 1024**2
    assert free > 16 * 1024**3
    return dict(allocated_bytes=allocated, free_bytes=free, elapsed_seconds=time.time() - START)


def authenticate(label):
    usage()
    assert auth.digest(auth.RUNTIME / 'runtime-manifest.json') == '1fa38f105d5b9fda9bda2ad3b0ee4518f083f917bc77dcbce6585ff152e476a3'
    auth.authenticate(label)
    paths = [FROZEN / name for name in ('REPORT.md', 'validation-receipts.json', 'final-source.patch', 'authentication-handoff-final.json', 'source-investigation-bindings.json')]
    paths += [REVIEW / 'REVIEW.md', ORACLE / 'audit.py', ORACLE / 'test_audit.py', ORACLE / 'matches.json', PARENT / 'evidence/parallel-advancement107/PLAN.md', pathlib.Path(module_spec.origin)]
    source_hashes = json.loads((FROZEN / 'invocation-06/invocation.json').read_text())['source_hashes']
    paths += [FROZEN / 'native' / name for name in source_hashes]
    for name, checksum in source_hashes.items():
        assert auth.digest(FROZEN / 'native' / name) == checksum
    bindings = json.loads((FROZEN / 'source-investigation-bindings.json').read_text())
    for name, binding in bindings.items():
        assert auth.digest(PARENT / name) == binding['sha256'] == binding['frozen_sha256']
        paths.append(PARENT / name)
    identity = {str(path): dict(sha256=auth.digest(path), bytes=path.stat().st_size) for path in paths}
    baseline = ROOT / 'authenticated-inputs-entry.json'
    if baseline.exists():
        assert identity == json.loads(baseline.read_text())
    write('authenticated-inputs-' + label + '.json', identity)
    return identity


def setup():
    authenticate('entry')
    shutil.copytree(FROZEN / 'native', ROOT / 'native')
    for name in ('home', 'tmp', 'xdg-cache', 'cache'):
        (ROOT / name).mkdir()
    write('budget.json', dict(start_epoch=START, stop_launch_epoch=START + 720, end_epoch=START + 900, application_limit=16, per_application_seconds=60, workers=1, scratch_limit_bytes=128 * 1024**2, free_disk_minimum_bytes=16 * 1024**3, no_builds=True, no_native_app_runs=True, no_git_writes=True, parent_read_only=True))
    print(json.dumps(usage()))


def limits():
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    resource.setrlimit(resource.RLIMIT_FSIZE, (8 * 1024**2, 8 * 1024**2))


def invoke(kind):
    checkpoint = usage()
    assert time.time() < START + 720
    previous = list(ROOT.glob('attempt-*/invocation.json'))
    number = len(previous) + 1
    assert number <= 16
    authenticate('pre-%02d' % number)
    destination = ROOT / ('attempt-%02d' % number)
    destination.mkdir()
    source = destination / 'source'
    shutil.copytree(ROOT / 'native/src', source)
    metadata = json.loads((FROZEN / 'invocation-06/invocation.json').read_text())
    environment = {name: value.replace(str(FROZEN), str(ROOT)) for name, value in metadata['environment'].items()}
    environment['VERUS_INFER_CACHE'] = str(ROOT / 'cache')
    argv = [value.replace(str(FROZEN / 'native'), str(ROOT / 'native')) for value in metadata['argv']]
    argv[argv.index('--export') + 1] = str(destination / 'hex_conservative.vir')
    argv[argv.index('--out-dir') + 1] = str(destination)
    manifest = {str(path.relative_to(ROOT / 'native')): auth.digest(path) for path in (ROOT / 'native').rglob('*') if path.is_file()}
    write(str(destination.relative_to(ROOT) / 'invocation.json'), dict(number=number, kind=kind, argv=argv, environment=environment, cwd=str(ROOT / 'native'), timeout_seconds=60, source_hashes=manifest, started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), **checkpoint))
    started = time.monotonic()
    timed_out = False
    try:
        with (destination / 'stdout').open('wb') as stdout, (destination / 'stderr').open('wb') as stderr:
            process = subprocess.Popen(argv, cwd=ROOT / 'native', env=environment, stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr, start_new_session=True, preexec_fn=limits)
            try:
                process.wait(timeout=59.5)
            except subprocess.TimeoutExpired:
                timed_out = True
                os.killpg(process.pid, signal.SIGKILL)
                process.wait()
        result = dict(number=number, kind=kind, returncode=process.returncode, timeout=timed_out, elapsed_seconds=time.monotonic() - started)
    except Exception as error:
        result = dict(number=number, kind=kind, launch_error=repr(error), elapsed_seconds=time.monotonic() - started)
    result['scope'] = None
    try:
        output = json.loads((destination / 'stdout').read_text())
        result['verification'] = output.get('verification-results')
        result['scope'] = output.get('verus-infer', {}).get('verification_scope')
        write(str(destination.relative_to(ROOT) / 'parsed-output.json'), output)
    except Exception:
        pass
    result['artifacts'] = {name: auth.digest(destination / name) for name in ('stdout', 'stderr') if (destination / name).exists()}
    write(str(destination.relative_to(ROOT) / 'result.json'), result)
    authenticate('post-%02d' % number)
    print(json.dumps({name: value for name, value in result.items() if name != 'scope'}))
    if result.get('returncode') != 0:
        print((destination / 'stderr').read_text()[-14000:])


if __name__ == '__main__':
    if sys.argv[1] == 'setup':
        setup()
    elif sys.argv[1] == 'authenticate':
        authenticate(sys.argv[2])
    else:
        invoke(sys.argv[1])
