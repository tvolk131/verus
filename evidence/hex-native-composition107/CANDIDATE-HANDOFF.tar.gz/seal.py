import datetime
import json
import pathlib
import sys
import time

sys.dont_write_bytecode = True
import control


def main():
    root = control.ROOT
    accounting = json.loads((root / 'audit-results.json').read_text())
    assert accounting['success']
    assert len(list(root.glob('attempt-*/invocation.json'))) == 3
    assert time.time() - control.START < 900
    final_sources = {str(path.relative_to(root / 'native')): control.auth.digest(path) for path in (root / 'native').rglob('*') if path.is_file()}
    for number in (1, 3):
        assert final_sources == json.loads((root / ('attempt-%02d/invocation.json' % number)).read_text())['source_hashes']
    assert not any((root / 'cache').rglob('*'))
    control.authenticate('handoff-final')
    resources = control.usage()
    manifest = {}
    for path in sorted(root.rglob('*')):
        if path.is_file() and path.name not in ('output-manifest.json', 'handoff.json', 'handoff.sha256'):
            manifest[str(path.relative_to(root))] = dict(bytes=path.stat().st_size, sha256=control.auth.digest(path))
    control.write('output-manifest.json', manifest)
    report = root / 'REPORT.md'
    handoff = dict(outcome='NEW_NATIVE_SINGLE_BYTE_COMPOSITION_VERIFIED_FROZEN_OPERATIONAL91_ONLY', source=str(root / 'native'), patch=str(root / 'final-source.patch'), complete_patch=str(root / 'complete-versus-archive.patch'), report=dict(path=str(report), bytes=report.stat().st_size, sha256=control.auth.digest(report)), manifest=dict(path=str(root / 'output-manifest.json'), sha256=control.auth.digest(root / 'output-manifest.json')), final_sources=final_sources, direct_verifier_applications=3, application_limit=16, remaining_applications=13, per_application_limit_seconds=60, maximum_workers=1, verifier_seconds=accounting['summed_verifier_seconds'], positive_attempts=[1, 3], preserved_semantic_negative=2, all_original_32_implementation_identities_retained=True, byte_identical_restoration=True, strict_persisted_owned_warm_cache_gate='UNMET', independent_review='REQUIRED_NOT_PERFORMED', final_native_acceptance=False, runtime_adoption=False, parent_integration=False, git_writes=False, redb_open_cells=18, start_utc=datetime.datetime.fromtimestamp(control.START, datetime.timezone.utc).isoformat(), sealed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), **resources)
    control.write('handoff.json', handoff)
    (root / 'handoff.sha256').write_text(control.auth.digest(root / 'handoff.json') + '  handoff.json\n')
    for name, binding in manifest.items():
        assert control.auth.digest(root / name) == binding['sha256']
    print(json.dumps(dict(root=str(root), report_sha256=handoff['report']['sha256'], handoff_sha256=control.auth.digest(root / 'handoff.json'), manifest_sha256=handoff['manifest']['sha256'], **control.usage()), indent=2))


if __name__ == '__main__':
    main()
