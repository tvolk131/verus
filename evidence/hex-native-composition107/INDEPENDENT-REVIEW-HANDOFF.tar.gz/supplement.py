import collections
import difflib
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys
import tarfile

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('recheck', ROOT / 'recheck.py')
review = importlib.util.module_from_spec(spec)
spec.loader.exec_module(review)
CANDIDATE = review.CANDIDATE
FROZEN = review.FROZEN

def load(path):
    return json.loads(path.read_text())

def normalize(value):
    if isinstance(value, str):
        for root in [str(CANDIDATE), str(FROZEN), str(ROOT)]:
            value = value.replace(root, '<ROOT>')
        return value
    if isinstance(value, list):
        return [normalize(item) for item in value]
    if isinstance(value, dict):
        return {key: normalize(item) for key, item in value.items()}
    return value

with tarfile.open(review.PARENT / 'evidence/verus-infer-hex-v3/native-source.tar.gz') as archive:
    original = {member.name: archive.extractfile(member).read() for member in archive.getmembers() if member.isfile()}
final = {str(path.relative_to(CANDIDATE / 'native')): path.read_bytes() for path in (CANDIDATE / 'native').rglob('*') if path.is_file()}
frozen = {str(path.relative_to(FROZEN / 'native')): path.read_bytes() for path in (FROZEN / 'native').rglob('*') if path.is_file()}
for patch, before in [('final-source.patch', frozen), ('complete-versus-archive.patch', original)]:
    regenerated = ''.join(''.join(difflib.unified_diff(before.get(name, b'').decode().splitlines(True), final[name].decode().splitlines(True), fromfile='a/' + name if name in before else '/dev/null', tofile='b/' + name)) for name in sorted(final) if before.get(name) != final[name])
    assert regenerated.encode() == (CANDIDATE / patch).read_bytes(), patch
for name in original:
    if name not in ['src/lib.rs', 'src/iter.rs']:
        assert original[name] == final[name]
for constant in ['LOWER', 'UPPER']:
    pattern = rb'pub\(crate\) const ' + constant.encode() + rb': Self = Table\(\[.*?\]\);'
    assert re.search(pattern, original['src/lib.rs'], re.S).group() == re.search(pattern, final['src/lib.rs'], re.S).group()
assert re.findall(rb'#\[derive\([^\n]+', original['src/lib.rs']) == re.findall(rb'#\[derive\([^\n]+', final['src/lib.rs'])
additions = ''
for name in ['src/iter.rs', 'src/encoding_spec.rs']:
    before, after = frozen[name].decode().splitlines(True), final[name].decode().splitlines(True)
    for tag, before_start, before_end, after_start, after_end in difflib.SequenceMatcher(a=before, b=after, autojunk=False).get_opcodes():
        if tag == 'insert':
            additions += ''.join(after[after_start:after_end])
assert not re.search(r'\b(assume|admit|axiom|external_body|assume_specification|unsafe|trusted|MaybeUninit|ArrayString|BufEncoder)\b', additions)
assert '//' not in additions and '/*' not in additions
theorem = final['src/iter.rs'].decode().split('fn native_single_byte_roundtrip', 1)[1].split('fn native_nibble_swap_control', 1)[0]
assert 'requires' not in theorem and 'ensures result == Ok(byte)' in theorem
assert 'case.table().byte_to_hex_chars(byte)' in theorem
assert 'hex_chars_to_byte(encoded[0] as u8, encoded[1] as u8)' in theorem
assert 'pub fn hex_chars_to_byte' not in final['src/iter.rs'].decode()
baseline = load(FROZEN / 'invocation-06/stdout')['verus-infer']
outputs = []
for base in [CANDIDATE, ROOT]:
    for number in [1, 3]:
        output = load(base / ('attempt-%02d/stdout' % number))
        inference = output['verus-infer']
        assert inference['trusted_models'] == baseline['trusted_models']
        assert len(inference['trusted_models']) == 382
        for name in ['trust', 'arithmetic', 'imported_inference_dependencies']:
            assert inference[name] == baseline[name]
        for name in inference:
            if 'assistance' in name and name != 'assistance_explanations':
                assert inference[name] == baseline[name], name
        helper = inference['functions'][0]
        assert len(inference['functions']) == 1
        for name in ['contract', 'dependencies', 'mode', 'summary_kind', 'exported', 'available_to_same_crate_callers', 'required_checks_passed']:
            assert helper[name] == baseline['functions'][0][name]
        details = output['func-details']
        outputs.append({'base': str(base), 'attempt': number, 'models': len(inference['trusted_models']), 'model_fingerprint_multiset': collections.Counter(item['fingerprint'] for item in inference['trusted_models']), 'helper_contract_unchanged': True, 'helper_exported': helper['exported'], 'helper_cache': helper['metrics'], 'assistance_explanations': normalize(inference['assistance_explanations']), 'backend_func_details': details})
assert outputs[0]['assistance_explanations'] == outputs[1]['assistance_explanations'] == outputs[2]['assistance_explanations'] == outputs[3]['assistance_explanations']
receipts = load(CANDIDATE / 'validation-receipts.json')
assert len(receipts) == 3
for number, receipt in enumerate(receipts, 1):
    attempt = CANDIDATE / ('attempt-%02d' % number)
    output = load(attempt / 'stdout')
    assert receipt['invocation'] == load(attempt / 'invocation.json')
    assert receipt['result'] == load(attempt / 'result.json')
    assert receipt['verification'] == output['verification-results']
    assert receipt['scope'] == output['verus-infer']['verification_scope']
    assert receipt['inference'] == output['verus-infer']['functions']
    assert receipt['positive_proof_credit'] == (number in [1, 3])
assert load(CANDIDATE / 'attempt-01/result.json')['scope'] is None
notes = load(CANDIDATE / 'operational-notes.json')
assert 'assert len(blocks) == 1' in (CANDIDATE / 'audit-attempt-01.stderr').read_text()
assert notes['shell_wrapper_failure']['stderr'] == 'zsh:18: read-only variable: status\n'
for base in [CANDIDATE, ROOT]:
    for number in [1, 2, 3]:
        attempt = base / ('attempt-%02d' % number)
        for path in (attempt / 'source').iterdir():
            expected = final['src/' + path.name]
            if number == 2 and path.name == 'iter.rs':
                expected = expected.replace(b'assert(decoded == Ok(0xbau8));', b'assert(decoded == Ok(0xabu8));')
            assert path.read_bytes() == expected
        errors = [line for line in (attempt / 'stderr').read_text().splitlines() if line.startswith('error:')]
        if number == 2:
            assert errors == ['error: assertion failed', 'error: aborting due to 1 previous error; 6 warnings emitted']
        else:
            assert not errors
expected_extras = {'<Case as core::clone::Clone>::clone', 'Case::table', 'encoding_spec::canonical_byte_encoding_goal', 'iter::native_nibble_swap_control', 'iter::native_single_byte_roundtrip', 'table::Table::byte_to_hex_chars'}
for run in load(ROOT / 'independent-audit.json')['identity_matches']:
    assert set(run['extra_exec']) == expected_extras
review.write('independent-source-trust-audit.json', {'exact_patch_reconstruction': True, 'constants_and_derives_preserved': True, 'new_trusted_constructs': [], 'models_per_positive': 382, 'trusted_models_unchanged': True, 'new_helper_preconditions': 'nibble < 16 on a u8, discharged at both arbitrary-byte call sites', 'theorem_preconditions': [], 'theorem_native_path': ['Case::table', 'Table::byte_to_hex_chars', 'Char as u8 casts', 'private iter::hex_chars_to_byte', 'Char::decode_nibble twice'], 'positives': outputs, 'baseline_assistance_explanations': normalize(baseline['assistance_explanations']), 'historical_metadata_events': notes, 'metadata_corrections_are_not_replays': True, 'aggregate_receipts_match_raw': True, 'all_source_snapshots_match_expected': True})
print(json.dumps({'supplement': 'passed', 'trusted_models': 382, 'patches_exact': True, 'attempts_audited': 6, **review.usage()}))
