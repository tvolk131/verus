import collections
import datetime
import importlib.util
import json
from pathlib import Path
import shutil
import sys
import time

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('recheck', ROOT / 'recheck.py')
review = importlib.util.module_from_spec(spec)
spec.loader.exec_module(review)
assert time.time() < review.START + 720
if (ROOT / 'handoff.json').exists():
    review.write('seal-revision.json', {'previous_handoff_sha256': review.digest(ROOT / 'handoff.json'), 'previous_manifest_sha256': review.digest(ROOT / 'output-manifest.json'), 'reason': 'Include the lower free-disk sample printed by the successful supplemental metadata audit; no new verifier launch or proof credit', 'supplemental_observed_free_bytes': 50869682176, 'supplemental_elapsed_seconds': 387.76413583755493})
source_audit = review.load(ROOT / 'independent-source-trust-audit.json')
key = lambda item: tuple((name, str(value)) for name, value in sorted(item.items()) if name != 'source')
before = collections.Counter(key(item) for item in source_audit['baseline_assistance_explanations']['decisions'])
after = collections.Counter(key(item) for item in source_audit['positives'][0]['assistance_explanations']['decisions'])
added = [dict(item) for item in (after - before).elements()]
assert len(added) == 6 and not before - after and all(item['status'] == 'skipped' for item in added)
review.write('assistance-decision-delta.json', {'new_decisions_ignoring_source_locations': added, 'removed_decisions': [], 'new_applied_assistance': []})
attempts = []
for number in [1, 2, 3]:
    destination = ROOT / ('attempt-%02d' % number)
    invocation = review.load(destination / 'invocation.json')
    result = review.load(destination / 'result.json')
    attempts.append({'number': number, 'kind': result['kind'], 'elapsed_seconds': result['elapsed_seconds'], 'returncode': result['returncode'], 'timeout': result['timeout'], 'verification': result['verification'], 'positive_proof_credit': number != 2, 'checked_exec': result['scope']['checked_exec_bodies'], 'checked_proof': result['scope']['checked_proof_bodies'], 'interface_written': result['interface_written'], 'invocation': str(destination / 'invocation.json'), 'result': str(destination / 'result.json'), 'scope_raw': str(destination / 'stdout'), 'launch_observations': {name: invocation[name] for name in ['allocated_file_bytes', 'free_bytes', 'elapsed_seconds']}})
assert len(list(ROOT.glob('attempt-*/invocation.json'))) == 3
assert not review.inventory(ROOT / 'cache')
review.authenticate('exit')
exit_auth = review.load(ROOT / 'authentication-exit.json')
entry_auth = review.load(ROOT / 'authentication-entry.json')
usage = review.usage()
directory_bytes = sum(path.stat().st_blocks * 512 for path in ROOT.rglob('*') if path.is_dir()) + ROOT.stat().st_blocks * 512
ledger = {'start_utc': '2026-11-08T02:51:50Z', 'launch_cutoff_utc': '2026-11-08T03:00:50Z', 'deadline_utc': '2026-11-08T03:03:50Z', 'sealed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'elapsed_seconds': time.time() - review.START, 'attempt_cap': 4, 'charged_attempts': 3, 'remaining_attempts_not_used': 1, 'budget_reset': False, 'attempts': attempts, 'verifier_seconds': sum(item['elapsed_seconds'] for item in attempts), 'maximum_review_workers': 1, 'concurrent_review_workers': False, 'per_attempt_timeout_seconds': 60, 'wait_before_kill_seconds': 59.5, 'timed_out_attempts': 0, 'historical_verifier_attempts_audited_not_relaunched': 3, 'historical_metadata_corrections_are_replays': False, 'scratch_limit_bytes': 128 * 1024**2, 'directory_allocated_bytes_observed': directory_bytes, 'final_file_allocation_observed': usage['allocated_file_bytes'], 'minimum_observed_free_bytes': min(entry_auth['free_bytes'], exit_auth['free_bytes'], usage['free_bytes'], *[item['launch_observations']['free_bytes'] for item in attempts]), 'free_disk_required_bytes': 16 * 1024**3, 'cache_files': [], 'resources_are_sampled_not_continuous_os_isolation': True, 'builds': 0, 'native_app_runs': 0, 'network_operations': 0, 'git_writes': 0, 'delegates': 0, 'writes_outside_scratch': 0, 'metadata_lookup_failure': 'read-only incorrect runtime/runtime-manifest.json lookup; corrected to root manifest; no verifier launch'}
ledger['minimum_observed_free_bytes'] = min(ledger['minimum_observed_free_bytes'], 50869682176)
ledger['additional_free_disk_observation'] = {'source': 'successful supplement.py metadata audit stdout', 'free_bytes': 50869682176, 'elapsed_seconds': 387.76413583755493}
review.write('resource-attempt-ledger.json', ledger)
review.write('findings.json', {'bounded_verdict': 'NO_NEW_THEOREM_SPECIFIC_BLOCKING_FINDING; THREE_BOUNDED_RECHECKS_CONFIRMED; FROZEN_OPERATIONAL91_ONLY', 'new_theorem_blocking_findings': [], 'existing_acceptance_barriers': ['strict persisted owned warm-cache gate UNMET', 'compiler/current-parent-source correspondence UNESTABLISHED', 'all18redb OPEN'], 'scope_caveats': ['54 obligations != 38 exec + 2 proof body inventory', 'selected local Verus items, not all Rust code', 'no decode_to_array::<1>, byte_to_str, unsafe buffer or native application claim'], 'final_native_acceptance': False, 'trust_adoption': False, 'runtime_adoption': False, 'parent_semantic_integration': False})
manifest = {name: value for name, value in review.inventory(ROOT).items() if name not in {'output-manifest.json', 'handoff.json', 'handoff.sha256'}}
review.write('output-manifest.json', manifest)
handoff = {'outcome': 'BOUNDED_INDEPENDENT_REVIEW_AND_RECHECKS_COMPLETE_NOT_FINAL_ACCEPTANCE', 'review': {'path': str(ROOT / 'REVIEW.md'), 'sha256': review.digest(ROOT / 'REVIEW.md')}, 'manifest': {'path': str(ROOT / 'output-manifest.json'), 'sha256': review.digest(ROOT / 'output-manifest.json'), 'payloads': len(manifest)}, 'candidate': str(review.CANDIDATE), 'candidate_pins': review.PINS, 'entry_exit_candidate_and_inputs_identical': True, 'authenticated_candidate_payloads': 132, 'byte_identical_parent_archive_members': 134, 'authenticated_immutable_input_files': 202, 'review_charged_attempts': 3, 'review_attempt_cap': 4, 'verifier_seconds': ledger['verifier_seconds'], 'maximum_review_workers': 1, 'independent_preserved_original_exec_identities': 32, 'distinct_from_overloads': 2, 'positive_exec_scope': 38, 'positive_proof_scope': 2, 'positive_obligations': 54, 'negative_backend_assertions': 1, 'negative_export': False, 'restored_sources_byte_identical': True, 'strict_persisted_owned_warm_cache_gate': 'UNMET', 'compiler_current_parent_source_correspondence': 'UNESTABLISHED', 'all18redb': 'OPEN', 'final_native_acceptance': False, 'trust_adoption': False, 'runtime_adoption': False, 'parent_semantic_integration': False, 'new_research_chain': False, 'sealed_utc': ledger['sealed_utc'], 'elapsed_seconds': time.time() - review.START, 'observed_file_allocation_before_seal_bytes': review.usage()['allocated_file_bytes'], 'observed_directory_allocation_bytes': directory_bytes, 'minimum_observed_free_bytes': ledger['minimum_observed_free_bytes']}
review.write('handoff.json', handoff)
checksum = review.digest(ROOT / 'handoff.json')
(ROOT / 'handoff.sha256').write_text(checksum + '  handoff.json\n')
assert time.time() < review.START + 720
assert review.usage()['allocated_file_bytes'] + directory_bytes < 128 * 1024**2
assert all(review.digest(ROOT / name) == value['sha256'] and (ROOT / name).stat().st_size == value['bytes'] for name, value in manifest.items())
print(json.dumps({'sealed_handoff': str(ROOT / 'handoff.json'), 'handoff_sha256': checksum, 'report_sha256': handoff['review']['sha256'], 'output_manifest_sha256': handoff['manifest']['sha256'], 'payloads': len(manifest), 'elapsed_seconds': time.time() - review.START, **review.usage()}, indent=2))
