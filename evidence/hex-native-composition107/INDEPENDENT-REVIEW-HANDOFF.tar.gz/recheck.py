import collections
import datetime
import difflib
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import resource
import shutil
import signal
import subprocess
import sys
import tarfile
import time

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
CANDIDATE = Path('/private/tmp/verus-hex-native-composition-20261107-Z4I683')
FROZEN = Path('/private/tmp/verus-hex130-privacy-repair-20261107-zm5hKz')
ORACLE = Path('/private/tmp/verus-hex130-preservation-audit-20261107-4h70icof')
PARENT = Path('/Users/tommyvolk/.t3/worktrees/verus/t3-60978068')
RUNTIME_ROOT = Path('/private/tmp/verus-operational91-runtime.q91')
START = datetime.datetime.fromisoformat('2026-11-08T02:51:50+00:00').timestamp()
PINS = {'output-manifest.json': '25954869da98e95ea4264d59b1a2bff723a58083463301e7176eabde5e31781d', 'REPORT.md': '7695000f747778c3daa5f623f70887776598be358cf58a9ed5691d5fae8eaa01', 'handoff.json': '7591ff8b25084a63038b96d3dad5a9d4e09858c0584bae19337c51212799e0f0'}

def load(path):
    return json.loads(path.read_text())

def write(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

def digest(path):
    checksum = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            checksum.update(block)
    return checksum.hexdigest()

def inventory(root):
    return {str(path.relative_to(root)): {'bytes': path.stat().st_size, 'sha256': digest(path)} for path in root.rglob('*') if path.is_file()}

def usage():
    paths = list(ROOT.rglob('*'))
    allocated = sum(max(path.stat().st_size, path.stat().st_blocks * 512) for path in paths if path.is_file())
    free = shutil.disk_usage(ROOT).free
    assert allocated < 128 * 1024**2 and free > 16 * 1024**3
    return {'allocated_file_bytes': allocated, 'free_bytes': free, 'elapsed_seconds': time.time() - START}

def authenticate(label):
    for name, expected in PINS.items():
        assert digest(CANDIDATE / name) == expected, name
    manifest = load(CANDIDATE / 'output-manifest.json')
    assert len(manifest) == 132
    found = inventory(CANDIDATE)
    assert set(found) == set(manifest) | {'output-manifest.json', 'handoff.json', 'handoff.sha256'}
    assert all(found[name] == expected for name, expected in manifest.items())
    for path in CANDIDATE.rglob('*'):
        assert not path.is_symlink()
    expected_inputs = load(CANDIDATE / 'authenticated-inputs-entry.json')
    frozen_manifest = FROZEN / 'output-manifest.json'
    assert digest(frozen_manifest) == '3ef7d0e40cf0150e40ee071bfd1629e8f440f5246b42633708ca80206f5c8d62'
    for name, expected in load(frozen_manifest).items():
        expected_inputs[str(FROZEN / name)] = expected
    expected_inputs[str(frozen_manifest)] = {'bytes': frozen_manifest.stat().st_size, 'sha256': digest(frozen_manifest)}
    auth = load(CANDIDATE / 'authentication-entry.json')
    records = list(auth['runtime'].values()) + auth['loader'] + [auth['rustc']]
    for record in records:
        expected_inputs[record['path']] = {'bytes': record['bytes'], 'sha256': record['sha256']}
    runtime_manifest = RUNTIME_ROOT / 'runtime-manifest.json'
    assert digest(runtime_manifest) == '1fa38f105d5b9fda9bda2ad3b0ee4518f083f917bc77dcbce6585ff152e476a3'
    expected_inputs[str(runtime_manifest)] = {'bytes': runtime_manifest.stat().st_size, 'sha256': digest(runtime_manifest)}
    archive = PARENT / 'evidence/hex-native-composition107/CANDIDATE-HANDOFF.tar.gz'
    assert digest(archive) == '4fc0fa56c8f1795a419f74759644f29e183e992a9d197d3ce622943646d2f210'
    expected_inputs[str(archive)] = {'bytes': archive.stat().st_size, 'sha256': digest(archive)}
    original = PARENT / 'evidence/verus-infer-hex-v3/native-source.tar.gz'
    assert digest(original) == 'e7f4b63eced039d437b54858fc600071b41614aa66b2a9fdc27caa94c9e0de5b'
    expected_inputs[str(original)] = {'bytes': original.stat().st_size, 'sha256': digest(original)}
    for name, expected in expected_inputs.items():
        path = Path(name)
        assert not path.is_symlink() and path.stat().st_size == expected['bytes'] and digest(path) == expected['sha256'], name
    with tarfile.open(archive) as packed:
        members = packed.getmembers()
        assert len(members) == 134
        assert {member.name for member in members} == set(manifest) | {'output-manifest.json', 'handoff.json'}
        for member in members:
            assert member.isfile() and packed.extractfile(member).read() == (CANDIDATE / member.name).read_bytes()
    result = {'candidate': found, 'immutable_inputs': expected_inputs, 'candidate_payloads': 132, 'archive_byte_identical_members': 134, 'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), **usage()}
    if (ROOT / 'authentication-entry.json').exists():
        entry = load(ROOT / 'authentication-entry.json')
        assert result['candidate'] == entry['candidate'] and result['immutable_inputs'] == entry['immutable_inputs']
    write('authentication-' + label + '.json', result)
    print(json.dumps({'authentication': label, 'candidate_payloads': 132, 'immutable_inputs': len(expected_inputs), **usage()}), flush=True)

def setup():
    authenticate('entry')
    for name in ['home', 'tmp', 'xdg-cache', 'cache', 'native/src']:
        (ROOT / name).mkdir(parents=True)
    for source in (CANDIDATE / 'native/src').iterdir():
        assert source.is_file() and source.suffix == '.rs'
        shutil.copyfile(source, ROOT / 'native/src' / source.name)
    write('budget.json', {'start_epoch': START, 'launch_cutoff_epoch': START + 540, 'end_epoch': START + 720, 'attempt_limit': 4, 'workers': 1, 'timeout_seconds': 60, 'scratch_limit': 128 * 1024**2, 'free_disk_minimum': 16 * 1024**3})

def limits():
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    resource.setrlimit(resource.RLIMIT_FSIZE, (8 * 1024**2, 8 * 1024**2))

def attempt(kind):
    assert time.time() < START + 540
    number = len(list(ROOT.glob('attempt-*/invocation.json'))) + 1
    assert number <= 4
    destination = ROOT / ('attempt-%02d' % number)
    destination.mkdir()
    metadata = load(CANDIDATE / 'attempt-01/invocation.json')
    environment = {name: value.replace(str(CANDIDATE), str(ROOT)) for name, value in metadata['environment'].items()}
    argv = [value.replace(str(CANDIDATE), str(ROOT)) for value in metadata['argv']]
    argv[argv.index('--export') + 1] = str(destination / 'hex_conservative.vir')
    argv[argv.index('--out-dir') + 1] = str(destination)
    assert argv[0] == str(RUNTIME_ROOT / 'runtime/verus') and argv[argv.index('--num-threads') + 1] == '1'
    source_hashes = inventory(ROOT / 'native')
    shutil.copytree(ROOT / 'native/src', destination / 'source')
    write(str(destination.relative_to(ROOT) / 'invocation.json'), {'number': number, 'kind': kind, 'argv': argv, 'environment': environment, 'cwd': str(ROOT / 'native'), 'timeout_seconds': 60, 'source_hashes': source_hashes, 'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), **usage()})
    started = time.monotonic()
    timed_out = False
    result = {'number': number, 'kind': kind, 'conservatively_charged': True}
    try:
        with (destination / 'stdout').open('wb') as stdout, (destination / 'stderr').open('wb') as stderr:
            process = subprocess.Popen(argv, cwd=ROOT / 'native', env=environment, stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr, start_new_session=True, preexec_fn=limits)
            try:
                process.wait(timeout=59.5)
            except subprocess.TimeoutExpired:
                timed_out = True
                os.killpg(process.pid, signal.SIGKILL)
                process.wait()
        result.update(returncode=process.returncode, timeout=timed_out)
    except Exception as error:
        result['launch_error'] = repr(error)
    result['elapsed_seconds'] = time.monotonic() - started
    try:
        output = load(destination / 'stdout')
        result['verification'] = output['verification-results']
        result['scope'] = output['verus-infer']['verification_scope']
        result['inferred_functions'] = output['verus-infer']['functions']
        result['interface_written'] = output['verus-infer']['interface_written']
    except Exception as error:
        result['parse_error'] = repr(error)
    result['artifacts'] = inventory(destination)
    write(str(destination.relative_to(ROOT) / 'result.json'), result)
    print(json.dumps({name: value for name, value in result.items() if name not in ['scope', 'artifacts', 'inferred_functions']}), flush=True)

def audit():
    spec = importlib.util.spec_from_file_location('identity_oracle', ORACLE / 'audit.py')
    oracle = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(oracle)
    archive = PARENT / 'evidence/verus-infer-hex-v3/native-source.tar.gz'
    with tarfile.open(archive) as packed:
        original = {member.name: packed.extractfile(member).read() for member in packed.getmembers() if member.isfile()}
    final = {str(path.relative_to(CANDIDATE / 'native')): path.read_bytes() for path in (CANDIDATE / 'native').rglob('*') if path.is_file()}
    frozen = {str(path.relative_to(FROZEN / 'native')): path.read_bytes() for path in (FROZEN / 'native').rglob('*') if path.is_file()}
    assert set(final) == set(frozen) == set(original) | {'src/encoding_spec.rs'}
    changed = [name for name in frozen if frozen[name] != final[name]]
    assert set(changed) == {'src/iter.rs', 'src/encoding_spec.rs'}
    insertions = {}
    for name in changed:
        matcher = difflib.SequenceMatcher(a=frozen[name].splitlines(True), b=final[name].splitlines(True), autojunk=False)
        operations = matcher.get_opcodes()
        assert all(operation[0] in ['equal', 'insert'] for operation in operations)
        insertions[name] = operations
    maps = {name: oracle.LineMap(original[name], final[name]) for name in original if original[name] != final[name]}
    assert set(maps) == {'src/lib.rs', 'src/iter.rs'}
    historical = load(FROZEN / 'historical-v3-baseline.json')['inference']['verification_scope']
    rows = oracle.checked_rows(historical, 32, 31, 0)
    old = collections.Counter()
    for index, row in rows:
        filename, span = oracle.parse_source(row['source'], oracle.HISTORICAL_ROOT, original)
        mapped = maps[filename].map_span(span) if filename in maps else span
        old[(row['rust_function'], filename, mapped)] += 1
    assert len(old) == 32 and all(value == 1 for value in old.values())
    matches = []
    for base, numbers in [(CANDIDATE, [1, 3]), (ROOT, [1, 3])]:
        for number in numbers:
            output = load(base / ('attempt-%02d/stdout' % number))
            scope = output['verus-infer']['verification_scope']
            current_rows = oracle.checked_rows(scope, 38, 37, 2)
            current, counts = oracle.identities(current_rows, str(base / 'native'), final)
            assert not old - counts and sum((counts - old).values()) == 6
            helper = output['verus-infer']['functions'][0]
            assert helper['required_checks_passed'] and not helper['exported']
            assert all(helper['proofs'][name]['status'] == 'proved' and helper['proofs'][name]['required'] for name in ['soundness', 'maximality', 'exactness'])
            selected = [{'rust_function': key[0], 'file': key[1], 'span': key[2], 'multiplicity': value} for key, value in old.items()]
            overloads = [row for row in selected if row['rust_function'] in oracle.OVERLOADS]
            assert len(overloads) == 2
            for row in overloads:
                assert tuple(row['span']) == oracle.OVERLOADS[row['rust_function']]
            matches.append({'base': str(base), 'attempt': number, 'original_matches': selected, 'from_overloads': overloads, 'extra_exec': sorted(key[0] for key in counts - old), 'exec': 38, 'proof': 2, 'verification_results': output['verification-results'], 'helper': helper})
    historical_attempts = []
    for base in [CANDIDATE, ROOT]:
        for number in [1, 2, 3]:
            destination = base / ('attempt-%02d' % number)
            output = load(destination / 'stdout')
            historical_attempts.append({'base': str(base), 'attempt': number, 'result': load(destination / 'result.json'), 'raw_verification': output['verification-results']})
        negative = load(base / 'attempt-02/stdout')
        stderr = (base / 'attempt-02/stderr').read_text()
        assert negative['verification-results']['errors'] == 1 and not negative['verification-results']['encountered-vir-error']
        assert stderr.count('error: assertion failed') == 1 and 'iter.rs:376:12' in stderr
        assert not (base / 'attempt-02/hex_conservative.vir').exists()
        assert not negative['verus-infer']['interface_written']
        assert negative['verus-infer']['verification_scope']['checked_exec_bodies'] == 0
        assert (base / 'attempt-02/source/iter.rs').read_bytes() == final['src/iter.rs'].replace(b'assert(decoded == Ok(0xbau8));', b'assert(decoded == Ok(0xabu8));')
        assert load(base / 'attempt-01/invocation.json')['source_hashes'] == load(base / 'attempt-03/invocation.json')['source_hashes']
    write('independent-audit.json', {'insertions': insertions, 'identity_matches': matches, 'attempts': historical_attempts, 'original_exec_count': 32, 'current_exec_count': 38, 'current_proof_count': 2, 'obligations_not_bodies': 54, 'source_maps': {name: mapping.receipt() for name, mapping in maps.items()}})
    print(json.dumps({'audit': 'passed', 'identity_runs': len(matches), 'original_bodies_per_run': 32, 'from_overloads': 2, **usage()}))

if __name__ == '__main__':
    if sys.argv[1] == 'setup':
        setup()
    elif sys.argv[1] == 'attempt':
        attempt(sys.argv[2])
    elif sys.argv[1] == 'auth':
        authenticate(sys.argv[2])
    elif sys.argv[1] == 'audit':
        audit()
