import json
import os
import pathlib
import time

from audit import DEADLINE, SCRATCH, START, authenticate, digest

assert time.time() < DEADLINE
authenticate('exit')
supplements = json.loads((SCRATCH / 'SUPPLEMENT-ENTRY.json').read_text())
exit_records = []
for record in supplements:
    observed = digest(record['path'])
    exit_records.append(dict(record, exit_sha256=observed, match=observed == record['sha256']))
assert all(record['match'] for record in exit_records)
(SCRATCH / 'SUPPLEMENT-EXIT.json').write_text(json.dumps(dict(recorded_epoch=time.time(), bindings=exit_records), indent=2) + '\n')
report = SCRATCH / 'REPORT.md'
assert report.stat().st_size <= 16384
filesystem = os.statvfs(SCRATCH)
free_bytes = filesystem.f_bavail * filesystem.f_frsize
assert free_bytes > 16 * 1024 ** 3
accounting = dict(start_epoch=START, absolute_deadline_epoch=DEADLINE, optional_analysis_cutoff_epoch=START + 360, source_inspection_finished_no_later_than_epoch=1794104333, finalization_recorded_epoch=time.time(), elapsed_seconds=time.time() - START, reserved_finalization_seconds=DEADLINE - 1794104333, report_bytes=report.stat().st_size, report_limit_bytes=16384, scratch_limit_bytes=8 * 1024 ** 2, free_bytes_at_finalization=free_bytes, required_free_bytes=16 * 1024 ** 3, supplied_entry_matches=212, supplied_exit_matches=212, supplemental_entry_count=len(supplements), supplemental_exit_matches=len(exit_records), target_verifier_solver_compiler_build_test_native_runs=0, network_operations=0, git_writes=0, parent_provider_runtime_edits=0, subdelegations=0, proof_credit=0, new_trust=0, adoption=0, acceptance=0, all_eighteen_cells='OPEN', limitations=['Endpoint hashes are sequential, not an atomic snapshot or continuous monitoring.', 'Full bookkeeping shell environments were not separately recorded.', 'Recovered Rust source content pins do not certify selected sysroot binary correspondence.'])
(SCRATCH / 'ACCOUNTING.json').write_text(json.dumps(accounting, indent=2) + '\n')
handoff = dict(verdict='SOURCE_ONLY_PREREQUISITE_GATE_NOT_SATISFIED', priority_next_action='Bounded source-only frozen-engine Arc<[u8]>::as_ref instance/binding trace and obligation design review; no new law or producer implementation.', user_decision='Explicit consequential scope/trust authorization required before a new producer, library assumption, experimental IR adoption or admission/export change.', report=dict(path=str(report), sha256=digest(report)), inputs=[dict(path=str(SCRATCH / name), sha256=digest(SCRATCH / name)) for name in ['INPUT-ENTRY.json', 'INPUT-EXIT.json', 'SUPPLEMENT-ENTRY.json', 'SUPPLEMENT-EXIT.json']], accounting=dict(path=str(SCRATCH / 'ACCOUNTING.json'), sha256=digest(SCRATCH / 'ACCOUNTING.json')), all_eighteen_cells='OPEN', nativefetchprobe104='UNEXECUTED')
(SCRATCH / 'HANDOFF.json').write_text(json.dumps(handoff, indent=2) + '\n')
files = sorted(path for path in SCRATCH.iterdir() if path.is_file() and path.name not in {'MANIFEST.sha256', 'SEAL.json'})
manifest = SCRATCH / 'MANIFEST.sha256'
manifest.write_text(''.join(digest(path) + '  ' + path.name + '\n' for path in files))
scratch_bytes = sum(path.stat().st_size for path in SCRATCH.rglob('*') if path.is_file())
seal = dict(kind='CONTENT_SEAL_NOT_PROOF_CERTIFICATE', manifest_path=str(manifest), manifest_sha256=digest(manifest), sealed_epoch=time.time(), elapsed_seconds=time.time() - START, absolute_deadline_epoch=DEADLINE, deadline_met=time.time() < DEADLINE, scratch_bytes_before_seal=scratch_bytes, scratch_limit_bytes=8 * 1024 ** 2, source_entry_exit_matches=True, supplied_bindings=212, supplemental_bindings=len(supplements), report_sha256=digest(report), accounting_sha256=digest(SCRATCH / 'ACCOUNTING.json'), handoff_sha256=digest(SCRATCH / 'HANDOFF.json'), all_eighteen_cells='OPEN')
assert seal['deadline_met'] and scratch_bytes + 8192 < 8 * 1024 ** 2
(SCRATCH / 'SEAL.json').write_text(json.dumps(seal, indent=2) + '\n')
for path in [report, SCRATCH / 'INPUT-ENTRY.json', SCRATCH / 'INPUT-EXIT.json', SCRATCH / 'SUPPLEMENT-ENTRY.json', SCRATCH / 'SUPPLEMENT-EXIT.json', SCRATCH / 'ACCOUNTING.json', SCRATCH / 'HANDOFF.json', manifest, SCRATCH / 'SEAL.json']:
    print(digest(path), str(path))
print(json.dumps(seal, indent=2))
