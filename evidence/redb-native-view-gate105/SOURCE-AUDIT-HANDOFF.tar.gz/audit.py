import collections
import hashlib
import json
import pathlib
import sys
import time

ROOT = pathlib.Path('/Users/tommyvolk/.t3/worktrees/verus/t3-60978068')
SCRATCH = pathlib.Path(__file__).parent
START = 1794104092
DEADLINE = START + 480
INPUT = ROOT / 'evidence/redb-native-view-gate105/INPUT-BINDINGS.json'
EXPECTED = 'a4907538147155022200c11d6a14855bcddc540b77e7a8312371f1913321041e'

def digest(path):
    result = hashlib.sha256()
    with open(path, 'rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            result.update(block)
    return result.hexdigest()

def authenticate(phase):
    assert time.time() < DEADLINE
    assert digest(INPUT) == EXPECTED
    payload = json.loads(INPUT.read_text())
    records = []
    for binding in payload['bindings']:
        assert time.time() < DEADLINE
        observed = digest(binding['path'])
        records.append(dict(binding, observed_sha256=observed, match=observed == binding['sha256']))
    result = dict(phase=phase, started_epoch=START, recorded_epoch=time.time(), absolute_deadline_epoch=DEADLINE, input_path=str(INPUT), input_sha256=EXPECTED, count=len(records), matched=sum(record['match'] for record in records), roles=dict(collections.Counter(record['role'] for record in records)), bindings=records)
    (SCRATCH / ('INPUT-' + phase.upper() + '.json')).write_text(json.dumps(result, indent=2) + '\n')
    assert len(records) == 212 and all(record['match'] for record in records)
    print(json.dumps({key: value for key, value in result.items() if key != 'bindings'}, indent=2))

def supplement(paths):
    destination = SCRATCH / 'SUPPLEMENT-ENTRY.json'
    records = json.loads(destination.read_text()) if destination.exists() else []
    known = {record['path'] for record in records}
    for path in paths:
        assert time.time() < DEADLINE
        if path not in known:
            records.append(dict(path=path, sha256=digest(path), recorded_before_substantive_read_epoch=time.time(), role='NEW_SOURCE_OR_INSTRUCTION_READ_ONLY_NOT_IN_SUPPLIED_212'))
    destination.write_text(json.dumps(records, indent=2) + '\n')
    print(json.dumps(records, indent=2))

if __name__ == '__main__':
    if sys.argv[1] == 'supplement':
        supplement(sys.argv[2:])
    else:
        authenticate(sys.argv[1])
