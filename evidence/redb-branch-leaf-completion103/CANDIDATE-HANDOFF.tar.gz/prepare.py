from pathlib import Path
import subprocess

root = Path('/private/tmp/branch-leaf-completion103-impl-R5nrcY0D')
old = Path('/private/tmp/branch-leaf-composition102-impl-SqXAof8z')
source = (old / 'attempt-008/input.rs').read_text()
leaf_start = source.index('pub proof fn fixture_leaf(')
lawful_start = source.index('pub proof fn fixture_lawful(')
witness_start = source.index('pub fn fixed_witness(')
leaf_text = source[leaf_start:lawful_start]
lawful_text = source[lawful_start:witness_start]
parts = [source[:leaf_start]]
for variable in (False, True):
    mode = 'variable' if variable else 'fixed'
    for child in range(3):
        specialized = leaf_text.replace('fixture_leaf(', 'fixture_leaf_%s_%d(' % (mode, child), 1)
        specialized = specialized.replace('page: Seq<u8>, child: int, variable: bool, first:', 'page: Seq<u8>, first:', 1)
        import re
        specialized = re.sub(r'\bchild\b', str(child), specialized)
        specialized = re.sub(r'\bvariable\b', str(variable).lower(), specialized)
        parts.append(specialized)
signature = leaf_text[:leaf_text.index('\n{')]
dispatch = '\n{\n    if variable {\n'
for variable in (True, False):
    mode = 'variable' if variable else 'fixed'
    if not variable:
        dispatch += '    } else {\n'
    dispatch += '        if child == 0 { fixture_leaf_%s_0(page, first, second); }\n' % mode
    dispatch += '        else if child == 1 { fixture_leaf_%s_1(page, first, second); }\n' % mode
    dispatch += '        else { fixture_leaf_%s_2(page, first, second); }\n' % mode
dispatch += '    }\n}\n\n'
parts.append(signature + dispatch)
for variable in (False, True):
    mode = 'variable' if variable else 'fixed'
    specialized = lawful_text.replace('fixture_lawful(', 'fixture_lawful_%s(' % mode, 1)
    specialized = specialized.replace('leaves: Seq<&[u8]>, variable: bool,', 'leaves: Seq<&[u8]>,', 1)
    specialized = re.sub(r'\bvariable\b', str(variable).lower(), specialized)
    parts.append(specialized)
signature = lawful_text[:lawful_text.index('\n{')]
parts.append(signature + '\n{\n    if variable { fixture_lawful_variable(bytes, leaves, first, second, third, fourth, fifth, sixth); }\n    else { fixture_lawful_fixed(bytes, leaves, first, second, third, fourth, fifth, sixth); }\n}\n\n')
witnesses = source[witness_start:]
for mode in ('fixed', 'variable'):
    begin = witnesses.index('pub fn %s_witness' % mode)
    end = witnesses.find('pub fn ', begin + 1)
    if end < 0:
        end = len(witnesses)
    segment = witnesses[begin:end]
    marker = '    let result = route_then_search(&bytes, &leaves, kw, vw, &query);'
    segments = segment.split(marker)
    rebuilt = segments[0]
    for number, remainder in enumerate(segments[1:]):
        if number < 6:
            child = number // 2
            index = number % 2
            rebuilt += '    proof {\n        assert(leaf::encoded_key(leaves@[%d]@, kw, vw, %d) == query@);\n        assert(union_has(leaves@, kw, vw, query@));\n    }\n' % (child, index)
        rebuilt += marker + remainder
    witnesses = witnesses[:begin] + rebuilt + witnesses[end:]
parts.append(witnesses)
result = ''.join(parts)
patch = '*** Begin Patch\n*** Add File: %s\n' % (root / 'positive.rs')
patch += ''.join('+' + line + '\n' for line in result.splitlines())
patch += '*** End Patch\n'
subprocess.run(['apply_patch', patch], check=True)
