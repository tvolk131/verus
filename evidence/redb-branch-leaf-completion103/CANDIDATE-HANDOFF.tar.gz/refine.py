from pathlib import Path
import subprocess

root = Path('/private/tmp/branch-leaf-completion103-impl-R5nrcY0D')
path = root / 'positive.rs'
source = path.read_text()
for mode in ('fixed', 'variable'):
    begin = source.index('pub proof fn fixture_lawful_%s(' % mode)
    end = source.index('\npub ', begin + 1)
    original = source[begin:end]
    body_start = original.index('\n{')
    leaf_calls = original.index('    fixture_leaf(leaves[0]@')
    branch_body = original[body_start:leaf_calls] + '}\n\n'
    literal = 'true' if mode == 'variable' else 'false'
    branch_signature = '''pub proof fn fixture_branch_%s(bytes: Seq<u8>)
    requires bytes == branch_image(%s),
    ensures branch_clients023::ordered_bytes::<u32>(bytes, fixture_kw(%s)),
        branch::key_count(bytes) == 2,
        branch::encoded_key(bytes, fixture_kw(%s), 0) == seq![0u8, 1, 0, 0],
        branch::encoded_key(bytes, fixture_kw(%s), 1) == seq![0u8, 0, 1, 0],
        meaning(branch::encoded_key(bytes, fixture_kw(%s), 0)) == 256,
        meaning(branch::encoded_key(bytes, fixture_kw(%s), 1)) == 65536,
''' % (mode, literal, literal, literal, literal, literal, literal)
    branch_body = branch_body.replace('    let vw = fixture_vw(%s);\n' % literal, '')
    branch_helper = branch_signature + branch_body
    remainder = original[leaf_calls:]
    remainder = remainder.replace('        decoded_four(fixture_key(child, index));', '        fixture_interval(bytes, kw, child, index);')
    assembled = original[:body_start] + '\n{\n    let kw = fixture_kw(%s);\n    let vw = fixture_vw(%s);\n    fixture_branch_%s(bytes);\n' % (literal, literal, mode) + remainder
    source = source[:begin] + branch_helper + assembled + source[end:]
interval_helper = '''pub proof fn fixture_interval(bytes: Seq<u8>, kw: Option<usize>, child: int, index: int)
    requires branch::key_count(bytes) == 2,
        meaning(branch::encoded_key(bytes, kw, 0)) == 256,
        meaning(branch::encoded_key(bytes, kw, 1)) == 65536,
        0 <= child < 3, 0 <= index < 2,
    ensures interval(bytes, kw, child, fixture_key(child, index)),
{
    if child == 0 {
        if index == 0 { decoded_four(fixture_key(0, 0)); }
        else { decoded_four(fixture_key(0, 1)); }
    } else if child == 1 {
        if index == 0 { decoded_four(fixture_key(1, 0)); }
        else { decoded_four(fixture_key(1, 1)); }
    } else {
        if index == 0 { decoded_four(fixture_key(2, 0)); }
        else { decoded_four(fixture_key(2, 1)); }
    }
}

'''
insert = source.index('pub proof fn fixture_branch_fixed(')
source = source[:insert] + interval_helper + source[insert:]
old_source = path.read_text()
patch = '*** Begin Patch\n*** Update File: %s\n@@\n' % path
patch += ''.join('-' + line + '\n' for line in old_source.splitlines())
patch += ''.join('+' + line + '\n' for line in source.splitlines())
patch += '*** End Patch\n'
subprocess.run(['apply_patch', patch], check=True)
