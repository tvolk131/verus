from pathlib import Path
import subprocess

path = Path('/private/tmp/branch-leaf-completion103-impl-R5nrcY0D/positive.rs')
original = path.read_text()
source = original
helper = '''pub proof fn branch_count_two(bytes: Seq<u8>)
    requires bytes.len() >= 4, bytes[2] == 2, bytes[3] == 0,
    ensures branch::key_count(bytes) == 2,
{
    leaf_lookup023::concrete_le16(bytes, 2);
}

pub proof fn branch_ordered_two(bytes: Seq<u8>, kw: Option<usize>)
    requires 32 <= bytes.len() <= usize::MAX, bytes[0] == 2,
        branch::key_count(bytes) == 2,
        branch::metadata(2, kw) + 8 <= bytes.len(),
        branch::boundary(bytes, kw, 0) == branch::metadata(2, kw),
        branch::boundary(bytes, kw, 1) == branch::metadata(2, kw) + 4,
        branch::boundary(bytes, kw, 2) == branch::metadata(2, kw) + 8,
        branch::encoded_key(bytes, kw, 0) == seq![0u8, 1, 0, 0],
        branch::encoded_key(bytes, kw, 1) == seq![0u8, 0, 1, 0],
    ensures branch_clients023::ordered_bytes::<u32>(bytes, kw),
        meaning(branch::encoded_key(bytes, kw, 0)) == 256,
        meaning(branch::encoded_key(bytes, kw, 1)) == 65536,
{
    assert forall|boundary: int| 0 <= boundary <= 2 implies branch::metadata(2, kw) <= #[trigger] branch::boundary(bytes, kw, boundary) <= bytes.len() by {
        assert(boundary == 0 || boundary == 1 || boundary == 2);
    }
    assert forall|index: int| 0 <= index < 2 implies #[trigger] branch::boundary(bytes, kw, index) <= branch::boundary(bytes, kw, index + 1) by {
        assert(index == 0 || index == 1);
    }
    decoded_four(branch::encoded_key(bytes, kw, 0));
    decoded_four(branch::encoded_key(bytes, kw, 1));
    meaning_bridge(branch::encoded_key(bytes, kw, 0));
    meaning_bridge(branch::encoded_key(bytes, kw, 1));
    assert forall|index: int| 0 <= index < 2 implies <u32 as leaf_lookup023::Value>::valid(#[trigger] branch::encoded_key(bytes, kw, index)) by {
        assert(index == 0 || index == 1);
    }
    assert forall|left: int, right: int| 0 <= left < right < 2 implies <u32 as leaf_lookup023::Value>::meaning(#[trigger] branch::encoded_key(bytes, kw, left)) < <u32 as leaf_lookup023::Value>::meaning(#[trigger] branch::encoded_key(bytes, kw, right)) by {
        assert(left == 0 && right == 1);
    }
}

'''
for mode in ('fixed', 'variable'):
    begin = source.index('pub proof fn fixture_branch_%s(' % mode)
    end = source.index('\npub ', begin + 1)
    function = source[begin:end]
    signature = function[:function.index('\n{')]
    literal = 'true' if mode == 'variable' else 'false'
    body = '\n{\n    let kw = fixture_kw(%s);\n    branch_count_two(bytes);\n' % literal
    if mode == 'variable':
        body += '    leaf_lookup023::concrete_le32(bytes, 80);\n    leaf_lookup023::concrete_le32(bytes, 84);\n'
    body += '    assert(branch::encoded_key(bytes, kw, 0) =~= seq![0u8, 1, 0, 0]);\n    assert(branch::encoded_key(bytes, kw, 1) =~= seq![0u8, 0, 1, 0]);\n    branch_ordered_two(bytes, kw);\n}\n'
    source = source[:begin] + signature + body + source[end:]
insert = source.index('pub proof fn fixture_branch_fixed(')
source = source[:insert] + helper + source[insert:]
patch = '*** Begin Patch\n*** Update File: %s\n@@\n' % path
patch += ''.join('-' + line + '\n' for line in original.splitlines())
patch += ''.join('+' + line + '\n' for line in source.splitlines())
patch += '*** End Patch\n'
subprocess.run(['apply_patch', patch], check=True)
