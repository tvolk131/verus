from pathlib import Path
import subprocess

path = Path('/private/tmp/branch-leaf-completion103-impl-R5nrcY0D/positive.rs')
original = path.read_text()
source = original
for mode in ('fixed', 'variable'):
    begin = source.index('pub fn %s_witness(' % mode)
    end = source.find('\npub ', begin + 1)
    if end < 0:
        end = source.rfind('\n}')
    function = source[begin:end]
    first_query = function.index('    let query:')
    setup = function[:first_query]
    queries = function[first_query:function.rfind('\n}')].split('    let query:')[1:]
    replacements = []
    for number, query in enumerate(queries):
        replacements.append(setup.replace('pub fn %s_witness(' % mode, 'pub fn %s_query_%d(' % (mode, number), 1) + '    let query:' + query + '\n}\n')
    signature = function[:function.index('{')]
    wrapper = signature + '{\n'
    for number in range(len(queries)):
        wrapper += '    %s_query_%d(first, second, third, fourth, fifth, sixth);\n' % (mode, number)
    wrapper += '}\n'
    replacements.append(wrapper)
    source = source[:begin] + '\n'.join(replacements) + source[end:]
helper = '''pub proof fn numeric_not_lexical()
    ensures meaning(fixture_key(0, 0)) < meaning(fixture_key(0, 1)),
        fixture_key(0, 0)[0] > fixture_key(0, 1)[0],
        meaning(fixture_key(0, 1)) < meaning(fixture_key(1, 1)),
        fixture_key(0, 1)[0] == fixture_key(1, 1)[0],
        fixture_key(0, 1)[1] > fixture_key(1, 1)[1],
{
    decoded_four(fixture_key(0, 0));
    decoded_four(fixture_key(0, 1));
    decoded_four(fixture_key(1, 1));
}

'''
insert = source.index('pub fn fixed_query_0(')
source = source[:insert] + helper + source[insert:]
patch = '*** Begin Patch\n*** Update File: %s\n@@\n' % path
patch += ''.join('-' + line + '\n' for line in original.splitlines())
patch += ''.join('+' + line + '\n' for line in source.splitlines())
patch += '*** End Patch\n'
subprocess.run(['apply_patch', patch], check=True)
