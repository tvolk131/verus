import datetime
import difflib
import hashlib
import json
from pathlib import Path
import re
import runpy
import shutil
import time

ROOT = Path('/private/tmp/branch-leaf-completion103-impl-R5nrcY0D')
OLD = Path('/private/tmp/branch-leaf-composition102-impl-SqXAof8z')
helpers = runpy.run_path(str(ROOT / 'runner.py'))
save = helpers['save']
digest = helpers['digest']
ledger = json.loads((ROOT / 'ACCOUNTING.json').read_text())
assert len(ledger['attempts']) == 10
assert ledger['actual_verifier_launches'] == 10
assert ledger['attempts'][-1]['summary']['success']
assert time.time() < helpers['DEADLINE']

def item(source, name):
    found = re.search(r'pub (?:open spec |proof )?fn ' + re.escape(name) + r'\b', source)
    assert found is not None, name
    begin = found.start()
    body = source.index('{', found.end())
    depth = 1
    end = body + 1
    while depth:
        if source[end] == '{':
            depth += 1
        elif source[end] == '}':
            depth -= 1
        end += 1
    return source[begin:end]

original_generic = (OLD / 'attempt-003/input.rs').read_text()
baseline = (ROOT / 'attempt-005/input.rs').read_text()
restored = (ROOT / 'attempt-010/input.rs').read_text()
assert baseline == restored == (ROOT / 'positive.rs').read_text() == (ROOT / 'restored-positive.rs').read_text()
names = ['meaning_bridge', 'meaning', 'interval', 'supplied', 'union_has', 'matching_child', 'route_then_search']
preservation = []
for name in names:
    old_item = item(original_generic, name)
    new_item = item(baseline, name)
    assert old_item == new_item, name
    preservation.append(dict(name=name, byte_identical=True, sha256=hashlib.sha256(old_item.encode()).hexdigest()))
all_names = re.findall(r'pub (?:open spec |proof )?fn (\w+)\b', baseline)
variant_results = []
for stage in (6, 7, 8, 9):
    variant = (ROOT / ('attempt-%03d/input.rs' % stage)).read_text()
    assert all(item(baseline, name) == item(variant, name) for name in all_names)
    variant_results.append(dict(attempt=stage, positive_entities_preserved=len(all_names), all_byte_identical=True))
save(ROOT / 'SOURCE-PRESERVATION.json', dict(generic_source_sha256=digest(OLD / 'attempt-003/input.rs'),
    generic_entities=preservation, positive_source_sha256=digest(ROOT / 'attempt-005/input.rs'),
    final_restored_source_sha256=digest(ROOT / 'attempt-010/input.rs'),
    restoration_byte_identical=True, variants=variant_results))

controls = []
for negative, counterpart, label, intended in [
    (6, 8, 'wrong-child', 'assert(hit.is_some() == union_has(leaves@, kw, vw, query@));'),
    (7, 9, 'wrong-value', 'assert(result.2.unwrap().1@ == seq![first]);'),
]:
    stage = ROOT / ('attempt-%03d' % negative)
    result = json.loads((stage / 'actual-verification.json').read_text())
    positive_result = json.loads((ROOT / ('attempt-%03d/actual-verification.json' % counterpart)).read_text())
    stderr = (stage / 'stderr.txt').read_text()
    assert result['verification-results']['errors'] == 1
    assert result['verification-results']['verified'] == 38
    assert not result['verification-results']['encountered-vir-error']
    assert stderr.count('error: assertion failed') == 1
    assert intended in stderr
    assert 'Resource limit' not in stderr
    assert positive_result['verification-results']['success']
    negative_source = (stage / 'input.rs').read_text().splitlines(keepends=True)
    correct_source = (ROOT / ('attempt-%03d/input.rs' % counterpart)).read_text().splitlines(keepends=True)
    changes = list(difflib.unified_diff(negative_source, correct_source, fromfile='negative', tofile='corrected'))
    (ROOT / (label + '-matched.diff')).write_text(''.join(changes))
    assert len(negative_source) == len(correct_source)
    changed_lines = [(number, negative_line, correct_line) for number, (negative_line, correct_line) in enumerate(zip(negative_source, correct_source), 1) if negative_line != correct_line]
    assert len(changed_lines) == 1
    number, negative_line, correct_line = changed_lines[0]
    (ROOT / (label + '-matched.diff')).write_text('--- negative\n+++ corrected\n@@ -%d,1 +%d,1 @@\n-%s+%s' % (number, number, negative_line, correct_line))
    controls.append(dict(label=label, negative_attempt=negative, corrected_attempt=counterpart,
        intended_assertion=intended, backend_assertion_failures=1, unrelated_failures=0,
        positive_entities_preserved=True, matched_single_assertion_line=True,
        negative_source_sha256=digest(stage / 'input.rs'),
        counterpart_source_sha256=digest(ROOT / ('attempt-%03d/input.rs' % counterpart))))
save(ROOT / 'CONTROLS.json', controls)

scopes = []
original_invocation = json.loads((OLD / 'attempt-003/invocation.json').read_text())
for attempt in ledger['attempts']:
    index = attempt['attempt']
    stage = ROOT / ('attempt-%03d' % index)
    result = json.loads((stage / 'stdout.txt').read_text())
    scope = result['verus-infer']['verification_scope']
    save(stage / 'actual-scope.json', scope)
    invocation = json.loads((stage / 'invocation.json').read_text())
    assert invocation['argv'][:-1] == original_invocation['argv'][:-1]
    assert invocation['environment'] == {key: value.replace(str(OLD / 'attempt-003'), str(stage)) for key, value in original_invocation['environment'].items()}
    assert invocation['timeout_seconds'] <= 60
    assert invocation['start'] < helpers['STOP']
    attempt['summary'] = result['verification-results']
    scopes.append(dict(attempt=index, label=attempt['label'], verification=result['verification-results'],
        complete_selected_scope_verified=scope['complete_selected_scope_verified'],
        checked_exec_bodies=scope['checked_exec_bodies'], checked_proof_bodies=scope['checked_proof_bodies']))
save(ROOT / 'SCOPE-INVENTORY.json', scopes)
save(ROOT / 'SETUP-FAILURES.json', dict(conservatively_charged=1, verifier_setup_or_spawn_failures=0,
    diagnostic='One exploratory Python metadata-path listing had an unmatched-parenthesis SyntaxError before any verifier use; conservatively charged despite not being a verifier launch.',
    stderr='SyntaxError: unmatched \')\'\n',
    provenance='Diagnostic retained from tool transcript. This non-verifier exploratory shell command did not capture its complete inherited shell environment. All ten verifier argv/full environments and raw stdout/stderr are retained.',
    exploratory_read_path_misses='Guessed lowercase accounting/argv/env names and branch.rs/SEAL.sha256 did not exist; correct uppercase ACCOUNTING.json, invocation.json, branch-003.rs and SEAL.json were subsequently read. These were read-only discovery diagnostics, not verifier applications or dependent execution.'))

helpers['authenticate']('exit')
authentications = [json.loads(path.read_text()) for path in ROOT.glob('*-authentication.json')]
assert len(authentications) == 22
assert all(report['all_match'] and report['current_binding_count'] == 320 for report in authentications)
ledger.update(total_charged_attempts=12, numbered_attempts=10,
    additional_conservatively_charged_exploratory_metadata_failure=1,
    additional_conservatively_charged_finalization_check_failure=1,
    actual_verifier_launches=10, semantic_negatives_launched=2,
    semantic_negatives_localized=2, corrected_counterparts_checked=2,
    full_positive_restoration_recheck=True,
    full_positive_sha256=digest(ROOT / 'restored-positive.rs'),
    full_positive_verified=38, full_positive_errors=0,
    all_pre_post_entry_exit_auth_match=True, bindings_per_authentication=320,
    authentication_snapshots=22, max_actual_application_seconds=max(item['elapsed_seconds'] for item in ledger['attempts']),
    timeouts=sum(item['timed_out'] for item in ledger['attempts']),
    maximum_recorded_scratch_bytes=max(report['scratch_bytes'] for report in authentications),
    minimum_recorded_free_bytes=min(report['free_bytes'] for report in authentications),
    scratch_limit_bytes=128 * 1024**2, free_disk_floor_bytes=16 * 1024**3,
    finalization_record_epoch=time.time(), elapsed_seconds_at_record=time.time() - helpers['START'],
    fresh_independent_review_required=True, all_eighteen_cells='OPEN',
    status='BOUNDED_CHECKED_PROOF_GATES_COMPLETED_NOT_ACCEPTED_ALL18OPEN')
save(ROOT / 'ACCOUNTING.json', ledger)
report = '''# Completion103: bounded checked-proof gates completed; NOT ACCEPTED

## Exact checked source and scope

`restored-positive.rs` and `attempt-010/input.rs` are byte-identical to the first
full positive `attempt-005/input.rs`: SHA256
`1e501a924f43adf863a80dc1454fdb1e506f071ed74caf79e02b02868bf5fcaf`.
Both full local verifier applications report 38 verified / 0 errors: 19 executable
bodies and 19 proof bodies, entire crate selected, with no filters. These are
authored client/ghost bodies, NOT freshly checked imported native bodies.

All seven original generic entities (meaning bridge, meaning, interval, supplied,
union_has, matching_child, route_then_search) retain byte-identical bodies and
signatures/contracts from checked102 attempt003. SOURCE-PRESERVATION.json records
per-entity hashes and preservation of every completed positive entity in both
negative variants and both corrected counterparts. Generic lawful arbitrary
keys/values/domain are unchanged; no new assumption or result/existence premise.

## Meaningful fixture completion

Lawful branch/leaf images are derived, not assumed, with separators256/65536 and
child keys [1,256], [257,65536], [65537,u32::MAX]. Six independent u8 arguments
remain unrestricted in every positive fixed/variable query caller. Fixed lengths
are 88/14 bytes; variable lengths96/30, with explicit endpoint tables. All six
present queries and absent0/2 are checked independently in both modes, including
exact returned query/value bytes, equality LEFT and numeric versus lexical order.
The checked numeric_not_lexical proof makes both lexical-order inversions explicit.
The executable composition continues to invoke the actual imported route_u32 and
search_u32, using the original supplied child array. No replacement runtime route
or search was authored. Existing public concrete LE decoding contracts are used;
no closed vstd definition was revealed and no privacy/runtime/trust was changed.

Concrete child/width leaf cases, abstract two-separator branch layout and small
interval reasoning avoid the earlier quantified proof resource explosions.
Separating each of the eight query callers in each width mode removes cumulative
caller solver load. All intermediate resource failures remain retained.

## Two localized matched controls and restoration

Only after attempt005's clean full positive, attempt006 correctly routes query256
to the left child using native route_u32, then deliberately searches the middle
child with native search_u32 and falsely asserts union completeness. It proves
selected==0, hit.is_none() and union presence before the sole intended failing
backend assertion. Attempt007 correctly routes/searches257, proves selected==1,
present exact key and value22, then falsely claims another child's value11.
The controls use lawful fixed fixture bytes at values11,12,22,23,33,34, without
narrowing any generic or arbitrary-value positive theorem.

Each control reports 38 verified / exactly1 error, the intended backend assertion
only: no frontend, resource, precondition, bounds, timeout, panic or import credit.
Attempts008/009 check single-assertion corrected counterparts:39 verified/0errors
each. CONTROLS.json and matched diffs retain the exact claims and single-line
relationship. All completed positive bodies remain byte-identical per variant.
Attempt010 finally rechecks byte-identical full positive:38 verified/0errors.

## Authentication and operational accounting

All320 current bindings match at entry, immediately before/after all10 verifier
launches, and exit (22 snapshots). All78 sealed102 payloads plus manifest/seal
(80 total files) are authenticated every time, including exact manifest
fd1a195803665011a015fc32856cd613924a806177d65e26615f73629473b281 and seal
b07c4ee24d953eedb23f30da01a53e93e43c273a8cf3fe90adebda834b0256d8.
The binding table, PLAN hash and two explicitly reconciled metadata contexts are
respected; original102 historical metadata hashes are not misapplied to current
live context. No unexplained mismatch or manifest edit occurred.

Fresh ledger:10 actual launches +1 conservatively charged exploratory metadata
SyntaxError +1 conservatively charged finalization diff-audit failure =12/16 charges.
FINALIZATION-FAILURES.json retains the corrected audit-only failure; no proof
source, invocation or verifier result changed. No verifier setup/spawn failure,
timeout or concurrent
verifier/solver workers; --num-threads1 and the exact original release invocation,
all7 matched VIR/rlib pairs, midpoint runtime and selected1.99.1 sysroot bindings.
Every verifier argv/full environment, source, raw stdout/stderr, JSON verification,
scope and timing is retained. SETUP-FAILURES.json discloses the non-verifier
exploratory shell-environment recording gap rather than claiming it was captured.
The old102 ledger remains9charged/7launches, no semantic controls/restoration;
its earlier research wall violation remains retained, not reset or waived.

Start2026-11-08 01:39:31UTC (November7 19:39:31CST); launch/optional cutoff01:51:31UTC;
absolute deadline01:54:31UTC. Runner enforces min(60seconds, remaining launch
window), single process group and kill-on-timeout. ACCOUNTING.json records actual
timings, scratch/free disk and completion before the absolute deadline. Only this
fresh scratch was written; no parent/Git writes, sealed scripts run in place,
network, compilation/export/build/native execution, runtime/toolchain/cache
copies, trust/axiom/assume/admit/external-body/admission changes or adoption.
Only historically bound selected sysroot artifacts were authenticated: not a new
full sysroot audit. The seal is content integrity, not certification.

## Remaining gates and inherited limits

Fresh independent review is REQUIRED; no final acceptance or cell promotion.
All18 final redb cells remain OPEN. Native-path preservation remains FAILED and
Git continuity UNAVAILABLE. Range/ordered-leaf conditions are explicit generic
caller premises, not native reachable-tree range establishment or preservation.
The page-number result does not prove fetched-page/supplied-image identity.
No native fetch-image/range establishment, native path continuity, ownership,
Drop/panic/glue/allocator/I/O/history or global database completeness is claimed.
Inherited conditional midpoint/std/slice/array/StructuralEq/LE/runtime/trait,
comparison/loop/adapter/compiler/solver TCB boundaries remain unchanged.
Variable-width accessor witnesses do not certify native fixed-u32 policy.
No growth049/zero-growth050/mutation030/refused-padding95/drop-pipeline work was
resumed or rerouted. This completion does not adopt native code or close cells.
'''
(ROOT / 'REPORT.md').write_text(report)
payloads = sorted(path for path in ROOT.rglob('*') if path.is_file() and path.name not in ('MANIFEST.sha256', 'SEAL.json'))
manifest = ''.join(digest(path) + '  ' + str(path.relative_to(ROOT)) + '\n' for path in payloads)
(ROOT / 'MANIFEST.sha256').write_text(manifest)
seal = dict(manifest_sha256=digest(ROOT / 'MANIFEST.sha256'), payload_file_count=len(payloads),
    total_file_count=len(payloads) + 2, report_sha256=digest(ROOT / 'REPORT.md'),
    accounting_sha256=digest(ROOT / 'ACCOUNTING.json'), full_positive_sha256=digest(ROOT / 'restored-positive.rs'),
    sealed_epoch=time.time(), elapsed_seconds=time.time() - helpers['START'],
    scope='content integrity only; checked-proof gates completed, fresh independent review required; NOT ACCEPTED; all18 OPEN')
assert seal['sealed_epoch'] < helpers['DEADLINE']
assert sum(path.stat().st_size for path in payloads) < 128 * 1024**2
assert shutil.disk_usage(ROOT).free > 16 * 1024**3
save(ROOT / 'SEAL.json', seal)
assert all(digest(path) == line.split('  ', 1)[0] for path, line in zip(payloads, manifest.splitlines()))
print(json.dumps(dict(scratch=str(ROOT), manifest_sha256=digest(ROOT / 'MANIFEST.sha256'),
    seal_sha256=digest(ROOT / 'SEAL.json'), **{key: value for key, value in seal.items() if key != 'manifest_sha256'}), indent=2))
