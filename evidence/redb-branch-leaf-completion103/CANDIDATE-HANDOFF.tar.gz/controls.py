from pathlib import Path
import subprocess
import json

root = Path('/private/tmp/branch-leaf-completion103-impl-R5nrcY0D')
positive = (root / 'positive.rs').read_text()
ledger = json.loads((root / 'ACCOUNTING.json').read_text())
assert ledger['attempts'][-1]['summary']['success']
start = positive.index('pub fn fixed_query_0(')
stop = positive.index('    let query:', start)
setup = positive[start:stop]
setup = setup.replace('pub fn fixed_query_0(first: u8, second: u8, third: u8, fourth: u8, fifth: u8, sixth: u8) {', 'pub fn CONTROL_NAME() {\n    let first: u8 = 11;\n    let second: u8 = 12;\n    let third: u8 = 22;\n    let fourth: u8 = 23;\n    let fifth: u8 = 33;\n    let sixth: u8 = 34;')
wrong_child = setup.replace('CONTROL_NAME', 'wrong_child_control') + '''    let query: [u8; 4] = [0, 1, 0, 0];
    proof {
        decoded_four(query@);
        assert(leaf::encoded_key(leaves@[0]@, kw, vw, 1) == query@);
        assert(union_has(leaves@, kw, vw, query@));
    }
    let (selected, page) = branch_clients023::route_u32(&bytes, kw, &query);
    assert(selected == 0);
    assert(page == branch::decoded_child(bytes@, selected as int));
    let hit = lookup_client::search_u32(leaves[1], kw, vw, &query);
    assert(hit.is_none());
    assert(hit.is_some() == union_has(leaves@, kw, vw, query@));
}
'''
wrong_value = setup.replace('CONTROL_NAME', 'wrong_value_control') + '''    let query: [u8; 4] = [1, 1, 0, 0];
    proof {
        decoded_four(query@);
        assert(leaf::encoded_key(leaves@[1]@, kw, vw, 0) == query@);
        assert(union_has(leaves@, kw, vw, query@));
    }
    let result = route_then_search(&bytes, &leaves, kw, vw, &query);
    assert(result.0 == 1);
    assert(result.2.is_some());
    assert(result.2.unwrap().0@ == query@);
    assert(result.2.unwrap().1@ == seq![third]);
    assert(first == 11 && third == 22 && first != third);
    assert(result.2.unwrap().1@ == seq![first]);
}
'''
for name, body in [('wrong-child.rs', wrong_child), ('wrong-value.rs', wrong_value)]:
    result = positive[:positive.rfind('\n}')] + '\n' + body + '}\n'
    patch = '*** Begin Patch\n*** Add File: %s\n' % (root / name)
    patch += ''.join('+' + line + '\n' for line in result.splitlines())
    patch += '*** End Patch\n'
    subprocess.run(['apply_patch', patch], check=True)
