from pathlib import Path
import subprocess

root = Path('/private/tmp/branch-leaf-completion103-impl-R5nrcY0D')
for name, old, corrected in [
    ('wrong-child', '    assert(hit.is_some() == union_has(leaves@, kw, vw, query@));', '    assert(hit.is_none() && union_has(leaves@, kw, vw, query@));'),
    ('wrong-value', '    assert(result.2.unwrap().1@ == seq![first]);', '    assert(result.2.unwrap().1@ == seq![third]);'),
]:
    source = (root / (name + '.rs')).read_text()
    position = source.rfind(old)
    assert position >= 0
    source = source[:position] + source[position:].replace(old, corrected, 1)
    target = root / (name + '-corrected.rs')
    patch = '*** Begin Patch\n*** Add File: %s\n' % target
    patch += ''.join('+' + line + '\n' for line in source.splitlines())
    patch += '*** End Patch\n'
    subprocess.run(['apply_patch', patch], check=True)
baseline = (root / 'attempt-005/input.rs').read_text()
patch = '*** Begin Patch\n*** Add File: %s\n' % (root / 'restored-positive.rs')
patch += ''.join('+' + line + '\n' for line in baseline.splitlines())
patch += '*** End Patch\n'
subprocess.run(['apply_patch', patch], check=True)
assert (root / 'restored-positive.rs').read_bytes() == (root / 'attempt-005/input.rs').read_bytes()
