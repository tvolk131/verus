import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time

ROOT = Path('/private/tmp/branch-leaf-completion103-impl-R5nrcY0D')
PARENT = Path('/Users/tommyvolk/.t3/worktrees/verus/t3-60978068')
OLD = Path('/private/tmp/branch-leaf-composition102-impl-SqXAof8z')
START = datetime.datetime.fromisoformat('2026-11-08T01:39:31+00:00').timestamp()
STOP = START + 720
DEADLINE = START + 900
BINDINGS = PARENT / 'evidence/redb-branch-leaf-completion103/INPUT-BINDINGS.json'

def digest(path):
    result = hashlib.sha256()
    with open(path, 'rb') as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b''):
            result.update(chunk)
    return result.hexdigest()

def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

def authenticate(label):
    begun = time.time()
    expected = {
        BINDINGS: '15e72043015fb58ee05d93932ec6d4471e23752a4889ed4830a68957c4f7cfb4',
        PARENT / 'evidence/redb-branch-leaf-completion103/PLAN.md': '025ed8d01e25ae3739df11c3c3d38aee94d4f54d8e9a314104f085d44491037b',
        OLD / 'MANIFEST.sha256': 'fd1a195803665011a015fc32856cd613924a806177d65e26615f73629473b281',
        OLD / 'SEAL.json': 'b07c4ee24d953eedb23f30da01a53e93e43c273a8cf3fe90adebda834b0256d8',
    }
    entries = json.loads(BINDINGS.read_text())['current_bindings']
    assert len(entries) == 320
    for entry in entries:
        expected[Path(entry['path'])] = entry['sha256']
    payloads = []
    for line in (OLD / 'MANIFEST.sha256').read_text().splitlines():
        hashed, relative = line.split('  ', 1)
        expected[OLD / relative] = hashed
        payloads.append(relative)
    assert len(payloads) == 78
    assert len([path for path in OLD.rglob('*') if path.is_file()]) == 80
    results = []
    for path, hashed in expected.items():
        try:
            actual = digest(path)
            results.append(dict(path=str(path), expected=hashed, actual=actual, match=actual == hashed))
        except Exception as error:
            results.append(dict(path=str(path), expected=hashed, error=repr(error), match=False))
    size = sum(path.stat().st_size for path in ROOT.rglob('*') if path.is_file())
    report = dict(label=label, start=begun, end=time.time(), current_binding_count=320,
                  sealed_payload_count=78, sealed_total_file_count=80,
                  all_match=all(item['match'] for item in results), results=results,
                  scratch_bytes=size, free_bytes=shutil.disk_usage(ROOT).free)
    save(ROOT / (label + '-authentication.json'), report)
    assert report['all_match'], [item for item in results if not item['match']]
    assert size < 128 * 1024 * 1024
    assert report['free_bytes'] > 16 * 1024**3
    return report

def run(source, label):
    ledger_path = ROOT / 'ACCOUNTING.json'
    ledger = json.loads(ledger_path.read_text()) if ledger_path.exists() else dict(
        start_epoch=START, stop_new_applications_epoch=STOP, absolute_deadline_epoch=DEADLINE,
        cap=16, total_charged_attempts=0, actual_verifier_launches=0,
        inherited102=dict(charged=9, launches=7, semantic_negatives=0, restoration=False,
                          prior_research_wall_violation_retained=True), attempts=[])
    assert time.time() < STOP
    assert ledger['total_charged_attempts'] < 16
    ledger['total_charged_attempts'] += 1
    index = ledger['total_charged_attempts']
    stage = ROOT / ('attempt-%03d' % index)
    stage.mkdir()
    save(ledger_path, ledger)
    authenticate('attempt-%03d-pre' % index)
    frozen = stage / 'input.rs'
    shutil.copyfile(source, frozen)
    original = json.loads((OLD / 'attempt-003/invocation.json').read_text())
    argv = original['argv'][:-1] + [str(frozen)]
    old_stage = str(OLD / 'attempt-003')
    environment = {key: value.replace(old_stage, str(stage)) for key, value in original['environment'].items()}
    for key, value in environment.items():
        if value.startswith(str(stage)) and key != 'PWD':
            Path(value).mkdir(parents=True, exist_ok=True)
    timeout = min(60, STOP - time.time())
    assert timeout > 0
    invocation = dict(label=label, argv=argv, environment=environment, cwd=str(stage),
                      source_sha256=digest(frozen), timeout_seconds=timeout,
                      start=time.time(), start_epoch=START, launch_stop=STOP, deadline=DEADLINE)
    save(stage / 'invocation.json', invocation)
    timed_out = False
    process = None
    try:
        with open(stage / 'stdout.txt', 'wb') as stdout, open(stage / 'stderr.txt', 'wb') as stderr:
            process = subprocess.Popen(argv, env=environment, cwd=stage, stdout=stdout, stderr=stderr, start_new_session=True)
            ledger['actual_verifier_launches'] += 1
            save(ledger_path, ledger)
            try:
                returncode = process.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                timed_out = True
                os.killpg(process.pid, signal.SIGKILL)
                returncode = process.wait()
        result = dict(returncode=returncode, timed_out=timed_out)
    except Exception as error:
        result = dict(spawn_error=repr(error), timed_out=timed_out)
    result.update(label=label, attempt=index, start=invocation['start'], end=time.time(), source_sha256=digest(frozen))
    result['elapsed_seconds'] = result['end'] - result['start']
    try:
        parsed = json.loads((stage / 'stdout.txt').read_text())
        save(stage / 'actual-verification.json', parsed)
        scope = parsed.get('verification-scope', parsed.get('verification_scope'))
        if scope is None:
            scope = parsed.get('verus-infer', {}).get('verification_scope')
        if scope is not None:
            save(stage / 'actual-scope.json', scope)
        result['summary'] = parsed.get('verification-results', {})
    except Exception as error:
        result['json_error'] = repr(error)
    save(stage / 'timing-result.json', result)
    ledger['attempts'].append(result)
    save(ledger_path, ledger)
    authenticate('attempt-%03d-post' % index)
    print(json.dumps(result, indent=2))

if __name__ == '__main__':
    if sys.argv[1] == 'auth':
        result = authenticate(sys.argv[2])
        print(json.dumps({key: value for key, value in result.items() if key != 'results'}, indent=2))
    elif sys.argv[1] == 'run':
        run(Path(sys.argv[2]), sys.argv[3])
