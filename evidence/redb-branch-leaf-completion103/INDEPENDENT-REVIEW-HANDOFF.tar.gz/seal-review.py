import json
from pathlib import Path
import sys
import time

sys.path.insert(0, '/private/tmp/completion103-independent-review-glXjLOpk')
from review import ROOT, START, STOP, DEADLINE, authenticate, digest, save, resources

assert (ROOT / 'REPORT.md').stat().st_size <= 24 * 1024
authentication = authenticate('exit')
receipts = sorted(ROOT.glob('*-authentication.json'))
assert len(receipts) == 10
assert all(json.loads(item.read_text())['all_match'] for item in receipts)
ledger = json.loads((ROOT / 'ACCOUNTING.json').read_text())
assert ledger['total_charged_applications'] == 6
assert ledger['actual_verifier_launches'] == 4
assert all(item['end'] < STOP for item in ledger['attempts'])
ledger['finalization_epoch'] = time.time()
ledger['elapsed_seconds_at_record'] = time.time() - START
ledger['all_authentication_endpoints_match'] = True
ledger['authentication_snapshots'] = len(receipts)
ledger['final_resource_snapshot'] = resources()
ledger['report_bytes'] = (ROOT / 'REPORT.md').stat().st_size
ledger['status'] = 'INDEPENDENT_CONDITIONAL_REVIEW_AND_FOUR_EXACT_RECHECKS_PASS_NOT_NATIVE_ACCEPTANCE_ALL18OPEN'
save(ROOT / 'ACCOUNTING.json', ledger)
save(ROOT / 'VERDICT.json', {'conditional_generic_contract_review': 'PASS', 'fixed_and_variable_positive_fixtures': 'PASS', 'fixed_semantic_controls': 'PASS', 'historical_single_assertion_counterparts': 'PASS', 'four_fresh_exact_rechecks': 'PASS', 'new_blocking_candidate_proof_source_defects_found': [], 'native_fetched_page_identity': 'NOT_ESTABLISHED', 'native_reachable_tree_ranges': 'NOT_ESTABLISHED', 'native_path_preservation': 'FAILED_INHERITED', 'git_continuity': 'UNAVAILABLE_INHERITED', 'native_or_whole_goal_acceptance': False, 'all_eighteen_cells': 'OPEN', 'content_seal_is_certificate': False})
members = sorted(item for item in ROOT.rglob('*') if item.is_file() and item.name not in {'MANIFEST.sha256', 'SEAL.json'})
manifest = ''.join(digest(item) + '  ' + str(item.relative_to(ROOT)) + '\n' for item in members)
(ROOT / 'MANIFEST.sha256').write_text(manifest)
save(ROOT / 'SEAL.json', {'manifest_sha256': digest(ROOT / 'MANIFEST.sha256'), 'report_sha256': digest(ROOT / 'REPORT.md'), 'accounting_sha256': digest(ROOT / 'ACCOUNTING.json'), 'payload_files': len(members), 'total_files': len(members) + 2, 'start_epoch': START, 'stop_optional_and_new_applications_epoch': STOP, 'absolute_deadline_epoch': DEADLINE, 'sealed_epoch': time.time(), 'elapsed_seconds': time.time() - START, 'charged_applications': 6, 'verifier_launches': 4, 'authentication_snapshots': 10, 'candidate_files_authenticated_each': 117, 'bindings_authenticated_each': 320, 'all_match': authentication['all_match'], 'scope': 'independent bounded conditional source/proof recheck; NOT native/whole-goal acceptance; content seal NOT certificate; all18OPEN', **resources()})
actual_files = {str(item.relative_to(ROOT)) for item in ROOT.rglob('*') if item.is_file()}
assert actual_files == {str(item.relative_to(ROOT)) for item in members} | {'MANIFEST.sha256', 'SEAL.json'}
assert all(digest(ROOT / line.split('  ', 1)[1]) == line.split('  ', 1)[0] for line in manifest.splitlines())
assert time.time() < STOP
print(json.dumps({'root': str(ROOT), 'manifest_sha256': digest(ROOT / 'MANIFEST.sha256'), 'seal_sha256': digest(ROOT / 'SEAL.json'), 'report_sha256': digest(ROOT / 'REPORT.md'), 'accounting_sha256': digest(ROOT / 'ACCOUNTING.json'), 'files': len(actual_files), 'report_bytes': (ROOT / 'REPORT.md').stat().st_size, 'elapsed_seconds': time.time() - START, 'resources': resources()}, indent=2))
