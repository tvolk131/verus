import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import sys
import time

ROOT = Path('/private/tmp/completion103-independent-review-glXjLOpk')
PARENT = Path('/Users/tommyvolk/.t3/worktrees/verus/t3-60978068')
CANDIDATE = Path('/private/tmp/branch-leaf-completion103-impl-R5nrcY0D')
CONTEXT = PARENT / 'evidence/redb-branch-leaf-completion103'
START = datetime.datetime.fromisoformat('2026-11-08T01:57:39+00:00').timestamp()
STOP = START + 720
DEADLINE = START + 900
PINS = {
    CONTEXT / 'REVIEW-PLAN.md': '9bb49f350f004103232ca0d76f6102700202ad63d3a4d718a4e478ed99142027',
    CONTEXT / 'CANDIDATE-STATUS.md': '4dfa213a09ca8859182ac55f814bf71255bdd9f52911f7f5008c3b92b7ed8668',
    CONTEXT / 'CANDIDATE-RETENTION.json': '4cdc5d4a07b3cde2ac64a544df223837590aa45cb9f793e425e34b91cfd050b8',
    CONTEXT / 'INPUT-BINDINGS.json': '15e72043015fb58ee05d93932ec6d4471e23752a4889ed4830a68957c4f7cfb4',
    CONTEXT / 'CANDIDATE-HANDOFF.tar.gz': 'ec0ee5608b3c5c76a442aae379d1ebdb96beab03e164d5713df7d313a8fb77dd',
    CANDIDATE / 'MANIFEST.sha256': 'b932d111092d0a19362b332bd70965f4dafbdd31543c3ee6125ab2cb7115e165',
    CANDIDATE / 'SEAL.json': 'cd57e95cd9d8255b25a4f870ef24456030b7aa7fec4c7d83b0515e0a998d7c14',
    CANDIDATE / 'REPORT.md': 'b93ab64c00e53fc5e48b30d34f30a3b33afe0938ebd2d5624230b6778385052b',
    CANDIDATE / 'ACCOUNTING.json': '5ee3fd41801d82922763122459c682eb44732514aa76d2c10b961deed91ef90f',
    Path('/private/tmp/branch-leaf-composition102-impl-SqXAof8z/attempt-003/input.rs'): 'e15f151f0211c269531c016cdd6956aba8de0ea5bdd08c472783a064fda10538',
}

def digest(filename):
    hashed = hashlib.sha256()
    with open(filename, 'rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            hashed.update(block)
    return hashed.hexdigest()

def save(filename, value):
    Path(filename).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

def resources():
    size = sum(item.stat().st_size for item in ROOT.rglob('*') if item.is_file())
    free = shutil.disk_usage(ROOT).free
    assert size < 128 * 1024**2, size
    assert free > 16 * 1024**3, free
    assert time.time() < DEADLINE, 'absolute deadline'
    return {'scratch_bytes': size, 'free_bytes': free}

def authenticate(label):
    begun = time.time()
    expected = dict(PINS)
    bindings = json.loads((CONTEXT / 'INPUT-BINDINGS.json').read_text())['current_bindings']
    assert len(bindings) == 320
    assert len({item['path'] for item in bindings}) == 320
    for item in bindings:
        filename = Path(item['path'])
        if filename in expected:
            assert expected[filename] == item['sha256']
        expected[filename] = item['sha256']
    members = {}
    for line in (CANDIDATE / 'MANIFEST.sha256').read_text().splitlines():
        hashed, relative = line.split('  ', 1)
        assert relative not in members
        assert not Path(relative).is_absolute() and '..' not in Path(relative).parts
        members[relative] = hashed
        expected[CANDIDATE / relative] = hashed
    actual_members = {str(item.relative_to(CANDIDATE)) for item in CANDIDATE.rglob('*') if item.is_file()}
    assert len(members) == 115
    assert actual_members == set(members) | {'MANIFEST.sha256', 'SEAL.json'}
    rows = []
    for filename, expected_hash in sorted(expected.items(), key=lambda pair: str(pair[0])):
        try:
            actual_hash = digest(filename)
            rows.append({'path': str(filename), 'expected': expected_hash, 'actual': actual_hash, 'match': actual_hash == expected_hash})
        except Exception as error:
            rows.append({'path': str(filename), 'expected': expected_hash, 'error': repr(error), 'match': False})
    receipt = {'label': label, 'start': begun, 'end': time.time(), 'candidate_payloads': 115, 'candidate_total': 117, 'candidate_exact_membership': True, 'bindings': 320, 'all_match': all(row['match'] for row in rows), 'results': rows, **resources()}
    save(ROOT / (label + '-authentication.json'), receipt)
    assert receipt['all_match'], [row for row in rows if not row['match']]
    return {key: value for key, value in receipt.items() if key != 'results'}

def run(number):
    mappings = {1: ('positive', 'restored-positive.rs', 5), 2: ('wrong-child', 'wrong-child.rs', 6), 3: ('wrong-value', 'wrong-value.rs', 7), 4: ('restored-positive', 'restored-positive.rs', 10)}
    label, source_name, historical_number = mappings[number]
    assert time.time() < STOP
    ledger_file = ROOT / 'ACCOUNTING.json'
    ledger = json.loads(ledger_file.read_text()) if ledger_file.exists() else {'start_epoch': START, 'stop_new_applications_epoch': STOP, 'absolute_deadline_epoch': DEADLINE, 'max_charged_applications': 6, 'total_charged_applications': 0, 'actual_verifier_launches': 0, 'attempts': [], 'old102': {'charged': 9, 'launches': 7, 'prior_research_wall_violation_retained': True}, 'main103': {'charged': 12, 'launches': 10, 'elapsed_seconds': 789.544420003891}}
    assert ledger['total_charged_applications'] < 6
    ledger['total_charged_applications'] += 1
    save(ledger_file, ledger)
    stage = ROOT / ('check-%02d-%s' % (number, label))
    stage.mkdir()
    authenticate('check-%02d-pre' % number)
    frozen = stage / 'input.rs'
    shutil.copyfile(CANDIDATE / source_name, frozen)
    historical_stage = CANDIDATE / ('attempt-%03d' % historical_number)
    original = json.loads((historical_stage / 'invocation.json').read_text())
    assert digest(frozen) == original['source_sha256']
    assert original['argv'][-1] == str(historical_stage / 'input.rs')
    argv = original['argv'][:-1] + [str(frozen)]
    environment = {key: value.replace(str(historical_stage), str(stage)) for key, value in original['environment'].items()}
    assert not any(flag.startswith('--verify-') or flag in {'--compile', '--export'} for flag in argv)
    assert argv[argv.index('--num-threads') + 1] == '1'
    assert len([item for item in argv if item == '--import']) == 7
    assert not any('native-branch-routing-023/artifacts' in item for item in argv)
    for key, value in environment.items():
        if value.startswith(str(stage)):
            Path(value).mkdir(parents=True, exist_ok=True)
    invocation = {'label': label, 'historical_attempt': historical_number, 'argv': argv, 'environment': environment, 'cwd': str(stage), 'source_sha256': digest(frozen), 'timeout_seconds': min(60.0, STOP - time.time()), 'start': time.time(), 'start_epoch': START, 'launch_stop': STOP, 'deadline': DEADLINE, 'environment_recording': 'complete actual subprocess environment; no inherited merge'}
    assert invocation['timeout_seconds'] > 0
    save(stage / 'invocation.json', invocation)
    result = {'label': label, 'charged_application': ledger['total_charged_applications'], 'start': invocation['start'], 'timed_out': False}
    process = None
    try:
        with open(stage / 'stdout.txt', 'wb') as stdout, open(stage / 'stderr.txt', 'wb') as stderr:
            process = subprocess.Popen(argv, env=environment, cwd=stage, stdout=stdout, stderr=stderr, start_new_session=True)
            ledger['actual_verifier_launches'] += 1
            save(ledger_file, ledger)
            try:
                result['returncode'] = process.wait(timeout=invocation['timeout_seconds'])
            except subprocess.TimeoutExpired:
                result['timed_out'] = True
                os.killpg(process.pid, signal.SIGKILL)
                result['returncode'] = process.wait()
    except Exception as error:
        result['spawn_error'] = repr(error)
    result['end'] = time.time()
    result['elapsed_seconds'] = result['end'] - result['start']
    result['source_sha256_post'] = digest(frozen)
    try:
        whole_json = json.loads((stage / 'stdout.txt').read_text())
        save(stage / 'actual-verification.json', whole_json)
        result['summary'] = whole_json['verification-results']
        scope = whole_json.get('verification-scope', whole_json.get('verification_scope', whole_json.get('verus-infer', {}).get('verification_scope')))
        assert scope is not None
        save(stage / 'actual-scope.json', scope)
        result['scope_counts'] = {key: scope.get(key) for key in ['checked_exec_bodies', 'checked_proof_bodies', 'complete_selected_scope_verified']}
    except Exception as error:
        result['json_error'] = repr(error)
    save(stage / 'timing-result.json', result)
    save(stage / 'file-hashes.json', {str(item.relative_to(stage)): digest(item) for item in stage.rglob('*') if item.is_file() and item.name != 'file-hashes.json'})
    ledger['attempts'].append(result)
    save(ledger_file, ledger)
    authenticate('check-%02d-post' % number)
    print(json.dumps(result, indent=2))

if __name__ == '__main__':
    if sys.argv[1] == 'auth':
        print(json.dumps(authenticate(sys.argv[2]), indent=2))
    elif sys.argv[1] == 'run':
        run(int(sys.argv[2]))
