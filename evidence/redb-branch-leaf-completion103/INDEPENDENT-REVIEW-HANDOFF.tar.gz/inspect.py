import difflib
import json
from pathlib import Path
import re
import shutil
import sys

sys.path.insert(0, '/private/tmp/completion103-independent-review-glXjLOpk')
from review import ROOT, CANDIDATE, CONTEXT, digest, save, resources

def span(source, name):
    matched = re.search(r'^pub (?:open spec fn|proof fn|fn) ' + re.escape(name) + r'(?:\b|<)', source, re.M)
    assert matched, name
    closing = source.index('\n}', matched.start()) + 2
    return source[matched.start():closing], source.count('\n', 0, matched.start()) + 1

positive = (CANDIDATE / 'restored-positive.rs').read_text()
old_filename = Path('/private/tmp/branch-leaf-composition102-impl-SqXAof8z/attempt-003/input.rs')
old = old_filename.read_text()
entities = ['meaning_bridge', 'meaning', 'interval', 'supplied', 'union_has', 'matching_child', 'route_then_search']
generic = []
for name in entities:
    current_span, current_line = span(positive, name)
    old_span, old_line = span(old, name)
    assert current_span.encode() == old_span.encode(), name
    generic.append({'entity': name, 'candidate_start_line': current_line, 'checked102_start_line': old_line, 'byte_identical': True, 'bytes': len(current_span.encode())})
save(ROOT / 'GENERIC-PRESERVATION.json', generic)

names = re.findall(r'^pub (?:open spec fn|proof fn|fn) (\w+)', positive, re.M)
preservation = []
for variant in ['wrong-child.rs', 'wrong-value.rs', 'wrong-child-corrected.rs', 'wrong-value-corrected.rs']:
    source = (CANDIDATE / variant).read_text()
    unchanged = [name for name in names if span(positive, name)[0] == span(source, name)[0]]
    assert len(unchanged) == len(names)
    preservation.append({'variant': variant, 'preserved_all_positive_entities': True, 'entity_count': len(names), 'preserved_names': unchanged, 'sha256': digest(CANDIDATE / variant)})
save(ROOT / 'VARIANT-PRESERVATION.json', preservation)

counterparts = []
for name in ['wrong-child', 'wrong-value']:
    bad = (CANDIDATE / (name + '.rs')).read_text().splitlines(keepends=True)
    corrected = (CANDIDATE / (name + '-corrected.rs')).read_text().splitlines(keepends=True)
    changed = [{'line': index + 1, 'bad': before.rstrip(), 'corrected': after.rstrip()} for index, (before, after) in enumerate(zip(bad, corrected)) if before != after]
    assert len(bad) == len(corrected) and len(changed) == 1
    assert 'assert(' in changed[0]['bad'] and 'assert(' in changed[0]['corrected']
    diff = ''.join(difflib.unified_diff(bad, corrected, fromfile=name + '.rs', tofile=name + '-corrected.rs'))
    (ROOT / (name + '-independent.diff')).write_text(diff)
    counterparts.append({'variant': name, 'changes': changed})
save(ROOT / 'COUNTERPARTS.json', counterparts)

historical = []
reference = json.loads((CANDIDATE / 'attempt-005/invocation.json').read_text())
for number in range(1, 11):
    stage = CANDIDATE / ('attempt-%03d' % number)
    retained = ROOT / 'historical' / stage.name
    retained.mkdir(parents=True, exist_ok=True)
    filenames = ['stdout.txt', 'stderr.txt', 'invocation.json', 'timing-result.json', 'actual-verification.json', 'actual-scope.json', 'input.rs']
    for filename in filenames:
        shutil.copyfile(stage / filename, retained / filename)
    invocation = json.loads((stage / 'invocation.json').read_text())
    timing = json.loads((stage / 'timing-result.json').read_text())
    raw_stdout = (stage / 'stdout.txt').read_text()
    stderr = (stage / 'stderr.txt').read_text()
    raw_json = json.loads(raw_stdout)
    assert raw_json == json.loads((stage / 'actual-verification.json').read_text())
    scope = raw_json['verus-infer']['verification_scope']
    assert scope == json.loads((stage / 'actual-scope.json').read_text())
    timing_summary = timing['summary'].get('verification-results', timing['summary'])
    assert raw_json['verification-results'] == timing_summary
    assert invocation['source_sha256'] == digest(stage / 'input.rs')
    assert timing['source_sha256'] == invocation['source_sha256']
    normalized_environment = {key: value.replace(str(stage), 'STAGE') for key, value in invocation['environment'].items()}
    reference_environment = {key: value.replace(str(CANDIDATE / 'attempt-005'), 'STAGE') for key, value in reference['environment'].items()}
    assert normalized_environment == reference_environment
    assert invocation['argv'][:-1] == reference['argv'][:-1]
    assert invocation['argv'][-1] == str(stage / 'input.rs')
    row = {'attempt': number, 'summary': raw_json['verification-results'], 'stderr': stderr, 'stdout_bytes': len(raw_stdout.encode()), 'stdout_keys': list(raw_json), 'func_details_type': type(raw_json['func-details']).__name__, 'verus_infer_keys': list(raw_json['verus-infer']), 'scope_keys': list(scope), 'checked_exec_bodies': scope['checked_exec_bodies'], 'checked_proof_bodies': scope['checked_proof_bodies'], 'complete_selected_scope_verified': scope['complete_selected_scope_verified'], 'same_flags_and_normalized_full_environment': True, 'environment_keys': sorted(normalized_environment), 'timing': timing, 'invocation_start': invocation['start'], 'timeout_seconds': invocation['timeout_seconds']}
    historical.append(row)
save(ROOT / 'HISTORICAL-AUDIT.json', historical)

fresh = []
for number, name in [(1, 'positive'), (2, 'wrong-child'), (3, 'wrong-value'), (4, 'restored-positive')]:
    stage = ROOT / ('check-%02d-%s' % (number, name))
    if not (stage / 'timing-result.json').exists():
        continue
    timing = json.loads((stage / 'timing-result.json').read_text())
    stderr = (stage / 'stderr.txt').read_text()
    summary = timing['summary']
    expected_errors = 1 if number in [2, 3] else 0
    assert summary['verified'] == 38 and summary['errors'] == expected_errors
    assert summary['is-verifying-entire-crate']
    assert not summary['encountered-vir-error']
    assert not timing['timed_out'] and 'spawn_error' not in timing
    if expected_errors:
        intended_line = 1063 if number == 2 else 1064
        assert stderr.count('error: assertion failed') == 1
        assert 'input.rs:%d:12' % intended_line in stderr
        assert 'error: aborting due to 1 previous error' in stderr
        assert not re.search(r'precondition|panic|timed out|resource limit|out of bounds|failed to import', stderr, re.I)
    else:
        assert stderr == ''
    fresh.append({'number': number, 'label': name, 'only_expected_result': True, 'stderr': stderr, 'summary': summary})
save(ROOT / 'FRESH-RESULT-AUDIT.json', fresh)

for item in historical:
    print('ATTEMPT', item['attempt'], 'SUMMARY', json.dumps(item['summary']), 'SECONDS', item['timing']['elapsed_seconds'])
    print(item['stderr'])
print('GENERIC', json.dumps(generic))
print('COUNTERPARTS', json.dumps(counterparts))
print('RESOURCE', json.dumps(resources()))
