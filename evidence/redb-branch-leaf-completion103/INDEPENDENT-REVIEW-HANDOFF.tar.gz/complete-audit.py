import hashlib
import json
from pathlib import Path
import re
import sys
import tarfile
import time

sys.path.insert(0, '/private/tmp/completion103-independent-review-glXjLOpk')
from review import ROOT, CANDIDATE, CONTEXT, START, STOP, DEADLINE, digest, save, resources

positive = (CANDIDATE / 'restored-positive.rs').read_text()
queries = [1, 256, 257, 65536, 65537, 4294967295, 0, 2]
parameters = 'first: u8, second: u8, third: u8, fourth: u8, fifth: u8, sixth: u8'
values = ['first', 'second', 'third', 'fourth', 'fifth', 'sixth']
fixtures = []
for mode in ['fixed', 'variable']:
    for index, numeric in enumerate(queries):
        name = mode + '_query_' + str(index)
        start = positive.index('pub fn ' + name + '(')
        end = positive.index('\n}', start) + 2
        body = positive[start:end]
        assert body.startswith('pub fn ' + name + '(' + parameters + ') {')
        assert 'requires' not in body
        query_match = re.search(r'let query: \[u8; 4\] = \[([^\]]+)\];', body)
        encoded = bytes(int(item.strip()) for item in query_match.group(1).split(','))
        assert int.from_bytes(encoded, 'little') == numeric
        assert 'let result = route_then_search(&bytes, &leaves, kw, vw, &query);' in body
        assert 'fixture_lawful(bytes@, leaves@, ' + ('false' if mode == 'fixed' else 'true') + ', first, second, third, fourth, fifth, sixth);' in body
        if index < 6:
            assert 'assert(result.0 == %d);' % (index // 2) in body
            assert 'assert(result.2.is_some());' in body
            assert 'assert(result.2.unwrap().0@ == query@);' in body
            assert 'assert(result.2.unwrap().1@ == seq![' + values[index] + ']);' in body
        else:
            assert 'assert(result.2.is_none());' in body
        fixtures.append({'function': name, 'line': positive.count('\n', 0, start) + 1, 'mode': mode, 'six_independent_unrestricted_u8_arguments': True, 'query_le_bytes': list(encoded), 'query_numeric': numeric, 'associated_value_argument': values[index] if index < 6 else None, 'expected_child': index // 2 if index < 6 else None, 'present': index < 6})
save(ROOT / 'FIXTURE-AUDIT.json', fixtures)

forbidden = re.compile(r'\b(?:assume|admit|axiom|trusted)\b|external_body|external_fn_specification|verify\(false\)')
trust = []
for name in ['restored-positive.rs', 'wrong-child.rs', 'wrong-value.rs', 'wrong-child-corrected.rs', 'wrong-value-corrected.rs']:
    source = (CANDIDATE / name).read_text()
    findings = [{'line': source.count('\n', 0, match.start()) + 1, 'match': match.group()} for match in forbidden.finditer(source)]
    assert not findings
    trust.append({'source': name, 'sha256': digest(CANDIDATE / name), 'new_trust_markers': findings, 'scope': 'lexical screen corroborating contract/body review; not a global TCB audit'})
save(ROOT / 'TRUST-SCREEN.json', trust)

bindings = json.loads((CONTEXT / 'INPUT-BINDINGS.json').read_text())['current_bindings']
bound = {item['path']: item['sha256'] for item in bindings}
reference = json.loads((CANDIDATE / 'attempt-005/invocation.json').read_text())
pairs = {}
for flag in ['--extern', '--import']:
    for index, item in enumerate(reference['argv']):
        if item == flag:
            name, filename = reference['argv'][index + 1].split('=', 1)
            assert filename in bound
            assert digest(filename) == bound[filename]
            pairs.setdefault(name, {})[flag] = {'path': filename, 'sha256': bound[filename]}
assert len(pairs) == 7 and all(len(pair) == 2 for pair in pairs.values())
save(ROOT / 'IMPORT-PAIRS.json', {'pairs': pairs, 'runtime': reference['argv'][0], 'runtime_sha256': digest(reference['argv'][0]), 'sysroot': reference['argv'][2], 'sysroot_scope': 'selected bound artifacts only, not a fresh whole-sysroot audit', 'one_verifier_worker': True, 'one_solver_worker': True, 'same_historical_runtime_flags_and_complete_environment_except_scratch_redirects': True})

archive_rows = []
with tarfile.open(CONTEXT / 'CANDIDATE-HANDOFF.tar.gz', 'r:gz') as archive:
    for member in archive.getmembers():
        assert member.isfile()
        relative = str(Path(member.name))
        assert not Path(relative).is_absolute() and '..' not in Path(relative).parts
        contents = archive.extractfile(member).read()
        actual = hashlib.sha256(contents).hexdigest()
        archive_rows.append({'member': relative, 'sha256': actual, 'candidate_sha256': digest(CANDIDATE / relative), 'match': actual == digest(CANDIDATE / relative)})
candidate_names = {str(item.relative_to(CANDIDATE)) for item in CANDIDATE.rglob('*') if item.is_file()}
assert len(archive_rows) == 117
assert {item['member'] for item in archive_rows} == candidate_names
assert all(item['match'] for item in archive_rows)
save(ROOT / 'ARCHIVE-AUDIT.json', {'archive_sha256': digest(CONTEXT / 'CANDIDATE-HANDOFF.tar.gz'), 'members': archive_rows, 'total': 117, 'exact_membership': True, 'all_byte_exact': True})

scope_rows = []
for number, label in [(1, 'positive'), (2, 'wrong-child'), (3, 'wrong-value'), (4, 'restored-positive')]:
    stage = ROOT / ('check-%02d-%s' % (number, label))
    invocation = json.loads((stage / 'invocation.json').read_text())
    historical = CANDIDATE / ('attempt-%03d' % invocation['historical_attempt'])
    original = json.loads((historical / 'invocation.json').read_text())
    assert invocation['argv'][:-1] == original['argv'][:-1]
    assert {key: value.replace(str(stage), 'STAGE') for key, value in invocation['environment'].items()} == {key: value.replace(str(historical), 'STAGE') for key, value in original['environment'].items()}
    scope = json.loads((stage / 'actual-scope.json').read_text())
    assert all(item['function'].startswith('branch_leaf_client::') for item in scope['native_functions'])
    assert all(item['selected'] for item in scope['native_functions'])
    assert all(not item['automatically_derived'] for item in scope['native_functions'])
    source_text = (stage / 'input.rs').read_text()
    source_names = re.findall(r'^pub (?:open spec fn|proof fn|fn) (\w+)', source_text, re.M)
    assert set(source_names) == {item['rust_function'] for item in scope['native_functions']}
    scope_rows.append({'check': number, 'label': label, 'all_source_named_functions_selected': True, 'no_generated_or_imported_native_bodies': True, 'named_functions': len(source_names), 'scope': scope})
save(ROOT / 'SCOPE-AUDIT.json', scope_rows)

failures = [
    {'event': 'read-only historical metadata listing typo', 'conservatively_charged': 1, 'verifier_launched': False, 'raw_stderr_from_tool_transcript': "SyntaxError: unmatched ')'\n", 'command_kind': '/usr/bin/python3 -c inline source-list and historical-result listing', 'cause': 'extra closing parenthesis in reviewer one-line metadata command', 'complete_inherited_shell_environment_recorded': False, 'proof_or_assumption_change': False},
    {'event': 'reviewer metadata-envelope assertion correction', 'conservatively_charged': 1, 'verifier_launched': False, 'command': '/usr/bin/python3 /private/tmp/completion103-independent-review-glXjLOpk/inspect.py', 'raw_stderr_from_tool_transcript': 'Traceback (most recent call last):\n  File "/private/tmp/completion103-independent-review-glXjLOpk/inspect.py", line 67, in <module>\n    assert raw_json[\'verification-results\'] == timing[\'summary\']\nAssertionError\n', 'cause': 'historical attempt001 timing summary contains the whole JSON envelope, unlike later normalized counter summaries', 'correction': 'read verification-results inside timing summary when present; do not alter historical evidence', 'complete_inherited_shell_environment_recorded': False, 'proof_or_assumption_change': False}
]
save(ROOT / 'REVIEW-AUDIT-FAILURES.json', {'events': failures, 'additional_charges': 2, 'verifier_invocation_environment_gaps': 0, 'provenance': 'diagnostics copied from tool transcript; no missing historical or reviewer shell environment invented', 'initial_read_only_discovery_diagnostics': ['initial zsh path loop shadowed PATH; ls unavailable for that shell', '/usr/bin/date does not exist on this host; no verifier setup involved']})
ledger = json.loads((ROOT / 'ACCOUNTING.json').read_text())
ledger['verifier_application_charges'] = 4
ledger['additional_conservatively_charged_metadata_audit_failures'] = 2
ledger['total_charged_applications'] = 6
ledger['no_more_applications_permitted'] = True
ledger['last_verifier_end_epoch'] = max(item['end'] for item in ledger['attempts'])
ledger['verification_elapsed_seconds_sum'] = sum(item['elapsed_seconds'] for item in ledger['attempts'])
ledger['audit_completion_epoch'] = time.time()
ledger['audit_elapsed_seconds'] = time.time() - START
ledger['resource_snapshot'] = resources()
assert ledger['actual_verifier_launches'] == 4
save(ROOT / 'ACCOUNTING.json', ledger)
print(json.dumps({'fixture_callers': len(fixtures), 'archive_exact_files': len(archive_rows), 'import_pairs': len(pairs), 'charges': 6, 'launches': 4, 'elapsed_seconds': time.time() - START, 'resources': resources()}, indent=2))
