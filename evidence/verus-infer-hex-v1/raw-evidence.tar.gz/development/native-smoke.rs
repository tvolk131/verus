use vstd::prelude::*;
#[verus_infer] fn lift(x:Option<u8>, e:u16)->Result<u8,u16> {x.ok_or(e)}
