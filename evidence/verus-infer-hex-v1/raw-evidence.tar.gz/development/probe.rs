use vstd::prelude::*;
#[verus_verify]
#[derive(Copy, Clone, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(u8)]
pub enum Char {
    /// `'0'`
    Zero = b'0',
    /// `'1'`
    One = b'1',
    /// `'2'`
    Two = b'2',
    /// `'3'`
    Three = b'3',
    /// `'4'`
    Four = b'4',
    /// `'5'`
    Five = b'5',
    /// `'6'`
    Six = b'6',
    /// `'7'`
    Seven = b'7',
    /// `'8'`
    Eight = b'8',
    /// `'9'`
    Nine = b'9',
    /// `'a'`
    LowerA = b'a',
    /// `'b'`
    LowerB = b'b',
    /// `'c'`
    LowerC = b'c',
    /// `'d'`
    LowerD = b'd',
    /// `'e'`
    LowerE = b'e',
    /// `'f'`
    LowerF = b'f',
    /// `'A'`
    UpperA = b'A',
    /// `'B'`
    UpperB = b'B',
    /// `'C'`
    UpperC = b'C',
    /// `'D'`
    UpperD = b'D',
    /// `'E'`
    UpperE = b'E',
    /// `'F'`
    UpperF = b'F',
}

#[verus_verify]
impl Char {
#[verus_verify]
    #[verus_spec(r => ensures r == digit(b))]
    pub(crate) fn decode_nibble(b: u8) -> Option<u8> {
        // Each valid hex byte maps to its nibble value; 0xFF marks invalid entries.
        // Char variant discriminants equal their ASCII byte values, so they index directly.
        #[verus_verify]
        #[verus_spec(ensures TABLE@ == Seq::new(256, |i: int| table_value(i)))]
        static TABLE: [u8; 256] = {
            let mut t = [0xFF_u8; 256];
            // Each Char variant is a u8. So all `as usize` casts are safe.
            t[Char::Zero  as usize] = 0;  t[Char::One   as usize] = 1;
            t[Char::Two   as usize] = 2;  t[Char::Three as usize] = 3;
            t[Char::Four  as usize] = 4;  t[Char::Five  as usize] = 5;
            t[Char::Six   as usize] = 6;  t[Char::Seven as usize] = 7;
            t[Char::Eight as usize] = 8;  t[Char::Nine  as usize] = 9;
            t[Char::LowerA as usize] = 10; t[Char::UpperA as usize] = 10;
            t[Char::LowerB as usize] = 11; t[Char::UpperB as usize] = 11;
            t[Char::LowerC as usize] = 12; t[Char::UpperC as usize] = 12;
            t[Char::LowerD as usize] = 13; t[Char::UpperD as usize] = 13;
            t[Char::LowerE as usize] = 14; t[Char::UpperE as usize] = 14;
            t[Char::LowerF as usize] = 15; t[Char::UpperF as usize] = 15;
            t
        };
        let n = TABLE[usize::from(b)];
        if n == 0xFF {
            None
        } else {
            Some(n)
        }
    }

}

verus! {
pub open spec fn table_value(i: int) -> u8 {
 if 48 <= i <= 57 {(i - 48) as u8}
 else if 65 <= i <= 70 {(i - 65 + 10) as u8}
 else if 97 <= i <= 102 {(i - 97 + 10) as u8}
 else {255}
}
pub open spec fn digit(b: u8) -> Option<u8> {
 if 48 <= b <= 57 {Some((b - 48) as u8)}
 else if 65 <= b <= 70 {Some((b - 65 + 10) as u8)}
 else if 97 <= b <= 102 {Some((b - 97 + 10) as u8)}
 else {None}
}
}

#[verus_infer]
fn hex_chars_to_byte(hi: u8, lo: u8) -> Result<u8, (u8, bool)> {
    let hih = Char::decode_nibble(hi).ok_or((hi, true))?;
    let loh = Char::decode_nibble(lo).ok_or((lo, false))?;
    Ok((hih << 4) | loh)
}
