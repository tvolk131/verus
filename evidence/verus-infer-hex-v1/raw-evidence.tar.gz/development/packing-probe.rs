use vstd::prelude::*;
verus! {
proof fn lemma() {
 assert(forall|h:u8,l:u8| h<16 && l<16 ==> ((h<<4)|l) as int == 16*h+l) by(bit_vector);
}
fn test(h:u8,l:u8)->(r:u8) requires h<16,l<16, ensures r as int==16*h+l, {
 proof { assert(forall|h:u8,l:u8| h<16 && l<16 ==> ((h<<4)|l) as int == 16*h+l) by(bit_vector); }
 (h<<4)|l
}
}
