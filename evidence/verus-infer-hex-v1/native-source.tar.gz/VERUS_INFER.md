# Verus Infer: forward byte-pair milestone

Baseline: `129db6ac54d25b08e0b927c225aefe4a8df05a57` (version 1.3.0).
This branch retains the native algorithms. Verification selects the actual
`Char::decode_nibble`, its original local 256-byte static initializer, and
`iter::hex_chars_to_byte`. `src/decoding_spec.rs` supplies independent ASCII-range
requirements and the forward equation `16 * high + low` for all byte pairs.

The table and nibble semantics are authored **requirements checked against their
bodies**, not inferred or assumed contracts. The pair implementation contract is
inferred and must pass body soundness, maximality and exactness. The ordinary
pair semantic goal additionally needs `--infer-goals` for a checked arithmetic
packing lemma. No authored assertions, loop invariants, assumed specifications,
external bodies, or implementation exclusions were added.

Use the matching local Verus Infer engine (policy 51 / candidate cache 57), built
with proof toolchain Rust 1.99.1. From its repository root:

```sh
python3 source/tools/check_hex_adoption.py \
  --native-root /Users/tommyvolk/Documents/GitHub/hex-conservative \
  --output /private/tmp/hex-acceptance-new
```

The default controller temporarily mutates this checkout, restores each file in
a `finally` block, checks six semantic failures and publication controls, then
runs fresh restored proofs and ordinary native tests. Use `--positive-only` to
skip mutations and negative controls. The output directory must be new. Cargo
uses the ignored `Cargo.lock` copied from upstream's `Cargo-recent.lock`; no
tracked lockfile or toolchain selection is changed. Verification invokes Verus
directly on this crate's actual `src/lib.rs` with `std` and `alloc` enabled; it
does not use a replacement proof crate or a source extractor.

The selected endpoint accepts two arbitrary `u8` inputs, including non-ASCII
bytes, returns one exact byte on success and preserves the offending input byte
and high/low flag on error, with the high byte winning when both are invalid.
This does not certify the complete public string API or iterator.

The inspected next boundary includes `ChunksExact`, iterator state/byte
positions, saturating arithmetic, error conversions, and the original unsafe
pointer-writing drains. They remain unverified in this milestone. Native tests
exercise public API lengths, mixed case and UTF-8 byte errors, but tests are not
proofs of those endpoints. Public APIs count UTF-8 **bytes**, not Unicode scalar
values. A mathematical fixed-array length theorem must account for the native
`2 * N` overflow domain (`N <= usize::MAX / 2` for checked arithmetic). Length
rejection precedes character rejection. No ASCII-only restriction is assumed.

The engine's `evidence/verus-infer-hex-v1` contains the frozen charter, source
inventory, raw replay logs, mutation/publication outcomes and artifact hashes.
Aleph v3/v4 fixtures, archives and fixed engines were left unchanged. This is a
finite independent adoption result, not blanket certification of Rust code.
