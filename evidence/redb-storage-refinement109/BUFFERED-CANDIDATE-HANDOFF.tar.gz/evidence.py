import difflib
import json
from pathlib import Path
import re
import sys

import harness

ROOT = harness.ROOT
NATIVE = harness.NATIVE
FINAL_SHA = '29485224c99ba2f994012ff53b2ddc98c9cab79daaf7b3fc2a855b952d2fdc4f'

def anchors():
    specifications = [
        ('nested-write-drain', 'src/tree_store/page_store/cached_file.rs', 490, 525,
         ['for stripe in &self.write_buffer', 'stripe.lock().unwrap()', 'write_buffer.cache.iter()',
          'self.file.write(*offset, buffer.as_ref().unwrap())?', 'write_buffer.cache.iter_mut()',
          'buffer.take().unwrap()', 'write_buffer.clear()', 'self.committed_pages_buffered', 'Ok(())']),
        ('flush-barrier', 'src/tree_store/page_store/cached_file.rs', 596, 600,
         ['self.flush_write_buffer()?', 'self.file.sync_data()']),
        ('whole-header-single-process', 'src/tree_store/page_store/page_manager.rs', 1617, 1629,
         ['is_multi_process_writable()', 'return self.storage.write_direct(0, &header.to_bytes(true))',
          '.write(0, DB_HEADER_SIZE, true)?', '.mem_mut()', '.copy_from_slice(&header.to_bytes(true))']),
        ('write-preflight-and-latch', 'src/tree_store/page_store/cached_file.rs', 251, 258,
         ['self.check_failure()?', 'self.file.write(offset, data)', 'result.is_err()',
          'self.io_failed.store(true, Ordering::Release)', 'result.map_err(StorageError::from)']),
        ('sync-preflight-and-latch', 'src/tree_store/page_store/cached_file.rs', 242, 249,
         ['self.check_failure()?', 'self.file.sync_data()', 'result.is_err()',
          'self.io_failed.store(true, Ordering::Release)', 'result.map_err(StorageError::from)']),
        ('unix-write', 'src/tree_store/page_store/file_backend/optimized.rs', 372, 379,
         ['fn sync_data', 'self.file.sync_data()', '#[cfg(unix)]', 'fn write', 'self.file.write_all_at(data, offset)']),
        ('fallback-write', 'src/tree_store/page_store/file_backend/fallback.rs', 112, 120,
         ['fn sync_data', 'self.file.lock().unwrap().sync_data()', 'fn write',
          'self.file.lock().unwrap()', 'file.seek(SeekFrom::Start(offset))?', 'file.write_all(data)']),
        ('cache-key-removal-not-admission', 'src/tree_store/page_store/cached_file.rs', 881, 910,
         ['fn write(', 'stripe.lock().unwrap()', 'let data = if let Some(removed) = lock.take_value(offset)']),
        ('lru-insert-is-not-replacement', 'src/tree_store/page_store/cached_file.rs', 64, 77,
         ['struct LRUWriteCache', 'LRUCache<Option<Arc<[u8]>>>', 'fn insert',
          'assert!(self.cache.insert(key, Some(value)).is_none())']),
    ]
    rows = []
    for name, relative, first, last, tokens in specifications:
        path = NATIVE / relative
        body = ''.join(path.read_text().splitlines(keepends=True)[first - 1:last])
        positions = []
        cursor = 0
        for token in tokens:
            found = body.find(token, cursor)
            if found < 0:
                raise AssertionError((name, token))
            positions.append({'token': token, 'byte_offset': found,
                              'line': first + body[:found].count('\n')})
            cursor = found + len(token)
        rows.append({'name': name, 'path': str(path), 'sha256': harness.digest(path),
                     'first_line': first, 'last_line': last, 'ordered_tokens': positions,
                     'status': 'source-token observation only; not an AST/body correspondence proof'})
    harness.save(ROOT / 'source-anchors.json', {'guards': rows, 'passed': len(rows),
                 'native_execution': False, 'native_producer': None})
    print('Source token guards:', len(rows), 'passed')

def results():
    assert harness.digest(ROOT / 'buffered_flush109.rs') == FINAL_SHA
    attempts = sorted(path for path in ROOT.glob('attempt-*') if path.is_dir())
    rows = []
    for attempt in attempts:
        invocation = json.loads((attempt / 'invocation.json').read_text())
        receipt = json.loads((attempt / 'receipt.json').read_text())
        output = json.loads((attempt / 'stdout.txt').read_text())
        result = output['verification-results']
        row = {'attempt': attempt.name, 'label': invocation['label'],
               'direct_child_status': receipt['direct_child_status'],
               'timeout': receipt['timeout'], 'launch_error': receipt['launch_error'],
               'seconds': receipt['elapsed_seconds'], 'source_sha256': invocation['source_sha256'],
               'verification': result,
               'export': [{'path': str(path), 'sha256': harness.digest(path), 'bytes': path.stat().st_size}
                          for path in attempt.glob('*.vir')]}
        if attempt.name == 'attempt-011':
            row['label_correction'] = 'Repeated eager-drain mutant after failed apply_patch; not the sync mutant'
        rows.append(row)
    final = rows[-1]
    assert final['direct_child_status'] == 0
    assert final['verification']['success']
    assert final['verification']['is-verifying-entire-crate']
    assert final['verification']['verified'] == 31
    assert final['source_sha256'] == FINAL_SHA
    assert (ROOT / 'attempt-008/input.rs').read_bytes() == (ROOT / 'attempt-013/input.rs').read_bytes()
    assert (ROOT / 'buffered_flush109.rs').read_bytes() == (ROOT / 'attempt-013/input.rs').read_bytes()
    harness.save(ROOT / 'restoration.json', {'positive': 'attempt-008', 'restored': 'attempt-013',
                 'byte_identical': True, 'sha256': FINAL_SHA, 'direct_status': 0,
                 'verification': final['verification']})
    text = (ROOT / 'buffered_flush109.rs').read_text()
    forbidden = re.findall(r'\b(?:assume|admit|axiom|external_body)\b', text)
    assert not forbidden
    scope = [{'name': match.group(1), 'line': text[:match.start()].count('\n') + 1,
              'kind': match.group(0).split()[1]}
             for match in re.finditer(r'pub (?:proof|open spec) fn ([A-Za-z0-9_]+)', text)]
    harness.save(ROOT / 'scope.json', {'authored_source_sha256': FINAL_SHA,
                 'functions': scope, 'forbidden_tokens': forbidden,
                 'native_functions_checked': [], 'manual_imports': [], 'manual_externs': [],
                 'runtime_imports': ['matching existing vstd/builtin artifacts automatically loaded by verus'],
                 'exports_are_candidate_only': True})
    patch = ''.join(difflib.unified_diff([], text.splitlines(keepends=True),
                                       fromfile='/dev/null', tofile='b/buffered_flush109.rs'))
    (ROOT / 'candidate.patch').write_text(patch)
    accounting = {'verifier_applications': len(rows), 'failed_mutation_setup': 1,
                  'conservative_total_charges': len(rows) + 1, 'allowed': 16,
                  'numbering_gap': 'No attempt-002 exists: the early harness counted its preexecution JSON as a directory. No launch is missing.',
                  'worker_count': 1, 'per_application_cap_seconds': 90,
                  'application_seconds': sum(row['seconds'] for row in rows),
                  'initial_discovery_command_failures': ['rg scoped instruction probe returned 1 for no matches; not a verifier launch'],
                  'resources': harness.resources()}
    assert accounting['conservative_total_charges'] <= 16
    harness.save(ROOT / 'results.json', {'attempts': rows, 'accounting': accounting,
                 'final_source_sha256': FINAL_SHA, 'source_path_preservation': 'FAILED_INHERITED',
                 'native_git': 'UNAVAILABLE_INHERITED', 'compiler_source_correspondence': 'UNESTABLISHED',
                 'all_eighteen_cells': 'OPEN', 'acceptance': False, 'integration': False})
    print(json.dumps({'accounting': accounting, 'final': final}, indent=2))

def seal():
    files = []
    for path in sorted(ROOT.rglob('*')):
        if path.is_file() and path.name not in ['MANIFEST.json', 'HANDOFF.json', 'SEAL.sha256']:
            files.append({'path': str(path.relative_to(ROOT)), 'bytes': path.stat().st_size,
                          'sha256': harness.digest(path)})
    harness.save(ROOT / 'MANIFEST.json', {'schema': 'redb-storage109-lane1-sealed-files-v1',
                 'root': str(ROOT), 'resources': harness.resources(), 'files': files,
                 'excludes_self_and_seal': True, 'acceptance': False, 'all_eighteen_cells': 'OPEN'})
    handoff = {'root': str(ROOT), 'report': 'REPORT.md', 'source': 'buffered_flush109.rs',
               'source_sha256': FINAL_SHA, 'patch': 'candidate.patch',
               'patch_sha256': harness.digest(ROOT / 'candidate.patch'),
               'manifest': 'MANIFEST.json', 'manifest_sha256': harness.digest(ROOT / 'MANIFEST.json'),
               'results_sha256': harness.digest(ROOT / 'results.json'),
               'report_sha256': harness.digest(ROOT / 'REPORT.md'),
               'final_verified_obligations': 31, 'all_eighteen_cells': 'OPEN',
               'acceptance': False, 'integration': False}
    harness.save(ROOT / 'HANDOFF.json', handoff)
    sealed = [ROOT / 'MANIFEST.json', ROOT / 'HANDOFF.json', ROOT / 'REPORT.md',
              ROOT / 'buffered_flush109.rs', ROOT / 'candidate.patch']
    (ROOT / 'SEAL.sha256').write_text(''.join(harness.digest(path) + '  ' + path.name + '\n' for path in sealed))
    print((ROOT / 'SEAL.sha256').read_text())

if __name__ == '__main__':
    if sys.argv[1] == 'prepare':
        anchors()
        results()
    elif sys.argv[1] == 'seal':
        seal()
