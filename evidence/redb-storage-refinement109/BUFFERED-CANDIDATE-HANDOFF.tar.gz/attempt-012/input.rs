use vstd::prelude::*;

verus! {

pub struct Image {
    pub visible: Seq<u8>,
    pub durable: Seq<u8>,
    pub permitted: Map<int, Set<u8>>,
}

pub struct Entry {
    pub offset: nat,
    pub bytes: Seq<u8>,
}

pub struct Decision {
    pub ok: bool,
    pub changed: Set<int>,
    pub persisted: Set<int>,
}

pub struct Event {
    pub kind: nat,
    pub stripe: nat,
    pub index: nat,
    pub ok: bool,
}

pub struct Chunk {
    pub image: Image,
    pub events: Seq<Event>,
    pub ok: bool,
    pub successful: nat,
}

pub struct Run {
    pub image: Image,
    pub pending: Seq<Seq<Entry>>,
    pub events: Seq<Event>,
    pub ok: bool,
    pub completed: nat,
}

pub struct Buffered {
    pub backend: Image,
    pub slots: Map<nat, Seq<u8>>,
}

pub open spec fn buffer_application(before: Buffered, offset: nat, bytes: Seq<u8>) -> Buffered {
    Buffered { backend: before.backend, slots: before.slots.insert(offset, bytes) }
}

pub open spec fn buffer_repeated(before: Buffered, offset: nat, values: Seq<Seq<u8>>) -> Buffered
    decreases values.len(),
{
    if values.len() == 0 { before } else {
        buffer_repeated(buffer_application(before, offset, values[0]), offset,
            values.subrange(1, values.len() as int))
    }
}

pub open spec fn valid(image: Image) -> bool {
    &&& image.visible.len() == image.durable.len()
    &&& forall|address: int| #[trigger] image.permitted.dom().contains(address)
        <==> 0 <= address < image.visible.len()
    &&& forall|address: int| 0 <= address < image.visible.len() ==>
        #[trigger] image.permitted[address].contains(image.visible[address])
        && image.permitted[address].contains(image.durable[address])
}

pub open spec fn entry_valid(entry: Entry, length: nat) -> bool {
    entry.offset + entry.bytes.len() <= length
}

pub open spec fn entries_valid(entries: Seq<Entry>, length: nat) -> bool {
    forall|position: int| 0 <= position < entries.len() ==>
        entry_valid(#[trigger] entries[position], length)
}

pub open spec fn pending_valid(pending: Seq<Seq<Entry>>, length: nat) -> bool {
    forall|stripe: int| 0 <= stripe < pending.len() ==>
        entries_valid(#[trigger] pending[stripe], length)
}

pub open spec fn clean(bytes: Seq<u8>) -> Image {
    Image { visible: bytes, durable: bytes,
        permitted: Map::new(Set::range(0, bytes.len() as int),
            |address: int| Set::empty().insert(bytes[address])) }
}

pub open spec fn overwrite(visible: Seq<u8>, entry: Entry) -> Seq<u8> {
    Seq::new(visible.len(), |address: int|
        if entry.offset <= address < entry.offset + entry.bytes.len() {
            entry.bytes[address - entry.offset]
        } else { visible[address] })
}

pub open spec fn write_visible(before: Image, entry: Entry, decision: Decision) -> Seq<u8> {
    Seq::new(before.visible.len(), |address: int|
        if entry.offset <= address < entry.offset + entry.bytes.len()
            && (decision.ok || decision.changed.contains(address)) {
            entry.bytes[address - entry.offset]
        } else { before.visible[address] })
}

pub open spec fn backend_write(before: Image, entry: Entry, decision: Decision) -> Image {
    let visible = write_visible(before, entry, decision);
    Image {
        visible,
        durable: Seq::new(before.durable.len(), |address: int|
            if decision.persisted.contains(address) { visible[address] }
            else { before.durable[address] }),
        permitted: Map::new(before.permitted.dom(), |address: int|
            before.permitted[address].insert(visible[address])),
    }
}

pub open spec fn backend_sync(before: Image, ok: bool, persisted: Set<int>) -> Image {
    if ok { before } else {
        Image { visible: before.visible,
            durable: Seq::new(before.durable.len(), |address: int|
                if persisted.contains(address) { before.visible[address] }
                else { before.durable[address] }),
            permitted: before.permitted }
    }
}

pub open spec fn event(kind: nat, stripe: nat, index: nat, ok: bool) -> Event {
    Event { kind, stripe, index, ok }
}

pub open spec fn no_sync(events: Seq<Event>) -> bool {
    forall|position: int| 0 <= position < events.len() ==>
        (#[trigger] events[position]).kind != 3
}

pub open spec fn model_entries(before: Image, entries: Seq<Entry>, stripe: nat,
    index: nat, decisions: spec_fn(nat, nat) -> Decision) -> Chunk
    decreases entries.len(),
{
    if entries.len() == 0 {
        Chunk { image: before, events: Seq::empty(), ok: true, successful: 0 }
    } else {
        let decision = decisions(stripe, index);
        let written = backend_write(before, entries[0], decision);
        let attempt = event(0, stripe, index, decision.ok);
        if !decision.ok {
            Chunk { image: written, events: seq![attempt], ok: false, successful: 0 }
        } else {
            let tail = model_entries(written, entries.subrange(1, entries.len() as int),
                stripe, index + 1, decisions);
            Chunk { image: tail.image, events: seq![attempt] + tail.events,
                ok: tail.ok, successful: tail.successful + 1 }
        }
    }
}

pub open spec fn visible_entries(before: Seq<u8>, entries: Seq<Entry>) -> Seq<u8>
    decreases entries.len(),
{
    if entries.len() == 0 { before } else {
        visible_entries(overwrite(before, entries[0]), entries.subrange(1, entries.len() as int))
    }
}

pub open spec fn model_stripes(before: Image, pending: Seq<Seq<Entry>>, stripe: nat,
    decisions: spec_fn(nat, nat) -> Decision) -> Run
    decreases pending.len(),
{
    if pending.len() == 0 {
        Run { image: before, pending: Seq::empty(), events: seq![event(2, stripe, 0, true)],
            ok: true, completed: 0 }
    } else {
        let head = model_entries(before, pending[0], stripe, 0, decisions);
        if !head.ok {
            Run { image: head.image, pending, events: head.events, ok: false, completed: 0 }
        } else {
            let tail = model_stripes(head.image, pending.subrange(1, pending.len() as int),
                stripe + 1, decisions);
            Run { image: tail.image, pending: seq![Seq::empty()] + tail.pending,
                events: head.events + seq![event(1, stripe, 0, true)] + tail.events,
                ok: tail.ok, completed: tail.completed + 1 }
        }
    }
}

pub open spec fn visible_stripes(before: Seq<u8>, pending: Seq<Seq<Entry>>) -> Seq<u8>
    decreases pending.len(),
{
    if pending.len() == 0 { before } else {
        visible_stripes(visible_entries(before, pending[0]), pending.subrange(1, pending.len() as int))
    }
}

pub open spec fn model_flush(before: Image, pending: Seq<Seq<Entry>>,
    decisions: spec_fn(nat, nat) -> Decision, sync_ok: bool, persisted: Set<int>) -> Run {
    let drained = model_stripes(before, pending, 0, decisions);
    if !drained.ok { drained } else {
        Run { image: backend_sync(drained.image, sync_ok, persisted), pending: drained.pending,
            events: drained.events + seq![event(3, 0, 0, sync_ok)], ok: sync_ok,
            completed: drained.completed }
    }
}

pub proof fn clean_valid(bytes: Seq<u8>)
    ensures valid(clean(bytes)),
{
    vstd::set_lib::lemma_int_range(0, bytes.len() as int);
}

pub proof fn write_valid(before: Image, entry: Entry, decision: Decision)
    requires valid(before), entry_valid(entry, before.visible.len()),
    ensures valid(backend_write(before, entry, decision)),
        backend_write(before, entry, decision).visible.len() == before.visible.len(),
        decision.ok ==> backend_write(before, entry, decision).visible == overwrite(before.visible, entry),
        forall|address: int| 0 <= address < before.visible.len()
            && !(entry.offset <= address < entry.offset + entry.bytes.len()) ==>
            backend_write(before, entry, decision).visible[address] == before.visible[address],
{
    let after = backend_write(before, entry, decision);
    assert forall|address: int| 0 <= address < after.visible.len() implies
        #[trigger] after.permitted[address].contains(after.visible[address])
        && after.permitted[address].contains(after.durable[address]) by {
        assert(before.permitted[address].contains(before.visible[address]));
        assert(before.permitted[address].contains(before.durable[address]));
    }
    if decision.ok {
        assert(after.visible =~= overwrite(before.visible, entry));
    }
}

pub proof fn sync_valid(before: Image, ok: bool, persisted: Set<int>)
    requires valid(before),
    ensures valid(backend_sync(before, ok, persisted)),
        backend_sync(before, ok, persisted).visible == before.visible,
        ok ==> backend_sync(before, ok, persisted).durable == before.visible,
{
    if ok { clean_valid(before.visible); } else {
        let after = backend_sync(before, ok, persisted);
        assert forall|address: int| 0 <= address < after.visible.len() implies
            #[trigger] after.permitted[address].contains(after.visible[address])
            && after.permitted[address].contains(after.durable[address]) by {
            assert(before.permitted[address].contains(before.visible[address]));
            assert(before.permitted[address].contains(before.durable[address]));
        }
    }
}

pub proof fn concat_no_sync(left: Seq<Event>, right: Seq<Event>)
    requires no_sync(left), no_sync(right),
    ensures no_sync(left + right),
{
    assert forall|position: int| 0 <= position < (left + right).len() implies
        (#[trigger] (left + right)[position]).kind != 3 by {
        if position < left.len() { assert(left[position].kind != 3); }
        else { assert(right[position - left.len()].kind != 3); }
    }
}

pub proof fn check_entries(before: Image, entries: Seq<Entry>, stripe: nat,
    index: nat, decisions: spec_fn(nat, nat) -> Decision)
    requires valid(before), entries_valid(entries, before.visible.len()),
    ensures valid(model_entries(before, entries, stripe, index, decisions).image),
        model_entries(before, entries, stripe, index, decisions).image.visible.len() == before.visible.len(),
        no_sync(model_entries(before, entries, stripe, index, decisions).events),
        model_entries(before, entries, stripe, index, decisions).successful <= entries.len(),
        model_entries(before, entries, stripe, index, decisions).ok ==>
            model_entries(before, entries, stripe, index, decisions).successful == entries.len(),
        !model_entries(before, entries, stripe, index, decisions).ok ==>
            model_entries(before, entries, stripe, index, decisions).successful < entries.len(),
        model_entries(before, entries, stripe, index, decisions).ok ==>
            model_entries(before, entries, stripe, index, decisions).image.visible
                == visible_entries(before.visible, entries),
        model_entries(before, entries, stripe, index, decisions).events.len()
            == model_entries(before, entries, stripe, index, decisions).successful
                + if model_entries(before, entries, stripe, index, decisions).ok { 0nat } else { 1nat },
        forall|position: int| 0 <= position < model_entries(before, entries, stripe, index, decisions).events.len() ==>
            (#[trigger] model_entries(before, entries, stripe, index, decisions).events[position])
                == event(0, stripe, index + position as nat,
                    position < model_entries(before, entries, stripe, index, decisions).successful),
    decreases entries.len(),
{
    if entries.len() > 0 {
        let decision = decisions(stripe, index);
        let written = backend_write(before, entries[0], decision);
        write_valid(before, entries[0], decision);
        if decision.ok {
            let rest = entries.subrange(1, entries.len() as int);
            assert(entries_valid(rest, written.visible.len())) by {
                assert forall|position: int| 0 <= position < rest.len() implies
                    entry_valid(#[trigger] rest[position], written.visible.len()) by {
                    assert(rest[position] == entries[position + 1]);
                }
            }
            check_entries(written, rest, stripe, index + 1, decisions);
            concat_no_sync(seq![event(0, stripe, index, true)],
                model_entries(written, rest, stripe, index + 1, decisions).events);
            let result = model_entries(before, entries, stripe, index, decisions);
            let tail = model_entries(written, rest, stripe, index + 1, decisions);
            assert forall|position: int| 0 <= position < result.events.len() implies
                (#[trigger] result.events[position]) == event(0, stripe, index + position as nat,
                    position < result.successful) by {
                if position > 0 {
                    assert(result.events[position] == tail.events[position - 1]);
                    assert(tail.events[position - 1] == event(0, stripe,
                        index + 1 + (position - 1) as nat, position - 1 < tail.successful));
                }
            }
        }
    }
}

pub proof fn check_stripes(before: Image, pending: Seq<Seq<Entry>>, stripe: nat,
    decisions: spec_fn(nat, nat) -> Decision)
    requires valid(before), pending_valid(pending, before.visible.len()),
    ensures valid(model_stripes(before, pending, stripe, decisions).image),
        model_stripes(before, pending, stripe, decisions).image.visible.len() == before.visible.len(),
        no_sync(model_stripes(before, pending, stripe, decisions).events),
        model_stripes(before, pending, stripe, decisions).pending.len() == pending.len(),
        model_stripes(before, pending, stripe, decisions).completed <= pending.len(),
        model_stripes(before, pending, stripe, decisions).ok ==>
            model_stripes(before, pending, stripe, decisions).completed == pending.len(),
        !model_stripes(before, pending, stripe, decisions).ok ==>
            model_stripes(before, pending, stripe, decisions).completed < pending.len(),
        forall|position: int| 0 <= position < pending.len() ==>
            (#[trigger] model_stripes(before, pending, stripe, decisions).pending[position])
                == if position < model_stripes(before, pending, stripe, decisions).completed {
                    Seq::<Entry>::empty() } else { pending[position] },
        model_stripes(before, pending, stripe, decisions).ok ==>
            model_stripes(before, pending, stripe, decisions).image.visible
                == visible_stripes(before.visible, pending),
        model_stripes(before, pending, stripe, decisions).ok ==>
            model_stripes(before, pending, stripe, decisions).events.last().kind == 2,
        !model_stripes(before, pending, stripe, decisions).ok ==>
            model_stripes(before, pending, stripe, decisions).events.len() > 0
            && model_stripes(before, pending, stripe, decisions).events.last().kind == 0
            && !model_stripes(before, pending, stripe, decisions).events.last().ok,
        forall|position: int| 0 <= position < model_stripes(before, pending, stripe, decisions).events.len()
            && (#[trigger] model_stripes(before, pending, stripe, decisions).events[position]).kind == 1 ==>
                stripe <= model_stripes(before, pending, stripe, decisions).events[position].stripe
                    < stripe + model_stripes(before, pending, stripe, decisions).completed,
    decreases pending.len(),
{
    if pending.len() > 0 {
        check_entries(before, pending[0], stripe, 0, decisions);
        let head = model_entries(before, pending[0], stripe, 0, decisions);
        if head.ok {
            let rest = pending.subrange(1, pending.len() as int);
            assert(pending_valid(rest, head.image.visible.len())) by {
                assert forall|position: int| 0 <= position < rest.len() implies
                    entries_valid(#[trigger] rest[position], head.image.visible.len()) by {
                    assert(rest[position] == pending[position + 1]);
                }
            }
            check_stripes(head.image, rest, stripe + 1, decisions);
            let tail = model_stripes(head.image, rest, stripe + 1, decisions);
            concat_no_sync(head.events, seq![event(1, stripe, 0, true)]);
            concat_no_sync(head.events + seq![event(1, stripe, 0, true)], tail.events);
            let result = model_stripes(before, pending, stripe, decisions);
            assert forall|position: int| 0 <= position < pending.len() implies
                (#[trigger] result.pending[position])
                    == if position < result.completed { Seq::<Entry>::empty() } else { pending[position] } by {
                if position > 0 {
                    assert(result.pending[position] == tail.pending[position - 1]);
                    assert(tail.pending[position - 1] == if position - 1 < tail.completed {
                        Seq::<Entry>::empty() } else { rest[position - 1] });
                }
            }
            assert forall|position: int| 0 <= position < result.events.len()
                && (#[trigger] result.events[position]).kind == 1 implies
                    stripe <= result.events[position].stripe < stripe + result.completed by {
                if position < head.events.len() {
                    assert(head.events[position].kind == 0);
                } else if position > head.events.len() {
                    let tail_position = position - head.events.len() - 1;
                    assert(result.events[position] == tail.events[tail_position]);
                    assert(stripe + 1 <= tail.events[tail_position].stripe
                        < stripe + 1 + tail.completed);
                }
            }
        }
    }
}

pub proof fn flush_refinement(before: Image, pending: Seq<Seq<Entry>>,
    decisions: spec_fn(nat, nat) -> Decision, sync_ok: bool, persisted: Set<int>)
    requires valid(before), pending_valid(pending, before.visible.len()),
    ensures valid(model_flush(before, pending, decisions, sync_ok, persisted).image),
        model_flush(before, pending, decisions, sync_ok, persisted).ok ==>
            model_flush(before, pending, decisions, sync_ok, persisted).image.durable
                == visible_stripes(before.visible, pending),
        model_stripes(before, pending, 0, decisions).ok ==>
            forall|position: int| 0 <= position < pending.len() ==>
                (#[trigger] model_flush(before, pending, decisions, sync_ok, persisted).pending[position]).len() == 0,
        !model_stripes(before, pending, 0, decisions).ok ==>
            no_sync(model_flush(before, pending, decisions, sync_ok, persisted).events),
        model_stripes(before, pending, 0, decisions).ok ==>
            model_flush(before, pending, decisions, sync_ok, persisted).events.last().kind == 3,
{
    check_stripes(before, pending, 0, decisions);
    let drained = model_stripes(before, pending, 0, decisions);
    if drained.ok {
        sync_valid(drained.image, sync_ok, persisted);
        assert forall|position: int| 0 <= position < pending.len() implies
            (#[trigger] model_flush(before, pending, decisions, sync_ok, persisted).pending[position]).len() == 0 by {
            assert(drained.pending[position] == Seq::<Entry>::empty());
        }
    }
}

pub proof fn same_offset_coalesces(pending: Map<nat, Seq<u8>>, offset: nat,
    earlier: Seq<u8>, latest: Seq<u8>)
    ensures pending.insert(offset, earlier).insert(offset, latest) == pending.insert(offset, latest),
        pending.insert(offset, earlier).insert(offset, latest)[offset] == latest,
{
    assert(pending.insert(offset, earlier).insert(offset, latest) =~= pending.insert(offset, latest));
}

pub proof fn localized_partial_error_control()
{
    let before = clean(seq![0u8, 0u8]);
    let entry = Entry { offset: 0, bytes: seq![7u8, 9u8] };
    let decision = Decision { ok: false, changed: Set::empty().insert(0),
        persisted: Set::empty().insert(0) };
    let after = backend_write(before, entry, decision);
    assert(after.visible[0] == 7);
    assert(after.visible[1] == 0);
    assert(after.durable[0] == 7);
    assert(after.durable[1] == 0);
    assert(after.visible != before.visible);
    assert(after.durable != before.durable);
}

pub proof fn successful_prefix_retained(before: Image, entries: Seq<Entry>, stripe: nat,
    index: nat, prefix: nat, decisions: spec_fn(nat, nat) -> Decision)
    requires valid(before), entries_valid(entries, before.visible.len()), prefix < entries.len(),
        forall|position: nat| position < prefix ==> (#[trigger] decisions(stripe, index + position)).ok,
        !decisions(stripe, index + prefix).ok,
    ensures !model_entries(before, entries, stripe, index, decisions).ok,
        model_entries(before, entries, stripe, index, decisions).successful == prefix,
        model_entries(before, entries, stripe, index, decisions).events.len() == prefix + 1,
        model_stripes(before, seq![entries], stripe,
            |selected_stripe: nat, position: nat| decisions(selected_stripe, index + position)).pending == seq![entries],
    decreases prefix,
{
    check_entries(before, entries, stripe, index, decisions);
    if prefix > 0 {
        let decision = decisions(stripe, index);
        assert(decisions(stripe, index + 0).ok);
        assert(decision.ok);
        write_valid(before, entries[0], decision);
        let written = backend_write(before, entries[0], decision);
        let rest = entries.subrange(1, entries.len() as int);
        assert(entries_valid(rest, written.visible.len())) by {
            assert forall|position: int| 0 <= position < rest.len() implies
                entry_valid(#[trigger] rest[position], written.visible.len()) by {
                assert(rest[position] == entries[position + 1]);
            }
        }
        assert forall|position: nat| position < prefix - 1 implies
            (#[trigger] decisions(stripe, index + 1 + position)).ok by {
            assert(decisions(stripe, index + (position + 1)).ok);
        }
        successful_prefix_retained(written, rest, stripe, index + 1, (prefix - 1) as nat, decisions);
    }
    shifted_decisions(before, entries, stripe, 0, index, decisions);
}

pub proof fn shifted_decisions(before: Image, entries: Seq<Entry>, stripe: nat,
    index: nat, shift: nat, decisions: spec_fn(nat, nat) -> Decision)
    ensures model_entries(before, entries, stripe, index + shift, decisions).image
        == model_entries(before, entries, stripe, index,
            |selected_stripe: nat, position: nat| decisions(selected_stripe, shift + position)).image,
        model_entries(before, entries, stripe, index + shift, decisions).ok
        == model_entries(before, entries, stripe, index,
            |selected_stripe: nat, position: nat| decisions(selected_stripe, shift + position)).ok,
    decreases entries.len(),
{
    if entries.len() > 0 && decisions(stripe, index + shift).ok {
        shifted_decisions(backend_write(before, entries[0], decisions(stripe, index + shift)),
            entries.subrange(1, entries.len() as int), stripe, index + 1, shift, decisions);
    }
}

pub open spec fn covers(entry: Entry, address: int) -> bool {
    entry.offset <= address < entry.offset + entry.bytes.len()
}

pub proof fn entries_preserve_address(before: Seq<u8>, entries: Seq<Entry>, address: int)
    requires 0 <= address < before.len(),
        forall|position: int| 0 <= position < entries.len() ==> !covers(#[trigger] entries[position], address),
    ensures visible_entries(before, entries)[address] == before[address],
        visible_entries(before, entries).len() == before.len(),
    decreases entries.len(),
{
    if entries.len() > 0 {
        let rest = entries.subrange(1, entries.len() as int);
        assert forall|position: int| 0 <= position < rest.len() implies
            !covers(#[trigger] rest[position], address) by {
            assert(rest[position] == entries[position + 1]);
        }
        entries_preserve_address(overwrite(before, entries[0]), rest, address);
    }
}

pub proof fn entries_reflect_last_cover(before: Seq<u8>, entries: Seq<Entry>, address: int, selected: nat)
    requires 0 <= address < before.len(), selected < entries.len(), covers(entries[selected as int], address),
        forall|position: int| selected < position < entries.len() ==>
            !covers(#[trigger] entries[position], address),
    ensures visible_entries(before, entries)[address]
        == entries[selected as int].bytes[address - entries[selected as int].offset],
        visible_entries(before, entries).len() == before.len(),
    decreases selected,
{
    let rest = entries.subrange(1, entries.len() as int);
    if selected == 0 {
        assert forall|position: int| 0 <= position < rest.len() implies
            !covers(#[trigger] rest[position], address) by {
            assert(rest[position] == entries[position + 1]);
        }
        entries_preserve_address(overwrite(before, entries[0]), rest, address);
    } else {
        assert(rest[(selected - 1) as int] == entries[selected as int]);
        assert forall|position: int| selected - 1 < position < rest.len() implies
            !covers(#[trigger] rest[position], address) by {
            assert(rest[position] == entries[position + 1]);
        }
        entries_reflect_last_cover(overwrite(before, entries[0]), rest, address, (selected - 1) as nat);
    }
}

pub proof fn stripe_drains_only_after_writes(before: Image, entries: Seq<Entry>, stripe: nat,
    decisions: spec_fn(nat, nat) -> Decision)
    requires valid(before), entries_valid(entries, before.visible.len()),
        model_entries(before, entries, stripe, 0, decisions).ok,
    ensures model_stripes(before, seq![entries], stripe, decisions).events.len() == entries.len() + 2,
        model_stripes(before, seq![entries], stripe, decisions).events[entries.len() as int].kind == 1,
        model_stripes(before, seq![entries], stripe, decisions).events.last().kind == 2,
        forall|position: int| 0 <= position < entries.len() ==>
            (#[trigger] model_stripes(before, seq![entries], stripe, decisions).events[position])
                == event(0, stripe, position as nat, true),
{
    reveal_with_fuel(model_stripes, 2);
    check_entries(before, entries, stripe, 0, decisions);
    assert(seq![entries].subrange(1, 1) =~= Seq::<Seq<Entry>>::empty());
}

pub open spec fn successful_decisions() -> spec_fn(nat, nat) -> Decision {
    |stripe: nat, position: nat| Decision { ok: true, changed: Set::empty(), persisted: Set::empty() }
}

pub proof fn all_entries_succeed(before: Image, entries: Seq<Entry>, stripe: nat, index: nat)
    ensures model_entries(before, entries, stripe, index, successful_decisions()).ok,
    decreases entries.len(),
{
    if entries.len() > 0 {
        all_entries_succeed(backend_write(before, entries[0], successful_decisions()(stripe, index)),
            entries.subrange(1, entries.len() as int), stripe, index + 1);
    }
}

pub proof fn all_stripes_succeed(before: Image, pending: Seq<Seq<Entry>>, stripe: nat)
    ensures model_stripes(before, pending, stripe, successful_decisions()).ok,
    decreases pending.len(),
{
    if pending.len() > 0 {
        all_entries_succeed(before, pending[0], stripe, 0);
        all_stripes_succeed(model_entries(before, pending[0], stripe, 0, successful_decisions()).image,
            pending.subrange(1, pending.len() as int), stripe + 1);
    }
}

pub proof fn arbitrary_successful_flush(before: Image, pending: Seq<Seq<Entry>>)
    requires valid(before), pending_valid(pending, before.visible.len()),
    ensures model_flush(before, pending, successful_decisions(), true, Set::empty()).ok,
        model_flush(before, pending, successful_decisions(), true, Set::empty()).image.durable
            == visible_stripes(before.visible, pending),
        forall|position: int| 0 <= position < pending.len() ==>
            (#[trigger] model_flush(before, pending, successful_decisions(), true, Set::empty()).pending[position]).len() == 0,
{
    all_stripes_succeed(before, pending, 0);
    flush_refinement(before, pending, successful_decisions(), true, Set::empty());
}

pub proof fn unbounded_pending_coalescing(before: Buffered, offset: nat, values: Seq<Seq<u8>>)
    ensures buffer_repeated(before, offset, values).backend == before.backend,
        values.len() > 0 ==> buffer_repeated(before, offset, values).slots
            == before.slots.insert(offset, values.last()),
    decreases values.len(),
{
    if values.len() > 0 {
        let first = buffer_application(before, offset, values[0]);
        let rest = values.subrange(1, values.len() as int);
        unbounded_pending_coalescing(first, offset, rest);
        if rest.len() > 0 {
            assert(rest.last() == values.last());
            same_offset_coalesces(before.slots, offset, values[0], values.last());
        }
    }
}

pub proof fn stripes_preserve_address(before: Seq<u8>, pending: Seq<Seq<Entry>>, address: int)
    requires 0 <= address < before.len(),
        forall|stripe: int, position: int| 0 <= stripe < pending.len()
            && 0 <= position < pending[stripe].len() ==>
            !covers(#[trigger] pending[stripe][position], address),
    ensures visible_stripes(before, pending).len() == before.len(),
        visible_stripes(before, pending)[address] == before[address],
    decreases pending.len(),
{
    if pending.len() > 0 {
        assert forall|position: int| 0 <= position < pending[0].len() implies
            !covers(#[trigger] pending[0][position], address) by {}
        entries_preserve_address(before, pending[0], address);
        let rest = pending.subrange(1, pending.len() as int);
        assert forall|stripe: int, position: int| 0 <= stripe < rest.len()
            && 0 <= position < rest[stripe].len() implies
            !covers(#[trigger] rest[stripe][position], address) by {
            assert(rest[stripe] == pending[stripe + 1]);
        }
        stripes_preserve_address(visible_entries(before, pending[0]), rest, address);
    }
}

pub proof fn stripes_reflect_last_cover(before: Seq<u8>, pending: Seq<Seq<Entry>>,
    address: int, selected_stripe: nat, selected_entry: nat)
    requires 0 <= address < before.len(), selected_stripe < pending.len(),
        selected_entry < pending[selected_stripe as int].len(),
        covers(pending[selected_stripe as int][selected_entry as int], address),
        forall|position: int| selected_entry < position < pending[selected_stripe as int].len() ==>
            !covers(#[trigger] pending[selected_stripe as int][position], address),
        forall|stripe: int, position: int| selected_stripe < stripe < pending.len()
            && 0 <= position < pending[stripe].len() ==>
            !covers(#[trigger] pending[stripe][position], address),
    ensures visible_stripes(before, pending)[address]
        == pending[selected_stripe as int][selected_entry as int].bytes[
            address - pending[selected_stripe as int][selected_entry as int].offset],
    decreases selected_stripe,
{
    let rest = pending.subrange(1, pending.len() as int);
    if selected_stripe == 0 {
        entries_reflect_last_cover(before, pending[0], address, selected_entry);
        assert forall|stripe: int, position: int| 0 <= stripe < rest.len()
            && 0 <= position < rest[stripe].len() implies
            !covers(#[trigger] rest[stripe][position], address) by {
            assert(rest[stripe] == pending[stripe + 1]);
        }
        stripes_preserve_address(visible_entries(before, pending[0]), rest, address);
    } else {
        assert(rest[(selected_stripe - 1) as int] == pending[selected_stripe as int]);
        assert forall|stripe: int, position: int| selected_stripe - 1 < stripe < rest.len()
            && 0 <= position < rest[stripe].len() implies
            !covers(#[trigger] rest[stripe][position], address) by {
            assert(rest[stripe] == pending[stripe + 1]);
        }
        visible_entries_length(before, pending[0]);
        stripes_reflect_last_cover(visible_entries(before, pending[0]), rest, address,
            (selected_stripe - 1) as nat, selected_entry);
    }
}

pub proof fn visible_entries_length(before: Seq<u8>, entries: Seq<Entry>)
    ensures visible_entries(before, entries).len() == before.len(),
    decreases entries.len(),
{
    if entries.len() > 0 {
        visible_entries_length(overwrite(before, entries[0]), entries.subrange(1, entries.len() as int));
    }
}

pub proof fn arbitrary_order_nonoverlapping_byte(before: Image, pending: Seq<Seq<Entry>>,
    address: int, selected_stripe: nat, selected_entry: nat)
    requires valid(before), pending_valid(pending, before.visible.len()),
        0 <= address < before.visible.len(), selected_stripe < pending.len(),
        selected_entry < pending[selected_stripe as int].len(),
        covers(pending[selected_stripe as int][selected_entry as int], address),
        forall|stripe: int, position: int| 0 <= stripe < pending.len()
            && 0 <= position < pending[stripe].len()
            && (stripe != selected_stripe || position != selected_entry) ==>
            !covers(#[trigger] pending[stripe][position], address),
    ensures model_flush(before, pending, successful_decisions(), true, Set::empty()).image.durable[address]
        == pending[selected_stripe as int][selected_entry as int].bytes[
            address - pending[selected_stripe as int][selected_entry as int].offset],
{
    arbitrary_successful_flush(before, pending);
    assert forall|position: int| selected_entry < position < pending[selected_stripe as int].len() implies
        !covers(#[trigger] pending[selected_stripe as int][position], address) by {}
    stripes_reflect_last_cover(before.visible, pending, address, selected_stripe, selected_entry);
}

pub proof fn coalesced_pending_flush(before: Buffered, offset: nat, values: Seq<Seq<u8>>)
    requires valid(before.backend), values.len() > 0,
        offset + values.last().len() <= before.backend.visible.len(),
    ensures buffer_repeated(before, offset, values).backend == before.backend,
        buffer_repeated(before, offset, values).slots[offset] == values.last(),
        model_flush(before.backend,
            seq![seq![Entry { offset, bytes: buffer_repeated(before, offset, values).slots[offset] }]],
            successful_decisions(), true, Set::empty()).ok,
        model_flush(before.backend,
            seq![seq![Entry { offset, bytes: buffer_repeated(before, offset, values).slots[offset] }]],
            successful_decisions(), true, Set::empty()).image.durable
                == overwrite(before.backend.visible, Entry { offset, bytes: values.last() }),
{
    unbounded_pending_coalescing(before, offset, values);
    let entry = Entry { offset, bytes: values.last() };
    let pending = seq![seq![entry]];
    assert(entries_valid(pending[0], before.backend.visible.len()));
    assert(pending_valid(pending, before.backend.visible.len()));
    arbitrary_successful_flush(before.backend, pending);
    reveal_with_fuel(visible_stripes, 2);
    reveal_with_fuel(visible_entries, 2);
    assert(pending.subrange(1, 1) =~= Seq::<Seq<Entry>>::empty());
    assert(pending[0].subrange(1, 1) =~= Seq::<Entry>::empty());
}

pub proof fn localized_sync_error_control()
{
    let before = Image { visible: seq![7u8, 9u8], durable: seq![0u8, 0u8],
        permitted: Map::new(Set::range(0, 2), |address: int| Set::empty().insert(0u8).insert(
            if address == 0 { 7u8 } else { 9u8 })) };
    let after = backend_sync(before, false, Set::empty().insert(0));
    assert(after.visible[0] == 7);
    assert(after.visible[1] == 9);
    assert(after.durable[0] == 7);
    assert(after.durable[1] == 0);
    assert(after.durable != before.durable);
    assert(after.durable != before.visible);
}

pub proof fn flush_sync_order(before: Image, pending: Seq<Seq<Entry>>,
    decisions: spec_fn(nat, nat) -> Decision, sync_ok: bool, persisted: Set<int>)
    requires valid(before), pending_valid(pending, before.visible.len()),
    ensures model_stripes(before, pending, 0, decisions).ok ==>
        model_flush(before, pending, decisions, sync_ok, persisted).events.last().kind == 3,
        model_stripes(before, pending, 0, decisions).ok ==>
            forall|position: int| 0 <= position < model_flush(before, pending, decisions, sync_ok, persisted).events.len() - 1 ==>
                (#[trigger] model_flush(before, pending, decisions, sync_ok, persisted).events[position]).kind != 3,
        !model_stripes(before, pending, 0, decisions).ok ==>
            model_flush(before, pending, decisions, sync_ok, persisted) == model_stripes(before, pending, 0, decisions),
{
    check_stripes(before, pending, 0, decisions);
}

pub enum Boundary {
    Returned(Run),
    OpenAbnormal { phase: nat },
}

pub open spec fn boundary(before: Image, pending: Seq<Seq<Entry>>,
    decisions: spec_fn(nat, nat) -> Decision, sync_ok: bool, persisted: Set<int>,
    abnormal_phase: Option<nat>) -> Boundary {
    match abnormal_phase {
        Some(phase) => Boundary::OpenAbnormal { phase },
        None => Boundary::Returned(model_flush(before, pending, decisions, sync_ok, persisted)),
    }
}

pub proof fn abnormal_is_not_an_acknowledgement(before: Image, pending: Seq<Seq<Entry>>,
    decisions: spec_fn(nat, nat) -> Decision, sync_ok: bool, persisted: Set<int>, phase: nat)
    ensures !(boundary(before, pending, decisions, sync_ok, persisted, Some(phase)) is Returned),
{
}

}
