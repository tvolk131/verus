import datetime
import difflib
import hashlib
import json
import os
from pathlib import Path
import resource
import shutil
import signal
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
REPO = Path('/Users/tommyvolk/.t3/worktrees/verus/t3-60978068')
NATIVE = Path('/private/tmp/verus-crash-consistency94-20261105/native-leaf-lookup-007/recovered-native/redb')
RUNTIME = Path('/private/tmp/verus-crash-consistency94-20261105/native-leaf-lookup-007/midpoint-runtime-proposal/runtime')
TOOLCHAIN = Path('/Users/tommyvolk/.rustup/toolchains/1.99.1-aarch64-apple-darwin')
START = datetime.datetime.fromisoformat('2026-11-08T03:42:24+00:00').timestamp()
STOP = START + 22 * 60
END = START + 25 * 60
PINNED = {
    REPO / 'evidence/redb-storage-refinement109/PLAN.md': 'ecc47ad6648c025d6ee5d0d6698ff6fc9f0afda18e79f30f7e40f60dbc1fac90',
    REPO / 'evidence/redb-storage-refinement109/INPUTS.json': 'ed423164d494ad5176e3fd04ddee983153fc7e29b4a7d43e1cebe7efac063bb4',
}

def digest(path):
    result = hashlib.sha256()
    with open(path, 'rb') as source:
        for block in iter(lambda: source.read(1024 * 1024), b''):
            result.update(block)
    return result.hexdigest()

def save(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

def resources():
    return {
        'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'elapsed_seconds': time.time() - START,
        'scratch_bytes': sum(path.stat().st_size for path in ROOT.rglob('*') if path.is_file()),
        'global_free_bytes': shutil.disk_usage('/private/tmp').free,
        'observation': 'sampled at authentication and application boundaries; not a hard quota',
    }

def selected():
    result = dict(PINNED)
    data = json.loads((REPO / 'evidence/redb-storage-refinement109/INPUTS.json').read_text())
    for record in data['records']:
        result[Path(record['path'])] = record['sha256']
    return result

def extra_files():
    result = [ROOT / 'harness.py', Path('/usr/bin/python3'), Path('/bin/zsh'), Path('/usr/bin/shasum'),
              Path('/usr/bin/sed'), Path('/usr/bin/nl'), Path('/bin/cat'), Path('/bin/ls'),
              Path('/bin/date'), Path('/bin/df'), Path('/usr/bin/git'),
              Path('/usr/bin/head'), Path('/usr/bin/du'),
              Path(sys.executable).resolve(), Path(sys.prefix) / 'Python3',
              Path('/Users/tommyvolk/.t3/userdata/providers/codex/codex_095eca24-b4b7-4a15-8759-9d8964dbd03a/shadow/tmp/arg0-macos/codex-arg011pOCK/apply_patch').resolve(),
              Path('/Users/tommyvolk/.codex/packages/standalone/releases/0.166.0-aarch64-apple-darwin/codex-path/rg'),
              REPO / 'source/tools/redb_crash_consistency94/persistence_model.rs',
              Path('/private/tmp/branch-leaf-composition102-impl-SqXAof8z/attempt-003/invocation.json')]
    result.extend(path for path in RUNTIME.rglob('*') if path.is_file())
    result.extend(path for path in (TOOLCHAIN / 'lib').rglob('*') if path.is_file())
    result.extend([TOOLCHAIN / 'bin/rustc', TOOLCHAIN / 'bin/rustdoc'])
    result.extend(path for path in NATIVE.rglob('AGENTS.md') if path.is_file())
    result.extend([NATIVE / 'src/tree_store/page_store/cached_file.rs',
                   NATIVE / 'src/tree_store/page_store/page_manager.rs',
                   NATIVE / 'src/tree_store/page_store/backends.rs', NATIVE / 'src/backends.rs'])
    result.extend(path for path in (NATIVE / 'src/tree_store/page_store/file_backend').glob('*.rs'))
    result.extend(path for path in ROOT.glob('*.rs'))
    result.extend(path for path in ROOT.glob('*.py'))
    result.extend(path for path in ROOT.glob('*.md'))
    result.extend(Path(module.__file__).resolve() for module in list(sys.modules.values())
                  if getattr(module, '__file__', None) and Path(module.__file__).is_file())
    return sorted(set(path for path in result if path.is_file()))

def authenticate(label):
    expected = selected()
    baseline_path = ROOT / 'entry-extra.json'
    baseline = json.loads(baseline_path.read_text()) if baseline_path.exists() else {}
    rows = []
    mismatch = []
    for path in sorted(set(expected) | set(extra_files())):
        actual = digest(path) if path.is_file() else None
        wanted = expected.get(path, baseline.get(str(path)))
        match = wanted is None or actual == wanted
        rows.append({'path': str(path), 'sha256': actual, 'expected_sha256': wanted, 'matches': match,
                     'bytes': path.stat().st_size if path.is_file() else None})
        if not match:
            mismatch.append(str(path))
    additions = {row['path']: row['sha256'] for row in rows if Path(row['path']) not in expected
                 and ROOT not in Path(row['path']).parents and row['path'] not in baseline}
    if additions or not baseline_path.exists():
        save(baseline_path, dict(baseline, **additions))
    result = {'label': label, 'resources': resources(), 'selected_count': 369,
              'mismatch': mismatch, 'records': rows,
              'authentication_limit': 'hash snapshots, not atomic first-read provenance; OS loader/system libraries not exhaustively enumerated'}
    save(ROOT / (label + '-authentication.json'), result)
    print(label, 'records', len(rows), 'mismatch', mismatch, 'resources', result['resources'], flush=True)
    if mismatch:
        raise SystemExit('AUTHENTICATION FAILED')
    return result

def run(source_name, label):
    attempts = sorted(path for path in ROOT.glob('attempt-*') if path.is_dir())
    number = max([int(path.name.split('-')[1]) for path in attempts] + [0]) + 1
    if number > 16 or time.time() >= STOP:
        raise SystemExit('launch allowance exhausted')
    current = resources()
    if current['scratch_bytes'] >= 768 * 1024**2 or current['global_free_bytes'] <= 16 * 1024**3:
        raise SystemExit('resource guard')
    attempt = ROOT / ('attempt-%03d' % number)
    attempt.mkdir()
    authenticate(attempt.name + '-preexecution')
    source = ROOT / source_name
    argv = [str(RUNTIME / 'verus'), '--sysroot', str(TOOLCHAIN), '--edition=2024',
            '--crate-type=lib', '--crate-name', 'buffered_flush109', '--no-cheating',
            '--output-json', '--num-threads', '1', '--triggers-mode', 'silent',
            '--multiple-errors', '8', '--rlimit', '20', '-C', 'debug-assertions=no',
            '--export', str(attempt / 'buffered_flush109.vir'), str(source)]
    environment = {
        'PATH': str(TOOLCHAIN / 'bin') + ':/usr/bin:/bin:/usr/sbin:/sbin',
        'DYLD_LIBRARY_PATH': str(TOOLCHAIN / 'lib') + ':' + str(TOOLCHAIN / 'lib/rustlib/aarch64-apple-darwin/lib'),
        'RUSTC': str(TOOLCHAIN / 'bin/rustc'), 'RUSTDOC': str(TOOLCHAIN / 'bin/rustdoc'),
        'RUSTC_BOOTSTRAP': '1', 'RUSTUP_TOOLCHAIN': '1.99.1-aarch64-apple-darwin',
        'RUSTUP_NO_UPDATE_CHECK': '1', 'RUST_MIN_STACK': '20971520',
        'VERUS_EXTRA_ARGS': '--sysroot ' + str(TOOLCHAIN), 'VERUS_IN_VARGO': '1',
        'VERUS_USE_RUSTUP': '0', 'VERUS_Z3_PATH': str(RUNTIME / 'z3'),
        'CARGO_NET_OFFLINE': 'true', 'GIT_CONFIG_GLOBAL': '/dev/null',
        'GIT_CONFIG_NOSYSTEM': '1', 'GIT_OPTIONAL_LOCKS': '0', 'PYTHONDONTWRITEBYTECODE': '1',
        'PWD': str(attempt),
    }
    for key in ['HOME', 'TMPDIR', 'TMP', 'TEMP', 'CARGO_HOME', 'CARGO_TARGET_DIR', 'RUSTUP_HOME',
                'VERUS_INFER_CACHE', 'XDG_CACHE_HOME', 'XDG_CONFIG_HOME', 'XDG_DATA_HOME', 'XDG_STATE_HOME']:
        directory = attempt / key.lower()
        directory.mkdir()
        environment[key] = str(directory)
    save(attempt / 'invocation.json', {'argv': argv, 'environment': environment, 'cwd': str(attempt),
         'source': str(source), 'source_sha256': digest(source), 'label': label, 'charged_application': number,
         'timeout_seconds': 90, 'own_start': START, 'optional_stop': STOP, 'hard_stop': END})
    (attempt / 'input.rs').write_bytes(source.read_bytes())
    started = time.time()
    status = None
    timeout = False
    failure = None
    with open(attempt / 'stdout.txt', 'wb') as stdout, open(attempt / 'stderr.txt', 'wb') as stderr:
        try:
            child = subprocess.Popen(argv, cwd=attempt, env=environment, stdout=stdout, stderr=stderr,
                                     start_new_session=True)
            try:
                status = child.wait(timeout=min(90, END - time.time()))
            except subprocess.TimeoutExpired:
                timeout = True
                os.killpg(child.pid, signal.SIGKILL)
                status = child.wait()
        except Exception as error:
            failure = repr(error)
    result = {'label': label, 'charged_application': number, 'direct_child_status': status,
              'timeout': timeout, 'launch_error': failure, 'elapsed_seconds': time.time() - started,
              'resources': resources(), 'source_sha256': digest(source),
              'artifacts': [{'path': str(path), 'sha256': digest(path), 'bytes': path.stat().st_size}
                            for path in attempt.glob('*') if path.is_file()]}
    save(attempt / 'receipt.json', result)
    print(json.dumps({key: value for key, value in result.items() if key != 'artifacts'}, indent=2))
    output = (attempt / 'stdout.txt').read_text(errors='replace')
    try:
        parsed = json.loads(output)
        print(json.dumps({'verification-results': parsed.get('verification-results'),
                          'verus': parsed.get('verus')}, indent=2))
    except ValueError:
        print(output[-4000:])
    print((attempt / 'stderr.txt').read_text(errors='replace')[-10000:])

if __name__ == '__main__':
    if sys.argv[1] == 'auth':
        authenticate(sys.argv[2])
    elif sys.argv[1] == 'run':
        run(sys.argv[2], sys.argv[3])
