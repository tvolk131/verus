import hashlib
import json
import os
import pathlib
import sys
import time

ROOT = pathlib.Path('/private/tmp/redb-storage109-lane2-wqh8Ege8')
REPO = pathlib.Path('/Users/tommyvolk/.t3/worktrees/verus/t3-60978068')
MANIFEST = REPO / 'evidence/redb-storage-refinement109/INPUTS.json'

def digest(path):
    value = hashlib.sha256()
    with open(path, 'rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(block)
    return value.hexdigest()

def audit(label):
    manifest = json.loads(MANIFEST.read_text())
    records = []
    for record in manifest['records']:
        actual = digest(record['path'])
        records.append(dict(path=record['path'], expected=record['sha256'], actual=actual,
                            matches=actual == record['sha256']))
    extras = [str(REPO / 'evidence/redb-storage-refinement109/PLAN.md'), str(MANIFEST),
              '/private/tmp/branch-leaf-composition102-impl-SqXAof8z/attempt-003/invocation.json']
    extras.extend(json.loads((ROOT / 'extra-inputs.json').read_text()) if (ROOT / 'extra-inputs.json').exists() else [])
    extra_records = [dict(path=path, sha256=digest(path)) for path in sorted(set(extras))]
    extra_drift = []
    baseline = {}
    previous = [json.loads(path.read_text()) for path in ROOT.glob('*authentication.json')]
    for snapshot in sorted(previous, key=lambda snapshot: snapshot['utc']):
        for record in snapshot['extras']:
            baseline.setdefault(record['path'], record['sha256'])
    for record in extra_records:
        if record['path'] in baseline and baseline[record['path']] != record['sha256']:
            extra_drift.append(record)
    result = dict(label=label, utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
                  selected=records, extras=extra_records, historical_drift=manifest['historical_drift'],
                  selected_match=all(record['matches'] for record in records), extra_drift=extra_drift,
                  free_bytes=os.statvfs(ROOT).f_bavail * os.statvfs(ROOT).f_frsize)
    (ROOT / (label + '-authentication.json')).write_text(json.dumps(result, indent=2) + '\n')
    print(label, 'selected', len(records), 'match', result['selected_match'], 'extras', len(extra_records))
    if not result['selected_match']:
        print([record for record in records if not record['matches']])
        raise SystemExit(2)
    if extra_drift:
        raise SystemExit('extra immutable input drift')
    if result['free_bytes'] <= 16 * 1024**3:
        raise SystemExit('free space limit')
    return result

if __name__ == '__main__':
    audit(sys.argv[1])
