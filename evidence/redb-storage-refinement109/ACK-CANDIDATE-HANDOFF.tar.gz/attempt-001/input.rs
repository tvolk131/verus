use vstd::prelude::*;

verus! {

pub struct Config {
    pub immediate: bool,
    pub requested_two_phase: bool,
    pub quick_repair: bool,
    pub multi_process: bool,
    pub needs_repair: bool,
    pub poisoned: bool,
    pub restored: bool,
    pub shrink_enabled: bool,
    pub new_id_ordered: bool,
    pub post_commit_free: bool,
    pub freed_any: bool,
    pub empty_system_freed: bool,
    pub empty_data_freed: bool,
    pub old_secondary: int,
    pub old_secondary_valid: bool,
    pub new_slot: int,
}

pub struct State {
    pub pc: int,
    pub status: int,
    pub phase: bool,
    pub events: Seq<int>,
    pub first_write: int,
    pub first_barrier: int,
    pub second_write: int,
    pub final_barrier: int,
    pub publication: int,
    pub acknowledgement: int,
    pub prepared: bool,
    pub secondary: int,
    pub secondary_valid: bool,
}

pub open spec fn initial(config: Config) -> State {
    State { pc: 0, status: 0, phase: config.requested_two_phase, events: Seq::empty(),
        first_write: -1, first_barrier: -1, second_write: -1, final_barrier: -1,
        publication: -1, acknowledgement: -1, prepared: false,
        secondary: config.old_secondary, secondary_valid: config.old_secondary_valid }
}

pub open spec fn effective_two_phase(config: Config) -> bool {
    config.requested_two_phase || config.quick_repair || config.multi_process
}

pub open spec fn local_mode(config: Config) -> bool {
    config.immediate && !config.multi_process && !config.shrink_enabled
        && effective_two_phase(config)
}

pub open spec fn fallible(pc: int, config: Config) -> bool {
    pc == 2 || pc == 6 || pc == 8 || (9 <= pc <= 15)
        || (pc == 16 && config.quick_repair && !config.needs_repair)
        || pc == 17 || pc == 18 || pc == 22 || pc == 23 || pc == 24
        || pc == 26 || pc == 27 || pc == 28 || pc == 35 || (37 <= pc <= 41)
}

pub open spec fn next_pc(state: State, config: Config) -> int {
    if state.pc == 1 { if config.poisoned { 2 } else { 3 } }
    else if state.pc == 34 { if config.post_commit_free && !config.multi_process { 35 } else { 43 } }
    else if state.pc == 36 { if config.freed_any { 37 } else { 43 } }
    else { state.pc + 1 }
}

pub open spec fn milestone(state: State) -> bool {
    state.pc == 23 || (state.pc == 24 && state.phase) || state.pc == 27
        || state.pc == 28 || state.pc == 31 || state.pc == 46
}

pub open spec fn step(state: State, config: Config, signal: int) -> State {
    if state.status != 0 { state }
    else if signal == 2 { State { status: 3, ..state } }
    else if signal == 3 { State { status: 4, ..state } }
    else if signal == 4 { State { status: 5, ..state } }
    else if signal == 1 {
        State { status: if fallible(state.pc, config) { 2 } else { 9 }, ..state }
    }
    else if signal != 0 { State { status: 9, ..state } }
    else if state.pc == 2 { State { status: 2, ..state } }
    else if state.pc == 8 && !config.immediate { State { status: 8, ..state } }
    else if state.pc == 19 && config.shrink_enabled { State { status: 6, ..state } }
    else if state.pc == 20 && !config.new_id_ordered { State { status: 3, ..state } }
    else if state.pc == 29 && config.multi_process { State { status: 7, ..state } }
    else if state.pc == 43 && !(config.empty_system_freed && config.empty_data_freed) {
        State { status: 3, ..state }
    }
    else {
        let position = state.events.len() as int;
        State {
            pc: next_pc(state, config),
            status: if state.pc == 46 { 1 } else { 0 },
            phase: if state.pc == 4 { effective_two_phase(config) } else { state.phase },
            events: if milestone(state) { state.events.push(state.pc) } else { state.events },
            first_write: if state.pc == 23 { position } else { state.first_write },
            first_barrier: if state.pc == 24 && state.phase { position } else { state.first_barrier },
            second_write: if state.pc == 27 { position } else { state.second_write },
            final_barrier: if state.pc == 28 { position } else { state.final_barrier },
            publication: if state.pc == 31 { position } else { state.publication },
            acknowledgement: if state.pc == 46 { position } else { state.acknowledgement },
            prepared: state.prepared || state.pc == 21,
            secondary: if state.pc == 24 && state.phase { config.new_slot } else { state.secondary },
            secondary_valid: state.secondary_valid,
        }
    }
}

pub open spec fn run(config: Config, signals: Seq<int>) -> State
    decreases signals.len(),
{
    if signals.len() == 0 { initial(config) }
    else { step(run(config, signals.drop_last()), config, signals.last()) }
}

pub open spec fn recorded(state: State, position: int, tag: int) -> bool {
    position == -1 || (0 <= position < state.events.len() && state.events[position] == tag)
}

pub open spec fn invariant(state: State, config: Config) -> bool {
    &&& 0 <= state.pc <= 47
    &&& recorded(state, state.first_write, 23)
    &&& recorded(state, state.first_barrier, 24)
    &&& recorded(state, state.second_write, 27)
    &&& recorded(state, state.final_barrier, 28)
    &&& recorded(state, state.publication, 31)
    &&& recorded(state, state.acknowledgement, 46)
    &&& (state.pc <= 23 ==> state.first_write == -1)
    &&& (state.pc <= 24 ==> state.first_barrier == -1)
    &&& (state.pc <= 27 ==> state.second_write == -1)
    &&& (state.pc <= 28 ==> state.final_barrier == -1)
    &&& (state.pc <= 31 ==> state.publication == -1)
    &&& (state.pc <= 46 ==> state.acknowledgement == -1)
    &&& (state.pc >= 24 ==> state.first_write >= 0)
    &&& (state.pc >= 25 && state.phase ==> state.first_barrier >= 0)
    &&& (state.pc >= 28 ==> state.second_write >= 0)
    &&& (state.pc >= 29 ==> state.final_barrier >= 0)
    &&& (state.pc >= 32 ==> state.publication >= 0)
    &&& (state.pc >= 47 ==> state.acknowledgement >= 0)
    &&& (state.first_barrier >= 0 ==> 0 <= state.first_write < state.first_barrier)
    &&& (state.second_write >= 0 && state.phase ==> 0 <= state.first_barrier < state.second_write)
    &&& (state.final_barrier >= 0 ==> 0 <= state.second_write < state.final_barrier)
    &&& (state.publication >= 0 ==> 0 <= state.final_barrier < state.publication)
    &&& (state.acknowledgement >= 0 ==> 0 <= state.publication < state.acknowledgement)
    &&& (state.pc > 4 ==> state.phase == effective_two_phase(config))
    &&& (state.status == 1 ==> state.pc == 47)
    &&& (state.pc <= 21 ==> !state.prepared)
    &&& (state.pc >= 22 ==> state.prepared)
    &&& (state.pc <= 24 ==> state.secondary == config.old_secondary)
    &&& state.secondary_valid == config.old_secondary_valid
}

pub proof fn initial_invariant(config: Config)
    ensures invariant(initial(config), config),
{}

pub proof fn step_preserves_invariant(state: State, config: Config, signal: int)
    requires invariant(state, config),
    ensures invariant(step(state, config, signal), config),
{
    if state.status == 0 && signal == 0 {
        if milestone(state) {
            let extended = state.events.push(state.pc);
            assert forall|position: int| 0 <= position < state.events.len() implies
                extended[position] == state.events[position] by {};
        }
    }
}

pub proof fn run_invariant(config: Config, signals: Seq<int>)
    ensures invariant(run(config, signals), config),
    decreases signals.len(),
{
    if signals.len() == 0 { initial_invariant(config); }
    else {
        run_invariant(config, signals.drop_last());
        step_preserves_invariant(run(config, signals.drop_last()), config, signals.last());
    }
}

pub proof fn public_ok_has_two_successful_barriers(config: Config, signals: Seq<int>)
    requires local_mode(config), run(config, signals).status == 1,
    ensures ({
        let state = run(config, signals);
        0 <= state.first_write < state.first_barrier < state.second_write
            < state.final_barrier < state.publication < state.acknowledgement < state.events.len()
            && state.events[state.first_write] == 23
            && state.events[state.first_barrier] == 24
            && state.events[state.second_write] == 27
            && state.events[state.final_barrier] == 28
            && state.events[state.publication] == 31
            && state.events[state.acknowledgement] == 46
    }),
{
    run_invariant(config, signals);
}

pub proof fn terminal_outcomes_are_absorbing(state: State, config: Config, signal: int)
    requires state.status != 0,
    ensures step(state, config, signal) == state,
{}

pub proof fn later_error_does_not_erase_publication(state: State, config: Config)
    requires invariant(state, config), state.status == 0, state.pc == 35,
    ensures step(state, config, 1).status == 2,
        step(state, config, 1).publication == state.publication,
        step(state, config, 1).publication >= 0,
        step(state, config, 1).final_barrier >= 0,
        step(state, config, 1).acknowledgement == -1,
{}

pub proof fn early_crash_preserves_possibly_stale_secondary(state: State, config: Config)
    requires invariant(state, config), state.status == 0, state.pc == 22,
        config.old_secondary_valid, config.old_secondary != config.new_slot,
    ensures step(state, config, 4).status == 5,
        step(state, config, 4).prepared,
        step(state, config, 4).secondary_valid,
        step(state, config, 4).secondary == config.old_secondary,
        step(state, config, 4).secondary != config.new_slot,
{}

pub open spec fn witness_config() -> Config {
    Config { immediate: true, requested_two_phase: true, quick_repair: false,
        multi_process: false, needs_repair: false, poisoned: false, restored: false,
        shrink_enabled: false, new_id_ordered: true, post_commit_free: true, freed_any: true,
        empty_system_freed: true, empty_data_freed: true, old_secondary: 1,
        old_secondary_valid: true, new_slot: 3 }
}

pub proof fn reachable_post_publication_error_witness()
    ensures ({
        let config = witness_config();
        let prefix = Seq::new(34, |position: int| 0int);
        let state = run(config, prefix);
        state.pc == 35 && state.status == 0 && state.publication >= 0
            && step(state, config, 1).status == 2
            && step(state, config, 1).final_barrier >= 0
            && step(state, config, 1).acknowledgement == -1
    }),
{
    reveal_with_fuel(run, 36);
}

pub proof fn reachable_stale_secondary_crash_witness()
    ensures ({
        let config = witness_config();
        let state = run(config, Seq::new(21, |position: int| 0int));
        state.pc == 22 && state.status == 0 && state.prepared
            && step(state, config, 4).status == 5
            && step(state, config, 4).secondary_valid
            && step(state, config, 4).secondary != config.new_slot
    }),
{
    reveal_with_fuel(run, 23);
}

}
