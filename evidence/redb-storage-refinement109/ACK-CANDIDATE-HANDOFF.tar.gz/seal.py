import datetime
import json
import os
import pathlib
import sys
import time

sys.dont_write_bytecode = True

from audit import ROOT, audit, digest
from retain import anchors, outcomes, patches

EXPECTED_SOURCE = '447a7fcfa23fcdec6114be0ec4eb27274ed4133efbc7d81fdac896dffd9306a2'
START = datetime.datetime.fromisoformat('2026-11-08T03:42:31+00:00').timestamp()
HARD = datetime.datetime.fromisoformat('2026-11-08T04:07:31+00:00').timestamp()

def write_json(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2) + '\n')

def main():
    anchors()
    results = outcomes()
    patches()
    assert len(results) == 14
    assert digest(ROOT / 'ack_cfg.rs') == EXPECTED_SOURCE
    restored = []
    for number in [5, 7, 9, 11, 13]:
        path = ROOT / ('attempt-%03d/input.rs' % number)
        assert digest(path) == EXPECTED_SOURCE
        restored.append(dict(attempt=number, sha256=digest(path), byte_identical=True))
    expected = [1, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 0]
    assert [result['status']['raw_returncode'] for result in results] == expected
    assert all(not result['status']['timed_out'] for result in results)
    assert all(result['status']['elapsed'] <= 90 for result in results)
    consumer = results[-1]['verification_scope']
    assert consumer['complete_selected_scope_verified']
    assert consumer['checked_exec_bodies'] == 0
    assert consumer['checked_proof_bodies'] == 17
    now = time.time()
    assert now < HARD
    authentication = audit('exit')
    scratch = sum(path.stat().st_size for path in ROOT.rglob('*') if path.is_file())
    assert scratch < 768 * 1024**2
    utc = datetime.datetime.fromtimestamp(now, datetime.timezone.utc).isoformat()
    write_json('ACCOUNTING.json', dict(
        start_utc='2026-11-08T03:42:31Z', sealed_preparation_utc=utc,
        elapsed_seconds=now-START, own_optional_stop_utc='2026-11-08T04:04:31Z',
        own_hard_handoff_utc='2026-11-08T04:07:31Z',
        round_optional_stop_utc='2026-11-08T04:23:26Z', round_hard_stop_utc='2026-11-08T04:35:26Z',
        charged_verifier_applications=14, application_budget=16, workers=1,
        timeout_seconds=90, observed_subprocess_seconds=sum(result['status']['elapsed'] for result in results),
        scratch_logical_bytes_before_seal=scratch, scratch_budget_bytes=768*1024**2,
        free_bytes_exit=authentication['free_bytes'], required_free_bytes_strict=16*1024**3,
        observation_limits='Free space and scratch sampled, not continuous quotas; no asserted instantaneous peak.',
        selected_input_count=369, selected_inputs_match=True,
        extra_input_count=len(authentication['extras']), extra_input_drift=authentication['extra_drift'],
        historical_drifts_retained=5, source_restoration=restored,
        git_writes=0, network=0, subdelegation=0, cargo_or_standalone_rustc_launches=0,
        application_build_or_execution=0, verifier_runtime_builds=0, toolchain_or_cache_copies=0,
        new_trust=0, original_native_bodies_checked=0, final_cells_closed=0,
        runtime_compiler_source_correspondence='UNESTABLISHED',
        native_original_paths='FAILED', native_git_continuity='UNAVAILABLE'))
    write_json('HANDOFF.json', dict(
        status='IMPLEMENTED_AND_CHECKED_AUTHORED_CFG_REFERENCE_CANDIDATE_ONLY',
        root=str(ROOT), source='ack_cfg.rs', source_sha256=EXPECTED_SOURCE,
        source_patch='ack_cfg.rs.patch', source_patch_sha256=digest(ROOT/'ack_cfg.rs.patch'),
        report='REPORT.md', report_sha256=digest(ROOT/'REPORT.md'),
        matrix='MATRIX.md', adapter='ADAPTER.md', consumer='consumer.rs',
        positive_source_attempts=[5,7,9,11,13], semantic_negatives=[6,8,10,12],
        corrected_counterparts=[7,9,11,13], consumer_attempt=14,
        final_candidate_checked_exec_bodies=0, final_candidate_checked_proof_bodies=15,
        consumer_checked_exec_bodies=0, consumer_checked_proof_bodies=17,
        vir_or_rlib_emitted=False, binary_import_checked=False, source_module_interface_checked=True,
        native_storage_resource_allocator_history_binding='OPEN',
        pending_byte_lane_binding='OPEN; see ADAPTER.md', all18_cells='OPEN',
        acceptance_or_integration=False, no_further_verifier_launches=True))
    records = []
    for path in sorted(ROOT.rglob('*')):
        if path.is_file() and path.name not in ['MANIFEST.json', 'SEAL.json']:
            records.append(dict(path=str(path.relative_to(ROOT)), bytes=path.stat().st_size, sha256=digest(path)))
    write_json('MANIFEST.json', dict(schema='redb-storage109-lane2-sealed-output-v1',
                                   root=str(ROOT), files=records,
                                   excludes=['MANIFEST.json','SEAL.json']))
    write_json('SEAL.json', dict(manifest_sha256=digest(ROOT/'MANIFEST.json'),
                               handoff_sha256=digest(ROOT/'HANDOFF.json'),
                               report_sha256=digest(ROOT/'REPORT.md'),
                               source_sha256=EXPECTED_SOURCE,
                               file_count=len(records), sealed_utc=utc,
                               qualification='Integrity hashes, not a proof certificate or native provenance repair'))
    print(json.dumps(json.loads((ROOT/'SEAL.json').read_text()), indent=2))

if __name__ == '__main__':
    main()
