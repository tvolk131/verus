import difflib
import hashlib
import json
import pathlib
import time

from audit import ROOT, digest

NATIVE = pathlib.Path('/private/tmp/verus-crash-consistency94-20261105/native-leaf-lookup-007/recovered-native/redb')

def anchors():
    scopes = {
        'src/transactions.rs': [(1752, 1868), (2025, 2261)],
        'src/tree_store/page_store/page_manager.rs': [(1021, 1063), (1617, 1629), (1797, 1892)],
    }
    result = []
    for relative, spans in scopes.items():
        source = NATIVE / relative
        lines = source.read_text().splitlines(keepends=True)
        for start, end in spans:
            text = ''.join(lines[start - 1:end])
            result.append(dict(path=str(source), file_sha256=digest(source), start_line=start,
                               end_line=end, excerpt=text,
                               excerpt_sha256=hashlib.sha256(text.encode()).hexdigest()))
    (ROOT / 'native-anchors.json').write_text(json.dumps(result, indent=2) + '\n')

def outcomes():
    results = []
    for directory in sorted(ROOT.glob('attempt-*')):
        invocation = json.loads((directory / 'invocation.json').read_text())
        result = dict(attempt=directory.name, source_sha256=digest(directory / 'input.rs'),
                      status=json.loads((directory / 'status.json').read_text()))
        try:
            output = json.loads((directory / 'stdout.txt').read_text())
            result['verification_results'] = output['verification-results']
            inference = output.get('verus-infer', {})
            result['verification_scope'] = inference.get('verification_scope')
            result['failed_functions'] = inference.get('failed_functions')
            result['interface_written'] = inference.get('interface_written')
        except Exception as error:
            result['parse_error'] = repr(error)
        result['argv'] = invocation['argv']
        results.append(result)
    (ROOT / 'RESULTS.json').write_text(json.dumps(results, indent=2) + '\n')
    for before, after, name in [(5, 6, 'ack-before-final-flush'), (7, 8, 'erase-publication-on-error'),
                                 (9, 10, 'prepare-overwrites-old-secondary'), (11, 12, 'false-err-implies-rollback')]:
        base = ROOT / ('attempt-%03d/input.rs' % before)
        changed = ROOT / ('attempt-%03d/input.rs' % after)
        if base.exists() and changed.exists():
            patch = ''.join(difflib.unified_diff(base.read_text().splitlines(keepends=True),
                                               changed.read_text().splitlines(keepends=True),
                                               fromfile=base.name, tofile=changed.name))
            (ROOT / (name + '.patch')).write_text(patch)
    return results

def patches():
    for name in ['ack_cfg.rs', 'consumer.rs']:
        source = ROOT / name
        if source.exists():
            patch = ''.join(difflib.unified_diff([], source.read_text().splitlines(keepends=True),
                                               fromfile='/dev/null', tofile=name))
            (ROOT / (name + '.patch')).write_text(patch)

if __name__ == '__main__':
    anchors()
    results = outcomes()
    patches()
    print('retained', len(results), 'attempts')
