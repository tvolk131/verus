import datetime
import hashlib
import json
import os
import pathlib
import subprocess
import sys
import time

sys.dont_write_bytecode = True

from audit import ROOT, audit, digest

RUNTIME = pathlib.Path('/private/tmp/verus-crash-consistency94-20261105/native-leaf-lookup-007/midpoint-runtime-proposal/runtime')
TOOLCHAIN = pathlib.Path('/Users/tommyvolk/.rustup/toolchains/1.99.1-aarch64-apple-darwin')
DEADLINE = datetime.datetime.fromisoformat('2026-11-08T04:04:31+00:00').timestamp()

def main():
    attempts = sorted(ROOT.glob('attempt-*'))
    if len(attempts) >= 16 or time.time() >= DEADLINE:
        raise SystemExit('launch budget/cutoff')
    number = len(attempts) + 1
    directory = ROOT / ('attempt-%03d' % number)
    directory.mkdir()
    source = pathlib.Path(sys.argv[1])
    (directory / 'input.rs').write_bytes(source.read_bytes())
    name = 'ack_cfg109'
    argv = [str(RUNTIME / 'verus'), '--sysroot', str(TOOLCHAIN), '--edition=2024',
            '--crate-type=lib', '--crate-name', name, '--no-cheating', '--output-json',
            '--num-threads', '1', '--triggers-mode', 'silent', '--multiple-errors', '8',
            '--rlimit', '30', '-C', 'debug-assertions=no']
    argv.extend(sys.argv[2:])
    argv.append(str(directory / 'input.rs'))
    environment = {
        'PATH': str(TOOLCHAIN / 'bin') + ':/usr/bin:/bin:/usr/sbin:/sbin',
        'DYLD_LIBRARY_PATH': str(TOOLCHAIN / 'lib') + ':' + str(TOOLCHAIN / 'lib/rustlib/aarch64-apple-darwin/lib'),
        'RUSTC_BOOTSTRAP': '1', 'RUST_MIN_STACK': '20971520', 'VERUS_IN_VARGO': '1',
        'VERUS_USE_RUSTUP': '0', 'VERUS_Z3_PATH': str(RUNTIME / 'z3'),
        'RUSTC': str(TOOLCHAIN / 'bin/rustc'), 'RUSTDOC': str(TOOLCHAIN / 'bin/rustdoc'),
        'RUSTUP_TOOLCHAIN': '1.99.1-aarch64-apple-darwin', 'RUSTUP_NO_UPDATE_CHECK': '1',
        'VERUS_EXTRA_ARGS': '--sysroot ' + str(TOOLCHAIN), 'CARGO_NET_OFFLINE': 'true',
        'GIT_CONFIG_GLOBAL': '/dev/null', 'GIT_CONFIG_NOSYSTEM': '1', 'GIT_OPTIONAL_LOCKS': '0',
        'PYTHONDONTWRITEBYTECODE': '1', 'PWD': str(directory),
    }
    for variable in ['HOME', 'TMPDIR', 'TMP', 'TEMP', 'RUSTUP_HOME', 'CARGO_HOME',
                     'CARGO_TARGET_DIR', 'VERUS_INFER_CACHE', 'XDG_CACHE_HOME', 'XDG_CONFIG_HOME',
                     'XDG_DATA_HOME', 'XDG_STATE_HOME']:
        path = directory / variable.lower()
        path.mkdir()
        environment[variable] = str(path)
    audit('preexecution-%03d' % number)
    started = time.time()
    invocation = dict(argv=argv, environment=environment, cwd=str(directory),
                      start=started, timeout_seconds=90, source_sha256=digest(directory / 'input.rs'))
    invocation['harness_sha256'] = dict(audit=digest(ROOT / 'audit.py'), runner=digest(ROOT / 'run_check.py'))
    invocation['source_dependencies'] = [dict(path=str(ROOT / 'ack_cfg.rs'), sha256=digest(ROOT / 'ack_cfg.rs'))]
    (directory / 'invocation.json').write_text(json.dumps(invocation, indent=2) + '\n')
    with open(directory / 'stdout.txt', 'wb') as stdout, open(directory / 'stderr.txt', 'wb') as stderr:
        try:
            process = subprocess.Popen(argv, cwd=directory, env=environment, stdout=stdout, stderr=stderr,
                                       start_new_session=True)
            try:
                status = process.wait(timeout=min(90, max(1, DEADLINE - started)))
                timed_out = False
            except subprocess.TimeoutExpired:
                import signal
                os.killpg(process.pid, signal.SIGKILL)
                status = process.wait()
                timed_out = True
            result = dict(raw_returncode=status, timed_out=timed_out, elapsed=time.time()-started,
                          exported=[str(path.name) for path in directory.glob('*.vir')],
                          libraries=[str(path.name) for path in directory.glob('*.rlib')])
        except Exception as error:
            result = dict(launch_error=repr(error), elapsed=time.time()-started)
    (directory / 'status.json').write_text(json.dumps(result, indent=2) + '\n')
    print(directory, json.dumps(result))
    try:
        output = json.loads((directory / 'stdout.txt').read_text())
        print(json.dumps(output.get('verification-results')))
        print(json.dumps(output.get('verus-infer', {}).get('failed_functions')))
    except Exception:
        print((directory / 'stdout.txt').read_text())
    print((directory / 'stderr.txt').read_text())

if __name__ == '__main__':
    main()
