use vstd::prelude::*;

#[path = "/private/tmp/redb-storage109-lane2-wqh8Ege8/ack_cfg.rs"]
pub mod ack;

verus! {

pub proof fn consume_public_ack_interface(config: ack::Config, signals: Seq<int>)
    requires ack::local_mode(config), ack::run(config, signals).status == 1,
    ensures ({
        let state = ack::run(config, signals);
        state.events[state.first_barrier] == 24
            && state.events[state.final_barrier] == 28
            && state.first_barrier < state.final_barrier < state.publication < state.acknowledgement
    }),
{
    ack::public_ok_has_two_successful_barriers(config, signals);
}

pub proof fn consume_error_interface(state: ack::State, config: ack::Config)
    requires ack::cfg_invariant(state, config), state.status == 0, state.pc == 35,
    ensures ack::step(state, config, 1).status == 2,
        ack::step(state, config, 1).publication >= 0,
        ack::step(state, config, 1).acknowledgement == -1,
{
    ack::later_error_does_not_erase_publication(state, config);
}

}
