import json
import pathlib
import tarfile

import review

ROOT = pathlib.Path(__file__).parent

def main():
    review.authenticate('exit')
    original = json.loads((ROOT / 'supplemental-identities.json').read_text())
    rows = []
    for record in original['records']:
        actual = review.digest(record['path'])
        rows.append(dict(path=record['path'], expected=record['sha256'], actual=actual, matches=actual == record['sha256']))
    review.write_json(ROOT / 'supplemental-exit.json', dict(records=rows, all_match=all(record['matches'] for record in rows), sample=review.sample()))
    if not all(record['matches'] for record in rows):
        raise RuntimeError('supplemental identity drift')
    if (ROOT / 'REPORT.md').stat().st_size > 32768:
        raise RuntimeError('report exceeds 32KiB')
    excluded = {'MANIFEST.json', 'SEAL.json', 'HANDOFF.json', 'handoff.tar.gz'}
    payloads = sorted(location for location in ROOT.rglob('*') if location.is_file() and location.relative_to(ROOT).parts[0] not in excluded)
    records = [dict(path=str(location.relative_to(ROOT)), bytes=location.stat().st_size, sha256=review.digest(location)) for location in payloads]
    review.write_json(ROOT / 'MANIFEST.json', dict(files=records, payloads=len(records), acceptance=False, all18='OPEN', self_and_seal_excluded=True))
    review.write_json(ROOT / 'SEAL.json', dict(manifest_sha256=review.digest(ROOT / 'MANIFEST.json'), report_sha256=review.digest(ROOT / 'REPORT.md'),
                                               exit_authentication_sha256=review.digest(ROOT / 'authentication-exit.json'),
                                               verifier_charges=6, verifier_launches=6, verifier_workers=1,
                                               acceptance=False, all18='OPEN', sample=review.sample(), final_cells_closed=0,
                                               deadline_utc='2026-11-08T04:22:00Z', optional_stop_utc='2026-11-08T04:19:22Z'))
    archive = ROOT / 'handoff.tar.gz'
    with tarfile.open(archive, 'w:gz') as destination:
        for location in payloads + [ROOT / 'MANIFEST.json', ROOT / 'SEAL.json']:
            destination.add(location, arcname=str(location.relative_to(ROOT)), recursive=False)
    review.write_json(ROOT / 'HANDOFF.json', dict(root=str(ROOT), report=str(ROOT / 'REPORT.md'), archive=str(archive),
                                               archive_sha256=review.digest(archive), archive_members=len(payloads) + 2,
                                               manifest_sha256=review.digest(ROOT / 'MANIFEST.json'), seal_sha256=review.digest(ROOT / 'SEAL.json'),
                                               sample=review.sample(), acceptance=False, all18='OPEN', ended_at_handoff=True))
    result = json.loads((ROOT / 'HANDOFF.json').read_text())
    if result['sample']['free_bytes'] <= 16 * 1024 ** 3 or result['sample']['scratch_bytes'] > 512 * 1024 ** 2:
        raise RuntimeError('final resource guard')
    print(json.dumps(result, indent=2))

if __name__ == '__main__':
    main()
