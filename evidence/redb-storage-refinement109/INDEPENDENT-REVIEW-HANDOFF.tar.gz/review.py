import datetime
import hashlib
import json
import os
import pathlib
import shutil
import signal
import subprocess
import sys
import time

ROOT = pathlib.Path(__file__).parent
BASE = pathlib.Path('/Users/tommyvolk/.t3/worktrees/verus/t3-60978068/evidence/redb-storage-refinement109')
A = pathlib.Path('/private/tmp/redb-storage109-lane1-20261108T034224Z')
B = pathlib.Path('/private/tmp/redb-storage109-lane2-wqh8Ege8')
CONTROLS = pathlib.Path('/private/tmp/redb-storage109-independent-controls-vKPHDj8s')
RUNTIME = pathlib.Path('/private/tmp/verus-crash-consistency94-20261105/native-leaf-lookup-007/midpoint-runtime-proposal/runtime')
PYTHON = '/Library/Developer/CommandLineTools/Library/Frameworks/Python3.framework/Versions/3.9/bin/python3.9'
FIRST = datetime.datetime.fromisoformat('2026-11-08T04:07:22+00:00').timestamp()
OPTIONAL = FIRST + 720
DEADLINE = datetime.datetime.fromisoformat('2026-11-08T04:22:00+00:00').timestamp()
PINS = {
    BASE / 'PLAN.md': 'ecc47ad6648c025d6ee5d0d6698ff6fc9f0afda18e79f30f7e40f60dbc1fac90',
    BASE / 'INPUTS.json': 'ed423164d494ad5176e3fd04ddee983153fc7e29b4a7d43e1cebe7efac063bb4',
    A / 'HANDOFF.json': 'f92d36f00ca9de1c8561031cb338b430dd2e7459912c5029a80f6ab0cb3b96aa',
    A / 'MANIFEST.json': '2fb03dedb6cf85e336ee6aba824876b1adf1d2506ebcb39dcf1faecbf49dc9fc',
    A / 'buffered_flush109.rs': '29485224c99ba2f994012ff53b2ddc98c9cab79daaf7b3fc2a855b952d2fdc4f',
    B / 'MANIFEST.json': '2ceca5762e9c983e2ed6a2f48ee0efee0f89237500c6c3898f987346f52ae053',
    B / 'ack_cfg.rs': '447a7fcfa23fcdec6114be0ec4eb27274ed4133efbc7d81fdac896dffd9306a2',
    CONTROLS / 'MANIFEST.json': '764153f9e8b0b6d6f5738d1e16a38bcd9e3b4fd6552cead8161c4db6d714d01e',
    BASE / 'BUFFERED-CANDIDATE-HANDOFF.tar.gz': 'f681a1c4bf93b5f36991d6403338b982c1ae1556ff2144acac8db3e7c51b38a0',
    BASE / 'ACK-CANDIDATE-HANDOFF.tar.gz': '3fab8b799531a87e3671ec6abb6bdbc40ec6262789d11ce76c1a529d2407c18b',
    BASE / 'INDEPENDENT-CONTROLS-HANDOFF.tar.gz': '961fecdf8c77c350eef61fc2c84d501727d8117abcecde04451e0bfbbedf54c5',
}

def digest(file_path):
    accumulator = hashlib.sha256()
    with open(file_path, 'rb') as source:
        for chunk in iter(lambda: source.read(1048576), b''):
            accumulator.update(chunk)
    return accumulator.hexdigest()

def write_json(file_path, value):
    file_path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

def sample():
    return dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                elapsed_seconds=time.time() - FIRST, free_bytes=shutil.disk_usage(ROOT).free,
                scratch_bytes=sum(file_path.stat().st_size for file_path in ROOT.rglob('*') if file_path.is_file()))

def tool_paths():
    paths = {pathlib.Path(PYTHON), pathlib.Path('/usr/bin/python3'), pathlib.Path('/Library/Developer/CommandLineTools/usr/bin/python3'),
             pathlib.Path('/Library/Developer/CommandLineTools/Library/Frameworks/Python3.framework/Versions/3.9/Python3'), pathlib.Path(__file__)}
    for module in list(sys.modules.values()):
        location = getattr(module, '__file__', None)
        if location and pathlib.Path(location).is_file():
            paths.add(pathlib.Path(location))
    return sorted(paths)

def authenticate(label):
    selected = json.loads((BASE / 'INPUTS.json').read_text())
    expected = dict(PINS)
    for record in selected['records']:
        location = pathlib.Path(record['path'])
        if location != BASE / 'README.md':
            expected[location] = record['sha256']
    counts = {}
    for candidate in (A, B, CONTROLS):
        records = json.loads((candidate / 'MANIFEST.json').read_text())['files']
        counts[str(candidate)] = len(records)
        for record in records:
            expected[candidate / record['path']] = record['sha256']
    extra = ROOT / 'entry-extra-identities.json'
    if extra.exists():
        for record in json.loads(extra.read_text()):
            expected[pathlib.Path(record['path'])] = record['sha256']
    else:
        identities = [dict(path=str(location), sha256=digest(location)) for location in tool_paths()]
        write_json(extra, identities)
        for record in identities:
            expected[pathlib.Path(record['path'])] = record['sha256']
    records = []
    for location, wanted in sorted(expected.items()):
        try:
            actual = digest(location)
            records.append(dict(path=str(location), expected=wanted, actual=actual, matches=actual == wanted))
        except Exception as error:
            records.append(dict(path=str(location), expected=wanted, matches=False, error=repr(error)))
    bad = [record for record in records if not record['matches']]
    result = dict(label=label, sample=sample(), selected_count=len(selected['records']),
                  payload_counts=counts, historical_drifts=selected['historical_drift'],
                  records=records, failures=bad, atomic_provenance=False,
                  parent_readme_immutable=False, exhaustive_dependency_closure=False)
    write_json(ROOT / ('authentication-' + label + '.json'), result)
    print(json.dumps(dict(authentication=label, failures=len(bad), records=len(records), sample=result['sample'])), flush=True)
    if bad:
        raise RuntimeError('authentication failed: ' + repr(bad[:3]))
    if result['sample']['free_bytes'] <= 16 * 1024 ** 3 or result['sample']['scratch_bytes'] > 512 * 1024 ** 2:
        raise RuntimeError('resource guard failed')

def run_check(number, lane, negative=False, restored=False):
    directory = ROOT / ('check-%02d' % number)
    directory.mkdir()
    candidate, filename, crate = (A, 'buffered_flush109.rs', 'buffered_flush109') if lane == 'A' else (B, 'ack_cfg.rs', 'ack_cfg109')
    source = directory / filename
    source.write_bytes((candidate / filename).read_bytes())
    if negative:
        if lane == 'A':
            old, new = 'decision.ok || decision.changed.contains(address)', 'decision.ok'
        else:
            old = 'if state.pc == 1 { if config.poisoned { 2 } else { 3 } }'
            new = 'if state.pc == 27 { 46 }\n    else if state.pc == 1 { if config.poisoned { 2 } else { 3 } }'
        text = source.read_text()
        if text.count(old) != 1:
            raise RuntimeError('mutation setup anchor not unique')
        original_line = next(line for line in text.splitlines() if old in line)
        replacement_line = original_line.replace(old, new)
        patch = '*** Begin Patch\n*** Update File: ' + str(source) + '\n@@\n-' + original_line + '\n+' + replacement_line.replace('\n', '\n+') + '\n*** End Patch\n'
        write_json(directory / 'mutation.json', dict(old=old, new=new, candidate_sha256=digest(candidate / filename)))
        mutation = subprocess.run(['apply_patch'], input=patch, text=True, capture_output=True)
        (directory / 'mutation-stdout.txt').write_text(mutation.stdout)
        (directory / 'mutation-stderr.txt').write_text(mutation.stderr)
        if mutation.returncode:
            raise RuntimeError('mutation apply_patch failed')
    template = json.loads((A / 'attempt-013/invocation.json').read_text())
    environment = dict(template['environment'])
    for key in ('CARGO_HOME', 'CARGO_TARGET_DIR', 'HOME', 'RUSTUP_HOME', 'TEMP', 'TMP', 'TMPDIR', 'VERUS_INFER_CACHE', 'XDG_CACHE_HOME', 'XDG_CONFIG_HOME', 'XDG_DATA_HOME', 'XDG_STATE_HOME'):
        destination = directory / key.lower()
        destination.mkdir()
        environment[key] = str(destination)
    environment['PWD'] = str(directory)
    export = directory / (crate + '.vir')
    argv = [str(RUNTIME / 'verus'), '--sysroot', '/Users/tommyvolk/.rustup/toolchains/1.99.1-aarch64-apple-darwin',
            '--edition=2024', '--crate-type=lib', '--crate-name', crate, '--no-cheating', '--output-json',
            '--num-threads', '1', '--triggers-mode', 'silent', '--multiple-errors', '8', '--rlimit',
            '20' if lane == 'A' else '30', '-C', 'debug-assertions=no', '--export', str(export), str(source)]
    invocation = dict(number=number, charged=True, lane=lane, negative=negative, restored=restored, argv=argv,
                      cwd=str(directory), environment=environment, source_sha256=digest(source),
                      candidate_sha256=digest(candidate / filename), requested_export=str(export),
                      fresh_export_absent=not export.exists(), timeout_seconds=90)
    write_json(directory / 'invocation.json', invocation)
    authenticate('preexecution-%02d' % number)
    started = time.time()
    if started >= OPTIONAL or started + 90 >= DEADLINE:
        raise RuntimeError('deadline guard prevents launch')
    status = dict(launched=False)
    with open(directory / 'stdout.txt', 'wb') as stdout, open(directory / 'stderr.txt', 'wb') as stderr:
        try:
            process = subprocess.Popen(argv, cwd=directory, env=environment, stdout=stdout, stderr=stderr, start_new_session=True)
            status['launched'] = True
            try:
                status['returncode'] = process.wait(timeout=90)
                status['timed_out'] = False
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                status['returncode'] = process.wait()
                status['timed_out'] = True
        except Exception as error:
            status['launch_error'] = repr(error)
    status.update(elapsed_seconds=time.time() - started, sample=sample(), requested_export=str(export),
                  export_exists=export.exists(), export_bytes=export.stat().st_size if export.exists() else 0,
                  export_sha256=digest(export) if export.exists() else None,
                  rlibs=[str(location) for location in directory.glob('*.rlib')])
    try:
        output = json.loads((directory / 'stdout.txt').read_text())
        status['verification_results'] = output.get('verification-results')
    except Exception as error:
        status['parse_error'] = repr(error)
    write_json(directory / 'status.json', status)
    print(json.dumps(dict(check=number, **status)), flush=True)

def main():
    mode = sys.argv[1]
    if mode == 'entry':
        authenticate('entry')
    elif mode == 'checks':
        for number, lane, negative, restored in [(1, 'A', False, False), (2, 'A', True, False), (3, 'A', False, True),
                                                  (4, 'B', False, False), (5, 'B', True, False), (6, 'B', False, True)]:
            run_check(number, lane, negative, restored)
    elif mode == 'exit':
        authenticate('exit')
    else:
        raise RuntimeError('unknown mode')

if __name__ == '__main__':
    main()
