import hashlib
import json
import pathlib
import re
import shutil
import sys
import tarfile

import review

ROOT = pathlib.Path(__file__).parent

def main():
    history = []
    for lane, candidate in [('A', review.A), ('B', review.B)]:
        for directory in sorted(candidate.glob('attempt-*')):
            if not directory.is_dir():
                continue
            invocation = json.loads((directory / 'invocation.json').read_text())
            status_file = directory / ('receipt.json' if lane == 'A' else 'status.json')
            status = json.loads(status_file.read_text())
            stdout = (directory / 'stdout.txt').read_text()
            stderr = (directory / 'stderr.txt').read_text()
            try:
                verification = json.loads(stdout).get('verification-results')
            except Exception:
                verification = None
            argv = invocation['argv']
            export = argv[argv.index('--export') + 1] if '--export' in argv else None
            history.append(dict(lane=lane, attempt=directory.name, invocation=invocation, status=status,
                                verification=verification, source_sha256=review.digest(directory / 'input.rs'),
                                stdout_sha256=review.digest(directory / 'stdout.txt'),
                                stderr_sha256=review.digest(directory / 'stderr.txt'),
                                stderr=stderr, requested_export=export,
                                current_requested_destination_exists=bool(export and pathlib.Path(export).exists()),
                                replayed=False))
    review.write_json(ROOT / 'historical-inspection.json', history)
    archives = []
    for candidate, filename in [(review.A, 'BUFFERED-CANDIDATE-HANDOFF.tar.gz'), (review.B, 'ACK-CANDIDATE-HANDOFF.tar.gz'),
                                 (review.CONTROLS, 'INDEPENDENT-CONTROLS-HANDOFF.tar.gz')]:
        archive = review.BASE / filename
        with tarfile.open(archive, 'r:gz') as source:
            members = source.getmembers()
            records = []
            for member in members:
                if not member.isfile():
                    records.append(dict(name=member.name, regular=False))
                    continue
                contents = source.extractfile(member).read()
                relative = pathlib.Path(member.name)
                direct = candidate / relative
                if not direct.is_file() and len(relative.parts) > 1:
                    direct = candidate.joinpath(*relative.parts[1:])
                actual = hashlib.sha256(contents).hexdigest()
                records.append(dict(name=member.name, regular=True, bytes=len(contents), sha256=actual,
                                    loose_path=str(direct), matches_loose=direct.is_file() and review.digest(direct) == actual))
        archives.append(dict(path=str(archive), sha256=review.digest(archive), members=len(members),
                             all_regular_match=all(record.get('matches_loose', True) for record in records), records=records))
    review.write_json(ROOT / 'archive-inspection.json', archives)
    scope = []
    for candidate, filename in [(review.A, 'buffered_flush109.rs'), (review.B, 'ack_cfg.rs')]:
        text = (candidate / filename).read_text()
        scope.append(dict(path=str(candidate / filename), sha256=review.digest(candidate / filename),
                          proof_bodies=len(re.findall(r'pub proof fn ', text)),
                          forbidden_tokens=re.findall(r'\b(?:assume|admit|axiom|external_body)\b', text),
                          native_executable_bodies_checked=0))
    review.write_json(ROOT / 'scope-inspection.json', scope)
    inherited = json.loads((review.A / 'entry-extra.json').read_text())
    tools = {pathlib.Path(shutil.which('apply_patch')), pathlib.Path('/bin/zsh'), pathlib.Path('/usr/bin/shasum'),
             pathlib.Path('/usr/bin/sed'), pathlib.Path('/usr/bin/nl'), pathlib.Path('/bin/cat'), pathlib.Path('/bin/date'),
             pathlib.Path('/bin/df'), pathlib.Path('/bin/ls'), pathlib.Path('/usr/bin/head'), pathlib.Path('/usr/bin/file'),
             pathlib.Path(shutil.which('rg')), pathlib.Path(__file__), ROOT / 'replay.py'}
    tools.update(review.tool_paths())
    rows = []
    for location in sorted(tools):
        actual = review.digest(location)
        prior = inherited.get(str(location), inherited.get(str(location.resolve())))
        rows.append(dict(path=str(location), sha256=actual, inherited_expected=prior,
                         matches_inherited=actual == prior if prior else None))
    extra_files = ['AUTHORIZATION.json', 'ACK-PUBLICATION-CORRECTION.json', 'INDEPENDENT-CONTROLS-COVERAGE.md',
                   'INDEPENDENT-CONTROLS-EXPECTED.json']
    rows.extend(dict(path=str(review.BASE / name), sha256=review.digest(review.BASE / name), inherited_expected=None,
                     matches_inherited=None) for name in extra_files)
    review.write_json(ROOT / 'supplemental-identities.json', dict(sample=review.sample(), records=rows,
                      late_bootstrap_tool_observation=True, parent_readme_not_immutable=True,
                      qualification='These additional tool/overlay observations are not retroactively claimed entry/preexecution authentication.'))
    print(json.dumps(dict(historical_attempts=len(history), archives=[dict(members=entry['members'], matches=entry['all_regular_match']) for entry in archives],
                          scope=scope, inherited_tool_mismatches=[row for row in rows if row['matches_inherited'] is False], sample=review.sample())), flush=True)

if __name__ == '__main__':
    main()
