import hashlib
import json
import os
import pathlib
import shutil
import subprocess
import sys
import time

import review

ROOT = pathlib.Path(__file__).parent
DESTINATION = ROOT / 'controls-replay'
PYTHON = review.PYTHON

def identity(location):
    return dict(path=str(location), sha256=review.digest(location), bytes=pathlib.Path(location).stat().st_size)

def main():
    DESTINATION.mkdir()
    names = ('authenticate.py', 'oracle.py', 'source_guards.py', 'test_controls.py', 'generate.py', 'controls_cli.py', 'expected_outcomes.json')
    copied = []
    for name in names:
        source = review.CONTROLS / name
        target = DESTINATION / name
        shutil.copyfile(source, target)
        copied.append(dict(original=identity(source), copy=identity(target)))
    original = "ROOT = pathlib.Path('/private/tmp/redb-storage109-independent-controls-vKPHDj8s')"
    replacement = 'ROOT = pathlib.Path(__file__).parent'
    patch = '*** Begin Patch\n*** Update File: ' + str(DESTINATION / 'authenticate.py') + '\n@@\n-' + original + '\n+' + replacement + '\n*** End Patch\n'
    result = subprocess.run(['apply_patch'], input=patch, text=True, capture_output=True)
    (DESTINATION / 'relocation-stdout.txt').write_text(result.stdout)
    (DESTINATION / 'relocation-stderr.txt').write_text(result.stderr)
    if result.returncode:
        raise RuntimeError('scratch relocation failed')
    review.write_json(DESTINATION / 'copied-inputs.json', dict(copied=copied, relocation=dict(old=original, new=replacement),
                                                          relocated=identity(DESTINATION / 'authenticate.py')))
    environment = dict(PATH='/usr/bin:/bin', HOME=str(DESTINATION), TMPDIR=str(DESTINATION), LC_ALL='C', TZ='UTC',
                       PYTHONDONTWRITEBYTECODE='1', PYTHONHASHSEED='0')
    for label, arguments in [('tests', ['-m', 'unittest', '-v', 'test_controls']), ('generation', ['generate.py'])]:
        review.authenticate('controls-preexecution-' + label)
        argv = [PYTHON, '-B'] + arguments
        invocation = dict(argv=argv, environment=environment, cwd=str(DESTINATION),
                          inputs=[identity(DESTINATION / name) for name in names], python=identity(PYTHON))
        review.write_json(DESTINATION / (label + '-invocation.json'), invocation)
        started = time.time()
        with open(DESTINATION / (label + '-stdout.txt'), 'wb') as stdout, open(DESTINATION / (label + '-stderr.txt'), 'wb') as stderr:
            process = subprocess.run(argv, cwd=DESTINATION, env=environment, stdout=stdout, stderr=stderr, timeout=90)
        review.write_json(DESTINATION / (label + '-status.json'), dict(returncode=process.returncode, elapsed_seconds=time.time() - started,
                                                                     sample=review.sample(), verifier_applications=0))
        print(label, process.returncode, flush=True)
        if process.returncode:
            raise RuntimeError(label + ' failed')
    products = ('case_inventory.json', 'crash_inventory.json', 'semantic_mutants.json', 'source_mutants.json', 'source_anchors.json', 'source_characterization.json', 'coverage.json')
    comparison = [dict(name=name, original=identity(review.CONTROLS / name), replay=identity(DESTINATION / name),
                       byte_identical=review.digest(review.CONTROLS / name) == review.digest(DESTINATION / name)) for name in products]
    review.write_json(DESTINATION / 'comparisons.json', comparison)
    print(json.dumps(dict(products=len(comparison), byte_identical=sum(record['byte_identical'] for record in comparison), sample=review.sample())), flush=True)

if __name__ == '__main__':
    main()
