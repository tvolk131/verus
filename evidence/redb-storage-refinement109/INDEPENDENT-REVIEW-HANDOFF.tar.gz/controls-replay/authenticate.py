import datetime
import hashlib
import json
import pathlib
import shutil
import sys

ROOT = pathlib.Path(__file__).parent
PARENT = pathlib.Path('/Users/tommyvolk/.t3/worktrees/verus/t3-60978068')
NATIVE = pathlib.Path('/private/tmp/verus-crash-consistency94-20261105/native-leaf-lookup-007/recovered-native/redb')
PATCH_TOOL = '/Users/tommyvolk/.t3/userdata/providers/codex/codex_095eca24-b4b7-4a15-8759-9d8964dbd03a/shadow/tmp/arg0-macos/codex-arg011pOCK/apply_patch'
PINS = {
    'PLAN.md': 'ecc47ad6648c025d6ee5d0d6698ff6fc9f0afda18e79f30f7e40f60dbc1fac90',
    'INPUTS.json': 'ed423164d494ad5176e3fd04ddee983153fc7e29b4a7d43e1cebe7efac063bb4',
}

def digest(path):
    return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()

def authenticate(stage):
    records = []
    evidence = PARENT / 'evidence/redb-storage-refinement109'
    for name, expected in PINS.items():
        path = evidence / name
        actual = digest(path)
        records.append(dict(path=str(path), expected=expected, actual=actual, matches=actual == expected))
    manifest = json.loads((evidence / 'INPUTS.json').read_text())
    selected = {'AGENTS.md', 'cached_file.rs', 'page_manager.rs', 'transactions.rs'}
    for entry in manifest['records']:
        path = pathlib.Path(entry['path'])
        if (str(path).startswith(str(NATIVE)) and path.name in selected) or entry.get('matches_historical') is False or str(path) == '/usr/bin/python3':
            actual = digest(path)
            records.append(dict(path=str(path), expected=entry['sha256'], actual=actual,
                                matches=actual == entry['sha256'], historical_sha256=entry.get('historical_sha256'),
                                historical_matches=entry.get('matches_historical'), bytes=path.stat().st_size))
    tools = []
    for path in sorted(set(['/usr/bin/python3', sys.executable, str(pathlib.Path(sys.executable).resolve()), PATCH_TOOL])):
        if path and pathlib.Path(path).is_file():
            tools.append(dict(path=path, sha256=digest(path), bytes=pathlib.Path(path).stat().st_size))
    result = dict(stage=stage, utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  records=records, tools=tools, historical_drift=manifest['historical_drift'],
                  all_match=all(record['matches'] for record in records),
                  free_bytes=shutil.disk_usage(ROOT).free, python_version=sys.version,
                  native_source_correspondence='UNESTABLISHED', all18='OPEN')
    if stage != 'entry':
        prior_path = ROOT / 'authentication-entry.json'
        result['entry_authentication_sha256'] = digest(prior_path)
        prior = json.loads(prior_path.read_text())
        baseline = {tool['path']: tool['sha256'] for tool in prior['tools']}
        result['tools_match_entry'] = all(baseline.get(tool['path']) == tool['sha256'] for tool in tools)
        result['all_match'] = result['all_match'] and result['tools_match_entry']
    (ROOT / ('authentication-' + stage + '.json')).write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    print(stage, 'match=', result['all_match'], 'records=', len(records), 'free_bytes=', result['free_bytes'])
    if not result['all_match'] or result['free_bytes'] <= 16 * 1024 ** 3:
        raise SystemExit(2)
    return result

if __name__ == '__main__':
    authenticate(sys.argv[1])
