import collections
import hashlib
import json
import pathlib

from authenticate import ROOT
from oracle import (INITIAL, PREPARED, PUBLISHED, Program, Storage, commit_cases,
                    crash_observations, inspect_image, run_commit, storage_cases, violations)
from source_guards import anchor_inventory, characterize, read_sources, source_mutants


def save(name, value):
    (ROOT / name).write_text(json.dumps(value, sort_keys=True, separators=(',', ':')) + '\n')

def main():
    sources = read_sources()
    characterization = characterize(sources)
    save('source_characterization.json', characterization)
    save('source_anchors.json', anchor_inventory(sources))
    mutants = list(source_mutants(sources))
    save('source_mutants.json', mutants)
    assert characterization['status'] == 'MATCH', characterization
    assert all(mutant['result']['status'] == 'MISMATCH' and mutant['corrected']['status'] == 'MATCH'
               for mutant in mutants), mutants
    storage = storage_cases()
    commits = commit_cases()
    for case in storage:
        case['source_anchors'] = ['flush_write_buffer', 'flush', 'checked_write', 'checked_sync']
    for run in commits:
        run['source_anchors'] = ['manager_commit', 'durable_commit', 'epilogue', 'public_commit']
        assert not violations(run), (run['id'], violations(run))
    save('case_inventory.json', dict(schema='finite-independent-cases-v1', storage=storage, commits=commits,
                                   qualification='No native execution, no universal coverage, no producer claim'))
    crash_rows = []
    for run in commits:
        prefixes = [(0, dict(visible=list(INITIAL), durable=list(INITIAL)))]
        prefixes += [(index + 1, event['state']) for index, event in enumerate(run['events'])]
        for event_index, snapshot in prefixes:
            for observation in crash_observations(snapshot):
                crash_rows.append(dict(case=run['id'], after_event=event_index, **observation))
    save('crash_inventory.json', dict(schema='finite-crash-observations-v1', observations=crash_rows,
                                    qualification='Raw image interpretations only, not native recovery outcomes'))
    semantic = []
    for name, program, failpoint, expected_violation in (
        ('premature_Ack', Program(name='premature_Ack', premature_ack=True), None,
         'Ack_before_required_successful_barrier'),
        ('omitted_first_barrier', Program(name='omitted_first_barrier', first_barrier=False), None,
         'prepared_barrier_missing_before_selector'),
        ('Err_implies_rollback', Program(name='Err_implies_rollback', rollback_error=True),
         'epilogue_register', 'postpublication_error_must_allow_committed_image'),
    ):
        bad = run_commit(program, failpoint=failpoint)
        good = run_commit(failpoint=failpoint)
        if name == 'Err_implies_rollback':
            rejected = inspect_image(bad['final']['durable'])['selected'] != 'new'
        else:
            rejected = expected_violation in violations(bad)
        semantic.append(dict(name=name, expected_violation=expected_violation, rejected=rejected,
                             mutant=bad, corrected=good, corrected_passes=not violations(good)))
    for name in ('loss_coalesced_latest', 'drain_failing_stripe'):
        records = []
        for wrong in (True, False):
            state = Storage()
            state.enqueue(0, 0, PREPARED)
            state.enqueue(0, 0, PUBLISHED, lose_latest=wrong and name == 'loss_coalesced_latest')
            state.flush('mutant_pair', fail_write=0 if name == 'drain_failing_stripe' else None,
                        drain_on_error=wrong and name == 'drain_failing_stripe')
            passes = state.durable[:3] == PUBLISHED if name == 'loss_coalesced_latest' else bool(state.pending[0])
            records.append(dict(wrong=wrong, property_passes=passes, events=state.events, final=state.state()))
        semantic.append(dict(name=name, rejected=not records[0]['property_passes'],
                             corrected_passes=records[1]['property_passes'], programs=records))
    stale = inspect_image(INITIAL)['secondary']
    semantic.append(dict(name='early_secondary_is_fresh', mutant='freshly_prepared', corrected=stale,
                         rejected=stale != 'freshly_prepared', corrected_passes=stale == 'valid_stale'))
    assert all(pair['rejected'] and pair['corrected_passes'] for pair in semantic)
    save('semantic_mutants.json', semantic)
    coverage = dict(
        storage_cases=len(storage), commit_cases=len(commits),
        storage_transitions=sum(len(case['events']) for case in storage),
        commit_transitions=sum(len(run['events']) for run in commits),
        unique_storage_terminal_states=len({json.dumps(case['final'], sort_keys=True) for case in storage}),
        unique_commit_terminal_outcomes=len({json.dumps([run['result'], run['final']], sort_keys=True) for run in commits}),
        crash_observations=len(crash_rows),
        crash_observations_by_mode=dict(collections.Counter(row['mode'] for row in crash_rows)),
        commit_results=dict(collections.Counter(run['result'] for run in commits)),
        semantic_mutant_pairs=len(semantic), source_mutant_pairs=len(mutants),
        source_status=characterization['status'], source_targets=len(characterization['anchors']),
        all18='OPEN', native_producer=False, universal_proof=False,
        parameterization='2 stripes, 3 entries, both stripe orders and each within-stripe order; every failing issue index; per-cell old/new/unknown write Err effects and independent old/visible persistence choices; 5 symbolic storage cells; 2 header phases; Result failpoints plus OPEN opaque continuations',
        aliasing='Sync-error progress parameterizations may duplicate terminal states; unique counts reported separately',
        unsupported='See BRANCH_COVERAGE.md; byte/resource/lifetime/panic/abort and full recovery OPEN',
    )
    save('coverage.json', coverage)
    print(json.dumps(coverage, indent=2, sort_keys=True))

if __name__ == '__main__':
    main()
