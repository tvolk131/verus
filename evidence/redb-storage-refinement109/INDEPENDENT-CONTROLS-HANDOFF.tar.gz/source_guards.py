import hashlib
import json
import pathlib
import re

from authenticate import NATIVE

PATHS = {
    'cached': 'src/tree_store/page_store/cached_file.rs',
    'manager': 'src/tree_store/page_store/page_manager.rs',
    'transactions': 'src/transactions.rs',
}
PINS = {
    'cached': 'cb901d44531b23f87d1bd31f72a24f1dc69308b5417db2167b7508921ffda486',
    'manager': 'b062608a527c3f53aa505af870f2b803da3fa7b095169194c681cc6441cb558a',
    'transactions': '02b383d6d984a14dfc4827ec04241d78637591f91ff754b42f9671b305d18bde',
}
TARGETS = {
    'flush_write_buffer': ('cached', 'fn flush_write_buffer(&self)'),
    'flush': ('cached', 'pub(super) fn flush(&self)'),
    'write': ('cached', 'pub(super) fn write(&self, offset:'),
    'checked_write': ('cached', 'fn write(&self, offset: u64, data:'),
    'checked_sync': ('cached', 'fn sync_data(&self)'),
    'write_header': ('manager', 'fn write_header(&self,'),
    'manager_commit': ('manager', 'pub(crate) fn commit('),
    'header_hold': ('manager', "pub(crate) fn header_hold<'a>("),
    'public_commit': ('transactions', 'pub fn commit(self)'),
    'commit_with': ('transactions', 'pub(crate) fn commit_with('),
    'commit_inner': ('transactions', 'fn commit_inner(&mut self,'),
    'commit_inner_helper': ('transactions', 'fn commit_inner_helper('),
    'durable_commit': ('transactions', 'pub(crate) fn durable_commit('),
    'epilogue': ('transactions', 'fn process_data_freed_pages_after_commit('),
}

class ParseFailure(Exception):
    pass

class Refusal(Exception):
    pass

def sanitized(source):
    if not isinstance(source, str):
        raise Refusal('non-text source')
    output = list(source)
    position = 0
    while position < len(source):
        if source.startswith('//', position):
            end = source.find('\n', position)
            end = len(source) if end < 0 else end
            output[position:end] = ' ' * (end - position)
            position = end
        elif source.startswith('/*', position):
            start = position
            depth = 1
            position += 2
            while position < len(source) and depth:
                if source.startswith('/*', position):
                    depth += 1
                    position += 2
                elif source.startswith('*/', position):
                    depth -= 1
                    position += 2
                else:
                    position += 1
            if depth:
                raise ParseFailure('unterminated block comment')
            output[start:position] = ['\n' if char == '\n' else ' ' for char in source[start:position]]
        elif source[position] == '"':
            start = position
            position += 1
            while position < len(source) and source[position] != '"':
                position += 2 if source[position] == '\\' else 1
            if position >= len(source):
                raise ParseFailure('unterminated string')
            position += 1
            output[start:position] = ['\n' if char == '\n' else ' ' for char in source[start:position]]
        else:
            position += 1
    return ''.join(output)

def tokens(source):
    return tuple(re.findall(r'[A-Za-z_][A-Za-z_0-9]*|[0-9]+|->|::|[^\s]', sanitized(source)))

def fragment(source, marker):
    clean = sanitized(source)
    start = clean.find(marker)
    if start < 0:
        raise Refusal('required target marker absent: ' + marker)
    brace = clean.find('{', start)
    if brace < 0:
        raise ParseFailure('missing function body')
    depth = 1
    end = brace + 1
    while end < len(clean) and depth:
        depth += (clean[end] == '{') - (clean[end] == '}')
        end += 1
    if depth:
        raise ParseFailure('unbalanced function body')
    return source[brace + 1:end - 1], start, end

def contains_sequence(body, snippets):
    body_tokens = tokens(body)
    position = 0
    for snippet in snippets:
        needle = tokens(snippet)
        found = False
        for index in range(position, len(body_tokens) - len(needle) + 1):
            if body_tokens[index:index + len(needle)] == needle:
                position = index + len(needle)
                found = True
                break
        if not found:
            return False, snippet
    return True, None

RULES = {
    'flush_write_buffer': [
        'for stripe in &self.write_buffer', 'for (offset, buffer) in write_buffer.cache.iter()',
        'self.file.write(*offset, buffer.as_ref().unwrap())?;',
        'for (offset, buffer) in write_buffer.cache.iter_mut()', 'write_buffer.clear();',
        'self.committed_pages_buffered.store(false, Ordering::Release);', 'Ok(())',
    ],
    'flush': ['self.flush_write_buffer()?;', 'self.file.sync_data()'],
    'write': ['let data = if let Some(removed) = lock.take_value(offset)',
              'removed', 'else', 'self.flush_lowest_priority(', 'Writeback::Required',
              'lock.insert(offset, result);', 'lock.take_value(offset).unwrap()', 'Ok(WritablePage'],
    'checked_write': ['self.check_failure()?;', 'let result = self.file.write(offset, data);',
                      'if result.is_err()', 'self.io_failed.store(true, Ordering::Release);',
                      'result.map_err(StorageError::from)'],
    'checked_sync': ['self.check_failure()?;', 'let result = self.file.sync_data();',
                     'if result.is_err()', 'self.io_failed.store(true, Ordering::Release);'],
    'write_header': ['if self.concurrency_mode.is_multi_process_writable()',
                     'return self.storage.write_direct(0, &header.to_bytes(true));',
                     'self.storage.write(0, DB_HEADER_SIZE, true)?.mem_mut().copy_from_slice(&header.to_bytes(true));',
                     'Ok(())'],
    'manager_commit': ['self.storage.check_io_errors()?;', 'Self::try_shrink(',
                       'header.write_secondary_slot(transaction_id, data_root, system_root);',
                       'let hold = self.header_hold(header_lock)?;', 'self.write_header(&header, &hold)?;',
                       'if two_phase { self.storage.flush()?; }',
                       'header.swap_primary_slot();', 'header.two_phase_commit = two_phase;',
                       'let hold = self.header_hold(header_lock)?;', 'self.write_header(&header, &hold)?;',
                       'self.storage.flush()?;', 'if shared', 'self.write_header(&header, &hold)?;',
                       'if shrunk { self.storage.resize(header.layout().len())?; }',
                       'self.unpersisted.lock().unwrap().clear();', 'state.header = header;', 'Ok(())'],
    'header_hold': ['Some(guard) => HeaderHold::Lent(guard)',
                    'None => HeaderHold::Own(self.lock_header_exclusive()?)'],
    'public_commit': ['self.commit_with(None)'],
    'commit_with': ['self.completed = true;', 'if self.is_poisoned()', 'self.abort_inner()?;',
                    'return Err(CommitError::TransactionPoisoned);', 'self.commit_inner(header_lock)'],
    'commit_inner': ['AllocatorStateLatch::arm(self.mem.clone());',
                     'self.commit_inner_helper(header_lock);', 'if result.is_ok()', 'latch.disarm();', 'result'],
    'commit_inner_helper': ['if self.quick_repair', 'self.two_phase_commit = true;',
                            'self.mem.concurrency_mode().is_multi_process_writable()',
                            'self.two_phase_commit = true;', 'table_tree.flush_and_close()?;',
                            'self.store_data_freed_pages(data_freed)?',
                            'self.durable_commit(user_root, allocated_pages, header_lock)?;', 'Ok(())'],
    'durable_commit': ['self.store_data_freed_pages_for(transaction_id, pages)?;',
                       'self.mem.header_hold(header_lock)?;', 'self.process_freed_pages(free_until_transaction)?;',
                       'self.flush_data_allocated_pages(allocated_pages)?;',
                       'if self.quick_repair && !self.mem.needs_repair()',
                       'system_tree.create_table_and_flush_table_root(',
                       'self.mem.reserve_allocator_state(tree, self.transaction_id)?;',
                       'self.mem.try_save_allocator_state(tree, num_regions)?',
                       'system_tree.finalize_dirty_checksums()?',
                       'self.mem.commit(user_root, system_root, self.transaction_id, self.two_phase_commit, self.shrink_policy, header_lock,)?;',
                       'clear_pending_non_durable_commits(&self.mem);', 'page_allocator.free(',
                       'self.apply_savepoint_state_on_commit();',
                       'if self.post_commit_free == PostCommitFree::Enabled && !self.mem.concurrency_mode().is_multi_process_writable()',
                       'self.process_data_freed_pages_after_commit(user_root, &page_allocator, savepoint_horizon,)?;',
                       'Ok(())'],
    'epilogue': ['Self::extract_freed_pages(', 'page_allocator.free(page, &PageTracker::ignore());',
                 'if !freed_any { return Ok(()); }',
                 'table_tree.flush_table_root_updates()?;', 'self.store_system_freed_pages(',
                 'system_tree.finalize_dirty_checksums()?', 'record_post_commit_allocations(',
                 'self.mem.non_durable_commit(user_root, system_root, epilogue_transaction, epilogue_allocations,)?;',
                 'self.transaction_tracker.register_non_durable_commit(&self.mem, epilogue_transaction, self.transaction_id, stored_system_freed_pages,)?;',
                 'Ok(())'],
}

def read_sources():
    return {name: (NATIVE / path).read_text() for name, path in PATHS.items()}

def characterize(sources, identity=True):
    results = []
    try:
        if set(sources) != set(PATHS):
            raise Refusal('source set must be exactly the three selected files')
        for name, source in sources.items():
            if not isinstance(source, str):
                raise Refusal('non-text source: ' + name)
            if identity and hashlib.sha256(source.encode()).hexdigest() != PINS[name]:
                return dict(status='MISMATCH', reason='source identity', source=name)
        for target, (name, marker) in TARGETS.items():
            body, start, end = fragment(sources[name], marker)
            matches, failed = contains_sequence(body, RULES[target])
            if target == 'manager_commit' and (tokens(body).count('return') or
                    sum(tokens(body)[index:index + 5] == ('Ok', '(', '(', ')', ')')
                        for index in range(len(tokens(body)) - 4)) != 1):
                matches, failed = False, 'unexpected early return/Ok'
            if not matches:
                return dict(status='MISMATCH', target=target, required=failed)
            results.append(dict(target=target, source=PATHS[name],
                                start_line=sources[name].count('\n', 0, start) + 1,
                                end_line=sources[name].count('\n', 0, end) + 1))
    except Refusal as error:
        return dict(status='REFUSAL', reason=str(error))
    except ParseFailure as error:
        return dict(status='PARSE_FAILURE', reason=str(error))
    return dict(status='MATCH', anchors=results,
                qualification='lexical characterization only; not a Rust parser or native semantics proof')

def anchor_inventory(sources):
    inventory = []
    for target, (name, marker) in TARGETS.items():
        body, start, end = fragment(sources[name], marker)
        base_line = sources[name].count('\n', 0, start) + 1
        clean = sanitized(sources[name][start:end])
        inventory.append(dict(target=target, path=str(NATIVE / PATHS[name]),
                              sha256=PINS[name], start_line=base_line,
                              end_line=sources[name].count('\n', 0, end) + 1,
                              text=sources[name][start:end],
                              question_mark_lines=[base_line + clean.count('\n', 0, match.start())
                                                   for match in re.finditer(r'\?', clean)],
                              qualification='all question marks listed lexically, not resolved call semantics'))
    return inventory

def source_mutants(sources):
    mutations = [
        ('omit_prepare_barrier', 'manager', 'if two_phase {\n            self.storage.flush()?;\n        }', 'if two_phase {}'),
        ('suppress_flush_write_error', 'cached', 'self.flush_write_buffer()?;', 'self.flush_write_buffer();'),
        ('premature_public_ok', 'manager', 'header.swap_primary_slot();', 'return Ok(());\n        header.swap_primary_slot();'),
        ('suppress_epilogue_error', 'transactions', 'savepoint_horizon,\n            )?;', 'savepoint_horizon,\n            );'),
        ('lose_latest_pending_header', 'cached', 'let data = if let Some(removed) = lock.take_value(offset)', 'let data = if let Some(removed) = None'),
        ('remove_failing_stripe_retention', 'cached', 'self.file.write(*offset, buffer.as_ref().unwrap())?;', 'write_buffer.clear();\n                self.file.write(*offset, buffer.as_ref().unwrap());'),
        ('omit_postpublication_savepoint_callback', 'transactions', 'self.apply_savepoint_state_on_commit();', 'opaque_not_bound();'),
    ]
    for name, source, before, after in mutations:
        if before not in sources[source]:
            raise Refusal('mutation anchor absent: ' + name)
        mutated = dict(sources)
        mutated[source] = sources[source].replace(before, after)
        yield dict(name=name, source=source, original_sha256=PINS[source],
                   mutant_sha256=hashlib.sha256(mutated[source].encode()).hexdigest(),
                   before=before, after=after, result=characterize(mutated, identity=False),
                   corrected=characterize(sources, identity=False),
                   corrected_sha256=hashlib.sha256(sources[source].encode()).hexdigest(),
                   original_unchanged=hashlib.sha256(sources[source].encode()).hexdigest() == PINS[source])
