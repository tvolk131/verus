import datetime
import hashlib
import json
import pathlib
import shutil
import tarfile

from authenticate import ROOT, authenticate, digest


def main():
    authentication = authenticate('exit')
    attempts = []
    for path in sorted(ROOT.glob('attempt-*/receipts.json')):
        receipts = json.loads(path.read_text())
        attempts.append(dict(path=str(path.relative_to(ROOT)), child_count=len(receipts),
                             all_expected=all(item['returncode'] == item.get('expected_returncode', 0)
                                              and not item['timed_out'] for item in receipts)))
    assert attempts and all(item['all_expected'] for item in attempts), attempts
    status = dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  result='INDEPENDENT_FINITE_CONTROLS_IMPLEMENTED_TESTED_NOT_ADOPTED',
                  all18='OPEN', native_producer=False, universal_proof=False,
                  authenticated_exit=authentication['all_match'], attempts=attempts,
                  free_bytes=shutil.disk_usage(ROOT).free,
                  scratch_before_archive_bytes=sum(path.stat().st_size for path in ROOT.rglob('*') if path.is_file()),
                  global_free_qualification='samples only, not a continuous guarantee',
                  forbidden_executions=0, subagents=0, native_or_parent_edits=0,
                  integration_or_acceptance=False)
    (ROOT / 'FINAL_STATUS.json').write_text(json.dumps(status, indent=2, sort_keys=True) + '\n')
    excluded = {'MANIFEST.json', 'MANIFEST.sha256', 'handoff.tar.gz', 'handoff.sha256', 'SEAL.json'}
    paths = [path for path in sorted(ROOT.rglob('*')) if path.is_file() and path.name not in excluded]
    manifest = dict(schema='sha256-payload-manifest-v1',
                    qualification='Manifest excludes itself and external seal/archive companions to avoid self-reference',
                    files=[dict(path=str(path.relative_to(ROOT)), bytes=path.stat().st_size, sha256=digest(path))
                           for path in paths])
    (ROOT / 'MANIFEST.json').write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
    manifest_hash = digest(ROOT / 'MANIFEST.json')
    (ROOT / 'MANIFEST.sha256').write_text(manifest_hash + '  MANIFEST.json\n')
    archive = ROOT / 'handoff.tar.gz'
    with tarfile.open(archive, 'w:gz', compresslevel=6) as bundle:
        for path in paths + [ROOT / 'MANIFEST.json', ROOT / 'MANIFEST.sha256']:
            bundle.add(path, arcname=str(path.relative_to(ROOT)), recursive=False)
    archive_hash = digest(archive)
    (ROOT / 'handoff.sha256').write_text(archive_hash + '  handoff.tar.gz\n')
    scratch = sum(path.stat().st_size for path in ROOT.rglob('*') if path.is_file())
    assert scratch < 64 * 1024 ** 2
    assert shutil.disk_usage(ROOT).free > 16 * 1024 ** 3
    with tarfile.open(archive, 'r:gz') as bundle:
        for entry in manifest['files']:
            content = bundle.extractfile(entry['path']).read()
            assert hashlib.sha256(content).hexdigest() == entry['sha256'], entry['path']
        assert hashlib.sha256(bundle.extractfile('MANIFEST.json').read()).hexdigest() == manifest_hash
    seal = dict(manifest_sha256=manifest_hash, archive_sha256=archive_hash,
                archive_bytes=archive.stat().st_size, payload_files=len(paths),
                scratch_bytes_after_archive=scratch, free_bytes=shutil.disk_usage(ROOT).free,
                archive_member_hashes_verified=True, status='SEALED_LOCAL_HANDOFF_ONLY',
                final_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                all18='OPEN', publication='parent retention/review not performed')
    (ROOT / 'SEAL.json').write_text(json.dumps(seal, indent=2, sort_keys=True) + '\n')
    print(json.dumps(seal, indent=2, sort_keys=True))

if __name__ == '__main__':
    main()
