import copy
import itertools
import json
import pathlib
import unittest

from oracle import (INITIAL, PREPARED, PUBLISHED, Program, Storage, commit_cases,
                    crash_observations, inspect_image, persistent_images, run_commit,
                    storage_cases, violations)
from source_guards import characterize, read_sources, source_mutants


class StorageControls(unittest.TestCase):
    def test_same_offset_full_header_coalesces_latest_before_issuance(self):
        storage = Storage()
        storage.enqueue(0, 0, PREPARED)
        storage.enqueue(0, 0, PUBLISHED)
        self.assertEqual(storage.visible, INITIAL)
        self.assertEqual(storage.pending, {0: {0: PUBLISHED}})
        self.assertEqual(storage.flush('coalesced'), 'Ok')
        writes = [event for event in storage.events if event['action'] == 'write_attempt']
        self.assertEqual(len(writes), 1)
        self.assertEqual(writes[0]['data'], list(PUBLISHED))
        self.assertEqual(storage.durable[:3], PUBLISHED)

    def test_loss_latest_mutant_and_corrected_counterpart(self):
        bad = Storage()
        bad.enqueue(0, 0, PREPARED)
        bad.enqueue(0, 0, PUBLISHED, lose_latest=True)
        bad.flush('wrong')
        good = Storage()
        good.enqueue(0, 0, PREPARED)
        good.enqueue(0, 0, PUBLISHED)
        good.flush('corrected')
        self.assertNotEqual(bad.durable[:3], PUBLISHED)
        self.assertEqual(good.durable[:3], PUBLISHED)

    def test_all_finite_storage_failure_prefixes_retain_whole_failing_stripe(self):
        for case in storage_cases():
            with self.subTest(case=case['id']):
                events = case['events']
                failure_index = case['failure_index']
                if failure_index is None:
                    self.assertEqual(case['result'], 'Ok')
                    self.assertTrue(all(not stripe for stripe in case['final']['pending'].values()))
                    self.assertEqual(case['final']['durable'], case['final']['visible'])
                    continue
                failing_stripe = case['ordered_writes'][failure_index][0]
                self.assertEqual(case['result'], 'Err')
                self.assertFalse(any(event['action'] == 'sync_attempt' for event in events))
                self.assertEqual(len([event for event in events if event['action'] == 'write_ok']), failure_index)
                expected_offsets = {'0', '3'} if failing_stripe == 0 else {'4'}
                self.assertEqual(set(case['final']['pending'][str(failing_stripe)]), expected_offsets)
                position = case['stripe_order'].index(failing_stripe)
                for drained in case['stripe_order'][:position]:
                    self.assertEqual(case['final']['pending'][str(drained)], {})
                for later in case['stripe_order'][position + 1:]:
                    self.assertTrue(case['final']['pending'][str(later)])

    def test_error_may_fully_issue_and_persist_bytes_without_sync(self):
        storage = Storage()
        storage.enqueue(0, 0, PUBLISHED)
        image = PUBLISHED + (0, 0)
        options = persistent_images(INITIAL, image)
        result = storage.flush('error', fail_write=0, error_image=image,
                               progress_index=options.index(image))
        self.assertEqual(result, 'Err')
        self.assertEqual(storage.durable[:3], PUBLISHED)
        self.assertTrue(storage.pending[0])
        self.assertFalse(any(event['action'] == 'sync_attempt' for event in storage.events))

    def test_sync_error_is_not_rollback_and_latches_future_operations(self):
        for progress_index in range(4):
            storage = Storage()
            storage.enqueue(0, 0, PUBLISHED)
            self.assertEqual(storage.flush('sync_error', sync_error=True, progress_index=progress_index), 'Err')
            self.assertEqual(storage.visible[:3], PUBLISHED)
            self.assertFalse(storage.pending[0])
            count = len(storage.events)
            self.assertEqual(storage.flush('retry'), 'Err')
            self.assertEqual([event['action'] for event in storage.events[count:]], ['latched_error'])

    def test_drain_on_error_mutant_and_corrected_counterpart(self):
        states = []
        for drain in (True, False):
            storage = Storage()
            storage.enqueue(0, 0, PUBLISHED)
            storage.flush('retention', fail_write=0, drain_on_error=drain)
            states.append(storage.pending[0])
        self.assertEqual(states[0], {})
        self.assertEqual(states[1], {0: PUBLISHED})


class CommitControls(unittest.TestCase):
    def test_authored_golden_outcomes_and_event_order(self):
        expected = json.loads(pathlib.Path(__file__).with_name('expected_outcomes.json').read_text())
        for case in expected['cases']:
            with self.subTest(case=case['id']):
                run = run_commit(failpoint=case['failpoint'])
                self.assertEqual(run['result'], case['result'])
                for key in ('durable', 'visible'):
                    if key in case:
                        self.assertEqual(run['final'][key], case[key])
                inspection = inspect_image(run['final']['durable'])
                for key in ('selected', 'secondary'):
                    if key in case:
                        self.assertEqual(inspection[key], case[key])
                labels = [event['action'] + (':' + event['label'] if 'label' in event else '')
                          for event in run['events']]
                cursor = -1
                for label in case.get('required_events', []):
                    cursor = labels.index(label, cursor + 1)
                for label in case.get('forbidden_events', []):
                    self.assertNotIn(label, labels)

    def test_all_enumerated_reference_runs_obey_public_barriers(self):
        for run in commit_cases():
            with self.subTest(case=run['id']):
                self.assertEqual(violations(run), [])
                if run['result'] == 'Ok':
                    self.assertEqual(run['final']['durable'], [1, 2, 3, 0, 7])

    def test_premature_ack_mutant_and_corrected_counterpart(self):
        bad = run_commit(Program(name='premature_ack', premature_ack=True))
        self.assertIn('Ack_before_required_successful_barrier', violations(bad))
        self.assertEqual(violations(run_commit()), [])

    def test_omitted_first_barrier_mutant_and_corrected_counterpart(self):
        bad = run_commit(Program(name='missing_prepare', first_barrier=False))
        self.assertIn('prepared_barrier_missing_before_selector', violations(bad))
        self.assertEqual(violations(run_commit()), [])

    def test_postpublication_epilogue_error_can_leave_committed_data(self):
        for failpoint in ('epilogue_extract', 'epilogue_flush_root', 'epilogue_store_system',
                          'epilogue_finalize_checksums', 'epilogue_non_durable_commit', 'epilogue_register'):
            run = run_commit(failpoint=failpoint)
            self.assertEqual(run['result'], 'Err')
            self.assertEqual(run['final']['durable'], [1, 2, 3, 0, 7])
            self.assertFalse(any(event['action'] == 'Ack' for event in run['events']))

    def test_err_implies_rollback_mutant_and_corrected_counterpart(self):
        bad = run_commit(Program(name='rollback_error', rollback_error=True), failpoint='epilogue_register')
        good = run_commit(failpoint='epilogue_register')
        self.assertEqual(bad['result'], good['result'])
        self.assertEqual(inspect_image(bad['final']['durable'])['selected'], 'old')
        self.assertEqual(inspect_image(good['final']['durable'])['selected'], 'new')

    def test_early_crash_secondary_valid_stale_not_prepared(self):
        run = run_commit(failpoint='hold_prepare')
        self.assertEqual(inspect_image(run['final']['durable'])['secondary'], 'valid_stale')
        self.assertNotEqual(inspect_image(run['final']['durable'])['secondary'], 'freshly_prepared')
        prepared = run_commit(failpoint='hold_publish')
        self.assertEqual(inspect_image(prepared['final']['durable'])['secondary'], 'freshly_prepared')

    def test_process_restart_and_power_loss_are_distinct_without_recovery_claim(self):
        run = run_commit(failpoint='publish_sync', progress_index=0)
        observations = list(crash_observations(run['final']))
        restart = [item for item in observations if item['mode'] == 'process_restart']
        power = [item for item in observations if item['mode'] == 'power_loss']
        self.assertEqual(restart[0]['selected'], 'new')
        self.assertEqual({item['selected'] for item in power}, {'old', 'new'})
        self.assertTrue(all(item['recovery'] == 'NOT_MODELLED' for item in observations))

    def test_write_error_can_leave_committed_image_before_final_barrier(self):
        image = (1, 2, 3, 0, 7)
        previous = (0, 2, 3, 0, 7)
        options = persistent_images(previous, image)
        run = run_commit(failpoint='publish_write', write_error_image=image,
                         progress_index=options.index(image))
        self.assertEqual(run['result'], 'Err')
        self.assertEqual(run['final']['durable'], list(image))
        self.assertFalse(any(event['action'] == 'barrier_ok' and event.get('label') == 'publish'
                             for event in run['events']))

    def test_opaque_callback_is_not_silently_adopted_as_inert(self):
        for name in ('quick_repair_callback', 'epilogue_extract', 'post_publication_callbacks'):
            run = run_commit(opaque_unknown=name, quick_repair=True)
            self.assertEqual(run['result'], 'OPEN_CALLBACK_EFFECT')
            self.assertFalse(any(event['action'] == 'Ack' for event in run['events']))


class SourceControls(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.sources = read_sources()

    def test_original_identity_and_characterization(self):
        result = characterize(self.sources)
        self.assertEqual(result['status'], 'MATCH', result)

    def test_semantic_source_mutants_mismatch_not_parser_failure(self):
        for mutant in source_mutants(self.sources):
            with self.subTest(mutant=mutant['name']):
                self.assertEqual(mutant['result']['status'], 'MISMATCH', mutant)
                self.assertEqual(mutant['corrected']['status'], 'MATCH', mutant)

    def test_identity_mismatch_separate_from_lexical_match(self):
        sources = dict(self.sources)
        sources['cached'] += '\n// harmless characterization-only change\n'
        self.assertEqual(characterize(sources)['status'], 'MISMATCH')
        self.assertEqual(characterize(sources, identity=False)['status'], 'MATCH')

    def test_comments_cannot_restore_missing_required_barrier(self):
        sources = dict(self.sources)
        before = 'if two_phase {\n            self.storage.flush()?;\n        }'
        sources['manager'] = sources['manager'].replace(before, 'if two_phase {} /* ' + before + ' */')
        self.assertEqual(characterize(sources, identity=False)['status'], 'MISMATCH')

    def test_refusal_and_parse_failure_are_not_successful_mutant_rejection(self):
        self.assertEqual(characterize({})['status'], 'REFUSAL')
        sources = dict(self.sources)
        sources['manager'] = None
        self.assertEqual(characterize(sources, identity=False)['status'], 'REFUSAL')
        sources = dict(self.sources)
        sources['manager'] += '\n/* unclosed'
        self.assertEqual(characterize(sources, identity=False)['status'], 'PARSE_FAILURE')
        sources = dict(self.sources)
        sources['cached'] = 'fn flush_write_buffer(&self) -> Result { '
        self.assertEqual(characterize(sources, identity=False)['status'], 'PARSE_FAILURE')


if __name__ == '__main__':
    unittest.main(verbosity=2)
