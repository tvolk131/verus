import json
import sys

from oracle import Program, inspect_image, run_commit, violations
from source_guards import characterize, read_sources, source_mutants


def main():
    family, name = sys.argv[1:3]
    if family == 'source':
        sources = read_sources()
        if name == 'original':
            result = characterize(sources)
        elif name == 'missing_inputs':
            result = characterize({})
        elif name == 'malformed':
            sources['manager'] += '\n/* unclosed'
            result = characterize(sources, identity=False)
        else:
            mutant = next(item for item in source_mutants(sources) if item['name'] == name)
            result = mutant['result']
        expected = 'MATCH' if name == 'original' else ('REFUSAL' if name == 'missing_inputs' else
                   ('PARSE_FAILURE' if name == 'malformed' else 'MISMATCH'))
    elif family == 'semantic':
        programs = {
            'corrected': Program(),
            'premature_Ack': Program(name='premature_Ack', premature_ack=True),
            'omitted_first_barrier': Program(name='omitted_first_barrier', first_barrier=False),
            'Err_implies_rollback': Program(name='Err_implies_rollback', rollback_error=True),
        }
        run = run_commit(programs[name], failpoint='epilogue_register' if name == 'Err_implies_rollback' else None)
        failures = violations(run)
        if name == 'Err_implies_rollback' and inspect_image(run['final']['durable'])['selected'] != 'new':
            failures.append('postpublication_error_must_allow_committed_image')
        result = dict(status='MISMATCH' if failures else 'MATCH', violations=failures,
                      outcome=run['result'], final=run['final'])
        expected = 'MATCH' if name == 'corrected' else 'MISMATCH'
    else:
        raise ValueError('unknown family')
    print(json.dumps(dict(family=family, case=name, expected=expected, result=result), sort_keys=True))
    raise SystemExit({'MATCH': 0, 'MISMATCH': 3, 'REFUSAL': 4, 'PARSE_FAILURE': 5}[result['status']])

if __name__ == '__main__':
    main()
