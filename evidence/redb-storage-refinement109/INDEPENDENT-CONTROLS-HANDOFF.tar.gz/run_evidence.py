import datetime
import hashlib
import json
import os
import pathlib
import shutil
import subprocess
import sys
import time

from authenticate import ROOT, authenticate, digest


def main():
    previous = sorted(ROOT.glob('attempt-[0-9][0-9][0-9]'))
    attempt = ROOT / ('attempt-%03d' % (len(previous) + 1))
    attempt.mkdir()
    entry = authenticate('preexecution-' + attempt.name)
    environment = {
        'PATH': '/usr/bin:/bin', 'HOME': str(ROOT), 'TMPDIR': str(ROOT),
        'LC_ALL': 'C', 'TZ': 'UTC', 'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONHASHSEED': '0',
    }
    inputs = {str(path): digest(path) for path in sorted(ROOT.glob('*.py'))}
    inputs[str(ROOT / 'expected_outcomes.json')] = digest(ROOT / 'expected_outcomes.json')
    receipts = []
    tasks = [
        ('unittest', [sys.executable, '-B', '-m', 'unittest', '-v', 'test_controls'], 0),
        ('generate', [sys.executable, '-B', str(ROOT / 'generate.py')], 0),
    ]
    source_cases = [('original', 0), ('missing_inputs', 4), ('malformed', 5)]
    source_cases += [(name, 3) for name in (
        'omit_prepare_barrier', 'suppress_flush_write_error', 'premature_public_ok',
        'suppress_epilogue_error', 'lose_latest_pending_header',
        'remove_failing_stripe_retention', 'omit_postpublication_savepoint_callback')]
    semantic_cases = [('corrected', 0), ('premature_Ack', 3), ('omitted_first_barrier', 3), ('Err_implies_rollback', 3)]
    for family, cases in (('source', source_cases), ('semantic', semantic_cases)):
        for name, expected_status in cases:
            tasks.append((family + '-' + name,
                          [sys.executable, '-B', str(ROOT / 'controls_cli.py'), family, name], expected_status))
    for label, arguments, expected_status in tasks:
        command = dict(label=label, argv=arguments, cwd=str(ROOT), environment=environment,
                       interpreter_sha256=digest(sys.executable), inputs=inputs,
                       started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
        (attempt / (label + '.command.json')).write_text(json.dumps(command, indent=2, sort_keys=True) + '\n')
        start = time.monotonic()
        with (attempt / (label + '.stdout')).open('wb') as stdout, (attempt / (label + '.stderr')).open('wb') as stderr:
            process = subprocess.Popen(arguments, cwd=str(ROOT), env=environment, stdout=stdout, stderr=stderr)
            timed_out = False
            try:
                returncode = process.wait(timeout=90)
            except subprocess.TimeoutExpired:
                timed_out = True
                process.kill()
                returncode = process.wait()
        receipt = dict(command=command, returncode=returncode, timed_out=timed_out,
                       expected_returncode=expected_status, expected_status_observed=returncode == expected_status,
                       elapsed_seconds=time.monotonic() - start,
                       stdout_sha256=digest(attempt / (label + '.stdout')),
                       stderr_sha256=digest(attempt / (label + '.stderr')),
                       finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
        receipts.append(receipt)
        (attempt / 'receipts.json').write_text(json.dumps(receipts, indent=2, sort_keys=True) + '\n')
        print(label, 'returncode=', returncode, 'timed_out=', timed_out, flush=True)
    used = sum(path.stat().st_size for path in ROOT.rglob('*') if path.is_file())
    resources = dict(scratch_bytes=used, scratch_limit_bytes=64 * 1024 ** 2,
                     free_bytes=shutil.disk_usage(ROOT).free, minimum_free_bytes=16 * 1024 ** 3,
                     qualification='Samples only; no hard quota or continuous global-free guarantee')
    (attempt / 'resource_sample.json').write_text(json.dumps(resources, indent=2) + '\n')
    print(json.dumps(resources, sort_keys=True))
    if used >= 64 * 1024 ** 2 or resources['free_bytes'] <= 16 * 1024 ** 3:
        raise SystemExit(3)
    raise SystemExit(0 if all(receipt['expected_status_observed'] and not receipt['timed_out'] for receipt in receipts) else 1)

if __name__ == '__main__':
    main()
