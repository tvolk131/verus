import copy
import itertools
from dataclasses import dataclass, field

INITIAL = (0, 2, 1, 0, 0)
PREPARED = (0, 2, 3)
PUBLISHED = (1, 2, 3)
UNKNOWN = -1
HEADER = 0
PAYLOAD = 4

def masks(length):
    return itertools.product((False, True), repeat=length)

def persistent_images(durable, visible):
    choices = [tuple(sorted(set((old, new)))) for old, new in zip(durable, visible)]
    return tuple(itertools.product(*choices))

def partial_write_images(before, offset, data):
    choices = [tuple(sorted(set((before[offset + index], value, UNKNOWN))))
               for index, value in enumerate(data)]
    for replacement in itertools.product(*choices):
        image = list(before)
        image[offset:offset + len(data)] = replacement
        yield tuple(image)

def inspect_image(image):
    selector = image[0]
    if selector not in (0, 1):
        return dict(selected='unknown', secondary='unknown', recovery='NOT_MODELLED')
    selected = image[1 + selector]
    secondary = image[2 - selector]
    return dict(selected={1: 'stale', 2: 'old', 3: 'new'}.get(selected, 'unknown'),
                secondary={1: 'valid_stale', 2: 'old', 3: 'freshly_prepared'}.get(secondary, 'unknown'),
                recovery='NOT_MODELLED')

@dataclass
class Storage:
    pending: dict = field(default_factory=dict)
    visible: tuple = INITIAL
    durable: tuple = INITIAL
    events: list = field(default_factory=list)
    failed: bool = False

    def event(self, action, **details):
        self.events.append(dict(action=action, **details, state=self.state()))

    def enqueue(self, stripe, offset, data, lose_latest=False):
        entries = self.pending.setdefault(stripe, {})
        if not lose_latest or offset not in entries:
            entries[offset] = tuple(data)
        self.event('enqueue', stripe=stripe, offset=offset, data=list(data))

    def flush(self, label, stripe_order=(0, 1), entry_orders=None, fail_write=None,
              error_image=None, sync_error=False, progress_index=0, drain_on_error=False):
        if self.failed:
            self.event('latched_error', label=label)
            return 'Err'
        write_index = 0
        for stripe in stripe_order:
            entries = self.pending.get(stripe, {})
            order = list(entries) if entry_orders is None else list(entry_orders.get(stripe, entries))
            for offset in order:
                data = entries[offset]
                self.event('write_attempt', label=label, stripe=stripe, offset=offset, data=list(data))
                if write_index == fail_write:
                    self.visible = tuple(error_image) if error_image is not None else self.visible
                    options = persistent_images(self.durable, self.visible)
                    self.durable = options[progress_index % len(options)]
                    self.failed = True
                    if drain_on_error:
                        entries.clear()
                    self.event('write_error', label=label, stripe=stripe, offset=offset)
                    return 'Err'
                image = list(self.visible)
                image[offset:offset + len(data)] = data
                self.visible = tuple(image)
                self.event('write_ok', label=label, stripe=stripe, offset=offset)
                write_index += 1
            entries.clear()
            self.event('drain_stripe', label=label, stripe=stripe)
        self.event('sync_attempt', label=label)
        if sync_error:
            options = persistent_images(self.durable, self.visible)
            self.durable = options[progress_index % len(options)]
            self.failed = True
            self.event('sync_error', label=label)
            return 'Err'
        self.durable = self.visible
        self.event('barrier_ok', label=label)
        return 'Ok'

    def state(self):
        return dict(pending={str(stripe): {str(offset): list(data) for offset, data in entries.items()}
                             for stripe, entries in self.pending.items()},
                    visible=list(self.visible), durable=list(self.durable), failed=self.failed)

OPAQUE_PREPARE = (
    'flush_user_tables', 'store_data_freed', 'store_pending_data_freed',
    'hold_free_horizon', 'oldest_active_transaction', 'process_freed_pages',
    'flush_data_allocated_pages', 'flush_system_roots', 'delete_allocator_table',
    'quick_repair_callback', 'finalize_dirty_checksums',
)
OPAQUE_EPILOGUE = (
    'epilogue_extract', 'epilogue_flush_root', 'epilogue_store_system',
    'epilogue_finalize_checksums', 'epilogue_non_durable_commit', 'epilogue_register',
)
FAILPOINTS = OPAQUE_PREPARE + (
    'check_io_errors', 'hold_prepare', 'admit_prepare', 'prepare_write', 'prepare_sync',
    'hold_publish', 'admit_publish', 'publish_write', 'publish_sync',
) + OPAQUE_EPILOGUE

@dataclass(frozen=True)
class Program:
    name: str = 'corrected_reference'
    first_barrier: bool = True
    premature_ack: bool = False
    lose_latest: bool = False
    rollback_error: bool = False

def run_commit(program=Program(), failpoint=None, progress_index=0, write_error_image=None,
               opaque_unknown=None, epilogue=True, quick_repair=False, pending_records=False):
    storage = Storage()
    snapshots = []
    outcome = None

    def capture():
        snapshots.append(dict(after_event=len(storage.events), **storage.state()))

    def fail(name):
        nonlocal outcome
        if opaque_unknown == name:
            storage.event('opaque_effect_unbound', callback=name)
            outcome = 'OPEN_CALLBACK_EFFECT'
            capture()
            return True
        if failpoint == name:
            storage.event('fallible_error', callback=name,
                          qualification='one finite witness; arbitrary callback effects OPEN')
            outcome = 'Err'
            if program.rollback_error:
                storage.visible = INITIAL
                storage.durable = INITIAL
                storage.pending.clear()
                storage.event('WRONG_rollback_on_error')
            capture()
            return True
        storage.event('fallible_ok', callback=name,
                      qualification='conditional witness; callback native binding OPEN')
        capture()
        return False

    capture()
    storage.event('public_completed_flag')
    storage.event('poison_check_ok')
    storage.event('allocator_latch_armed')
    for name in OPAQUE_PREPARE:
        if name == 'quick_repair_callback' and not quick_repair:
            continue
        if name == 'store_pending_data_freed' and not pending_records:
            continue
        if fail(name):
            return dict(program=program.name, result=outcome, failpoint=failpoint,
                        events=storage.events, snapshots=snapshots, final=storage.state())
    storage.enqueue(1, PAYLOAD, (7,))
    capture()
    for name in ('check_io_errors', 'hold_prepare', 'admit_prepare'):
        if fail(name):
            return dict(program=program.name, result=outcome, failpoint=failpoint,
                        events=storage.events, snapshots=snapshots, final=storage.state())
    storage.event('prepare_slot')
    storage.enqueue(0, HEADER, PREPARED, program.lose_latest)
    capture()
    for phase in ('prepare', 'publish'):
        if phase == 'publish':
            storage.event('publish_selector')
            capture()
            if program.premature_ack:
                storage.event('Ack')
                capture()
                outcome = 'Ok'
                break
            for name in ('hold_publish', 'admit_publish'):
                if fail(name):
                    break
            if outcome is not None:
                break
            storage.enqueue(0, HEADER, PUBLISHED, program.lose_latest)
            capture()
        if phase == 'prepare' and not program.first_barrier:
            storage.event('WRONG_omitted_prepare_barrier')
            capture()
            continue
        result = storage.flush(phase, fail_write=0 if failpoint == phase + '_write' else None,
                               error_image=write_error_image, sync_error=failpoint == phase + '_sync',
                               progress_index=progress_index)
        capture()
        if result == 'Err':
            outcome = 'Err'
            if program.rollback_error:
                storage.visible = INITIAL
                storage.durable = INITIAL
                storage.pending.clear()
                storage.event('WRONG_rollback_on_error')
                capture()
            break
    if outcome is None:
        storage.event('install_manager_state')
        storage.event('opaque_post_publication_callbacks',
                      qualification='tracker/free/savepoint effects and panic/resource behavior OPEN')
        capture()
        if opaque_unknown == 'post_publication_callbacks':
            storage.event('opaque_effect_unbound', callback=opaque_unknown)
            outcome = 'OPEN_CALLBACK_EFFECT'
            capture()
        elif epilogue:
            for name in OPAQUE_EPILOGUE:
                if fail(name):
                    break
        if outcome is None:
            storage.event('public_postconditions_checked')
            storage.event('allocator_latch_disarmed')
            storage.event('Ack')
            outcome = 'Ok'
            capture()
    return dict(program=program.name, result=outcome, failpoint=failpoint,
                events=storage.events, snapshots=snapshots, final=storage.state())

def violations(run):
    events = run['events']
    failures = []
    prepare = [index for index, event in enumerate(events)
               if event['action'] == 'barrier_ok' and event.get('label') == 'prepare']
    publish = [index for index, event in enumerate(events) if event['action'] == 'publish_selector']
    final_barriers = [index for index, event in enumerate(events)
                      if event['action'] == 'barrier_ok' and event.get('label') == 'publish']
    acknowledgements = [index for index, event in enumerate(events) if event['action'] == 'Ack']
    if publish and (not prepare or prepare[0] >= publish[0]):
        failures.append('prepared_barrier_missing_before_selector')
    if acknowledgements and (not final_barriers or final_barriers[-1] >= acknowledgements[0]):
        failures.append('Ack_before_required_successful_barrier')
    for index, event in enumerate(events):
        if event['action'] == 'write_error' and any(
                later['action'] == 'sync_attempt' and later.get('label') == event.get('label')
                for later in events[index + 1:]):
            failures.append('sync_after_write_error')
    if run['result'] == 'Ok' and inspect_image(run['final']['durable'])['selected'] != 'new':
        failures.append('Ack_without_new_durable_selected_image')
    return failures

def crash_observations(snapshot):
    visible = tuple(snapshot['visible'])
    durable = tuple(snapshot['durable'])
    yield dict(mode='process_restart', image=list(visible), **inspect_image(visible),
               qualification='process memory lost; same surviving backend image assumed; no reopen proof')
    for image in persistent_images(durable, visible):
        yield dict(mode='power_loss', image=list(image), **inspect_image(image),
                   qualification='finite per-cell persistence abstraction; recovery/atomicity OPEN')

def storage_cases():
    cases = []
    for stripe_order in itertools.permutations((0, 1)):
        for own_order in itertools.permutations((0, 3)):
            for failure_index in (None, 0, 1, 2):
                seed = Storage()
                seed.enqueue(0, 0, (1, 2, 3))
                seed.enqueue(0, 3, (8,))
                seed.enqueue(1, 4, (7,))
                ordered = [(stripe, offset) for stripe in stripe_order
                           for offset in (own_order if stripe == 0 else (4,))]
                before = INITIAL
                if failure_index is not None:
                    for stripe, offset in ordered[:failure_index]:
                        image = list(before)
                        data = seed.pending[stripe][offset]
                        image[offset:offset + len(data)] = data
                        before = tuple(image)
                    stripe, offset = ordered[failure_index]
                    images = tuple(partial_write_images(before, offset, seed.pending[stripe][offset]))
                else:
                    images = (None,)
                for error_image in images:
                    progress = range(len(persistent_images(INITIAL, error_image))) if error_image is not None else range(1)
                    for progress_index in progress:
                        storage = copy.deepcopy(seed)
                        result = storage.flush('finite_storage', stripe_order, {0: own_order, 1: (4,)},
                                               failure_index, error_image, progress_index=progress_index)
                        cases.append(dict(id='storage-%04d' % len(cases), stripe_order=list(stripe_order),
                                          own_order=list(own_order), failure_index=failure_index,
                                          error_image=error_image, progress_index=progress_index,
                                          result=result, events=storage.events, final=storage.state(),
                                          ordered_writes=[list(item) for item in ordered]))
    return cases

def commit_cases():
    cases = []
    for failpoint in (None,) + FAILPOINTS:
        options = dict(quick_repair=failpoint == 'quick_repair_callback',
                       pending_records=failpoint == 'store_pending_data_freed')
        if failpoint in ('prepare_write', 'publish_write'):
            before = tuple(run_commit(failpoint=failpoint, **options)['final']['visible'])
            previous_durable = tuple(run_commit(failpoint=failpoint, **options)['final']['durable'])
            data = PREPARED if failpoint == 'prepare_write' else PUBLISHED
            error_images = partial_write_images(before, 0, data)
        else:
            error_images = (None,)
        for error_image in error_images:
            if error_image is not None:
                progress = range(len(persistent_images(previous_durable, error_image)))
            else:
                progress = range(32) if failpoint in ('prepare_sync', 'publish_sync') else range(1)
            for progress_index in progress:
                run = run_commit(failpoint=failpoint, progress_index=progress_index,
                                 write_error_image=error_image, **options)
                run.update(id='commit-%03d' % len(cases), progress_index=progress_index,
                           write_error_image=error_image, branch_options=options)
                cases.append(run)
    for name in OPAQUE_PREPARE + OPAQUE_EPILOGUE + ('post_publication_callbacks',):
        run = run_commit(opaque_unknown=name, quick_repair=name == 'quick_repair_callback',
                         pending_records=name == 'store_pending_data_freed')
        run.update(id='opaque-%03d' % len(cases), opaque_unknown=name)
        cases.append(run)
    return cases
