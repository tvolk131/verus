import datetime
import hashlib
import json
from pathlib import Path
import shutil
import tarfile


ROOT = Path('/private/tmp/redb-storage109-independent-controls-vKPHDj8s')
DESTINATION = Path('/Users/tommyvolk/.t3/worktrees/verus/t3-60978068/evidence/redb-storage-refinement109')


def sha256(filename):
    return hashlib.sha256(filename.read_bytes()).hexdigest()


assert sha256(ROOT / 'MANIFEST.json') == '764153f9e8b0b6d6f5738d1e16a38bcd9e3b4fd6552cead8161c4db6d714d01e'
assert sha256(ROOT / 'handoff.tar.gz') == '961fecdf8c77c350eef61fc2c84d501727d8117abcecde04451e0bfbbedf54c5'
records = json.loads((ROOT / 'MANIFEST.json').read_text())['files']
expected = set()
for record in records:
    relative = Path(record['path'])
    assert not relative.is_absolute() and '..' not in relative.parts
    filename = ROOT / relative
    assert not filename.is_symlink() and filename.is_file()
    assert filename.stat().st_size == record['bytes'] and sha256(filename) == record['sha256']
    expected.add(record['path'])
assert len(expected) == len(records) == 133
with tarfile.open(ROOT / 'handoff.tar.gz', 'r:gz') as archive:
    members = archive.getmembers()
    assert len(members) == 135
    assert {member.name for member in members} == expected | {'MANIFEST.json', 'MANIFEST.sha256'}
    for member in members:
        assert member.isfile() and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
        assert archive.extractfile(member).read() == (ROOT / member.name).read_bytes(), member.name

frozen = json.loads((DESTINATION / 'INPUTS.json').read_text())['records']
drift = [record['path'] for record in frozen if sha256(Path(record['path'])) != record['sha256']]
assert not drift, drift
copies = {
    'REPORT.md': 'INDEPENDENT-CONTROLS-REPORT.md',
    'BRANCH_COVERAGE.md': 'INDEPENDENT-CONTROLS-COVERAGE.md',
    'expected_outcomes.json': 'INDEPENDENT-CONTROLS-EXPECTED.json',
    'handoff.tar.gz': 'INDEPENDENT-CONTROLS-HANDOFF.tar.gz',
}
for source, target in copies.items():
    assert not (DESTINATION / target).exists()
    shutil.copyfile(ROOT / source, DESTINATION / target)
    assert (ROOT / source).read_bytes() == (DESTINATION / target).read_bytes()

result = {
    'schema': 'redb-storage109-independent-controls-retention-v1',
    'retained_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'source': str(ROOT), 'manifest_sha256': sha256(ROOT / 'MANIFEST.json'),
    'archive_sha256': sha256(ROOT / 'handoff.tar.gz'), 'authenticated_payloads': len(records),
    'archive_members_byte_compared': 135, 'current_frozen_input_matches': len(frozen),
    'historical_drift_count_still_disclosed': 5,
    'report_sha256': sha256(ROOT / 'REPORT.md'),
    'expected_outcomes_sha256': sha256(ROOT / 'expected_outcomes.json'),
    'tests': 21, 'storage_cases': 844, 'commit_and_opaque_cases': 195,
    'crash_observations': 12644, 'semantic_mutant_corrected_pairs': 6,
    'source_mutant_corrected_pairs': 7, 'scope': 'FINITE_CONTROLS_NOT_NATIVE_PROOF',
    'candidate_independent_review': 'PENDING_PROOF_CANDIDATE_HANDOFFS',
    'acceptance': False, 'trust_adoption': False, 'integration': False, 'redb_open_cells': 18,
    'child_final_status': json.loads((ROOT / 'FINAL_STATUS.json').read_text()),
}
(DESTINATION / 'INDEPENDENT-CONTROLS-RESULTS.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
print(json.dumps({key: result[key] for key in ['authenticated_payloads', 'archive_members_byte_compared', 'current_frozen_input_matches', 'archive_sha256', 'report_sha256', 'expected_outcomes_sha256']}, indent=2))
