import datetime
import hashlib
import json
from pathlib import Path
import shutil
import tarfile


ROOT = Path('/private/tmp/redb-storage109-review-QFf6FvBP')
PARENT = Path('/Users/tommyvolk/.t3/worktrees/verus/t3-60978068')
DESTINATION = PARENT / 'evidence/redb-storage-refinement109'


def sha256(filename):
    return hashlib.sha256(filename.read_bytes()).hexdigest()


assert sha256(ROOT / 'handoff.tar.gz') == '6e390c54f0c89696be954839cb1079f5a03cbf0c6465cba9b3b05959c4559b5d'
handoff = json.loads((ROOT / 'HANDOFF.json').read_text())
assert sha256(ROOT / 'MANIFEST.json') == handoff['manifest_sha256']
assert sha256(ROOT / 'SEAL.json') == handoff['seal_sha256']
seal = json.loads((ROOT / 'SEAL.json').read_text())
assert sha256(ROOT / 'REPORT.md') == seal['report_sha256']
records = json.loads((ROOT / 'MANIFEST.json').read_text())['files']
assert len({record['path'] for record in records}) == len(records) == 90
for record in records:
    relative = Path(record['path'])
    assert not relative.is_absolute() and '..' not in relative.parts
    filename = ROOT / relative
    assert filename.is_file() and not filename.is_symlink()
    assert filename.stat().st_size == record['bytes']
    assert sha256(filename) == record['sha256']
expected_members = {record['path'] for record in records} | {'MANIFEST.json', 'SEAL.json'}
with tarfile.open(ROOT / 'handoff.tar.gz', 'r:gz') as archive:
    members = archive.getmembers()
    assert len(members) == len(expected_members) == 92
    assert {member.name for member in members} == expected_members
    for member in members:
        assert member.isfile() and not Path(member.name).is_absolute()
        assert '..' not in Path(member.name).parts
        assert archive.extractfile(member).read() == (ROOT / member.name).read_bytes()
frozen = json.loads((DESTINATION / 'INPUTS.json').read_text())['records']
assert all(sha256(Path(record['path'])) == record['sha256'] for record in frozen)
exit_authentication = json.loads((ROOT / 'authentication-exit.json').read_text())
assert exit_authentication['failures'] == []
assert len(exit_authentication['records']) == 783
for source, target in {
    'REPORT.md': 'INDEPENDENT-REVIEW.md',
    'handoff.tar.gz': 'INDEPENDENT-REVIEW-HANDOFF.tar.gz',
    'HANDOFF.json': 'INDEPENDENT-REVIEW-METADATA.json',
}.items():
    assert not (DESTINATION / target).exists()
    shutil.copyfile(ROOT / source, DESTINATION / target)
    assert sha256(DESTINATION / target) == sha256(ROOT / source)
historical_documents = {}
for document, target in {
    'GOAL.md': 'HISTORICAL-GOAL.md',
    'STATUS.json': 'HISTORICAL-STATUS.json',
}.items():
    source = PARENT / 'evidence/redb-crash-consistency94' / document
    assert not (DESTINATION / target).exists()
    shutil.copyfile(source, DESTINATION / target)
    assert sha256(source) == sha256(DESTINATION / target)
    historical_documents[str(source)] = {
        'snapshot': target,
        'sha256': sha256(source),
    }
checks = []
for directory in sorted(ROOT.glob('check-*')):
    status = json.loads((directory / 'status.json').read_text())
    assert status['launched'] and not status['timed_out']
    expected_success = directory.name in {'check-01', 'check-03', 'check-04', 'check-06'}
    assert status['export_exists'] == expected_success
    assert status['returncode'] == (0 if expected_success else 1)
    checks.append({'check': directory.name, **status})
assert len(checks) == 6
result = {
    'schema': 'redb-storage109-combined-review-retention-v1',
    'retained_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'verdict': 'NO_INVALID_BOUNDED_MODEL_THEOREM_IDENTIFIED_NATIVE_LINKAGE_OPEN',
    'source': str(ROOT),
    'authenticated_payloads': len(records),
    'archive_members_byte_compared': len(expected_members),
    'archive_sha256': handoff['archive_sha256'],
    'manifest_sha256': handoff['manifest_sha256'],
    'report_sha256': seal['report_sha256'],
    'review_exit_authenticated_paths': len(exit_authentication['records']),
    'review_exit_mismatches': 0,
    'current_frozen_input_matches_before_parent_reconciliation': len(frozen),
    'historical_documents_before_reconciliation': historical_documents,
    'charged_attempts': 6,
    'verifier_launches': 6,
    'checks': checks,
    'controls_tests_replayed': 21,
    'controls_regenerated_products_byte_identical': 7,
    'buffered_proof_bodies': 26,
    'buffered_verified_obligations': 31,
    'acknowledgement_proof_bodies': 15,
    'acknowledgement_verified_obligations': 16,
    'consumer_proof_bodies_historically_checked_not_fresh_replayed': 17,
    'consumer_verified_obligations_historically_checked': 18,
    'native_executable_bodies_checked': 0,
    'publication_correction': 'ACK-PUBLICATION-CORRECTION.json',
    'bootstrap_provenance': 'QUALIFIED_NO_EXHAUSTIVE_OR_ATOMIC_FIRST_USE_CLAIM',
    'conditional_models_have_identical_transition_domains': False,
    'native_adapter_R': 'OPEN',
    'acceptance': False,
    'integration': False,
    'trust_adoption': False,
    'redb_open_cells': 18,
}
(DESTINATION / 'INDEPENDENT-REVIEW-RESULTS.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
print(json.dumps({key: result[key] for key in ('verdict', 'authenticated_payloads', 'archive_members_byte_compared', 'review_exit_authenticated_paths', 'current_frozen_input_matches_before_parent_reconciliation', 'archive_sha256')}, indent=2))
