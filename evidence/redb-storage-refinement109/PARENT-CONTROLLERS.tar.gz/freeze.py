import datetime
import hashlib
import json
from pathlib import Path
import shutil


ROOT = Path(__file__).resolve().parent
PARENT = Path('/Users/tommyvolk/.t3/worktrees/verus/t3-60978068')
DESTINATION = PARENT / 'evidence/redb-storage-refinement109'
BASE = Path('/private/tmp/verus-crash-consistency94-20261105/native-leaf-lookup-007')


def identity(filename):
    content = filename.read_bytes()
    return {'path': str(filename), 'bytes': len(content), 'sha256': hashlib.sha256(content).hexdigest()}


records = {}
historical_drift = []
bindings = json.loads((PARENT / 'evidence/redb-branch-leaf-completion103/INPUT-BINDINGS.json').read_text())['current_bindings']
for binding in bindings:
    filename = Path(binding['path'])
    current = identity(filename)
    current['historical_sha256'] = binding['sha256']
    current['matches_historical'] = current['sha256'] == binding['sha256']
    if not current['matches_historical']:
        historical_drift.append(str(filename))
    if '/midpoint-runtime-proposal/runtime/' in str(filename):
        assert current['matches_historical'], str(filename)
    records[str(filename)] = current

native_rechecked = []
prior = json.loads(Path('/private/tmp/redb-protocol108.ILh6YU/INPUTS.json').read_text())['files']
native_root = BASE / 'recovered-native/redb'
for record in prior:
    filename = Path(record['path'])
    if filename.is_relative_to(native_root):
        current = identity(filename)
        assert current['sha256'] == record['sha256'] and current['bytes'] == record['size_bytes'], str(filename)
        native_rechecked.append(str(filename))
        records[str(filename)] = current

extra = [
    PARENT / 'evidence/redb-storage-refinement109/PLAN.md',
    PARENT / 'evidence/redb-critical-path108/PROTOCOL-REPORT.md',
    PARENT / 'evidence/redb-critical-path108/FIRST-CELL-REPORT.md',
    PARENT / 'evidence/redb-crash-consistency94/SCOPE.md',
    PARENT / 'evidence/redb-crash-consistency94/GOAL.md',
    PARENT / 'evidence/redb-crash-consistency94/RECOVERY-SELECTOR-INDEPENDENT-REVIEW.md',
    PARENT / 'evidence/redb-crash-consistency94/RECOVERY-REENCODING-INDEPENDENT-REVIEW.md',
    PARENT / 'evidence/redb-branch-leaf-completion103/INPUT-BINDINGS.json',
    Path('/private/tmp/branch-leaf-composition102-impl-SqXAof8z/attempt-003/invocation.json'),
    BASE / 'recovery.json', BASE / 'recovery-initial-blobs.json',
]
extra += sorted((PARENT / 'source/tools/redb_crash_consistency94').glob('*.rs'))
extra += [native_root / 'src/tree_store/page_store' / name for name in [
    'backends.rs', 'lru_cache.rs', 'file_backend/mod.rs', 'file_backend/optimized.rs', 'file_backend/fallback.rs', 'base.rs',
]]
extra += [Path('/Users/tommyvolk/.rustup/toolchains/1.99.1-aarch64-apple-darwin/bin') / name for name in ['rustc', 'rustdoc', 'cargo']]
extra += [Path('/usr/bin/python3'), ROOT / 'freeze.py']
for filename in extra:
    records[str(filename)] = identity(filename)

captured = datetime.datetime.now(datetime.timezone.utc).isoformat()
manifest = {
    'schema': 'redb-storage109-frozen-selected-inputs-v1', 'captured_utc': captured,
    'first_read_or_atomic_snapshot_claim': False, 'compiler_source_correspondence': 'UNESTABLISHED',
    'source_path_preservation': 'FAILED_INHERITED', 'native_git_continuity': 'UNAVAILABLE_INHERITED',
    'historical_binding_records': len(bindings), 'historical_drift': historical_drift,
    'native_inputs_rechecked_against_prior_authenticated_records': native_rechecked,
    'records': [records[name] for name in sorted(records)],
}
(DESTINATION / 'INPUTS.json').write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
authorization = {
    'user_approval': 'Absolutely!', 'scope': '60min_4GiB_scratch_only_native_storage_refinement_implementation_review',
    'round_start_utc': '2026-11-08T03:35:26Z', 'hard_deadline_utc': '2026-11-08T04:35:26Z',
    'optional_work_stop_utc': '2026-11-08T04:23:26Z', 'no_compiler_runtime_builds': True,
    'no_new_trust_adoption': True, 'no_weakened_gates': True, 'diagnostic107_D1_authorized': False,
    'all18': 'OPEN', 'global_free_bytes_at_freeze': shutil.disk_usage(ROOT).free,
    'plan': identity(DESTINATION / 'PLAN.md'), 'inputs': identity(DESTINATION / 'INPUTS.json'),
}
(DESTINATION / 'AUTHORIZATION.json').write_text(json.dumps(authorization, indent=2, sort_keys=True) + '\n')
print(json.dumps({'captured_utc': captured, 'frozen_records': len(records), 'historical_drift': historical_drift, 'native_records_rechecked': len(native_rechecked), 'inputs_sha256': authorization['inputs']['sha256'], 'plan_sha256': authorization['plan']['sha256']}, indent=2))
