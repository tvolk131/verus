import datetime
import hashlib
import json
from pathlib import Path
import shutil
import tarfile


ROOT = Path('/private/tmp/redb-storage109-lane2-wqh8Ege8')
PARENT = Path('/Users/tommyvolk/.t3/worktrees/verus/t3-60978068')
DESTINATION = PARENT / 'evidence/redb-storage-refinement109'


def sha256(filename):
    return hashlib.sha256(filename.read_bytes()).hexdigest()


assert sha256(ROOT / 'MANIFEST.json') == '2ceca5762e9c983e2ed6a2f48ee0efee0f89237500c6c3898f987346f52ae053'
assert sha256(ROOT / 'ack_cfg.rs') == '447a7fcfa23fcdec6114be0ec4eb27274ed4133efbc7d81fdac896dffd9306a2'
records = json.loads((ROOT / 'MANIFEST.json').read_text())['files']
for record in records:
    relative = Path(record['path'])
    assert not relative.is_absolute() and '..' not in relative.parts
    filename = ROOT / relative
    assert not filename.is_symlink() and filename.is_file()
    assert filename.stat().st_size == record['bytes'] and sha256(filename) == record['sha256']
assert len({record['path'] for record in records}) == len(records) == 111
frozen = json.loads((DESTINATION / 'INPUTS.json').read_text())['records']
assert all(sha256(Path(record['path'])) == record['sha256'] for record in frozen)

archive_path = DESTINATION / 'ACK-CANDIDATE-HANDOFF.tar.gz'
assert not archive_path.exists()
with tarfile.open(archive_path, 'w:gz') as archive:
    for relative in [record['path'] for record in records] + ['MANIFEST.json', 'SEAL.json']:
        archive.add(ROOT / relative, arcname=relative, recursive=False)
with tarfile.open(archive_path, 'r:gz') as archive:
    members = archive.getmembers()
    assert len(members) == 113
    for member in members:
        assert member.isfile() and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
        assert archive.extractfile(member).read() == (ROOT / member.name).read_bytes()

for source, target in {
    'REPORT.md': 'ACK-CANDIDATE-REPORT.md', 'MATRIX.md': 'ACK-CANDIDATE-COVERAGE.md',
    'ADAPTER.md': 'ACK-CANDIDATE-ADAPTER.md', 'ack_cfg.rs.patch': 'ACK-CANDIDATE.patch',
}.items():
    assert not (DESTINATION / target).exists()
    shutil.copyfile(ROOT / source, DESTINATION / target)
    assert (ROOT / source).read_bytes() == (DESTINATION / target).read_bytes()

attempts = json.loads((ROOT / 'RESULTS.json').read_text())
publication = []
for attempt in attempts:
    arguments = attempt.get('argv', [])
    export = arguments[arguments.index('--export') + 1] if '--export' in arguments else None
    publication.append({'attempt': attempt['attempt'], 'export_requested': export, 'historical_interface_written': attempt.get('interface_written')})
interfaces = [{'path': str(ROOT / name), 'bytes': (ROOT / name).stat().st_size, 'sha256': sha256(ROOT / name)} for name in ['ack_cfg109.vir', 'consumer109.vir']]
correction = {
    'schema': 'redb-storage109-parent-publication-correction-v1',
    'finding': 'RUNNER_SCANS_ATTEMPT_DIRECTORY_BUT_EXPORT_ARGUMENT_TARGETS_ROOT',
    'original_candidate_and_report_unchanged': True,
    'observed_root_interfaces': interfaces,
    'correction': 'The two root .vir files are sealed binary payloads. The report/handoff statement that no .vir was emitted is incorrect; per-attempt interface_written=false did not inspect the requested export destinations.',
    'negative_control_limit': 'The four semantic negative invocations did not request export. They establish localized verification failures, not fresh requested-export refusal. No earlier root-artifact creation timestamp or historical rewrite status is reconstructed from this final observation.',
    'scope_unchanged': 'No .rlib or binary-import check established. Public source-module consumer is checked; root .vir presence is not native acceptance, trusted producer, native body verification or a complete artifact pair.',
    'fresh_review_check': 'Use fresh explicit export destinations on positive/negative/restored verifier rechecks and record those exact paths.',
    'publication_rows': publication,
}
(DESTINATION / 'ACK-PUBLICATION-CORRECTION.json').write_text(json.dumps(correction, indent=2, sort_keys=True) + '\n')
result = {
    'schema': 'redb-storage109-ack-candidate-retention-v1',
    'retained_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'source': str(ROOT), 'manifest_sha256': sha256(ROOT / 'MANIFEST.json'),
    'report_sha256': sha256(ROOT / 'REPORT.md'), 'source_sha256': sha256(ROOT / 'ack_cfg.rs'),
    'archive_sha256': sha256(archive_path), 'authenticated_payloads': 111,
    'archive_members_byte_compared': 113, 'current_frozen_input_matches': len(frozen),
    'historical_drifts_retained': 5, 'verifier_applications': 14,
    'checked_proof_bodies': 15, 'consumer_checked_proof_bodies': 17,
    'native_executable_bodies_checked': 0, 'semantic_negatives': 4,
    'independent_review': 'PENDING_BOTH_PROOF_CANDIDATES',
    'publication_correction': 'ACK-PUBLICATION-CORRECTION.json',
    'acceptance': False, 'integration': False, 'trust_adoption': False, 'redb_open_cells': 18,
}
(DESTINATION / 'ACK-CANDIDATE-RESULTS.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
print(json.dumps({key: result[key] for key in ['authenticated_payloads', 'archive_members_byte_compared', 'current_frozen_input_matches', 'archive_sha256']}, indent=2))
print('Publication report corrected in parent overlay; original sealed report preserved.')
