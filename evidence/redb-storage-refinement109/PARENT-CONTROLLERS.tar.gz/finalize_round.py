import datetime
import hashlib
import json
from pathlib import Path
import shutil
import tarfile


PARENT = Path('/Users/tommyvolk/.t3/worktrees/verus/t3-60978068')
DESTINATION = PARENT / 'evidence/redb-storage-refinement109'
CONTROLLERS = Path('/private/tmp/redb-storage109-jOy47i')
ROOTS = {
    'buffered': Path('/private/tmp/redb-storage109-lane1-20261108T034224Z'),
    'acknowledgement': Path('/private/tmp/redb-storage109-lane2-wqh8Ege8'),
    'controls': Path('/private/tmp/redb-storage109-independent-controls-vKPHDj8s'),
    'review': Path('/private/tmp/redb-storage109-review-QFf6FvBP'),
    'parent_controllers': CONTROLLERS,
    'retained_evidence': DESTINATION,
}


def sha256(filename):
    return hashlib.sha256(filename.read_bytes()).hexdigest()


def file_bytes(root):
    return sum(filename.stat().st_size for filename in root.rglob('*') if filename.is_file())


authorization = json.loads((DESTINATION / 'AUTHORIZATION.json').read_text())
assert sha256(DESTINATION / 'PLAN.md') == authorization['plan']['sha256']
assert sha256(DESTINATION / 'INPUTS.json') == authorization['inputs']['sha256']
review = json.loads((DESTINATION / 'INDEPENDENT-REVIEW-RESULTS.json').read_text())
snapshots = review['historical_documents_before_reconciliation']
selected = json.loads((DESTINATION / 'INPUTS.json').read_text())
expected_drift = []
unchanged = []
for record in selected['records']:
    filename = Path(record['path'])
    observed = sha256(filename)
    if str(filename) in snapshots:
        snapshot = snapshots[str(filename)]
        assert sha256(DESTINATION / snapshot['snapshot']) == record['sha256'] == snapshot['sha256']
        assert observed != record['sha256']
        expected_drift.append({
            'path': str(filename), 'frozen_sha256': record['sha256'],
            'reconciled_sha256': observed, 'snapshot': snapshot['snapshot'],
            'reason': 'Parent documentation reconciliation after all implementation/review exits',
        })
    else:
        assert observed == record['sha256'], str(filename)
        unchanged.append(str(filename))
assert len(expected_drift) == 2 and len(unchanged) == 367
authenticated_payloads = {}
for label in ('buffered', 'acknowledgement', 'controls', 'review'):
    root = ROOTS[label]
    manifest = json.loads((root / 'MANIFEST.json').read_text())
    records = manifest if isinstance(manifest, list) else manifest['files']
    for record in records:
        filename = root / record['path']
        assert filename.is_file() and not filename.is_symlink()
        assert sha256(filename) == record['sha256'], str(filename)
    authenticated_payloads[label] = len(records)
assert authenticated_payloads == {'buffered': 93, 'acknowledgement': 111, 'controls': 133, 'review': 90}
for retention in ('BUFFERED-CANDIDATE-RESULTS.json', 'ACK-CANDIDATE-RESULTS.json', 'INDEPENDENT-CONTROLS-RESULTS.json', 'INDEPENDENT-REVIEW-RESULTS.json'):
    result = json.loads((DESTINATION / retention).read_text())
    archive = {
        'BUFFERED-CANDIDATE-RESULTS.json': 'BUFFERED-CANDIDATE-HANDOFF.tar.gz',
        'ACK-CANDIDATE-RESULTS.json': 'ACK-CANDIDATE-HANDOFF.tar.gz',
        'INDEPENDENT-CONTROLS-RESULTS.json': 'INDEPENDENT-CONTROLS-HANDOFF.tar.gz',
        'INDEPENDENT-REVIEW-RESULTS.json': 'INDEPENDENT-REVIEW-HANDOFF.tar.gz',
    }[retention]
    assert sha256(DESTINATION / archive) == result['archive_sha256']
status = json.loads((PARENT / 'evidence/redb-crash-consistency94/STATUS.json').read_text())
assert not status['whole_goal_acceptance']
assert status['pending_independent_review_tasks'] == []
assert len(status['completion_properties']) * len(status['required_histories']) == 18
assert status['native_storage_refinement109'].startswith('COMPLETE_CONDITIONAL_')
controller_archive = DESTINATION / 'PARENT-CONTROLLERS.tar.gz'
assert not controller_archive.exists()
with tarfile.open(controller_archive, 'w:gz') as archive:
    for filename in sorted(CONTROLLERS.glob('*.py')):
        archive.add(filename, arcname=filename.name, recursive=False)
now = datetime.datetime.now(datetime.timezone.utc)
start = datetime.datetime.fromisoformat(authorization['round_start_utc'].replace('Z', '+00:00'))
deadline = datetime.datetime.fromisoformat(authorization['hard_deadline_utc'].replace('Z', '+00:00'))
assert now < deadline
sizes = {label: file_bytes(root) for label, root in ROOTS.items()}
free_bytes = shutil.disk_usage('/private/tmp').free
assert sum(sizes.values()) < 4 * 1024 ** 3
assert free_bytes > 16 * 1024 ** 3
result = {
    'schema': 'redb-storage109-completed-round-v1',
    'status': 'BOUNDED_ROUND_COMPLETE_DATABASE_GOAL_OPEN',
    'start_utc': start.isoformat(),
    'completed_utc': now.isoformat(),
    'hard_deadline_utc': deadline.isoformat(),
    'elapsed_seconds': (now - start).total_seconds(),
    'within_authorized_deadline': True,
    'single_independent_review_completed': True,
    'buffered_verified_obligations': 31,
    'buffered_proof_bodies': 26,
    'acknowledgement_verified_obligations': 16,
    'acknowledgement_proof_bodies': 15,
    'native_executable_bodies_checked': 0,
    'charged_attempts': {'buffered': 13, 'acknowledgement': 14, 'review': 6, 'total': 33},
    'verifier_launches': {'buffered': 12, 'acknowledgement': 14, 'review': 6, 'total': 32},
    'independent_review_checks': {'successful_positive_or_restored': 4, 'semantic_negative': 2, 'requested_exports_written': 4, 'requested_exports_refused': 2},
    'finite_controls': {'tests_pass': 21, 'independent_replay_tests_pass': 21, 'storage_cases': 844, 'commit_or_opaque_cases': 195, 'crash_observations': 12644, 'byte_identical_regenerated_products': 7, 'universal_proof': False},
    'final_payloads_authenticated': authenticated_payloads,
    'selected_inputs': {'total': 369, 'unchanged': 367, 'expected_post_review_document_updates': expected_drift, 'unexpected_mismatches': 0, 'earlier_historical_drifts_still_disclosed': 5},
    'resources': {'sample_utc': now.isoformat(), 'scratch_file_bytes_by_root': sizes, 'scratch_file_bytes_total': sum(sizes.values()), 'scratch_cap_bytes': 4 * 1024 ** 3, 'global_free_bytes': free_bytes, 'global_free_floor_bytes': 16 * 1024 ** 3, 'qualification': 'Boundary samples and logical file bytes, not continuous quotas, peak memory, allocated filesystem blocks or exhaustive dependency closure; results/manifest add small final metadata after this sample'},
    'parent_controller_archive_sha256': sha256(controller_archive),
    'open_native_dependencies': ['actual_admission_and_eviction', 'backend_and_crash_semantics', 'opaque_callback_and_durable_history_frames', 'stateful_cross_model_native_adapter_R', 'resource_allocator_and_abnormal_bindings', 'compiler_source_correspondence', 'all_eighteen_complete_property_history_cells'],
    'historical_publication_correction_preserved': True,
    'no_new_follow_on_work_authorized': True,
    'new_trusted_assumptions_adopted': 0,
    'compiler_runtime_vstd_cargo_builds': 0,
    'native_application_executions': 0,
    'parent_source_integration': False,
    'admission_or_export_gate_changes': False,
    'final_cells_closed': 0,
    'redb_open_cells': 18,
    'acceptance': False,
    'integration': False,
}
(DESTINATION / 'ROUND-RESULTS.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
inventory = []
for filename in sorted(DESTINATION.iterdir()):
    assert filename.is_file() and not filename.is_symlink()
    inventory.append({'path': filename.name, 'bytes': filename.stat().st_size, 'sha256': sha256(filename)})
(DESTINATION / 'ROUND-MANIFEST.json').write_text(json.dumps({'schema': 'redb-storage109-retained-round-files-v1', 'excludes_self': True, 'files': inventory, 'content_authentication_not_acceptance': True}, indent=2, sort_keys=True) + '\n')
print(json.dumps({'completed_utc': result['completed_utc'], 'elapsed_seconds': result['elapsed_seconds'], 'unexpected_input_mismatches': 0, 'expected_post_review_document_updates': len(expected_drift), 'round_payloads': len(inventory), 'sampled_scratch_file_bytes': sum(sizes.values()), 'sampled_global_free_bytes': free_bytes, 'final_cells_closed': 0, 'redb_open_cells': 18}, indent=2))
