import datetime
import hashlib
import json
from pathlib import Path
import shutil
import tarfile


ROOT = Path('/private/tmp/redb-storage109-lane1-20261108T034224Z')
DESTINATION = Path('/Users/tommyvolk/.t3/worktrees/verus/t3-60978068/evidence/redb-storage-refinement109')


def sha256(filename):
    return hashlib.sha256(filename.read_bytes()).hexdigest()


assert sha256(ROOT / 'HANDOFF.json') == 'f92d36f00ca9de1c8561031cb338b430dd2e7459912c5029a80f6ab0cb3b96aa'
handoff = json.loads((ROOT / 'HANDOFF.json').read_text())
assert sha256(ROOT / 'MANIFEST.json') == handoff['manifest_sha256']
records = json.loads((ROOT / 'MANIFEST.json').read_text())['files']
assert len({record['path'] for record in records}) == len(records) == 93
for record in records:
    relative = Path(record['path'])
    assert not relative.is_absolute() and '..' not in relative.parts
    filename = ROOT / relative
    assert filename.is_file() and not filename.is_symlink()
    assert filename.stat().st_size == record['bytes']
    assert sha256(filename) == record['sha256']
frozen = json.loads((DESTINATION / 'INPUTS.json').read_text())['records']
assert all(sha256(Path(record['path'])) == record['sha256'] for record in frozen)
members_expected = sorted({record['path'] for record in records} | {'MANIFEST.json', 'HANDOFF.json', 'SEAL.sha256'})
archive_path = DESTINATION / 'BUFFERED-CANDIDATE-HANDOFF.tar.gz'
assert not archive_path.exists()
with tarfile.open(archive_path, 'w:gz') as archive:
    for relative in members_expected:
        archive.add(ROOT / relative, arcname=relative, recursive=False)
with tarfile.open(archive_path, 'r:gz') as archive:
    members = archive.getmembers()
    assert len(members) == len(members_expected)
    assert {member.name for member in members} == set(members_expected)
    for member in members:
        assert member.isfile() and '..' not in Path(member.name).parts
        assert not Path(member.name).is_absolute()
        assert archive.extractfile(member).read() == (ROOT / member.name).read_bytes()
for source, target in {
    'REPORT.md': 'BUFFERED-CANDIDATE-REPORT.md',
    'CORRESPONDENCE.md': 'BUFFERED-CANDIDATE-CORRESPONDENCE.md',
    'CONTROLS.md': 'BUFFERED-CANDIDATE-CONTROLS.md',
    'candidate.patch': 'BUFFERED-CANDIDATE.patch',
}.items():
    assert not (DESTINATION / target).exists()
    shutil.copyfile(ROOT / source, DESTINATION / target)
    assert sha256(DESTINATION / target) == sha256(ROOT / source)
result = {
    'schema': 'redb-storage109-buffered-candidate-retention-v1',
    'retained_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'source': str(ROOT),
    'source_sha256': handoff['source_sha256'],
    'manifest_sha256': handoff['manifest_sha256'],
    'handoff_sha256': sha256(ROOT / 'HANDOFF.json'),
    'report_sha256': handoff['report_sha256'],
    'archive_sha256': sha256(archive_path),
    'authenticated_payloads': len(records),
    'archive_members_byte_compared': len(members_expected),
    'current_frozen_input_matches': len(frozen),
    'historical_drifts_retained': 5,
    'charged_attempts': 13,
    'verifier_launches': 12,
    'verified_obligations': 31,
    'native_executable_bodies_checked': 0,
    'semantic_mutants': 3,
    'independent_review': 'PENDING_COMBINED_REVIEW',
    'acceptance': False,
    'integration': False,
    'trust_adoption': False,
    'redb_open_cells': 18,
}
(DESTINATION / 'BUFFERED-CANDIDATE-RESULTS.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
print(json.dumps(result, indent=2, sort_keys=True))
