// SPDX-License-Identifier: CC0-1.0
//! Native boundary checks supplement the finite pair verification scope.
use hex_conservative::{decode_to_array, DecodeFixedLengthBytesError};

#[test]
fn array_lengths_mixed_case_and_utf8_bytes() {
    assert_eq!(decode_to_array::<3>("aB01fF").unwrap(), [0xab, 1, 255]);
    assert_eq!(decode_to_array::<0>("").unwrap(), []);
    for s in ["g", "é0", "g000"] {
        let err = decode_to_array::<1>(s).unwrap_err();
        match err {
            DecodeFixedLengthBytesError::InvalidLength(e) => {
                assert_eq!(e.expected, 2); assert_eq!(e.invalid, s.len());
            },
            _ => panic!("length rejection must precede decoding"),
        }
    }
    for (s, pos, byte) in [("é", 0, 0xc3), ("0g", 1, b'g'), ("g?", 0, b'g')] {
        match decode_to_array::<1>(s).unwrap_err() {
            DecodeFixedLengthBytesError::InvalidChar(e) => {
                assert_eq!(e.pos(), pos);
                #[allow(deprecated)]
                { assert_eq!(e.invalid_char(), byte); }
            },
            _ => panic!("expected invalid byte"),
        }
    }
}

#[cfg(feature = "alloc")]
#[test]
fn vector_lengths_values_and_error_precedence() {
    use hex_conservative::{decode_to_vec, DecodeVariableLengthBytesError};
    assert_eq!(decode_to_vec("aB01fF").unwrap(), [0xab, 1, 255]);
    assert_eq!(decode_to_vec("").unwrap(), []);
    match decode_to_vec("é0").unwrap_err() {
        DecodeVariableLengthBytesError::OddLengthString(e) => assert_eq!(e.length(), 3),
        _ => panic!("odd byte length must win"),
    }
    match decode_to_vec("01é").unwrap_err() {
        DecodeVariableLengthBytesError::InvalidChar(e) => {
            assert_eq!(e.pos(), 2);
            #[allow(deprecated)]
            { assert_eq!(e.invalid_char(), 0xc3); }
        },
        _ => panic!("expected invalid UTF-8 byte"),
    }
}
