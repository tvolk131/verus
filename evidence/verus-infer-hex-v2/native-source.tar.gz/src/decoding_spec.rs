// SPDX-License-Identifier: CC0-1.0
//! Authored required behavior, independent of the native lookup table.
use vstd::prelude::*;
verus! {
pub open spec fn table_value(i: int) -> u8 {
    if 48 <= i <= 57 { (i - 48) as u8 }
    else if 65 <= i <= 70 { (i - 65 + 10) as u8 }
    else if 97 <= i <= 102 { (i - 97 + 10) as u8 }
    else { 255 }
}
pub open spec fn digit(b: u8) -> Option<u8> {
    if 48 <= b <= 57 { Some((b - 48) as u8) }
    else if 65 <= b <= 70 { Some((b - 65 + 10) as u8) }
    else if 97 <= b <= 102 { Some((b - 97 + 10) as u8) }
    else { None }
}
pub open spec fn pair(hi: u8, lo: u8) -> Result<u8, (u8, bool)> {
    match digit(hi) {
        None => Err((hi, true)),
        Some(h) => match digit(lo) {
            None => Err((lo, false)),
            Some(l) => Ok((16 * h + l) as u8),
        },
    }
}
}
