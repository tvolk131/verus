from pathlib import Path
root=Path('/Users/tommyvolk/Documents/GitHub/hex-conservative')
p=root/'src/iter.rs';s=p.read_text()
for text in ['pub struct HexSliceToBytesIter','pub struct HexToBytesIter','pub struct HexDigitsIter']:
 s=s.replace(text,'#[cfg_attr(verus_keep_ghost, verus_verify)]\n'+text,1)
for text in ["impl<'a> HexToBytesIter<HexDigitsIter<'a>> {", "impl<'a> HexDigitsIter<'a> {", "impl Iterator for HexDigitsIter<'_> {", 'impl<I> Iterator for HexToBytesIter<I>', 'impl<I> HexToBytesIter<I>']:
 s=s.replace(text,'#[cfg_attr(verus_keep_ghost, verus_verify)]\n'+text,1)
s=s.replace('    /// Writes all the bytes yielded by this `HexToBytesIter` to the provided slice.','}\n\nimpl<\'a> HexToBytesIter<HexDigitsIter<\'a>> {\n    /// Writes all the bytes yielded by this `HexToBytesIter` to the provided slice.',1)
s=s.replace("impl ExactSizeIterator for HexDigitsIter<'_> {}", "#[cfg_attr(verus_keep_ghost, verus_verify)]\nimpl ExactSizeIterator for HexDigitsIter<'_> {}",1)
s=s.replace('impl<I> ExactSizeIterator for HexToBytesIter<I>', '#[cfg_attr(verus_keep_ghost, verus_verify)]\nimpl<I> ExactSizeIterator for HexToBytesIter<I>',1)
p.write_text(s)
p=root/'src/error.rs';s=p.read_text();s='#[cfg(verus_keep_ghost)]\nuse vstd::prelude::*;\n'+s if not s.startswith('//!') else s
# Keep the file-level doc comment before imports.
s=p.read_text();index=s.index('use ');s=s[:index]+'#[cfg(verus_keep_ghost)]\nuse vstd::prelude::*;\n'+s[index:]
for text in ['pub struct InvalidCharError','pub struct OddLengthStringError']:
 s=s.replace(text,'#[cfg_attr(verus_keep_ghost, verus_verify)]\n'+text,1)
p.write_text(s)
