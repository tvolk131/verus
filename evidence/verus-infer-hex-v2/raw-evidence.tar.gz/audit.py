import hashlib,json,re,subprocess
from pathlib import Path
engine=Path('/Users/tommyvolk/Documents/GitHub/verus'); native=engine.parent/'hex-conservative'; work=Path('/private/tmp/verus-hex-iterator-v2'); out=engine/'evidence/verus-infer-hex-v2'
binary='/private/tmp/verus-validation-v4/inventory-target/release/verus-adoption-source-inventory'
files=sorted(subprocess.check_output(['git','ls-tree','-r','--name-only','129db6ac54d25b08e0b927c225aefe4a8df05a57','src'],cwd=native,text=True).splitlines())
base=work/'upstream-source'
for f in files:
 p=base/f;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(subprocess.check_output(['git','show','129db6ac54d25b08e0b927c225aefe4a8df05a57:'+f],cwd=native))
def parse(root,fs,label):
 r=subprocess.run([binary,str(root),*fs],capture_output=True,text=True,check=True);(work/(label+'.json')).write_text(r.stdout);return json.loads(r.stdout)['entries']
a=parse(base,files,'upstream-inventory'); b=parse(native,[*files,'src/decoding_spec.rs'],'live-inventory')
def key(e):return (e['file'],e['owner'],e['name'])
def erase(s):
 prefix='# [cfg_attr (verus_keep_ghost , verus_'
 while prefix in s:
  start=s.index(prefix); end=start+2;depth=1
  while depth:
   end+=1
   if s[end]=='[':depth+=1
   if s[end]==']':depth-=1
  s=s[:start]+s[end+1:]
 return ' '.join(s.split())
by={key(e):e for e in b if e['kind']=='function'};checks=[]
for e in a:
 if e['kind']!='function':continue
 f=by[key(e)];assert e['signature']==f['signature'],key(e)
 assert erase(e['body'] or '')==erase(f['body'] or ''),key(e)
 checks.append(dict(file=e['file'],owner=e['owner'],name=e['name'],signature_unchanged=True,body_sha256_after_erasing_added_verification_attributes=hashlib.sha256(erase(f['body'] or '').encode()).hexdigest()))
authored=[e for e in b if e['kind']=='function' and (e['in_verus'] or any('verus_' in s for s in e['attributes']))]
for e in authored:
 if e['mode']=='exec':assert not any(f['kind'] in ['assume','assert','proof_block','loop_annotation','reveal_hide','manual_trigger'] for f in e['findings']),key(e)
 assert not any('external_body' in s or 'verifier :: external' in s for s in e['attributes']),key(e)
assert not [e for e in b if e['kind']=='assumed_specification']
assert not [e for e in authored if e['mode']=='proof']
json.dump(dict(comparable_original_functions=len(checks),all_original_signatures_and_executable_bodies_unchanged=True,method='Verus/Rust parser inventories; compare all six upstream files; erase only added verification attributes in original bodies. No source extraction used for proofs.',checks=checks,authored_functions=[{k:v for k,v in e.items() if k!='body'}|({'spec_definition':e['body']} if e['mode']=='spec' else {}) for e in authored],first_party_assumed_specifications=0,first_party_external_bodies_added=0,source_proof_blocks_assertions_loop_invariants_manual_triggers=0),open(out/'source-audit.json','w'),indent=2)
print(len(checks),'unchanged upstream functions;',len(authored),'authored verification items')
