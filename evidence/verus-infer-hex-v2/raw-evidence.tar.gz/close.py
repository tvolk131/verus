import gzip,hashlib,io,json,subprocess,tarfile
from pathlib import Path
r=Path('/Users/tommyvolk/Documents/GitHub/verus');n=r.parent/'hex-conservative';w=Path('/private/tmp/verus-hex-iterator-v2');o=r/'evidence/verus-infer-hex-v2'
def git(root,*args):return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,data):(o/name).write_text(json.dumps(data,indent=2)+'\n')
receipt=json.load(open(w/'acceptance-final/receipt.json'));assert receipt['success'];assert receipt['native_sources_before']==receipt['native_sources_after'];assert not git(n,'status','--porcelain')
engine_commit=git(r,'rev-parse','HEAD');native_commit=git(n,'rev-parse','HEAD')
sources={p:sha(r/p) for p in git(r,'ls-files','source','dependencies').splitlines() if (r/p).is_file()}
write('engine-source-receipt.json',dict(engine_implementation_commit=engine_commit,native_implementation_commit=native_commit,engine_baseline='b42a50e3e96e32b9c76b25dd51caaacd5a120c37',metadata_schema=38,inference_policy=52,candidate_cache=58,binary_banner='0.2026.10.30.b42a50e.dirty; source/artifact hashes bind the actual build',artifacts=receipt['artifacts'],solver_sha256=sha(r/'source/z3'),engine_source_sha256=sources,proof_toolchain=receipt['proof_toolchain']))
write('controls-summary.json',dict(success=True,cases=[dict(label=e['label'],expected_success=e['expected_success'],verification=e['verification'],interface_written=e['inference']['interface_written'],exact_pair_checks_passed=e['inference'].get('functions',[{}])[0].get('required_checks_passed') if e['inference'].get('functions') else None) for e in receipt['cases']],native_sources_before=receipt['native_sources_before'],native_sources_after=receipt['native_sources_after'],commands=receipt['commands']))
restored=json.load(open(w/'acceptance-final/restored.stdout'));v=restored['verus-infer'];scope=v['verification_scope'];checked=[e for e in scope['native_functions'] if e['body_status']=='checked_exec_body'];goals=[e['function'] for e in checked if e['function'].endswith('_goal')];assert len(goals)==7
write('closure-summary.json',dict(decision='accepted finite native forward string iterator milestone',engine_implementation_commit=engine_commit,native_implementation_commit=native_commit,proof_run='acceptance-final/restored',verification_results=30,errors=0,new_application_theorems=6,retained_pair_application_theorems=1,application_goals=goals,native_named_checked_exec_bodies=len(checked),real_static_initializer_checked=True,exact_inference_helpers=1,mandatory_certificates=3,inference_regressions=291,constant_static_regressions=57,constant_static_ignored=2,unwind_regressions=17,type_invariant_regressions=90,vstd_verified_tooling_only=2215,semantic_mutations_rejected=18,negative_controls_rejected=['without_assistance','no_verify','filtered'],native_features=['default','all','no-default','alloc-only'],native_toolchain='1.99.1',msrv='1.74.0',restored_source_hashes_match=True,all_218_original_bodies_and_signatures_unchanged=True,metadata_schema=38,policy=52,cache=58,actual_public_decode_to_vec_verified=False,generic_runtime_size_hint_len_exactness_verified=False,prior_accepted_evidence_preserved=True))
# Archive committed native source, with the ignored matching native lockfile explicitly included.
with tarfile.open(o/'native-source.tar.gz','w:gz') as t:
 for p in [*git(n,'ls-files').splitlines(),'Cargo.lock']:
  if (n/p).is_file():t.add(n/p,arcname=p,recursive=False)
patch=subprocess.check_output(['git','diff','129db6ac54d25b08e0b927c225aefe4a8df05a57',native_commit],cwd=n)
(o/'native-source.patch.gz').write_bytes(gzip.compress(patch))
paths=[p for p in w.iterdir() if p.is_file() and p.suffix in ['.stdout','.stderr','.py','.json']]
paths += [p for series in ['acceptance','acceptance-final'] for p in (w/series).iterdir() if p.is_file()]
index={str(p.relative_to(w)):sha(p) for p in sorted(paths)}
with tarfile.open(o/'raw-evidence.tar.gz','w:gz') as t:
 for p in sorted(paths):t.add(p,arcname=str(p.relative_to(w)),recursive=False)
write('raw-evidence-index.json',dict(files_sha256=index,raw_archive_sha256=sha(o/'raw-evidence.tar.gz'),native_archive_sha256=sha(o/'native-source.tar.gz'),native_patch_sha256=sha(o/'native-source.patch.gz')))
print(engine_commit,native_commit,len(paths),'raw files')
