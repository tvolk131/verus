from pathlib import Path
p=Path('/Users/tommyvolk/Documents/GitHub/hex-conservative/src/iter.rs');s=p.read_text()
s=s.replace("    fn new_unchecked(digits: &'a [u8]) -> Self", "    #[cfg_attr(verus_keep_ghost, verus_spec(r => ensures r.pairs().len()==digits@.len()/2, forall|i:int| 0<=i<r.pairs().len() ==> r.pairs()[i]@ == digits@.subrange(2*i,2*i+2)))]\n    fn new_unchecked(digits: &'a [u8]) -> Self",1)
s=s.replace('    pub fn from_pairs(iter: I) -> Self', '    #[cfg_attr(verus_keep_ghost, verus_spec(r => ensures r.front_pos==0, r.iter==iter))]\n    pub fn from_pairs(iter: I) -> Self',1)
s=s.replace("    pub(crate) fn new_unchecked(s: &'a str) -> Self", "    #[cfg_attr(verus_keep_ghost, verus_spec(r => ensures r.front_pos==0, r.iter.pairs().len()==s.spec_bytes().len()/2, forall|i:int| 0<=i<r.iter.pairs().len() ==> r.iter.pairs()[i]@ == s.spec_bytes().subrange(2*i,2*i+2)))]\n    pub(crate) fn new_unchecked(s: &'a str) -> Self",1)
s=s.replace("    pub(crate) fn new(s: &'a str) -> Result<Self, OddLengthStringError>", "    #[cfg_attr(verus_keep_ghost, verus_spec(r => ensures r.is_ok() <==> s.spec_bytes().len()%2==0, r.is_err() ==> r->Err_0.len==s.spec_bytes().len(), r.is_ok() ==> r->Ok_0.front_pos==0 && r->Ok_0.iter.pairs().len()==s.spec_bytes().len()/2, r.is_ok() ==> forall|i:int| 0<=i<r->Ok_0.iter.pairs().len() ==> r->Ok_0.iter.pairs()[i]@ == s.spec_bytes().subrange(2*i,2*i+2)))]\n    pub(crate) fn new(s: &'a str) -> Result<Self, OddLengthStringError>",1)
s+='''
#[cfg(verus_keep_ghost)]
verus! {
use vstd::std_specs::iter::{IteratorSpec, IteratorSpecImpl, ExactSizeIteratorSpecImpl};
use vstd::std_specs::chunks_exact::{chunks, width};
use vstd::string::StringSliceAdditionalSpecFns;

impl<'a> HexDigitsIter<'a> {
    #[verifier::type_invariant]
    pub closed spec fn valid(&self)->bool {
        forall|i:int| 0<=i<chunks(self.iter).len() ==> #[trigger] chunks(self.iter)[i]@.len()==2
    }
    pub closed spec fn pairs(&self)->Seq<[u8;2]> {
        Seq::new(chunks(self.iter).len(),|i:int| [chunks(self.iter)[i]@[0],chunks(self.iter)[i]@[1]])
    }
}
impl<'a> IteratorSpecImpl for HexDigitsIter<'a> {
    open spec fn obeys_prophetic_iter_laws(&self)->bool {true}
    open spec fn remaining(&self)->Seq<Self::Item> {self.pairs()}
    open spec fn will_return_none(&self)->bool {true}
    open spec fn decrease(&self)->Option<nat> {Some(self.pairs().len())}
    open spec fn peek(&self,index:int)->Option<Self::Item> {
        if 0<=index<self.pairs().len() {Some(self.pairs()[index])} else {None}
    }
}
impl<'a> ExactSizeIteratorSpecImpl for HexDigitsIter<'a> {
    open spec fn exact_len(&self)->usize {self.pairs().len() as usize}
}

pub open spec fn sat(x:int)->usize {if x>usize::MAX {usize::MAX} else {x as usize}}
// The required decoder is expressed with the accepted independent ASCII spec.
pub closed spec fn decoded(p:[u8;2],cursor:int)->Result<u8,InvalidCharError> {
    match crate::decoding_spec::pair(p@[0],p@[1]) {
        Ok(v)=>Ok(v),
        Err((c,high))=>Err(InvalidCharError {invalid:c,pos:sat(2*cursor+if high {0} else {1})}),
    }
}
impl<I> HexToBytesIter<I> where I:Iterator<Item=[u8;2]>+ExactSizeIterator {
    #[verifier::prophetic]
    pub closed spec fn pending(&self)->Seq<Result<u8,InvalidCharError>> {
        Seq::new(self.iter.remaining().len(),|i:int| decoded(self.iter.remaining()[i],self.front_pos as int+i))
    }
}
impl<I> IteratorSpecImpl for HexToBytesIter<I> where I:Iterator<Item=[u8;2]>+ExactSizeIterator {
    open spec fn obeys_prophetic_iter_laws(&self)->bool {self.iter.obeys_prophetic_iter_laws()}
    #[verifier::prophetic]
    open spec fn remaining(&self)->Seq<Self::Item> {self.pending()}
    open spec fn will_return_none(&self)->bool {self.iter.will_return_none()}
    open spec fn decrease(&self)->Option<nat> {self.iter.decrease()}
    open spec fn peek(&self,index:int)->Option<Self::Item> {
        match self.iter.peek(index) {Some(p)=>Some(decoded(p,self.front_pos as int+index)),None=>None}
    }
}
impl<I> ExactSizeIteratorSpecImpl for HexToBytesIter<I> where I:Iterator<Item=[u8;2]>+ExactSizeIterator {
    open spec fn exact_len(&self)->usize {self.iter.exact_len()}
}
}
'''
p.write_text(s)
