from pathlib import Path
p=Path('/Users/tommyvolk/Documents/GitHub/hex-conservative/src/iter.rs');s=p.read_text();start=s.index('impl<I> Iterator for HexToBytesIter');end=s.index('impl<I> DoubleEndedIterator',start);part=s[start:end]
post='''old(self).source().obeys_prophetic_iter_laws() ==> final(self).source().remaining()==if SKIP<old(self).source().remaining().len() {old(self).source().remaining().subrange(SKIP as int+1,old(self).source().remaining().len() as int)} else {Seq::empty()}, old(self).source().obeys_prophetic_iter_laws() ==> r==if SKIP<old(self).source().remaining().len() {Some(decoded(old(self).source().remaining()[SKIP as int],old(self).cursor() as int+SKIP as int))} else {None}, '''
old='#[cfg_attr(verus_keep_ghost, verus_spec(r => ensures final(self).cursor()=='
pos=part.index(old);part=part[:pos]+part[pos:].replace(old,'#[cfg_attr(verus_keep_ghost, verus_spec(r => ensures '+post.replace('SKIP','0usize')+'final(self).cursor()==',1)
pos=part.index(old);part=part[:pos]+part[pos:].replace(old,'#[cfg_attr(verus_keep_ghost, verus_spec(r => ensures '+post.replace('SKIP','n')+'final(self).cursor()==',1)
s=s[:start]+part+s[end:];p.write_text(s)
