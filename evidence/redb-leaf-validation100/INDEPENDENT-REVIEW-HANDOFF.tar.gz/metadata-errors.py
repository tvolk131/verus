import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent

if sys.argv[1] == 'keyerror':
    rows = json.loads((ROOT / 'sysroot-inventory.json').read_text())
    sealed = json.loads((ROOT / 'pinned-operational.json').read_text())
    for name, row in rows.items():
        expected = sealed['/Users/tommyvolk/.rustup/toolchains/1.99.1-aarch64-apple-darwin/' + name]
        assert row['sha256'] == expected['sha256'] == expected['expected_sha256']
elif sys.argv[1] == 'missing-exit':
    json.loads((ROOT / 'metadata-reproduction' / 'authentication-exit.json').read_text())
