import datetime
import difflib
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import stat
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
CANDIDATE = Path('/private/tmp/verus-leaf-validation100-oXK71ovU')
ORIGINAL = Path('/private/tmp/verus-leaf007-independent-review-tOKSrsOe')
PACKAGE = Path('/private/tmp/verus-crash-consistency94-20261105/native-leaf-lookup-007')
SYSROOT = Path('/Users/tommyvolk/.rustup/toolchains/1.99.1-aarch64-apple-darwin')
START = datetime.datetime.fromisoformat('2026-11-08T00:30:00+00:00')
PINS = {
    str(CANDIDATE): '0d370a2c977c9db13f42ba8bfdb9bedb9dcd3b5f6323d9f391e7b4196e3c0bce',
    str(ORIGINAL): '286358f51477c3f14193f5230a047759f26e0f17c7655fc63427971809129e53',
    str(PACKAGE): '39cd35936577c41b43949776012c984a874892729b4da5fa15760fc71721b04c',
}

def digest(path):
    checksum = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            checksum.update(block)
    return checksum.hexdigest()

def load(path):
    return json.loads(Path(path).read_text())

def write(path, value):
    Path(path).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

def budget():
    elapsed = (datetime.datetime.now(datetime.timezone.utc) - START).total_seconds()
    size = sum(path.stat().st_size for path in ROOT.rglob('*') if path.is_file())
    free = shutil.disk_usage(ROOT).free
    assert elapsed < 720, elapsed
    assert size <= 128 * 1024**2, size
    assert free > 16 * 1024**3, free
    return dict(conservative_elapsed_seconds=elapsed, scratch_bytes=size, free_bytes=free)

def authenticate(stage):
    result = dict(stage=stage, utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), packages={}, files={}, budget=budget())
    for root_string, expected in PINS.items():
        root = Path(root_string)
        assert digest(root / 'SEAL.json') == expected
        seal = load(root / 'SEAL.json')
        manifest = load(root / 'MANIFEST.json')
        assert digest(root / 'MANIFEST.json') == seal['manifest_sha256']
        if root == CANDIDATE:
            assert seal['manifest_sha256'] == '3bfd1ea8b424f3dd000b5423a92666b3972067a2580a1729a70741e0c324272e'
            assert len(manifest) == 76
            assert digest(root / 'REPORT.md') == '96bdc27c9bda486e4fc01a5719cb4d42fc58531b50779e7a9e981e0bafc69806'
        names = {str(path.relative_to(root)) for path in root.rglob('*') if not path.is_dir()}
        assert names == set(manifest) | {'MANIFEST.json', 'SEAL.json'}
        assert len(manifest) == seal['payloads']
        rows = {}
        for name, row in manifest.items():
            path = root / name
            status = path.lstat()
            assert stat.S_ISREG(status.st_mode) and not status.st_mode & 0o222, str(path)
            actual = digest(path)
            assert status.st_size == row['size_bytes'] and actual == row['sha256'], str(path)
            rows[name] = dict(sha256=actual, size_bytes=status.st_size)
        result['packages'][root_string] = dict(seal_sha256=expected, manifest_sha256=digest(root / 'MANIFEST.json'), payloads=len(rows), rows=rows, exact_membership_regular_readonly=True)
    invocation = load(CANDIDATE / 'runs/attempt-002/invocation.json')
    old = load(ORIGINAL / 'runs/attempt-013/invocation.json')
    assert invocation['runtime_sha256'] == old['runtime_sha256']
    assert invocation['inputs'] == old['inputs']
    assert invocation['imports'] == old['imports']
    binding = load(PACKAGE / 'midpoint-runtime-proposal/runtime-binding.json')
    runtime = PACKAGE / 'midpoint-runtime-proposal/runtime'
    assert {path.name for path in runtime.iterdir()} == set(invocation['runtime_sha256'])
    for name, expected in invocation['runtime_sha256'].items():
        assert expected == binding['runtime'][name]
        assert digest(runtime / name) == expected, name
        result['files'][str(runtime / name)] = expected
    for name, expected in invocation['inputs'].items():
        assert digest(name) == expected, name
        result['files'][name] = expected
    baseline = load(CANDIDATE / 'sysroot-entry.json')
    assert baseline == load(CANDIDATE / 'sysroot-exit.json')
    assert {str(path.relative_to(SYSROOT)) for path in SYSROOT.rglob('*') if path.is_file() or path.is_symlink()} == set(baseline)
    for name, row in baseline.items():
        path = SYSROOT / name
        assert path.is_symlink() == (row['symlink'] is not None), str(path)
        if path.is_symlink():
            assert os.readlink(path) == row['symlink']
        assert path.stat().st_size == row['size_bytes'] and digest(path) == row['sha256'], str(path)
    result['sysroot'] = dict(path=str(SYSROOT), authenticated_files=len(baseline), inventory_sha256=digest(CANDIDATE / 'sysroot-entry.json'))
    result['budget_after'] = budget()
    write(ROOT / f'authentication-{stage}.json', result)
    print(json.dumps(dict(authentication=stage, packages={name: row['payloads'] for name, row in result['packages'].items()}, sysroot_files=len(baseline), budget=budget())), flush=True)

def prepare():
    evidence = ROOT / 'frozen-evidence'
    evidence.mkdir()
    shutil.copyfile('/Users/tommyvolk/.t3/worktrees/verus/t3-60978068/evidence/redb-leaf-validation100/REVIEW-PLAN.md', ROOT / 'REVIEW-PLAN.md')
    original = (ORIGINAL / 'generic_adversarial.rs').read_bytes()
    repaired = (CANDIDATE / 'draft-001-repaired.rs').read_bytes()
    assert hashlib.sha256(original).hexdigest() == '036505f3ec263621a2b5b1b81380625ad57e7170c4717750e027bd35f8c29477'
    assert hashlib.sha256(repaired).hexdigest() == '714e854e227d04c300ac8be1dfcb860f53d1ef0098cc6c6bb048482ecf078363'
    (ROOT / 'original.rs').write_bytes(original)
    (ROOT / 'positive.rs').write_bytes(repaired)
    changes = [row for row in difflib.SequenceMatcher(None, original.splitlines(True), repaired.splitlines(True), autojunk=False).get_opcodes() if row[0] != 'equal']
    assert len(changes) == 1 and changes[0][0] == 'insert', changes
    change = changes[0]
    inserted = b''.join(repaired.splitlines(True)[change[3]:change[4]])
    assert len(inserted.splitlines()) == 14
    assert inserted.startswith(b'    proof {\n') and inserted.endswith(b'    }\n')
    assert not any(token in inserted for token in (b'assume(', b'admit(', b'external_body', b'axiom'))
    (ROOT / 'inserted-ghost-block.txt').write_bytes(inserted)
    (ROOT / 'repair.patch').write_text(''.join(difflib.unified_diff(original.decode().splitlines(True), repaired.decode().splitlines(True), fromfile='original.rs', tofile='positive.rs')))
    before = b'assert(forall|before: int| 0 <= before < index\n        ==> <u32 as Value>::meaning(#[trigger] leaf::encoded_key(page@, key_width, value_width, before))\n            < <u32 as Value>::meaning(query@));'
    assert repaired.count(before) == 1 and original.count(before) == 1
    negative = repaired.replace(before, before.replace(b'            < <u32', b'            >= <u32'), 1)
    (ROOT / 'negative.rs').write_bytes(negative)
    (ROOT / 'partition-negative.patch').write_text(''.join(difflib.unified_diff(repaired.decode().splitlines(True), negative.decode().splitlines(True), fromfile='positive.rs', tofile='negative.rs')))
    (ROOT / 'restored.rs').write_bytes(repaired)
    write(ROOT / 'source-audit.json', dict(original_sha256=digest(ROOT / 'original.rs'), positive_sha256=digest(ROOT / 'positive.rs'), restored_sha256=digest(ROOT / 'restored.rs'), negative_sha256=digest(ROOT / 'negative.rs'), changes=changes, inserted_lines=14, final_assertion_mutated_line=30, insertion_only=True, original_recovered_by_removal=b''.join(repaired.splitlines(True)[:change[3]] + repaired.splitlines(True)[change[4]:]) == original))
    for name in ('REPORT.md', 'REPLAY.md', 'metadata-repair-log.json', 'method-ledger.json', 'application-ledger.jsonl', 'audit-draft-001.py', 'audit.py', 'cycle-auth-draft-001.py', 'cycle.py', 'prepare.py', 'prepare-controls.py', 'source-preservation-audit.json', 'audit.stdout.txt', 'audit.stderr.txt'):
        shutil.copyfile(CANDIDATE / name, evidence / name)
    for ordinal in range(1, 6):
        target = evidence / f'attempt-{ordinal:03d}'
        target.mkdir()
        for name in ('input.rs', 'invocation.json', 'stdout.txt', 'stderr.txt', 'scope.json', 'receipt.json'):
            shutil.copyfile(CANDIDATE / f'runs/attempt-{ordinal:03d}' / name, target / name)
    for name in ('REPORT.md', 'REPLAY.md'):
        shutil.copyfile(ORIGINAL / name, evidence / ('original-review-' + name))

def run(kind):
    budget_before = budget()
    ledger = ROOT / 'application-ledger.jsonl'
    prior = ledger.read_text().splitlines() if ledger.exists() else []
    ordinal = len(prior) + 1
    assert ordinal <= 4
    output = ROOT / 'runs' / f'attempt-{ordinal:03d}'
    output.mkdir(parents=True)
    original = load(CANDIDATE / 'runs/attempt-002/invocation.json')
    source = ROOT / f'{kind}.rs'
    shutil.copyfile(source, output / 'input.rs')
    argv = [str(output / 'input.rs') if part == original['argv'][-1] else part for part in original['argv']]
    argv[-1:-1] = ['--export', str(output / 'partition-control.vir')]
    environment = {key: value.replace(original['cwd'], str(output)) for key, value in original['environment'].items()}
    for key in ('CARGO_HOME', 'CARGO_TARGET_DIR', 'HOME', 'RUSTUP_HOME', 'TMPDIR', 'VERUS_INFER_CACHE', 'XDG_CACHE_HOME'):
        Path(environment[key]).mkdir(parents=True, exist_ok=True)
    invocation = dict(ordinal=ordinal, kind=kind, argv=argv, environment=environment, cwd=str(output), source_sha256=digest(output / 'input.rs'), runner_sha256=digest(__file__), authentication_entry_sha256=digest(ROOT / 'authentication-entry.json'), timeout_seconds=60, budget_before=budget_before, requested_export=str(output / 'partition-control.vir'))
    write(output / 'invocation.json', invocation)
    write(output / 'outputs-before.json', dict(requested_export_exists=(output / 'partition-control.vir').exists(), files=sorted(str(path.relative_to(output)) for path in output.rglob('*') if path.is_file())))
    with ledger.open('a') as stream:
        stream.write(json.dumps(dict(ordinal=ordinal, kind=kind, invocation_sha256=digest(output / 'invocation.json'), utc=datetime.datetime.now(datetime.timezone.utc).isoformat())) + '\n')
        stream.flush()
        os.fsync(stream.fileno())
    started = time.monotonic()
    returncode = None
    timed_out = False
    spawn_error = None
    with (output / 'stdout.txt').open('wb') as stdout, (output / 'stderr.txt').open('wb') as stderr:
        try:
            process = subprocess.Popen(argv, cwd=output, env=environment, stdout=stdout, stderr=stderr, start_new_session=True)
            try:
                returncode = process.wait(timeout=60)
            except subprocess.TimeoutExpired:
                timed_out = True
                os.killpg(process.pid, signal.SIGKILL)
                returncode = process.wait()
        except OSError as error:
            spawn_error = repr(error)
    try:
        backend = load(output / 'stdout.txt')
    except (ValueError, OSError):
        backend = {}
    write(output / 'actual-scope.json', backend.get('verus-infer', {}).get('verification_scope', {}))
    files = {str(path.relative_to(output)): dict(sha256=digest(path), size_bytes=path.stat().st_size) for path in output.rglob('*') if path.is_file()}
    exports = [name for name in files if Path(name).suffix in ('.vir', '.rlib', '.rmeta', '.interface')]
    receipt = dict(ordinal=ordinal, kind=kind, returncode=returncode, timed_out=timed_out, spawn_error=spawn_error, seconds=time.monotonic() - started, verification=backend.get('verification-results'), outputs=files, exports=exports, requested_export_exists=(output / 'partition-control.vir').exists(), budget_after=budget())
    write(output / 'receipt.json', receipt)
    print(json.dumps(receipt), flush=True)

if __name__ == '__main__':
    if sys.argv[1] == 'auth':
        authenticate(sys.argv[2])
    elif sys.argv[1] == 'prepare':
        prepare()
    elif sys.argv[1] == 'run':
        run(sys.argv[2])
