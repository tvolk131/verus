import difflib
import json
from pathlib import Path
import shutil
import subprocess
import sys

from review import ROOT, CANDIDATE, ORIGINAL, SYSROOT, digest, load, write, budget

def normalized_argv(invocation, old=False):
    argv = invocation['argv'][:]
    if '--export' in argv:
        position = argv.index('--export')
        del argv[position:position + 2]
    output = invocation['output'] if old else invocation['cwd']
    return [part.replace(output, '<OUTPUT>') for part in argv]

def normalized_environment(invocation, old=False):
    output = invocation['output'] if old else invocation['cwd']
    return {key: value.replace(output, '<OUTPUT>') for key, value in invocation['environment'].items()}

template = load(CANDIDATE / 'runs/attempt-002/invocation.json')
historical = load(ORIGINAL / 'runs/attempt-013/invocation.json')
assert normalized_argv(template) == normalized_argv(historical, True)
assert normalized_environment(template) == normalized_environment(historical, True)
evidence = ROOT / 'frozen-evidence'
for ordinal in (1, 3, 4):
    shutil.copyfile(ORIGINAL / f'runs/attempt-{ordinal:03d}/input.rs', evidence / f'import-{ordinal:03d}.rs')
shutil.copyfile(CANDIDATE / 'sysroot-entry.json', ROOT / 'sysroot-inventory.json')
sealed = load(ORIGINAL / 'preservation-before.json')['surviving_immutable_rows']
subset = {name: row for name, row in sealed.items() if name.startswith(str(SYSROOT) + '/')}
assert len(subset) == 61
inventory = load(ROOT / 'sysroot-inventory.json')
for name, row in subset.items():
    current = inventory[str(Path(name).relative_to(SYSROOT))]
    assert row['sha256'] == row['expected_sha256'] == current['sha256']
write(ROOT / 'pinned-operational.json', subset)
write(ROOT / 'runtime-binding-summary.json', {key: value for key, value in load(CANDIDATE / 'authentication-entry.json').items() if key in ('packages', 'sysroot')})

original_rows = []
for ordinal in range(1, 6):
    output = CANDIDATE / f'runs/attempt-{ordinal:03d}'
    target = evidence / f'attempt-{ordinal:03d}'
    shutil.copyfile(output / 'runner.py', target / 'runner.py')
    invocation = load(output / 'invocation.json')
    backend = load(output / 'stdout.txt')
    receipt = load(output / 'receipt.json')
    infer = backend['verus-infer']
    scope = infer['verification_scope']
    result = backend['verification-results']
    stderr = (output / 'stderr.txt').read_text()
    assert digest(output / 'input.rs') == invocation['source_sha256']
    assert normalized_argv(invocation) == normalized_argv(template)
    assert normalized_environment(invocation) == normalized_environment(template)
    assert invocation['imports'] == template['imports']
    assert invocation['runtime_sha256'] == template['runtime_sha256']
    assert invocation['inputs'] == template['inputs']
    assert receipt['spawn_error'] is None and not receipt['timed_out'] and receipt['seconds'] < 60
    assert result['verified'] == [2, 3, 4, 3, 3][ordinal - 1]
    assert result['errors'] == [1, 0, 0, 1, 0][ordinal - 1]
    assert result['is-verifying-entire-crate'] and not result['encountered-vir-error']
    assert stderr.count('error: assertion failed') == [2, 0, 0, 1, 0][ordinal - 1]
    assert len(scope['native_functions']) == (4 if ordinal in (3, 4) else 3)
    assert all(row['selected'] for row in scope['native_functions'])
    assert scope['checked_exec_bodies'] == [0, 3, 3, 0, 3][ordinal - 1]
    assert scope['checked_proof_bodies'] == [0, 0, 1, 0, 0][ordinal - 1]
    actual_exports = sorted(str(path.relative_to(output)) for path in output.rglob('*') if path.is_file() and path.suffix in ('.vir', '.rlib', '.rmeta', '.interface'))
    assert actual_exports == (['control.vir'] if ordinal == 3 else [])
    if ordinal == 1:
        assert (output / 'input.rs').read_bytes() == (ROOT / 'original.rs').read_bytes()
        assert load(output / 'scope.json') == {} and receipt['scope'] == {}
        assert "backend.get('verification-scope'" in (output / 'runner.py').read_text()
        assert ':14:12' in stderr and ':17:12' in stderr
    if ordinal in (2, 5):
        assert (output / 'input.rs').read_bytes() == (ROOT / 'positive.rs').read_bytes()
    if ordinal == 4:
        assert infer['failed_functions'] == ['review_generic::mathematical_assertion_control']
        assert ':89:12' in stderr
    if ordinal in (3, 4):
        expected_source = 'draft-002-control-correct.rs' if ordinal == 3 else 'draft-003-control-incorrect.rs'
        assert (output / 'input.rs').read_bytes() == (CANDIDATE / expected_source).read_bytes()
    write(target / 'raw-derived-body-records.json', scope)
    original_rows.append(dict(ordinal=ordinal, source_sha256=digest(output / 'input.rs'), returncode=receipt['returncode'], verification=result, scope=scope, failed_functions=infer['failed_functions'], interface_written=infer['interface_written'], exports=actual_exports, diagnostic_count=stderr.count('error: assertion failed'), seconds=receipt['seconds'], normalized_argv_environment_imports_exact=True))
correct = (CANDIDATE / 'draft-002-control-correct.rs').read_text()
incorrect = (CANDIDATE / 'draft-003-control-incorrect.rs').read_text()
assert correct.replace('assert(number + 1 > number);', 'assert(number + 1 < number);') == incorrect
write(ROOT / 'original-five-raw-audit.json', original_rows)

fresh_rows = []
for ordinal in range(1, 4):
    output = ROOT / f'runs/attempt-{ordinal:03d}'
    invocation = load(output / 'invocation.json')
    backend = load(output / 'stdout.txt')
    receipt = load(output / 'receipt.json')
    infer = backend['verus-infer']
    scope = infer['verification_scope']
    result = backend['verification-results']
    stderr = (output / 'stderr.txt').read_text()
    assert normalized_argv(invocation) == normalized_argv(template)
    assert normalized_environment(invocation) == normalized_environment(template)
    assert '--export' in invocation['argv'] and invocation['timeout_seconds'] == 60
    assert not load(output / 'outputs-before.json')['requested_export_exists']
    assert receipt['spawn_error'] is None and not receipt['timed_out'] and receipt['seconds'] < 60
    assert result['verified'] == [3, 2, 3][ordinal - 1] and result['errors'] == [0, 1, 0][ordinal - 1]
    assert result['is-verifying-entire-crate'] and not result['encountered-vir-error']
    assert len(scope['native_functions']) == 3 and all(row['selected'] for row in scope['native_functions'])
    assert scope['checked_exec_bodies'] == [3, 0, 3][ordinal - 1] and scope['checked_proof_bodies'] == 0
    assert scope['complete_selected_scope_verified'] == (ordinal != 2)
    if ordinal == 2:
        assert receipt['returncode'] == 1 and not receipt['exports'] and not receipt['requested_export_exists']
        assert infer['failed_functions'] == ['review_generic::generic_partition_bytes']
        assert not infer['interface_written']
        assert stderr.count('error: assertion failed') == 1 and ':28:12' in stderr
        assert '>= <u32 as Value>::meaning(query@)' in stderr
        assert not any(term in stderr.lower() for term in ('panic', 'timed out', 'failed to load', 'unresolved import'))
    else:
        assert receipt['returncode'] == 0 and receipt['exports'] == ['partition-control.vir'] and receipt['requested_export_exists']
        assert not stderr and not infer['failed_functions']
        assert (output / 'input.rs').read_bytes() == (ROOT / 'positive.rs').read_bytes()
    fresh_rows.append(dict(ordinal=ordinal, kind=invocation['kind'], returncode=receipt['returncode'], verification=result, scope=scope, failed_functions=infer['failed_functions'], interface_written=infer['interface_written'], exports=receipt['exports'], requested_export_exists=receipt['requested_export_exists'], seconds=receipt['seconds'], source_sha256=digest(output / 'input.rs')))
write(ROOT / 'fresh-controls-audit.json', fresh_rows)

metadata = ROOT / 'metadata-reproduction'
metadata.mkdir()
metadata_rows = []
for mode in ('keyerror', 'missing-exit'):
    argv = [sys.executable, '-B', str(ROOT / 'metadata-errors.py'), mode]
    with (metadata / f'{mode}.stdout.txt').open('wb') as stdout, (metadata / f'{mode}.stderr.txt').open('wb') as stderr:
        result = subprocess.run(argv, cwd=metadata, stdout=stdout, stderr=stderr, timeout=5)
    assert result.returncode == 1
    diagnostic = (metadata / f'{mode}.stderr.txt').read_text()
    assert ('KeyError:' if mode == 'keyerror' else 'FileNotFoundError:') in diagnostic
    metadata_rows.append(dict(mode=mode, argv=argv, cwd=str(metadata), returncode=result.returncode, verifier_applications=0))
write(metadata / 'invocations.json', metadata_rows)
write(ROOT / 'audit-summary.json', dict(result='CONDITIONAL_PROOF_REPAIR_AND_PARTITION_PAIRED_CONTROL_CONFIRMED', original_applications_reviewed=5, fresh_verifier_applications=3, application_limit=4, remaining_applications_unused=1, fresh_verifier_seconds=sum(row['seconds'] for row in fresh_rows), setup_spawn_timeout_failures=0, expected_semantic_negative_failures=1, unexpected_failures=0, metadata_reproduction_python_failures=2, subdelegation=0, builds=0, native_executions=0, network=0, parent_frozen_runtime_toolchain_git_writes=0, all_eighteen_final_redb_cells='OPEN', budget=budget()))
print(json.dumps(load(ROOT / 'audit-summary.json')), flush=True)
