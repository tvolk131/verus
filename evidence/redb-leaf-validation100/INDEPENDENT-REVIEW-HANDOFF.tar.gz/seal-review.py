import datetime
import json
import os
from pathlib import Path

from review import ROOT, CANDIDATE, digest, load, write, budget

entry = load(ROOT / 'authentication-entry.json')
exit_record = load(ROOT / 'authentication-exit.json')
assert entry['packages'] == exit_record['packages']
assert entry['files'] == exit_record['files']
assert entry['sysroot'] == exit_record['sysroot']
assert not (ROOT / 'auth-entry.stderr.txt').read_bytes()
assert not (ROOT / 'auth-exit.stderr.txt').read_bytes()
assert not (ROOT / 'audit-review.stderr.txt').read_bytes()
assert len((ROOT / 'application-ledger.jsonl').read_text().splitlines()) == 3
summary = load(ROOT / 'audit-summary.json')
handoff = dict(
    schema='independent-leaf100-partition-review-handoff-v1',
    verdict=summary['result'],
    all_eighteen_final_redb_cells='OPEN',
    conditional_only=True,
    native_execution_or_counterexample_claim=False,
    original_native_path_preservation='FAILED_1331_MISSING',
    original_native_git_continuity='UNAVAILABLE',
    shared_objectstore_continuity='NOT_CERTIFIED',
    inherited_conditional_boundaries=['private_usize_midpoint', 'six_LE_std_bindings'],
    candidate_entry_and_exit=dict(seal_sha256=digest(CANDIDATE / 'SEAL.json'), manifest_sha256=digest(CANDIDATE / 'MANIFEST.json'), report_sha256=digest(CANDIDATE / 'REPORT.md'), payloads=76, equal=True),
    authentication_entry_sha256=digest(ROOT / 'authentication-entry.json'),
    authentication_exit_sha256=digest(ROOT / 'authentication-exit.json'),
    original_review_seal_sha256=entry['packages']['/private/tmp/verus-leaf007-independent-review-tOKSrsOe']['seal_sha256'],
    original_package_seal_sha256=entry['packages']['/private/tmp/verus-crash-consistency94-20261105/native-leaf-lookup-007']['seal_sha256'],
    endpoint_all_payloads_files_sysroot_equal=True,
    source_audit=load(ROOT / 'source-audit.json'),
    original_five_raw_audit_sha256=digest(ROOT / 'original-five-raw-audit.json'),
    fresh_controls_audit_sha256=digest(ROOT / 'fresh-controls-audit.json'),
    fresh_application_count=3,
    fresh_application_limit=4,
    original_applications_reviewed=5,
    metadata_evidence_objection='Original exception tracebacks absent; independently reproduced and explicitly distinguished from historical raw logs.',
    scope_and_exports=[{key: row[key] for key in ('ordinal', 'kind', 'returncode', 'verification', 'exports', 'requested_export_exists', 'seconds')} for row in load(ROOT / 'fresh-controls-audit.json')],
    parent_retention_and_integration='NOT_PERFORMED_PARENT_DECIDES',
    conservative_budget_start_utc='2026-11-08T00:30:00+00:00',
    scratch_creation_utc=datetime.datetime.fromtimestamp(ROOT.stat().st_birthtime, datetime.timezone.utc).isoformat(),
    budget=budget(),
)
write(ROOT / 'HANDOFF.json', handoff)
manifest = {}
for path in sorted(ROOT.rglob('*')):
    if path.is_file():
        assert not path.is_symlink()
        manifest[str(path.relative_to(ROOT))] = dict(sha256=digest(path), size_bytes=path.stat().st_size)
write(ROOT / 'MANIFEST.json', manifest)
seal = dict(schema='independent-leaf100-partition-review-seal-v1', sealed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), manifest_sha256=digest(ROOT / 'MANIFEST.json'), handoff_sha256=digest(ROOT / 'HANDOFF.json'), report_sha256=digest(ROOT / 'REPORT.md'), authentication_entry_sha256=digest(ROOT / 'authentication-entry.json'), authentication_exit_sha256=digest(ROOT / 'authentication-exit.json'), payloads=len(manifest), direct_verifier_applications=3, all_eighteen_final_redb_cells='OPEN', budget=budget())
write(ROOT / 'SEAL.json', seal)
seal['budget'] = budget()
for attempt in range(4):
    write(ROOT / 'SEAL.json', seal)
    size = sum(path.stat().st_size for path in ROOT.rglob('*') if path.is_file())
    if seal['budget']['scratch_bytes'] == size:
        break
    seal['budget']['scratch_bytes'] = size
else:
    raise AssertionError('Final seal byte-size accounting did not stabilize')
for name, row in manifest.items():
    assert digest(ROOT / name) == row['sha256'] and (ROOT / name).stat().st_size == row['size_bytes']
for path in ROOT.rglob('*'):
    if path.is_file():
        os.chmod(path, 0o444)
for path in sorted((path for path in ROOT.rglob('*') if path.is_dir()), key=lambda path: len(path.parts), reverse=True):
    os.chmod(path, 0o555)
os.chmod(ROOT, 0o555)
print(json.dumps(dict(root=str(ROOT), seal_sha256=digest(ROOT / 'SEAL.json'), manifest_sha256=digest(ROOT / 'MANIFEST.json'), handoff_sha256=digest(ROOT / 'HANDOFF.json'), report_sha256=digest(ROOT / 'REPORT.md'), authentication_entry_sha256=seal['authentication_entry_sha256'], authentication_exit_sha256=seal['authentication_exit_sha256'], payloads=len(manifest), budget=budget()), indent=2))
