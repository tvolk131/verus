# Reproduction and audit handoff

Do not run a runner, auditor, finalizer or sealer inside this read-only package.
Use a NEW private writable root. Do not reconstruct original native checkouts or
Git metadata, retry interrupted destruction/compiler-data work, or treat this
review as authorization for repairs or a new stage.

## Exact evidence already produced

- process-ledger.jsonl reserves every one of the 15 applications, including all
  failures and ordinary compile/export attempts. There were no setup failures.
- runs/attempt-NNN/invocation.json gives actual argv, complete environment, cwd,
  input hashes, exact .vir/.rlib imports, runtime hashes and selected scope.
- runs/attempt-NNN/{input.rs,runner.py,stdout.txt,stderr.txt,scope.json,receipt.json}
  retain frozen source/runner bytes and raw verification evidence. Receipt output
  hashes and the package manifest bind the emitted ordinary artifacts.
- application-ledger.json classifies the seven full positives, seven intended
  backend controls, and unexpected supplemental draft013 separately.
- method-ledger.json lists exactly five NEW methods. Historical methods reused
  unchanged are not charged again as newly authored methods.
- readonly-process-ledger.json and recovery-chain-*/invocation.json cover the
  read-only Git content/inventory queries, which are not verifier applications.

Fresh exported chain:
1. runs/attempt-001/{leaf_decoder.vir,libleaf_decoder.rlib}
2. runs/attempt-003/{builder_step.vir,libbuilder_step.rlib}, importing fresh001
3. runs/attempt-004/{lookup_client.vir,liblookup_client.rlib}, importing001/003

All imports in later invocations use this fresh same-runtime chain, never the
parent's historical final rlibs. Provider002 is debug-only qualification; the
composing builder/client chain is release-only.

## Exact ordinary replay recipe, if separately authorized

Copy runner.py and validation-plan.json to a new empty private writable directory.
Do NOT copy process-ledger.jsonl or runs/. Keep the sealed input-source paths in
validation-plan.json; they are immutable inputs, not output locations. The runner
derives all writable locations from its own NEW __file__ parent. Preserve the
private matched runtime and sysroot bindings and all logical verifier flags.

In that new directory run the copied runner.py with these step names in order:

    provider-release provider-debug builder-release client-release
    parent-witnesses right-value wrong-value right-presence wrong-absence
    unsorted-reject malformed-query-reject wrong-midpoint
    generic-adversarial duplicate-reject zero-count-reject

The last three are not an instruction to fix the failed generic fixture.
Expected evidence is the original classification: supplemental013 fails with
two partition assertion diagnostics and gets ZERO complete-scope/control credit.
Do not delete failing assertions, narrow its scope or retry it with source edits
while calling that reproduction unchanged. Intended negative controls each have
one backend diagnostic; a frontend, setup or resource failure earns zero credit.

audit_independent.py, source_audit.py, recovery_chain.py and final_audit.py record
the independent audit algorithms. Their outputs are already sealed; no rebuild
or rerun is necessary to read them. Any future run must use a new writable root
and its own authorization, budget and receipts. Recovery-chain commands only
read existing pinned objects with lazy fetching disabled and never write native
paths or Git metadata. Pinned content equality is not metadata continuity.

## Independent seal check

Hash SEAL.json and compare the externally handed-off seal digest. Authenticate
MANIFEST.json against SEAL.json, then require exact file membership equal to all
manifest rows plus MANIFEST.json and SEAL.json. Each payload must be a regular,
non-symlink, read-only file with the recorded SHA256 and byte count. No directory
entry, mode or objectstore-continuity claim is implied by a content manifest.

The parent seal expected by this review is
39cd35936577c41b43949776012c984a874892729b4da5fa15760fc71721b04c.
The baseline82 guards, preservation comparisons and incident exceptions must be
read alongside any positive proof result. All 18 database/history cells remain
OPEN, and no live adoption is authorized.
