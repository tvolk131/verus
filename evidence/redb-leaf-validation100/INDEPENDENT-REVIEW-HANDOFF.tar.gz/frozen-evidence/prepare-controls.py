from pathlib import Path

ROOT = Path(__file__).resolve().parent
repaired = (ROOT / 'draft-001-repaired.rs').read_text()
assert repaired.endswith('\n}\n')
correct = '\npub proof fn mathematical_assertion_control(number: int) {\n    assert(number + 1 > number);\n}\n'
incorrect = correct.replace('number + 1 > number', 'number + 1 < number')
(ROOT / 'draft-002-control-correct.rs').write_text(repaired[:-2] + correct + '\n}\n')
(ROOT / 'draft-003-control-incorrect.rs').write_text(repaired[:-2] + incorrect + '\n}\n')
assert (ROOT / 'draft-002-control-correct.rs').read_text().replace('number + 1 > number', 'number + 1 < number') == (ROOT / 'draft-003-control-incorrect.rs').read_text()
(ROOT / 'draft-004-restored.rs').write_text(repaired)
