use vstd::prelude::*;
use core::mem::size_of;
use leaf_decoder as leaf;

verus! {

pub const LEAF: u8 = 1;

pub struct RawLeafBuilder<'a> {
    page: &'a mut [u8],
    fixed_key_size: Option<usize>,
    fixed_value_size: Option<usize>,
    num_pairs: usize,
    provisioned_key_bytes: usize,
    pairs_written: usize,
}

pub open spec fn metadata(count: int, key_width: Option<usize>, value_width: Option<usize>) -> int {
    4 + (if key_width.is_none() { 4 * count } else { 0 })
      + (if value_width.is_none() { 4 * count } else { 0 })
}

pub open spec fn read32(bytes: Seq<u8>, offset: int) -> int {
    vstd::bytes::spec_u32_from_le_bytes(bytes.subrange(offset, offset + 4)) as int
}

pub open spec fn read16(bytes: Seq<u8>, offset: int) -> int {
    vstd::bytes::spec_u16_from_le_bytes(bytes.subrange(offset, offset + 2)) as int
}

pub open spec fn patch(bytes: Seq<u8>, start: int, value: Seq<u8>) -> Seq<u8>
    recommends 0 <= start, start + value.len() <= bytes.len(),
{
    bytes.subrange(0, start) + value + bytes.subrange(start + value.len(), bytes.len() as int)
}

pub proof fn patch_facts(bytes: Seq<u8>, start: int, value: Seq<u8>)
    requires 0 <= start, start + value.len() <= bytes.len(),
    ensures
        patch(bytes, start, value).len() == bytes.len(),
        patch(bytes, start, value).subrange(start, start + value.len()) == value,
        forall|index: int| 0 <= index < bytes.len() ==> #[trigger] patch(bytes, start, value)[index]
            == if start <= index < start + value.len() { value[index - start] } else { bytes[index] },
{
    assert(patch(bytes, start, value).subrange(start, start + value.len()) =~= value);
}

pub open spec fn initialized_bytes(bytes: Seq<u8>, count: int, key_width: Option<usize>, value_width: Option<usize>) -> Seq<u8> {
    let header = patch(bytes.update(0, LEAF), 2, vstd::bytes::spec_u16_to_le_bytes(count as u16));
    if cfg!(debug_assertions) {
        patch(header, 4, Seq::new((metadata(count, key_width, value_width) - 4) as nat, |index: int| 0xffu8))
    } else { header }
}

pub proof fn initial_byte_facts(bytes: Seq<u8>, count: int, key_width: Option<usize>, value_width: Option<usize>)
    requires
        4 <= bytes.len() <= usize::MAX,
        0 <= count <= 65535,
        cfg!(debug_assertions) ==> metadata(count, key_width, value_width) <= bytes.len(),
    ensures
        initialized_bytes(bytes, count, key_width, value_width).len() == bytes.len(),
        initialized_bytes(bytes, count, key_width, value_width)[0] == LEAF,
        initialized_bytes(bytes, count, key_width, value_width)[1] == bytes[1],
        read16(initialized_bytes(bytes, count, key_width, value_width), 2) == count,
        forall|index: int| 4 <= index < bytes.len()
            && (!cfg!(debug_assertions) || index >= metadata(count, key_width, value_width))
            ==> #[trigger] initialized_bytes(bytes, count, key_width, value_width)[index] == bytes[index],
        cfg!(debug_assertions) ==> forall|index: int| 4 <= index < metadata(count, key_width, value_width)
            ==> #[trigger] initialized_bytes(bytes, count, key_width, value_width)[index] == 0xff,
{
    vstd::bytes::lemma_auto_spec_u16_to_from_le_bytes();
    let updated = bytes.update(0, LEAF);
    let encoding = vstd::bytes::spec_u16_to_le_bytes(count as u16);
    patch_facts(updated, 2, encoding);
    let header = patch(updated, 2, encoding);
    assert(header.subrange(2, 4) =~= encoding);
    if cfg!(debug_assertions) {
        let poison = Seq::new((metadata(count, key_width, value_width) - 4) as nat, |index: int| 0xffu8);
        patch_facts(header, 4, poison);
        let result = patch(header, 4, poison);
        assert(result.subrange(2, 4) =~= encoding);
    }
}

pub open spec fn first_bytes(bytes: Seq<u8>, count: int, key_width: Option<usize>, value_width: Option<usize>,
    reserved: int, key: Seq<u8>, value: Seq<u8>) -> Seq<u8>
{
    let start = metadata(count, key_width, value_width);
    let bytes = if key_width.is_none() {
        patch(bytes, 4, vstd::bytes::spec_u32_to_le_bytes((start + key.len()) as u32))
    } else { bytes };
    let bytes = patch(bytes, start, key);
    let bytes = if value_width.is_none() {
        patch(bytes, 4 + (if key_width.is_none() { 4 * count } else { 0 }),
            vstd::bytes::spec_u32_to_le_bytes((start + reserved + value.len()) as u32))
    } else { bytes };
    patch(bytes, start + reserved, value)
}

pub fn witness_first_append(page: &mut [u8], count: usize, key_width: Option<usize>,
    value_width: Option<usize>, reserved: usize, key: &[u8], value: &[u8])
    requires
        1 <= count <= 65535,
        page@.len() <= usize::MAX,
        metadata(count as int, key_width, value_width) + reserved + value.len() <= page@.len(),
        key.len() <= reserved,
        key_width.is_some() ==> key_width.unwrap() == key.len(),
        value_width.is_some() ==> value_width.unwrap() == value.len(),
        key_width.is_none() ==> metadata(count as int, key_width, value_width) + key.len() <= u32::MAX,
        value_width.is_none() ==> metadata(count as int, key_width, value_width) + reserved + value.len() <= u32::MAX,
    ensures final(page)@ == first_bytes(old(page)@, count as int, key_width, value_width, reserved as int, key@, value@),
{
    let mut builder = RawLeafBuilder {
        page,
        fixed_key_size: key_width,
        fixed_value_size: value_width,
        num_pairs: count,
        provisioned_key_bytes: reserved,
        pairs_written: 0,
    };
    assert(builder.ready(key@, value@));
    builder.append(key, value);
}

impl<'a> RawLeafBuilder<'a> {
    pub fn into_page_projection(self) -> (result: &'a mut [u8])
        ensures result@ == self.contents(), final(result)@ == self.eventual_contents(),
    {
        self.page
    }

    pub fn new(
        page: &'a mut [u8],
        num_pairs: usize,
        fixed_key_size: Option<usize>,
        fixed_value_size: Option<usize>,
        key_bytes: usize,
    ) -> (result: Self)
        requires
            num_pairs <= 65535,
            4 <= page@.len() <= usize::MAX,
            cfg!(debug_assertions) ==> metadata(num_pairs as int, fixed_key_size, fixed_value_size) <= page@.len(),
        ensures
            result.contents() == initialized_bytes(old(page)@, num_pairs as int, fixed_key_size, fixed_value_size),
            result.shape() == (fixed_key_size, fixed_value_size, num_pairs, key_bytes),
            result.written() == 0,
            result.key_position() == metadata(num_pairs as int, fixed_key_size, fixed_value_size),
            result.value_position() == metadata(num_pairs as int, fixed_key_size, fixed_value_size) + key_bytes as int,
            result.eventual_contents() == final(page)@,
    {
        page[0] = LEAF;
        page[2..4].copy_from_slice(&u16::try_from(num_pairs).unwrap().to_le_bytes());
        #[cfg(debug_assertions)]
        {
            // Poison all the key & value offsets, in case the caller forgets to write them
            let mut last = 4;
            if fixed_key_size.is_none() {
                last += size_of::<u32>() * num_pairs;
            }
            if fixed_value_size.is_none() {
                last += size_of::<u32>() * num_pairs;
            }
            for x in &mut page[4..last] {
                *x = 0xFF;
            }
        }
        RawLeafBuilder {
            page,
            fixed_key_size,
            fixed_value_size,
            num_pairs,
            provisioned_key_bytes: key_bytes,
            pairs_written: 0,
        }
    }

    pub closed spec fn meta(self) -> int {
        metadata(self.num_pairs as int, self.fixed_key_size, self.fixed_value_size)
    }

    pub closed spec fn key_position(self) -> int {
        if self.pairs_written == 0 {
            self.meta()
        } else if self.fixed_key_size.is_some() {
            self.meta() + self.fixed_key_size.unwrap() as int * self.pairs_written as int
        } else {
            read32(self.page@, 4 + 4 * (self.pairs_written as int - 1))
        }
    }

    pub closed spec fn value_position(self) -> int {
        if self.pairs_written == 0 {
            self.meta() + self.provisioned_key_bytes as int
        } else if self.fixed_value_size.is_some() {
            self.meta() + self.provisioned_key_bytes as int
                + self.fixed_value_size.unwrap() as int * self.pairs_written as int
        } else {
            read32(self.page@, 4 + (if self.fixed_key_size.is_none() { 4 * self.num_pairs as int } else { 0 })
                + 4 * (self.pairs_written as int - 1))
        }
    }

    pub closed spec fn ready(self, key: Seq<u8>, value: Seq<u8>) -> bool {
        &&& self.num_pairs <= 65535
        &&& self.pairs_written < self.num_pairs
        &&& self.meta() <= self.page@.len() <= usize::MAX
        &&& self.meta() <= self.key_position()
        &&& self.key_position() + key.len() <= self.meta() + self.provisioned_key_bytes as int
        &&& self.meta() + self.provisioned_key_bytes as int <= self.value_position()
        &&& self.value_position() + value.len() <= self.page@.len()
        &&& self.fixed_key_size.is_some() ==> self.fixed_key_size.unwrap() == key.len()
        &&& self.fixed_value_size.is_some() ==> self.fixed_value_size.unwrap() == value.len()
        &&& self.fixed_key_size.is_none() ==> self.key_position() + key.len() <= u32::MAX
        &&& self.fixed_value_size.is_none() ==> self.value_position() + value.len() <= u32::MAX
    }

    pub closed spec fn after_bytes(self, key: Seq<u8>, value: Seq<u8>) -> Seq<u8> {
        let bytes = self.page@;
        let key_start = self.key_position();
        let value_start = self.value_position();
        let bytes = if self.fixed_key_size.is_none() {
            patch(bytes, 4 + 4 * self.pairs_written as int,
                vstd::bytes::spec_u32_to_le_bytes((key_start + key.len()) as u32))
        } else { bytes };
        let bytes = patch(bytes, key_start, key);
        let bytes = if self.fixed_value_size.is_none() {
            patch(bytes, 4 + (if self.fixed_key_size.is_none() { 4 * self.num_pairs as int } else { 0 })
                + 4 * self.pairs_written as int,
                vstd::bytes::spec_u32_to_le_bytes((value_start + value.len()) as u32))
        } else { bytes };
        patch(bytes, value_start, value)
    }

    pub closed spec fn contents(self) -> Seq<u8> { self.page@ }

    #[verifier::prophetic]
    pub closed spec fn eventual_contents(self) -> Seq<u8> { final(self.page)@ }

    pub closed spec fn shape(self) -> (Option<usize>, Option<usize>, usize, usize) {
        (self.fixed_key_size, self.fixed_value_size, self.num_pairs, self.provisioned_key_bytes)
    }

    pub closed spec fn written(self) -> int { self.pairs_written as int }

    pub proof fn initial_step_formula(builder: Self, key: Seq<u8>, value: Seq<u8>)
        requires builder.written() == 0,
        ensures builder.after_bytes(key, value) == first_bytes(builder.contents(),
            builder.shape().2 as int, builder.shape().0, builder.shape().1,
            builder.shape().3 as int, key, value),
            builder.key_position() == metadata(builder.shape().2 as int, builder.shape().0, builder.shape().1),
            builder.value_position() == metadata(builder.shape().2 as int, builder.shape().0, builder.shape().1)
                + builder.shape().3 as int,
            builder.key_slot() == 4,
            builder.value_slot() == 4 + (if builder.shape().0.is_none() { 4 * builder.shape().2 as int } else { 0 }),
    {
    }

    pub proof fn ready_initial(builder: Self, key: Seq<u8>, value: Seq<u8>)
        requires
            builder.written() == 0,
            1 <= builder.shape().2 <= 65535,
            builder.contents().len() <= usize::MAX,
            metadata(builder.shape().2 as int, builder.shape().0, builder.shape().1)
                + builder.shape().3 as int + value.len() <= builder.contents().len(),
            key.len() <= builder.shape().3,
            builder.shape().0.is_some() ==> builder.shape().0.unwrap() == key.len(),
            builder.shape().1.is_some() ==> builder.shape().1.unwrap() == value.len(),
            builder.shape().0.is_none() ==> metadata(builder.shape().2 as int, builder.shape().0, builder.shape().1) + key.len() <= u32::MAX,
            builder.shape().1.is_none() ==> metadata(builder.shape().2 as int, builder.shape().0, builder.shape().1)
                + builder.shape().3 as int + value.len() <= u32::MAX,
        ensures builder.ready(key, value),
    {
    }

    pub closed spec fn key_slot(self) -> int { 4 + 4 * self.pairs_written as int }

    pub closed spec fn value_slot(self) -> int {
        4 + (if self.fixed_key_size.is_none() { 4 * self.num_pairs as int } else { 0 })
            + 4 * self.pairs_written as int
    }

    pub closed spec fn touched(self, key: Seq<u8>, value: Seq<u8>, index: int) -> bool {
        ||| self.key_position() <= index < self.key_position() + key.len()
        ||| self.value_position() <= index < self.value_position() + value.len()
        ||| self.fixed_key_size.is_none() && self.key_slot() <= index < self.key_slot() + 4
        ||| self.fixed_value_size.is_none() && self.value_slot() <= index < self.value_slot() + 4
    }

    pub proof fn step_facts(before: Self, key: Seq<u8>, value: Seq<u8>)
        requires before.ready(key, value),
        ensures
            before.after_bytes(key, value).len() == before.contents().len(),
            before.after_bytes(key, value).subrange(before.key_position(), before.key_position() + key.len()) == key,
            before.after_bytes(key, value).subrange(before.value_position(), before.value_position() + value.len()) == value,
            before.after_bytes(key, value).subrange(0, 4) == before.contents().subrange(0, 4),
            before.shape().0.is_none() ==> read32(before.after_bytes(key, value), before.key_slot()) == before.key_position() + key.len(),
            before.shape().1.is_none() ==> read32(before.after_bytes(key, value), before.value_slot()) == before.value_position() + value.len(),
            forall|index: int| 0 <= index < before.contents().len() && !before.touched(key, value, index)
                ==> #[trigger] before.after_bytes(key, value)[index] == before.contents()[index],
    {
        vstd::bytes::lemma_auto_spec_u32_to_from_le_bytes();
        let bytes = before.page@;
        let key_start = before.key_position();
        let value_start = before.value_position();
        let key_slot = before.key_slot();
        let value_slot = before.value_slot();
        let key_encoding = vstd::bytes::spec_u32_to_le_bytes((key_start + key.len()) as u32);
        let value_encoding = vstd::bytes::spec_u32_to_le_bytes((value_start + value.len()) as u32);
        let first = if before.fixed_key_size.is_none() {
            patch_facts(bytes, key_slot, key_encoding);
            patch(bytes, key_slot, key_encoding)
        } else { bytes };
        patch_facts(first, key_start, key);
        let second = patch(first, key_start, key);
        let third = if before.fixed_value_size.is_none() {
            patch_facts(second, value_slot, value_encoding);
            patch(second, value_slot, value_encoding)
        } else { second };
        patch_facts(third, value_start, value);
        let after = patch(third, value_start, value);
        assert(after == before.after_bytes(key, value));
        assert(after.subrange(key_start, key_start + key.len()) =~= key);
        assert(after.subrange(value_start, value_start + value.len()) =~= value);
        assert(after.subrange(0, 4) =~= bytes.subrange(0, 4));
        if before.fixed_key_size.is_none() {
            assert(after.subrange(key_slot, key_slot + 4) =~= key_encoding);
        }
        if before.fixed_value_size.is_none() {
            assert(after.subrange(value_slot, value_slot + 4) =~= value_encoding);
        }
    }

    pub fn required_bytes(
        num_pairs: usize,
        keys_values_bytes: usize,
        key_size: Option<usize>,
        value_size: Option<usize>,
    ) -> (result: usize)
        requires metadata(num_pairs as int, key_size, value_size) + keys_values_bytes <= usize::MAX,
        ensures result as int == metadata(num_pairs as int, key_size, value_size) + keys_values_bytes,
    {
        let mut result = 4;
        if key_size.is_none() {
            result += num_pairs * size_of::<u32>();
        }
        if value_size.is_none() {
            result += num_pairs * size_of::<u32>();
        }
        result += keys_values_bytes;

        result
    }

    fn key_section_start(&self) -> (result: usize)
        requires self.num_pairs <= 65535,
        ensures result as int == self.meta(),
    {
        let mut offset = 4;
        if self.fixed_key_size.is_none() {
            offset += size_of::<u32>() * self.num_pairs;
        }
        if self.fixed_value_size.is_none() {
            offset += size_of::<u32>() * self.num_pairs;
        }

        offset
    }

    fn key_end(&self, n: usize) -> (result: usize)
        requires
            self.num_pairs <= 65535,
            n < self.num_pairs,
            self.meta() <= self.page@.len(),
            self.fixed_key_size.is_some() ==>
                self.meta() + self.fixed_key_size.unwrap() as int * (n as int + 1) <= usize::MAX,
        ensures result as int == if self.fixed_key_size.is_some() {
                self.meta() + self.fixed_key_size.unwrap() as int * (n as int + 1)
            } else { read32(self.contents(), 4 + 4 * n as int) },
    {
        if let Some(fixed) = self.fixed_key_size {
            return self.key_section_start() + fixed * (n + 1);
        }
        let offset = 4 + size_of::<u32>() * n;
        u32::from_le_bytes(
            self.page[offset..(offset + size_of::<u32>())]
                .try_into()
                .unwrap(),
        ) as usize
    }

    fn value_end(&self, n: usize) -> (result: usize)
        requires
            self.num_pairs <= 65535,
            n < self.num_pairs,
            self.meta() <= self.page@.len(),
            self.fixed_value_size.is_some() ==>
                self.meta() + self.provisioned_key_bytes as int
                    + self.fixed_value_size.unwrap() as int * (n as int + 1) <= usize::MAX,
        ensures result as int == if self.fixed_value_size.is_some() {
                self.meta() + self.provisioned_key_bytes as int
                    + self.fixed_value_size.unwrap() as int * (n as int + 1)
            } else {
                read32(self.contents(), 4 + (if self.fixed_key_size.is_none() { 4 * self.num_pairs as int } else { 0 })
                    + 4 * n as int)
            },
    {
        if let Some(fixed) = self.fixed_value_size {
            return self.key_section_start() + self.provisioned_key_bytes + fixed * (n + 1);
        }
        let mut offset = 4 + size_of::<u32>() * n;
        if self.fixed_key_size.is_none() {
            offset += size_of::<u32>() * self.num_pairs;
        }
        u32::from_le_bytes(
            self.page[offset..(offset + size_of::<u32>())]
                .try_into()
                .unwrap(),
        ) as usize
    }

    pub fn append(&mut self, key: &[u8], value: &[u8])
        requires old(self).ready(key@, value@),
        ensures
            final(self).contents() == old(self).after_bytes(key@, value@),
            old(self).eventual_contents() == final(self).eventual_contents(),
            final(self).shape() == old(self).shape(),
            final(self).written() == old(self).written() + 1,
    {
        if let Some(key_width) = self.fixed_key_size {
            assert_eq!(key_width, key.len());
        }
        if let Some(value_width) = self.fixed_value_size {
            assert_eq!(value_width, value.len());
        }
        let key_offset = if self.pairs_written == 0 {
            self.key_section_start()
        } else {
            self.key_end(self.pairs_written - 1)
        };
        let value_offset = if self.pairs_written == 0 {
            self.key_section_start() + self.provisioned_key_bytes
        } else {
            self.value_end(self.pairs_written - 1)
        };

        let n = self.pairs_written;
        if self.fixed_key_size.is_none() {
            let offset = 4 + size_of::<u32>() * n;
            self.page[offset..(offset + size_of::<u32>())]
                .copy_from_slice(&u32::try_from(key_offset + key.len()).unwrap().to_le_bytes());
        }
        self.page[key_offset..(key_offset + key.len())].copy_from_slice(key);
        let written_key_len = key_offset + key.len() - self.key_section_start();
        assert!(written_key_len <= self.provisioned_key_bytes);

        if self.fixed_value_size.is_none() {
            let mut offset = 4 + size_of::<u32>() * n;
            if self.fixed_key_size.is_none() {
                offset += size_of::<u32>() * self.num_pairs;
            }
            self.page[offset..(offset + size_of::<u32>())].copy_from_slice(
                &u32::try_from(value_offset + value.len())
                    .unwrap()
                    .to_le_bytes(),
            );
        }
        self.page[value_offset..(value_offset + value.len())].copy_from_slice(value);
        self.pairs_written += 1;
    }
}
}

verus! {

pub open spec fn payload_sum(parts: Seq<Seq<u8>>, count: int) -> int
    recommends 0 <= count <= parts.len(),
    decreases count,
{
    if count <= 0 { 0 } else { payload_sum(parts, count - 1) + parts[count - 1].len() }
}

pub proof fn payload_nonnegative(parts: Seq<Seq<u8>>, count: int)
    requires 0 <= count <= parts.len(),
    ensures 0 <= payload_sum(parts, count),
    decreases count,
{
    if count > 0 { payload_nonnegative(parts, count - 1); }
}

pub proof fn payload_monotone(parts: Seq<Seq<u8>>, left: int, right: int)
    requires 0 <= left <= right <= parts.len(),
    ensures 0 <= payload_sum(parts, left) <= payload_sum(parts, right),
    decreases right - left,
{
    payload_nonnegative(parts, left);
    if left < right { payload_monotone(parts, left, right - 1); }
}

impl<'a> RawLeafBuilder<'a> {
    pub closed spec fn key_at(self, boundary: int) -> int {
        if boundary == 0 { self.meta() }
        else if self.fixed_key_size.is_some() { self.meta() + self.fixed_key_size.unwrap() as int * boundary }
        else { read32(self.contents(), 4 + 4 * (boundary - 1)) }
    }

    pub closed spec fn value_at(self, boundary: int) -> int {
        if boundary == 0 { self.meta() + self.provisioned_key_bytes as int }
        else if self.fixed_value_size.is_some() {
            self.meta() + self.provisioned_key_bytes as int + self.fixed_value_size.unwrap() as int * boundary
        } else {
            read32(self.contents(), 4 + (if self.fixed_key_size.is_none() { 4 * self.num_pairs as int } else { 0 })
                + 4 * (boundary - 1))
        }
    }

    pub closed spec fn built_prefix(self, keys: Seq<Seq<u8>>, values: Seq<Seq<u8>>, initial: Seq<u8>) -> bool {
        &&& 1 <= self.num_pairs <= 65535
        &&& keys.len() == self.num_pairs
        &&& values.len() == self.num_pairs
        &&& self.pairs_written <= self.num_pairs
        &&& self.provisioned_key_bytes as int == payload_sum(keys, keys.len() as int)
        &&& self.contents().len() == initial.len()
        &&& self.meta() + self.provisioned_key_bytes as int + payload_sum(values, values.len() as int)
            <= initial.len() <= usize::MAX
        &&& self.meta() + self.provisioned_key_bytes as int + payload_sum(values, values.len() as int) <= u32::MAX
        &&& self.contents()[0] == LEAF
        &&& self.contents()[1] == initial[1]
        &&& read16(self.contents(), 2) == self.num_pairs as int
        &&& forall|index: int| 0 <= index < keys.len() && self.fixed_key_size.is_some()
            ==> #[trigger] keys[index].len() == self.fixed_key_size.unwrap()
        &&& forall|index: int| 0 <= index < values.len() && self.fixed_value_size.is_some()
            ==> #[trigger] values[index].len() == self.fixed_value_size.unwrap()
        &&& forall|boundary: int| 0 <= boundary <= self.pairs_written
            ==> #[trigger] self.key_at(boundary) == self.meta() + payload_sum(keys, boundary)
        &&& forall|boundary: int| 0 <= boundary <= self.pairs_written
            ==> #[trigger] self.value_at(boundary) == self.meta() + self.provisioned_key_bytes as int + payload_sum(values, boundary)
        &&& forall|index: int| 0 <= index < self.pairs_written
            ==> #[trigger] self.contents().subrange(self.meta() + payload_sum(keys, index),
                self.meta() + payload_sum(keys, index + 1)) == keys[index]
        &&& forall|index: int| 0 <= index < self.pairs_written
            ==> #[trigger] self.contents().subrange(self.meta() + self.provisioned_key_bytes as int + payload_sum(values, index),
                self.meta() + self.provisioned_key_bytes as int + payload_sum(values, index + 1)) == values[index]
        &&& forall|index: int| self.meta() + self.provisioned_key_bytes as int + payload_sum(values, values.len() as int)
            <= index < initial.len() ==> #[trigger] self.contents()[index] == initial[index]
    }

    proof fn prefix_start(writer: Self, keys: Seq<Seq<u8>>, values: Seq<Seq<u8>>, initial: Seq<u8>)
        requires
            writer.written() == 0, 1 <= writer.num_pairs <= 65535,
            keys.len() == writer.num_pairs, values.len() == writer.num_pairs,
            writer.provisioned_key_bytes as int == payload_sum(keys, keys.len() as int),
            writer.contents() == initialized_bytes(initial, writer.num_pairs as int, writer.fixed_key_size, writer.fixed_value_size),
            writer.meta() + writer.provisioned_key_bytes as int + payload_sum(values, values.len() as int)
                <= initial.len() <= usize::MAX,
            writer.meta() + writer.provisioned_key_bytes as int + payload_sum(values, values.len() as int) <= u32::MAX,
            forall|index: int| 0 <= index < keys.len() && writer.fixed_key_size.is_some()
                ==> #[trigger] keys[index].len() == writer.fixed_key_size.unwrap(),
            forall|index: int| 0 <= index < values.len() && writer.fixed_value_size.is_some()
                ==> #[trigger] values[index].len() == writer.fixed_value_size.unwrap(),
        ensures writer.built_prefix(keys, values, initial),
    {
        payload_nonnegative(keys, keys.len() as int);
        payload_nonnegative(values, values.len() as int);
        initial_byte_facts(initial, writer.num_pairs as int, writer.fixed_key_size, writer.fixed_value_size);
        assert(writer.contents().len() == initial.len());
        assert(writer.contents()[0] == LEAF);
        assert(writer.contents()[1] == initial[1]);
        assert(read16(writer.contents(), 2) == writer.num_pairs as int);
        assert forall|boundary: int| #![all_triggers] 0 <= boundary <= writer.pairs_written implies {
            &&& writer.key_at(boundary) == writer.meta() + payload_sum(keys, boundary)
            &&& writer.value_at(boundary) == writer.meta() + writer.provisioned_key_bytes as int + payload_sum(values, boundary)
        } by { assert(boundary == 0); }
        assert forall|index: int| writer.meta() + writer.provisioned_key_bytes as int + payload_sum(values, values.len() as int)
            <= index < initial.len() implies #[trigger] writer.contents()[index] == initial[index] by { }
        reveal(RawLeafBuilder::built_prefix);
    }

    pub proof fn prefix_ready(writer: Self, keys: Seq<Seq<u8>>, values: Seq<Seq<u8>>, initial: Seq<u8>)
        requires writer.built_prefix(keys, values, initial), writer.written() < keys.len(),
        ensures writer.ready(keys[writer.written()], values[writer.written()]),
    {
        let done = writer.written();
        payload_monotone(keys, done, done + 1);
        payload_monotone(keys, done + 1, keys.len() as int);
        payload_monotone(values, done, done + 1);
        payload_monotone(values, done + 1, values.len() as int);
        assert(writer.key_position() == writer.key_at(done));
        assert(writer.value_position() == writer.value_at(done));
    }

    pub proof fn append_range_frame(before: Self, key: Seq<u8>, value: Seq<u8>, start: int, end: int)
        requires before.ready(key, value), 0 <= start <= end <= before.contents().len(),
            forall|index: int| start <= index < end ==> !before.touched(key, value, index),
        ensures before.after_bytes(key, value).subrange(start, end) == before.contents().subrange(start, end),
    {
        Self::step_facts(before, key, value);
        assert(before.after_bytes(key, value).subrange(start, end) =~= before.contents().subrange(start, end));
    }

    pub proof fn prefix_step(before: Self, after: Self, keys: Seq<Seq<u8>>, values: Seq<Seq<u8>>, initial: Seq<u8>)
        requires
            before.built_prefix(keys, values, initial), before.written() < keys.len(),
            before.ready(keys[before.written()], values[before.written()]),
            after.contents() == before.after_bytes(keys[before.written()], values[before.written()]),
            after.shape() == before.shape(), after.written() == before.written() + 1,
        ensures after.built_prefix(keys, values, initial),
    {
        let done = before.written();
        let key = keys[done];
        let value = values[done];
        assert(after.fixed_key_size == before.fixed_key_size);
        assert(after.fixed_value_size == before.fixed_value_size);
        assert(after.num_pairs == before.num_pairs);
        assert(after.provisioned_key_bytes == before.provisioned_key_bytes);
        Self::step_facts(before, key, value);
        payload_monotone(keys, done + 1, keys.len() as int);
        payload_monotone(values, done + 1, values.len() as int);
        assert(before.key_position() == before.key_at(done));
        assert(before.value_position() == before.value_at(done));
        assert(after.contents().subrange(2, 4) =~= before.contents().subrange(2, 4));
        assert(after.contents()[0] == before.contents()[0]);
        assert(after.contents()[1] == before.contents()[1]);
        assert forall|boundary: int| #![all_triggers] 0 <= boundary <= done + 1 implies {
            &&& after.key_at(boundary) == after.meta() + payload_sum(keys, boundary)
            &&& after.value_at(boundary) == after.meta() + after.provisioned_key_bytes as int + payload_sum(values, boundary)
        } by {
            if boundary <= done {
                if 0 < boundary && before.fixed_key_size.is_none() {
                    let start = 4 + 4 * (boundary - 1);
                    assert forall|index: int| start <= index < start + 4 implies !before.touched(key, value, index) by { }
                    Self::append_range_frame(before, key, value, start, start + 4);
                }
                if 0 < boundary && before.fixed_value_size.is_none() {
                    let start = 4 + (if before.fixed_key_size.is_none() { 4 * before.num_pairs as int } else { 0 }) + 4 * (boundary - 1);
                    assert forall|index: int| start <= index < start + 4 implies !before.touched(key, value, index) by { }
                    Self::append_range_frame(before, key, value, start, start + 4);
                }
                assert(after.key_at(boundary) == before.key_at(boundary));
                assert(after.value_at(boundary) == before.value_at(boundary));
            } else {
                assert(boundary == done + 1);
                assert(payload_sum(keys, boundary) == payload_sum(keys, done) + key.len());
                assert(payload_sum(values, boundary) == payload_sum(values, done) + value.len());
                if before.fixed_key_size.is_some() {
                    let width = before.fixed_key_size.unwrap() as int;
                    assert(key.len() == width);
                    vstd::arithmetic::mul::lemma_mul_basics(width);
                    assert(width * (done + 1) == width * done + width) by (nonlinear_arith);
                    assert(after.key_at(boundary) == before.meta() + width * (done + 1));
                    assert(before.key_position() == before.meta() + width * done);
                } else {
                    assert(before.key_slot() == 4 + 4 * done);
                    assert(after.key_at(boundary) == read32(after.contents(), before.key_slot()));
                    assert(read32(after.contents(), before.key_slot()) == before.key_position() + key.len());
                }
                if before.fixed_value_size.is_some() {
                    let width = before.fixed_value_size.unwrap() as int;
                    vstd::arithmetic::mul::lemma_mul_basics(width);
                    assert(width * (done + 1) == width * done + width) by (nonlinear_arith);
                }
                assert(after.key_at(boundary) == before.key_position() + key.len());
                assert(after.value_at(boundary) == before.value_position() + value.len());
            }
        }
        assert forall|boundary: int| 0 <= boundary <= done + 1 implies
            #[trigger] after.key_at(boundary) == after.meta() + payload_sum(keys, boundary) by {
            assert(after.value_at(boundary) == after.meta() + after.provisioned_key_bytes as int + payload_sum(values, boundary));
        }
        assert forall|index: int| #![all_triggers] 0 <= index < done + 1 implies {
            &&& after.contents().subrange(after.meta() + payload_sum(keys, index),
                after.meta() + payload_sum(keys, index + 1)) == keys[index]
            &&& after.contents().subrange(after.meta() + after.provisioned_key_bytes as int + payload_sum(values, index),
                after.meta() + after.provisioned_key_bytes as int + payload_sum(values, index + 1)) == values[index]
        } by {
            if index < done {
                payload_monotone(keys, index, index + 1);
                payload_monotone(keys, index + 1, done);
                payload_monotone(values, index, index + 1);
                payload_monotone(values, index + 1, done);
                let key_start = before.meta() + payload_sum(keys, index);
                let key_end = before.meta() + payload_sum(keys, index + 1);
                let value_start = before.meta() + before.provisioned_key_bytes as int + payload_sum(values, index);
                let value_end = before.meta() + before.provisioned_key_bytes as int + payload_sum(values, index + 1);
                assert forall|byte: int| key_start <= byte < key_end implies !before.touched(key, value, byte) by { }
                assert forall|byte: int| value_start <= byte < value_end implies !before.touched(key, value, byte) by { }
                Self::append_range_frame(before, key, value, key_start, key_end);
                Self::append_range_frame(before, key, value, value_start, value_end);
            } else {
                assert(index == done);
            }
        }
        assert forall|index: int| 0 <= index < done + 1 implies
            #[trigger] after.contents().subrange(after.meta() + payload_sum(keys, index),
                after.meta() + payload_sum(keys, index + 1)) == keys[index] by {
            assert(after.contents().subrange(after.meta() + after.provisioned_key_bytes as int + payload_sum(values, index),
                after.meta() + after.provisioned_key_bytes as int + payload_sum(values, index + 1)) == values[index]);
        }
        assert forall|index: int| after.meta() + after.provisioned_key_bytes as int + payload_sum(values, values.len() as int)
            <= index < initial.len() implies #[trigger] after.contents()[index] == initial[index] by {
            assert(!before.touched(key, value, index));
        }
        reveal(RawLeafBuilder::built_prefix);
    }
}
}

verus! {

pub open spec fn part_views<'p>(parts: Seq<&'p [u8]>) -> Seq<Seq<u8>> {
    Seq::new(parts.len(), |index: int| parts[index]@)
}

impl<'a> RawLeafBuilder<'a> {
    pub proof fn complete_grammar(writer: Self, keys: Seq<Seq<u8>>, values: Seq<Seq<u8>>, initial: Seq<u8>)
        requires writer.built_prefix(keys, values, initial), writer.written() == keys.len(),
        ensures
            leaf::leaf_bytes_wf(writer.contents(), writer.shape().0, writer.shape().1),
            leaf::pair_count(writer.contents()) == keys.len(),
            forall|index: int| 0 <= index < keys.len() ==> #[trigger]
                leaf::encoded_key(writer.contents(), writer.shape().0, writer.shape().1, index) == keys[index],
            forall|index: int| 0 <= index < values.len() ==> #[trigger]
                leaf::encoded_value(writer.contents(), writer.shape().0, writer.shape().1, index) == values[index],
            writer.key_position() == writer.meta() + writer.shape().3 as int,
    {
        let bytes = writer.contents();
        let key_width = writer.fixed_key_size;
        let value_width = writer.fixed_value_size;
        let count = writer.num_pairs as int;
        let base = writer.meta();
        let reserved = writer.provisioned_key_bytes as int;
        assert(leaf::pair_count(bytes) == count);
        assert(writer.key_position() == writer.key_at(count));
        assert(writer.key_at(count) == base + reserved);
        assert forall|boundary: int| #![all_triggers] 0 <= boundary <= count implies {
            &&& leaf::key_boundary(bytes, key_width, value_width, boundary) == base + payload_sum(keys, boundary)
            &&& leaf::value_boundary(bytes, key_width, value_width, boundary) == base + reserved + payload_sum(values, boundary)
            &&& base <= leaf::key_boundary(bytes, key_width, value_width, boundary) <= bytes.len()
            &&& leaf::key_boundary(bytes, key_width, value_width, boundary) <= u32::MAX
            &&& base + reserved <= leaf::value_boundary(bytes, key_width, value_width, boundary) <= bytes.len()
            &&& leaf::value_boundary(bytes, key_width, value_width, boundary) <= u32::MAX
        } by {
            payload_monotone(keys, 0, boundary);
            payload_monotone(keys, boundary, count);
            payload_monotone(values, 0, boundary);
            payload_monotone(values, boundary, count);
            assert(leaf::key_boundary(bytes, key_width, value_width, boundary) == writer.key_at(boundary));
            assert(leaf::value_boundary(bytes, key_width, value_width, boundary) == writer.value_at(boundary));
        }
        assert forall|left: int, right: int| #![all_triggers] 0 <= left <= right <= count implies {
            &&& leaf::key_boundary(bytes, key_width, value_width, left) <= leaf::key_boundary(bytes, key_width, value_width, right)
            &&& leaf::value_boundary(bytes, key_width, value_width, left) <= leaf::value_boundary(bytes, key_width, value_width, right)
        } by {
            payload_monotone(keys, left, right);
            payload_monotone(values, left, right);
        }
        assert forall|index: int| 0 <= index < keys.len() implies #[trigger]
            leaf::encoded_key(bytes, key_width, value_width, index) == keys[index] by { }
        assert forall|index: int| 0 <= index < values.len() implies #[trigger]
            leaf::encoded_value(bytes, key_width, value_width, index) == values[index] by { }
    }
}

pub fn build_leaf_projection<'a>(page: &'a mut [u8], key_parts: &[&[u8]], value_parts: &[&[u8]],
    key_width: Option<usize>, value_width: Option<usize>, reserved: usize) -> (result: &'a mut [u8])
    requires
        1 <= key_parts@.len() <= 65535, value_parts@.len() == key_parts@.len(),
        reserved as int == payload_sum(part_views(key_parts@), key_parts@.len() as int),
        metadata(key_parts@.len() as int, key_width, value_width) + reserved as int
            + payload_sum(part_views(value_parts@), value_parts@.len() as int) <= page@.len() <= usize::MAX,
        metadata(key_parts@.len() as int, key_width, value_width) + reserved as int
            + payload_sum(part_views(value_parts@), value_parts@.len() as int) <= u32::MAX,
        forall|index: int| 0 <= index < key_parts@.len() && key_width.is_some()
            ==> #[trigger] key_parts@[index]@.len() == key_width.unwrap(),
        forall|index: int| 0 <= index < value_parts@.len() && value_width.is_some()
            ==> #[trigger] value_parts@[index]@.len() == value_width.unwrap(),
    ensures
        leaf::leaf_bytes_wf(result@, key_width, value_width),
        leaf::pair_count(result@) == key_parts@.len(),
        forall|index: int| 0 <= index < key_parts@.len() ==> #[trigger]
            leaf::encoded_key(result@, key_width, value_width, index) == key_parts@[index]@,
        forall|index: int| 0 <= index < value_parts@.len() ==> #[trigger]
            leaf::encoded_value(result@, key_width, value_width, index) == value_parts@[index]@,
        result@.len() == old(page)@.len(), result@[1] == old(page)@[1],
        forall|index: int| metadata(key_parts@.len() as int, key_width, value_width) + reserved as int
            + payload_sum(part_views(value_parts@), value_parts@.len() as int) <= index < old(page)@.len()
            ==> #[trigger] result@[index] == old(page)@[index],
{
    let ghost initial = page@;
    let ghost keys = part_views(key_parts@);
    let ghost values = part_views(value_parts@);
    let count = key_parts.len();
    proof {
        payload_nonnegative(keys, count as int);
        payload_nonnegative(values, count as int);
    }
    let mut writer = RawLeafBuilder::new(page, count, key_width, value_width, reserved);
    proof { RawLeafBuilder::prefix_start(writer, keys, values, initial); }
    let mut index = 0;
    while index < count
        invariant
            writer.built_prefix(keys, values, initial),
            writer.shape() == (key_width, value_width, count, reserved),
            index as int == writer.written(), index <= count,
            count == key_parts@.len(), count == value_parts@.len(),
            keys == part_views(key_parts@), values == part_views(value_parts@),
        decreases count - index,
    {
        let key = key_parts[index];
        let value = value_parts[index];
        let ghost before = writer;
        proof { RawLeafBuilder::prefix_ready(before, keys, values, initial); }
        writer.append(key, value);
        proof { RawLeafBuilder::prefix_step(before, writer, keys, values, initial); }
        index += 1;
    }
    proof { RawLeafBuilder::complete_grammar(writer, keys, values, initial); }
    writer.into_page_projection()
}
}
