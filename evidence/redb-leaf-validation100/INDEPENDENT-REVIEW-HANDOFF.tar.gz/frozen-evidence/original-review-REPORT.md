# Independent bounded review: native sorted-leaf lookup reference007

Review dates: November 5–6, 2026, America/Chicago; process receipts use November 6 UTC.
This is a NEW independent review of the ordinary byte-format/search reference and
its private numerical std-contract proposal. No subdelegation, source repair,
native edit, Git write, network operation, compiler/vstd/Cargo/harness build,
production adoption, or interrupted destructor/compiler-data validation occurred.
The parent owns reassessment; this report stops at handoff.

## Findings, severity ordered

1. **HIGH — original-input preservation remains FAILED.** All 1,331 original
   guarded native paths are still missing, and original native Git metadata
   continuity is UNAVAILABLE. This is an actual preservation failure, not a
   successful 1,401/1,331 original-inventory preservation check. Independently
   authenticated recovered CONTENTS are a qualified substitute for source
   correspondence, not restoration of original paths or metadata. No actor or
   cause is attributed. This exception blocks any unqualified preservation or
   native-repository-continuity assertion, not the precisely conditional proof
   about those recovered bytes. See preservation-comparison.json and the
   independently recorded read-only pinned-object checks.
2. **HIGH adoption/trust boundary — midpoint is newly ASSUMED, not implemented
   and proved here.** The one private usize::midpoint declaration has a plausible
   item/signature, unsigned mathematical floor-average postcondition, no caller
   precondition, opens_invariants none and no_unwind. No blocking mismatch was
   found for this bounded API model. This is approval only of the explicitly
   conditional boundary's plausibility/disclosure, NOT a Rust-core implementation
   proof, application search axiom, exhaustive TCB certification, production
   adoption, or approval inherited from the earlier six LE boundaries.
3. **MEDIUM — supplemental independent validation is incomplete.** Fresh
   application013, generic_adversarial.rs, reports 2 verified / 1 failed function
   and two assertion diagnostics at input.rs:14 and :17. These attempt to restate
   the exported insertion partition using leaf::encoded_key terms. The entire
   selected three-method scope is NOT certified; checked scope counts are 0/0.
   It receives ZERO complete-scope or control credit, including its other
   supplemental methods. No source was repaired, no retry or narrowed-scope
   extraction was run, and no cause such as a mere trigger issue is asserted as
   established. This does not demonstrate a target-source counterexample; the
   exact provider and existing generic imported byte client independently pass.
   Nevertheless an all-fresh-checks-PASS claim would be false. Resolution, if
   desired, requires a separately authorized parent decision.
4. **MEDIUM preservation qualification — shared refs differ from parent final.**
   Three added refs in the t3/orchestration-v2/checkpoints namespace are observed;
   no existing ref is changed or removed. Owned HEAD, branch, index and status
   still match parent final. The added refs' actor/cause is not attributed.
   The reviewer issued no Git-mutating command, but shared-refs-unchanged is
   NOT a valid endpoint claim. See shared-ref-drift.json/.diff; historical/shared
   Git objectstore remains NOT_CERTIFIED.
5. **MEDIUM scope boundaries — no full native trait/producer/lifecycle theorem.**
   Value/Key is a comparison/from_bytes-only projection. Native Value GATs,
   Debug, separators and complete trait ABI/closure are not verified. The
   authored builder and explicit slice-transfer adapter remain RELEASE-ONLY;
   native producer, Drop, caller, lifetime and exceptional behavior are not
   established. These are disclosed limits, not newly discovered hidden axioms.
   No physical32, whole-KV/storage/commit/recovery, compiler/destructor F2 or
   Infer-feature credit follows. All 18 database/history cells remain OPEN.

**Disposition:** no blocking correctness, selected-body correspondence, or
undeclared application-trust defect was found within the exact conditional
reference claims. The independent review is QUALIFIED by the original-path
loss and the unrepaired supplemental validation failure; it is not an
unconditional acceptance or a completely passing supplemental suite.

## Authentication and preservation evidence

The parent SEAL.json independently hashes to
39cd35936577c41b43949776012c984a874892729b4da5fa15760fc71721b04c.
All 1,676 payloads have exact membership, sizes and SHA256s, are regular
non-symlink read-only files, and match at entry and exit. MANIFEST/SEAL and the
report/summary hash bindings also match. No parent runner, checker, auditor or
finalizer was executed in place.

All six packages listed in inherited-authentication.json authenticate separately:
C0 provider 540 payloads; C0 review 321; builder-prefix006 170; prefix review 189;
original codec review 1,484; incremental codec review 389. Their exact seals,
membership and payloads pass at entry/exit. These remain INHERITED BOUNDED
EVIDENCE, not fresh verifier work or new midpoint approval. Their prior limits
on native ownership, std trust and global acceptance are retained.

Using baseline82 immutable-hashes.json and native-hashes.json independently:

- 132 recovered redb and 1,199 recovered Fedimint contents equal every original
  guarded SHA256; all are read-only regular snapshot files.
- Twelve Fedimint entries are materialized symlink REFERENTS, not preserved
  symlinks. Their original symlink object bytes/targets and materialized referent
  equality were separately reauthenticated. No original checkout was recreated.
- Seventy other immutable inputs remain at their original paths and match.
- Two read-only git cat-file --batch processes resolve the pinned commits and
  paths through surviving archives. Recomputed Git object hashes and every
  ordinary recovered blob match; the twelve symlink-target/referent chains
  match. The surviving 14 archive files match their recorded hashes. This does
  NOT certify historical/shared objectstore continuity, which remains
  NOT_CERTIFIED, or original native metadata continuity.
- All 2,345 live source inventory names match the parent final inventory. Exactly
  evidence/redb-crash-consistency94/STATUS.json and PROGRESS.md differ from its
  pre-documentation final snapshot, as disclosed in the brief. Entry/exit live
  source hashes are identical throughout THIS review. No live evidence document
  was edited by the reviewer. Current owned Git identity/status comparison is
  recorded field-by-field, separately from the failed native Git continuity.

The parent's first durable observation of loss was November 6, 2026,
05:07:15.773910 UTC, November 5 locally. Original-path preservation and recovered
content equality are deliberately separate verdicts. Neither endpoint hashing
nor read-only Git queries constitute transient-write, PID, or actor attribution.

## Independent source/contract audit

Source authority is recovered-native/redb at
c82ab865bb362bc4af067d332adc44978ff64813, authenticated to original guarded
contents and pinned objects, not an original surviving native checkout.

An independently authored lexer/bracket audit, not the parent's audit.py,
recompares all 21 C0 executable bodies plus position, find_key, u32 from_bytes
and u32 compare. All 25 full bodies match recovered native tokens after removal
of proof blocks/loop annotations. Signatures match modulo the stated visibility,
named result, Ordering qualification and explicit u32 macro substitution.
EntryAccessor/LeafAccessor fields, types and lifetime tokens also match. The
complete inherited C0 text is unchanged. This is source-token correspondence,
NOT native AST, full macro/trait ABI or whole-crate refinement certification.

The native binary-search loop, usize::midpoint call, comparator call order,
inclusive/exclusive bounds, early equality return and final debug assertion
are retained. The proof maintains a strict-before/strict-after partition and a
decreasing max_entry-min_entry measure. The midpoint assumption supplies an
in-range index without overflowing a machine a+b. This supports the native
conditional safety/termination and positioned/find_key contracts in both fresh
provider configurations. The new external expanded partition restatement in
application013 is explicitly NOT counted as successful independent validation.

The byte grammar retains counts 1..65535, metadata and every used key/value
endpoint bounded by both the slice length and u32::MAX, monotone intervals,
and arbitrary permitted spare tails. Sorted lookup additionally requires every
key to be exactly four canonical LE u32 bytes, in strictly increasing NUMERIC
order, and every query to have length four. Numeric order is not lexicographic
LE byte order. Fixed/variable key modes and independent fixed/variable values
are covered conditionally; empty/fixed0 values are permitted. No count0,
duplicate/unsorted-key, malformed-query or native producer guarantee is added.

The actual macro-instantiated u32 from_bytes/compare bodies are checked, not an
unimplemented concrete comparator oracle. The generic trait contract remains a
conditional abstraction for other K; only the named u32 instance is concretely
qualified here. The ordinary external search_u32 client uses new/find_key/
entry/key/value and checked byte-canonicality reasoning. Its contract returns
Some iff an exact key byte sequence exists, returns that query's original key
BYTES, and returns the original associated value BYTES. It is not merely a rank
or numeric-equality theorem. Fresh consumer verification is 3/0, with 2 exec
and 1 proof body, using newly emitted same-runtime provider/builder imports.

## Midpoint proposal and runtime binding

Exactly one private source differs from matching live vstd:
vstd/std_specs/num.rs, before
04daa2336d19e328c9dfa2ca8024af74ee242b79e03f0092142051d50050b6c1,
after 9c45cb906ea8e481ee2f40402dd1ab9710bdb5b2795f1d676ce91ece9b23d549.
The independent unified delta is midpoint-source.diff. It adds only the
cfg(not(verus_verify_core)) assumed usize::midpoint declaration.

Both arguments and result are by-value usize. Casting each argument to int
BEFORE addition gives a nonnegative mathematical sum, so /2 is floor and the
result lies within usize for every argument pair, including reversed arguments
and MAX/MAX. No invariant-bearing argument or mutable effect is modeled;
opens_invariants none and no_unwind are plausible for the ordinary unsigned
std operation. Frontend acceptance supplies item/signature compatibility, not
proof of the Rust-core implementation or of its panic/overflow behavior.

Nine runtime artifacts and 141 private source files have exact matching
membership and hashes. Only libvstd.rlib and vstd.vir differ from runtime005;
the host verifier/compiler and other runtime bytes are unchanged. The single
historical matched-vstd build records 2225/0 and its 141 source input bindings
match. This build is AUDITED ONLY, not rerun or credited as a core proof.
The historical 3,340-file sysroot binding and legacy 1,084-path compiler map
reauthenticate. That compiler map remains expressly NONEXHAUSTIVE.

The earlier six trusted LE std boundaries, this seventh campaign-added std
boundary, and preexisting verifier/std/Rust/solver assumptions remain TCB. This
is not a claim of only seven total axioms. There is no live adoption.

## Fresh independent verifier work

The new private root owns its runner, input copies, mutable directories,
invocations and receipts. Exactly **15/20** direct applications were reserved
and launched sequentially, including three ordinary compile/export applications
and every failed verification. Zero verifier setup/spawn/timeouts or frontend
failures occurred. Exactly **5/5** new exec/proof methods were authored; no new spec
methods or application assumptions were added. No source was repaired.

Every application retains full --no-cheating, --output-json, entire-crate scope,
one verifier thread, exact argv/environment/cwd, raw stdout/stderr, frozen input
hashes, explicit .vir/.rlib import hashes and all output hashes. Exported libraries
are ordinary fixtures, not compiler/vstd/Cargo/harness builds. Runtime and bound
inputs match after every application and again at exit.

| Fresh application | Result | Qualification |
| --- | --- | --- |
|001 provider release|37/0|25 exec + 6 proof; fresh .vir/.rlib|
|002 provider debug|37/0|same native source; 25 exec + 6 proof; no builder-debug credit|
|003 unchanged builder release|26/0|9 exec + 12 proof; imports fresh001; fresh .vir/.rlib|
|004 imported client release|3/0|2 exec + 1 proof; imports fresh001/003; fresh .vir/.rlib|
|005 parent witnesses replay|3/0|numeric-vs-byte order/all width combinations, MAX, empty/presence, midpoint extrema|
|006 correct value|1/0|original value [7] succeeds|
|007 wrong value|0/1|sole intended assertion at input.rs:14; [9] rejected|
|008 correct presence|1/0|presence counterpart succeeds|
|009 wrong absence|0/1|sole intended assertion at input.rs:14|
|010 unsorted keys|0/1|sole ordered_inputs precondition at input.rs:16|
|011 malformed query|0/1|sole length-four precondition at input.rs:8|
|012 wrong midpoint|0/1|sole intended assertion at input.rs:8|
|013 supplemental draft|2/1|two failed partition assertions, lines14/17; ZERO complete-scope/control credit|
|014 duplicate keys|0/1|sole ordered_inputs precondition at input.rs:12|
|015 count0 leaf|0/1|sole leaf_bytes_wf precondition at input.rs:8|

Thus seven complete positive applications pass and seven intended backend
controls discriminate at their specified locations. These are not eight
successful negative controls:013 is an unexpected failed draft, not a control.
Its raw 2/1 function summary does not certify the other two selected methods.
The three new draft methods attempted generic byte/partition transfer, general
midpoint properties and a raw variable-value singleton with arbitrary header,
value and spare-tail bytes. The two additional new methods are the duplicate
and zero-count premise controls. All five count against the method budget.

## Historical receipts — audited only

Two non-verifier tooling failures are retained in tooling-failures.json. A final
audit reader incorrectly resolved relative historical build-input names and
stopped at vstd/Cargo.lock. Its original script remains unmodified; separate
data-only finalization uses the recorded build cwd and verifies all141 inputs.
One document/data-file patch was rejected for an unmatched context, changing no
files, then reissued. Neither operation launched a verifier or repaired a
reviewed/verifier source. Even conservatively charging both failures gives
17/20 attempts; the exact direct-verifier process ledger contains15.

All 23 parent invocations, frozen input hashes, raw output hashes and retained
artifact hashes authenticate. The exact final bundle is provider009 leaf-final.vir
plus libleaf_decoder.rlib; unchanged builder010 builder-final.vir plus
libbuilder_step.rlib; client011 client-final.vir plus liblookup_client.rlib.
Sources match these final frozen inputs. Parent014 witnesses are separately
bound. No draft artifact or mismatched historical runtime substitutes for the
newly rebuilt import chain.

Parent016/018/019/020/021 each have exactly one intended backend obligation at
their documented lines; no frontend/resource diagnostic is credited. Their
corresponding fresh checks are007/009/010/011/012. Parent001/003/006/007/012/013
remain SIX FAILED DRAFTS, explicitly including the unsupported original-runtime
midpoint frontend rejection and the witness proof/resource failures. They
receive zero completed-result/control credit. The parent's one historical vstd
build is separate from those 23 application receipts and from fresh review work.

## Unresolved obligations and handoff

No safeguard-interrupted destructor/compiler-data work was retried, perturbed,
inspected via a candidate, or declared closed. Zero compiler/destructor F2,
native trait ABI, native producer/Drop/lifetime/caller, physical32, storage,
whole-KV, commit/recovery or Infer-feature credit is awarded. All 18 original
database/history cells remain OPEN; historical/shared objectstore is
NOT_CERTIFIED. The parent must own any reassessment, new validation authorization
or adoption decision. No repair or next-stage work is performed here.

Machine results: VERDICT.json, fresh-summary.json, application-ledger.json,
method-ledger.json, historical-audited-only.json, historical-clean-controls.json,
authentication{,-after}.json, source-audit.json, bindings{,-after}.json,
additional-binding-checks.json, recovery-chain.json and preservation-comparison.json.
REPLAY.md explains reproduction without executing a sealed runner in place.
