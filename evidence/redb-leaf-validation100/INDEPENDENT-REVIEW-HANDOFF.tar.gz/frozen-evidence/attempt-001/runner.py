import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import stat
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
REVIEW = Path('/private/tmp/verus-leaf007-independent-review-tOKSrsOe')
PARENT = Path('/private/tmp/verus-crash-consistency94-20261105/native-leaf-lookup-007')
PLAN = Path('/Users/tommyvolk/.t3/worktrees/verus/t3-60978068/evidence/redb-leaf-validation100/PLAN.md')
BASELINE = Path('/private/tmp/verus-review94-byte-step-20261105-UyVDNcAR/preservation-baseline.json')
PINS = {str(REVIEW): '286358f51477c3f14193f5230a047759f26e0f17c7655fc63427971809129e53', str(PARENT): '39cd35936577c41b43949776012c984a874892729b4da5fa15760fc71721b04c'}
START = '2026-11-08T00:16:12+00:00'

def digest(path):
    checksum = hashlib.sha256()
    with open(path, 'rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            checksum.update(block)
    return checksum.hexdigest()

def load(path):
    return json.loads(Path(path).read_text())

def write(path, value):
    Path(path).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

def budget():
    elapsed = (datetime.datetime.now(datetime.timezone.utc) - datetime.datetime.fromisoformat(START)).total_seconds()
    size = sum(path.stat().st_size for path in ROOT.rglob('*') if path.is_file())
    free = shutil.disk_usage(ROOT).free
    assert elapsed < 900, elapsed
    assert size <= 128 * 1024**2, size
    assert free > 16 * 1024**3, free
    return {'elapsed_seconds': elapsed, 'scratch_bytes': size, 'free_bytes': free}

def authenticate(stage):
    results = {'stage': stage, 'packages': {}, 'files': {}, 'budget': budget()}
    for root_string, expected in PINS.items():
        root = Path(root_string)
        assert digest(root / 'SEAL.json') == expected
        seal = load(root / 'SEAL.json')
        assert digest(root / 'MANIFEST.json') == seal['manifest_sha256']
        manifest = load(root / 'MANIFEST.json')
        names = {str(path.relative_to(root)) for path in root.rglob('*') if not path.is_dir()}
        assert names == set(manifest) | {'MANIFEST.json', 'SEAL.json'}
        assert len(manifest) == seal['payloads']
        for name, row in manifest.items():
            path = root / name
            status = path.lstat()
            assert stat.S_ISREG(status.st_mode) and not status.st_mode & 0o222, str(path)
            assert status.st_size == row['size_bytes'], str(path)
            assert digest(path) == row['sha256'], str(path)
        results['packages'][root_string] = {'seal_sha256': expected, 'manifest_sha256': seal['manifest_sha256'], 'payloads': len(manifest), 'exact_membership_regular_readonly_all_hashes': True}
    invocation = load(REVIEW / 'runs/attempt-013/invocation.json')
    runtime = PARENT / 'midpoint-runtime-proposal/runtime'
    binding = load(PARENT / 'midpoint-runtime-proposal/runtime-binding.json')
    for name, expected in invocation['runtime_sha256'].items():
        assert expected == binding['runtime'][name]
        path = runtime / name
        assert digest(path) == expected, str(path)
        results['files'][str(path)] = expected
    for path_string, expected in invocation['inputs'].items():
        assert digest(path_string) == expected, path_string
        results['files'][path_string] = expected
    for ordinal in (1, 3, 4, 13):
        path = REVIEW / f'runs/attempt-{ordinal:03d}/input.rs'
        results['files'][str(path)] = digest(path)
    sysroot = Path(binding['sysroot'])
    historical = load(BASELINE)
    sysroot_rows = {}
    for name, row in historical['sysroot_files'].items():
        path = sysroot / name
        assert path.is_symlink() == (row['symlink'] is not None), str(path)
        if path.is_symlink():
            assert os.readlink(path) == row['symlink'], str(path)
        assert path.stat().st_size == row['size_bytes'], str(path)
        assert digest(path) == row['sha256'], str(path)
        sysroot_rows[name] = row
    write(ROOT / f'sysroot-{stage}.json', sysroot_rows)
    results['sysroot'] = {'path': str(sysroot), 'files': len(sysroot_rows), 'baseline_sha256': digest(BASELINE), 'inventory_sha256': digest(ROOT / f'sysroot-{stage}.json'), 'qualification': 'Historical inventory read as corroboration; current exact files checked; no toolchain build/copy.'}
    for path in (PLAN, REVIEW / 'REPORT.md', REVIEW / 'REPLAY.md', REVIEW / 'preservation-comparison.json'):
        results['files'][str(path)] = digest(path)
    results['complete'] = True
    write(ROOT / f'authentication-{stage}.json', results)
    print(json.dumps({'authentication': stage, 'packages': results['packages'], 'sysroot_files': len(sysroot_rows), 'budget': budget()}))

def run(name, source):
    budget_before = budget()
    ledger = ROOT / 'application-ledger.jsonl'
    previous = ledger.read_text().splitlines() if ledger.exists() else []
    ordinal = len(previous) + 1
    assert ordinal <= 16
    output = ROOT / 'runs' / f'attempt-{ordinal:03d}'
    output.mkdir(parents=True)
    input_path = output / 'input.rs'
    shutil.copyfile(source, input_path)
    shutil.copyfile(__file__, output / 'runner.py')
    original = load(REVIEW / 'runs/attempt-013/invocation.json')
    old_output = original['output']
    argv = [str(input_path) if part == str(Path(old_output) / 'input.rs') else part for part in original['argv']]
    environment = {key: value.replace(old_output, str(output)) for key, value in original['environment'].items()}
    for key in ('CARGO_HOME', 'CARGO_TARGET_DIR', 'HOME', 'RUSTUP_HOME', 'TMPDIR', 'VERUS_INFER_CACHE', 'XDG_CACHE_HOME'):
        Path(environment[key]).mkdir(parents=True, exist_ok=True)
    entry = {'ordinal': ordinal, 'name': name, 'reserved_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'argv': argv, 'environment': environment, 'cwd': str(output), 'source_sha256': digest(input_path), 'draft_path': str(Path(source).resolve()), 'runner_sha256': digest(__file__), 'runtime_sha256': original['runtime_sha256'], 'imports': original['imports'], 'inputs': original['inputs'], 'authentication_entry_sha256': digest(ROOT / 'authentication-entry.json'), 'timeout_seconds': 60, 'scope': 'ENTIRE_CRATE_ALL_THREE_ORIGINAL_FUNCTIONS_NO_FILTERS', 'budget_before': budget_before}
    write(output / 'invocation.json', entry)
    with ledger.open('a') as stream:
        stream.write(json.dumps({'ordinal': ordinal, 'name': name, 'invocation_sha256': digest(output / 'invocation.json')}) + '\n')
        stream.flush()
        os.fsync(stream.fileno())
    started = time.monotonic()
    returncode = None
    timed_out = False
    spawn_error = None
    with (output / 'stdout.txt').open('wb') as stdout, (output / 'stderr.txt').open('wb') as stderr:
        try:
            process = subprocess.Popen(argv, cwd=output, env=environment, stdout=stdout, stderr=stderr, start_new_session=True)
            try:
                returncode = process.wait(timeout=60)
            except subprocess.TimeoutExpired:
                timed_out = True
                os.killpg(process.pid, signal.SIGKILL)
                returncode = process.wait()
        except OSError as error:
            spawn_error = repr(error)
    try:
        backend = load(output / 'stdout.txt')
    except (ValueError, OSError):
        backend = {}
    scope = backend.get('verification-scope', backend.get('verification_scope', {}))
    write(output / 'scope.json', scope)
    write(output / 'backend.json', backend)
    receipt = {'ordinal': ordinal, 'name': name, 'returncode': returncode, 'timed_out': timed_out, 'spawn_error': spawn_error, 'seconds': time.monotonic() - started, 'verification': backend.get('verification-results'), 'scope': scope, 'output_files': {str(path.relative_to(output)): digest(path) for path in output.rglob('*') if path.is_file()}, 'exports': [str(path.relative_to(output)) for path in output.rglob('*') if path.suffix in ('.vir', '.rlib', '.rmeta', '.interface')], 'budget_after': budget()}
    write(output / 'receipt.json', receipt)
    print(json.dumps(receipt, indent=2))

if __name__ == '__main__':
    if sys.argv[1] == 'auth':
        authenticate(sys.argv[2])
    elif sys.argv[1] == 'run':
        run(sys.argv[2], sys.argv[3])
