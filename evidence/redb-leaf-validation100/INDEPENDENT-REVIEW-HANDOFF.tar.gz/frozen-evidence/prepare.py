import difflib
from pathlib import Path

ROOT = Path(__file__).resolve().parent
original = Path('/private/tmp/verus-leaf007-independent-review-tOKSrsOe/generic_adversarial.rs').read_text()
addition = (ROOT / 'partition-proof.txt').read_text()
anchor = '    assert(0 <= index <= leaf::pair_count(page@));\n'
assert original.count(anchor) == 1
repaired = original.replace(anchor, anchor + addition)
assert repaired.replace(addition, '', 1) == original
(ROOT / 'draft-001-repaired.rs').write_text(repaired)
(ROOT / 'proof-only.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True), repaired.splitlines(True), fromfile='sealed/generic_adversarial.rs', tofile='draft-001-repaired.rs')))
