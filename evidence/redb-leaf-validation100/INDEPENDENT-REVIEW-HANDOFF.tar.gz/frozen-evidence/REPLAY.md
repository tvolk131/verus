# Read-only handoff and fresh replay recipe

Do not run cycle.py, prepare*.py, audit.py or seal.py in this sealed directory.
The original review and parent also remain read-only. Any later verifier run
requires its own authorization, fresh scratch and separately bounded ledger.
This handoff does not authorize a further cycle or adoption.

Authenticate this package by checking SEAL.json against the digest in the handoff
message, then the SEAL's manifest_sha256, exact regular-file membership equal to
MANIFEST rows plus MANIFEST.json and SEAL.json, all sizes/content hashes and
read-only payload modes. No directory/objectstore/actor continuity is implied.

The exact commands used for all five applications are in each run's
invocation.json: argv is an argument array, environment is the complete explicit
env passed to Popen, cwd is scratch-local. Match the source SHA and import/runtime
pins before interpreting results. Receipts preserve exit, export and timeout
outcomes; stdout.txt contains the raw full Verus JSON, stderr.txt raw diagnostics.
derived-scope-NNN.json extracts the authoritative verus-infer.verification_scope.
Attempt001's original scope extraction bug is disclosed, not silently rewritten.

If a fresh same-runtime rerun is separately authorized, author a new runner or
copy this UNEXECUTED script text to that NEW empty scratch and update ROOT-bound
output locations and the separate cycle's own deadline/ledger. Never write into
this package. Do not re-use this cycle's fixed START or its application ledger.
Keep every logical flag, exact matched private runtime, sealed ordinary imports,
sysroot and DYLD library paths. Redirect only scratch-local env/cwd/source/output
paths. Do not substitute an operational91/current-parent driver or vstd.

Relevant sequence (already completed; not an instruction to execute again):
1. Authenticate externally pinned review/parent and exact runtime/import/sysroot.
2. Original generic_adversarial.rs, exactly once: expect TWO backend partition
   diagnostics and 2 verified / 1 failed, ZERO complete-scope credit.
3. draft-001-repaired.rs full release: expect 3/0 and checked counts 3/0.
4. draft-002-control-correct.rs full release with --export: expect 4/0,
   checked counts 3/1 and control.vir produced.
5. draft-003-control-incorrect.rs with the identical export request: expect one
   backend assertion failure ONLY at mathematical_assertion_control, no export
   and ZERO complete-scope credit (3 verified / 1 failed is NOT full acceptance).
6. draft-004-restored.rs (byte-identical to repaired): expect 3/0, counts 3/0.
7. Authenticate unchanged endpoints; audit exact ghost-only inverse delta.

proof-only.patch and partition-proof.txt are the full 14-line repair.
No native source patch, provider change, auxiliary lemma, compiler build,
proof-library compile, new spec or new assumption is necessary.
