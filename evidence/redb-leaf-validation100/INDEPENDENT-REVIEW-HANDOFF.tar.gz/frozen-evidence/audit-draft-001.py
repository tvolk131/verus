import datetime
import json
from pathlib import Path
import re

from cycle import ROOT, REVIEW, PARENT, PLAN, digest, load, write, budget

original = (REVIEW / 'generic_adversarial.rs').read_text()
addition = (ROOT / 'partition-proof.txt').read_text()
repaired = (ROOT / 'draft-001-repaired.rs').read_text()
restored = (ROOT / 'draft-004-restored.rs').read_text()
assert repaired.count(addition) == 1
assert repaired.replace(addition, '', 1) == original
assert restored == repaired
assert len(addition.splitlines()) == 14
assert addition.startswith('    proof {\n') and addition.endswith('    }\n')
assert not re.search(r'\b(assume|admit|external_body|external|axiom|requires|ensures|fn|unsafe)\b', addition)
retained = ['review_generic::generic_partition_bytes', 'review_generic::midpoint_general', 'review_generic::raw_singleton_spare_tail']
control = 'review_generic::mathematical_assertion_control'
correct_addition = '\npub proof fn mathematical_assertion_control(number: int) {\n    assert(number + 1 > number);\n}\n'
correct = (ROOT / 'draft-002-control-correct.rs').read_text()
incorrect = (ROOT / 'draft-003-control-incorrect.rs').read_text()
assert correct == repaired[:-2] + correct_addition + '\n}\n'
assert incorrect == correct.replace('number + 1 > number', 'number + 1 < number')
write(ROOT / 'source-preservation-audit.json', {
    'original_source_sha256': digest(REVIEW / 'generic_adversarial.rs'),
    'repaired_source_sha256': digest(ROOT / 'draft-001-repaired.rs'),
    'restored_byte_identical': True,
    'delete_exact_added_ghost_block_recovers_original_bytes': True,
    'signatures_requires_original_input_domain_exec_statements_all_original_assertions_unchanged': True,
    'both_partition_assertions_preserved_verbatim': True,
    'midpoint_general_and_raw_singleton_spare_tail_unchanged_verbatim': True,
    'lines_added': 14, 'lines_removed': 0,
    'proof_addition_sha256': digest(ROOT / 'partition-proof.txt'),
    'control_pair_diff': 'one relational operator in one additional checked proof method: > becomes <',
    'original_native_path_preservation': 'FAILED; inherited all 1331 guarded original paths missing',
    'native_git_continuity': 'UNAVAILABLE',
    'pinned_recovered_input': 'c82ab865bb362bc4af067d332adc44978ff64813; content qualification only',
    'scope_of_endpoint_preservation': 'Pinned parent/review payloads, exact private runtime, sysroot/import chain, and PLAN; not transient-write or unrelated live-worktree/shared-ref attestation',
})
write(ROOT / 'method-ledger.json', {
    'retained_exec_identities': retained,
    'additional_exec_identities': [],
    'additional_proof_identities': [control],
    'additional_identity_count': 1,
    'control_body_variants_counted_conservatively': 2,
    'additional_identity_limit': 8,
    'auxiliary_checked_proof_lemmas_used': 0,
    'auxiliary_checked_proof_lemma_limit': 4,
    'new_spec_identities': [],
    'new_trust_boundaries': [],
    'qualifications': 'The control has one fully-qualified identity and two separately preserved body variants. Even charging each variant separately uses 2/8. The retained generic method has a proof-only body revision, no new identity.'
})
ledger_rows = [json.loads(line) for line in (ROOT / 'application-ledger.jsonl').read_text().splitlines()]
assert len(ledger_rows) == 5
historical = load(REVIEW / 'runs/attempt-013/invocation.json')
summary = []
for ordinal, ledger in enumerate(ledger_rows, 1):
    output = ROOT / f'runs/attempt-{ordinal:03d}'
    invocation = load(output / 'invocation.json')
    receipt = load(output / 'receipt.json')
    backend = load(output / 'stdout.txt')
    scope = backend['verus-infer']['verification_scope']
    infer = backend['verus-infer']
    scope_path = ROOT / f'derived-scope-{ordinal:03d}.json'
    write(scope_path, scope)
    assert ledger['invocation_sha256'] == digest(output / 'invocation.json')
    assert invocation['source_sha256'] == digest(output / 'input.rs')
    assert invocation['runner_sha256'] == digest(output / 'runner.py')
    for relative, expected in receipt['output_files'].items():
        assert digest(output / relative) == expected, (ordinal, relative)
    assert receipt['spawn_error'] is None and not receipt['timed_out'] and receipt['seconds'] < 60
    assert invocation['runtime_sha256'] == historical['runtime_sha256']
    assert invocation['imports'] == historical['imports']
    normalized_argv = [argument.replace(str(output), historical['output']) for argument in invocation['argv']]
    if ordinal in (3, 4):
        export_index = normalized_argv.index('--export')
        del normalized_argv[export_index:export_index + 2]
    assert normalized_argv == historical['argv']
    assert {key: value.replace(str(output), historical['output']) for key, value in invocation['environment'].items()} == historical['environment']
    selected = {row['function'] for row in scope['native_functions'] if row['selected']}
    assert selected == set(retained) | ({control} if ordinal in (3, 4) else set())
    assert backend['verification-results']['is-verifying-entire-crate']
    assert infer['requested_functions'] == infer['generated_functions'] == 0
    assert not infer['trusted_models'] and not infer['imported_inference_dependencies']
    diagnostics = (output / 'stderr.txt').read_text()
    if ordinal == 1:
        assert (output / 'input.rs').read_text() == original
        assert receipt['returncode'] == 1
        assert diagnostics.count('error: assertion failed') == 2
        assert ':14:12' in diagnostics and ':17:12' in diagnostics
        assert infer['failed_functions'] == [retained[0]]
        classification = 'EXPECTED_ORIGINAL_BACKEND_FAILURE_TWO_PARTITION_DIAGNOSTICS_ZERO_FULL_SCOPE_CREDIT'
    elif ordinal == 4:
        assert receipt['returncode'] == 1
        assert diagnostics.count('error: assertion failed') == 1
        assert ':89:12' in diagnostics and 'assert(number + 1 < number)' in diagnostics
        assert infer['failed_functions'] == [control]
        assert not (output / 'control.vir').exists()
        assert not receipt['exports'] and not infer['interface_written']
        classification = 'INTENDED_LOCALIZED_MATHEMATICAL_BACKEND_CONTROL_FAILURE_EXPORT_REQUESTED_BUT_SUPPRESSED_ZERO_FULL_SCOPE_CREDIT'
    else:
        assert receipt['returncode'] == 0 and not diagnostics
        assert scope['complete_selected_scope_verified'] and scope['checked_exec_bodies'] == 3
        assert not infer['failed_functions']
        assert backend['verification-results']['verified'] == (4 if ordinal == 3 else 3)
        classification = 'FULL_SCOPE_PASS'
    if ordinal in (1, 4):
        assert not scope['complete_selected_scope_verified']
        assert scope['checked_exec_bodies'] == scope['checked_proof_bodies'] == 0
        assert not receipt['exports'] and not infer['interface_written']
    if ordinal == 3:
        assert receipt['exports'] == ['control.vir'] and scope['checked_proof_bodies'] == 1
    summary.append({'ordinal': ordinal, 'name': invocation['name'], 'classification': classification, 'returncode': receipt['returncode'], 'verification': backend['verification-results'], 'checked_exec_bodies': scope['checked_exec_bodies'], 'checked_proof_bodies': scope['checked_proof_bodies'], 'complete_selected_scope_verified': scope['complete_selected_scope_verified'], 'failed_functions': infer['failed_functions'], 'assertion_diagnostics': diagnostics.count('error: assertion failed'), 'interface_written': infer['interface_written'], 'exports': receipt['exports'], 'seconds': receipt['seconds'], 'source_sha256': digest(output / 'input.rs'), 'invocation_sha256': digest(output / 'invocation.json'), 'scope_derived_from_raw_stdout': str(scope_path.relative_to(ROOT))})
entry = load(ROOT / 'authentication-entry.json')
exit_auth = load(ROOT / 'authentication-exit.json')
assert entry['packages'] == exit_auth['packages'] and entry['files'] == exit_auth['files']
assert load(ROOT / 'sysroot-entry.json') == load(ROOT / 'sysroot-exit.json')
sealed_immutable = load(REVIEW / 'preservation-before.json')['surviving_immutable_rows']
for name, row in load(ROOT / 'sysroot-entry.json').items():
    expected = sealed_immutable[entry['sysroot']['path'] + '/' + name]
    assert row['sha256'] == expected['sha256'] == expected['expected_sha256']
write(ROOT / 'sysroot-pin-corroboration.json', {'entry_and_exit_inventories_equal': True, 'all_3340_hashes_match_pinned_review_preservation_before': True, 'pinned_review_payload': 'preservation-before.json', 'source_sha256': digest(REVIEW / 'preservation-before.json'), 'runtime_and_sysroot_exact_membership_checked_at_exit': True})
write(ROOT / 'fresh-summary.json', {'result': 'REPAIRED_RELEASE_FULL_SCOPE_WITH_RESTORED_REPEAT_AND_LOCALIZED_PAIRED_CONTROL', 'applications': summary, 'direct_verifier_applications': 5, 'application_limit': 16, 'setup_spawn_timeout_failures': 0, 'unexpected_verification_failures': 0, 'expected_failure_applications': [1, 4], 'full_success_applications': [2, 3, 5], 'unchanged_original_reproductions': 1, 'second_debug_profile': 'NOT_RUN; release-only supplemental client evidence; no native builder-debug claim', 'compiler_vstd_cargo_harness_builds': 0, 'native_application_executions': 0, 'proof_library_compile_applications': 0, 'export_only_applications': [3, 4], 'new_trust': False, 'all_eighteen_final_redb_cells': 'OPEN', 'parent_independent_review': 'PENDING', 'harness_metadata_note': 'Attempt001 initial receipt scope was {} due to an extraction-key bug. Its original raw JSON already contains the complete failed scope. Original receipt/runner retained unchanged; all five scopes are normalized in derived-scope-NNN.json without any verifier rerun.', 'budget': budget(), 'verification_seconds_total': sum(row['seconds'] for row in summary)})
print(json.dumps({'audit': 'PASS', 'applications': len(summary), 'budget': budget(), 'original_source_sha256': digest(REVIEW / 'generic_adversarial.rs'), 'repaired_source_sha256': digest(ROOT / 'draft-001-repaired.rs')}))
