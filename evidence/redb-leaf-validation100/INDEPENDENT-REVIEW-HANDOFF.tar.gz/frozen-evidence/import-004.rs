use vstd::prelude::*;
use builder_step::{build_leaf_projection, metadata, part_views, payload_sum};
use leaf_decoder::{self as leaf, LeafAccessor, Value};

verus! {

pub open spec fn request<'k, 'v>(page: Seq<u8>, keys: Seq<&'k [u8]>, values: Seq<&'v [u8]>,
    key_width: Option<usize>, value_width: Option<usize>, reserved: usize) -> bool
{
    &&& 1 <= keys.len() <= 65535
    &&& values.len() == keys.len()
    &&& reserved as int == payload_sum(part_views(keys), keys.len() as int)
    &&& metadata(keys.len() as int, key_width, value_width) + reserved as int
        + payload_sum(part_views(values), values.len() as int) <= page.len() <= usize::MAX
    &&& metadata(keys.len() as int, key_width, value_width) + reserved as int
        + payload_sum(part_views(values), values.len() as int) <= u32::MAX
    &&& forall|index: int| 0 <= index < keys.len() && key_width.is_some()
        ==> #[trigger] keys[index]@.len() == key_width.unwrap()
    &&& forall|index: int| 0 <= index < values.len() && value_width.is_some()
        ==> #[trigger] values[index]@.len() == value_width.unwrap()
}

pub open spec fn ordered_inputs<'k>(keys: Seq<&'k [u8]>) -> bool {
    &&& forall|index: int| 0 <= index < keys.len() ==> #[trigger] keys[index]@.len() == 4
    &&& forall|left: int, right: int| 0 <= left < right < keys.len()
        ==> <u32 as Value>::meaning(#[trigger] keys[left]@)
            < <u32 as Value>::meaning(#[trigger] keys[right]@)
}

pub open spec fn ordered_leaf(bytes: Seq<u8>, key_width: Option<usize>, value_width: Option<usize>) -> bool {
    &&& leaf::leaf_bytes_wf(bytes, key_width, value_width)
    &&& forall|index: int| 0 <= index < leaf::pair_count(bytes)
        ==> #[trigger] leaf::encoded_key(bytes, key_width, value_width, index).len() == 4
    &&& forall|left: int, right: int| 0 <= left < right < leaf::pair_count(bytes)
        ==> <u32 as Value>::meaning(#[trigger] leaf::encoded_key(bytes, key_width, value_width, left))
            < <u32 as Value>::meaning(#[trigger] leaf::encoded_key(bytes, key_width, value_width, right))
}

pub proof fn canonical_u32(left: Seq<u8>, right: Seq<u8>)
    requires left.len() == 4, right.len() == 4,
    ensures (<u32 as Value>::meaning(left) == <u32 as Value>::meaning(right)) == (left == right),
{
    vstd::bytes::lemma_auto_spec_u32_to_from_le_bytes();
    assert(vstd::bytes::spec_u32_to_le_bytes(vstd::bytes::spec_u32_from_le_bytes(left)) == left);
    assert(vstd::bytes::spec_u32_to_le_bytes(vstd::bytes::spec_u32_from_le_bytes(right)) == right);
}

pub fn search_u32<'a>(page: &'a [u8], key_width: Option<usize>, value_width: Option<usize>, query: &[u8])
    -> (result: Option<(&'a [u8], &'a [u8])>)
    requires ordered_leaf(page@, key_width, value_width), query.len() == 4,
    ensures
        result.is_some() == exists|index: int| 0 <= index < leaf::pair_count(page@)
            && #[trigger] leaf::encoded_key(page@, key_width, value_width, index) == query@,
        result.is_some() ==> result.unwrap().0@ == query@,
        result.is_some() ==> exists|index: int| 0 <= index < leaf::pair_count(page@)
            && #[trigger] leaf::encoded_key(page@, key_width, value_width, index) == query@
            && leaf::encoded_value(page@, key_width, value_width, index) == result.unwrap().1@,
{
    let accessor = LeafAccessor::new(page, key_width, value_width);
    proof {
        assert(accessor.sorted_for::<u32>());
        assert forall|index: int| 0 <= index < accessor.count()
            implies (<u32 as Value>::meaning(#[trigger] accessor.key_bytes_at(index))
                == <u32 as Value>::meaning(query@)) == (accessor.key_bytes_at(index) == query@) by {
            canonical_u32(accessor.key_bytes_at(index), query@);
        }
    }
    let found = accessor.find_key::<u32>(query);
    proof {
        if found.is_some() {
            let index = found.unwrap() as int;
            canonical_u32(accessor.key_bytes_at(index), query@);
            assert(leaf::encoded_key(page@, key_width, value_width, index) == query@);
            assert(exists|candidate: int| 0 <= candidate < leaf::pair_count(page@)
                && #[trigger] leaf::encoded_key(page@, key_width, value_width, candidate) == query@);
        } else if exists|index: int| 0 <= index < leaf::pair_count(page@)
            && #[trigger] leaf::encoded_key(page@, key_width, value_width, index) == query@ {
            let index = choose|index: int| 0 <= index < leaf::pair_count(page@)
                && #[trigger] leaf::encoded_key(page@, key_width, value_width, index) == query@;
            assert(<u32 as Value>::meaning(accessor.key_bytes_at(index)) == <u32 as Value>::meaning(query@));
            assert(exists|candidate: int| 0 <= candidate < accessor.count()
                && <u32 as Value>::meaning(#[trigger] accessor.key_bytes_at(candidate)) == <u32 as Value>::meaning(query@));
            assert(false);
        }
        assert(found.is_some() == exists|index: int| 0 <= index < leaf::pair_count(page@)
            && #[trigger] leaf::encoded_key(page@, key_width, value_width, index) == query@);
    }
    match found {
        Some(index) => {
            let entry = accessor.entry(index).unwrap();
            Some((entry.key(), entry.value()))
        }
        None => None,
    }
}

pub fn build_then_lookup<'a>(page: &'a mut [u8], keys: &[&[u8]], values: &[&[u8]],
    key_width: Option<usize>, value_width: Option<usize>, reserved: usize, query: &[u8])
    -> (result: Option<(&'a [u8], &'a [u8])>)
    requires request(page@, keys@, values@, key_width, value_width, reserved),
        ordered_inputs(keys@), query.len() == 4,
    ensures
        result.is_some() == exists|index: int| 0 <= index < keys@.len() && #[trigger] keys@[index]@ == query@,
        result.is_some() ==> result.unwrap().0@ == query@,
        result.is_some() ==> exists|index: int| 0 <= index < keys@.len()
            && #[trigger] keys@[index]@ == query@ && values@[index]@ == result.unwrap().1@,
{
    let buffer = build_leaf_projection(page, keys, values, key_width, value_width, reserved);
    proof {
        assert(ordered_leaf(buffer@, key_width, value_width));
        assert forall|index: int| 0 <= index < keys@.len()
            implies #[trigger] leaf::encoded_key(buffer@, key_width, value_width, index) == keys@[index]@ by {}
    }
    let ghost image = buffer@;
    let result = search_u32(buffer, key_width, value_width, query);
    proof {
        if result.is_some() {
            let index = choose|index: int| 0 <= index < leaf::pair_count(image)
                && #[trigger] leaf::encoded_key(image, key_width, value_width, index) == query@
                && leaf::encoded_value(image, key_width, value_width, index) == result.unwrap().1@;
            assert(keys@[index]@ == query@ && values@[index]@ == result.unwrap().1@);
            assert(exists|candidate: int| 0 <= candidate < keys@.len()
                && #[trigger] keys@[candidate]@ == query@ && values@[candidate]@ == result.unwrap().1@);
        } else if exists|index: int| 0 <= index < keys@.len() && #[trigger] keys@[index]@ == query@ {
            let index = choose|index: int| 0 <= index < keys@.len() && #[trigger] keys@[index]@ == query@;
            assert(leaf::encoded_key(image, key_width, value_width, index) == query@);
            assert(exists|candidate: int| 0 <= candidate < leaf::pair_count(image)
                && #[trigger] leaf::encoded_key(image, key_width, value_width, candidate) == query@);
            assert(false);
        }
        assert(result.is_some() == exists|index: int| 0 <= index < keys@.len() && #[trigger] keys@[index]@ == query@);
    }
    result
}

}
