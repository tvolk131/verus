use core::cmp::Ordering;
use vstd::prelude::*;
use core::mem::size_of;
use core::ops::Range;

verus! {

pub const LEAF: u8 = 1;

pub open spec fn read16(bytes: Seq<u8>, offset: int) -> int {
    vstd::bytes::spec_u16_from_le_bytes(bytes.subrange(offset, offset + 2)) as int
}

pub open spec fn read32(bytes: Seq<u8>, offset: int) -> int {
    vstd::bytes::spec_u32_from_le_bytes(bytes.subrange(offset, offset + 4)) as int
}

pub open spec fn pair_count(bytes: Seq<u8>) -> int {
    read16(bytes, 2)
}

pub open spec fn key_array_bytes(bytes: Seq<u8>, fixed_key: Option<usize>) -> int {
    if fixed_key.is_none() { 4 * pair_count(bytes) } else { 0 }
}

pub open spec fn value_array_bytes(bytes: Seq<u8>, fixed_value: Option<usize>) -> int {
    if fixed_value.is_none() { 4 * pair_count(bytes) } else { 0 }
}

pub open spec fn metadata_end(bytes: Seq<u8>, fixed_key: Option<usize>, fixed_value: Option<usize>) -> int {
    4 + key_array_bytes(bytes, fixed_key) + value_array_bytes(bytes, fixed_value)
}

pub open spec fn key_boundary(bytes: Seq<u8>, fixed_key: Option<usize>, fixed_value: Option<usize>, boundary: int) -> int {
    if boundary == 0 {
        metadata_end(bytes, fixed_key, fixed_value)
    } else if fixed_key.is_some() {
        metadata_end(bytes, fixed_key, fixed_value) + fixed_key.unwrap() as int * boundary
    } else {
        read32(bytes, 4 + 4 * (boundary - 1))
    }
}

pub open spec fn value_boundary(bytes: Seq<u8>, fixed_key: Option<usize>, fixed_value: Option<usize>, boundary: int) -> int {
    if boundary == 0 {
        key_boundary(bytes, fixed_key, fixed_value, pair_count(bytes))
    } else if fixed_value.is_some() {
        key_boundary(bytes, fixed_key, fixed_value, pair_count(bytes)) + fixed_value.unwrap() as int * boundary
    } else {
        read32(bytes, 4 + key_array_bytes(bytes, fixed_key) + 4 * (boundary - 1))
    }
}

pub open spec fn leaf_bytes_wf(bytes: Seq<u8>, fixed_key: Option<usize>, fixed_value: Option<usize>) -> bool {
    &&& bytes.len() >= 4
    &&& bytes.len() <= usize::MAX
    &&& bytes[0] == LEAF
    &&& 1 <= pair_count(bytes) <= 65535
    &&& metadata_end(bytes, fixed_key, fixed_value) <= bytes.len()
    &&& metadata_end(bytes, fixed_key, fixed_value) <= u32::MAX
    &&& forall|boundary: int| 0 <= boundary <= pair_count(bytes) ==> {
        &&& metadata_end(bytes, fixed_key, fixed_value) <= #[trigger] key_boundary(bytes, fixed_key, fixed_value, boundary) <= bytes.len()
        &&& key_boundary(bytes, fixed_key, fixed_value, boundary) <= u32::MAX
    }
    &&& forall|boundary: int| 0 <= boundary <= pair_count(bytes) ==> {
        &&& key_boundary(bytes, fixed_key, fixed_value, pair_count(bytes)) <= #[trigger] value_boundary(bytes, fixed_key, fixed_value, boundary) <= bytes.len()
        &&& value_boundary(bytes, fixed_key, fixed_value, boundary) <= u32::MAX
    }
    &&& forall|left: int, right: int| 0 <= left <= right <= pair_count(bytes) ==> {
        &&& #[trigger] key_boundary(bytes, fixed_key, fixed_value, left) <= #[trigger] key_boundary(bytes, fixed_key, fixed_value, right)
    }
    &&& forall|left: int, right: int| 0 <= left <= right <= pair_count(bytes) ==> {
        &&& #[trigger] value_boundary(bytes, fixed_key, fixed_value, left) <= #[trigger] value_boundary(bytes, fixed_key, fixed_value, right)
    }
}

pub open spec fn encoded_key(bytes: Seq<u8>, fixed_key: Option<usize>, fixed_value: Option<usize>, index: int) -> Seq<u8> {
    bytes.subrange(key_boundary(bytes, fixed_key, fixed_value, index), key_boundary(bytes, fixed_key, fixed_value, index + 1))
}

pub open spec fn encoded_value(bytes: Seq<u8>, fixed_key: Option<usize>, fixed_value: Option<usize>, index: int) -> Seq<u8> {
    bytes.subrange(value_boundary(bytes, fixed_key, fixed_value, index), value_boundary(bytes, fixed_key, fixed_value, index + 1))
}

pub proof fn concrete_le16(bytes: Seq<u8>, offset: int)
    requires 0 <= offset, offset + 2 <= bytes.len(),
    ensures read16(bytes, offset) == ((bytes[offset] as u16) | (bytes[offset + 1] as u16) << 8) as int,
        read16(bytes, offset) == bytes[offset] as int + 256 * bytes[offset + 1] as int,
{
    vstd::bytes::lemma_u16_from_le_bytes_expansion(bytes.subrange(offset, offset + 2));
    let byte0 = bytes[offset];
    let byte1 = bytes[offset + 1];
    assert(((byte0 as u16) | (byte1 as u16) << 8) as u32 == byte0 as u32 + 256u32 * byte1 as u32) by (bit_vector);
}

pub proof fn concrete_le32(bytes: Seq<u8>, offset: int)
    requires 0 <= offset, offset + 4 <= bytes.len(),
    ensures read32(bytes, offset) == ((bytes[offset] as u32) | (bytes[offset + 1] as u32) << 8 | (bytes[offset + 2] as u32) << 16 | (bytes[offset + 3] as u32) << 24) as int,
        read32(bytes, offset) == bytes[offset] as int + 256 * bytes[offset + 1] as int + 65536 * bytes[offset + 2] as int + 16777216 * bytes[offset + 3] as int,
{
    vstd::bytes::lemma_u32_from_le_bytes_expansion(bytes.subrange(offset, offset + 4));
    let byte0 = bytes[offset];
    let byte1 = bytes[offset + 1];
    let byte2 = bytes[offset + 2];
    let byte3 = bytes[offset + 3];
    assert(((byte0 as u32) | (byte1 as u32) << 8 | (byte2 as u32) << 16 | (byte3 as u32) << 24) as u64
        == byte0 as u64 + 256u64 * byte1 as u64 + 65536u64 * byte2 as u64 + 16777216u64 * byte3 as u64) by (bit_vector);
}

pub proof fn layout_bounds(bytes: Seq<u8>, fixed_key: Option<usize>, fixed_value: Option<usize>)
    requires leaf_bytes_wf(bytes, fixed_key, fixed_value), bytes.len() <= usize::MAX,
    ensures
        1 <= pair_count(bytes) <= 65535,
        4 <= metadata_end(bytes, fixed_key, fixed_value) <= 524284,
        metadata_end(bytes, fixed_key, fixed_value) <= bytes.len(),
        metadata_end(bytes, fixed_key, fixed_value) <= usize::MAX,
        4 * pair_count(bytes) <= usize::MAX,
{
}

pub proof fn interval_bounds(bytes: Seq<u8>, fixed_key: Option<usize>, fixed_value: Option<usize>, start: int, end: int)
    requires leaf_bytes_wf(bytes, fixed_key, fixed_value), bytes.len() <= usize::MAX, 0 <= start <= end <= pair_count(bytes),
    ensures
        0 <= key_boundary(bytes, fixed_key, fixed_value, start) <= key_boundary(bytes, fixed_key, fixed_value, end) <= bytes.len(),
        key_boundary(bytes, fixed_key, fixed_value, end) <= key_boundary(bytes, fixed_key, fixed_value, pair_count(bytes)),
        0 <= value_boundary(bytes, fixed_key, fixed_value, start) <= value_boundary(bytes, fixed_key, fixed_value, end) <= bytes.len(),
        key_boundary(bytes, fixed_key, fixed_value, pair_count(bytes)) <= value_boundary(bytes, fixed_key, fixed_value, start),
        key_boundary(bytes, fixed_key, fixed_value, end) - key_boundary(bytes, fixed_key, fixed_value, start)
            + value_boundary(bytes, fixed_key, fixed_value, end) - value_boundary(bytes, fixed_key, fixed_value, start) <= bytes.len(),
{
    layout_bounds(bytes, fixed_key, fixed_value);
}

pub open spec fn key_lengths(bytes: Seq<u8>, fixed_key: Option<usize>, fixed_value: Option<usize>, start: int, end: int) -> int
    decreases end - start,
{
    if start >= end { 0 } else {
        encoded_key(bytes, fixed_key, fixed_value, start).len() as int + key_lengths(bytes, fixed_key, fixed_value, start + 1, end)
    }
}

pub open spec fn value_lengths(bytes: Seq<u8>, fixed_key: Option<usize>, fixed_value: Option<usize>, start: int, end: int) -> int
    decreases end - start,
{
    if start >= end { 0 } else {
        encoded_value(bytes, fixed_key, fixed_value, start).len() as int + value_lengths(bytes, fixed_key, fixed_value, start + 1, end)
    }
}

pub proof fn telescoping_lengths(bytes: Seq<u8>, fixed_key: Option<usize>, fixed_value: Option<usize>, start: int, end: int)
    requires leaf_bytes_wf(bytes, fixed_key, fixed_value), 0 <= start <= end <= pair_count(bytes),
    ensures
        key_lengths(bytes, fixed_key, fixed_value, start, end) == key_boundary(bytes, fixed_key, fixed_value, end) - key_boundary(bytes, fixed_key, fixed_value, start),
        value_lengths(bytes, fixed_key, fixed_value, start, end) == value_boundary(bytes, fixed_key, fixed_value, end) - value_boundary(bytes, fixed_key, fixed_value, start),
        key_lengths(bytes, fixed_key, fixed_value, start, end) + value_lengths(bytes, fixed_key, fixed_value, start, end) <= bytes.len(),
    decreases end - start,
{
    interval_bounds(bytes, fixed_key, fixed_value, start, end);
    if start < end {
        interval_bounds(bytes, fixed_key, fixed_value, start, start + 1);
        telescoping_lengths(bytes, fixed_key, fixed_value, start + 1, end);
    }
}

pub proof fn symbolic_count_domain(bytes: Seq<u8>, fixed_key: Option<usize>, fixed_value: Option<usize>, native_count: u16)
    requires leaf_bytes_wf(bytes, fixed_key, fixed_value), pair_count(bytes) == native_count as int,
    ensures
        1 <= native_count <= u16::MAX,
        4 <= metadata_end(bytes, fixed_key, fixed_value) <= 4 + 8 * native_count as int,
        native_count == u16::MAX ==> metadata_end(bytes, None, None) == 524284,
        0 <= key_boundary(bytes, fixed_key, fixed_value, native_count as int) <= bytes.len(),
        0 <= value_boundary(bytes, fixed_key, fixed_value, native_count as int) <= bytes.len(),
{
    layout_bounds(bytes, fixed_key, fixed_value);
    interval_bounds(bytes, fixed_key, fixed_value, 0, native_count as int);
}

pub struct EntryAccessor<'a> {
    key: &'a [u8],
    value: &'a [u8],
}



impl<'a> EntryAccessor<'a> {

    pub fn new(key: &'a [u8], value: &'a [u8]) -> (result: Self)
        ensures result.key_bytes() == key@, result.value_bytes() == value@,
    {
        EntryAccessor { key, value }
    }


    pub closed spec fn key_bytes(&self) -> Seq<u8> { self.key@ }
    pub closed spec fn value_bytes(&self) -> Seq<u8> { self.value@ }
}


impl<'a: 'b, 'b> EntryAccessor<'a> {

    pub fn key(&'b self) -> (result: &'a [u8])
        ensures result@ == self.key_bytes(),
    {
        self.key
    }

    pub fn value(&'b self) -> (result: &'a [u8])
        ensures result@ == self.value_bytes(),
    {
        self.value
    }

}

pub struct LeafAccessor<'a> {
    page: &'a [u8],
    fixed_key_size: Option<usize>,
    fixed_value_size: Option<usize>,
    num_pairs: usize,
}


impl<'a> LeafAccessor<'a> {

    pub closed spec fn bytes(&self) -> Seq<u8> { self.page@ }
    pub closed spec fn fixed_key(&self) -> Option<usize> { self.fixed_key_size }
    pub closed spec fn fixed_value(&self) -> Option<usize> { self.fixed_value_size }
    pub closed spec fn count(&self) -> int { self.num_pairs as int }
    pub open spec fn kb(&self, boundary: int) -> int { key_boundary(self.bytes(), self.fixed_key(), self.fixed_value(), boundary) }
    pub open spec fn vb(&self, boundary: int) -> int { value_boundary(self.bytes(), self.fixed_key(), self.fixed_value(), boundary) }
    pub open spec fn wf(&self) -> bool {
        &&& leaf_bytes_wf(self.bytes(), self.fixed_key(), self.fixed_value())
        &&& self.count() == pair_count(self.bytes())
    }

    pub fn new(
        page: &'a [u8],
        fixed_key_size: Option<usize>,
        fixed_value_size: Option<usize>,
    ) -> (result: Self)
        requires leaf_bytes_wf(page@, fixed_key_size, fixed_value_size),
        ensures result.wf(), result.bytes() == page@, result.fixed_key() == fixed_key_size, result.fixed_value() == fixed_value_size,
            result.count() == pair_count(page@),
    {
        proof { layout_bounds(page@, fixed_key_size, fixed_value_size); }
        debug_assert_eq!(page[0], LEAF);
        let num_pairs = u16::from_le_bytes(page[2..4].try_into().unwrap()) as usize;
        LeafAccessor {
            page,
            fixed_key_size,
            fixed_value_size,
            num_pairs,
        }
    }

    pub fn key_section_start(&self) -> (result: usize)
        requires self.wf(),
        ensures result as int == metadata_end(self.bytes(), self.fixed_key(), self.fixed_value()),
    {
        proof { layout_bounds(self.bytes(), self.fixed_key(), self.fixed_value()); }
        let mut offset = 4;
        if self.fixed_key_size.is_none() {
            offset += size_of::<u32>() * self.num_pairs;
        }
        if self.fixed_value_size.is_none() {
            offset += size_of::<u32>() * self.num_pairs;
        }

        offset
    }

    pub fn key_start(&self, n: usize) -> (result: Option<usize>)
        requires self.wf(),
        ensures result == (if n <= self.count() { Some(self.kb(n as int) as usize) } else { None }),
    {
        if n == 0 {
            Some(self.key_section_start())
        } else {
            self.key_end(n - 1)
        }
    }

    pub fn key_end(&self, n: usize) -> (result: Option<usize>)
        requires self.wf(),
        ensures result == (if n < self.count() { Some(self.kb(n as int + 1) as usize) } else { None }),
    {
        proof { layout_bounds(self.bytes(), self.fixed_key(), self.fixed_value()); if n < self.count() { interval_bounds(self.bytes(), self.fixed_key(), self.fixed_value(), n as int, n as int + 1); } }
        if n >= self.num_pairs() {
            None
        } else {
            if let Some(fixed) = self.fixed_key_size {
                return Some(self.key_section_start() + fixed * (n + 1));
            }
            let offset = 4 + size_of::<u32>() * n;
            let end = u32::from_le_bytes(
                self.page
                    .get(offset..(offset + size_of::<u32>()))?
                    .try_into()
                    .unwrap(),
            ) as usize;
            Some(end)
        }
    }

    pub fn value_start(&self, n: usize) -> (result: Option<usize>)
        requires self.wf(),
        ensures result == (if n <= self.count() { Some(self.vb(n as int) as usize) } else { None }),
    {
        if n == 0 {
            self.key_end(self.num_pairs() - 1)
        } else {
            self.value_end(n - 1)
        }
    }

    pub fn value_end(&self, n: usize) -> (result: Option<usize>)
        requires self.wf(),
        ensures result == (if n < self.count() { Some(self.vb(n as int + 1) as usize) } else { None }),
    {
        proof { layout_bounds(self.bytes(), self.fixed_key(), self.fixed_value()); if n < self.count() { interval_bounds(self.bytes(), self.fixed_key(), self.fixed_value(), n as int, n as int + 1); } }
        if n >= self.num_pairs() {
            None
        } else {
            if let Some(fixed) = self.fixed_value_size {
                return Some(self.key_end(self.num_pairs.checked_sub(1)?)? + fixed * (n + 1));
            }
            let mut offset = 4 + size_of::<u32>() * n;
            if self.fixed_key_size.is_none() {
                offset += size_of::<u32>() * self.num_pairs;
            }
            let end = u32::from_le_bytes(
                self.page
                    .get(offset..(offset + size_of::<u32>()))?
                    .try_into()
                    .unwrap(),
            ) as usize;
            Some(end)
        }
    }

    pub fn num_pairs(&self) -> (result: usize)
        ensures result as int == self.count(),
    {
        self.num_pairs
    }

    pub fn offset_of_first_value(&self) -> (result: usize)
        requires self.wf(),
        ensures result as int == self.vb(0),
    {
        proof { interval_bounds(self.bytes(), self.fixed_key(), self.fixed_value(), 0, 0); }
        self.offset_of_value(0).unwrap()
    }

    pub fn offset_of_value(&self, n: usize) -> (result: Option<usize>)
        requires self.wf(),
        ensures result == (if n <= self.count() { Some(self.vb(n as int) as usize) } else { None }),
    {
        self.value_start(n)
    }

    pub fn value_range(&self, n: usize) -> (result: Option<(usize, usize)>)
        requires self.wf(),
        ensures result == (if n < self.count() { Some((self.vb(n as int) as usize, self.vb(n as int + 1) as usize)) } else { None }),
    {
        Some((self.value_start(n)?, self.value_end(n)?))
    }

    pub fn length_of_pairs(&self, start: usize, end: usize) -> (result: usize)
        requires self.wf(), start <= end <= self.count(),
        ensures result as int == self.vb(end as int) - self.vb(start as int) + self.kb(end as int) - self.kb(start as int),
            result as int == key_lengths(self.bytes(), self.fixed_key(), self.fixed_value(), start as int, end as int) + value_lengths(self.bytes(), self.fixed_key(), self.fixed_value(), start as int, end as int),
    {
        proof { telescoping_lengths(self.bytes(), self.fixed_key(), self.fixed_value(), start as int, end as int); }
        self.length_of_values(start, end) + self.length_of_keys(start, end)
    }

    pub fn length_of_values(&self, start: usize, end: usize) -> (result: usize)
        requires self.wf(), start <= end <= self.count(),
        ensures result as int == self.vb(end as int) - self.vb(start as int),
            result as int == value_lengths(self.bytes(), self.fixed_key(), self.fixed_value(), start as int, end as int),
    {
        proof { telescoping_lengths(self.bytes(), self.fixed_key(), self.fixed_value(), start as int, end as int); }
        if end == 0 {
            return 0;
        }
        let end_offset = self.value_end(end - 1).unwrap();
        let start_offset = self.value_start(start).unwrap();
        end_offset - start_offset
    }

    pub fn length_of_keys(&self, start: usize, end: usize) -> (result: usize)
        requires self.wf(), start <= end <= self.count(),
        ensures result as int == self.kb(end as int) - self.kb(start as int),
            result as int == key_lengths(self.bytes(), self.fixed_key(), self.fixed_value(), start as int, end as int),
    {
        proof { telescoping_lengths(self.bytes(), self.fixed_key(), self.fixed_value(), start as int, end as int); }
        if end == 0 {
            return 0;
        }
        let end_offset = self.key_end(end - 1).unwrap();
        let start_offset = self.key_start(start).unwrap();
        end_offset - start_offset
    }

    pub fn total_length(&self) -> (result: usize)
        requires self.wf(),
        ensures result as int == self.vb(self.count()), result <= self.bytes().len(),
    {
        // Values are stored last
        self.value_end(self.num_pairs() - 1).unwrap()
    }

    pub fn key_unchecked(&self, n: usize) -> (result: &[u8])
        requires self.wf(), n < self.count(),
        ensures result@ == encoded_key(self.bytes(), self.fixed_key(), self.fixed_value(), n as int),
    {
        proof { interval_bounds(self.bytes(), self.fixed_key(), self.fixed_value(), n as int, n as int + 1); }
        &self.page[self.key_start(n).unwrap()..self.key_end(n).unwrap()]
    }

    pub fn entry(&self, n: usize) -> (result: Option<EntryAccessor<'a>>)
        requires self.wf(),
        ensures result.is_some() == (n < self.count()),
            n < self.count() ==> result.unwrap().key_bytes() == encoded_key(self.bytes(), self.fixed_key(), self.fixed_value(), n as int),
            n < self.count() ==> result.unwrap().value_bytes() == encoded_value(self.bytes(), self.fixed_key(), self.fixed_value(), n as int),
    {
        proof { if n < self.count() { interval_bounds(self.bytes(), self.fixed_key(), self.fixed_value(), n as int, n as int + 1); } }
        let key = &self.page[self.key_start(n)?..self.key_end(n)?];
        let value = &self.page[self.value_start(n)?..self.value_end(n)?];
        Some(EntryAccessor::new(key, value))
    }

    pub fn entry_ranges(&self, n: usize) -> (result: Option<(Range<usize>, Range<usize>)>)
        requires self.wf(),
        ensures result.is_some() == (n < self.count()),
            n < self.count() ==> result.unwrap().0.start as int == self.kb(n as int),
            n < self.count() ==> result.unwrap().0.end as int == self.kb(n as int + 1),
            n < self.count() ==> result.unwrap().1.start as int == self.vb(n as int),
            n < self.count() ==> result.unwrap().1.end as int == self.vb(n as int + 1),
    {
        let key = self.key_start(n)?..self.key_end(n)?;
        let value = self.value_start(n)?..self.value_end(n)?;
        Some((key, value))
    }

    pub fn last_entry(&self) -> (result: EntryAccessor<'a>)
        requires self.wf(),
        ensures result.key_bytes() == encoded_key(self.bytes(), self.fixed_key(), self.fixed_value(), self.count() - 1),
            result.value_bytes() == encoded_value(self.bytes(), self.fixed_key(), self.fixed_value(), self.count() - 1),
    {
        self.entry(self.num_pairs() - 1).unwrap()
    }

}
pub trait Value: Sized {
    spec fn valid(bytes: Seq<u8>) -> bool;
    spec fn meaning(bytes: Seq<u8>) -> int;
    spec fn number(value: Self) -> int;

    fn from_bytes<'a>(data: &'a [u8]) -> (result: Self)
        where Self: 'a,
        requires Self::valid(data@),
        ensures Self::number(result) == Self::meaning(data@);
}

pub trait Key: Value {
    fn compare(data1: &[u8], data2: &[u8]) -> (result: core::cmp::Ordering)
        requires Self::valid(data1@), Self::valid(data2@),
        ensures result == if Self::meaning(data1@) < Self::meaning(data2@) {
            Ordering::Less
        } else if Self::meaning(data1@) > Self::meaning(data2@) {
            Ordering::Greater
        } else {
            Ordering::Equal
        };
}

impl Value for u32 {
    open spec fn valid(bytes: Seq<u8>) -> bool { bytes.len() == 4 }
    open spec fn meaning(bytes: Seq<u8>) -> int {
        vstd::bytes::spec_u32_from_le_bytes(bytes) as int
    }
    open spec fn number(value: Self) -> int { value as int }

    fn from_bytes<'a>(data: &'a [u8]) -> (result: u32)
        where Self: 'a,
    {
        <u32>::from_le_bytes(data.try_into().unwrap())
    }
}

impl Key for u32 {
    fn compare(data1: &[u8], data2: &[u8]) -> (result: core::cmp::Ordering) {
        Self::from_bytes(data1).cmp(&Self::from_bytes(data2))
    }
}

impl<'a> LeafAccessor<'a> {
    pub open spec fn key_bytes_at(&self, index: int) -> Seq<u8> {
        encoded_key(self.bytes(), self.fixed_key(), self.fixed_value(), index)
    }

    pub open spec fn sorted_for<K: Key>(&self) -> bool {
        &&& self.wf()
        &&& forall|index: int| 0 <= index < self.count()
            ==> K::valid(#[trigger] self.key_bytes_at(index))
        &&& forall|left: int, right: int| 0 <= left < right < self.count()
            ==> K::meaning(#[trigger] self.key_bytes_at(left))
                < K::meaning(#[trigger] self.key_bytes_at(right))
    }

    pub open spec fn positioned<K: Key>(&self, query: Seq<u8>, index: int, found: bool) -> bool {
        &&& 0 <= index <= self.count()
        &&& found ==> index < self.count() && K::meaning(self.key_bytes_at(index)) == K::meaning(query)
        &&& forall|before: int| 0 <= before < index
            ==> K::meaning(#[trigger] self.key_bytes_at(before)) < K::meaning(query)
        &&& forall|after: int| index + (if found { 1int } else { 0int }) <= after < self.count()
            ==> K::meaning(#[trigger] self.key_bytes_at(after)) > K::meaning(query)
    }

    pub fn position<K: Key>(&self, query: &[u8]) -> (result: (usize, bool))
        requires self.sorted_for::<K>(), K::valid(query@),
        ensures self.positioned::<K>(query@, result.0 as int, result.1),
    {
        let mut min_entry = 0;
        let mut max_entry = self.num_pairs();
        while min_entry < max_entry
            invariant
                self.sorted_for::<K>(), K::valid(query@),
                0 <= min_entry <= max_entry <= self.count(),
                forall|before: int| 0 <= before < min_entry
                    ==> K::meaning(#[trigger] self.key_bytes_at(before)) < K::meaning(query@),
                forall|after: int| max_entry <= after < self.count()
                    ==> K::meaning(#[trigger] self.key_bytes_at(after)) > K::meaning(query@),
            decreases max_entry - min_entry,
        {
            let mid = min_entry.midpoint(max_entry);
            proof { assert(min_entry <= mid < max_entry); }
            let key = self.key_unchecked(mid);
            proof {
                assert(key@ == self.key_bytes_at(mid as int));
                assert(K::valid(self.key_bytes_at(mid as int)));
            }
            match K::compare(query, key) {
                Ordering::Less => {
                    proof {
                        assert forall|after: int| mid <= after < self.count()
                            implies K::meaning(#[trigger] self.key_bytes_at(after)) > K::meaning(query@) by {
                            if mid < after {
                                assert(K::meaning(self.key_bytes_at(mid as int))
                                    < K::meaning(self.key_bytes_at(after)));
                            }
                        }
                    }
                    max_entry = mid;
                }
                Ordering::Equal => {
                    proof {
                        assert forall|before: int| 0 <= before < mid
                            implies K::meaning(#[trigger] self.key_bytes_at(before)) < K::meaning(query@) by {
                            assert(K::meaning(self.key_bytes_at(before))
                                < K::meaning(self.key_bytes_at(mid as int)));
                        }
                        assert forall|after: int| mid < after < self.count()
                            implies K::meaning(#[trigger] self.key_bytes_at(after)) > K::meaning(query@) by {
                            assert(K::meaning(self.key_bytes_at(mid as int))
                                < K::meaning(self.key_bytes_at(after)));
                        }
                    }
                    return (mid, true);
                }
                Ordering::Greater => {
                    proof {
                        assert forall|before: int| 0 <= before <= mid
                            implies K::meaning(#[trigger] self.key_bytes_at(before)) < K::meaning(query@) by {
                            if before < mid {
                                assert(K::meaning(self.key_bytes_at(before))
                                    < K::meaning(self.key_bytes_at(mid as int)));
                            }
                        }
                    }
                    min_entry = mid + 1;
                }
            }
        }
        debug_assert_eq!(min_entry, max_entry);
        (min_entry, false)
    }

    pub fn find_key<K: Key>(&self, query: &[u8]) -> (result: Option<usize>)
        requires self.sorted_for::<K>(), K::valid(query@),
        ensures
            result.is_some() == exists|index: int| 0 <= index < self.count()
                && K::meaning(#[trigger] self.key_bytes_at(index)) == K::meaning(query@),
            result.is_some() ==> 0 <= result.unwrap() < self.count()
                && K::meaning(self.key_bytes_at(result.unwrap() as int)) == K::meaning(query@),
    {
        let (entry, found) = self.position::<K>(query);
        if found { Some(entry) } else { None }
    }
}

}
