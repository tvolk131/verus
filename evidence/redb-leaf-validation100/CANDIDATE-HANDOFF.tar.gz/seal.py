import datetime
import os
from pathlib import Path
import stat

from cycle import ROOT, PINS, budget, digest, load, write

assert not (ROOT / 'SEAL.json').exists()
assert len((ROOT / 'REPORT.md').read_bytes()) <= 16 * 1024
summary = load(ROOT / 'fresh-summary.json')
assert summary['direct_verifier_applications'] == 5
assert (ROOT / 'audit.stderr.txt').read_text() == ''
assert '"audit": "PASS"' in (ROOT / 'audit.stdout.txt').read_text()
write(ROOT / 'HANDOFF.json', {
    'schema': 'cycle100-redb-leaf-lookup-handoff-v1',
    'result': summary['result'],
    'report': 'REPORT.md',
    'proof_delta': 'proof-only.patch',
    'candidate': 'draft-001-repaired.rs',
    'restored_repeat': 'draft-004-restored.rs',
    'source_preservation_audit': 'source-preservation-audit.json',
    'applications': 'application-ledger.jsonl',
    'results': 'fresh-summary.json',
    'method_ledger': 'method-ledger.json',
    'raw_evidence': 'runs/attempt-001 through runs/attempt-005',
    'authentication': ['authentication-entry.json', 'authentication-exit.json', 'sysroot-pin-corroboration.json'],
    'externally_pinned_inputs': PINS,
    'candidate_sha256': digest(ROOT / 'draft-001-repaired.rs'),
    'original_source_sha256': '036505f3ec263621a2b5b1b81380625ad57e7170c4717750e027bd35f8c29477',
    'direct_verifier_applications': 5,
    'auxiliary_checked_proof_lemmas': 0,
    'additional_verus_identities': 1,
    'conservative_control_body_variant_charge': 2,
    'new_specs': 0,
    'new_trust_native_or_live_acceptance': False,
    'independent_review': 'PENDING_PARENT_COMMISSION',
    'all_eighteen_cells': 'OPEN',
    'original_native_source_path_preservation': 'FAILED',
    'original_native_git_continuity': 'UNAVAILABLE',
    'budget_at_handoff': budget(),
})
manifest = {}
for path in sorted(ROOT.rglob('*')):
    if path.is_file():
        assert stat.S_ISREG(path.lstat().st_mode) and not path.is_symlink()
        manifest[str(path.relative_to(ROOT))] = {'sha256': digest(path), 'size_bytes': path.stat().st_size}
write(ROOT / 'MANIFEST.json', manifest)
write(ROOT / 'SEAL.json', {
    'schema': 'cycle100-scratch-proof-only-conditional-handoff-seal-v1',
    'sealed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'manifest_sha256': digest(ROOT / 'MANIFEST.json'),
    'report_sha256': digest(ROOT / 'REPORT.md'),
    'handoff_sha256': digest(ROOT / 'HANDOFF.json'),
    'summary_sha256': digest(ROOT / 'fresh-summary.json'),
    'payloads': len(manifest),
    'direct_verifier_applications': 5,
    'minimum_supplemental_release_target': 'ACHIEVED_CONDITIONALLY_PENDING_INDEPENDENT_REVIEW',
    'new_trust_native_or_live_acceptance': False,
    'all_eighteen_cells': 'OPEN',
    'budget': budget(),
})
for path in ROOT.rglob('*'):
    if path.is_file():
        path.chmod(0o444)
for path in sorted((path for path in ROOT.rglob('*') if path.is_dir()), key=lambda path: len(path.parts), reverse=True):
    path.chmod(0o555)
ROOT.chmod(0o555)
actual = {str(path.relative_to(ROOT)) for path in ROOT.rglob('*') if path.is_file()}
assert actual == set(manifest) | {'MANIFEST.json', 'SEAL.json'}
for relative, row in manifest.items():
    path = ROOT / relative
    assert digest(path) == row['sha256'] and path.stat().st_size == row['size_bytes']
    assert not path.stat().st_mode & 0o222
print('HANDOFF_ROOT', ROOT)
print('SEAL_SHA256', digest(ROOT / 'SEAL.json'))
print('REPORT_BYTES', (ROOT / 'REPORT.md').stat().st_size)
print('MANIFEST_BYTES', (ROOT / 'MANIFEST.json').stat().st_size)
print('PAYLOADS', len(manifest))
print('FINAL_BUDGET', budget())
