import hashlib
import json
import pathlib
import shutil
import signal
import time

scratch = pathlib.Path(__file__).resolve().parent
started_epoch = 1794104836
absolute_deadline_epoch = 1794105196
basis_deadline_epoch = 1794104956
optional_stop_epoch = 1794105076
scratch_limit_bytes = 8 * 1024 * 1024
free_minimum_bytes = 16 * 1024 * 1024 * 1024


def enforce_deadline():
    if time.time() >= absolute_deadline_epoch:
        raise RuntimeError("ABSOLUTE_DEADLINE_EXCEEDED")


def deadline_signal(signal_number, frame):
    raise RuntimeError("ABSOLUTE_DEADLINE_EXCEEDED")


def digest(path):
    enforce_deadline()
    hasher = hashlib.sha256()
    with pathlib.Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            enforce_deadline()
            hasher.update(chunk)
    return hasher.hexdigest()


def write_json(name, data):
    enforce_deadline()
    (scratch / name).write_text(json.dumps(data, indent=2) + "\n")


signal.signal(signal.SIGALRM, deadline_signal)
signal.setitimer(signal.ITIMER_REAL, max(0.001, absolute_deadline_epoch - time.time()))
entry = json.loads((scratch / "input-entry.json").read_bytes())
supplement = json.loads((scratch / "supplement-entry.json").read_bytes())
control_root = pathlib.Path("/Users/tommyvolk/.t3/worktrees/verus/t3-60978068/evidence/redb-native-binding-trace106")
control_hashes = {name: digest(control_root / name) for name in ["README.md", "PLAN.md", "INPUT-BINDINGS.json"]}
assert control_hashes["PLAN.md"] == "df5746a5c7f90ec8f299513777082c724fae873db39c362d91a69f405c0d9776"
assert control_hashes["INPUT-BINDINGS.json"] == entry["table_sha256"]
table = json.loads((control_root / "INPUT-BINDINGS.json").read_bytes())
current = {binding["path"]: binding for binding in table["bindings"]}
historical_root = pathlib.Path("/private/tmp/redb-native-view-gate105-research-20261107-XfBCmr")
historical = json.loads((historical_root / "INPUT-ENTRY.json").read_bytes())
historical_supplement = json.loads((historical_root / "SUPPLEMENT-ENTRY.json").read_bytes())
differences = []
unchanged = 0
for binding in historical["bindings"]:
    present = current.get(binding["path"])
    if present and present["sha256"] == binding["sha256"]:
        unchanged += 1
    else:
        differences.append({"path": binding["path"], "historical_sha256": binding["sha256"], "current_sha256": present["sha256"] if present else None})
reconciliation = table["intentional_context_reconciliation"][0]
assert unchanged == 211 and len(differences) == 1
assert differences[0]["path"] == reconciliation["path"]
assert differences[0]["historical_sha256"] == reconciliation["historical_sha256"]
assert differences[0]["current_sha256"] == reconciliation["current_sha256"]
assert current[reconciliation["historical_snapshot"]]["sha256"] == reconciliation["historical_sha256"]
supplement_unchanged = all(current[binding["path"]]["sha256"] == binding["sha256"] for binding in historical_supplement)
assert supplement_unchanged and len(historical_supplement) == 4
write_json("context-reconciliation.json", {"historical_descriptors_only_not_live_manifest": True, "old212_count": len(historical["bindings"]), "unchanged211": unchanged, "intentional_reconciliation": reconciliation, "differences": differences, "historical_snapshot_exact_old_hash": True, "supplemental4_unchanged": supplement_unchanged, "old320_not_applied": True})
exit_records = []
exit_started_epoch = time.time()
for binding in entry["records"]:
    actual = digest(binding["path"])
    exit_records.append({"path": binding["path"], "role": binding["role"], "expected_sha256": binding["sha256"], "entry_sha256": binding["actual_sha256"], "exit_sha256": actual, "match": actual == binding["sha256"] == binding["actual_sha256"]})
assert len(exit_records) == 235 and all(binding["match"] for binding in exit_records)
write_json("input-exit.json", {"phase": "exit", "started_epoch": exit_started_epoch, "completed_epoch": time.time(), "count": len(exit_records), "matches": sum(binding["match"] for binding in exit_records), "control_hashes": control_hashes, "records": exit_records})
supplement_exit = []
for binding in supplement["records"]:
    actual = digest(binding["path"])
    supplement_exit.append(dict(binding, exit_sha256=actual, exit_match=actual == binding["actual_sha256"] == binding["expected_sha256"]))
assert all(binding["exit_match"] for binding in supplement_exit)
write_json("supplement-exit.json", {"completed_epoch": time.time(), "count": len(supplement_exit), "matches": sum(binding["exit_match"] for binding in supplement_exit), "records": supplement_exit})
report_size = (scratch / "REPORT.md").stat().st_size
assert report_size <= 10 * 1024
disk_free = shutil.disk_usage(scratch).free
assert disk_free > free_minimum_bytes
files_before_accounting = sorted(path for path in scratch.iterdir() if path.is_file())
scratch_before_accounting = sum(path.stat().st_size for path in files_before_accounting)
assert scratch_before_accounting < scratch_limit_bytes
write_json("ACCOUNTING.json", {"started_epoch": started_epoch, "recorded_epoch": time.time(), "basis_decision_epoch": 1794104907.94458, "basis_search_seconds_including_entry_auth": 71.94458, "basis_deadline_epoch": basis_deadline_epoch, "optional_stop_epoch": optional_stop_epoch, "absolute_deadline_epoch": absolute_deadline_epoch, "elapsed_seconds_at_accounting": time.time() - started_epoch, "all_optional_inspection_ended_before_epoch": 1794104956, "finalization_only_after_source_basis_stop": True, "supplied_entry_count": 235, "supplied_exit_count": 235, "entry_matches": entry["matches"], "exit_matches": 235, "supplement_entry_exit_matches": len(supplement_exit), "supplied_input_bytes_hashed_per_endpoint": sum(binding["size_bytes"] for binding in entry["records"]), "report_bytes": report_size, "report_limit_bytes": 10240, "scratch_bytes_before_accounting_manifest_seal": scratch_before_accounting, "scratch_limit_bytes": scratch_limit_bytes, "free_bytes_measured": disk_free, "free_minimum_bytes": free_minimum_bytes, "target_executions": 0, "network_operations": 0, "git_operations": 0, "subdelegations": 0, "parent_source_provider_runtime_writes": 0, "new_proof_credit": 0, "new_trust": 0, "adoption": 0, "all_eighteen_cells": "OPEN", "no_atomic_snapshot_or_full_utility_environment_attestation": True})
payloads = sorted(path for path in scratch.iterdir() if path.is_file() and path.name not in ["MANIFEST.sha256", "SEAL.json"])
manifest_lines = [digest(path) + "  " + path.name for path in payloads]
(scratch / "MANIFEST.sha256").write_text("\n".join(manifest_lines) + "\n")
manifest_hash = digest(scratch / "MANIFEST.sha256")
seal = {"kind": "CONTENT_INTEGRITY_SEAL_NOT_PROOF_CERTIFICATE", "manifest_sha256": manifest_hash, "report_sha256": digest(scratch / "REPORT.md"), "input_entry_sha256": digest(scratch / "input-entry.json"), "input_exit_sha256": digest(scratch / "input-exit.json"), "accounting_sha256": digest(scratch / "ACCOUNTING.json"), "payload_count": len(payloads), "all_supplied_entry_exit_matches": True, "all_additional_entry_exit_matches": True, "sealed_epoch": time.time(), "elapsed_seconds": time.time() - started_epoch, "absolute_deadline_epoch": absolute_deadline_epoch, "deadline_met": time.time() < absolute_deadline_epoch, "all_eighteen_cells": "OPEN", "next_implementation_decision": "NO_GO_WITHOUT_SEPARATE_AUTHORIZATION_FOR_ONE_PROVENANCE_BEARING_EXACT_CALL_CAPABILITY_BUILD_PROBE"}
write_json("SEAL.json", seal)
final_scratch_bytes = sum(path.stat().st_size for path in scratch.iterdir() if path.is_file())
assert final_scratch_bytes <= scratch_limit_bytes
assert shutil.disk_usage(scratch).free > free_minimum_bytes
for path in payloads:
    expected = next(line.split("  ")[0] for line in manifest_lines if line.endswith("  " + path.name))
    assert digest(path) == expected
enforce_deadline()
print(json.dumps({"root": str(scratch), "report_sha256": seal["report_sha256"], "manifest_sha256": manifest_hash, "seal_sha256": digest(scratch / "SEAL.json"), "entry_sha256": seal["input_entry_sha256"], "exit_sha256": seal["input_exit_sha256"], "accounting_sha256": seal["accounting_sha256"], "payload_count": len(payloads), "file_count": len(payloads) + 2, "scratch_bytes": final_scratch_bytes, "report_bytes": report_size, "elapsed_seconds": time.time() - started_epoch, "deadline_met": True, "free_bytes": shutil.disk_usage(scratch).free}, indent=2))
