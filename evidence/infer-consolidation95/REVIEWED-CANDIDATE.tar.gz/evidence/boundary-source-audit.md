# Native-resource F1 boundary-regression assessment

November 7, 2026. Read-only assessment of the dirty worktree:
`/Users/tommyvolk/.t3/worktrees/verus/t3-60978068`.
Anchors are root-relative. Source findings and proposed tests are not runtime
results or frozen-candidate authentication.

## Decision and blocking objection

**F1 is real. An import diagnostic defect also blocks a clean-rejection claim;
it does not demonstrate an acceptance/soundness bypass.**

F1:
`evidence/redb-crash-consistency94/NATIVE-RESOURCE-IMPLEMENTATION-INDEPENDENT-REVIEW.md:63`.
The JSON publication test calls `reject_crate` with three strings; the other
controls call `check_lowering` directly (`source/vir/src/native_resource/tests.rs:109`,
`:128`, `:142`). None detects misplaced/missing boundary calls.

**Blocking diagnostic mismatch, source-proven, not runtime-reproduced:**

1. `reject_crate` constructs `error(&function.span, ...)`
   (`source/vir/src/native_resource.rs:10`). `error` delegates to `message`,
   which always stores one primary span (`source/vir/src/messages.rs:422`, `:275`).
   Deserialization discards only `raw_span`, not the `Span` object
   (`source/vir/src/messages.rs:14`).
2. Real import propagates that error immediately after decoding
   (`source/rust_verify/src/import_export.rs:111`, `:116`).
3. The actual driver import-error arm asserts `err.spans.len() == 0` before
   reporting the note or setting `encountered_vir_error`
   (`source/rust_verify/src/verifier.rs:3423`, `:3426`, `:3429`). A decoded marked
   member therefore reaches a failing assertion, not the intended diagnostic arm.
4. `driver::run_compiler` catches panics and maps them to `Err(())`
   (`source/rust_verify/src/driver.rs:18`, `:29`). Merely asserting unsuccessful
   exit/status would incorrectly count this panic as a passing refusal test.

Require the native-resource diagnostic, no panic/ICE, and normal driver error
bookkeeping. Reconcile the import diagnostic convention; do not remove the guard,
erase local spans globally, or bless the panic. No correction is implemented.

## Actual callable seams and ordering

- **Import:** crate-private `import_crates(&Args, Vec<(String, String)>) ->
  Result<ImportOutput, VirErr>`, `source/rust_verify/src/import_export.rs:98`.
  `args.import` and the Cargo vector share the loop (`:107`). Actual
  `bincode_next::serde::decode_from_std_read(..., config::legacy())` precedes
  rejection (`:116`), then model/trailer handling (`:117`, `:131`).
  `ImportOutput` lacks `Debug` (`:90`): use `match`/`.err().expect(...)`, not
  `Result::unwrap_err()` requiring a new derive.
- **Export:** crate-private `export_crate(&Args, &Option<PathBuf>, CrateMetadata,
  Krate, verified_inference)`, same file `:261`. No output path intentionally
  returns `Ok(())` (`:273`); rejection (`:276`) precedes private-member pruning
  (`:283`) and executable-body stripping (`:288`). Real serialization and
  publication are in private `atomic_export` (`:332`, `:343`, `:357`).
- **Local driver admission:** private, rustc-dependent
  `Verifier::construct_vir_crate`, `source/rust_verify/src/verifier.rs:2784`.
  The real call rejects `query.get_exportable_crate()` at `:2914`, before the
  no-lifetime checks (`:2916`), pending export (`:2992`), UserFilter (`:3050`)
  and merged VIR (`:3057`). Query gathers checked functions before user filtering
  (`source/rust_verify/src/query.rs:497`). Imports do NOT cover this local guard.
- **Driver:** `Verifier::new` (`verifier.rs:503`), then
  `driver::run(verifier, rustc_args, verus_root, build_test_mode)`
  (`source/rust_verify/src/driver.rs:263`). `finish_export` (`verifier.rs:3089`)
  needs pending VIR/no errors; publication follows compile status (`driver.rs:372`).

## Minimal fixtures and test placement

Propose a `#[cfg(test)]` child module in `import_export.rs`: actual private
`CrateWithMetadata { krate, metadata }` (`:29`), serializer and APIs are accessible
there. Recreate the small Function/Krate builders from
`source/vir/src/native_resource/tests.rs:21`, `:82` locally; they are private to
VIR tests, not importable rust_verify fixtures. Expose no production test API.

Use unit-returning VIR, `infer=false`, no inference-contract attributes, only
`infer_candidate_id=Some("experimental-native-resource-ir:v1:affine")` changed.
This is adversarial VIR, not a native Rust producer. Metadata: fixed test crate
ID, empty `original_files`, `inference_aware=false`.
Keep an unmarked public sibling first and the marked member later. Variants:
public/bodyful exec, public/bodyless exec, private/bodyless exec (a real module
path in `visibility.restricted_to`). This catches both body and visibility
erasure. Retain paired unmarked clones of the same fixtures.

Encode marked imports as the ACTUAL envelope using
`bincode_next::serde::encode_into_std_write(..., config::legacy())` into a unique
temporary directory; no JSON, patched offsets, duplicate wire struct or rejecting
exporter as fixture writer. Independently decode and assert marker, body,
restriction and metadata survival. This grants no normal export authorization.

## Recommended regression group

### I. Real bincode import, including both import sources

- Import each marked fixture through `args.import`, then the Cargo vector alone.
  Assert `Err`, Error level and `import is unavailable; conditional IR transport
  is not native correspondence`, not I/O/trailer/deserialization failure. Put an
  unmarked crate before a marked crate once to detect first-item-only checks.
- Unmarked twins must import with expected counts, metadata, body/visibility
  and no inference dependencies. Truncated bytes must produce the distinct
  deserialize error (`import_export.rs:113`). Do not freeze the bad span convention.

### E. Real exporter, before pruning/stripping/publication

- Call `export_crate(..., marked, None)` with direct and Cargo-only output paths.
  Require native-resource `export is unavailable`, no new final artifact, and no
  `path.with_extension(format!("vir.{}.tmp", process::id()))` file.
- Seed a destination with sentinel bytes in a separate run: direct rejection
  must leave them unchanged; invalidation is separate (`:250`).
- Export each unmarked clone successfully; decode the real published bytes as
  `CrateWithMetadata`. Assert the private function is absent, the public exec
  body is removed, expected public members/metadata remain, and no temp file
  remains. This demonstrates that the marked variants would otherwise vanish
  through pruning/body-stripping. No-output-path is an intentional no-op, not
  publication/bypass; direct path precedence is at `import_export.rs:244`.

### D. Real driver refusal, skips/filters, and stale-output invalidation

**Import driver needs no injection:** from rust_verify's test module, use the
real bincode fixture, valid Rust consumer, fresh Args/Verifier and `driver::run`.
Cover default, valid exclusion filter, and combined `no_verify + no_lifetime`.
Require error status AND `encountered_vir_error=true`, zero verified functions,
no pending export/published inference, native-resource import diagnostic and no
panic/ICE. The span mismatch fails this oracle. Outer `catch_unwind` cannot
detect a panic already caught by the driver.

Capture stderr with test-process child isolation or the raw binary harness after
wiring typed fixtures. `driver::run` returns no diagnostics.
`common::run_verus_raw` captures subprocess output
(`source/rust_verify_test/tests/common/mod.rs:544`, `:576`); do not duplicate the
private schema just to use it.

**Local-driver gap: no injectable marked-local-crate seam exists today.**
Helper calls, imports, or seeded `pending_export` do not cover local admission.
Propose a private per-Verifier `#[cfg(test)]` one-shot `Krate -> Krate` transform
after successful `get_exportable_crate`, immediately before rejection. Mark a
translated private member, optionally strip its body, retain rustc spans; the
hook must NOT reject. Callback must be Send (`driver.rs:22`), initialized None in
BOTH constructors (`verifier.rs:503`, `:564`), never copied to workers. No source
attribute, production CLI/env gate, trust rule or alternative admission. Unit-test
cfg does not propagate to the external binary: use rust_verify's own unit-test
driver, with child isolation for stderr.

Use two modules: function filter marks a private sibling in the selected module;
module filter marks the other module. Separate cases: default,
`--verify-only-module selected --verify-function survivor`, module filter only,
`--no-verify`, `--no-lifetime`, and both skip flags. The function-filter pairing
is required (`source/rust_verify/src/config.rs:687`,
`source/rust_verify/src/user_filter.rs:61`). Invalid filters are not refusals.

Assert the LOCAL `native source admission is unavailable` diagnostic, normal
driver error bookkeeping, `user_filter=None`, `vir_crate=None`,
`pending_export=None`, `inference_exported=false`, and zero verified functions.
Paired identity-transform/unmarked runs must validate identical source/options
and selected-member exclusion. Missing toolchain/externs is not a control pass.
Test fresh and seeded direct exports: both must be absent after driver refusal;
callbacks invalidate old paths (`verifier.rs:3293`, `:3393`). Include a no-export
case to prove refusal is independent of publication.

### L. Actual lowerer entrypoints, without solver execution

Extend `source/vir/src/native_resource/tests.rs`; move only context setup
(`:195`, `:218`) outside the feature-only solver module. Stop at SST, not
`check_at`'s AIR/solver tail.

- Feature OFF: manually marked, bodyful exec through
  `ast_to_sst_crate::ast_to_sst_krate` / `function_to_sst` must return the exact
  native-resource lowerer diagnostic. The unmarked twin must lower successfully.
- Feature ON: marked internal exec body must lower; marked spec body with
  `check_recommends=true` and owning-bucket membership must fail through
  `function_to_sst` (`source/vir/src/ast_to_sst_func.rs:1070`). Build valid spec
  parameter/return modes, not just an invalid mode-flipped exec fixture.
- Call real `func_def_to_sst(ctx, diagnostics, marked, true)` and require refusal
  before safe-API havoc (`ast_to_sst_func.rs:741`, `:747`). This covers the flag,
  NOT safe-public-trait dispatch, which needs a public safe trait declaration and
  `ctx.global.check_api_safety` (`source/vir/src/safe_api.rs:166`).

Do not claim universal lowerer refusal: bodyless exec/spec declarations need not
enter `func_def_to_sst` (`ast_to_sst_func.rs:1059`), ordinary nonrecursive spec
functions can skip recommends checking (`:1072`), and crate lowering skips
invisible / `is_decrease_by` members (`source/vir/src/ast_to_sst_crate.rs:21`).
Document/characterize these limits; do not require new rejection and silently
change admission. Blanket crate barriers protect publication/native admission.

## Build integration, evidence limits, and preservation

bincode already belongs to rust_verify; add only the existing workspace tempfile
as a dev-dependency if needed (`source/rust_verify/Cargo.toml:10`, `:32`;
`source/Cargo.toml:79`). No bincode dependency in VIR. Feature is VIR-only,
default-off (`source/vir/Cargo.toml:21`): test both states with dependency-feature
selection for rust_verify, not a new feature. Adversarial markers need no producer.

Do not propose `vargo test -p rust_verify` or `-p vir`: that runner accepts only
air/rust_verify_test (`tools/vargo/src/commands/test.rs:56`). Future unit runs
need direct Cargo package/lib targeting in `source`; not attempted here. Pinned
toolchain: 1.99.1 + rustc-dev (`rust-toolchain.toml:1`); rust_verify is rustc-private
(`source/rust_verify/src/lib.rs:1`). Cargo config sets cfgs/bootstrap/target and
solver paths (`source/.cargo/config.toml:1`). Subprocess tests additionally need
compatible built artifacts (`common/mod.rs:544`); availability is unverified.

No builds, tests, solver/native executions, network, Git write commands,
implementation/admission changes or delegation. Existing files and excluded
tasks were untouched. Only this report was written. Free space stayed above
16 GiB (~106 GiB). No native-correspondence, trust or acceptance claim follows.
