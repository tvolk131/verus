import hashlib
import json
from pathlib import Path
import shutil
import sys


ROOT = Path('/Users/tommyvolk/.t3/worktrees/verus/t3-60978068')
WORK = Path('/private/tmp/verus-consolidation-hardening-20261107-3uq41d0f')
CANDIDATES = (
    'README.md',
    'VERUS_INFER_STATUS.md',
    'evidence/infer-consolidation95/README.md',
    'evidence/redb-crash-consistency94/GOAL.md',
    'evidence/redb-crash-consistency94/STATUS.json',
    'evidence/redb-crash-consistency94/TAKEOVER.md',
    'source/Cargo.lock',
    'source/rust_verify/Cargo.toml',
    'source/rust_verify/src/import_export.rs',
    'source/rust_verify/src/import_export/native_resource_boundary_tests.rs',
    'source/tools/INFER_TRANSFERS.md',
    'source/tools/check_native_resource_boundaries.py',
    'source/tools/test_native_resource_boundaries.py',
    'source/tools/test_fedimint_insert_link80a.py',
    'source/tools/fixtures/fedimint_insert_link80a.rs',
    'source/vir/NATIVE_RESOURCE_IR.md',
)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    destination = WORK / sys.argv[1]
    baseline = json.loads((WORK / 'BASELINE.json').read_text())
    changed = {}
    for name, original in baseline['files'].items():
        path = ROOT / name
        current = digest(path) if path.is_file() else None
        if current != original:
            changed[name] = {'baseline_sha256': original, 'candidate_sha256': current}
    unexpected = sorted(set(changed) - set(CANDIDATES))
    if unexpected:
        raise RuntimeError(f'unexpected baseline changes: {unexpected}')
    receipt = json.loads((WORK / 'replay3/receipt.json').read_text())
    if not receipt['success']:
        raise RuntimeError('replay3 did not pass')
    drift = [name for name, expected in receipt['inputs'].items()
             if digest(ROOT / name) != expected]
    if drift:
        raise RuntimeError(f'tested input drift: {drift}')
    destination.mkdir(exist_ok=False)
    support = (
        'source/tools/check_fedimint_insert_link80a.py',
        'evidence/transfer-fedimint-insert-link80a/source-ledger.json',
        'evidence/redb-crash-consistency94/NATIVE-RESOURCE-IMPLEMENTATION-INDEPENDENT-REVIEW.md',
    )
    copied = {}
    for name in sorted(set(CANDIDATES) | set(receipt['inputs']) | set(support)):
        source = ROOT / name
        target = destination / 'tree' / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
        copied[str(target.relative_to(destination))] = digest(target)
    artifacts = [WORK / 'BASELINE.json', WORK / 'seal_candidate.py']
    artifacts.extend(WORK.glob('*.log'))
    for replay in ('replay1', 'replay2', 'replay3'):
        artifacts.extend((WORK / replay).glob('*.log'))
        artifacts.extend((WORK / replay).glob('*.json'))
    audit = Path('/private/tmp/verus-native-resource-f1-review-20261107-YLG16Z74/REPORT.md')
    for source in artifacts:
        target = destination / 'evidence' / source.relative_to(WORK)
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
        copied[str(target.relative_to(destination))] = digest(target)
    target = destination / 'evidence/boundary-source-audit.md'
    shutil.copyfile(audit, target)
    copied[str(target.relative_to(destination))] = digest(target)
    manifest = {
        'schema': 'infer-hardening95-candidate-v1',
        'classification': 'engineering implementation review; no native proof acceptance',
        'baseline_head': baseline['head'],
        'baseline_file_count': len(baseline['files']),
        'changed_baseline_files': changed,
        'unrelated_baseline_files_unchanged': len(baseline['files']) - len(changed),
        'unexpected_baseline_changes': unexpected,
        'new_candidate_files': sorted(set(CANDIDATES) - baseline['files'].keys()),
        'review_candidates': list(CANDIDATES),
        'tested_input_drift': drift,
        'copied_files': copied,
        'limitations': [
            'baseline preserves hashes/status, not complete original bytes',
            'candidate full files include inherited edits and are not a baseline patch',
            'selected replay source identities are not complete runtime provenance',
            'independent source audit predates final implementation review',
        ],
    }
    manifest_path = destination / 'MANIFEST.json'
    manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
    print(json.dumps({'snapshot': str(destination), 'manifest_sha256': digest(manifest_path),
                      'changed_baseline_files': len(changed),
                      'unrelated_baseline_files_unchanged': manifest['unrelated_baseline_files_unchanged'],
                      'new_candidate_files': len(manifest['new_candidate_files']),
                      'copied_files': len(copied)}, indent=2))


if __name__ == '__main__':
    main()
