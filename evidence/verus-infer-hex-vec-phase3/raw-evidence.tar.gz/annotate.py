from pathlib import Path
r=Path('/Users/tommyvolk/Documents/GitHub/hex-conservative')
sel='#[cfg_attr(verus_keep_ghost, cfg_attr(verus_hex_vec_phase3, verus_verify))]'
p=r/'src/lib.rs';s=p.read_text();s=s.replace('mod decoding_spec;','mod decoding_spec;\n#[cfg(verus_keep_ghost)]\n#[cfg(verus_hex_vec_phase3)]\nmod vector_spec;',1)
s=s.replace('pub fn decode_to_vec(hex:',sel+'\n#[cfg_attr(verus_keep_ghost, cfg_attr(verus_hex_vec_phase3, verus_spec(r => ensures crate::vector_spec::public_result(hex, r))))]\npub fn decode_to_vec(hex:',1);p.write_text(s)
p=r/'src/iter.rs';s=p.read_text();s=s.replace('    pub(crate) fn drain_to_vec(self)', '    '+sel+'\n    #[cfg_attr(verus_keep_ghost, cfg_attr(verus_hex_vec_phase3, verus_spec(r => ensures crate::vector_spec::drain_result(self.input_pairs(), self.cursor() as int, r))))]\n    pub(crate) fn drain_to_vec(self)',1);p.write_text(s)
p=r/'src/error.rs';s=p.read_text();s=s.replace('pub enum DecodeVariableLengthBytesError',sel+'\npub enum DecodeVariableLengthBytesError',1)
for name,variant in [('InvalidCharError','InvalidChar'),('OddLengthStringError','OddLengthString')]:
 before='impl From<'+name+'> for DecodeVariableLengthBytesError {'
 s=s.replace(before,sel+'\n'+before,1)
 before='    fn from(e: '+name+') -> Self { Self::'+variant+'(e) }'
 after='    #[cfg_attr(verus_keep_ghost, cfg_attr(verus_hex_vec_phase3, verus_spec(r => ensures r == Self::'+variant+'(e))))]\n'+before
 s=s.replace(before,after,1)
p.write_text(s)
p=r/'src/vector_spec.rs';p.write_text('''// SPDX-License-Identifier: CC0-1.0
//! Required public/vector behavior for the opt-in, currently unaccepted memory phase.
use vstd::prelude::*;
use vstd::string::StringSliceAdditionalSpecFns;
use crate::error::{DecodeVariableLengthBytesError,InvalidCharError};
use crate::alloc::vec::Vec;
verus! {
// Numeric ASCII semantics are the independent v1 requirements, never a table axiom.
pub open spec fn public_result(s:&str,r:Result<Vec<u8>,DecodeVariableLengthBytesError>)->bool {
    let bytes=s.spec_bytes();
    if bytes.len()%2!=0 {
        match r {
            Err(DecodeVariableLengthBytesError::OddLengthString(e))=>e.len==bytes.len(),
            _=>false,
        }
    } else {
        match r {
            Ok(v)=>v@.len()==bytes.len()/2 && (forall|i:int| 0<=i<v@.len() ==>
                crate::decoding_spec::pair(bytes[2*i],bytes[2*i+1])==Ok(v@[i])),
            Err(DecodeVariableLengthBytesError::InvalidChar(e))=>
                e.pos<bytes.len() && e.invalid==bytes[e.pos as int] &&
                crate::decoding_spec::digit(e.invalid).is_none() &&
                (forall|i:int| 0<=i<e.pos ==> crate::decoding_spec::digit(bytes[i]).is_some()),
            _=>false,
        }
    }
}

pub open spec fn sat_position(n:int)->usize {if n>usize::MAX {usize::MAX} else {n as usize}}
// Required logical result only. This is NOT an assumed drain contract or a
// permission to write memory; the selected native body must establish it.
pub open spec fn drain_result(pairs:Seq<[u8;2]>,cursor:int,r:Result<Vec<u8>,InvalidCharError>)->bool {
    match r {
        Ok(v)=>v@.len()==pairs.len() && (forall|i:int| 0<=i<pairs.len() ==>
            crate::decoding_spec::pair(pairs[i]@[0],pairs[i]@[1])==Ok(v@[i])),
        Err(e)=>exists|i:int| 0<=i<pairs.len() &&
            (forall|j:int| 0<=j<i ==> crate::decoding_spec::pair(pairs[j]@[0],pairs[j]@[1]).is_ok()) &&
            match crate::decoding_spec::pair(pairs[i]@[0],pairs[i]@[1]) {
                Err((b,high))=>e.invalid==b && e.pos==sat_position(2*(cursor+i)+if high {0int}else{1int}),
                _=>false,
            },
    }
}
}
''')
