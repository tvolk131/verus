import gzip,hashlib,json,subprocess,tarfile
from pathlib import Path
r=Path('/Users/tommyvolk/Documents/GitHub/verus');n=r.parent/'hex-conservative';w=Path('/private/tmp/verus-hex-vec-phase3');o=r/'evidence/verus-infer-hex-vec-phase3'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def git(root,*args):return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
def write(name,data):(o/name).write_text(json.dumps(data,indent=2)+'\n')
p=json.load(open(w/'final-restored/receipt.json'));a=json.load(open(w/'final-restored/restored-iterator/receipt.json'));assert a['success'];assert not p['public_vector_verified'];assert not p['interface_written'];assert p['sources_before']==p['sources_after'];assert not git(n,'status','--porcelain')
v2=r/'evidence/verus-infer-hex-v2';v2r=json.load(open(v2/'engine-source-receipt.json'));assert p['artifacts']==v2r['artifacts']
for path,h in v2r['engine_source_sha256'].items():
 if any(path.startswith(prefix) for prefix in ['source/rust_verify/','source/vir/','source/vstd/','source/builtin/','source/builtin_macros/']):assert sha(r/path)==h,path
for name,h in json.load(open(o/'preserved-v2-files.json')).items():assert sha(v2/name)==h,name
write('closure-summary.json',dict(decision='public vector memory endpoint remains unsupported; iterator acceptance preserved',public_vector_verified=False,native_phase_commit=git(n,'rev-parse','HEAD'),native_iterator_commit='cc0bf36056a190bd7da4cbf226e778580e8bb472',engine_implementation_commit=v2r['engine_implementation_commit'],iterator_archive_commit='0b512160f',proof_toolchain=a['proof_toolchain'],metadata_schema=38,inference_policy=52,candidate_cache=58,unsupported_operations=['Vec::as_mut_ptr','core::ptr::write','raw-pointer add','Vec::set_len'],phase3_published_interface=False,restored_iterator_verification_results=30,restored_iterator_errors=0,restored_native_features_and_msrv_pass=True,no_compiler_or_vstd_implementation_changes=True,compiler_vstd_artifacts=p['artifacts'],all_218_original_signatures_and_bodies_preserved=True,cargo_config_change="Only add cfg(verus_hex_vec_phase3) to existing deny-level check-cfg allowlist",phase_feature='proc_macro_hygiene only when verus_keep_ghost and verus_hex_vec_phase3',sources_before=p['sources_before'],sources_after=p['sources_after'],blocked_probe_command=p['failed_probe_command'],blocked_exit_code=p['failed_probe_exit'],runner_sha256=p['runner_sha256']))
with tarfile.open(o/'native-source.tar.gz','w:gz') as t:
 for path in [*git(n,'ls-files').splitlines(),'Cargo.lock']:
  if (n/path).is_file():t.add(n/path,arcname=path,recursive=False)
(o/'native-phase.patch.gz').write_bytes(gzip.compress(subprocess.check_output(['git','diff','cc0bf36056a190bd7da4cbf226e778580e8bb472','HEAD'],cwd=n)))
paths=[path for path in w.rglob('*') if path.is_file() and path.suffix in ['.stdout','.stderr','.json','.py','.vir'] and not any(part in ['native-target','msrv-target','upstream-source'] for part in path.relative_to(w).parts)]
with tarfile.open(o/'raw-evidence.tar.gz','w:gz') as t:
 for path in sorted(paths):t.add(path,arcname=str(path.relative_to(w)),recursive=False)
write('raw-evidence-index.json',dict(files_sha256={str(path.relative_to(w)):sha(path) for path in sorted(paths)},raw_archive_sha256=sha(o/'raw-evidence.tar.gz'),native_archive_sha256=sha(o/'native-source.tar.gz'),phase_patch_sha256=sha(o/'native-phase.patch.gz')))
print('Concrete blocker and restored evidence archived;',len(paths),'raw files')
