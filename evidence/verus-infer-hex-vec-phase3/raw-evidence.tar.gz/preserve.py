import hashlib,json,subprocess
from pathlib import Path
r=Path('/Users/tommyvolk/Documents/GitHub/verus');o=r/'evidence/verus-infer-hex-v2'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def git(p,*args):return subprocess.check_output(['git',*args],cwd=p,text=True).strip()
b=json.load(open(o/'baseline.json'))
for p,h in b['preserved_evidence_sha256'].items():assert sha(r/p)==h,p
v4=Path('/private/tmp/verus-validation-v4/aleph'); prior=json.load(open(r/'evidence/verus-infer-validation-v4/closure-summary.json'))
for p,h in prior['source_hashes'].items():assert sha(v4/p)==h,p
assert git(v4,'rev-parse','HEAD')==prior['native_implementation_commit'];assert not git(v4,'status','--porcelain')
pin=json.load(open('/private/tmp/verus-mechanical-v3/PINNED_ENGINE.json'));s=Path(pin['engine_source']);bin=s/'target-verus/release'
for p,h in pin['artifacts_sha256'].items():assert sha(bin/p)==h,p
assert sha(s/'z3')==pin['z3_sha256'];assert git(s.parent,'rev-parse','HEAD')==pin['engine_commit'];assert not git(s.parent,'status','--porcelain')
json.dump(dict(all_prior_evidence_file_hashes_preserved=len(b['preserved_evidence_sha256']),aleph_v4_native_commit=prior['native_implementation_commit'],aleph_v4_sources_preserved=len(prior['source_hashes']),aleph_v4_clean=True,aleph_v3_fixed_engine_commit=pin['engine_commit'],aleph_v3_fixed_engine_clean=True,aleph_v3_pinned_artifacts_and_solver_preserved=len(pin['artifacts_sha256'])+1,hex_v1_source_commit='5ccfbad247d5a332408929173e4072fbf06d8bd1',hex_v1_archive_preserved=True,accepted_evidence_git_trees=git(r,'ls-tree','HEAD','evidence/verus-infer-hex-v1','evidence/verus-infer-mechanical-v3','evidence/verus-infer-validation-v4').splitlines()),open(r/'evidence/verus-infer-hex-vec-phase3/preservation.json','w'),indent=2)
print('Prior accepted evidence, native Aleph inputs and pinned engine artifacts preserved')
