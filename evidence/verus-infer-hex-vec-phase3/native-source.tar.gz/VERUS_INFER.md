# Verus Infer: forward byte-pair milestone

Baseline: `129db6ac54d25b08e0b927c225aefe4a8df05a57` (version 1.3.0).
This branch retains the native algorithms. Verification selects the actual
`Char::decode_nibble`, its original local 256-byte static initializer, and
`iter::hex_chars_to_byte`. `src/decoding_spec.rs` supplies independent ASCII-range
requirements and the forward equation `16 * high + low` for all byte pairs.

The table and nibble semantics are authored **requirements checked against their
bodies**, not inferred or assumed contracts. The pair implementation contract is
inferred and must pass body soundness, maximality and exactness. The ordinary
pair semantic goal additionally needs `--infer-goals` for a checked arithmetic
packing lemma. No authored assertions, loop invariants, assumed specifications,
external bodies, or implementation exclusions were added.

Use the matching local Verus Infer engine (policy 51 / candidate cache 57), built
with proof toolchain Rust 1.99.1. From its repository root:

```sh
python3 source/tools/check_hex_adoption.py \
  --native-root /Users/tommyvolk/Documents/GitHub/hex-conservative \
  --output /private/tmp/hex-acceptance-new
```

The default controller temporarily mutates this checkout, restores each file in
a `finally` block, checks six semantic failures and publication controls, then
runs fresh restored proofs and ordinary native tests. Use `--positive-only` to
skip mutations and negative controls. The output directory must be new. Cargo
uses the ignored `Cargo.lock` copied from upstream's `Cargo-recent.lock`; no
tracked lockfile or toolchain selection is changed. Verification invokes Verus
directly on this crate's actual `src/lib.rs` with `std` and `alloc` enabled; it
does not use a replacement proof crate or a source extractor.

The selected endpoint accepts two arbitrary `u8` inputs, including non-ASCII
bytes, returns one exact byte on success and preserves the offending input byte
and high/low flag on error, with the high byte winning when both are invalid.
This does not certify the complete public string API or iterator.

The inspected next boundary includes `ChunksExact`, iterator state/byte
positions, saturating arithmetic, error conversions, and the original unsafe
pointer-writing drains. They remain unverified in this milestone. Native tests
exercise public API lengths, mixed case and UTF-8 byte errors, but tests are not
proofs of those endpoints. Public APIs count UTF-8 **bytes**, not Unicode scalar
values. A mathematical fixed-array length theorem must account for the native
`2 * N` overflow domain (`N <= usize::MAX / 2` for checked arithmetic). Length
rejection precedes character rejection. No ASCII-only restriction is assumed.

The engine's `evidence/verus-infer-hex-v1` contains the frozen charter, source
inventory, raw replay logs, mutation/publication outcomes and artifact hashes.
Aleph v3/v4 fixtures, archives and fixed engines were left unchanged. This is a
finite independent adoption result, not blanket certification of Rust code.

## Forward string iterator milestone (v2)

The live checkout additionally selects the actual length-checking internal string
constructor used by `decode_to_vec`, `HexDigitsIter` over real `ChunksExact(2)`,
and generic `HexToBytesIter::next/nth`. Six new connected application goals
prove arbitrary Rust string construction, arbitrary forward-history steps,
byte values, original-byte error payload/location and high-byte priority,
remaining pair counts, skipping, exhaustion and saturation. The v1 pair goal
and its three exact inference certificates remain required. Input is UTF-8
bytes with no ASCII restriction. `nth` may skip invalid pairs; out-of-range
`nth` empties the source but leaves the native cursor unchanged.

Use policy 52 / candidate cache 58 and the matching Rust 1.99.1 compiler/vstd:

```sh
python3 source/tools/check_hex_iterator.py \
  --native-root /Users/tommyvolk/Documents/GitHub/hex-conservative \
  --output /private/tmp/hex-iterator-acceptance-new
```

Additional source is required contracts, closed observations, a checked
HexDigits structural type invariant, trait spec implementations and semantic
goals/tests. The production bodies and original derives remain intact. General
assistance proposes callback contracts and uses the existing checked
use_type_invariant operator; original closure bodies and borrow restoration
still verify. New trusted **standard-library** models cover immutable
ChunksExact state, slice-to-array conversion and concrete no-unwind std
refinements. No first-party assumed contracts, external bodies or blanket
exclusions were added. The public `HexSliceToBytesIter` forwarding wrapper is
natively tested but not selected for proof. Logical remaining pair length and
HexDigits' concrete size_hint are proved; the generic runtime size_hint/len
exactness is not part of this proof.

The actual unsafe vector/slice drains and public decode endpoints are not
certified by this iterator result. Their allocation, raw pointer initialization
and set_len obligations require a separate memory phase. Fixed arrays retain
the `2*N` overflow issue noted above. Evidence lives in the matching engine's
`evidence/verus-infer-hex-v2`; immutable v1 source remains in its commit/archive.

## Original vector-memory phase (opt-in, unaccepted)

The live source also carries independent whole-vector and drain requirements in
closed spec functions beside the native endpoints, plus selection of the actual public `decode_to_vec`, its
two error conversions and unchanged `drain_to_vec` body. Enable these only with
`--cfg verus_hex_vec_phase3` in a Verus invocation. The proof-only
proc_macro_hygiene feature supports rewriting the original native for loop;
Cargo check-cfg additionally recognizes only this proof flag; normal feature
defaults and algorithms are unchanged.

This phase currently **fails closed**: Vec::as_mut_ptr, core::ptr::write,
raw-pointer add and Vec::set_len are unsupported. No vector endpoint theorem or
memory-safety result is claimed. The model must connect capacity/allocation,
pointer provenance, write permissions and initialized-prefix ownership, prove
allocation length from the actual runtime iterator hint, and account for early
errors leaving Vec length zero. Existing tracked pointer wrappers require
permissions that this original path does not carry. Neither an assumed drain
contract nor a safe replacement is used. The ordinary iterator proof remains
the accepted v2 scope when the opt-in flag is absent.

The matching engine's `source/tools/check_hex_vec_phase3.py` records the four
unsupported-operation diagnostics and absence of publication, then runs restored
iterator proofs and native feature/MSRV tests. See
`evidence/verus-infer-hex-vec-phase3` for the finite phase charter and blocker.
