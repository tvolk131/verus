// SPDX-License-Identifier: CC0-1.0

//! Iterator that converts hex to bytes.

#[cfg(verus_keep_ghost)]
use vstd::prelude::*;

use core::borrow::Borrow;
use core::convert::TryInto;
use core::iter::FusedIterator;
use core::str;
#[cfg(feature = "std")]
use std::io;

#[cfg(feature = "alloc")]
use crate::alloc::vec::Vec;
use crate::error::{InvalidCharError, OddLengthStringError};
use crate::{Case, Char, Table};

/// Iterator over bytes decoded from a hex string slice.
///
/// This is an iterator type returned when decoding a `&str` of hex digits. Each pair of hex
/// characters is decoded into one byte.
///
/// Use [`HexToBytesIter`] if you need an iterator that is generic over the source of hex digit
/// pairs.
#[derive(Debug, Clone)]
#[cfg_attr(verus_keep_ghost, verus_verify)]
pub struct HexSliceToBytesIter<'a>(HexToBytesIter<HexDigitsIter<'a>>);

impl<'a> HexSliceToBytesIter<'a> {
    /// Constructs a new [`HexSliceToBytesIter`] from a string slice.
    ///
    /// # Errors
    ///
    /// If the input string is of odd length.
    ///
    /// # Examples
    ///
    /// ```
    /// # #[cfg(feature = "std")] {
    /// # use hex_conservative::HexSliceToBytesIter;
    /// # fn main() -> Result<(), Box<dyn std::error::Error>> {
    /// let bytes: Vec<u8> = HexSliceToBytesIter::new("deadbeef")?
    ///     .collect::<Result<_, _>>()?;
    /// assert_eq!(bytes, [0xde, 0xad, 0xbe, 0xef]);
    /// # Ok(())
    /// # }
    /// # }
    /// ```
    #[inline]
    pub fn new(s: &'a str) -> Result<Self, OddLengthStringError> {
        HexToBytesIter::new(s).map(Self)
    }
}

impl Iterator for HexSliceToBytesIter<'_> {
    type Item = Result<u8, InvalidCharError>;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> { self.0.next() }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) { self.0.size_hint() }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<Self::Item> { self.0.nth(n) }
}

impl DoubleEndedIterator for HexSliceToBytesIter<'_> {
    #[inline]
    fn next_back(&mut self) -> Option<Self::Item> { self.0.next_back() }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> { self.0.nth_back(n) }
}

impl ExactSizeIterator for HexSliceToBytesIter<'_> {}

impl FusedIterator for HexSliceToBytesIter<'_> {}

#[cfg(feature = "std")]
impl io::Read for HexSliceToBytesIter<'_> {
    #[inline]
    fn read(&mut self, buf: &mut [u8]) -> io::Result<usize> { self.0.read(buf) }
}

/// Iterator yielding bytes decoded from an iterator of pairs of hex digits.
///
/// This type is intentionally low-level. It operates on an iterator of character pairs, each
/// represented as a `[u8; 2]`. If you already have a `&str`, use [`HexSliceToBytesIter`] instead.
///
/// This iterator is not fused unless the underlying iterator is. If the underlying iterator does
/// not implement the [`FusedIterator`](core::iter::FusedIterator) trait, once
/// [`HexToBytesIter::next`] returns `None`, further calls may panic or otherwise behave
/// arbitrarily, regardless of what the underlying iterator is documented to do.
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
#[cfg_attr(verus_keep_ghost, verus_verify)]
pub struct HexToBytesIter<I>
where
    I: Iterator<Item = [u8; 2]>,
{
    iter: I,
    /// Number of (high, low) char pairs consumed from the front.
    front_pos: usize,
}

#[cfg_attr(verus_keep_ghost, verus_verify)]
impl<'a> HexToBytesIter<HexDigitsIter<'a>> {
    /// Constructs a new `HexToBytesIter` from a string slice.
    ///
    /// # Errors
    ///
    /// If the input string is of odd length.
    #[inline]
    #[cfg_attr(verus_keep_ghost, verus_spec(r => ensures s.spec_bytes().len()<=usize::MAX, r.is_ok() <==> s.spec_bytes().len()%2==0, r.is_err() ==> r->Err_0.len==s.spec_bytes().len(), r.is_ok() ==> r->Ok_0.cursor()==0 && r->Ok_0.input_pairs().len()==s.spec_bytes().len()/2, r.is_ok() ==> forall|i:int| 0<=i<r->Ok_0.input_pairs().len() ==> r->Ok_0.input_pairs()[i]@ == s.spec_bytes().subrange(2*i,2*i+2)))]
    pub(crate) fn new(s: &'a str) -> Result<Self, OddLengthStringError> {
        if s.len() % 2 != 0 {
            Err(OddLengthStringError { len: s.len() })
        } else {
            Ok(Self::new_unchecked(s))
        }
    }

    #[inline]
    #[cfg_attr(verus_keep_ghost, verus_spec(r => ensures r.cursor()==0, r.input_pairs().len()==s.spec_bytes().len()/2, forall|i:int| 0<=i<r.input_pairs().len() ==> r.input_pairs()[i]@ == s.spec_bytes().subrange(2*i,2*i+2)))]
    pub(crate) fn new_unchecked(s: &'a str) -> Self {
        Self::from_pairs(HexDigitsIter::new_unchecked(s.as_bytes()))
    }

}

impl<'a> HexToBytesIter<HexDigitsIter<'a>> {
    /// Writes all the bytes yielded by this `HexToBytesIter` to the provided slice.
    ///
    /// Stops writing if this `HexToBytesIter` yields an `InvalidCharError`.
    ///
    /// # Panics
    ///
    /// Panics if the length of this `HexToBytesIter` is not equal to the length of the provided
    /// slice.
    pub(crate) fn drain_to_slice(self, buf: &mut [u8]) -> Result<(), InvalidCharError> {
        assert_eq!(self.len(), buf.len());
        let mut ptr = buf.as_mut_ptr();
        for byte in self {
            // SAFETY: for loop iterates `len` times, and `buf` has length `len`
            unsafe {
                core::ptr::write(ptr, byte?);
                ptr = ptr.add(1);
            }
        }
        Ok(())
    }

    /// Writes all the bytes yielded by this `HexToBytesIter` to a `Vec<u8>`.
    ///
    /// This is equivalent to the combinator chain `iter().map().collect()` but was found by
    /// benchmarking to be faster.
    #[cfg(feature = "alloc")]
    #[cfg_attr(all(verus_keep_ghost, verus_hex_vec_phase3), verus_verify)]
    #[cfg_attr(all(verus_keep_ghost, verus_hex_vec_phase3), verus_spec(r => ensures required_vector_drain_result(self.input_pairs(), self.cursor() as int, r)))]
    pub(crate) fn drain_to_vec(self) -> Result<Vec<u8>, InvalidCharError> {
        let len = self.len();
        let mut ret = Vec::with_capacity(len);
        let mut ptr = ret.as_mut_ptr();
        for byte in self {
            // SAFETY: for loop iterates `len` times, and `ret` has a capacity of at least `len`
            unsafe {
                // docs: "`core::ptr::write` is appropriate for initializing uninitialized memory"
                core::ptr::write(ptr, byte?);
                ptr = ptr.add(1);
            }
        }
        // SAFETY: `len` elements have been initialized, and `ret` has a capacity of at least `len`
        unsafe {
            ret.set_len(len);
        }
        Ok(ret)
    }
}

#[cfg_attr(verus_keep_ghost, verus_verify)]
impl<I> HexToBytesIter<I>
where
    I: Iterator<Item = [u8; 2]> + ExactSizeIterator,
{
    /// Constructs a custom hex decoding iterator from another iterator.
    ///
    /// # Examples
    ///
    /// ```
    /// # #[cfg(feature = "std")] {
    /// # use hex_conservative::HexToBytesIter;
    /// # fn main() -> Result<(), Box<dyn std::error::Error>> {
    /// let hex_digits: Vec<u8> = b"deadbeef".iter().copied().collect();
    /// let pairs = hex_digits.chunks_exact(2).map(|c| [c[0], c[1]]);
    /// let decoded: Vec<u8> = HexToBytesIter::from_pairs(pairs)
    ///     .collect::<Result<_, _>>()?;
    /// assert_eq!(decoded, [0xde, 0xad, 0xbe, 0xef]);
    /// # Ok(())
    /// # }
    /// # }
    /// ```
    #[inline]
    #[cfg_attr(verus_keep_ghost, verus_spec(r => ensures r.cursor()==0, r.source()==iter))]
    pub fn from_pairs(iter: I) -> Self { Self { front_pos: 0, iter } }
}

#[cfg_attr(verus_keep_ghost, verus_verify)]
impl<I> Iterator for HexToBytesIter<I>
where
    I: Iterator<Item = [u8; 2]> + ExactSizeIterator,
{
    type Item = Result<u8, InvalidCharError>;

    #[inline]
    #[cfg_attr(verus_keep_ghost, verus_spec(r => ensures old(self).source().obeys_prophetic_iter_laws() ==> final(self).source().remaining()==if 0usize<old(self).source().remaining().len() {old(self).source().remaining().subrange(0usize as int+1,old(self).source().remaining().len() as int)} else {Seq::empty()}, old(self).source().obeys_prophetic_iter_laws() ==> r==if 0usize<old(self).source().remaining().len() {Some(decoded(old(self).source().remaining()[0usize as int],old(self).cursor() as int+0usize as int))} else {None}, final(self).cursor()==if r.is_some() {sat(old(self).cursor() as int+1)} else {old(self).cursor()}))]
    fn next(&mut self) -> Option<Self::Item> { self.nth(0) }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) { self.iter.size_hint() }

    #[inline]
    #[cfg_attr(verus_keep_ghost, verus_spec(r => ensures old(self).source().obeys_prophetic_iter_laws() ==> final(self).source().remaining()==if n<old(self).source().remaining().len() {old(self).source().remaining().subrange(n as int+1,old(self).source().remaining().len() as int)} else {Seq::empty()}, old(self).source().obeys_prophetic_iter_laws() ==> r==if n<old(self).source().remaining().len() {Some(decoded(old(self).source().remaining()[n as int],old(self).cursor() as int+n as int))} else {None}, final(self).cursor()==if r.is_some() {sat(old(self).cursor() as int+n as int+1)} else {old(self).cursor()}))]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        let [hi, lo] = self.iter.nth(n)?;
        let pos = self.front_pos.saturating_add(n).saturating_mul(2);
        self.front_pos = self.front_pos.saturating_add(n).saturating_add(1);
        Some(hex_chars_to_byte(hi, lo).map_err(|(c, is_high)| InvalidCharError {
            invalid: c,
            pos: if is_high { pos } else { pos.saturating_add(1) },
        }))
    }
}

impl<I> DoubleEndedIterator for HexToBytesIter<I>
where
    I: Iterator<Item = [u8; 2]> + DoubleEndedIterator + ExactSizeIterator,
{
    #[inline]
    fn next_back(&mut self) -> Option<Self::Item> { self.nth_back(0) }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        let [hi, lo] = self.iter.nth_back(n)?;
        let pos = (self.front_pos + self.iter.len()).saturating_mul(2);
        Some(hex_chars_to_byte(hi, lo).map_err(|(c, is_high)| InvalidCharError {
            invalid: c,
            pos: if is_high { pos } else { pos.saturating_add(1) },
        }))
    }
}

#[cfg_attr(verus_keep_ghost, verus_verify)]
impl<I> ExactSizeIterator for HexToBytesIter<I> where I: Iterator<Item = [u8; 2]> + ExactSizeIterator
{}

impl<I> FusedIterator for HexToBytesIter<I> where
    I: Iterator<Item = [u8; 2]> + ExactSizeIterator + FusedIterator
{
}

#[cfg(feature = "std")]
impl<I> io::Read for HexToBytesIter<I>
where
    I: Iterator<Item = [u8; 2]> + ExactSizeIterator + FusedIterator,
{
    #[inline]
    fn read(&mut self, buf: &mut [u8]) -> io::Result<usize> {
        let mut bytes_read = 0usize;
        for dst in buf {
            match self.next() {
                Some(Ok(src)) => {
                    *dst = src;
                    bytes_read += 1;
                }
                Some(Err(e)) => return Err(io::Error::new(io::ErrorKind::InvalidData, e)),
                None => break,
            }
        }
        Ok(bytes_read)
    }
}

/// An internal iterator returning hex digits from a string.
///
/// Generally you shouldn't need to refer to this or bother with it and just use
/// [`HexToBytesIter::new`] consuming the returned value and use `HexSliceToBytesIter` if you need
/// to refer to the iterator in your types.
#[derive(Debug, Clone)]
#[cfg_attr(verus_keep_ghost, verus_verify)]
pub struct HexDigitsIter<'a> {
    // Invariant: the length of the chunks is 2.
    // Technically, this is `iter::Map` but we can't use it because fn is anonymous.
    // We can swap this for actual `ArrayChunks` once it's stable.
    iter: core::slice::ChunksExact<'a, u8>,
}

#[cfg_attr(verus_keep_ghost, verus_verify)]
impl<'a> HexDigitsIter<'a> {
    #[inline]
    #[cfg_attr(verus_keep_ghost, verus_spec(r => ensures r.pairs().len()==digits@.len()/2, forall|i:int| 0<=i<r.pairs().len() ==> r.pairs()[i]@ == digits@.subrange(2*i,2*i+2)))]
    fn new_unchecked(digits: &'a [u8]) -> Self { Self { iter: digits.chunks_exact(2) } }
}

#[cfg_attr(verus_keep_ghost, verus_verify)]
impl Iterator for HexDigitsIter<'_> {
    type Item = [u8; 2];

    #[inline]
    #[cfg_attr(verus_keep_ghost, verus_spec(r => ensures r==if old(self).pairs().len()>0 {Some(old(self).pairs()[0])} else {None}, final(self).pairs()==if old(self).pairs().len()>0 {old(self).pairs().drop_first()} else {Seq::empty()}))]
    fn next(&mut self) -> Option<Self::Item> {
        self.iter.next().map(|digits| digits.try_into().expect("HexDigitsIter invariant"))
    }

    #[inline]
    #[cfg_attr(verus_keep_ghost, verus_spec(r => ensures r==(self.pairs().len() as usize,Some(self.pairs().len() as usize))))]
    fn size_hint(&self) -> (usize, Option<usize>) { self.iter.size_hint() }

    #[inline]
    #[cfg_attr(verus_keep_ghost, verus_spec(r => ensures r==if n<old(self).pairs().len() {Some(old(self).pairs()[n as int])} else {None}, final(self).pairs()==if n<old(self).pairs().len() {old(self).pairs().subrange(n as int+1,old(self).pairs().len() as int)} else {Seq::empty()}))]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.iter.nth(n).map(|digits| digits.try_into().expect("HexDigitsIter invariant"))
    }
}

impl DoubleEndedIterator for HexDigitsIter<'_> {
    #[inline]
    fn next_back(&mut self) -> Option<Self::Item> {
        self.iter.next_back().map(|digits| digits.try_into().expect("HexDigitsIter invariant"))
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.iter.nth_back(n).map(|digits| digits.try_into().expect("HexDigitsIter invariant"))
    }
}

#[cfg_attr(verus_keep_ghost, verus_verify)]
impl ExactSizeIterator for HexDigitsIter<'_> {}

impl core::iter::FusedIterator for HexDigitsIter<'_> {}

/// `hi` and `lo` are bytes representing hex characters.
///
/// Returns the valid byte or the invalid input byte and a bool indicating error for `hi` or `lo`.
#[cfg_attr(verus_keep_ghost, verus_infer)]
fn hex_chars_to_byte(hi: u8, lo: u8) -> Result<u8, (u8, bool)> {
    let hih = Char::decode_nibble(hi).ok_or((hi, true))?;
    let loh = Char::decode_nibble(lo).ok_or((lo, false))?;
    Ok((hih << 4) | loh)
}

/// Iterator over bytes which encodes the bytes and yields `[Char; 2]` pairs of hex characters.
///
/// Each call to [`Iterator::next`] consumes one byte and returns the two hex digits that encode
/// it as `[high_nibble, low_nibble]`.
///
/// If you want to yield a stream of [`Char`] only, call [`flatten`].
///
/// # Examples
///
/// ```
/// # #[cfg(feature = "alloc")]
/// # {
/// use hex_conservative::{BytesToHexIter, Case};
///
/// let bytes = [0xde, 0xad, 0xbe, 0xef].into_iter();
/// let hex_string: String =
///     BytesToHexIter::new(bytes, Case::Lower).flatten().map(char::from).collect();
/// assert_eq!(hex_string, "deadbeef");
/// # }
///```
///
/// [`flatten`]: Iterator::flatten
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub struct BytesToHexIter<I>
where
    I: Iterator,
    I::Item: Borrow<u8>,
{
    /// The iterator whose next byte will be encoded to yield hex characters.
    iter: I,
    /// The byte-to-hex conversion table.
    table: &'static Table,
}

impl<I> BytesToHexIter<I>
where
    I: Iterator,
    I::Item: Borrow<u8>,
{
    /// Constructs a `BytesToHexIter` that will yield hex character pairs in the given case from a
    /// byte iterator.
    pub fn new(iter: I, case: Case) -> BytesToHexIter<I> { Self { iter, table: case.table() } }
}

impl<I> Iterator for BytesToHexIter<I>
where
    I: Iterator,
    I::Item: Borrow<u8>,
{
    type Item = [Char; 2];

    #[inline]
    fn next(&mut self) -> Option<[Char; 2]> {
        self.iter.next().map(|b| self.table.byte_to_hex_chars(*b.borrow()))
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) { self.iter.size_hint() }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<[Char; 2]> {
        self.iter.nth(n).map(|b| self.table.byte_to_hex_chars(*b.borrow()))
    }
}

impl<I> DoubleEndedIterator for BytesToHexIter<I>
where
    I: DoubleEndedIterator,
    I::Item: Borrow<u8>,
{
    #[inline]
    fn next_back(&mut self) -> Option<[Char; 2]> {
        self.iter.next_back().map(|b| self.table.byte_to_hex_chars(*b.borrow()))
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<[Char; 2]> {
        self.iter.nth_back(n).map(|b| self.table.byte_to_hex_chars(*b.borrow()))
    }
}

impl<I> ExactSizeIterator for BytesToHexIter<I>
where
    I: ExactSizeIterator,
    I::Item: Borrow<u8>,
{
    #[inline]
    fn len(&self) -> usize { self.iter.len() }
}

impl<I> FusedIterator for BytesToHexIter<I>
where
    I: FusedIterator,
    I::Item: Borrow<u8>,
{
}

#[cfg(test)]
mod tests {
    #[cfg(feature = "alloc")]
    use alloc::string::String;

    use super::*;

    fn nth_slow<I: Iterator>(iter: &mut I, n: usize) -> Option<I::Item> {
        for _ in 0..n {
            iter.next()?;
        }
        iter.next()
    }

    fn nth_back_slow<I: DoubleEndedIterator>(iter: &mut I, n: usize) -> Option<I::Item> {
        for _ in 0..n {
            iter.next_back()?;
        }
        iter.next_back()
    }

    #[test]
    fn encode_byte() {
        assert_eq!(Table::LOWER.byte_to_chars(0x00), ['0', '0']);
        assert_eq!(Table::LOWER.byte_to_chars(0x0a), ['0', 'a']);
        assert_eq!(Table::LOWER.byte_to_chars(0xad), ['a', 'd']);
        assert_eq!(Table::LOWER.byte_to_chars(0xff), ['f', 'f']);

        assert_eq!(Table::UPPER.byte_to_chars(0x00), ['0', '0']);
        assert_eq!(Table::UPPER.byte_to_chars(0x0a), ['0', 'A']);
        assert_eq!(Table::UPPER.byte_to_chars(0xad), ['A', 'D']);
        assert_eq!(Table::UPPER.byte_to_chars(0xff), ['F', 'F']);

        let mut buf = [0u8; 2];
        assert_eq!(Table::LOWER.byte_to_str(&mut buf, 0x00), "00");
        assert_eq!(Table::LOWER.byte_to_str(&mut buf, 0x0a), "0a");
        assert_eq!(Table::LOWER.byte_to_str(&mut buf, 0xad), "ad");
        assert_eq!(Table::LOWER.byte_to_str(&mut buf, 0xff), "ff");

        assert_eq!(Table::UPPER.byte_to_str(&mut buf, 0x00), "00");
        assert_eq!(Table::UPPER.byte_to_str(&mut buf, 0x0a), "0A");
        assert_eq!(Table::UPPER.byte_to_str(&mut buf, 0xad), "AD");
        assert_eq!(Table::UPPER.byte_to_str(&mut buf, 0xff), "FF");
    }

    #[test]
    fn decode_iter_forward() {
        let hex = "deadbeef";
        let bytes = [0xde, 0xad, 0xbe, 0xef];

        for (i, b) in HexToBytesIter::new(hex).unwrap().enumerate() {
            assert_eq!(b.unwrap(), bytes[i]);
        }

        let mut iter = HexToBytesIter::new(hex).unwrap();
        for i in (0..=bytes.len()).rev() {
            assert_eq!(iter.len(), i);
            let _ = iter.next();
        }
    }

    #[test]
    fn decode_iter_backward() {
        let hex = "deadbeef";
        let bytes = [0xef, 0xbe, 0xad, 0xde];

        for (i, b) in HexToBytesIter::new(hex).unwrap().rev().enumerate() {
            assert_eq!(b.unwrap(), bytes[i]);
        }

        let mut iter = HexToBytesIter::new(hex).unwrap().rev();
        for i in (0..=bytes.len()).rev() {
            assert_eq!(iter.len(), i);
            let _ = iter.next();
        }
    }

    #[test]
    fn hex_to_digits_size_hint() {
        let hex = "deadbeef";
        let iter = HexDigitsIter::new_unchecked(hex.as_bytes());
        // HexDigitsIter yields two digits at a time `[u8; 2]`.
        assert_eq!(iter.size_hint(), (4, Some(4)));
    }

    #[test]
    fn hex_to_bytes_size_hint() {
        let hex = "deadbeef";
        let iter = HexToBytesIter::new_unchecked(hex);
        assert_eq!(iter.size_hint(), (4, Some(4)));
    }

    #[test]
    fn hex_to_bytes_slice_drain() {
        let hex = "deadbeef";
        let want = [0xde, 0xad, 0xbe, 0xef];
        let iter = HexToBytesIter::new_unchecked(hex);
        let mut got = [0u8; 4];
        iter.drain_to_slice(&mut got).unwrap();
        assert_eq!(got, want);

        let hex = "";
        let want: [u8; 0] = [];
        let iter = HexToBytesIter::new_unchecked(hex);
        let mut got = [];
        iter.drain_to_slice(&mut got).unwrap();
        assert_eq!(got, want);
    }

    #[test]
    #[should_panic]
    // Don't test panic message because it is from `debug_assert`.
    #[allow(clippy::should_panic_without_expect)]
    fn hex_to_bytes_slice_drain_panic_empty() {
        let hex = "deadbeef";
        let iter = HexToBytesIter::new_unchecked(hex);
        let mut got = [];
        iter.drain_to_slice(&mut got).unwrap();
    }

    #[test]
    #[should_panic]
    // Don't test panic message because it is from `debug_assert`.
    #[allow(clippy::should_panic_without_expect)]
    fn hex_to_bytes_slice_drain_panic_too_small() {
        let hex = "deadbeef";
        let iter = HexToBytesIter::new_unchecked(hex);
        let mut got = [0u8; 3];
        iter.drain_to_slice(&mut got).unwrap();
    }

    #[test]
    #[should_panic]
    // Don't test panic message because it is from `debug_assert`.
    #[allow(clippy::should_panic_without_expect)]
    fn hex_to_bytes_slice_drain_panic_too_big() {
        let hex = "deadbeef";
        let iter = HexToBytesIter::new_unchecked(hex);
        let mut got = [0u8; 5];
        iter.drain_to_slice(&mut got).unwrap();
    }

    #[test]
    fn hex_to_bytes_slice_drain_first_char_error() {
        let hex = "geadbeef";
        let iter = HexToBytesIter::new_unchecked(hex);
        let mut got = [0u8; 4];
        assert_eq!(
            iter.drain_to_slice(&mut got).unwrap_err(),
            InvalidCharError { invalid: b'g', pos: 0 }
        );
    }

    #[test]
    fn hex_to_bytes_slice_drain_middle_char_error() {
        let hex = "deadgeef";
        let iter = HexToBytesIter::new_unchecked(hex);
        let mut got = [0u8; 4];
        assert_eq!(
            iter.drain_to_slice(&mut got).unwrap_err(),
            InvalidCharError { invalid: b'g', pos: 4 }
        );
    }

    #[test]
    fn hex_to_bytes_slice_drain_end_char_error() {
        let hex = "deadbeeg";
        let iter = HexToBytesIter::new_unchecked(hex);
        let mut got = [0u8; 4];
        assert_eq!(
            iter.drain_to_slice(&mut got).unwrap_err(),
            InvalidCharError { invalid: b'g', pos: 7 }
        );
    }

    #[cfg(feature = "alloc")]
    #[test]
    fn hex_to_bytes_vec_drain() {
        let hex = "deadbeef";
        let want = [0xde, 0xad, 0xbe, 0xef];
        let iter = HexToBytesIter::new_unchecked(hex);
        let got = iter.drain_to_vec().unwrap();
        assert_eq!(got, want);

        let hex = "";
        let iter = HexToBytesIter::new_unchecked(hex);
        let got = iter.drain_to_vec().unwrap();
        assert!(got.is_empty());
    }

    #[cfg(feature = "alloc")]
    #[test]
    fn hex_to_bytes_vec_drain_first_char_error() {
        let hex = "geadbeef";
        let iter = HexToBytesIter::new_unchecked(hex);
        assert_eq!(iter.drain_to_vec().unwrap_err(), InvalidCharError { invalid: b'g', pos: 0 });
    }

    #[cfg(feature = "alloc")]
    #[test]
    fn hex_to_bytes_vec_drain_middle_char_error() {
        let hex = "deadgeef";
        let iter = HexToBytesIter::new_unchecked(hex);
        assert_eq!(iter.drain_to_vec().unwrap_err(), InvalidCharError { invalid: b'g', pos: 4 });
    }

    #[cfg(feature = "alloc")]
    #[test]
    fn hex_to_bytes_vec_drain_end_char_error() {
        let hex = "deadbeeg";
        let iter = HexToBytesIter::new_unchecked(hex);
        assert_eq!(iter.drain_to_vec().unwrap_err(), InvalidCharError { invalid: b'g', pos: 7 });
    }

    #[test]
    fn decode_error_pos_after_next_back() {
        let mut iter = HexToBytesIter::new("geadbeef").unwrap();
        iter.next_back().unwrap().unwrap();
        assert_eq!(iter.next().unwrap().unwrap_err(), InvalidCharError { invalid: b'g', pos: 0 },);
    }

    #[test]
    fn decode_error_pos_after_next() {
        let mut iter = HexToBytesIter::new("deadbeGf").unwrap();
        iter.next().unwrap().unwrap();
        assert_eq!(
            iter.next_back().unwrap().unwrap_err(),
            InvalidCharError { invalid: b'G', pos: 6 },
        );
    }

    #[cfg(feature = "alloc")]
    #[test]
    fn encode_iter() {
        let bytes = [0xde, 0xad, 0xbe, 0xef];
        let lower_want = "deadbeef";
        let upper_want = "DEADBEEF";

        let lower_got: String =
            BytesToHexIter::new(bytes.iter(), Case::Lower).flatten().map(char::from).collect();
        assert_eq!(lower_got, lower_want);
        let upper_got: String =
            BytesToHexIter::new(bytes.iter(), Case::Upper).flatten().map(char::from).collect();
        assert_eq!(upper_got, upper_want);
    }

    #[cfg(feature = "alloc")]
    #[test]
    fn encode_iter_backwards() {
        let bytes = [0xde, 0xad, 0xbe, 0xef];
        // .rev().flatten() yields pairs in reverse byte order but each pair remains [high, low].
        let lower_want = "efbeadde";
        let upper_want = "EFBEADDE";

        let lower_got: String = BytesToHexIter::new(bytes.iter(), Case::Lower)
            .rev()
            .flatten()
            .map(char::from)
            .collect();
        assert_eq!(lower_got, lower_want);
        let upper_got: String = BytesToHexIter::new(bytes.iter(), Case::Upper)
            .rev()
            .flatten()
            .map(char::from)
            .collect();
        assert_eq!(upper_got, upper_want);

        // .flatten().rev() yields pairs in reverse byte order and each pair becomes [low, high].
        let lower_want = "feebdaed";
        let upper_want = "FEEBDAED";

        let lower_got: String = BytesToHexIter::new(bytes.iter(), Case::Lower)
            .flatten()
            .rev()
            .map(char::from)
            .collect();
        assert_eq!(lower_got, lower_want);
        let upper_got: String = BytesToHexIter::new(bytes.iter(), Case::Upper)
            .flatten()
            .rev()
            .map(char::from)
            .collect();
        assert_eq!(upper_got, upper_want);
    }

    #[test]
    fn encode_iter_nth() {
        let bytes = [0xde, 0xad, 0xbe, 0xef];

        for n in 0..=bytes.len() + 1 {
            let mut got = BytesToHexIter::new(bytes.iter(), Case::Lower);
            let mut want = BytesToHexIter::new(bytes.iter(), Case::Lower);

            assert_eq!(got.nth(n), nth_slow(&mut want, n));
            assert_eq!(got.len(), want.len());
            assert!(got.eq(want));
        }
    }

    #[test]
    fn encode_iter_nth_after_next_back() {
        let bytes = [0xde, 0xad, 0xbe, 0xef];

        for n in 0..=bytes.len() {
            let mut got = BytesToHexIter::new(bytes.iter(), Case::Lower);
            let mut want = BytesToHexIter::new(bytes.iter(), Case::Lower);

            assert_eq!(got.next_back(), want.next_back());
            assert_eq!(got.nth(n), nth_slow(&mut want, n));
            assert_eq!(got.len(), want.len());
            assert!(got.eq(want));
        }
    }

    #[test]
    fn encode_iter_nth_after_next() {
        let bytes = [0xde, 0xad, 0xbe, 0xef];

        for n in 0..=bytes.len() {
            let mut got = BytesToHexIter::new(bytes.iter(), Case::Lower);
            let mut want = BytesToHexIter::new(bytes.iter(), Case::Lower);

            assert_eq!(got.next(), want.next());
            assert_eq!(got.nth(n), nth_slow(&mut want, n));
            assert_eq!(got.len(), want.len());
            assert!(got.eq(want));
        }
    }

    #[test]
    fn encode_iter_nth_back() {
        let bytes = [0xde, 0xad, 0xbe, 0xef];

        for n in 0..=bytes.len() + 1 {
            let mut got = BytesToHexIter::new(bytes.iter(), Case::Lower);
            let mut want = BytesToHexIter::new(bytes.iter(), Case::Lower);

            assert_eq!(got.nth_back(n), nth_back_slow(&mut want, n));
            assert_eq!(got.len(), want.len());
            assert!(got.eq(want));
        }
    }

    #[test]
    fn encode_iter_nth_back_after_next() {
        let bytes = [0xde, 0xad, 0xbe, 0xef];

        for n in 0..=bytes.len() {
            let mut got = BytesToHexIter::new(bytes.iter(), Case::Lower);
            let mut want = BytesToHexIter::new(bytes.iter(), Case::Lower);

            assert_eq!(got.next(), want.next());
            assert_eq!(got.nth_back(n), nth_back_slow(&mut want, n));
            assert_eq!(got.len(), want.len());
            assert!(got.eq(want));
        }
    }

    #[test]
    fn encode_iter_nth_back_after_next_back() {
        let bytes = [0xde, 0xad, 0xbe, 0xef];

        for n in 0..=bytes.len() {
            let mut got = BytesToHexIter::new(bytes.iter(), Case::Lower);
            let mut want = BytesToHexIter::new(bytes.iter(), Case::Lower);

            assert_eq!(got.next_back(), want.next_back());
            assert_eq!(got.nth_back(n), nth_back_slow(&mut want, n));
            assert_eq!(got.len(), want.len());
            assert!(got.eq(want));
        }
    }

    #[cfg(feature = "alloc")]
    #[test]
    fn roundtrip_forward() {
        let lower_want = "deadbeefcafebabe";
        let upper_want = "DEADBEEFCAFEBABE";
        let lower_bytes_iter = HexToBytesIter::new(lower_want).unwrap().map(|res| res.unwrap());
        let lower_got: String =
            BytesToHexIter::new(lower_bytes_iter, Case::Lower).flatten().map(char::from).collect();
        assert_eq!(lower_got, lower_want);
        let upper_bytes_iter = HexToBytesIter::new(upper_want).unwrap().map(|res| res.unwrap());
        let upper_got: String =
            BytesToHexIter::new(upper_bytes_iter, Case::Upper).flatten().map(char::from).collect();
        assert_eq!(upper_got, upper_want);
    }

    #[cfg(feature = "alloc")]
    #[test]
    fn roundtrip_backward() {
        let lower_want = "deadbeefcafebabe";
        let upper_want = "DEADBEEFCAFEBABE";
        let lower_bytes_iter =
            HexToBytesIter::new(lower_want).unwrap().rev().map(|res| res.unwrap());
        let lower_got: String = BytesToHexIter::new(lower_bytes_iter, Case::Lower)
            .rev()
            .flatten()
            .map(char::from)
            .collect();
        assert_eq!(lower_got, lower_want);
        let upper_bytes_iter =
            HexToBytesIter::new(upper_want).unwrap().rev().map(|res| res.unwrap());
        let upper_got: String = BytesToHexIter::new(upper_bytes_iter, Case::Upper)
            .rev()
            .flatten()
            .map(char::from)
            .collect();
        assert_eq!(upper_got, upper_want);
    }

    #[test]
    #[cfg(feature = "std")]
    fn hex_to_bytes_iter_read() {
        use std::io::Read;

        let hex = "deadbeef";
        let mut iter = HexToBytesIter::new(hex).unwrap();
        let mut buf = [0u8; 4];
        let bytes_read = iter.read(&mut buf).unwrap();
        assert_eq!(bytes_read, 4);
        assert_eq!(buf, [0xde, 0xad, 0xbe, 0xef]);

        let hex = "deadbeef";
        let mut iter = HexToBytesIter::new(hex).unwrap();
        let mut buf = [0u8; 2];
        let bytes_read = iter.read(&mut buf).unwrap();
        assert_eq!(bytes_read, 2);
        assert_eq!(buf, [0xde, 0xad]);

        let hex = "deadbeef";
        let mut iter = HexToBytesIter::new(hex).unwrap();
        let mut buf = [0u8; 6];
        let bytes_read = iter.read(&mut buf).unwrap();
        assert_eq!(bytes_read, 4);
        assert_eq!(buf[..4], [0xde, 0xad, 0xbe, 0xef]);

        let hex = "deadbeefXX";
        let mut iter = HexToBytesIter::new(hex).unwrap();
        let mut buf = [0u8; 6];
        let err = iter.read(&mut buf).unwrap_err();
        assert_eq!(err.kind(), io::ErrorKind::InvalidData);
    }
}

#[cfg(verus_keep_ghost)]
verus! {
/// Complete forward semantics on every pair of bytes, including non-ASCII bytes.
fn pair_decoding_goal(hi: u8, lo: u8) -> (r: Result<u8, (u8, bool)>)
    ensures r == crate::decoding_spec::pair(hi, lo),
{ hex_chars_to_byte(hi, lo) }
}

#[cfg(test)]
mod forward_decoding_semantics {
    use super::*;

    fn reference(b: u8) -> Option<u8> {
        match b {
            48..=57 => Some(b - 48),
            65..=70 => Some(b - 65 + 10),
            97..=102 => Some(b - 97 + 10),
            _ => None,
        }
    }

    #[test]
    fn every_byte_and_pair_matches_forward_range_semantics() {
        for hi in 0..=u8::MAX {
            assert_eq!(Char::decode_nibble(hi), reference(hi));
            for lo in 0..=u8::MAX {
                let expected = match reference(hi) {
                    None => Err((hi, true)),
                    Some(h) => match reference(lo) {
                        None => Err((lo, false)),
                        Some(l) => Ok(16 * h + l),
                    },
                };
                assert_eq!(hex_chars_to_byte(hi, lo), expected, "pair {hi:#x}, {lo:#x}");
            }
        }
    }
}

#[cfg(verus_keep_ghost)]
verus! {
use vstd::std_specs::iter::{IteratorSpec, IteratorSpecImpl, ExactSizeIteratorSpecImpl, ExactSizeIteratorSpec};
use vstd::std_specs::chunks_exact::{chunks, width};
use vstd::string::StringSliceAdditionalSpecFns;

impl<'a> HexToBytesIter<HexDigitsIter<'a>> {
    pub closed spec fn input_pairs(&self)->Seq<[u8;2]> {self.iter.pairs()}
}
impl<'a> HexDigitsIter<'a> {
    #[verifier::type_invariant]
    pub closed spec fn valid(&self)->bool {
        chunks(self.iter).len() <= usize::MAX && (forall|i:int| 0<=i<chunks(self.iter).len() ==> chunks(self.iter)[i]@.len()==2)
    }
    pub closed spec fn pairs(&self)->Seq<[u8;2]> {
        Seq::new(chunks(self.iter).len(),|i:int| [chunks(self.iter)[i]@[0],chunks(self.iter)[i]@[1]])
    }
}
impl<'a> IteratorSpecImpl for HexDigitsIter<'a> {
    closed spec fn obeys_prophetic_iter_laws(&self)->bool {true}
    closed spec fn remaining(&self)->Seq<Self::Item> {self.pairs()}
    closed spec fn will_return_none(&self)->bool {true}
    closed spec fn decrease(&self)->Option<nat> {Some(self.pairs().len())}
    closed spec fn peek(&self,index:int)->Option<Self::Item> {
        if 0<=index<self.pairs().len() {Some(self.pairs()[index])} else {None}
    }
}
impl<'a> ExactSizeIteratorSpecImpl for HexDigitsIter<'a> {
    closed spec fn exact_len(&self)->usize {self.pairs().len() as usize}
}

pub closed spec fn sat(x:int)->usize {if x>usize::MAX {usize::MAX} else {x as usize}}
// The required decoder is expressed with the accepted independent ASCII spec.
pub closed spec fn decoded(p:[u8;2],cursor:int)->Result<u8,InvalidCharError> {
    match crate::decoding_spec::pair(p@[0],p@[1]) {
        Ok(v)=>Ok(v),
        Err((c,high))=>Err(InvalidCharError {invalid:c,pos:sat(2*cursor+if high {0int} else {1int})}),
    }
}
impl<I> HexToBytesIter<I> where I:Iterator<Item=[u8;2]>+ExactSizeIterator {
    pub closed spec fn cursor(&self)->usize {self.front_pos}
    pub closed spec fn source(&self)->I {self.iter}
    #[verifier::prophetic]
    pub closed spec fn pending(&self)->Seq<Result<u8,InvalidCharError>> {
        Seq::new(self.iter.remaining().len(),|i:int| decoded(self.iter.remaining()[i],self.front_pos as int+i))
    }
}
impl<I> IteratorSpecImpl for HexToBytesIter<I> where I:Iterator<Item=[u8;2]>+ExactSizeIterator {
    closed spec fn obeys_prophetic_iter_laws(&self)->bool {self.iter.obeys_prophetic_iter_laws()}
    #[verifier::prophetic]
    closed spec fn remaining(&self)->Seq<Self::Item> {self.pending()}
    #[verifier::prophetic]
    closed spec fn will_return_none(&self)->bool {self.iter.will_return_none()}
    closed spec fn decrease(&self)->Option<nat> {self.iter.decrease()}
    closed spec fn peek(&self,index:int)->Option<Self::Item> {
        match self.iter.peek(index) {Some(p)=>Some(decoded(p,self.front_pos as int+index)),None=>None}
    }
}
impl<I> ExactSizeIteratorSpecImpl for HexToBytesIter<I> where I:Iterator<Item=[u8;2]>+ExactSizeIterator {
    closed spec fn exact_len(&self)->usize {self.iter.exact_len()}
}
}

#[cfg(verus_keep_ghost)]
verus! {
impl<'a> HexToBytesIter<HexDigitsIter<'a>> {
    pub closed spec fn forward_state(&self,bytes:Seq<u8>)->bool {
        &&& bytes.len()<=usize::MAX
        &&& bytes.len()%2==0
        &&& self.cursor() <= bytes.len()/2
        &&& self.input_pairs().len() <= bytes.len()/2
        &&& self.input_pairs().len()>0 ==> self.input_pairs().len()==bytes.len()/2-self.cursor()
        &&& forall|i:int| 0<=i<self.input_pairs().len() ==>
            self.input_pairs()[i]@ == bytes.subrange(2*(self.cursor()+i),2*(self.cursor()+i)+2)
    }
}
// A compositional theorem for any reachable forward history; exhaustion is
// intentionally allowed to retain an earlier native cursor.
fn forward_step_goal(s:&str,it:&mut HexToBytesIter<HexDigitsIter<'_>>,n:usize)->(r:Option<Result<u8,InvalidCharError>>)
    requires old(it).forward_state(s.spec_bytes()),
    ensures final(it).forward_state(s.spec_bytes()),
        r==if n<old(it).input_pairs().len() {Some(decoded(old(it).input_pairs()[n as int],old(it).cursor() as int+n as int))} else {None},
        final(it).input_pairs().len()==if n<old(it).input_pairs().len() {old(it).input_pairs().len()-n-1} else {0},
        final(it).cursor()==if n<old(it).input_pairs().len() {old(it).cursor() as int+n as int+1} else {old(it).cursor() as int},
        r.is_some() ==> match r->Some_0 {
            Ok(v)=>v==crate::decoding_spec::pair(s.spec_bytes()[2*(old(it).cursor()+n)],s.spec_bytes()[2*(old(it).cursor()+n)+1])->Ok_0,
            Err(e)=> e.pos==2*(old(it).cursor()+n) || e.pos==2*(old(it).cursor()+n)+1,
        },
{it.nth(n)}

fn string_forward_goal<'a>(s:&'a str,n:usize)->(r:Result<(Option<Result<u8,InvalidCharError>>,HexToBytesIter<HexDigitsIter<'a>>),OddLengthStringError>)
    ensures r.is_ok() <==> s.spec_bytes().len()%2==0,
        r.is_err() ==> r->Err_0.len==s.spec_bytes().len(),
        r.is_ok() ==> r->Ok_0.1.forward_state(s.spec_bytes()),
        r.is_ok() ==> r->Ok_0.0==if n<s.spec_bytes().len()/2 {Some(decoded([s.spec_bytes()[2*n],s.spec_bytes()[2*n+1]],n as int))} else {None},
        r.is_ok() ==> r->Ok_0.1.input_pairs().len()==if n<s.spec_bytes().len()/2 {s.spec_bytes().len()/2-n-1} else {0},
{
    let mut it=HexToBytesIter::new(s)?;
    let value=it.nth(n);
    Ok((value,it))
}

fn string_next_goal<'a>(s:&'a str)->(r:Result<(Option<Result<u8,InvalidCharError>>,HexToBytesIter<HexDigitsIter<'a>>),OddLengthStringError>)
    ensures r.is_ok() <==> s.spec_bytes().len()%2==0,
        r.is_err() ==> r->Err_0.len==s.spec_bytes().len(),
        r.is_ok() ==> r->Ok_0.1.forward_state(s.spec_bytes()),
        r.is_ok() ==> r->Ok_0.0==if s.spec_bytes().len()>0 {Some(decoded([s.spec_bytes()[0],s.spec_bytes()[1]],0))} else {None},
{
    let mut it=HexToBytesIter::new(s)?;
    let value=it.next();
    Ok((value,it))
}
}

#[cfg(verus_keep_ghost)]
verus! {
fn original_error_location_goal(s:&str,it:&mut HexToBytesIter<HexDigitsIter<'_>>,n:usize)->(r:Option<Result<u8,InvalidCharError>>)
    requires old(it).forward_state(s.spec_bytes()),
    ensures final(it).forward_state(s.spec_bytes()),
        r.is_some() && r->Some_0.is_err() ==> {
            let e=r->Some_0->Err_0;
            &&& e.pos < s.spec_bytes().len()
            &&& e.invalid == s.spec_bytes()[e.pos as int]
            &&& crate::decoding_spec::digit(e.invalid).is_none()
            &&& e.pos==2*(old(it).cursor()+n) ||
                (e.pos==2*(old(it).cursor()+n)+1 && crate::decoding_spec::digit(s.spec_bytes()[e.pos as int-1]).is_some())
        },
{forward_step_goal(s,it,n)}

fn string_exhaustion_goal(s:&str)->(r:Result<Option<Result<u8,InvalidCharError>>,OddLengthStringError>)
    ensures r.is_ok() <==> s.spec_bytes().len()%2==0,
        r.is_ok() ==> r->Ok_0.is_none(),
{
    let mut it=HexToBytesIter::new(s)?;
    let _=it.nth(usize::MAX);
    Ok(it.next())
}

fn saturated_error_position_goal(input:&[u8])->(r:Option<Result<u8,InvalidCharError>>)
    requires input@.len()==2, crate::decoding_spec::digit(input@[0]).is_none(),
    ensures r==Some(Err::<u8,InvalidCharError>(InvalidCharError{invalid:input@[0],pos:usize::MAX})),
{
    let mut it=HexToBytesIter::from_pairs(HexDigitsIter::new_unchecked(input));
    it.front_pos=usize::MAX;
    it.next()
}
}

#[cfg(test)]
mod forward_iterator_semantics {
    use super::*;
    fn digit(b: u8) -> Option<u8> {
        match b { 48..=57 => Some(b-48), 65..=70 => Some(b-55), 97..=102 => Some(b-87), _ => None }
    }
    fn pair(bytes: &[u8], pos: usize) -> Result<u8, InvalidCharError> {
        let hi = digit(bytes[pos]).ok_or(InvalidCharError { invalid: bytes[pos], pos })?;
        let lo = digit(bytes[pos+1]).ok_or(InvalidCharError { invalid: bytes[pos+1], pos: pos+1 })?;
        Ok(16*hi+lo)
    }
    #[test]
    fn original_byte_positions_skips_lengths_and_exhaustion() {
        let corpus = ["", "0", "aF", "aF10Bc", "zz12xy34", "0z11z0", "é", "é00", "0é", "€", "😀", "a😀b", "\0f00"];
        let histories: &[&[usize]] = &[&[0,0,0,0,0], &[1,0,2,0], &[2,1,0], &[usize::MAX,0,usize::MAX], &[0,usize::MAX,0]];
        for s in corpus {
            for history in histories {
                let mut it = match HexToBytesIter::new(s) {
                    Err(e) => { assert_eq!(s.len()%2,1); assert_eq!(e.len,s.len()); continue; }
                    Ok(it) => { assert_eq!(s.len()%2,0); it }
                };
                let mut cursor=0;
                let mut remaining=s.len()/2;
                for &n in *history {
                    assert_eq!(it.len(),remaining);
                    assert_eq!(it.size_hint(),(remaining,Some(remaining)));
                    let expected=if n<remaining {Some(pair(s.as_bytes(),2*(cursor+n)))} else {None};
                    let actual=if n==0 {it.next()} else {it.nth(n)};
                    assert_eq!(actual,expected,"{s:?}, skip {n}, cursor {cursor}");
                    if n<remaining {cursor+=n+1;remaining-=n+1;} else {remaining=0;}
                    assert_eq!(it.front_pos,cursor);
                }
            }
        }
    }
    #[test]
    fn generic_saturation_boundaries_are_native_behavior() {
        for high in [false,true] {
            let input=if high {[b'z',b'0']} else {[b'0',b'z']};
            for cursor in [usize::MAX/2,usize::MAX-1,usize::MAX] {
                let mut it=HexToBytesIter::from_pairs(core::iter::once(input));
                it.front_pos=cursor;
                let e=it.next().unwrap().unwrap_err();
                assert_eq!(e.invalid,b'z');
                assert_eq!(e.pos,cursor.saturating_mul(2).saturating_add(if high {0}else{1}));
                assert_eq!(it.front_pos,cursor.saturating_add(1));
                assert_eq!(it.nth(usize::MAX),None);
                assert_eq!(it.next(),None);
            }
        }
    }
}

#[cfg(verus_keep_ghost)]
#[cfg(verus_hex_vec_phase3)]
verus! {
pub(crate) open spec fn sat_position(n:int)->usize {if n>usize::MAX {usize::MAX} else {n as usize}}
// Required logical result only. This is NOT an assumed drain contract or a
// permission to write memory; the selected native body must establish it.
pub(crate) closed spec fn required_vector_drain_result(pairs:Seq<[u8;2]>,cursor:int,r:Result<Vec<u8>,InvalidCharError>)->bool {
    match r {
        Ok(v)=>v@.len()==pairs.len() && (forall|i:int| 0<=i<pairs.len() ==>
            crate::decoding_spec::pair(pairs[i]@[0],pairs[i]@[1])==Ok(v@[i])),
        Err(e)=>exists|i:int| 0<=i<pairs.len() &&
            (forall|j:int| 0<=j<i ==> crate::decoding_spec::pair(pairs[j]@[0],pairs[j]@[1]).is_ok()) &&
            match crate::decoding_spec::pair(pairs[i]@[0],pairs[i]@[1]) {
                Err((b,high))=>e.invalid==b && e.pos==sat_position(2*(cursor+i)+if high {0int}else{1int}),
                _=>false,
            },
    }
}
}
