"""Seal generated artifacts without writing to the parent checkout or Git."""

from datetime import datetime, timezone
import json
from pathlib import Path
import sys


ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
import retain_results as retained


candidate = json.loads((ROOT / "CANDIDATE-IDENTITIES.json").read_text())
reconstructed = {name: retained.identity(ROOT / "reconstructed" / name) for name in candidate}
if candidate != reconstructed:
    raise RuntimeError("reconstructed patch does not match candidate bytes")
baseline = json.loads((ROOT / "BASELINE-INPUTS.json").read_text())
exit_baseline = retained.baseline()
if baseline["read_input_sha256"] != exit_baseline["read_input_sha256"]:
    raise RuntimeError("parent read-input identity changed before final seal")
retained.write_json(ROOT / "BASELINE-FINAL.json", dict(exit_baseline, endpoint_drift=[]))
retained.write_json(ROOT / "PATCH-ROUNDTRIP.json", {"matches": True, "files": reconstructed})
suite_prefix = "TMPDIR=/private/tmp/provenance-receipt107.Puwj4s/test-tmp "
suite = "python3 -I -B -m unittest discover -s candidate/source/tools -p test_capture_provenance_receipt.py -v"
commands = [
    {"kind": "unit", "argv_shell": suite_prefix + "PYTHONDONTWRITEBYTECODE=1 " + suite.replace(" -B", ""),
     "log": "logs/unit-001.log", "exit_code": 0, "tests": 30},
    {"kind": "unit", "argv_shell": suite_prefix + suite,
     "log": "logs/unit-002.log", "exit_code": 0, "tests": 37},
    {"kind": "unit", "argv_shell": suite_prefix + suite,
     "log": "logs/unit-003-regression-red.log", "exit_code": 1, "tests": 38,
     "failures": 1, "errors": 1, "note": "retained developing-candidate red regression run"},
    {"kind": "unit", "argv_shell": suite_prefix + suite,
     "log": "logs/unit-004-regression-green.log", "exit_code": 0, "tests": 38},
    {"kind": "unit", "argv_shell": suite_prefix + suite.replace("candidate/", "reconstructed/"),
     "log": "logs/unit-005-reconstructed-final.log", "exit_code": 0, "tests": 38},
    {"kind": "fixtures", "argv_shell": "python3 -I -B retain_results.py",
     "log": "logs/scenarios-001.log", "exit_code": 0},
    {"kind": "final-fixtures-and-patch", "argv_shell": "python3 -I -B prepare_final.py",
     "log": "logs/prepare-final.log", "exit_code": 0},
    {"kind": "patch-check", "argv_shell": "patch --batch --forward --dry-run -p1 -d reconstructed < candidate.patch",
     "log": "logs/patch-dry-run.log", "exit_code": 0},
    {"kind": "patch-reconstruction", "argv_shell": "patch --batch --forward -p1 -d reconstructed < candidate.patch",
     "log": "logs/patch-apply.log", "exit_code": 0},
]
retained.write_json(ROOT / "COMMANDS.json", {
    "cwd": str(ROOT), "records": commands,
    "scope": "substantive validation and packaging executions; exploratory read-only shell commands are not an exhaustive syscall trace",
    "first_run_python_environment_note": "-I ignores PYTHONDONTWRITEBYTECODE; subsequent runs explicitly use -B",
    "fixture_child_launch_environment": {"LANG": "C", "LC_ALL": "C", "TZ": "UTC"},
})
finished = datetime.now(timezone.utc)
started = datetime.fromisoformat("2026-11-08T02:41:46+00:00")
payloads = [path for path in ROOT.rglob("*") if path.is_file()]
sample = retained.disk_entry()
samples = [json.loads((ROOT / name).read_text()) for name in
           ("RESOURCE-BEFORE.json", "RESOURCE-AFTER-SCENARIOS.json")]
initial_free_bytes = 52694464 * 1024
allocated_bytes = sum(path.stat().st_blocks * 512 for path in payloads)
accounting = {
    "started_utc": started.isoformat(), "final_accounting_utc": finished.isoformat(),
    "elapsed_seconds": (finished - started).total_seconds(), "deadline_utc": "2026-11-08T03:01:46+00:00",
    "optional_work_cutoff_utc": "2026-11-08T02:58:46+00:00",
    "scratch_limit_bytes": 256 * 1024 ** 2, "minimum_global_free_bytes": 16 * 1024 ** 3,
    "scratch_logical_bytes_before_final_bookkeeping": sample["scratch_logical_bytes"],
    "scratch_allocated_file_bytes_before_final_bookkeeping": allocated_bytes,
    "disk_samples": [dict(observed_utc=started.isoformat(), free_bytes=initial_free_bytes)] + samples + [sample],
    "minimum_sampled_global_free_bytes": min([initial_free_bytes] + [entry["free_bytes"] for entry in samples] + [sample["free_bytes"]]),
    "monitoring_scope": "samples before phases, not continuous global monitoring; final manifest/seal add a small amount of scratch",
    "python_unit_suite_invocations": 5, "final_unit_tests": 38, "final_unit_success": True,
    "retained_negative_development_suite_runs": 1, "retained_demo_receipts": 18,
    "retained_demo_commands_started": 16, "parent_writes": 0, "git_commands": 0,
    "network_requests": 0, "delegates": 0, "cargo_executions": 0, "verifier_executions": 0,
    "solver_executions": 0, "compiler_executions": 0, "vstd_builds": 0,
    "native_target_executions": 0, "native_runtime_executions": 0,
    "compiler_source_build_claims": 0, "native_proof_credit": 0, "redb_cells_open": 18,
    "independent_review": "required before parent integration; not performed here",
}
retained.write_json(ROOT / "ACCOUNTING.json", accounting)
manifest = {str(path.relative_to(ROOT)): retained.identity(path)
            for path in sorted(ROOT.rglob("*")) if path.is_file()
            and path.name not in ("MANIFEST.json", "SEAL.json")}
retained.write_json(ROOT / "MANIFEST.json", {
    "schema": "scratch-file-manifest-v1", "root": str(ROOT), "files": manifest,
    "exclusions": ["MANIFEST.json", "SEAL.json"],
    "inputs": "BASELINE-INPUTS.json and individual scenario plan/receipt records",
    "output_role": "unintegrated implementation and hermetic validation artifacts, not native proof",
})
retained.write_json(ROOT / "SEAL.json", {
    "schema": "content-integrity-seal-v1", "sealed_utc": datetime.now(timezone.utc).isoformat(),
    "files": {name: retained.identity(ROOT / name) for name in
              ("MANIFEST.json", "ACCOUNTING.json", "HANDOFF.md", "candidate.patch")},
    "limitation": "content integrity only; no compiler/source correspondence, native proof, or independent review",
})
final_sample = retained.disk_entry()
print(json.dumps({"patch": retained.identity(ROOT / "candidate.patch"),
                  "seal": retained.identity(ROOT / "SEAL.json"), "manifest_payloads": len(manifest),
                  "elapsed_seconds": accounting["elapsed_seconds"], "final_resource_sample": final_sample}, indent=2))
