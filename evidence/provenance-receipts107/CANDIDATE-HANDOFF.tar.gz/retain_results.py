"""Retain bounded Python-only demonstration receipts and package identities."""

from datetime import datetime, timezone
import difflib
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import time


ROOT = Path(__file__).resolve().parent
PARENT = Path("/Users/tommyvolk/.t3/worktrees/verus/t3-60978068")
sys.path.insert(0, str(ROOT / "candidate/source/tools"))
import capture_provenance_receipt as provenance


def identity(path):
    return {"sha256": hashlib.sha256(path.read_bytes()).hexdigest(), "size_bytes": path.stat().st_size}


def write_json(path, payload):
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")


def utc_now():
    return datetime.now(timezone.utc).isoformat()


def disk_entry():
    usage = shutil.disk_usage(ROOT)
    logical_bytes = sum(path.stat().st_size for path in ROOT.rglob("*") if path.is_file())
    if usage.free <= 16 * 1024 ** 3 or logical_bytes > 256 * 1024 ** 2:
        raise RuntimeError("resource boundary exceeded")
    return {"observed_utc": utc_now(), "free_bytes": usage.free,
            "scratch_logical_bytes": logical_bytes}


def baseline():
    names = {str(path.relative_to(PARENT)) for path in (PARENT / "source/tools").glob("*.py")}
    names.update(("evidence/parallel-advancement107/PLAN.md",
                  "evidence/redb-native-binding-trace106/SOURCE-REPORT.md"))
    additions = [str(path.relative_to(ROOT / "candidate"))
                 for path in (ROOT / "candidate").rglob("*") if path.is_file()
                 and path.suffix in (".py", ".md")]
    for name in additions:
        if (PARENT / name).exists():
            raise RuntimeError(f"new-file baseline unexpectedly present: {name}")
    return {"observed_utc": utc_now(), "parent": str(PARENT),
            "hash_timing": "captured after discovery, not a pre-read or atomic snapshot",
            "read_input_sha256": {name: identity(PARENT / name) for name in sorted(names)},
            "candidate_baseline": {name: {"status": "absent"} for name in sorted(additions)}}


def retain_scenarios(directory_name="scenarios", summary_name="SCENARIOS.json"):
    scenarios = ROOT / directory_name
    scenarios.mkdir()
    summary = {}
    for name in ("success", "missing-output", "stale-output", "seeded-output", "source-drift",
                 "source-addition", "command-failure", "timeout", "compiler-drift"):
        workspace = scenarios / name
        workspace.mkdir()
        inputs = workspace / "inputs"
        inputs.mkdir()
        source = inputs / "engine.rs"
        source.write_bytes(b"fake source, never compiled\n")
        compiler = workspace / "fake-compiler"
        compiler.write_bytes(b"fake bytes, never executed\n")
        artifact = workspace / "artifact.bin"
        executable = Path(sys.executable).resolve()
        code = f"from pathlib import Path; Path({str(artifact)!r}).write_bytes(b'fake artifact')"
        if name == "missing-output":
            code = "pass"
        elif name == "stale-output":
            code += f"; import os; os.utime({str(artifact)!r}, ns=(1, 1))"
        elif name == "seeded-output":
            artifact.write_bytes(b"seeded and preserved")
        elif name == "source-drift":
            code += f"; Path({str(source)!r}).write_text('changed source')"
        elif name == "source-addition":
            code += f"; Path({str(inputs / 'added.rs')!r}).write_text('new selected input')"
        elif name == "command-failure":
            code += "; print('retained harmless failure'); raise SystemExit(9)"
        elif name == "timeout":
            code += "; import time; time.sleep(10)"
        elif name == "compiler-drift":
            code += f"; Path({str(compiler)!r}).write_bytes(b'changed fake compiler')"
        plan = {
            "schema": provenance.PLAN_SCHEMA, "cwd": str(workspace),
            "argv": [str(executable), "-I", "-S", "-c", code],
            "executable_sha256": identity(executable)["sha256"],
            "compiler": {"path": str(compiler), "sha256": identity(compiler)["sha256"]},
            "inventory": {"root": str(workspace), "files": [], "trees": ["inputs"],
                          "expected_sha256": {"inputs/engine.rs": identity(source)["sha256"]}},
            "outputs": [str(artifact)], "timeout_seconds": 0.2 if name == "timeout" else 5,
        }
        write_json(workspace / "plan.json", plan)
        receipt = provenance.capture(plan, workspace / "receipt")
        if receipt["success"] != (name == "success"):
            raise AssertionError(f"unexpected demonstration result: {name}: {receipt['errors']}")
        summary[name] = {"success": receipt["success"], "errors": receipt["errors"],
                         "receipt": str((workspace / "receipt/receipt.json").relative_to(ROOT))}
    write_json(ROOT / summary_name, summary)


def make_patch():
    chunks = []
    for path in sorted((ROOT / "candidate").rglob("*")):
        if path.is_file() and path.suffix in (".py", ".md"):
            name = str(path.relative_to(ROOT / "candidate"))
            chunks.extend((f"diff --git a/{name} b/{name}\n", "new file mode 100644\n"))
            chunks.extend(difflib.unified_diff([], path.read_text().splitlines(keepends=True),
                                             fromfile="/dev/null", tofile="b/" + name))
    (ROOT / "candidate.patch").write_text("".join(chunks))


if __name__ == "__main__":
    write_json(ROOT / "BASELINE-INPUTS.json", baseline())
    write_json(ROOT / "RESOURCE-BEFORE.json", disk_entry())
    retain_scenarios()
    make_patch()
    write_json(ROOT / "RESOURCE-AFTER-SCENARIOS.json", disk_entry())
    print(json.dumps({"scenarios": 9, "patch": str(ROOT / "candidate.patch"), "resource": disk_entry()}))
