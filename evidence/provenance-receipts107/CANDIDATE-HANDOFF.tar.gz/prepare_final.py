"""Prepare final-code fixtures, baseline recheck, and an additions-only patch."""

import json
from pathlib import Path
import sys


ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
import retain_results as retained


previous = json.loads((ROOT / "BASELINE-INPUTS.json").read_text())
current = retained.baseline()
drift = sorted(name for name in previous["read_input_sha256"].keys() | current["read_input_sha256"].keys()
               if previous["read_input_sha256"].get(name) != current["read_input_sha256"].get(name))
retained.write_json(ROOT / "BASELINE-EXIT.json", dict(current, drift_from_first_hash_snapshot=drift))
if drift:
    raise RuntimeError(f"parent input endpoint drift: {drift}")
retained.retain_scenarios("scenarios-final", "SCENARIOS-FINAL.json")
retained.make_patch()
retained.write_json(ROOT / "CANDIDATE-IDENTITIES.json", {
    str(path.relative_to(ROOT / "candidate")): retained.identity(path)
    for path in sorted((ROOT / "candidate").rglob("*"))
    if path.is_file() and path.suffix in (".py", ".md")})
print(json.dumps({"parent_input_hashes": len(current["read_input_sha256"]), "parent_endpoint_drift": drift,
                  "candidate_patch": retained.identity(ROOT / "candidate.patch"),
                  "resources": retained.disk_entry()}))
