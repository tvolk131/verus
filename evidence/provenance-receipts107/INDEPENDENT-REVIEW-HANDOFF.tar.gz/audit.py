"""Read-only candidate authentication and bounded independent review evidence."""

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile
import time


ROOT = Path(__file__).resolve().parent
CANDIDATE = Path('/private/tmp/provenance-receipt107.Puwj4s')
PARENT = Path('/Users/tommyvolk/.t3/worktrees/verus/t3-60978068')
ARCHIVE = PARENT / 'evidence/provenance-receipts107/CANDIDATE-HANDOFF.tar.gz'
STARTED = '2026-11-08T02:59:40+00:00'
LIMIT = 256 * 1024 ** 2
ENVIRONMENT = {'LANG': 'C', 'LC_ALL': 'C', 'TZ': 'UTC', 'TMPDIR': str(ROOT / 'test-tmp')}


def identity(path):
    payload = path.read_bytes()
    return {'sha256': hashlib.sha256(payload).hexdigest(), 'size_bytes': len(payload)}


def write_json(name, payload):
    (ROOT / name).write_text(json.dumps(payload, indent=2, sort_keys=True) + '\n')


def snapshot():
    baseline = json.loads((CANDIDATE / 'BASELINE-INPUTS.json').read_text())
    return {
        'observed_utc': datetime.now(timezone.utc).isoformat(),
        'candidate_files': {str(path.relative_to(CANDIDATE)): identity(path)
                            for path in sorted(CANDIDATE.rglob('*')) if path.is_file()},
        'parent_used_inputs': {name: identity(PARENT / name)
                               for name in sorted(baseline['read_input_sha256'])},
        'parent_archive': identity(ARCHIVE),
        'parent_addition_baselines': {name: os.path.lexists(PARENT / name)
                                      for name in baseline['candidate_baseline']},
        'python_executable': {'path': str(Path(sys.executable).resolve()),
                              **identity(Path(sys.executable).resolve())},
    }


def resources():
    files = [path for path in ROOT.rglob('*') if path.is_file()]
    record = {'observed_utc': datetime.now(timezone.utc).isoformat(),
              'free_bytes': shutil.disk_usage(ROOT).free,
              'scratch_logical_bytes': sum(path.stat().st_size for path in files),
              'scratch_allocated_file_bytes': sum(path.stat().st_blocks * 512 for path in files)}
    if record['free_bytes'] <= 16 * 1024 ** 3 or record['scratch_logical_bytes'] > LIMIT:
        raise RuntimeError('resource boundary exceeded')
    return record


def run(name, argv, stdin=None):
    ledger_path = ROOT / 'COMMANDS.json'
    ledger = json.loads(ledger_path.read_text()) if ledger_path.exists() else []
    started = time.monotonic()
    result = subprocess.run(argv, cwd=ROOT, env=ENVIRONMENT, input=stdin,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=30)
    log = 'logs/' + name + '.log'
    (ROOT / log).write_bytes(result.stdout)
    ledger.append({'argv': argv, 'cwd': str(ROOT), 'environment': ENVIRONMENT,
                   'stdin_sha256': None if stdin is None else hashlib.sha256(stdin).hexdigest(),
                   'exit_code': result.returncode, 'elapsed_seconds': time.monotonic() - started,
                   'log': log})
    write_json('COMMANDS.json', ledger)
    print(json.dumps({'command': name, 'exit_code': result.returncode, 'log': log}))
    return result


def prepare():
    (ROOT / 'logs').mkdir()
    (ROOT / 'test-tmp').mkdir()
    (ROOT / 'reconstructed').mkdir()
    entry = snapshot()
    write_json('ENTRY.json', entry)
    write_json('RESOURCES-ENTRY.json', resources())
    expected = {'candidate.patch': 'e319638a6ff0c5552f1136e041b652b4131995133df5b365caa1db83dad3707d',
                'MANIFEST.json': 'fe2bdfa70db26ac6a25ec1a89c15c6cbdfa3055a96c5ffbbbe87267f163ce070',
                'HANDOFF.md': 'ce70b30a8f6f799b37821fd81a09530792cfcb3e467a5bd7a99a18ba75682b21'}
    for name, digest in expected.items():
        assert entry['candidate_files'][name]['sha256'] == digest
    assert entry['parent_archive']['sha256'] == '052de112c872c293232f60d29b241e1e9ddae2f3165ffc7898472e183f656cfe'
    manifest = json.loads((CANDIDATE / 'MANIFEST.json').read_text())
    assert all(entry['candidate_files'][name] == record for name, record in manifest['files'].items())
    archive_members = []
    with tarfile.open(ARCHIVE, 'r:gz') as archive:
        for member in archive.getmembers():
            assert member.isfile(), member.name
            payload = archive.extractfile(member).read()
            assert payload == (CANDIDATE / member.name).read_bytes(), member.name
            archive_members.append(member.name)
    assert set(archive_members) == set(entry['candidate_files'])
    baselines = {name: json.loads((CANDIDATE / name).read_text())
                 for name in ('BASELINE-INPUTS.json', 'BASELINE-EXIT.json', 'BASELINE-FINAL.json')}
    assert all(value['read_input_sha256'] == entry['parent_used_inputs'] for value in baselines.values())
    assert not any(entry['parent_addition_baselines'].values())
    raw_logs = {name: (CANDIDATE / name).read_text()
                for name in entry['candidate_files'] if name.endswith('.log')}
    write_json('RAW-CANDIDATE-LOGS.json', raw_logs)
    scenario_checks = {}
    for name, record in json.loads((CANDIDATE / 'SCENARIOS-FINAL.json').read_text()).items():
        receipt = json.loads((CANDIDATE / record['receipt']).read_text())
        assert receipt['success'] == record['success'] == (name == 'success')
        assert receipt['errors'] == record['errors']
        scenario_checks[name] = {'success': receipt['success'], 'errors': receipt['errors']}
    write_json('AUTHENTICATION.json', {'manifest_payloads': len(manifest['files']),
               'archive_members': len(archive_members), 'parent_input_hashes': len(entry['parent_used_inputs']),
               'all_pinned_digests_match': True, 'manifest_payloads_match': True,
               'archive_bytes_match_candidate': True, 'baseline_snapshots_match_parent': True,
               'raw_logs_read': len(raw_logs), 'final_scenarios': scenario_checks,
               'entry_hash_timing': 'after initial source/discovery reads; before reconstruction and tests'})
    patch = (CANDIDATE / 'candidate.patch').read_bytes()
    for name, options in (('patch-dry-run', ['--dry-run']), ('patch-apply', [])):
        result = run(name, ['/usr/bin/patch', '--batch', '--forward', *options, '-p1',
                            '-d', str(ROOT / 'reconstructed')], patch)
        assert result.returncode == 0
    reconstructed = {str(path.relative_to(ROOT / 'reconstructed')): identity(path)
                     for path in sorted((ROOT / 'reconstructed').rglob('*')) if path.is_file()}
    assert len(reconstructed) == 3
    for name, record in reconstructed.items():
        assert record == entry['candidate_files']['candidate/' + name]
    write_json('RECONSTRUCTION.json', reconstructed)
    result = run('unit-38', [sys.executable, '-I', '-B', '-m', 'unittest', 'discover',
                            '-s', str(ROOT / 'reconstructed/source/tools'),
                            '-p', 'test_capture_provenance_receipt.py', '-v'])
    assert result.returncode == 0
    assert b'Ran 38 tests' in result.stdout


def finish():
    entry = json.loads((ROOT / 'ENTRY.json').read_text())
    final = snapshot()
    write_json('EXIT.json', final)
    fields = ('candidate_files', 'parent_used_inputs', 'parent_archive',
              'parent_addition_baselines', 'python_executable')
    drift = [field for field in fields if entry[field] != final[field]]
    assert not drift, drift
    accounting = {'started_utc': STARTED, 'finished_utc': final['observed_utc'],
                  'elapsed_seconds': (datetime.fromisoformat(final['observed_utc']) -
                                      datetime.fromisoformat(STARTED)).total_seconds(),
                  'endpoint_drift': drift, 'resources': resources(),
                  'parent_writes': 0, 'candidate_writes': 0, 'git_commands': 0,
                  'network_requests': 0, 'delegates': 0, 'native_executions': 0,
                  'toolchain_runtime_cache_copies': 0, 'redb_cells_open': 18,
                  'native_proof_credit': 0,
                  'scope': 'endpoint hashes and phase resource samples, not continuous custody or global monitoring'}
    write_json('ACCOUNTING.json', accounting)
    manifest = {str(path.relative_to(ROOT)): identity(path) for path in sorted(ROOT.rglob('*'))
                if path.is_file() and path.name not in ('MANIFEST.json', 'SEAL.json', 'REVIEW-HANDOFF.tar.gz')}
    write_json('MANIFEST.json', {'files': manifest,
               'exclusions': ['MANIFEST.json', 'SEAL.json', 'REVIEW-HANDOFF.tar.gz']})
    write_json('SEAL.json', {'manifest': identity(ROOT / 'MANIFEST.json'),
                            'report': identity(ROOT / 'REVIEW.md'),
                            'accounting': identity(ROOT / 'ACCOUNTING.json')})
    with tarfile.open(ROOT / 'REVIEW-HANDOFF.tar.gz', 'w:gz') as archive:
        for name in sorted([*manifest, 'MANIFEST.json', 'SEAL.json']):
            archive.add(ROOT / name, arcname=name, recursive=False)
    archive_digest = identity(ROOT / 'REVIEW-HANDOFF.tar.gz')
    print(json.dumps({'archive': archive_digest, 'accounting': accounting}, indent=2))


if __name__ == '__main__':
    if sys.argv[1] == 'prepare':
        prepare()
    elif sys.argv[1] == 'adversarial':
        result = run('reviewer-adversarial', [sys.executable, '-I', '-B',
                                            str(ROOT / 'reviewer_tests.py')])
        raise SystemExit(result.returncode)
    elif sys.argv[1] == 'finish':
        finish()
