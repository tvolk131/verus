# Native hex: one next proof slice

Research-only assessment, 2026-11-07 (America/Chicago). NOT a verification result,
patch approval, trusted interface, or authority to retry refused/exhausted work.

## Recommendation

Propose **canonical single-byte encoding through the original Case::table and
Table::byte_to_hex_chars**, for every u8 and both Lower/Upper cases. This is one
finite encoding slice, not an encoder-iterator, string-encoding, or roundtrip
milestone. It adds useful case-sensitive output semantics beyond established
decoding/forward coverage without loops, raw pointers, new dependency models,
or an engine extension. Feasibility is source-inspected, not demonstrated.

The primitive feeds BytesToHexIter::{next,nth,next_back,nth_back} in archived
src/iter.rs:407,415,426,431; these iterator transitions remain unproved here.

## Exact inputs and candidate locations

Parent P = /Users/tommyvolk/.t3/worktrees/verus/t3-60978068.
Authoritative native source is archive member src/lib.rs in
P/evidence/verus-infer-hex-v3/native-source.tar.gz, NOT an unexamined live checkout.
The planned integration destination is src/lib.rs in a separately authorized,
disposable native source tree authenticated against that archive.

- src/lib.rs:204: Case enum, both variants; select as verified data.
- src/lib.rs:225: original Case::table, including both match branches.
- src/lib.rs:240: existing verified repr(u8) Char, retain all 22 variants.
- src/lib.rs:390: Table([Char; 16]), select as verified data.
- src/lib.rs:394 and :401: original LOWER/UPPER initializers, select and check;
  do not substitute new arrays or assume their contents.
- src/lib.rs:433: original Table::byte_to_hex_chars, complete body.
- Proposed new ghost module: src/encoding_spec.rs and cfg(verus_keep_ghost)
  declaration/imports in src/lib.rs. The proposed fixture below supplies that
  module's policy/goal and one optional proved arithmetic lemma; native selection
  annotations and required contracts are still to be integrated.

Frozen input identities:

- Native acceptance commit: 54b6672c00c2cbeac8bcd7c6761cf1b0bec1a6a2.
- Engine acceptance commit: 6d80948ce8c981bd650ae851cd99c64cf7625f5d.
- Upstream version 1.3.0, commit 129db6ac54d25b08e0b927c225aefe4a8df05a57.
- native-source.tar.gz SHA256:
  e7f4b63eced039d437b54858fc600071b41614aa66b2a9fdc27caa94c9e0de5b.
- Streamed archive src/lib.rs SHA256:
  c5d584fb99c620c8e086c970afcf14b36fa4bb8838d9ead1a415ef3142c67073.
- closure-summary.json SHA256:
  762e7ac7cfc54b8a16624e36099086f524c2dd0f35b61be26b04157da98570af.
- requirements-preservation.json SHA256:
  9dd33548c9bc4ca813aa480affc38cb92464d6facbcc2f3b8ce67ade2cc0ab44.

Deliverables (fresh scratch only):
- /private/tmp/verus-hex-encode-assessment-20261107-TfFS9w/REPORT.md
- /private/tmp/verus-hex-encode-assessment-20261107-TfFS9w/encoding_slice.proposed.rs

## Established evidence, not new executions

Inspected frozen v1/v2/v3 READMEs, charters/assumptions and v3 closure/source audit.

- v1 establishes actual nibble-table initialization and all-byte-pair decoding,
  including independent arithmetic/error policy; the pair is the exact inferred
  helper, with soundness, maximality and exactness separately checked.
- v2 adds native construction, ChunksExact forward next/nth, skipping, original
  UTF-8 byte positions, exhaustion and saturation. Its scope explicitly excludes
  encoding and backward/mixed iteration.
- The earlier verus-infer-hex-vec-phase3 is an UNACCEPTED pointer-model blocker,
  not the last state. v3 records accepted original public vector decoding,
  actual length/hints, permission-backed writes/set_len and first-error policy:
  37 results, zero errors, 32 named bodies, 24 rejected mutations. These are
  historical recorded claims; nothing was replayed here. It retains the sole
  exact inferred pair helper rather than counting ordinary goals as inference.
- v3 remains finite: aarch64-apple-darwin, 64-bit usize; no whole-crate claim.
  Its original-function audit covers 218 signatures/executable bodies, including
  the proposed encoding methods, but those encoding methods were not thereby
  proved correct. Preservation is not verification.

Not selected: fixed arrays (native 2*N overflow domain/different unsafe drain),
backward/mixed iteration (no searched next_back/nth_back in the ChunksExact model),
or the distinct cached rust-hex 0.4.3 lane in
P/evidence/parallel-proof-lanes94/PLAN.md. None is being restarted or counted here.

## Authored goal and complete intended domain

Let ascii(Char) be its actual repr(u8) discriminant, interpreted as an integer.
For 0 <= n < 16 define the independent numeric policy

    glyph(n, Lower) = if n < 10 then 48+n else 87+n
    glyph(n, Upper) = if n < 10 then 48+n else 55+n.

The policy does not inspect Table, duplicate its literal array, call the decoder,
or characterize the output merely by a successful decode.

For every byte b in 0..=255 and case c in {Lower,Upper}, the original composition

    c.table().byte_to_hex_chars(b)

must return r: [Char;2] with

    ascii(r[0]) = glyph((b as int)/16, c)
    ascii(r[1]) = glyph((b as int)%16, c).

There is NO input precondition, ASCII/lower-only restriction, nonzero/small-byte
range or successful-input condition. Zero, 255 and both-letter nibbles are included.
The array type supplies exactly two elements; there is no allocation/error path.
Keep the existing native target; other targets are not accepted by analogy.

The original helper also accepts **any legal Table([Char;16])**, not just the two
constants. Preserve that complete method domain with a no-precondition required
contract, authored in table's module:

    r@[0] == self.0@[(b as int)/16]
    r@[1] == self.0@[(b as int)%16]
    *self == Table::LOWER ==> encoding_spec::required_encoding(b, Lower, r)
    *self == Table::UPPER ==> encoding_spec::required_encoding(b, Upper, r).

The two equalities to constants are logical value equality, NOT calls to the
original Table::PartialEq::eq. Arbitrary shuffled/repeated Char arrays get the
actual selection equations; they do not acquire a false canonical-hex promise.
No canonical-table invariant or constructor assumption is imposed on callers.

Give the ORIGINAL Case::table an ordinary, body-checked required postcondition:

    match self { Lower => *r == Table::LOWER, Upper => *r == Table::UPPER }.

These are proposed ordinary requirements, not already proved summaries and not
new trusted specifications. Select the real constant definitions so the helper's
canonical implications must follow from their actual entries. A copied table,
opaque assumed table equation, or success on only LOWER is not acceptance.

## Correspondence and remaining handwritten work

The complete original helper is:

    let left = self.0[usize::from(byte >> 4)];
    let right = self.0[usize::from(byte & 0x0F)];
    [left, right]

Preserve those executable statements, both Case::table branches, both arrays,
types, derives and signatures. Do not replace shifts/masks with division/modulo,
Char with u8, usize::from with a cast, or native code with a verified adapter.
The fixture's wrapper calls original methods; it is not a replacement implementation.

Work still to do, with no proof-success estimate disguised as a result:

1. Integrate selection annotations, the two method requirements, and ghost module
   declaration/imports; handle native private-field/constant visibility normally.
2. Prove both actual array indices safe and connect shifts/masks to div/mod.
   Start with ordinary verification under the existing application assistance
   settings. If needed, the draft contains ONE universal u8 lemma, four checked
   facts, usable through one erased proof! call at the start of the native helper.
   Its premises do not restrict b. It is handwritten proof work, not Infer output.
3. Prove the canonical implications from all 16 actual entries of EACH constant.
   Ordinary unfolding may suffice. If not, permit at most one small, checked
   finite-index correspondence lemma and explicit uses, keeping its original
   literal-array source and numeric policy fixed. No assumed lookup theorem.
4. Check the complete application goal on both cases and every byte; record actual
   annotations, lemma statements/calls and solver time. No handwritten loop
   invariants, ownership proof, or generalized iterator induction is anticipated.

If adding the erased proof! call is needed, disclose that the SOURCE body gained
ghost code. Require a fresh comparison of erased executable tokens/signatures;
the frozen audit did not inspect this later addition and is not its certificate.
Any constant lemma is likewise an ordinary checked body, never external_body,
assume, admit, axiomatization, or a newly trusted first-party API.

## Existing support and assumptions

Evidence inspected in the DIRTY parent, not built or authenticated as a runtime:

- source/builtin_macros/src/attr_rewrite.rs:1 documents selection, required
  contracts and erased proof! blocks; :640 implements constant annotation rewriting.
- source/rust_verify_test/tests/integers.rs:674 has repr(u8) enum cast precedents;
  source/rust_verify_test/tests/consts.rs:534 has an associated-struct constant
  precedent. Neither is a fresh proof of this exact enum-array/native combination.
- source/vstd/std_specs/convert.rs:129,149 contains the pre-existing u8-to-usize
  From model. Use it unchanged and list it as inherited trust, not a new rule.
- source/vstd/bits.rs:53 and :114 provide checked shift/division machinery;
  ordinary assert(... ) by(bit_vector) is another existing way to check the four
  finite-width facts. No solver was invoked here.
- source/docs/guide/src/infer.md:1397-1450 limits automatic scalar assistance:
  initial exact-call/explicit-assertion shapes and bounded expansion; it does NOT
  promise arbitrary postcondition or implicit array-index discharge. Enum/table
  semantics will not be inferred merely because --infer-goals is enabled.
  source/vir/src/infer/bitvector_hints.rs:1 preserves safety/precision obligations
  and checks complete proposed theorems. Do not count assistance proposals as
  proof success or demand that this new ordinary helper receive exact inference.

Trust inherited for this slice: Rust/Verus frontend and erasure, SMT/BV checking,
ordinary ADT/array/Seq semantics and the existing integer-conversion library
specifications. Enum representation must come from the actual Char declaration.
No new standard-library model or first-party assume-specification is proposed or
adopted. The broader retained v3 proof still carries its separately inventoried
ChunksExact/Vec/raw-pointer assumptions; this encoding primitive needs none of
those mechanisms, and does not remove them from the retained decoding claim.

The frozen v3 receipt uses metadata schema38/policy54/cache60; the current dirty
source/rust_verify/src/import_export.rs:17 names candidate-bound-evidence-v76.
Do NOT mix old accepted artifacts with a putative current build or infer binary
identity from a source inspection. Matching runtime/macros/vstd availability,
associated enum-array const exposure, native visibility and proof erasure are
explicit feasibility checkpoints. If unsupported without a new model/build or
executable adaptation, report that exact blocker and stop.

## One matched semantic negative

Only in a separately authorized disposable native copy, change the ORIGINAL
src/lib.rs:227 branch from Case::Lower => &Table::LOWER to
Case::Lower => &Table::UPPER. Keep all required contracts, source selection,
Char declarations, constants, byte domain and proof settings unchanged.

Witness: byte 0xab with Lower must produce ASCII [97,98] ('a','b'), but the
mutant produces [65,66] ('A','B'). Decoding either still yields 0xab: a roundtrip
check alone would miss this canonical-case error. Expected outcome is an ordinary
Case::table requirement failure (or the unchanged encoding goal if that is the
reported failing obligation), NOT unsupported syntax, timeout or a missing model.
The generic byte-selection helper, both actual constants and retained decoder
certificates should remain healthy. Reject/no accepted publication; then restore
the exact branch and obtain a fresh successful proof before any acceptance claim.
This is a proposed control, not a claim of an upstream bug or an executed rejection.

## Bounded FUTURE execution plan -- NOT run or authorized here

The current report-only/no-execution instruction takes precedence over this plan.
Before any future work the parent must explicitly authorize it, confirm no step
restarts a refused/exhausted task, supply the permitted matching runtime and an
isolated source copy, and retain all source/evidence pins. No inherited retry or
build permission is granted. Do not use old acceptance controllers: they mutate
native source and run test/toolchain commands outside this report's allowance.

Use at most FIVE direct verifier invocations, INCLUDING failed attempts:

1. Check the complete retained v3 selected scope plus candidate requirements on
   an authenticated native copy, unchanged executable bodies and existing
   --infer-goals --no-cheating settings. Freeze candidate input hashes first.
2. Only if the failure is the bounded nibble/table proof work above, allow ONE
   explicit checked-lemma augmentation and recheck the IDENTICAL full domain.
   No automatic retry or new frontend, model, contract weakening, or algorithm.
3. Run the single wrong-case mutant in that same successful configuration.
4. Restore source; fresh-cache full-scope positive replay with matched hashes.
5. One warm-cache replay, still requiring freshly checked acceptance obligations.

If step2 is unnecessary, skip it; do not spend its budget elsewhere. If a positive
configuration cannot be obtained within steps1-2, STOP: there is no acceptance,
and a negative rejection alone does not establish the slice. A negative timeout
or parse failure is inconclusive. The known historical v3 without-assistance
failure is not a reason to repeat that exhausted control.

Limits: one verifier worker, <=60s wall time per invocation, <=5 minutes verifier
wall time total, <=64 MiB fresh scratch/log/cache allocation. No compiler/vstd
builds, tests, network, Git operations, subdelegation, cleanup of inherited data,
or adoption of trust. Require >16 GiB free BEFORE each step and stop before any
allocation that could cross that floor. Keep logs/source hashes and distinguish
ordinary body proofs, retained exact-pair certificates, assistance telemetry and
publication. Do not use filtering/no-verify/no-lifetime to manufacture acceptance.

## What this report did and did not do

Read-only file/source-archive inspection and hashing; one initial git status
observation of the already dirty checkout. No compiler, build, test, verifier,
solver, network or Git-write command was run. No parent content was edited and
no parent/other-machine assumption was adopted. No subdelegation. No native
source was extracted to disk. Only this fresh report and unexecuted proposal
were written under /private/tmp; filesystem/global Git metadata continuity was
not independently audited. Visible inherited restriction: no rerun of interrupted
compiler-data perturbation tasks; none was attempted. Additional refused or
exhausted task identities not present in this brief cannot be inferred away.

Disk observations were 108,599,412 then 111,959,568 available 1-KiB blocks on the
shared /private/tmp volume (each >100 GiB, above the required >16 GiB floor).
No cleanup or large allocation was needed. Deliverable sizes are checked after
writing; this report is capped at 16 KiB.

**Bottom line:** propose a full-byte, both-case theorem on the original encoding
primitive, with visible ordinary proof work and one case-sensitive negative.
There is no new proved capability, accepted artifact, engine patch, whole-encoder
claim, fixed-array claim, backward-iteration claim, or successful restricted trial.
