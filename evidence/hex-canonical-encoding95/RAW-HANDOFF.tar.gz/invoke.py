import datetime
import json
import os
import pathlib
import resource
import shutil
import signal
import subprocess
import sys
import time

sys.dont_write_bytecode = True
ROOT = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from prepare import RUNTIME, authenticate, digest, record


def allocation():
    return sum(max(path.stat().st_size, path.stat().st_blocks * 512)
               for path in ROOT.rglob('*') if path.is_file())


def limits():
    resource.setrlimit(resource.RLIMIT_FSIZE, (8 * 1024**2, 8 * 1024**2))
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))


def invoke(number, cache_name):
    runs = sorted(ROOT.glob('invocation-*/result.json'))
    completed = [json.loads(path.read_text()) for path in runs]
    assert len(completed) < 5 and number not in [item['invocation'] for item in completed]
    assert sum(item['seconds'] for item in completed) < 240
    if number == 1:
        assert not completed
    elif number == 2:
        assert [item['invocation'] for item in completed] == [1]
        assert (ROOT / 'invocation2-authorization.json').is_file()
    elif number == 3:
        assert any(item['returncode'] == 0 for item in completed if item['invocation'] in (1, 2))
    elif number == 4:
        assert any(item['invocation'] == 3 and item['returncode'] != 0 for item in completed)
    elif number == 5:
        assert any(item['invocation'] == 4 and item['returncode'] == 0 for item in completed)
    else:
        raise RuntimeError('outside strict invocation plan')
    authenticate('pre-invocation-' + str(number))
    free = shutil.disk_usage(ROOT).free
    allocated = allocation()
    assert free > 16 * 1024**3 + 64 * 1024**2
    assert allocated < 48 * 1024**2
    destination = ROOT / ('invocation-' + str(number))
    destination.mkdir()
    cache = ROOT / cache_name
    if number != 5:
        cache.mkdir()
    else:
        assert cache.is_dir()
    for directory in ('home', 'tmp', 'xdg-cache'):
        (ROOT / directory).mkdir(exist_ok=True)
    sysroot = '/Users/tommyvolk/.rustup/toolchains/1.99.1-aarch64-apple-darwin'
    loader = json.loads((RUNTIME / 'fresh-qualification.json').read_text())['loader']['DYLD_LIBRARY_PATH']
    environment = {
        'PATH': sysroot + '/bin:/usr/bin:/bin:/usr/sbin:/sbin',
        'HOME': str(ROOT / 'home'),
        'TMPDIR': str(ROOT / 'tmp'),
        'XDG_CACHE_HOME': str(ROOT / 'xdg-cache'),
        'CARGO_NET_OFFLINE': 'true',
        'GIT_CONFIG_GLOBAL': '/dev/null',
        'GIT_CONFIG_NOSYSTEM': '1',
        'GIT_OPTIONAL_LOCKS': '0',
        'PYTHONDONTWRITEBYTECODE': '1',
        'RUSTUP_TOOLCHAIN': '1.99.1-aarch64-apple-darwin',
        'RUSTC_BOOTSTRAP': '1',
        'RUST_MIN_STACK': '20971520',
        'DYLD_LIBRARY_PATH': loader,
        'VERUS_USE_RUSTUP': '0',
        'VERUS_Z3_PATH': str(RUNTIME / 'runtime/z3'),
        'VERUS_INFER_CACHE': str(cache),
        'TZ': 'America/Chicago',
        'LC_ALL': 'C',
    }
    argv = [str(RUNTIME / 'runtime/verus'), str(ROOT / 'native/src/lib.rs'),
            '--crate-type', 'lib', '--crate-name', 'hex_conservative',
            '--cfg', 'feature="std"', '--cfg', 'feature="alloc"', '--cfg', 'verus_hex_vec_phase3',
            '--infer-goals', '--no-cheating', '--output-json',
            '--export', str(destination / 'hex_conservative.vir'),
            '--num-threads', '1', '--sysroot', sysroot, '--out-dir', str(destination), '--color', 'never']
    source_hashes = {str(path.relative_to(ROOT)): digest(path)
                     for path in sorted((ROOT / 'native').rglob('*')) if path.is_file()}
    cache_before = {str(path.relative_to(cache)): digest(path) for path in cache.rglob('*') if path.is_file()}
    record(str(destination.relative_to(ROOT) / 'invocation.json'),
           dict(invocation=number, argv=argv, environment=environment, cwd=str(ROOT / 'native'),
                timeout_seconds=60, total_limit_seconds=300, num_workers=1,
                source_hashes=source_hashes, cache_before=cache_before,
                disk_free_before=free, allocated_scratch_before=allocated,
                runtime_manifest_sha256=digest(RUNTIME / 'runtime-manifest.json'),
                started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()))
    started = time.monotonic()
    reason = None
    with (destination / 'stdout').open('wb') as stdout, (destination / 'stderr').open('wb') as stderr:
        process = subprocess.Popen(argv, cwd=ROOT / 'native', env=environment,
                                   stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr,
                                   start_new_session=True, preexec_fn=limits)
        while process.poll() is None:
            if time.monotonic() - started >= 59.5:
                reason = 'wall limit reached (killed before 60 seconds)'
            elif allocation() >= 60 * 1024**2:
                reason = 'scratch guard reached before 64 MiB'
            elif shutil.disk_usage(ROOT).free <= 16 * 1024**3:
                reason = 'free-disk guard reached'
            if reason:
                os.killpg(process.pid, signal.SIGKILL)
                break
            time.sleep(0.05)
        returncode = process.wait()
    seconds = time.monotonic() - started
    result = dict(invocation=number, returncode=returncode, seconds=seconds,
                  interrupted=reason, allocation_after=allocation(), free_bytes_after=shutil.disk_usage(ROOT).free,
                  stdout=dict(path=str(destination / 'stdout'), sha256=digest(destination / 'stdout')),
                  stderr=dict(path=str(destination / 'stderr'), sha256=digest(destination / 'stderr')),
                  exported=(destination / 'hex_conservative.vir').exists(),
                  cache_after={str(path.relative_to(cache)): digest(path) for path in cache.rglob('*') if path.is_file()})
    record(str(destination.relative_to(ROOT) / 'result.json'), result)
    print(json.dumps(result), flush=True)


if __name__ == '__main__':
    invoke(int(sys.argv[1]), sys.argv[2])
