import hashlib
import json
import pathlib
import shutil
import sys
import tarfile
import time

sys.dont_write_bytecode = True
ROOT = pathlib.Path(__file__).resolve().parent
PARENT = pathlib.Path('/Users/tommyvolk/.t3/worktrees/verus/t3-60978068')
EVIDENCE = PARENT / 'evidence/verus-infer-hex-v3'
RUNTIME = pathlib.Path('/private/tmp/verus-operational91-runtime.q91')
ASSESSMENT = pathlib.Path('/private/tmp/verus-hex-encode-assessment-20261107-TfFS9w')


def digest(path):
    checksum = hashlib.sha256()
    with pathlib.Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            checksum.update(chunk)
    return checksum.hexdigest()


def identity(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def load(path):
    return json.loads(pathlib.Path(path).read_text())


def record(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def check_artifact(binding):
    path = pathlib.Path(binding['path'])
    actual = digest(path)
    assert actual == binding['sha256'], (str(path), actual, binding['sha256'])
    return dict(binding, actual_sha256=actual, bytes=path.stat().st_size, authenticated=True)


def authenticate(label):
    assert shutil.disk_usage(ROOT).free > 16 * 1024**3
    manifest = load(RUNTIME / 'runtime-manifest.json')
    runtime_checks = {name: check_artifact(binding) for name, binding in manifest.items()}
    assert all(pathlib.Path(item['path']).parent == RUNTIME / 'runtime' for item in runtime_checks.values())
    qualification = load(RUNTIME / 'fresh-qualification.json')
    assert qualification['runtime'] == {name: item['sha256'] for name, item in manifest.items()}
    qualification_checks = {
        name: check_artifact(binding)
        for name, binding in qualification['source_runtime_qualification_artifacts'].items()
    }
    loader_checks = [check_artifact(binding) for binding in qualification['loader']['files']]
    compiler = load(RUNTIME / 'compiler-source-manifest.json')
    freeze = load(RUNTIME / 'freeze.json')
    assert identity(compiler) == freeze['compiler_manifest_sha256']
    assert compiler == load(RUNTIME / 'source-manifest.json')
    compiler_identity = identity({name: value for name, value in compiler.items()
                                 if name != qualification['test_only_source']})
    assert compiler_identity == qualification['compiler_sources_sha256'] == freeze['compiler_identity']
    assert identity(load(RUNTIME / 'full-source-manifest.json')) == freeze['full_manifest_sha256']
    historical_builds = {}
    for name in ('compiler-build', 'matched-vstd'):
        invocation = load(RUNTIME / 'runs' / name / 'invocation.json')
        result = load(RUNTIME / 'runs' / name / 'result.json')
        assert invocation['compiler_source_sha256'] == identity(compiler)
        assert result['returncode'] == 0 and not result['timeout']
        historical_builds[name] = dict(invocation=invocation, result=result,
                                      stdout=check_artifact(result['stdout']),
                                      stderr=check_artifact(result['stderr']))
    pinned = {
        'native-source.tar.gz': 'e7f4b63eced039d437b54858fc600071b41614aa66b2a9fdc27caa94c9e0de5b',
        'closure-summary.json': '762e7ac7cfc54b8a16624e36099086f524c2dd0f35b61be26b04157da98570af',
        'requirements-preservation.json': '9dd33548c9bc4ca813aa480affc38cb92464d6facbcc2f3b8ce67ade2cc0ab44',
    }
    parent_checks = {name: check_artifact(dict(path=str(EVIDENCE / name), sha256=value))
                     for name, value in pinned.items()}
    with tarfile.open(EVIDENCE / 'native-source.tar.gz', 'r:gz') as archive:
        lib = archive.extractfile('src/lib.rs').read()
    assert hashlib.sha256(lib).hexdigest() == 'c5d584fb99c620c8e086c970afcf14b36fa4bb8838d9ead1a415ef3142c67073'
    result = dict(time_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
                  runtime_manifest_sha256=digest(RUNTIME / 'runtime-manifest.json'),
                  runtime=runtime_checks, qualification=qualification,
                  qualification_checks=qualification_checks, loader=loader_checks,
                  rustc=check_artifact(qualification['rustc']),
                  compiler_source_manifest_identity=identity(compiler),
                  compiler_identity=compiler_identity, freeze=freeze,
                  historical_builds=historical_builds, parent=parent_checks,
                  native_lib_archive_sha256=hashlib.sha256(lib).hexdigest(),
                  free_bytes=shutil.disk_usage(ROOT).free,
                  qualification_scope='frozen campaign91 runtime only; not current parent/hardening95 or historical hex-v3')
    record('authentication-' + label + '.json', result)
    return result


def prepare():
    result = authenticate('entry')
    inputs = ROOT / 'inputs'
    inputs.mkdir(exist_ok=True)
    for name in ('REPORT.md', 'encoding_slice.proposed.rs'):
        shutil.copyfile(ASSESSMENT / name, inputs / ('assessment-' + name))
    for name in ('closure-summary.json', 'requirements-preservation.json', 'source-audit.json',
                 'assumptions.md', 'charter.md', 'README.md'):
        shutil.copyfile(EVIDENCE / name, inputs / name)
    for name in ('runtime-manifest.json', 'compiler-source-manifest.json', 'fresh-qualification.json',
                 'full-source-manifest.json', 'qualified-full-source-manifest.json', 'setup.json'):
        shutil.copyfile(RUNTIME / name, inputs / name)
    native = ROOT / 'native'
    native.mkdir(exist_ok=True)
    native_hashes = {}
    with tarfile.open(EVIDENCE / 'native-source.tar.gz', 'r:gz') as archive:
        members = archive.getmembers()
        assert sum(member.size for member in members) < 4 * 1024**2
        for member in members:
            relative = pathlib.PurePosixPath(member.name)
            assert not relative.is_absolute() and '..' not in relative.parts
            assert '.git' not in relative.parts
            assert member.isdir() or member.isfile()
            destination = native.joinpath(*relative.parts)
            if member.isdir():
                destination.mkdir(parents=True, exist_ok=True)
            else:
                destination.parent.mkdir(parents=True, exist_ok=True)
                destination.write_bytes(archive.extractfile(member).read())
                native_hashes[member.name] = digest(destination)
    with tarfile.open(EVIDENCE / 'raw-evidence.tar.gz', 'r:gz') as archive:
        member = archive.getmember('acceptance-committed/receipt.json')
        assert member.size < 8 * 1024**2
        data = archive.extractfile(member).read()
        (inputs / 'historical-v3-receipt.json').write_bytes(data)
    receipt = load(inputs / 'historical-v3-receipt.json')
    historical = next(case for case in receipt['cases'] if case['label'] == 'restored')
    assert receipt['native_commit'] == '54b6672c00c2cbeac8bcd7c6761cf1b0bec1a6a2'
    assert all(native_hashes[name] == value for name, value in receipt['native_sources_before'].items())
    record('native-authenticated-manifest.json', native_hashes)
    record('historical-v3-baseline.json', dict(command=next(command for command in receipt['commands']
                                                          if command['label'] == 'restored'),
                                              verification=historical['verification'],
                                              inference=historical['inference']))
    record('input-bindings.json', {str(path.relative_to(ROOT)): dict(sha256=digest(path), bytes=path.stat().st_size)
                                  for path in sorted(inputs.iterdir())})
    print(json.dumps(dict(authentication='all matched', runtime_artifacts=len(result['runtime']),
                          loader_files=len(result['loader']), native_files=len(native_hashes),
                          compiler_identity=result['compiler_identity'],
                          verifier_invocations=0, root=str(ROOT))))


if __name__ == '__main__':
    if sys.argv[1:] == ['prepare']:
        prepare()
    else:
        authenticate(sys.argv[1])
