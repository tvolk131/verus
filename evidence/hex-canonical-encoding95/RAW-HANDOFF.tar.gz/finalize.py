import collections
import json
import pathlib
import shutil
import sys

sys.dont_write_bytecode = True
ROOT = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from prepare import authenticate, digest, record


def finalize():
    output = json.loads((ROOT / 'invocation-1/stdout').read_text())
    invocation = json.loads((ROOT / 'invocation-1/invocation.json').read_text())
    result = json.loads((ROOT / 'invocation-1/result.json').read_text())
    baseline = json.loads((ROOT / 'historical-v3-baseline.json').read_text())
    audit = json.loads((ROOT / 'selected-source-audit-invocation1.json').read_text())
    scope = output['verus-infer']['verification_scope']
    old_functions = baseline['inference']['verification_scope']['native_functions']
    new_functions = scope['native_functions']
    old_selected = collections.Counter(item['rust_function'] for item in old_functions if item['selected'])
    new_selected = collections.Counter(item['rust_function'] for item in new_functions if item['selected'])
    missing = old_selected - new_selected
    added = new_selected - old_selected
    assert not missing
    assert sum(old_selected.values()) == 71 and sum(new_selected.values()) == 79
    assert scope['checked_exec_bodies'] == scope['checked_proof_bodies'] == 0
    assert output['verification-results']['encountered-vir-error']
    assert not output['verification-results']['success']
    assert not scope['complete_selected_scope_verified']
    assert not output['verus-infer']['interface_written']
    assert output['verus-infer']['functions'] == []
    assert result['returncode'] == 1 and not result['interrupted']
    assert result['seconds'] < 60
    for name, expected in invocation['source_hashes'].items():
        assert digest(ROOT / name) == expected
    assert digest(ROOT / 'invocation-1/stdout') == result['stdout']['sha256']
    assert digest(ROOT / 'invocation-1/stderr') == result['stderr']['sha256']
    assert audit['executable_signatures_and_bodies_unchanged_after_erasure']
    stderr = (ROOT / 'invocation-1/stderr').read_text()
    assert stderr.count('error: disallowed: constructor for an opaque datatype') == 2
    assert stderr.count('error: disallowed: field expression for an opaque datatype') == 1
    assert not (ROOT / 'invocation-2').exists()
    assert not (ROOT / 'invocation-3').exists()
    assert not (ROOT / 'invocation-4').exists()
    assert not (ROOT / 'invocation-5').exists()
    forbidden = ['--no-verify', '--no-lifetime', '--verify-function', '--verify-root', '--compile']
    assert not any(flag in invocation['argv'] for flag in forbidden)
    assert '--infer-goals' in invocation['argv'] and '--no-cheating' in invocation['argv']
    checks = dict(
        classification='NOT ACCEPTED — FRONTEND_VISIBILITY_BLOCKER',
        exact_errors=[dict(kind='opaque datatype constructor', item='Table::LOWER', location='native/src/lib.rs:406:40'),
                      dict(kind='opaque datatype constructor', item='Table::UPPER', location='native/src/lib.rs:414:40'),
                      dict(kind='opaque datatype field in crate-visible ensures', item='Table::byte_to_hex_chars',
                           location='native/src/lib.rs:448:27')],
        stop_reason='Failure is frontend visibility/well-formedness, not bounded nibble/table lemma proof work. Invocation 2 is unauthorized for this failure; no passing positive means controls 3–5 must not run.',
        verification_results=output['verification-results'], engine_reported_identity=output['verus'],
        scope=scope, source_selection_preservation=dict(
            comparison_key='rust_function (stable Rust spelling; translated VIR names unavailable after frontend error)',
            historical_selected=sum(old_selected.values()), current_selected=sum(new_selected.values()),
            missing=dict(missing), added=dict(added),
            historical_body_claims_not_revalidated=True,
            note='Collection/selection only. No translated body proof and no full-scope success.'),
        ordinary_checked_exec_bodies=0, ordinary_checked_proof_bodies=0,
        newly_inferred_helpers=0, newly_checked_helper_certificates=0,
        retained_historical_helper=dict(count=1, certificates=3, revalidated_in_this_run=False),
        assistance={key: value for key, value in output['verus-infer'].items()
                    if 'assistance' in key or key in ('metrics', 'status', 'trust', 'crate_success',
                                                     'interface_written', 'generation_failure', 'functions')},
        publication=dict(vir_export_exists=result['exported'], infer_interface_written=False,
                         adoption=False, integration=False),
        inputs_unchanged_since_invocation=True,
        proof_attempts=[result], direct_invocations=1, failed_direct_invocations=1,
        total_direct_verifier_wall_seconds=result['seconds'],
        controls=[dict(invocation=1, state='failed frontend, not a semantic proof rejection'),
                  dict(invocation=2, state='not eligible; no correction and no rerun'),
                  dict(invocation=3, state='not run; prerequisite positive missing'),
                  dict(invocation=4, state='not run; prerequisite positive/control missing'),
                  dict(invocation=5, state='not run; prerequisite fresh positive missing')],
        budget=dict(max_workers=1, max_invocations=5, per_invocation_wall_seconds=60,
                    total_verifier_wall_seconds=300, scratch_limit_bytes=64 * 1024**2,
                    required_free_bytes=16 * 1024**3, disk_free_before=invocation['disk_free_before'],
                    scratch_allocated_before=invocation['allocated_scratch_before'],
                    disk_free_after=shutil.disk_usage(ROOT).free),
        parent_files_modified=False, runtime_files_modified=False, frozen_inputs_modified=False,
        native_tests_run=0, compiler_builds=0, vstd_builds=0, cargo_builds=0,
        subdelegates=0, network_operations=0, git_operations=0,
        redb_all18_and_S0_Infer_import_export_barriers='unchanged; no integration or trust adoption',
    )
    record('proof-result-checks.json', checks)
    authentication = authenticate('exit')
    assert authentication['runtime_manifest_sha256'] == json.loads(
        (ROOT / 'authentication-entry.json').read_text())['runtime_manifest_sha256']
    assert {name: value['actual_sha256'] for name, value in authentication['runtime'].items()} == {
        name: value['actual_sha256'] for name, value in json.loads(
            (ROOT / 'authentication-entry.json').read_text())['runtime'].items()}
    assert (ROOT / 'REPORT.md').stat().st_size <= 24 * 1024
    record('finalization-summary.json', dict(
        classification=checks['classification'], verifier_invocations=1,
        verifier_wall_seconds=result['seconds'],
        report_bytes=(ROOT / 'REPORT.md').stat().st_size,
        allocated_bytes_before_final_manifest=sum(max(path.stat().st_size, path.stat().st_blocks * 512)
                                                 for path in ROOT.rglob('*') if path.is_file()),
        exit_authentication_passed=True, selected_scope_retained=True, full_scope_verified=False,
        checked_exec_bodies=0, checked_proof_bodies=0,
        no_additional_execution_authorized=True))
    record('output-manifest.json', {str(path.relative_to(ROOT)): dict(sha256=digest(path), bytes=path.stat().st_size)
                                   for path in sorted(ROOT.rglob('*'))
                                   if path.is_file() and path.name != 'output-manifest.json'})
    allocated = sum(max(path.stat().st_size, path.stat().st_blocks * 512)
                    for path in ROOT.rglob('*') if path.is_file())
    assert allocated < 64 * 1024**2
    print(json.dumps(dict(classification=checks['classification'], invocations=1,
                          verifier_seconds=result['seconds'], scratch_allocated_bytes=allocated,
                          report_bytes=(ROOT / 'REPORT.md').stat().st_size,
                          disk_free_bytes=shutil.disk_usage(ROOT).free,
                          exit_authentication='all nine runtime artifacts, source/build bindings and loader files matched',
                          selected_scope_retained=True, full_scope_verified=False,
                          checked_exec_bodies=0, checked_proof_bodies=0)))


if __name__ == '__main__':
    finalize()
