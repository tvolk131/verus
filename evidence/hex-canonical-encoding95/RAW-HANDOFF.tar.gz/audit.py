import collections
import difflib
import hashlib
import json
import pathlib
import re
import sys
import tarfile

sys.dont_write_bytecode = True
ROOT = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from prepare import EVIDENCE, digest, record


def function(text, name):
    match = re.search(r'pub\(crate\) fn ' + name + r'\b[^\{]*\{', text)
    assert match, name
    depth = 1
    position = match.end()
    while depth:
        depth += (text[position] == '{') - (text[position] == '}')
        position += 1
    return text[match.start():position]


def audit(label):
    native = ROOT / 'native'
    baseline = json.loads((ROOT / 'native-authenticated-manifest.json').read_text())
    current = {str(path.relative_to(native)): digest(path)
               for path in native.rglob('*') if path.is_file()}
    assert set(current) == set(baseline) | {'src/encoding_spec.rs'}
    assert [name for name in baseline if baseline[name] != current[name]] == ['src/lib.rs']
    with tarfile.open(EVIDENCE / 'native-source.tar.gz', 'r:gz') as archive:
        before = archive.extractfile('src/lib.rs').read().decode()
    after = (native / 'src/lib.rs').read_text()
    additions = []
    matcher = difflib.SequenceMatcher(a=before.splitlines(True), b=after.splitlines(True), autojunk=False)
    for tag, before_start, before_end, after_start, after_end in matcher.get_opcodes():
        assert tag in ('equal', 'insert'), (tag, before_start, after_start)
        if tag == 'insert':
            additions.append(dict(before_line=before_start + 1, after_line=after_start + 1,
                                  text=''.join(after.splitlines(True)[after_start:after_end])))
    original_functions = {name: function(before, name) for name in ('table', 'byte_to_hex_chars')}
    current_functions = {name: function(after, name) for name in original_functions}
    ghost_call = '            #[cfg(verus_keep_ghost)]\n            proof! { crate::encoding_spec::encoding_index_facts(byte); }\n'
    erased_functions = {name: body.replace(ghost_call, '') for name, body in current_functions.items()}
    assert erased_functions == original_functions
    constants = {}
    for name in ('LOWER', 'UPPER'):
        pattern = r'pub\(crate\) const ' + name + r': Self = Table\(\[.*?\]\);'
        original = re.search(pattern, before, re.S).group(0)
        candidate = re.search(pattern, after, re.S).group(0)
        assert candidate == original
        constants[name] = dict(initializer_sha256=hashlib.sha256(original.encode()).hexdigest(),
                               original_initializer_unchanged=True,
                               explicitly_selected=bool(re.search(r'verus_verify\)\]\n\s*' + pattern, after, re.S)))
        assert constants[name]['explicitly_selected']
    new_module = (native / 'src/encoding_spec.rs').read_text()
    assert not re.search(r'\b(assume|admit|axiom|external_body|assume_specification)\b', new_module)
    assert 'requires' not in new_module
    added = ''.join(item['text'] for item in additions)
    assert not re.search(r'\b(assume|admit|axiom|external_body|assume_specification|requires)\b', added)
    delta = ''.join(difflib.unified_diff(before.splitlines(True), after.splitlines(True),
                                       fromfile='authenticated-v3/src/lib.rs', tofile='candidate/src/lib.rs'))
    delta += ''.join(difflib.unified_diff([], new_module.splitlines(True),
                                        fromfile='/dev/null', tofile='candidate/src/encoding_spec.rs'))
    (ROOT / ('source-delta-' + label + '.patch')).write_text(delta)
    snapshot = ROOT / ('source-' + label)
    snapshot.mkdir()
    (snapshot / 'lib.rs').write_text(after)
    (snapshot / 'encoding_spec.rs').write_text(new_module)
    result = dict(manifest=current, additions=additions, changes_only_insertions=True,
                  all_53_archived_files_preserved_except_additive_lib_annotations=True,
                  executable_signatures_and_bodies_unchanged_after_erasure=True,
                  all_original_218_function_preservation_inherited_from_authenticated_v3_audit=True,
                  constants=constants, native_types_and_derives_unchanged=True,
                  full_retained_scope_and_requirements_preserved=True,
                  no_preconditions_on_new_encoding_functions=True,
                  policy='independent integer ASCII: 48+n if n<10, otherwise Lower 87+n / Upper 55+n',
                  case_domain=['Lower', 'Upper'], byte_domain='all u8 values 0..=255',
                  helper_domain='every legal Table([Char;16]); selection equations unconditional; canonical implications only',
                  original_function_hashes={name: hashlib.sha256(body.encode()).hexdigest()
                                            for name, body in original_functions.items()},
                  erased_function_hashes={name: hashlib.sha256(body.encode()).hexdigest()
                                          for name, body in erased_functions.items()},
                  selection_annotation_counts_before=dict(collections.Counter(re.findall(r'verus_verify[^\n]*', before))),
                  selection_annotation_counts_after=dict(collections.Counter(re.findall(r'verus_verify[^\n]*', after))))
    record('selected-source-audit-' + label + '.json', result)
    print(json.dumps(dict(audit='passed', label=label, original_files=len(baseline),
                          lib_sha256=current['src/lib.rs'], encoding_spec_sha256=current['src/encoding_spec.rs'],
                          constants=constants)))
    return result


if __name__ == '__main__':
    audit(sys.argv[1])
