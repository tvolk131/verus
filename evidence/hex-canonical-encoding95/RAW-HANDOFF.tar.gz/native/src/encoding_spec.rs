use vstd::prelude::*;

verus! {

pub(crate) open spec fn required_digit_ascii(nibble: int, case: crate::Case) -> int {
    if nibble < 10 {
        48 + nibble
    } else {
        match case {
            crate::Case::Lower => 87 + nibble,
            crate::Case::Upper => 55 + nibble,
        }
    }
}

pub(crate) open spec fn required_encoding(
    byte: u8,
    case: crate::Case,
    result: [crate::Char; 2],
) -> bool {
    (result@[0] as u8) as int == required_digit_ascii((byte as int) / 16, case)
        && (result@[1] as u8) as int == required_digit_ascii((byte as int) % 16, case)
}

fn canonical_byte_encoding_goal(byte: u8, case: crate::Case) -> (result: [crate::Char; 2])
    ensures
        required_encoding(byte, case, result),
{
    case.table().byte_to_hex_chars(byte)
}

}
